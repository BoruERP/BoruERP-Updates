using System.Text.Json;
using MiapaxERP.Desktop;
using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;
public sealed class DestekIzlemeTestleri
{
    [Fact]public void HamSqlVeParolaHataBildirimineGirmez()
    {
        var raw="Geçerli hesap kodu bulunamadı. password=SECRET SQL SELECT customer_data";
        var result=DestekIzleme.Siniflandir(new ArgumentException(raw),"Muhasebe");Assert.Equal("ACCOUNT_CODE_INVALID",result.Code);Assert.Equal("MUHASEBE",result.Module);
        string payload=JsonSerializer.Serialize(new DestekHata(Guid.NewGuid(),result.Code,result.Module));Assert.DoesNotContain("SECRET",payload);Assert.DoesNotContain("customer_data",payload);
    }
    [Fact]public void LaboratuvarLisansEksigiAyrilir()
    {
        var value=DestekIzleme.Siniflandir(new UnauthorizedAccessException("Bu modül lisans kapsamında değil"),"LABORATUVAR");Assert.Equal("MODULE_LICENSE_MISSING",value.Code);Assert.Equal("LABORATUVAR",value.Module);
    }
    [Fact]public void DonanimBilgisiOkumaYoneticiYetkisiGerektirmez()
    {
        var result=DestekIzleme.Cihaz();Assert.Matches("^[A-F0-9]{64}$",result.Device);Assert.NotEmpty(result.Info.Os);Assert.NotEmpty(result.Info.Version);Assert.True(result.Info.RamGb is null or >0);Assert.True(result.Info.DiskTotalGb is null or >0);
    }
}
