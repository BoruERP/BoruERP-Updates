using System.Data;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using MiapaxERP.Desktop;
using MiapaxERP.Guncelleme;
using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;

public sealed class ModulGorunum283Testleri
{
    [Theory]
    [InlineData("https://raw.githubusercontent.com/BoruERP/BoruERP-Updates/main/manifest-yan.json","Yan","https://raw.githubusercontent.com/MiaPaxERP/MiapaxERP-Updates/main/manifest-yan.json")]
    [InlineData("https://example.com/manifest-ana.json","Ana","https://example.com/manifest-ana.json")]
    [InlineData("https://raw.githubusercontent.com/BoruERP/BoruERP-Updates/main/manifest-ana.json","Yan","https://raw.githubusercontent.com/BoruERP/BoruERP-Updates/main/manifest-ana.json")]
    public void EskiYayinAdresiYalnizBilinenKanalIcinTasinir(string source,string channel,string expected)=>Assert.Equal(expected,GuncellemeKanalAyari.ManifestAdresi(source,channel));
    [Fact]public async Task SekizModulTemayaUyarVeKendineOzelYerlesimleCizilir()
    {
        var done=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var thread=new Thread(()=>{try{
            var owner=new MainWindow(true);var menu=(WrapPanel)owner.FindName("TemaMenuOgeleri");var style=(Style)owner.Resources["MenuButton"];
            foreach(var button in menu.Children.OfType<Button>().Where(b=>b.Tag is string s&&IsletmePaneli.sections.ContainsKey(s)))Assert.Same(style,button.Style);
            var layouts=new HashSet<string>();string folder=Path.Combine(AppContext.BaseDirectory,"TestResults","Ui283");Directory.CreateDirectory(folder);
            foreach(string kind in IsletmePaneli.sections.Keys)
            foreach(bool dark in new[]{false,true})
            {
                var panel=new IsletmePaneli(owner,"Server=not-used;Database=not-used",1,kind);Assert.Equal(kind,panel.ModulKodu);layouts.Add(panel.YerlesimKodu);
                panel.Resources.MergedDictionaries.Add(new ResourceDictionary{Source=new Uri("pack://application:,,,/MiapaxERP.Desktop;component/Assets/ModernKontroller.xaml")});
                Theme(panel.Resources,dark);var data=Sample(kind);panel.VeriyiGoster(data);Render(panel,Path.Combine(folder,kind+(dark?"-koyu":"-acik")+".png"),1240,820);
                Assert.Equal(dark?"#FF172333":"#FFEDF3F8",((SolidColorBrush)panel.Background).Color.ToString());
            }
            Assert.Equal(8,layouts.Count);
            var login=new GirisPenceresi("Server=not-used");Theme(login.Resources,false);Render((FrameworkElement)login.Content,Path.Combine(folder,"giris.png"),850,640);
            var animation=(GirisAkisAnimasyonu)login.FindName("GirisArkaPlanAnimasyonu");Assert.False(animation.Oynuyor);animation.OnizlemeSaniyesi=1;Render(animation,Path.Combine(folder,"akis-1.png"),315,640);animation.OnizlemeSaniyesi=4;Render(animation,Path.Combine(folder,"akis-2.png"),315,640);Assert.NotEqual(File.ReadAllBytes(Path.Combine(folder,"akis-1.png")),File.ReadAllBytes(Path.Combine(folder,"akis-2.png")));login.Close();owner.Close();done.SetResult();
        }catch(Exception e){done.SetException(e);}});thread.SetApartmentState(ApartmentState.STA);thread.Start();await done.Task.WaitAsync(TimeSpan.FromSeconds(60));
    }
    static void Theme(ResourceDictionary r,bool dark)
    {
        r["ErpMenu"]=new SolidColorBrush((Color)ColorConverter.ConvertFromString("#112C45"));
        foreach(var (key,color) in new[]{("ErpZemin",dark?"#172333":"#EDF3F8"),("ErpKart",dark?"#203044":"#FFFFFF"),("ErpMetin",dark?"#F2F7FF":"#182E42"),("ErpCizgi",dark?"#435568":"#D4DEE6"),("ErpVurgu","#0869A6")})r[key]=new SolidColorBrush((Color)ColorConverter.ConvertFromString(color));r["ErpKose"]=new CornerRadius(10);r["ErpBosluk"]=new Thickness(14,8,14,8);r["ErpSatir"]=36d;
    }
    static void Render(FrameworkElement element,string path,int width,int height)
    {
        element.Measure(new Size(width,height));element.Arrange(new Rect(0,0,width,height));element.UpdateLayout();var bitmap=new RenderTargetBitmap(width,height,96,96,PixelFormats.Pbgra32);bitmap.Render(element);var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(bitmap));using var file=File.Create(path);encoder.Save(file);
    }
    static DataTable Sample(string kind)
    {
        var t=new DataTable();t.Columns.Add("Id",typeof(long));t.Columns.Add("Surum",typeof(byte[]));
        string[] fields=kind switch{"Sevkiyat"=>new[]{"SevkiyatNo","Musteri","Nereden","Nereye","Plaka","Sofor","Durum"},"BasincTest"=>new[]{"TestNo","Urun","Parti","Standart","HedefBar","IlkBar","SonBar","Durum"},"Depo"=>new[]{"LotId","StokAdi","Birim","Depo","Raf","Parti","Kalite","Miktar","Rezerve","Kullanilabilir"},"Muhasebe"=>new[]{"Kod","Ad","Borc","Alacak","Bakiye"},"Tahsilat"=>new[]{"BelgeNo","Musteri","Doviz","Toplam","Kapanan","Kalan","KalanTRY"},"Makine"=>new[]{"Kod","Makine","GunlukDakika","MakineSaatTRY","IscilikSaatTRY","EnerjiSaatTRY"},"UretimMaliyet"=>new[]{"UretimEmriNo","Makine","MalzemeTRY","DonusumTRY","ToplamTRY","BirimMaliyetTRY"},_=>new[]{"BelgeNo","Tedarikci","Termin","Doviz","Durum"}};
        foreach(string f in fields)t.Columns.Add(f);var row=t.NewRow();row["Id"]=1L;row["Surum"]=new byte[8];foreach(string f in fields)row[f]=f switch{"Durum"=>"Taslak","Doviz"=>"TRY","Kalite"=>"Serbest","Depo"=>"Merkez","Raf"=>"A-01","Nereden"=>"İstanbul","Nereye"=>"Ankara","Musteri" or "Tedarikci"=>"Örnek firma","Plaka"=>"34 ABC 123","Sofor"=>"Örnek şoför","Borc" or "ToplamTRY" or "Toplam"=>"1200","Alacak" or "Kapanan"=>"200","Kalan" or "KalanTRY" or "Bakiye"=>"1000","HedefBar" or "IlkBar" or "SonBar"=>"10","GunlukDakika"=>"480",_=>"Örnek kayıt"};t.Rows.Add(row);return t;
    }
}
