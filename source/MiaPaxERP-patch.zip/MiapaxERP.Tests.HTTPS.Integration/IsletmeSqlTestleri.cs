using System.Data;
using System.IO;
using System.Text.RegularExpressions;
using Microsoft.Data.SqlClient;
using MiapaxERP.Desktop;
using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;
public sealed class IsletmeSqlTestleri
{
    static void Sql(SqlConnection c,string text){using var q=new SqlCommand(text,c){CommandTimeout=60};q.ExecuteNonQuery();}
    static decimal Scalar(SqlConnection c,string text){using var q=new SqlCommand(text,c);return Convert.ToDecimal(q.ExecuteScalar());}
    [Fact] public void IzoleVeritabanindaSatisDepoMuhasebeVeSatinalmaButunlugu()
    {
        string name="MiapaxHttps310_"+Guid.NewGuid().ToString("N");using var master=new SqlConnection(Environment.GetEnvironmentVariable("MIAPAX_TEST_SQL")??"Server=localhost;Database=master;Integrated Security=true;Encrypt=true;TrustServerCertificate=true;Pooling=false;Connect Timeout=5");master.Open();Sql(master,"CREATE DATABASE ["+name+"]");
        try
        {
            string cs=new SqlConnectionStringBuilder(master.ConnectionString){InitialCatalog=name}.ConnectionString;using var c=new SqlConnection(cs);c.Open();Sql(c,"""
            CREATE TABLE dbo.StokKartlari(Id int PRIMARY KEY,StokKodu nvarchar(50),StokAdi nvarchar(200),Birim nvarchar(20),StokTipi nvarchar(30),Aktif bit);
            INSERT dbo.StokKartlari VALUES(1,'RAW',N'Hammadde','KG',N'Hammadde',1),(2,'PIPE',N'Boru','Adet',N'Kangal',1);
            CREATE TABLE dbo.StokBakiyeleri(StokKartId int PRIMARY KEY,Birim nvarchar(20),Miktar decimal(18,3));INSERT dbo.StokBakiyeleri VALUES(1,'KG',100),(2,'Adet',100);
            CREATE TABLE dbo.StokHareketleri(Id bigint IDENTITY PRIMARY KEY,StokKartId int,HareketTipi nvarchar(50),Yon nchar(1),Miktar decimal(18,3),Birim nvarchar(20),Aciklama nvarchar(500),UretimStokIslemId bigint NULL);
            CREATE TABLE dbo.CariKartlari(Id int PRIMARY KEY,CariKodu nvarchar(50),Unvan nvarchar(100),Aktif bit);INSERT dbo.CariKartlari VALUES(1,'C1',N'Müşteri',1),(2,'V1',N'Tedarikçi',1);
            CREATE TABLE dbo.CariHareketleri(Id bigint IDENTITY PRIMARY KEY,CariId int,Tarih date,HareketTipi nvarchar(30),Tutar decimal(18,2),Aciklama nvarchar(400),Kaynak nvarchar(100),YapanKullaniciId int,TersKayitId bigint NULL);
            CREATE TABLE dbo.FinansHesaplari(Id int PRIMARY KEY,HesapAdi nvarchar(100),HesapTipi nvarchar(30),ParaBirimi varchar(3),Aktif bit);INSERT dbo.FinansHesaplari VALUES(1,'TEST KASA',N'Kasa','TRY',1),(2,'TEST USD',N'Banka','USD',1);
            CREATE TABLE dbo.FinansHareketleri(Id bigint IDENTITY PRIMARY KEY,HesapId int,CariId int NULL,CariHareketId bigint NULL,Tarih date,HareketTipi nvarchar(30),Tutar decimal(18,2),Aciklama nvarchar(400),YapanKullaniciId int,TersKayitId bigint NULL);
            CREATE TABLE dbo.BoruERP_YeniBelgeler(Id bigint IDENTITY PRIMARY KEY,BelgeTuru nchar(1),BelgeNo nvarchar(80),CariId int,Tarih date,GecerlilikTarihi date NULL,OdemeDurumu nvarchar(20),AraToplam decimal(18,2),KdvToplam decimal(18,2),Indirim decimal(18,2),GenelToplam decimal(18,2),Aciklama nvarchar(400),KaynakTeklifId bigint NULL,YapanKullaniciId int,Durum nvarchar(30) DEFAULT N'Kaydedildi',ParaBirimi varchar(3) DEFAULT 'TRY');
            CREATE TABLE dbo.BoruERP_YeniBelgeKalemleri(Id bigint IDENTITY PRIMARY KEY,BelgeId bigint,StokKartId int,UrunAciklama nvarchar(350),Birim nvarchar(20),Miktar decimal(18,3),BirimFiyat decimal(18,2),KdvOrani decimal(5,2),SatirAraToplam decimal(18,2),KdvTutari decimal(18,2),SatirGenelToplam decimal(18,2));
            CREATE TABLE dbo.Yetkiler(YetkiKodu varchar(100) PRIMARY KEY,Modul nvarchar(100),Islem nvarchar(100),Aciklama nvarchar(200),Aktif bit);
            CREATE TABLE dbo.BERP260_LabCihaz(Id bigint PRIMARY KEY,Kod nvarchar(40),Ad nvarchar(160),Kalibrasyon date,Gecerlilik date,Belge nvarchar(250));INSERT dbo.BERP260_LabCihaz VALUES(1,'T1','TEST',DATEADD(year,-1,GETDATE()),DATEADD(year,1,GETDATE()),'TEST');
            CREATE TABLE dbo.BERP260_LabBloke(NumuneId bigint PRIMARY KEY,StokId int,Aktif bit);
            """);
            var service=new IsletmeServisi(cs,1,(_,_,_)=>{});service.Kur();service.Kur();int shelf=Convert.ToInt32(Scalar(c,"SELECT MIN(Id) FROM dbo.MPX310_Raf"));long lot=service.PartiDevret(Guid.NewGuid(),2,shelf,"P-001",100,10,"TEST açılış dayanağı");
            var sale=new SatisGirdisi(Guid.NewGuid(),false,"SALE-001",1,DateTime.Today,null,"TRY",1,0,"TEST",null,new[]{new SatisKalemi(2,10,20,20)},1,240,1);long saleId=service.SatisKaydet(sale);
            Assert.Equal(90,Scalar(c,"SELECT Miktar FROM dbo.StokBakiyeleri WHERE StokKartId=2"));Assert.Equal(90,Scalar(c,"SELECT Miktar FROM dbo.MPX310_LotBakiye WHERE LotId="+lot));Assert.Equal(0,Scalar(c,"SELECT SUM(CASE HareketTipi WHEN N'Borç' THEN Tutar ELSE -Tutar END) FROM dbo.CariHareketleri WHERE CariId=1"));Assert.Equal(240,Scalar(c,"SELECT SUM(Tutar) FROM dbo.FinansHareketleri"));Assert.Equal(0,Scalar(c,"SELECT COUNT(*) FROM(SELECT FisId FROM dbo.MPX310_FisKalem GROUP BY FisId HAVING SUM(Borc-Alacak)<>0) q"));Assert.Throws<InvalidOperationException>(()=>service.SatisKaydet(sale));
            long docs=Convert.ToInt64(Scalar(c,"SELECT COUNT(*) FROM dbo.BoruERP_YeniBelgeler"));Assert.Throws<InvalidOperationException>(()=>service.SatisKaydet(sale with{Anahtar=Guid.NewGuid(),No="TOO-MUCH",Kalemler=new[]{new SatisKalemi(2,1000,20,20)},Tahsilat=0}));Assert.Equal(docs,Convert.ToInt64(Scalar(c,"SELECT COUNT(*) FROM dbo.BoruERP_YeniBelgeler")));
            var shipment=new SevkiyatGirdisi(Guid.NewGuid(),null,null,"SVK-1",1,"Fabrika","Müşteri",DateTime.Today,"Karayolu","34 TEST 1","Şoför","",5000,5100,saleId,new[]{new SevkiyatKalemi(2,lot,shelf,10)},"TEST");long ship=service.SevkiyatKaydet(shipment);service.SevkEt(ship,(byte[])service.Oku(ship,"Sevkiyat")["Surum"]);Assert.Equal(90,Scalar(c,"SELECT Miktar FROM dbo.StokBakiyeleri WHERE StokKartId=2"));
            Assert.Throws<InvalidOperationException>(()=>service.SevkEt(ship,(byte[])service.Oku(ship,"Sevkiyat")["Surum"]));
            var pressure=new BasincTestGirdisi(Guid.NewGuid(),null,null,"BST-1",2,lot,1,"Hidrostatik","TEST şartnamesi",DateTimeOffset.UtcNow.AddHours(-2),DateTimeOffset.UtcNow.AddHours(-1),20,10,10,10,1,false,"TEST ölçümleri");long test=service.BasincKaydet(pressure);byte[] version=(byte[])service.Oku(test,"BasincTest")["Surum"];
            Assert.Throws<InvalidOperationException>(()=>service.BasincIncele(test,version,true,"TEST kendi onayı engellenmeli"));var reviewer=new IsletmeServisi(cs,2,(_,_,_)=>{});reviewer.BasincIncele(test,version,true,"TEST bağımsız teknik inceleme");service.PartiSerbestBirak(lot,"TEST laboratuvar serbest bırakma");
            var fxSale=sale with{Anahtar=Guid.NewGuid(),No="FX-001",Para="USD",Kur=.333333m,Kalemler=new[]{new SatisKalemi(2,3,1,0)},Tahsilat=0,TahsilatHesabi=null};long fxId=service.SatisKaydet(fxSale);for(int i=0;i<3;i++)service.Tahsilat(new(Guid.NewGuid(),fxId,2,DateTime.Today,1,.4m,"TEST kısmi döviz tahsilatı"));Assert.Equal(0,Scalar(c,"SELECT SUM(CASE HareketTipi WHEN N'Borç' THEN Tutar ELSE -Tutar END) FROM dbo.CariHareketleri WHERE CariId=1"));Assert.Equal(1,Scalar(c,"SELECT SUM(DefterTutar) FROM dbo.MPX310_Tahsilat WHERE BelgeId="+fxId));
            service.DepoKaydet(new("SUBE","Şube depo","R1","İlk raf"));int target=Convert.ToInt32(Scalar(c,"SELECT MAX(Id) FROM dbo.MPX310_Raf"));long reservation=service.Rezerve(new(Guid.NewGuid(),null,lot,shelf,50,"TEST sipariş rezervasyonu"));Assert.Throws<InvalidOperationException>(()=>service.Transfer(new(Guid.NewGuid(),lot,shelf,target,40,"TEST rezervasyonu aşan transfer")));service.Transfer(new(Guid.NewGuid(),lot,shelf,target,30,"TEST raf transferi"));Assert.Equal(87,Scalar(c,"SELECT Miktar FROM dbo.StokBakiyeleri WHERE StokKartId=2"));
            var countRow=service.DepoBakiyeleri().AsEnumerable().Single(r=>(long)r["LotId"]==lot&&(int)r["RafId"]==shelf);byte[] countVersion=(byte[])countRow["Surum"];Assert.Throws<InvalidOperationException>(()=>service.Sayim(new(Guid.NewGuid(),"COUNT-BAD",DateTime.Today,new[]{new SayimKalemi(lot,shelf,49,countVersion)},"TEST rezerve miktardan az")));service.Sayim(new(Guid.NewGuid(),"COUNT-OK",DateTime.Today,new[]{new SayimKalemi(lot,shelf,60,countVersion)},"TEST fiilî sayım farkı"));Assert.Equal(90,Scalar(c,"SELECT Miktar FROM dbo.StokBakiyeleri WHERE StokKartId=2"));Assert.Equal(30,Scalar(c,"SELECT SUM(Alacak-Borc) FROM dbo.MPX310_FisKalem WHERE Hesap='397'"));service.RezervasyonBirak(reservation,"TEST sipariş iptali");
            var order=new SatinAlmaGirdisi(Guid.NewGuid(),null,null,"PO-1",2,DateTime.Today,DateTime.Today,"TRY",1,new[]{new SiparisKalemi(1,shelf,20,10,20,"")},"TEST");long po=service.SiparisKaydet(order);service.MalKabul(new(Guid.NewGuid(),po,DateTime.Today,new[]{new MalKabulKalemi(0,10,"RAW-001",false)},"TEST teslim"));Assert.Throws<InvalidOperationException>(()=>service.MalKabul(new(Guid.NewGuid(),po,DateTime.Today,new[]{new MalKabulKalemi(0,11,"RAW-002",false)},"TEST fazla")));Assert.Throws<InvalidOperationException>(()=>service.AlisFaturasi(new(Guid.NewGuid(),po,"INV-BAD",DateTime.Today,new[]{new AlisFaturaKalemi(0,10,11,20)},"TEST fiyat farkı")));service.AlisFaturasi(new(Guid.NewGuid(),po,"INV-OK",DateTime.Today,new[]{new AlisFaturaKalemi(0,10,10,20)},"TEST eşleşti"));Assert.Equal(110,Scalar(c,"SELECT Miktar FROM dbo.StokBakiyeleri WHERE StokKartId=1"));
            service.DonemDurumu(DateTime.Today.Year,DateTime.Today.Month,true,"TEST dönem kapanışı");Assert.Throws<InvalidOperationException>(()=>service.FisKaydet(new(Guid.NewGuid(),DateTime.Today,"TEST kapalı dönem",new[]{new MuhasebeKalemi("100",1,0,null,"TEST"),new MuhasebeKalemi("500",0,1,null,"TEST")})));
        }
        finally
        {
            if(!Regex.IsMatch(name,"^MiapaxHttps310_[a-f0-9]{32}$"))throw new InvalidOperationException("Test temizleme hedefi geçersiz.");Sql(master,"ALTER DATABASE ["+name+"] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;DROP DATABASE ["+name+"]");
        }
    }
}

