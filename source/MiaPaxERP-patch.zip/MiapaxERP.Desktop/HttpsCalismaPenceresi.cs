using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
namespace MiapaxERP.Desktop;

// Yan cihaz yalnız HTTPS istemcisini ve kendi yerel ekranlarını çalıştırır.
public sealed class HttpsGirisPenceresi : Window
{
    readonly TextBox name=new(){MinHeight=36,MaxLength=60};
    readonly PasswordBox pass=new(){MinHeight=36,MaxLength=512};
    readonly TextBlock status=new(){TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,12,0,0)};
    readonly Button submit=new(){Content="Giriş yap",MinHeight=42,Margin=new Thickness(0,16,0,0),IsDefault=true};
    readonly CancellationTokenSource stop=new();bool busy;
    public HttpsIstemci? Istemci {get;private set;}
    public HttpsGirisPenceresi(string address)
    {
        Title="MiaPaxERP · Sunucuya giriş";Width=850;Height=680;MinWidth=850;MinHeight=680;WindowStartupLocation=WindowStartupLocation.CenterScreen;
        var root=new Grid();root.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(315)});root.ColumnDefinitions.Add(new ColumnDefinition());Content=root;
        var brand=new Grid{Background=new SolidColorBrush((Color)ColorConverter.ConvertFromString("#17263D"))};root.Children.Add(brand);brand.Children.Add(new GirisAkisAnimasyonu());
        var intro=new StackPanel{Margin=new Thickness(30,42,30,30)};brand.Children.Add(intro);
        intro.Children.Add(new Border{Background=Brushes.White,CornerRadius=new CornerRadius(8),Padding=new Thickness(10),Height=105,Child=new System.Windows.Controls.Image{Source=new System.Windows.Media.Imaging.BitmapImage(new Uri("pack://application:,,,/MiapaxERP.Desktop;component/Assets/MiapaxERP_Wordmark.png")),Stretch=Stretch.Uniform}});
        intro.Children.Add(new TextBlock{Text="İŞLETME YÖNETİM SİSTEMİ",Foreground=Brushes.LightSteelBlue,FontSize=12,Margin=new Thickness(0,20,0,24)});
        intro.Children.Add(new TextBlock{Text="İşinizin her adımı,\ntek bir merkezde.",Foreground=Brushes.White,FontSize=21,TextWrapping=TextWrapping.Wrap});
        intro.Children.Add(new TextBlock{Text="Kişisel hesabınızla güvenli sunucu bağlantısı üzerinden giriş yapın.",Foreground=Brushes.LightSteelBlue,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,22,0,0)});
        var p=new StackPanel{Margin=new Thickness(38),VerticalAlignment=VerticalAlignment.Center};Grid.SetColumn(p,1);root.Children.Add(p);
        p.Children.Add(new TextBlock{Text="MiaPaxERP hesabınızla giriş yapın",FontSize=22,FontWeight=FontWeights.SemiBold,TextWrapping=TextWrapping.Wrap});
        p.Children.Add(new TextBlock{Text=address,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,10,0,16)});
        p.Children.Add(new TextBlock{Text="Kullanıcı adı"});p.Children.Add(name);p.Children.Add(new TextBlock{Text="Şifre",Margin=new Thickness(0,12,0,4)});p.Children.Add(pass);p.Children.Add(submit);p.Children.Add(status);
        var change=new Button{Content="Şifre değiştir / İlk giriş",Margin=new Thickness(0,12,0,5),MinHeight=34};var recovery=new Button{Content="Şifremi unuttum",MinHeight=34};p.Children.Add(change);p.Children.Add(recovery);
        change.Click+=(_,_)=>new HttpsSifrePenceresi(this,address,name.Text.Trim(),false).ShowDialog();recovery.Click+=(_,_)=>new HttpsSifrePenceresi(this,address,name.Text.Trim(),true).ShowDialog();
        submit.Click+=async(_,_)=>
        {
            if(busy)return;busy=true;submit.IsEnabled=false;status.Text="Giriş kontrol ediliyor…";
            var c=new HttpsIstemci(address);
            try{await c.Giris(name.Text.Trim(),pass.Password,stop.Token);var codes=await c.KurtarmaKodlari(stop.Token);if(codes is not null){if(new OnemliKurtarmaKodlariPenceresi(codes.Kodlar){Owner=this}.ShowDialog()!=true){await c.Cikis();throw new InvalidOperationException("Kurtarma kodları onaylanmadı; giriş tamamlanmadı.");}await c.KurtarmaOnayla(codes.GrupId,stop.Token);}Istemci=c;DialogResult=true;}
            catch(OperationCanceledException){c.Dispose();if(!stop.IsCancellationRequested)status.Text="Sunucu zamanında yanıt vermedi. Bağlantıyı kontrol edin.";}
            catch(Exception e){c.Dispose();if(!stop.IsCancellationRequested)status.Text=e is System.Net.Http.HttpRequestException?"Güvenli sunucu bağlantısı kurulamadı. Adres ve sertifikayı kontrol edin.":e.Message;}
            finally{pass.Clear();busy=false;submit.IsEnabled=true;}
        };
        Closed+=(_,_)=>stop.Cancel();Loaded+=(_,_)=>name.Focus();
    }
}

public sealed class HttpsCalismaPenceresi : Window
{
    readonly StackPanel modules=new(){Margin=new Thickness(22)};
    readonly HttpsIstemci client;
    public HttpsCalismaPenceresi(HttpsIstemci client)
    {
        this.client=client;HttpsOturumu.Baslat(client);var session=client.Oturum??throw new UnauthorizedAccessException();
        Title="MiaPaxERP";Width=1100;Height=780;MinWidth=760;MinHeight=560;WindowStartupLocation=WindowStartupLocation.CenterScreen;
        SetResourceReference(BackgroundProperty,"ErpZemin");SetResourceReference(ForegroundProperty,"ErpMetin");
        var root=new DockPanel{Margin=new Thickness(24)};Content=root;
        var top=new StackPanel();top.Children.Add(Tema170.Baslik("MIAPAX ERP","Çalışma alanınız"));
        top.Children.Add(new TextBlock{Text=session.Kullanici.AdSoyad+" · "+session.Kullanici.Roller+"\n"+client.Adres,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(5,10,0,18)});
        DockPanel.SetDock(top,Dock.Top);root.Children.Add(top);
        var bottom=new WrapPanel();DockPanel.SetDock(bottom,Dock.Bottom);root.Children.Add(bottom);
        ErpModulPenceresi.B(bottom,"Sunucu bağlantısı",()=>new BaglantiAyarlariPenceresi{Owner=this}.ShowDialog());
        ErpModulPenceresi.B(bottom,"Çıkış yap",Close);
        root.Children.Add(new ScrollViewer{Content=modules,VerticalScrollBarVisibility=ScrollBarVisibility.Auto});
        string cs=HttpsOturumu.Baglanti;int user=session.Kullanici.Id;
        void Open(Window w){w.Owner=this;w.ShowDialog();}
        void Module(string license,string title,Action action)
        {
            if(!session.Moduller.Contains(license))return;
            var b=new Button{Content=title,MinHeight=48,HorizontalContentAlignment=System.Windows.HorizontalAlignment.Left,Padding=new Thickness(18,8,18,8),Margin=new Thickness(0,0,0,10)};
            b.Click+=(_,_)=>{b.IsEnabled=false;try{action();}catch(Exception e){DestekIzleme.Bildir(e,"HttpsCalismaPenceresi");MessageBox.Show(this,e.Message,"MiaPaxERP",MessageBoxButton.OK,MessageBoxImage.Warning);}finally{b.IsEnabled=true;}};modules.Children.Add(b);
        }
        Module("IK","İnsan kaynakları · Personel ve izinler",()=>Open(new ErpModulPenceresi(cs,user,"personel")));
        Module("SATINALMA","Satın alma · Talepler ve siparişler",()=>Open(new ErpModulPenceresi(cs,user,"satinalma")));
        Module("STOK","Hammadde · Parti, paket ve etiketler",()=>Open(new ErpModulPenceresi(cs,user,"parti")));
        foreach(var item in new[]{("SALES","SATIS","Satış operasyonları"),("PURCHASE","SATINALMA","Satın alma operasyonları"),("CRM","CRM","Müşteri ilişkileri"),("ECOM","ETICARET","E-ticaret operasyonları"),("TRADE","DISTICARET","Dış ticaret")})
        {var (code,license,title)=item;Module(license,title,()=>Open(new TicaretMerkezi(cs,user,code)));}
        Module("FINANS","Gelir ve giderler",()=>Open(new Window{Title="MiaPaxERP · Gelir / Gider",Width=1200,Height=820,Content=new GelirGiderPaneli(cs,user)}));
        Module("URETIM","Üretim · Reçeteler ve üretim kayıtları",()=>Open(new SektorUretimPenceresi(cs,user,session.Sektor)));
        Module("RESTORAN","Restoran · Masa, adisyon ve mutfak",()=>Open(new RestoranPenceresi(cs,user)));
        Module("CRM","Saha pazarlama · Müşteri ve görüşmeler",()=>Open(new SahaPenceresi(cs,user)));
        if(modules.Children.Count==0)modules.Children.Add(new TextBlock{Text="Bu hesap için açık modül bulunamadı. Yöneticinizle görüşün.",TextWrapping=TextWrapping.Wrap});
        bool cikiliyor=false,cikisTamam=false;
        Closing+=async(_,e)=>
        {
            if(cikisTamam)return;e.Cancel=true;if(cikiliyor)return;cikiliyor=true;IsEnabled=false;
            try{await client.Cikis();}finally{HttpsOturumu.Temizle();cikisTamam=true;Close();}
        };
    }
}

