using SqlConnection = MiapaxERP.Desktop.ErpSqlConnection;
using SqlCommand = MiapaxERP.Desktop.ErpSqlCommand;
using SqlTransaction = MiapaxERP.Desktop.ErpSqlTransaction;
using SqlDataReader = MiapaxERP.Desktop.ErpSqlReader;
using SqlDataAdapter = MiapaxERP.Desktop.ErpSqlDataAdapter;
using System;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;
using Microsoft.Win32;

namespace MiapaxERP.Desktop
{
    public partial class FirmaBilgileriPenceresi : Window
    {
        private readonly string baglanti;
        private readonly int kullaniciId;
        private readonly string[] alanlar = { "FirmaAdi", "KisaAd", "FirmaTuru", "MersisNo", "TicaretSicilNo", "TicaretSicilMudurlugu", "VergiDairesi", "VergiNo", "NaceKodu", "KurulusTarihi", "Telefon", "Telefon2", "Eposta", "WebSitesi", "KepAdresi", "Etebligat", "Il", "Ilce", "PostaKodu", "Ulke", "Adres", "YetkiliAdSoyad", "YetkiliUnvan", "YetkiliTelefon", "Iban", "BankaAdi", "SubeAdi", "HesapNo", "OdaKayitNo", "FaaliyetKonusu", "Aciklama" };
        private bool yonetici;
        private const string SemaGuncelleme = @"IF COL_LENGTH('dbo.FirmaBilgileri','KisaAd') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [KisaAd] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','FirmaTuru') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [FirmaTuru] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','MersisNo') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [MersisNo] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','TicaretSicilNo') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [TicaretSicilNo] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','TicaretSicilMudurlugu') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [TicaretSicilMudurlugu] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','NaceKodu') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [NaceKodu] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','KurulusTarihi') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [KurulusTarihi] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','Telefon2') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [Telefon2] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','Eposta') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [Eposta] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','WebSitesi') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [WebSitesi] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','KepAdresi') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [KepAdresi] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','Etebligat') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [Etebligat] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','Il') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [Il] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','Ilce') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [Ilce] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','PostaKodu') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [PostaKodu] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','Ulke') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [Ulke] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','YetkiliAdSoyad') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [YetkiliAdSoyad] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','YetkiliUnvan') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [YetkiliUnvan] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','YetkiliTelefon') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [YetkiliTelefon] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','Iban') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [Iban] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','BankaAdi') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [BankaAdi] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','SubeAdi') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [SubeAdi] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','HesapNo') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [HesapNo] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','OdaKayitNo') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [OdaKayitNo] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','FaaliyetKonusu') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [FaaliyetKonusu] NVARCHAR(1000) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','Aciklama') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [Aciklama] NVARCHAR(1000) NULL;
IF OBJECT_ID(N'dbo.FirmaBelgeleri',N'U') IS NULL
BEGIN
 CREATE TABLE dbo.FirmaBelgeleri (
 Id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
 BelgeTuru NVARCHAR(100) NOT NULL,
 DosyaAdi NVARCHAR(255) NOT NULL,
 PdfIcerik VARBINARY(MAX) NOT NULL,
 EklenmeTarihi DATETIME2 NOT NULL CONSTRAINT DF_FirmaBelgeleri_Eklenme DEFAULT SYSDATETIME(),
 EkleyenKullaniciId INT NULL
 );
END;";

        public FirmaBilgileriPenceresi(string connectionString, int userId)
        {
            InitializeComponent();
            baglanti = connectionString;
            kullaniciId = userId;
            Loaded += (_, _) => Guvenli(Yukle);
        }

        private SqlConnection Baglan()
        {
            var con = new SqlConnection(baglanti);
            con.Open();
            return con;
        }

        private bool Yetki(SqlConnection con, string kod)
        {
            using var cmd = new SqlCommand(@"SELECT CASE WHEN EXISTS
              (SELECT 1 FROM dbo.vw_KullaniciEtkinYetkileri
               WHERE KullaniciId=@id AND YetkiKodu=@kod AND Yetkili=1)
               AND EXISTS(SELECT 1 FROM dbo.Kullanicilar WHERE Id=@id AND Aktif=1)
              THEN 1 ELSE 0 END", con);
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = kullaniciId;
            cmd.Parameters.Add("@kod", SqlDbType.NVarChar, 100).Value = kod;
            return Convert.ToInt32(cmd.ExecuteScalar()) == 1;
        }

        private void Guvenli(Action action)
        {
            try { action(); }
            catch (Exception ex)
            {DestekIzleme.Bildir(ex,"FirmaBilgileriPenceresi.xaml");
                MessageBox.Show(ex.Message, "Firma Bilgileri", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Yukle()
        {
            using var con = Baglan();
            if (!Yetki(con, "SETTINGS.VIEW"))
                throw new UnauthorizedAccessException("Firma bilgilerini görüntüleme yetkiniz yok.");
            yonetici = Yetki(con, "USERS.MANAGE");
            if (yonetici)
            {
                // Yalnızca eksik sütunları ve belge tablosunu oluşturur; kayıt silmez.
                if(HttpsOturumu.Uzak(baglanti))new YardimciEkranServisi(baglanti,kullaniciId).FirmaHazirla();
                else {using var migration = new SqlCommand(SemaGuncelleme, con) { CommandTimeout = 60 };migration.ExecuteNonQuery();}
            }
            using var cmd = new SqlCommand("SELECT * FROM dbo.FirmaBilgileri WHERE Id=1", con);
            using var reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                foreach (string alan in alanlar)
                {
                    var kontrol = (TextBox)FindName("F_" + alan);
                    int ordinal = reader.GetOrdinal(alan);
                    kontrol.Text = reader.IsDBNull(ordinal) ? "" : Convert.ToString(reader.GetValue(ordinal)) ?? "";
                    kontrol.IsReadOnly = !yonetici;
                }
            }
            reader.Close();
            BelgeleriYukle(con);
            Durum.Text = yonetici ? "Firma kaydı ve PDF belgeleri düzenlenebilir." : "Salt okunur erişim.";
        }

        private void BelgeleriYukle(SqlConnection con)
        {
            using var da = new SqlDataAdapter(
                "SELECT Id, BelgeTuru, DosyaAdi, EklenmeTarihi FROM dbo.FirmaBelgeleri ORDER BY Id DESC", con);
            var dt = new DataTable();
            da.Fill(dt);
            Belgeler.ItemsSource = dt.DefaultView;
        }

        private void Kaydet_Click(object sender, RoutedEventArgs e) => Guvenli(() =>
        {
if(HttpsOturumu.Uzak(baglanti)){new YardimciEkranServisi(baglanti,kullaniciId).FirmaKaydet(alanlar.ToDictionary(a=>a,a=>((TextBox)FindName("F_"+a)).Text.Trim()));Durum.Text="Firma bilgileri kaydedildi.";return;}
            using var con = Baglan();
            if (!Yetki(con, "USERS.MANAGE")) throw new UnauthorizedAccessException("Firma bilgilerini düzenleme yetkisi gerekli.");
            string firmaAdi = ((TextBox)FindName("F_FirmaAdi")).Text.Trim();
            if (firmaAdi.Length < 2 || firmaAdi.Length > 200)
                throw new ArgumentException("Firma adı 2-200 karakter arasında olmalı.");
            using var tx = con.BeginTransaction(IsolationLevel.Serializable);
            string setler = string.Join(",", alanlar.Select(a => "[" + a + "]=@" + a));
            string kolonlar = string.Join(",", alanlar.Select(a => "[" + a + "]"));
            string parametreler = string.Join(",", alanlar.Select(a => "@" + a));
            using var cmd = new SqlCommand(
                "UPDATE dbo.FirmaBilgileri SET " + setler + ",GuncellemeTarihi=SYSDATETIME() WHERE Id=1;" +
                "IF @@ROWCOUNT=0 INSERT INTO dbo.FirmaBilgileri (Id," + kolonlar + ") VALUES(1," + parametreler + ");",
                con, tx);
            foreach (string alan in alanlar)
            {
                string value = ((TextBox)FindName("F_" + alan)).Text.Trim();
                int max = alan switch
                {
                    "FirmaAdi" => 200,
                    "VergiDairesi" => 100,
                    "VergiNo" => 20,
                    "Telefon" => 40,
                    "Adres" => 400,
                    "Aciklama" or "FaaliyetKonusu" => 1000,
                    _ => 500
                };
                if (value.Length > max)
                    throw new ArgumentException(alan + " alanı çok uzun.");
                cmd.Parameters.Add("@" + alan, SqlDbType.NVarChar, max).Value = value;
            }
            cmd.ExecuteNonQuery();
            tx.Commit();
            Durum.Text = "Firma bilgileri kaydedildi.";
        });

        private int SecilenBelge()
        {
            if (Belgeler.SelectedItem is not DataRowView row)
                throw new InvalidOperationException("Önce listeden bir PDF seçin.");
            return Convert.ToInt32(row["Id"]);
        }

        private (string Ad, byte[] Pdf) BelgeOku(SqlConnection con, int id)
        {
            using var cmd = new SqlCommand("SELECT DosyaAdi,PdfIcerik FROM dbo.FirmaBelgeleri WHERE Id=@id", con);
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            using var reader = cmd.ExecuteReader();
            if (!reader.Read()) throw new FileNotFoundException("Belge bulunamadı.");
            return (reader.GetString(0), (byte[])reader.GetValue(1));
        }

        private void BelgeEkle_Click(object sender, RoutedEventArgs e) => Guvenli(() =>
        {
            using var con = Baglan();
            if (!Yetki(con, "USERS.MANAGE")) throw new UnauthorizedAccessException("PDF ekleme yetkisi gerekli.");
            var dialog = new OpenFileDialog { Filter = "PDF Belgeleri (*.pdf)|*.pdf", CheckFileExists = true };
            if (dialog.ShowDialog(this) != true) return;
            var info = new FileInfo(dialog.FileName);
            if (info.Length < 5 || info.Length > 20 * 1024 * 1024)
                throw new ArgumentException("PDF boyutu 20 MB sınırını aşamaz.");
            byte[] data = File.ReadAllBytes(dialog.FileName);
            if (data[0] != 0x25 || data[1] != 0x50 || data[2] != 0x44 || data[3] != 0x46 || data[4] != 0x2D)
                throw new ArgumentException("Geçerli bir PDF dosyası seçin.");
            string tur = (BelgeTuru.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Diğer";
if(HttpsOturumu.Uzak(baglanti)){new YardimciEkranServisi(baglanti,kullaniciId).FirmaBelgeEkle(tur,info.Name,data);}
else{            using var cmd = new SqlCommand(@"INSERT INTO dbo.FirmaBelgeleri
                (BelgeTuru,DosyaAdi,PdfIcerik,EkleyenKullaniciId)
                VALUES(@tur,@ad,@pdf,@id)", con);
            cmd.Parameters.Add("@tur", SqlDbType.NVarChar, 100).Value = tur;
            cmd.Parameters.Add("@ad", SqlDbType.NVarChar, 255).Value = info.Name;
            cmd.Parameters.Add("@pdf", SqlDbType.VarBinary, -1).Value = data;
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = kullaniciId;
            cmd.ExecuteNonQuery();
}
            BelgeleriYukle(con);
            Durum.Text = "PDF arşive eklendi.";
        });

        private void BelgeDisari_Click(object sender, RoutedEventArgs e) => Guvenli(() =>
        {
            using var con = Baglan();
            if (!Yetki(con, "SETTINGS.VIEW")) throw new UnauthorizedAccessException();
            var (ad, pdf) = BelgeOku(con, SecilenBelge());
            var dialog = new SaveFileDialog { Filter = "PDF (*.pdf)|*.pdf", FileName = ad };
            if (dialog.ShowDialog(this) == true) File.WriteAllBytes(dialog.FileName, pdf);
        });

        private string GeciciPdf()
        {
            using var con = Baglan();
            if (!Yetki(con, "SETTINGS.VIEW")) throw new UnauthorizedAccessException();
            var (_, pdf) = BelgeOku(con, SecilenBelge());
            string path = Path.Combine(Path.GetTempPath(), "MiapaxERP_Firma_" + Guid.NewGuid().ToString("N") + ".pdf");
            File.WriteAllBytes(path, pdf);
            return path;
        }

        private void BelgeAc_Click(object sender, RoutedEventArgs e) => Guvenli(() =>
        {
            Process.Start(new ProcessStartInfo(GeciciPdf()) { UseShellExecute = true });
            Durum.Text = "PDF varsayılan görüntüleyicide açıldı. Geçici kopya bilgisayarda kalabilir.";
        });

        private void BelgeYazdir_Click(object sender, RoutedEventArgs e) => Guvenli(() =>
        {
            Process.Start(new ProcessStartInfo(GeciciPdf()) { UseShellExecute = true, Verb = "print" });
            Durum.Text = "Yazdırma komutu PDF görüntüleyiciye gönderildi.";
        });

        private void BelgeSil_Click(object sender, RoutedEventArgs e) => Guvenli(() =>
        {
            using var con = Baglan();
            if (!Yetki(con, "USERS.MANAGE")) throw new UnauthorizedAccessException("PDF silme yetkisi gerekli.");
            int id = SecilenBelge();
            if (MessageBox.Show("Seçili PDF arşivden kalıcı silinsin mi?", "Onay",
                MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
if(HttpsOturumu.Uzak(baglanti)){new YardimciEkranServisi(baglanti,kullaniciId).FirmaBelgeSil(id);}
else{            using var cmd = new SqlCommand("DELETE FROM dbo.FirmaBelgeleri WHERE Id=@id", con);
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            cmd.ExecuteNonQuery();
}
            BelgeleriYukle(con);
            Durum.Text = "Belge silindi.";
        });

        private void Kapat_Click(object sender, RoutedEventArgs e) => Close();
    }
}
