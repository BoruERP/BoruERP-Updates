using System.Configuration;
using System.Data;
using System.Windows;

namespace MiapaxERP.Desktop
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        internal static bool LisansAcilistaDogrulandi;
        private static void EskiDosyalariYetkiyleTemizle()
        {
            try
            {
                var start = new System.Diagnostics.ProcessStartInfo(System.IO.Path.Combine(AppContext.BaseDirectory, "MiapaxERP.Updater.exe")) { UseShellExecute = true, Verb = "runas" };
                start.ArgumentList.Add("cleanup"); start.ArgumentList.Add(AppContext.BaseDirectory.TrimEnd(System.IO.Path.DirectorySeparatorChar));
                start.ArgumentList.Add(System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MiapaxERP", "GecisYedekleri"));
                using var process = System.Diagnostics.Process.Start(start); process?.WaitForExit(30000);
            }
            catch (Exception ex) { MessageBox.Show("Eski program dosyaları temizlenemedi: " + ex.Message, "Miapax ERP"); }
        }
        protected override async void OnStartup(StartupEventArgs e)
        {
            try
            {
                MarkaGecisi.Temizle(AppContext.BaseDirectory, System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MiapaxERP", "GecisYedekleri"));
            }
            catch (UnauthorizedAccessException) { EskiDosyalariYetkiyleTemizle(); }
            catch (System.IO.IOException) { /* Kullanımda olan eski dosyalar bir sonraki açılışta tekrar denenir. */ }
            catch (System.Text.Json.JsonException) { /* Geçersiz eski ayar değiştirilmez; program kendi hata bildirimini kullanır. */ }
            TemaPencereServisi.Baslat();
            Tema170.Uygula(new GorunumTercihleri());
            DispatcherUnhandledException+=(_,args)=>DestekIzleme.Bildir(args.Exception,"ERP");
            base.OnStartup(e);
            ShutdownMode = ShutdownMode.OnExplicitShutdown;
            try
            {
                KolayBaglantiProfili profil;
                try { profil=KolayBaglantiProfili.Oku(); }
                catch(Exception ex)when(ex is System.IO.IOException or System.Text.Json.JsonException or ArgumentException or UnauthorizedAccessException){profil=new();}
                if(e.Args.Contains("--baglanti",StringComparer.OrdinalIgnoreCase)||profil.Rol=="Mobil")
                {
                    new BaglantiAyarlariPenceresi{WindowStartupLocation=WindowStartupLocation.CenterScreen}.ShowDialog();
                    profil=KolayBaglantiProfili.Oku();
                    if(profil.Rol!="Yan"){Shutdown();return;}
                }
                if(profil.Rol=="Yan"||e.Args.Contains("--https-client",StringComparer.OrdinalIgnoreCase))
                {
                    if(profil.MasaustuHttps.Length==0)
                    {
                        new BaglantiAyarlariPenceresi{WindowStartupLocation=WindowStartupLocation.CenterScreen}.ShowDialog();
                        profil=KolayBaglantiProfili.Oku();
                    }
                    profil=profil with{Rol="Yan"};profil.Dogrula(true);
                    var giris=new HttpsGirisPenceresi(profil.MasaustuHttps);
                    if(giris.ShowDialog()!=true||giris.Istemci is null){Shutdown();return;}
                    HttpsOturumu.Baslat(giris.Istemci);
                    var native=new MainWindow(false,giris.Istemci);native.Closed+=async(_,_)=>{try{await giris.Istemci.Cikis();}finally{HttpsOturumu.Temizle();}};MainWindow=native;
                    ShutdownMode=ShutdownMode.OnMainWindowClose;MainWindow.Show();DestekIzleme.Baslat();return;
                }
                if (LisansOturumu.Zorunlu)
                {
                    LisansOturumu.Hazirla(MiapaxERPBaglantiAyarlari.BaglantiAdresi());
                    if (!await LisansOturumu.YenileAsync())
                    {
                        var activation = new LisansPenceresi { WindowStartupLocation = WindowStartupLocation.CenterScreen };
                        if (activation.ShowDialog() != true) { Shutdown(); return; }
                    }
                    LisansAcilistaDogrulandi = true;
                }
                MainWindow = new MainWindow();
                ShutdownMode = ShutdownMode.OnMainWindowClose;
                MainWindow.Show();DestekIzleme.Baslat();
            }
            catch (Exception ex)
            {DestekIzleme.Bildir(ex,"App.xaml");
                MessageBox.Show(ex.Message, "MiapaxERP açılış hatası", MessageBoxButton.OK, MessageBoxImage.Error);
                Shutdown(1);
            }
        }
    }

}

