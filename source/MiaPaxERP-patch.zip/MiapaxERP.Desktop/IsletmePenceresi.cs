using System.Data;
using System.IO;
using System.Net;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using MiapaxERP.Desktop.Laboratuvar;
namespace MiapaxERP.Desktop;
public sealed partial class IsletmePaneli:UserControl
{
    readonly IsletmeServisi db;readonly Window pencere;
    readonly DataGrid grid=new(){IsReadOnly=true,AutoGenerateColumns=true,CanUserAddRows=false,SelectionMode=DataGridSelectionMode.Single};
    readonly WrapPanel actions=new();readonly TextBlock status=new(){TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,10,0,0)};
    readonly string kind;bool busy;
    internal static readonly Dictionary<string,string> sections=new(){["Sevkiyat"]="Sevkiyat ve kantar",["BasincTest"]="Boru basınç testleri",["Depo"]="Depo · raf · parti",["SatinAlma"]="Satın alma eşleştirme",["Muhasebe"]="Genel muhasebe",["Tahsilat"]="Satış tahsilatları",["Makine"]="Makine ve kapasite",["UretimMaliyet"]="Üretim maliyeti ve MRP"};
    public IsletmePaneli(Window owner,string connection,int user,string initial="Sevkiyat")
    {
        pencere=owner;db=new(connection,user);kind=sections.ContainsKey(initial)?initial:throw new ArgumentException("Modül bulunamadı.");
        SetResourceReference(BackgroundProperty,"ErpZemin");SetResourceReference(ForegroundProperty,"ErpMetin");
        PaneliKur();Configure();
        grid.AutoGeneratingColumn+=(_,e)=>{if(e.PropertyName is "Veri" or "Surum" or "Data"||e.PropertyType==typeof(byte[]))e.Cancel=true;else e.Column.Header=Baslik(e.PropertyName);};
        Loaded+=async(_,_)=>await Run(Load);
    }
    void Action(string text,Func<Task> body){var b=new Button{Content=text,Padding=new Thickness(12,8,12,8),Margin=new Thickness(0,12,8,12)};actions.Children.Add(b);b.Click+=async(_,_)=>await Run(body);}
    async Task Run(Func<Task> action){if(busy)return;busy=true;actions.IsEnabled=false;try{await action();}catch(Exception e){status.Text=e.Message;}finally{busy=false;actions.IsEnabled=true;}}
    DataRow Selected()=>grid.SelectedItem is DataRowView r?r.Row:throw new ArgumentException("Listeden bir kayıt seçin.");
    long Id()=>Convert.ToInt64(Selected()["Id"]);
    byte[] Version()=>(byte[])Selected()["Surum"];
    async Task Load()
    {
        var first=ilkTarih.SelectedDate??new DateTime(DateTime.Today.Year,1,1);var last=sonTarih.SelectedDate??DateTime.Today;bool journal=rapor.SelectedIndex==1;
        var table=await Task.Run(()=>kind switch{"Depo"=>db.DepoBakiyeleri(),"Tahsilat"=>db.SatisBakiyeleri(),"Muhasebe"=>journal?db.Yevmiye(first,last):db.Mizan(first,last),_=>db.Liste(kind)});
        VeriyiGoster(table);status.Text=table.Rows.Count+" kayıt · "+sections[kind];
        if(kind=="Makine")await KapasiteleriYukle();
    }
    async Task Saved(){await Load();status.Text="İşlem kaydedildi. "+status.Text;}
    void Configure()
    {
        actions.Children.Clear();Action("Yenile",Load);Action("Kurulum / tablo kontrolü",async()=>{await Task.Run(db.Kur);await Load();});
        if(kind=="Sevkiyat"){Action("Yeni sevkiyat",Shipment);Action("Sevk et",async()=>{long id=Id();byte[] version=Version();if(System.Windows.MessageBox.Show(pencere,"Sevkiyat kesinleştirilsin mi? Bağlı satış varsa stok ikinci kez düşülmez.","Sevkiyat",MessageBoxButton.YesNo)!=MessageBoxResult.Yes)return;await Task.Run(()=>db.SevkEt(id,version));await Saved();});Action("Teslim kaydı",Delivery);}
        if(kind=="BasincTest"){Action("Yeni basınç testi",Pressure);Action("Teknik inceleme",Review);Action("Fotoğraf / video yükle",Upload);Action("Medya arşivi",Media);Action("Test raporu / PDF",Report);Action("Partiyi serbest bırak",Release);}
        if(kind=="Depo")ConfigureWarehouse();if(kind=="Muhasebe")ConfigureAccounting();if(kind=="SatinAlma")ConfigurePurchase();
        if(kind is "Makine" or "UretimMaliyet")ConfigureProduction();
        if(kind=="Tahsilat")Action("Seçili satışa tahsilat",async()=>{long id=Id();var row=Selected();var f=new IsletmeForm(pencere,"Satış tahsilatı");f.Note(Convert.ToString(row["BelgeNo"])+" · "+row["Musteri"]+" · Kalan: "+row["Kalan"]+" "+row["Doviz"]);f.Select("account","Kasa / banka hesabı",await Task.Run(()=>db.Secimler("hesap")));f.Date("date","Tahsilat tarihi");f.Number("amount","Tahsil edilen tutar (belge dövizinde)",(decimal)row["Kalan"]);f.Number("rate","Tahsilat kuru (1 belge dövizi kaç TRY)",Convert.ToDecimal(row["Kur"]));f.Text("note","Dekont / tahsilat dayanağı");if(f.ShowDialog()!=true)return;var g=new TahsilatGirdisi(Guid.NewGuid(),id,f.I("account"),f.D("date"),f.N("amount"),f.N("rate"),f.S("note"));await Task.Run(()=>db.Tahsilat(g));await Saved();});
    }
    async Task Shipment()
    {
        var stocks=await Task.Run(()=>db.Secimler("stok"));var shelves=await Task.Run(()=>db.Secimler("raf"));var f=new IsletmeForm(pencere,"Yeni sevkiyat");f.Text("no","Sevkiyat numarası","SVK-"+DateTime.Now.ToString("yyyyMMdd-HHmmss"),80);f.Select("cari","Müşteri",await Task.Run(()=>db.Secimler("cari")));f.Text("from","Nereden",max:200);f.Text("to","Nereye",max:200);f.Date("date","Sevkiyat tarihi");f.Choice("way","Taşıma şekli",new[]{"Karayolu","Denizyolu","Demiryolu","Havayolu","Müşteri teslimi"});f.Text("plate","Araç plakası",max:30);f.Text("driver","Şoför adı soyadı",max:120);f.Text("phone","Şoför telefonu",max:40);f.Number("empty","Boş araç ağırlığı (KG)");f.Number("full","Dolu araç ağırlığı (KG)");f.Text("sale","Bağlı satış belge numarası (isteğe bağlı, kayıt ID)",max:20);f.Text("note","Açıklama");
        var lines=f.Lines("lines","Ürünler · yeni satır ekleyin",("Ürün",typeof(int)),("Parti",typeof(long)),("Raf",typeof(int)),("Miktar",typeof(decimal)));f.LineChoice("lines","Ürün",stocks);f.LineChoice("lines","Raf",shelves);f.LineChoice("lines","Parti",await Task.Run(()=>db.Secimler("lot")));f.Note("Parti boşsa uygun partilerden sırayla çıkış yapılır. Taslak kaydı stok düşürmez. Dolu − boş = net yük.");if(f.ShowDialog()!=true)return;
        var input=new SevkiyatGirdisi(Guid.NewGuid(),null,null,f.S("no"),f.I("cari"),f.S("from"),f.S("to"),f.D("date"),f.S("way"),f.S("plate"),f.S("driver"),f.S("phone"),f.N("empty"),f.N("full"),f.S("sale").Length==0?null:long.Parse(f.S("sale")),lines.AsEnumerable().Select(r=>new SevkiyatKalemi((int)r["Ürün"],r.IsNull("Parti")?null:(long)r["Parti"],(int)r["Raf"],(decimal)r["Miktar"])).ToArray(),f.S("note"));await Task.Run(()=>db.SevkiyatKaydet(input));await Saved();
    }
    async Task Delivery(){long id=Id();byte[] v=Version();var f=new IsletmeForm(pencere,"Teslim kaydı");f.Text("name","Teslim alan",max:120);f.Text("note","Teslim belgesi / açıklama");if(f.ShowDialog()!=true)return;await Task.Run(()=>db.SevkiyatTeslim(id,v,f.S("name"),f.S("note")));await Saved();}
    async Task Pressure()
    {
        var f=new IsletmeForm(pencere,"Boru basınç testi");f.Text("no","Test numarası","BST-"+DateTime.Now.ToString("yyyyMMdd-HHmmss"),80);f.Select("stok","Boru / ürün",await Task.Run(()=>db.Secimler("stok")));f.Select("lot","Test edilen parti",await Task.Run(()=>db.Secimler("lot")));f.Select("device","Kalibrasyonlu test cihazı",await Task.Run(()=>db.Secimler("cihaz")));f.Text("method","Deney yöntemi",max:160);f.Text("standard","Uygulanan standart / müşteri şartnamesi",max:120);f.Text("start","Başlangıç (tarih, saat, saat dilimi)",DateTimeOffset.Now.AddHours(-1).ToString("dd.MM.yyyy HH:mm zzz"),40);f.Text("end","Bitiş (tarih, saat, saat dilimi)",DateTimeOffset.Now.ToString("dd.MM.yyyy HH:mm zzz"),40);f.Number("temp","Deney sıcaklığı (°C)",20);f.Number("target","Gerekli en düşük basınç (bar)");f.Number("first","Başlangıç basıncı (bar)");f.Number("last","Bitiş basıncı (bar)");f.Number("hours","Gerekli test süresi (saat)",1);f.Check("leak","Sızıntı görüldü");f.Text("note","Deney gözlemleri",max:2000);f.Note("Ölçütleri uyguladığınız standarda göre girin. Test kaydı partiyi bloke eder; teknik inceleme ve serbest bırakma ayrı işlemlerdir.");if(f.ShowDialog()!=true)return;
        var g=new BasincTestGirdisi(Guid.NewGuid(),null,null,f.S("no"),f.I("stok"),f.L("lot"),f.L("device"),f.S("method"),f.S("standard"),f.Time("start"),f.Time("end"),f.N("temp"),f.N("target"),f.N("first"),f.N("last"),f.N("hours"),f.B("leak"),f.S("note"));await Task.Run(()=>db.BasincKaydet(g));await Saved();
    }
    async Task Review(){long id=Id();byte[] v=Version();var f=new IsletmeForm(pencere,"Teknik inceleme");f.Choice("decision","Sonuç",new[]{"Onayla","Reddet"});f.Text("note","Teknik gerekçe");f.Note("İncelemeyi testi kaydedenden farklı yetkili yapmalıdır.");if(f.ShowDialog()!=true)return;await Task.Run(()=>db.BasincIncele(id,v,f.S("decision")=="Onayla",f.S("note")));await Saved();}
    async Task Upload(){long id=Id();byte[] v=Version();var open=new OpenFileDialog{Filter="Fotoğraf ve video|*.png;*.jpg;*.jpeg;*.mp4;*.webm"};if(open.ShowDialog(pencere)!=true)return;if(new FileInfo(open.FileName).Length>40*1024*1024)throw new ArgumentException("En fazla 40 MB yükleyin.");string name=Path.GetFileName(open.FileName),type=Path.GetExtension(name).ToLowerInvariant() switch{".png"=>"image/png",".jpg" or ".jpeg"=>"image/jpeg",".mp4"=>"video/mp4",_=>"video/webm"};byte[] bytes=await File.ReadAllBytesAsync(open.FileName);await Task.Run(()=>db.BasincMedyaEkle(Guid.NewGuid(),id,v,new(name,type,bytes)));status.Text="Medya sunucu arşivine eklendi.";}
    async Task Media()
    {
        long id=Id();var table=await Task.Run(()=>db.BasincMedyaListesi(id));var w=new Window{Owner=pencere,Title="Test fotoğraf ve videoları",Width=1000,Height=600,WindowStartupLocation=WindowStartupLocation.CenterOwner};var root=new DockPanel{Margin=new Thickness(15)};w.Content=root;var list=new DataGrid{ItemsSource=table.DefaultView,IsReadOnly=true,AutoGenerateColumns=true};var export=new Button{Content="Seçili dosyayı dışa aktar",Padding=new Thickness(15)};DockPanel.SetDock(export,Dock.Top);root.Children.Add(export);root.Children.Add(list);export.Click+=async(_,_)=>{export.IsEnabled=false;try{if(list.SelectedItem is not DataRowView selected)throw new ArgumentException("Dosya seçin.");var file=await Task.Run(()=>db.BasincMedyaOku(Convert.ToInt64(selected["Id"])));var save=new SaveFileDialog{FileName=file.Ad};if(save.ShowDialog(w)==true)await File.WriteAllBytesAsync(save.FileName,file.Veri);}catch(Exception e){System.Windows.MessageBox.Show(w,e.Message);}finally{export.IsEnabled=true;}};w.ShowDialog();
    }
    async Task Report(){long id=Id();string html=await Task.Run(()=>db.BasincRaporu(id));await LabRapor.Goster(pencere,html,()=>db.BasincDisariAktarYetkisi());}
    async Task Release(){long id=Id();var row=await Task.Run(()=>db.Oku(id,"BasincTest"));var g=System.Text.Json.JsonSerializer.Deserialize<BasincTestGirdisi>((string)row["Veri"],HttpsJson.Ayarlar)!;var f=new IsletmeForm(pencere,"Partiyi serbest bırak");f.Text("note","Serbest bırakma gerekçesi");if(f.ShowDialog()==true){await Task.Run(()=>db.PartiSerbestBirak(g.Lot,f.S("note")));await Saved();}}
}

