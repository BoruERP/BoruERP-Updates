using SqlConnection = MiapaxERP.Desktop.ErpSqlConnection;
using SqlCommand = MiapaxERP.Desktop.ErpSqlCommand;
using SqlTransaction = MiapaxERP.Desktop.ErpSqlTransaction;
using SqlDataReader = MiapaxERP.Desktop.ErpSqlReader;
using SqlDataAdapter = MiapaxERP.Desktop.ErpSqlDataAdapter;

using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;
using System.IO;
using System.Text.Json;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using System.Xml.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;
using Microsoft.Data.Sqlite;

namespace MiapaxERP.Desktop
{
    public partial class MainWindow : Window
    {

        // Tarla sulama krokisi: ana pencerenin mevcut sayfa ve veri akisini degistirmez.
        private void KrokiYonetimi_Click(object sender, RoutedEventArgs e)
        {
            if(!LisansOturumu.ModulVar("KROKI")){MessageBox.Show("Kroki modülü lisansınızda açık değil.");return;}
            var pencere = new System.Windows.Window
            {
                Title = "MiapaxERP | Kroki Yönetimi",
                Width = 1350,
                Height = 820,
                MinWidth = 950,
                MinHeight = 600,
                Owner = this,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Content = new KrokiYonetimi()
            };
            pencere.Show();
        }

        // DEMO MODU
        // true  = SQLite, SQL Server gerekmez
        // false = Normal SQL Server bağlantısı
        private static readonly bool DemoModu = false;

        private readonly string baglantiAdresi = MiapaxERPBaglantiAyarlari.BaglantiAdresi();

        private int? duzenlenenStokId = null;
        private int? duzenlenenUretimEmriId = null;
        private readonly DataTable receteKalemleri = new DataTable();
        private int? duzenlenenReceteId = null;
        private readonly DataTable uretimReceteOnizleme = new DataTable();
        private bool uretimFormYukleniyor = false;
        private bool uretimSecimYukleniyor;
        private bool uretimOtomatikFireYukleniyor;
        private bool paketKaydiYapiliyor;
        private static readonly CultureInfo uretimTr = CultureInfo.GetCultureInfo("tr-TR");

        // Oturum açılana kadar ana pencere kullanılamaz.
        // İşlem bazlı yetkiler sonraki aşamada ayrıca uygulanmalıdır.
        private KullaniciOturumu? aktifKullanici;
        private bool girisPenceresiAcik;
        private readonly DispatcherTimer bildirimZamanlayici = new DispatcherTimer { Interval = TimeSpan.FromSeconds(60) };
        private bool bildirimYukleniyor;
        private readonly List<int> goruntulenenBildirimIdleri = new List<int>();


        public MainWindow() : this(false) { }

        // Test ve tasarım önizlemesi SQL, ağ, oturum veya güncelleyici başlatmaz.
        internal MainWindow(bool yalnizGorunum,HttpsIstemci? uzakIstemci=null)
        {
            InitializeComponent();
            MenuAramaBagla();
            StokGorselleriniBagla();
            TemaTakvimAlani.SizeChanged += (_, _) => TakvimYerlesiminiUygula();
            if (yalnizGorunum) return;
            if(LisansOturumu.Zorunlu)gorunum.Sektor="GENEL";
            Closing += (_, e) => { if (muhasebePaneli?.IslemSuruyor == true) e.Cancel = true; };
            OtomatikGuncellemeyiBagla();
            AsistanHazirla();
            YardimBaslat();
            // Kullanıcı doğrulanana kadar ana pencereyi devre dışı bırak.
            if (!DemoModu) IsEnabled = false;
            uretimReceteOnizleme.Columns.Add("Hammadde", typeof(string));
            uretimReceteOnizleme.Columns.Add("Oran", typeof(decimal));
            uretimReceteOnizleme.Columns.Add("GerekenKg", typeof(decimal));
            UretimReceteOnizlemeTablosu.ItemsSource = uretimReceteOnizleme.DefaultView;
            receteKalemleri.Columns.Add("HammaddeStokId", typeof(int));
            receteKalemleri.Columns.Add("Hammadde", typeof(string));
            receteKalemleri.Columns.Add("Yuzde", typeof(decimal));
            receteKalemleri.Columns.Add("GerekliKg", typeof(decimal));
            ReceteKalemleriTablosu.ItemsSource = receteKalemleri.DefaultView;
            // XAML oluşturulduktan ve DataTable sütunları eklendikten sonra bağlanır.
            TxtReceteHesapKg.TextChanged += ReceteHesapKg_TextChanged;
            ReceteKilogramHesapla();
            Loaded += AnaSayfaIlkYukleme;
            Closed += AnaSayfaKapatildi;
            Loaded += (_, _) => TakvimBaslat();
            bildirimZamanlayici.Tick += async (_, _) => await BildirimleriYenileAsync(false);
            Closed += (_, _) => bildirimZamanlayici.Stop();

            // İlk açılışta giriş penceresini ana pencere görünür olduktan sonra aç.
            // Giriş iptal edilirse ana pencere de kapatılır.
            Loaded += (_, _) => Dispatcher.BeginInvoke(
                new Action(async () => { if(uzakIstemci is not null)UzakOturumuKabul(uzakIstemci);else if(await LisansBaslatAsync()) OturumGirisiniGoster(); }), DispatcherPriority.Background);

            // Arama ve filtreleme olaylarını XAML dosyasını değiştirmeden bağla.
            TxtStokAra.TextChanged += StokFiltresiDegisti;
            CmbStokFiltre.SelectionChanged += StokFiltresiDegisti;
            CmbDurumFiltre.SelectionChanged += StokFiltresiDegisti;
            BtnFiltreTemizle.Click += FiltreTemizle_Click;
            BtnPasifeAl.Click += PasifeAl_Click;
            BtnAktiflestir.Click += Aktiflestir_Click;
            CmbHareketTur.SelectionChanged += (_, _) => StokHareketButonunuYenile();
            StokDinamikBagla();

            if (DemoModu)
            {
                try
                {
                    DemoVeritabani.Hazirla();

                    Title = "MiapaxERP | Demo v0.1";

                    MessageBox.Show(
                        "MiapaxERP Demo v0.1 hazır!\n" +
                        "Bağımsız SQLite veritabanı kullanılıyor.",
                        "MiapaxERP Demo",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                }
                catch (Exception hata)
                {
                    MessageBox.Show(
                        "Demo veritabanı hazırlanamadı:\n\n" +
                        hata.Message,
                        "MiapaxERP",
                        MessageBoxButton.OK,
                        MessageBoxImage.Error);
                }
            }
            else
            {
                AgIzlemeyiBaslat();
            }
        }

        private void VeritabaniBaglantisiniTestEt()
        {
            try
            {
                using (SqlConnection baglanti =
                    new SqlConnection(baglantiAdresi))
                {
                    baglanti.Open();

                    MessageBox.Show(
                        "SQL Server bağlantısı başarılı!",
                        "MiapaxERP",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(
                    "Veritabanı bağlantı hatası:\n" +
                    hata.Message,
                    "MiapaxERP",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void TumIcerikleriGizle()
        {
            if (!yardimOtomatikGecis && yardimTurAdimlari.Count > 0)
                YardimRehberiniBitir(false);
            IsletmeIcerik.Visibility = Visibility.Collapsed;
            IsletmeIcerik.Content = null;
            DahiliTicariIcerik.Visibility = Visibility.Collapsed;
            MuhasebeIcerik.Visibility = Visibility.Collapsed;
            GenelIcerik.Visibility = Visibility.Collapsed;
            AnaSayfaIcerik.Visibility = Visibility.Collapsed;
            AnaSayfaArkaPlan.Visibility = Visibility.Collapsed;
            BrdAnaSurum.Visibility = Visibility.Collapsed;
            StokIcerik.Visibility = Visibility.Collapsed;
            StokAcilisIcerik.Visibility = Visibility.Collapsed;
            StokHareketIcerik.Visibility = Visibility.Collapsed;
            YeniStokIcerik.Visibility = Visibility.Collapsed;
            UretimIcerik.Visibility = Visibility.Collapsed;
            ReceteIcerik.Visibility = Visibility.Collapsed;
        }

        private void SayfaDegistir(
            string baslik, string aciklama)
        {
            SayfaBasligi.Text = baslik;
            IcerikBasligi.Text = baslik;
            IcerikAciklamasi.Text = aciklama;

            TumIcerikleriGizle();
            GenelIcerik.Visibility = Visibility.Visible;
        }

        private void StokEkraniniAc()
        {
            if (!StokYetkisiGerekli("STOCK.VIEW")) return;
            StokYetkiGorunumuYenile();
            SayfaBasligi.Text = "Stok Yönetimi";

            TumIcerikleriGizle();
            StokIcerik.Visibility = Visibility.Visible;

            StoklariListele();
            StokKritikUyarilariniYukle();
        }

        // Stok kartındaki birim neyse açılış stoku da o birimde kaydedilir.
        // SQL Server modunda çalışır; demo SQLite yapısı değiştirilmez.
        private void StokAcilisAc_Click(object sender, RoutedEventArgs e)
        {
            if (!StokYetkisiGerekli("STOCK.VIEW") || !StokYetkisiGerekli("STOCK.OPENING")) return;
            StokYetkiGorunumuYenile();
            if (DemoModu)
            {
                MessageBox.Show("Açılış stoku şu anda SQL Server modunda kullanılabilir.",
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            int? seciliStok = StokTablosu.SelectedItem is DataRowView secilen
                ? Convert.ToInt32(secilen["Id"]) : null;
            SayfaBasligi.Text = "Açılış Stok Girişi";
            TumIcerikleriGizle();
            StokAcilisIcerik.Visibility = Visibility.Visible;
            AcilisStoklariniYukle(seciliStok);
            StokYetkiGorunumuYenile();
        }

        private void StokAcilisGeri_Click(object sender, RoutedEventArgs e)
        {
            StokEkraniniAc();
        }

        private void AcilisStoklariniYukle(int? seciliStokId = null)
        {
            if (!StokYetkisiVar("STOCK.VIEW") || !StokYetkisiVar("STOCK.OPENING")) return;
            if (DemoModu) return;
            try
            {
                DataTable stoklar = new DataTable();
                using (SqlConnection baglanti = new SqlConnection(baglantiAdresi))
                {
                    baglanti.Open();
                    using (SqlCommand komut = new SqlCommand(
                        "SELECT Id, StokKodu + N' - ' + StokAdi AS SecimMetni, Birim " +
                        "FROM dbo.StokKartlari WHERE Aktif = 1 ORDER BY StokAdi;", baglanti))
                    using (SqlDataReader okuyucu = komut.ExecuteReader())
                        stoklar.Load(okuyucu);
                }
                CmbAcilisStok.ItemsSource = stoklar.DefaultView;
                CmbAcilisStok.DisplayMemberPath = "SecimMetni";
                CmbAcilisStok.SelectedValuePath = "Id";
                if (seciliStokId.HasValue && stoklar.Select("Id = " + seciliStokId.Value).Length > 0)
                    CmbAcilisStok.SelectedValue = seciliStokId.Value;
                else
                    CmbAcilisStok.SelectedIndex = -1;
                AcilisStokBilgileriniYenile();
            }
            catch (Exception hata)
            {
                MessageBox.Show("Açılış stok kartları yüklenemedi:\n\n" + hata.Message,
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void StokAcilisStokDegisti(object sender, SelectionChangedEventArgs e)
        {
            AcilisStokBilgileriniYenile();
        }

        private void StokAcilisYenile_Click(object sender, RoutedEventArgs e)
        {
            int? seciliId = CmbAcilisStok.SelectedValue is int id ? id : null;
            AcilisStoklariniYukle(seciliId);
        }

        private void AcilisStokBilgileriniYenile()
        {
            if (TxtStokAcilisBirim == null || TxtStokAcilisDurum == null ||
                BtnStokAcilisKaydet == null || StokAcilisHareketTablosu == null)
                return;

            TxtStokAcilisBirim.Text = "-";
            TxtStokAcilisDurum.Text = "Stok kartı seçin.";
            BtnStokAcilisKaydet.IsEnabled = false;
            StokAcilisHareketTablosu.ItemsSource = null;
            if (CmbAcilisStok.SelectedValue is not int stokId) return;

            try
            {
                using (SqlConnection baglanti = new SqlConnection(baglantiAdresi))
                {
                    baglanti.Open();
                    string birim;
                    using (SqlCommand komut = new SqlCommand(
                        "SELECT Birim FROM dbo.StokKartlari WHERE Id = @Id AND Aktif=1;", baglanti))
                    {
                        komut.Parameters.Add("@Id", SqlDbType.Int).Value = stokId;
                        birim = Convert.ToString(komut.ExecuteScalar()) ?? "";
                    }
                    if (string.IsNullOrWhiteSpace(birim))
                    {
                        TxtStokAcilisDurum.Text = "Seçilen stok aktif değil veya birimi boş.";
                        return;
                    }
                    TxtStokAcilisBirim.Text = birim;

                    using (SqlCommand komut = new SqlCommand(
                        "SELECT COUNT_BIG(*) FROM dbo.StokBakiyeleri WHERE StokKartId=@Id;", baglanti))
                    {
                        komut.Parameters.Add("@Id", SqlDbType.Int).Value = stokId;
                        if (Convert.ToInt64(komut.ExecuteScalar()) > 0)
                        {
                            using (SqlCommand bakiyeKomutu = new SqlCommand(
                                "SELECT Miktar FROM dbo.StokBakiyeleri WHERE StokKartId=@Id;", baglanti))
                            {
                                bakiyeKomutu.Parameters.Add("@Id", SqlDbType.Int).Value = stokId;
                                object? bakiye = bakiyeKomutu.ExecuteScalar();
                                TxtStokAcilisDurum.Text = "Mevcut stok bakiyesi: " +
                                    (bakiye == null ? "-" : Convert.ToDecimal(bakiye).ToString("0.###", CultureInfo.GetCultureInfo("tr-TR"))) +
                                    " " + birim + ". Bu karta daha önce bakiye kaydedildi; yeniden açılış girişi yapılamaz.";
                            }
                        }
                        else
                        {
                            TxtStokAcilisDurum.Text = "Henüz bakiye yok. Açılış miktarı kaydedilebilir.";
                            BtnStokAcilisKaydet.IsEnabled = true;
                        }
                    }
                    DataTable hareketler = new DataTable();
                    using (SqlCommand komut = new SqlCommand(
                        "SELECT TOP (100) KayitTarihi, HareketTipi, Yon, Miktar, Birim, Aciklama " +
                        "FROM dbo.StokHareketleri WHERE StokKartId=@Id ORDER BY Id DESC;", baglanti))
                    {
                        komut.Parameters.Add("@Id", SqlDbType.Int).Value = stokId;
                        using (SqlDataReader okuyucu = komut.ExecuteReader())
                            hareketler.Load(okuyucu);
                    }
                    StokAcilisHareketTablosu.ItemsSource = StokYetkisiVar("STOCK.HISTORY") ?
                        hareketler.DefaultView : null;
                    if (hareketler.Rows.Count > 0)
                    {
                        BtnStokAcilisKaydet.IsEnabled = false;
                        if (!TxtStokAcilisDurum.Text.Contains("Bu karta daha önce"))
                            TxtStokAcilisDurum.Text = "Bu stokun hareket geçmişi var. Açılış girişi yapılamaz.";
                    }
                }
            }
            catch (Exception hata)
            {
                TxtStokAcilisDurum.Text = "Stok durumu okunamadı: " + hata.Message;
                BtnStokAcilisKaydet.IsEnabled = false;
            }
        }

        private void StokAcilisKaydet_Click(object sender, RoutedEventArgs e)
        {
            if (!StokYetkisiGerekli("STOCK.OPENING")) return;
            if (DemoModu) return;
            if (CmbAcilisStok.SelectedValue is not int stokId)
            {
                MessageBox.Show("Önce stok kartı seçin.", "MiapaxERP",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (!PozitifUretimSayisi(TxtStokAcilisMiktar.Text, out decimal miktar))
            {
                MessageBox.Show("Sıfırdan büyük, en fazla üç ondalıklı bir miktar girin. Örnek: 250,500",
                    "Geçersiz Miktar", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtStokAcilisMiktar.Focus();
                return;
            }

            string secilenMetin = (CmbAcilisStok.SelectedItem as DataRowView)?["SecimMetni"]?.ToString() ?? "";
            string birimGoster = TxtStokAcilisBirim.Text;
            if (MessageBox.Show(secilenMetin + " için " + miktar.ToString("0.###", CultureInfo.GetCultureInfo("tr-TR")) + " " + birimGoster +
                " açılış stoku kaydedilsin mi?\n\nBu işlem aynı karta ikinci kez yapılamaz.",
                "Açılış Kaydı Onayı", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
                return;

            BtnStokAcilisKaydet.IsEnabled = false;
            try
            {
                {new EskiStokServisi(baglantiAdresi,aktifKullanici!.KullaniciId).Acilis(stokId,miktar,TxtStokAcilisAciklama.Text.Trim());}

                TxtStokAcilisMiktar.Clear();
                TxtStokAcilisAciklama.Clear();
                AcilisStokBilgileriniYenile();
                MessageBox.Show("Açılış stoku ve hareket kaydı başarıyla oluşturuldu.",
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception hata)
            {
                MessageBox.Show("Açılış stoku kaydedilemedi. Hiçbir yarım kayıt bırakılmadı.\n\n" +
                    hata.Message, "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Error);
                AcilisStokBilgileriniYenile();
            }
        }

        // Kritik stoklar Stok Yönetimi ekranında ayrı satırda görünür.
        // Ana sayfa tasarımı kullanıcı tarif edene kadar değiştirilmez.
        private void StokKritikUyarilariniYukle()
        {
            if (!StokYetkisiVar("STOCK.VIEW")) { StokKritikTablosu.ItemsSource = null; return; }
            if (StokKritikTablosu == null || TxtStokKritikOzet == null) return;
            StokKritikTablosu.ItemsSource = null;
            if (DemoModu)
            {
                TxtStokKritikOzet.Text = "Kritik stok kontrolü SQL Server modunda kullanılabilir.";
                return;
            }

            try
            {
                DataTable kritikStoklar = new DataTable();
                using (SqlConnection baglanti = new SqlConnection(baglantiAdresi))
                {
                    baglanti.Open();
                    using (SqlCommand komut = new SqlCommand(
                        "SELECT sk.StokKodu, sk.StokAdi, sk.Birim, " +
                        "COALESCE(sb.Miktar, 0) AS Bakiye, sk.MinimumStokMiktari " +
                        "FROM dbo.StokKartlari AS sk " +
                        "LEFT JOIN dbo.StokBakiyeleri AS sb ON sb.StokKartId = sk.Id " +
                        "WHERE sk.Aktif = 1 AND sk.MinimumStokMiktari IS NOT NULL " +
                        "AND COALESCE(sb.Miktar, 0) <= sk.MinimumStokMiktari " +
                        "ORDER BY COALESCE(sb.Miktar, 0) / NULLIF(sk.MinimumStokMiktari, 0), sk.StokAdi;",
                        baglanti))
                    using (SqlDataReader okuyucu = komut.ExecuteReader())
                        kritikStoklar.Load(okuyucu);
                }

                StokKritikTablosu.ItemsSource = kritikStoklar.DefaultView;
                TxtStokKritikOzet.Text = kritikStoklar.Rows.Count == 0
                    ? "Kritik Stok Uyarıları — Kritik seviyede aktif stok bulunmuyor."
                    : "⚠ Kritik Stok Uyarıları — " + kritikStoklar.Rows.Count +
                      " stok kartı minimum seviyede veya altında.";
            }
            catch (Exception hata)
            {
                TxtStokKritikOzet.Text = "Kritik stoklar yüklenemedi: " + hata.Message;
            }
        }

        // STOK HAREKETLERİ / GÜNCEL BAKİYELER / KRİTİK STOKLAR
        // Bu ekran yalnızca SQL Server modunda kullanılır.
        private void StokHareketleriAc_Click(object sender, RoutedEventArgs e)
        {
            if (!StokYetkisiGerekli("STOCK.VIEW") || !StokHareketPaneliYetkisiGerekli()) return;
            StokYetkiGorunumuYenile();
            if (DemoModu)
            {
                MessageBox.Show("Stok hareketleri paneli şimdilik SQL Server modunda kullanılabilir.",
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            int? secilenStokId = StokTablosu.SelectedItem is DataRowView secilen
                ? Convert.ToInt32(secilen["Id"]) : null;
            SayfaBasligi.Text = "Stok Hareketleri";
            TumIcerikleriGizle();
            StokHareketIcerik.Visibility = Visibility.Visible;
            StokHareketTedarikcileriYukle();
            DtHareketAlisTarihi.SelectedDate = DateTime.Today;
            StokHareketStoklariYukle(secilenStokId);
            StokHareketRaporunuYukle();
            StokYetkiGorunumuYenile();
        }

        private void StokHareketGeri_Click(object sender, RoutedEventArgs e)
        {
            StokEkraniniAc();
        }

        private void StokHareketStoklariYukle(int? seciliStokId = null)
        {
            if (!StokYetkisiVar("STOCK.VIEW")) return;
            if (DemoModu) return;
            try
            {
                DataTable stoklar = new DataTable();
                using (SqlConnection baglanti = new SqlConnection(baglantiAdresi))
                {
                    baglanti.Open();
                    using (SqlCommand komut = new SqlCommand(
                        "SELECT Id, StokKodu + N' - ' + StokAdi AS SecimMetni " +
                        "FROM dbo.StokKartlari WHERE Aktif = 1 ORDER BY StokAdi;", baglanti))
                    using (SqlDataReader okuyucu = komut.ExecuteReader())
                        stoklar.Load(okuyucu);
                }

                StokFotograflariniYukle(stoklar,"Id");
                CmbHareketStok.ItemsSource = stoklar.DefaultView;
                CmbHareketStok.DisplayMemberPath = "";
                CmbHareketStok.SelectedValuePath = "Id";
                if (seciliStokId.HasValue && stoklar.Select("Id = " + seciliStokId.Value).Length > 0)
                    CmbHareketStok.SelectedValue = seciliStokId.Value;
                else
                    CmbHareketStok.SelectedIndex = -1;
                StokHareketSeciliStokuGoster();
            }
            catch (Exception hata)
            {
                MessageBox.Show("Hareket ekranı stok kartları yüklenemedi:\n\n" + hata.Message,
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void HareketStokDegisti(object sender, SelectionChangedEventArgs e)
        {
            if (TxtHareketMevcutBakiye == null || TxtHareketMinimum == null) return;
            StokHareketSeciliStokuGoster();
            // İsteğe bağlı stok filtresi: seçim varsa o kartın geçmişi görünür.
            StokHareketGecmisiniYukle();
        }

        private void StokHareketSeciliStokuGoster()
        {
            if (TxtHareketMevcutBakiye == null || TxtHareketMinimum == null ||
                BtnHareketKaydet == null) return;
            TxtHareketMevcutBakiye.Text = "Stok kartı seçin.";
            TxtHareketMinimum.Clear();
            BtnHareketKaydet.IsEnabled = false;
            if (CmbHareketStok.SelectedValue is not int stokId) return;
            try
            {
                using (SqlConnection baglanti = new SqlConnection(baglantiAdresi))
                {
                    baglanti.Open();
                    using (SqlCommand komut = new SqlCommand(
                        "SELECT sk.Birim, sk.MinimumStokMiktari, COALESCE(sb.Miktar, 0) AS Bakiye, " +
                        "sb.Birim AS BakiyeBirim FROM dbo.StokKartlari AS sk " +
                        "LEFT JOIN dbo.StokBakiyeleri AS sb ON sb.StokKartId=sk.Id " +
                        "WHERE sk.Id=@Id AND sk.Aktif=1;", baglanti))
                    {
                        komut.Parameters.Add("@Id", SqlDbType.Int).Value = stokId;
                        using (SqlDataReader okuyucu = komut.ExecuteReader())
                        {
                            if (!okuyucu.Read()) return;
                            string stokBirimi = Convert.ToString(okuyucu["Birim"]) ?? "";
                            string? bakiyeBirimi = okuyucu["BakiyeBirim"] == DBNull.Value
                                ? null : Convert.ToString(okuyucu["BakiyeBirim"]);
                            decimal bakiye = Convert.ToDecimal(okuyucu["Bakiye"]);
                            if (bakiyeBirimi != null && !string.Equals(bakiyeBirimi, stokBirimi,
                                StringComparison.OrdinalIgnoreCase))
                            {
                                TxtHareketMevcutBakiye.Text = "DİKKAT: Stok kartı ile bakiye birimi uyuşmuyor! İşlem yapmayın.";
                                return;
                            }
                            TxtHareketMevcutBakiye.Text = "Mevcut: " +
                                bakiye.ToString("0.###", CultureInfo.GetCultureInfo("tr-TR")) + " " + stokBirimi;
                            if (okuyucu["MinimumStokMiktari"] != DBNull.Value)
                            {
                                decimal minimum = Convert.ToDecimal(okuyucu["MinimumStokMiktari"]);
                                TxtHareketMinimum.Text = minimum.ToString("0.###", CultureInfo.GetCultureInfo("tr-TR"));
                                if (bakiye <= minimum)
                                    TxtHareketMevcutBakiye.Text += "  —  KRİTİK STOK!";
                            }
                            BtnHareketKaydet.IsEnabled = StokHareketTipineUIYetkiVar();
                        }
                    }
                }
            }
            catch (Exception hata)
            {
                TxtHareketMevcutBakiye.Text = "Stok bilgisi okunamadı: " + hata.Message;
            }
        }

        private void StokHareketYenile_Click(object sender, RoutedEventArgs e)
        {
            int? seciliStokId = CmbHareketStok.SelectedValue is int id ? id : null;
            StokHareketStoklariYukle(seciliStokId);
            StokHareketRaporunuYukle();
        }

        private void StokHareketRaporunuYukle()
        {
            if (!StokYetkisiVar("STOCK.VIEW")) return;
            if (DemoModu) return;
            try
            {
                DataTable bakiyeRaporu = new DataTable();
                using (SqlConnection baglanti = new SqlConnection(baglantiAdresi))
                {
                    baglanti.Open();
                    using (SqlCommand komut = new SqlCommand(
                        "SELECT sk.Id AS StokKartId, sk.StokKodu, sk.StokAdi, COALESCE(sb.Miktar,0) AS Bakiye, " +
                        "sk.Birim, sk.MinimumStokMiktari, " +
                        "CASE WHEN sk.MinimumStokMiktari IS NULL THEN N'Belirlenmedi' " +
                        "WHEN COALESCE(sb.Miktar,0) <= sk.MinimumStokMiktari THEN N'KRİTİK' " +
                        "ELSE N'Normal' END AS Uyari, " +
                        "CASE WHEN sk.Aktif=1 THEN N'Aktif' ELSE N'Pasif' END AS Durum " +
                        "FROM dbo.StokKartlari AS sk " +
                        "LEFT JOIN dbo.StokBakiyeleri AS sb ON sb.StokKartId=sk.Id " +
                        "ORDER BY CASE WHEN sk.MinimumStokMiktari IS NOT NULL " +
                        "AND COALESCE(sb.Miktar,0)<=sk.MinimumStokMiktari THEN 0 ELSE 1 END, sk.StokAdi;",
                        baglanti))
                    using (SqlDataReader okuyucu = komut.ExecuteReader())
                        bakiyeRaporu.Load(okuyucu);
                }
                StokFotograflariniYukle(bakiyeRaporu,"StokKartId");
                StokBakiyeRaporTablosu.ItemsSource = bakiyeRaporu.DefaultView;
                StokHareketGecmisiniYukle();
            }
            catch (Exception hata)
            {
                MessageBox.Show("Stok bakiye raporu yüklenemedi:\n\n" + hata.Message,
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void StokHareketTedarikcileriYukle()
        {
            if (DemoModu) return;
            using var baglanti = new SqlConnection(baglantiAdresi);
            baglanti.Open();
            using var komut = new SqlCommand(
                "SELECT Id, Unvan FROM dbo.CariKartlari WHERE Aktif=1 ORDER BY Unvan;", baglanti);
            var tablo = new DataTable();
            using (var okuyucu = komut.ExecuteReader()) tablo.Load(okuyucu);
            CmbHareketTedarikci.ItemsSource = tablo.DefaultView;
            CmbHareketTedarikci.DisplayMemberPath = "Unvan";
            CmbHareketTedarikci.SelectedValuePath = "Id";
            CmbHareketTedarikci.SelectedIndex = -1;
        }

        private void StokHareketGecmisiniYukle()
        {
            if (DemoModu || StokHareketGecmisiTablosu == null) return;
            if (!StokYetkisiVar("STOCK.HISTORY"))
            {
                StokHareketGecmisiTablosu.ItemsSource = null;
                return;
            }
            try
            {
                DataTable gecmis = new DataTable();
                using (SqlConnection baglanti = new SqlConnection(baglantiAdresi))
                {
                    baglanti.Open();
                    using (SqlCommand komut = new SqlCommand(
                        "SELECT TOP (200) sk.Id AS StokKartId, sh.KayitTarihi, sk.StokKodu, sh.HareketTipi, " +
                        "sh.Yon, sh.Miktar, sh.Birim, sh.Aciklama, " +
                        "c.Unvan AS Tedarikci, a.AlimTarihi, a.BirimFiyat, a.ParaBirimi " +
                        "FROM dbo.StokHareketleri AS sh " +
                        "LEFT JOIN dbo.StokAlimKayitlari a ON a.StokHareketId=sh.Id " +
                        "LEFT JOIN dbo.CariKartlari c ON c.Id=a.CariKartId " +
                        "INNER JOIN dbo.StokKartlari AS sk ON sk.Id=sh.StokKartId " +
                        "WHERE (@StokId IS NULL OR sh.StokKartId=@StokId) " +
                        "ORDER BY sh.Id DESC;", baglanti))
                    {
                        komut.Parameters.Add("@StokId", SqlDbType.Int).Value =
                            CmbHareketStok.SelectedValue is int stokId ? stokId : DBNull.Value;
                        using (SqlDataReader okuyucu = komut.ExecuteReader())
                            gecmis.Load(okuyucu);
                    }
                }
                StokFotograflariniYukle(gecmis,"StokKartId");
                StokHareketGecmisiTablosu.ItemsSource = gecmis.DefaultView;
            }
            catch (Exception hata)
            {
                MessageBox.Show("Hareket geçmişi okunamadı:\n\n" + hata.Message,
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void StokHareketKaydet_Click(object sender, RoutedEventArgs e)
        {
            if (!StokYetkisiGerekli("STOCK.VIEW")) return;
            if (DemoModu) return;
            if (CmbHareketStok.SelectedValue is not int stokId)
            {
                MessageBox.Show("Önce stok kartı seçin.", "MiapaxERP",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (CmbHareketTur.SelectedItem is not ComboBoxItem hareketTuru ||
                hareketTuru.Tag is not string yon || (yon != "G" && yon != "C"))
                return;
            string hareketYetkisi = yon == "G" ? "STOCK.RECEIVE" : "STOCK.ISSUE";
            if (!StokYetkisiGerekli(hareketYetkisi)) return;
            if (!PozitifUretimSayisi(TxtHareketMiktar.Text, out decimal miktar))
            {
                MessageBox.Show("Miktar sıfırdan büyük ve en fazla üç ondalıklı olmalı. Örnek: 125,500",
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtHareketMiktar.Focus();
                return;
            }
            bool satinAlma = yon == "G" &&
                (CmbHareketTedarikci.SelectedValue is int ||
                 !string.IsNullOrWhiteSpace(TxtHareketAlisFiyati.Text));
            int? tedarikciId = CmbHareketTedarikci.SelectedValue is int cariId ? cariId : null;
            DateTime? alimTarihi = DtHareketAlisTarihi.SelectedDate;
            decimal alisFiyati = 0m;
            string paraBirimi = (CmbHareketParaBirimi.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "TRY";
            if (satinAlma && (tedarikciId == null || alimTarihi == null ||
                !decimal.TryParse(TxtHareketAlisFiyati.Text, NumberStyles.Number,
                    CultureInfo.GetCultureInfo("tr-TR"), out alisFiyati) ||
                alisFiyati < 0 || decimal.Round(alisFiyati, 4) != alisFiyati))
            {
                MessageBox.Show("Satın alma için tedarikçi, tarih ve en fazla 4 ondalıklı geçerli alış fiyatı girin.",
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            string aciklama = TxtHareketAciklama.Text.Trim();
            string stokAdi = (CmbHareketStok.SelectedItem as DataRowView)?["SecimMetni"]?.ToString() ?? "";
            string yonAciklama = yon == "G" ? "GİRİŞ" : "ÇIKIŞ";
            if (MessageBox.Show(stokAdi + " için " + miktar.ToString("0.###", CultureInfo.GetCultureInfo("tr-TR")) +
                " " + yonAciklama + " kaydedilsin mi?",
                "Stok Hareketi Onayı", MessageBoxButton.YesNo, MessageBoxImage.Question)
                != MessageBoxResult.Yes) return;

            BtnHareketKaydet.IsEnabled = false;
            try
            {
                decimal sonBakiye;
                {sonBakiye=new EskiStokServisi(baglantiAdresi,aktifKullanici!.KullaniciId).Hareket(new(stokId,yon,miktar,aciklama,satinAlma,tedarikciId,alimTarihi,alisFiyati,paraBirimi));}

                TxtHareketMiktar.Clear();
                TxtHareketAciklama.Clear();
                TxtHareketAlisFiyati.Clear();
                CmbHareketTedarikci.SelectedIndex = -1;
                StokHareketSeciliStokuGoster();
                StokHareketRaporunuYukle();
                MessageBox.Show("Stok hareketi kaydedildi. Güncel bakiye: " +
                    sonBakiye.ToString("0.###", CultureInfo.GetCultureInfo("tr-TR")),
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception hata)
            {
                MessageBox.Show("İşlem yapılamadı. Bakiye ve hareket geçmişi birlikte korundu.\n\n" +
                    hata.Message, "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Error);
                StokHareketSeciliStokuGoster();
            }
            finally
            {
                BtnHareketKaydet.IsEnabled = CmbHareketStok.SelectedValue is int && StokHareketTipineUIYetkiVar();
            }
        }

        private static void HareketOndalikParametre(SqlCommand komut, string ad, decimal miktar)
        {
            SqlParameter parametre = komut.Parameters.Add(ad, SqlDbType.Decimal);
            parametre.Precision = 18;
            parametre.Scale = 3;
            parametre.Value = miktar;
        }

        private void StokMinimumKaydet_Click(object sender, RoutedEventArgs e)
        {
            if (!StokYetkisiGerekli("STOCK.MINIMUM")) return;
            if (DemoModu) return;
            if (CmbHareketStok.SelectedValue is not int stokId)
            {
                MessageBox.Show("Önce stok kartı seçin.", "MiapaxERP",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            string metin = TxtHareketMinimum.Text.Trim();
            decimal? minimum = null;
            if (metin.Length > 0)
            {
                if (!PozitifUretimSayisi(metin, out decimal girilen))
                {
                    MessageBox.Show("Minimum stok sıfırdan büyük, en fazla 3 ondalıklı olmalıdır.",
                        "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                minimum = girilen;
            }

            string bilgi = minimum.HasValue
                ? "Minimum stok limiti " + minimum.Value.ToString("0.###", CultureInfo.GetCultureInfo("tr-TR")) + " olarak kaydedilsin mi?"
                : "Minimum stok limiti kaldırılsın mı?";
            if (MessageBox.Show(bilgi, "Kritik Stok Limiti",
                MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
                return;
            try
            {
                {new EskiStokServisi(baglantiAdresi,aktifKullanici!.KullaniciId).Minimum(stokId,minimum);}

                StokHareketSeciliStokuGoster();
                StokHareketRaporunuYukle();
                MessageBox.Show("Minimum stok limiti kaydedildi.", "MiapaxERP",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception hata)
            {
                MessageBox.Show("Minimum stok limiti kaydedilemedi:\n\n" + hata.Message,
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void StoklariListele()
        {
            if (!StokYetkisiVar("STOCK.VIEW")) { StokTablosu.ItemsSource = null; return; }
            try
            {
                DataTable tablo = new DataTable();

                if (DemoModu)
                {
                    using (SqliteConnection baglanti =
                        new SqliteConnection(
                            DemoVeritabani.BaglantiAdresi))
                    {
                        baglanti.Open();

                        string sorgu =
                            "SELECT Id, StokKodu, StokAdi, " +
                            "StokTipi, Birim, " +
                            "CASE WHEN Aktif = 1 THEN 'Aktif' ELSE 'Pasif' END AS Durum " +
                            "FROM StokKartlari ORDER BY Id DESC";

                        using (SqliteCommand komut =
                            new SqliteCommand(sorgu, baglanti))
                        using (SqliteDataReader okuyucu =
                            komut.ExecuteReader())
                        {
                            tablo.Load(okuyucu);
                        }
                    }
                }
                else
                {
                    using (SqlConnection baglanti =
                        new SqlConnection(baglantiAdresi))
                    {
                        baglanti.Open();

                        string sorgu =
                            "SELECT Id, StokKodu, StokAdi, " +
                            "StokTipi, Birim, " +
                            "CASE WHEN Aktif = 1 THEN 'Aktif' ELSE 'Pasif' END AS Durum " +
                            "FROM dbo.StokKartlari ORDER BY Id DESC";

                        using (SqlCommand komut =
                            new SqlCommand(sorgu, baglanti))
                        using (SqlDataReader okuyucu =
                            komut.ExecuteReader())
                        {
                            tablo.Load(okuyucu);
                        }
                    }
                }

                StokFotograflariniYukle(tablo,"Id");
                StokTablosu.ItemsSource = tablo.DefaultView;
                StokFiltresiniUygula();
            }
            catch (Exception hata)
            {
                MessageBox.Show(
                    "Stoklar yüklenirken hata oluştu:\n\n" +
                    hata.Message,
                    "MiapaxERP",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        // Mevcut stok tablosunu yeniden sorgulamadan anlık olarak filtreler.
        private void StokFiltresiDegisti(object sender, RoutedEventArgs e)
        {
            StokFiltresiniUygula();
        }

        private void StokFiltresiniUygula()
        {
            if (StokTablosu.ItemsSource is not DataView gorunum)
                return;

            string arama = TxtStokAra.Text.Trim();
            string tip = (CmbStokFiltre.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Tümü";
            string durum = (CmbDurumFiltre.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Tümü";

            string aranan = FiltreMetniniKacir(arama);
            string secilenTip = tip.Replace("'", "''");

            var filtreler = new System.Collections.Generic.List<string>();

            if (!string.IsNullOrWhiteSpace(arama))
                filtreler.Add($"(StokKodu LIKE '%{aranan}%' OR StokAdi LIKE '%{aranan}%')");

            if (tip != "Tümü")
                filtreler.Add($"StokTipi = '{secilenTip}'");

            if (durum == "Aktif" || durum == "Pasif")
                filtreler.Add($"Durum = '{durum}'");

            gorunum.RowFilter = string.Join(" AND ", filtreler);
        }

        private static string FiltreMetniniKacir(string metin)
        {
            return metin.Replace("'", "''")
                        .Replace("[", "[[]")
                        .Replace("]", "[]]")
                        .Replace("%", "[%]")
                        .Replace("*", "[*]");
        }

        private void FiltreTemizle_Click(object sender, RoutedEventArgs e)
        {
            TxtStokAra.Clear();
            CmbStokFiltre.SelectedIndex = 0;
            CmbDurumFiltre.SelectedIndex = 0;
            StokFiltresiniUygula();
        }

        private void YeniStokEkle_Click(
            object sender, RoutedEventArgs e)
        {
            if (!StokYetkisiGerekli("STOCK.CREATE")) return;
            duzenlenenStokId = null;

            SayfaBasligi.Text = "Yeni Stok Kartı";
            StokFormBasligi.Text = "Yeni Stok Kartı";
            BtnStokKaydet.Content = "Kaydet";

            TxtStokKodu.Clear();
            TxtStokAdi.Clear();
            TxtAciklama.Clear();
            TxtCapMm.Clear();
            TxtBasincSinifi.Clear();
            TxtUzunlukMetre.Clear();
            TxtRenk.Clear();
            TxtEtKalinligiMm.Clear();
            TxtHammaddeTuru.Clear();
            TxtAgirlikKg.Clear();

            if (!DemoModu)
            {
                try { StokTipleriniYukle(); }
                catch (Exception ex)
                {
                    MessageBox.Show("Dinamik stok tanımları yüklenemedi. Önce v0.12 SQL betiğini uygulayın.\n\n" + ex.Message,
                        "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
            }
            else CmbStokTipi.SelectedIndex = 0;
            CmbBirim.SelectedIndex = 0;

            TumIcerikleriGizle();
            YeniStokIcerik.Visibility = Visibility.Visible;
            StokYetkiGorunumuYenile();

            TxtStokKodu.Focus();
        }

        private void StokDuzenle_Click(
            object sender, RoutedEventArgs e)
        {
            if (!StokYetkisiGerekli("STOCK.EDIT")) return;
            if (StokTablosu.SelectedItem is not DataRowView secilen)
            {
                MessageBox.Show(
                    "Lütfen düzenlemek istediğiniz stok kartını seçin.",
                    "Stok Seçilmedi",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
                return;
            }

            int stokId = Convert.ToInt32(secilen["Id"]);

            try
            {
                string stokKodu;
                string stokAdi;
                string stokTipi;
                string birim;
                string aciklama;

                if (DemoModu)
                {
                    using (SqliteConnection baglanti =
                        new SqliteConnection(
                            DemoVeritabani.BaglantiAdresi))
                    {
                        baglanti.Open();

                        using (SqliteCommand komut =
                            baglanti.CreateCommand())
                        {
                            komut.CommandText =
                                "SELECT StokKodu, StokAdi, StokTipi, " +
                                "Birim, Aciklama, CapMm, BasincSinifi, UzunlukMetre, " +
                                "Renk, EtKalinligiMm, HammaddeTuru, AgirlikKg " +
                                "FROM StokKartlari WHERE Id = @Id";

                            komut.Parameters.AddWithValue(
                                "@Id", stokId);

                            using (SqliteDataReader okuyucu =
                                komut.ExecuteReader())
                            {
                                if (!okuyucu.Read())
                                {
                                    MessageBox.Show(
                                        "Stok bulunamadı.");
                                    return;
                                }

                                stokKodu = okuyucu.GetString(0);
                                stokAdi = okuyucu.GetString(1);
                                stokTipi = okuyucu.GetString(2);
                                birim = okuyucu.GetString(3);
                                aciklama = okuyucu.IsDBNull(4)
                                    ? ""
                                    : okuyucu.GetString(4);
                                TxtCapMm.Text = SayiyiGoster(okuyucu, 5);
                                TxtBasincSinifi.Text = MetniOku(okuyucu, 6);
                                TxtUzunlukMetre.Text = SayiyiGoster(okuyucu, 7);
                                TxtRenk.Text = MetniOku(okuyucu, 8);
                                TxtEtKalinligiMm.Text = SayiyiGoster(okuyucu, 9);
                                TxtHammaddeTuru.Text = MetniOku(okuyucu, 10);
                                TxtAgirlikKg.Text = SayiyiGoster(okuyucu, 11);
                            }
                        }
                    }
                }
                else
                {
                    using (SqlConnection baglanti =
                        new SqlConnection(baglantiAdresi))
                    {
                        baglanti.Open();

                        using (SqlCommand komut =
                            baglanti.CreateCommand())
                        {
                            komut.CommandText =
                                "SELECT StokKodu, StokAdi, StokTipi, " +
                                "Birim, Aciklama, CapMm, BasincSinifi, UzunlukMetre, " +
                                "Renk, EtKalinligiMm, HammaddeTuru, AgirlikKg " +
                                "FROM dbo.StokKartlari WHERE Id = @Id";

                            komut.Parameters.Add(
                                "@Id", SqlDbType.Int).Value = stokId;

                            using (SqlDataReader okuyucu =
                                komut.ExecuteReader())
                            {
                                if (!okuyucu.Read())
                                {
                                    MessageBox.Show(
                                        "Stok bulunamadı.");
                                    return;
                                }

                                stokKodu = okuyucu.GetString(0);
                                stokAdi = okuyucu.GetString(1);
                                stokTipi = okuyucu.GetString(2);
                                birim = okuyucu.GetString(3);
                                aciklama = okuyucu.IsDBNull(4)
                                    ? ""
                                    : okuyucu.GetString(4);
                                TxtCapMm.Text = SayiyiGosterSql(okuyucu, 5);
                                TxtBasincSinifi.Text = MetniOkuSql(okuyucu, 6);
                                TxtUzunlukMetre.Text = SayiyiGosterSql(okuyucu, 7);
                                TxtRenk.Text = MetniOkuSql(okuyucu, 8);
                                TxtEtKalinligiMm.Text = SayiyiGosterSql(okuyucu, 9);
                                TxtHammaddeTuru.Text = MetniOkuSql(okuyucu, 10);
                                TxtAgirlikKg.Text = SayiyiGosterSql(okuyucu, 11);
                            }
                        }
                    }
                }

                duzenlenenStokId = stokId;

                TxtStokKodu.Text = stokKodu;
                TxtStokAdi.Text = stokAdi;
                TxtAciklama.Text = aciklama;

                if (!DemoModu)
                {
                    StokTipleriniYukle(stokTipi);
                    StokDinamikDuzenlemeYukle(stokId);
                }
                else ComboSec(CmbStokTipi, stokTipi);
                ComboSec(CmbBirim, birim);

                SayfaBasligi.Text = "Stok Kartı Düzenle";
                StokFormBasligi.Text = "Stok Kartı Düzenle";
                BtnStokKaydet.Content = "Güncelle";

                TumIcerikleriGizle();
                YeniStokIcerik.Visibility = Visibility.Visible;
                StokYetkiGorunumuYenile();
            }
            catch (Exception hata)
            {
                MessageBox.Show(
                    "Stok bilgileri alınamadı:\n\n" +
                    hata.Message,
                    "MiapaxERP",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void ComboSec(
            ComboBox combo, string deger)
        {
            combo.SelectedIndex = -1;

            foreach (ComboBoxItem item in combo.Items)
            {
                if (string.Equals(
                    item.Content?.ToString(),
                    deger,
                    StringComparison.OrdinalIgnoreCase))
                {
                    combo.SelectedItem = item;
                    return;
                }
            }
        }

        private void StokKaydet_Click(
            object sender, RoutedEventArgs e)
        {
            string stokYazmaYetkisi = duzenlenenStokId.HasValue ? "STOCK.EDIT" : "STOCK.CREATE";
            if (!StokYetkisiGerekli(stokYazmaYetkisi)) return;
            string stokKodu = TxtStokKodu.Text.Trim();
            string stokAdi = TxtStokAdi.Text.Trim();

            if (string.IsNullOrWhiteSpace(stokAdi))
            {
                MessageBox.Show(
                    "Stok adı boş bırakılamaz.",
                    "Eksik Bilgi",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
                return;
            }

            if (CmbStokTipi.SelectedItem is not ComboBoxItem tipItem ||
                CmbBirim.SelectedItem is not ComboBoxItem birimItem)
            {
                MessageBox.Show(
                    "Stok tipi ve birim seçilmelidir.",
                    "Eksik Bilgi",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
                return;
            }

            string stokTipi = tipItem.Content.ToString()!;
            string birim = birimItem.Content.ToString()!;
            // Sadece yeni kartta kod boş bırakılırsa otomatik üretilir.
            if (!duzenlenenStokId.HasValue && string.IsNullOrWhiteSpace(stokKodu))
            {
                stokKodu = MiapaxERPStokKodlari.YeniKod(stokTipi);
                TxtStokKodu.Text = stokKodu;
            }
            if (string.IsNullOrWhiteSpace(stokKodu))
            {
                MessageBox.Show("Stok kodu boş bırakılamaz.", "Eksik Bilgi",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (!StokOzelAlanlariDogrula()) return;

            if (!SayiyiDogrula(TxtCapMm, "Çap", out double? capMm) ||
                !SayiyiDogrula(TxtUzunlukMetre, "Uzunluk", out double? uzunlukMetre) ||
                !SayiyiDogrula(TxtEtKalinligiMm, "Et kalınlığı", out double? etKalinligiMm) ||
                !SayiyiDogrula(TxtAgirlikKg, "Ağırlık", out double? agirlikKg))
                return;

            try
            {
                if (DemoModu)
                {
                    using (SqliteConnection baglanti =
                        new SqliteConnection(
                            DemoVeritabani.BaglantiAdresi))
                    {
                        baglanti.Open();

                        using (SqliteCommand komut =
                            baglanti.CreateCommand())
                        {
                            if (duzenlenenStokId.HasValue)
                            {
                                komut.CommandText =
                                    "UPDATE StokKartlari SET " +
                                    "StokKodu=@StokKodu, " +
                                    "StokAdi=@StokAdi, " +
                                    "StokTipi=@StokTipi, " +
                                    "Birim=@Birim, " +
                                    "Aciklama=@Aciklama, " +
                                    "CapMm=@CapMm, BasincSinifi=@BasincSinifi, " +
                                    "UzunlukMetre=@UzunlukMetre, Renk=@Renk, " +
                                    "EtKalinligiMm=@EtKalinligiMm, " +
                                    "HammaddeTuru=@HammaddeTuru, AgirlikKg=@AgirlikKg " +
                                    "WHERE Id=@Id";

                                komut.Parameters.AddWithValue(
                                    "@Id", duzenlenenStokId.Value);
                            }
                            else
                            {
                                komut.CommandText =
                                    "INSERT INTO StokKartlari " +
                                    "(StokKodu, StokAdi, StokTipi, " +
                                    "Birim, Aciklama, CapMm, BasincSinifi, " +
                                    "UzunlukMetre, Renk, EtKalinligiMm, " +
                                    "HammaddeTuru, AgirlikKg) VALUES " +
                                    "(@StokKodu, @StokAdi, @StokTipi, " +
                                    "@Birim, @Aciklama, @CapMm, @BasincSinifi, " +
                                    "@UzunlukMetre, @Renk, @EtKalinligiMm, " +
                                    "@HammaddeTuru, @AgirlikKg)";
                            }

                            komut.Parameters.AddWithValue(
                                "@StokKodu", stokKodu);
                            komut.Parameters.AddWithValue(
                                "@StokAdi", stokAdi);
                            komut.Parameters.AddWithValue(
                                "@StokTipi", stokTipi);
                            komut.Parameters.AddWithValue(
                                "@Birim", birim);
                            komut.Parameters.AddWithValue(
                                "@Aciklama",
                                string.IsNullOrWhiteSpace(
                                    TxtAciklama.Text)
                                    ? DBNull.Value
                                    : TxtAciklama.Text.Trim());

                            komut.Parameters.AddWithValue("@CapMm", (object?)capMm ?? DBNull.Value);
                            komut.Parameters.AddWithValue("@BasincSinifi", BosIseNull(TxtBasincSinifi.Text));
                            komut.Parameters.AddWithValue("@UzunlukMetre", (object?)uzunlukMetre ?? DBNull.Value);
                            komut.Parameters.AddWithValue("@Renk", BosIseNull(TxtRenk.Text));
                            komut.Parameters.AddWithValue("@EtKalinligiMm", (object?)etKalinligiMm ?? DBNull.Value);
                            komut.Parameters.AddWithValue("@HammaddeTuru", BosIseNull(TxtHammaddeTuru.Text));
                            komut.Parameters.AddWithValue("@AgirlikKg", (object?)agirlikKg ?? DBNull.Value);

                            int sonuc = komut.ExecuteNonQuery();

                            if (sonuc == 0)
                            {
                                MessageBox.Show(
                                    "Kayıt bulunamadı.");
                                return;
                            }
                        }
                    }
                }
                else
                {
                    {new EskiStokServisi(baglantiAdresi,aktifKullanici!.KullaniciId).Kaydet(new(duzenlenenStokId,stokKodu,stokAdi,ComboId(CmbStokTipi)??throw new ArgumentException("Stok tipi seçin."),birim,TxtAciklama.Text.Trim(),capMm,TxtBasincSinifi.Text.Trim(),uzunlukMetre,TxtRenk.Text.Trim(),etKalinligiMm,TxtHammaddeTuru.Text.Trim(),agirlikKg,SeciliKategori(CmbStokKategori)?.Id,SeciliKategori(CmbStokAltKategori)?.Id,_stokDinamikAlanlar.Values.ToDictionary(a=>a.Id,a=>StokOzelMetin(a))));}

                }

                MessageBox.Show(
                    duzenlenenStokId.HasValue
                        ? "Stok kartı başarıyla güncellendi."
                        : "Stok kartı başarıyla kaydedildi.",
                    "MiapaxERP",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                duzenlenenStokId = null;
                StokEkraniniAc();
            }
            catch (SqliteException hata)
                when (hata.SqliteErrorCode == 19)
            {
                MessageBox.Show(
                    "Bu stok kodu zaten kayıtlı.",
                    "Tekrarlanan Stok Kodu",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
            }
            catch (SqlException hata)
                when (hata.Number == 2601 || hata.Number == 2627)
            {
                MessageBox.Show(
                    "Bu stok kodu zaten kayıtlı.",
                    "Tekrarlanan Stok Kodu",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
            }
            catch (Exception hata)
            {
                MessageBox.Show(
                    "Stok kaydedilemedi:\n\n" +
                    hata.Message,
                    "MiapaxERP",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        // Boş ölçüler NULL kaydedilir; virgüllü ve noktalı ondalık sayılar kabul edilir.
        private static bool SayiyiDogrula(TextBox alan, string ad, out double? sonuc)
        {
            sonuc = null;
            string metin = alan.Text.Trim();
            if (metin.Length == 0) return true;

            // Binlik ayracı yerine yalnızca tek ondalık ayracı beklenir.
            string standart = metin.Replace(',', '.');
            if (!double.TryParse(standart, NumberStyles.AllowDecimalPoint,
                    CultureInfo.InvariantCulture, out double deger) ||
                !double.IsFinite(deger) || deger <= 0)
            {
                MessageBox.Show($"{ad} için sıfırdan büyük geçerli bir sayı girin. Örnek: 5,8",
                    "Geçersiz Teknik Özellik", MessageBoxButton.OK, MessageBoxImage.Warning);
                alan.Focus();
                return false;
            }
            sonuc = deger;
            return true;
        }

        private static object BosIseNull(string metin) =>
            string.IsNullOrWhiteSpace(metin) ? DBNull.Value : metin.Trim();

        private static string MetniOku(SqliteDataReader okuyucu, int sira) =>
            okuyucu.IsDBNull(sira) ? "" : okuyucu.GetString(sira);

        private static string SayiyiGoster(SqliteDataReader okuyucu, int sira) =>
            okuyucu.IsDBNull(sira) ? "" :
            Convert.ToDouble(okuyucu.GetValue(sira), CultureInfo.InvariantCulture)
                .ToString("0.################", CultureInfo.GetCultureInfo("tr-TR"));

        // SQL Server DECIMAL(12,3) alanlarına kültürden bağımsız sayısal değer gönder.
        private static void SqlOndalikEkle(SqlCommand komut, string ad, double? deger)
        {
            SqlParameter parametre = komut.Parameters.Add(ad, SqlDbType.Decimal);
            parametre.Precision = 12;
            parametre.Scale = 3;
            parametre.Value = deger.HasValue
                ? (object)Convert.ToDecimal(deger.Value)
                : DBNull.Value;
        }

        private static string MetniOkuSql(SqlDataReader okuyucu, int sira) =>
            okuyucu.IsDBNull(sira) ? "" : okuyucu.GetString(sira);

        private static string SayiyiGosterSql(SqlDataReader okuyucu, int sira) =>
            okuyucu.IsDBNull(sira) ? "" :
            Convert.ToDecimal(okuyucu.GetValue(sira), CultureInfo.InvariantCulture)
                .ToString("0.###", CultureInfo.GetCultureInfo("tr-TR"));

        private void StokIptal_Click(
            object sender, RoutedEventArgs e)
        {
            duzenlenenStokId = null;
            StokEkraniniAc();
        }

        // Stok kartları hiçbir zaman silinmez; yalnızca Aktif alanı değiştirilir.
        private void PasifeAl_Click(object sender, RoutedEventArgs e)
        {
            StokDurumunuDegistir(false);
        }

        private void Aktiflestir_Click(object sender, RoutedEventArgs e)
        {
            StokDurumunuDegistir(true);
        }

        private void StokDurumunuDegistir(bool aktifYap)
        {
            if (!StokYetkisiGerekli("STOCK.STATUS")) return;
            if (StokTablosu.SelectedItem is not DataRowView secilen)
            {
                MessageBox.Show(
                    "Lütfen önce listeden bir stok kartı seçin.",
                    "Stok Seçilmedi",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
                return;
            }

            int stokId = Convert.ToInt32(secilen["Id"]);
            string stokKodu = Convert.ToString(secilen["StokKodu"]) ?? "";
            string stokAdi = Convert.ToString(secilen["StokAdi"]) ?? "";
            string mevcutDurum = Convert.ToString(secilen["Durum"]) ?? "";
            string hedefDurum = aktifYap ? "Aktif" : "Pasif";

            if (mevcutDurum == hedefDurum)
            {
                MessageBox.Show(
                    $"Bu stok kartı zaten {hedefDurum.ToLowerInvariant()} durumda.",
                    "İşlem Gerekli Değil",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
                return;
            }

            string soru = aktifYap
                ? $"{stokKodu} - {stokAdi} stok kartını yeniden aktifleştirmek istiyor musunuz?"
                : $"{stokKodu} - {stokAdi} stok kartını pasife almak istiyor musunuz?\n\nStok kartı ve geçmiş kayıtlar silinmeyecek.";

            if (MessageBox.Show(
                    soru,
                    "Stok Durumu Onayı",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question) != MessageBoxResult.Yes)
            {
                return;
            }

            try
            {
                int sonuc;
                if (DemoModu)
                {
                    using (SqliteConnection baglanti =
                        new SqliteConnection(DemoVeritabani.BaglantiAdresi))
                    {
                        baglanti.Open();
                        using (SqliteCommand komut = baglanti.CreateCommand())
                        {
                            komut.CommandText =
                                "UPDATE StokKartlari SET Aktif = @Aktif " +
                                "WHERE Id = @Id AND Aktif <> @Aktif";
                            komut.Parameters.AddWithValue("@Aktif", aktifYap ? 1 : 0);
                            komut.Parameters.AddWithValue("@Id", stokId);
                            sonuc = komut.ExecuteNonQuery();
                        }
                    }
                }
                else
                {
                    {sonuc=new EskiStokServisi(baglantiAdresi,aktifKullanici!.KullaniciId).Durum(stokId,aktifYap);}

                }

                StoklariListele();
                if (sonuc == 0)
                {
                    MessageBox.Show(
                        "Stok durumu değişmedi. Kayıt başka bir işlemde değiştirilmiş " +
                        "veya bulunamıyor olabilir. Liste yenilendi.",
                        "Bilgi",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                    return;
                }

                MessageBox.Show(
                    $"{stokKodu} kodlu stok kartı {hedefDurum.ToLowerInvariant()} duruma getirildi.",
                    "MiapaxERP",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
            catch (Exception hata)
            {
                MessageBox.Show(
                    "Stok durumu değiştirilemedi:\n\n" + hata.Message,
                    "MiapaxERP",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }


        // ================================================================
        // MiapaxERP ANA SAYFA / DASHBOARD - mevcut modüllerden bağımsız, salt okunur
        // ================================================================
        private readonly DispatcherTimer anaSaatZamanlayici = new DispatcherTimer();
        private readonly DispatcherTimer anaBannerZamanlayici = new DispatcherTimer();
        private readonly DispatcherTimer anaVeriZamanlayici = new DispatcherTimer();
        private readonly DispatcherTimer anaKurZamanlayici = new DispatcherTimer();
        private static readonly HttpClient anaKurHttp = new HttpClient { Timeout = TimeSpan.FromSeconds(12) };
        private readonly List<string> anaBannerResimleri = new List<string>();
        private bool anaBannerDegisiyor;
        private int anaBannerIndeksi;
        private bool anaVeriYukleniyor;
        private bool anaKurYukleniyor;
        private bool anaSayfaZamanlayicilariKuruldu;
        private AnaKurBilgisi? anaSonBasariliKur;

        private sealed class AnaKurBilgisi
        {
            public decimal UsdAlis { get; set; }
            public decimal UsdSatis { get; set; }
            public decimal EurAlis { get; set; }
            public decimal EurSatis { get; set; }
            public string YayinTarihi { get; set; } = "";
            public DateTime SonKontrol { get; set; }
        }

        private static string AnaKurOnbellekYolu => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "MiapaxERP", "tcmb-gunluk-kur.json");

        private readonly DispatcherTimer sektorHaberZamanlayici = new DispatcherTimer();
        private string sektorHaberUrl = "https://www.tarimorman.gov.tr/";
        private static string SektorHaberOnbellek => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "MiapaxERP", "sektor-haberleri.json");
        private sealed class SektorHaberKaydi
        {
            public string Baslik { get; set; } = "";
            public string Ozet { get; set; } = "";
            public string Baglanti { get; set; } = "";
            public string Tarih { get; set; } = "";
            public DateTime KontrolUtc { get; set; }
        }
        private static readonly string VarsayilanSektorBaslik =
            "Modern basınçlı borulu sulama, su kayıplarını azaltmaya yardımcı olur";
        private static readonly string VarsayilanSektorOzet =
            "Öneri: Damla ve yağmurlama sistemlerinde boru çapı, basınç sınıfı, " +
            "filtreleme ve işletme basıncını projeye göre kontrol edin. " +
            "Teknik seçim için üretici standartlarına ve proje hesabına başvurun.";
        private const string VarsayilanSektorUrl =
            "https://www.tarimorman.gov.tr/TAGEM/Belgeler/yayin/Tar%C4%B1msal%20Sulama%20SPB_2021-2025.pdf";

        private readonly List<SektorHaberKaydi> sektorHaberListesi = new();
        private int sektorHaberIndeks = -1;
        private bool sektorHaberYukleniyor;
        private readonly DispatcherTimer sektorHaberGecisZamanlayici = new DispatcherTimer();

        private void SonrakiSektorHaberi()
        {
            if (sektorHaberListesi.Count == 0) return;
            sektorHaberIndeks = (sektorHaberIndeks + 1) % sektorHaberListesi.Count;
            SektorHaberiGoster(sektorHaberListesi[sektorHaberIndeks],
                "Haber " + (sektorHaberIndeks + 1) + "/" + sektorHaberListesi.Count);
        }

        private async Task SektorHaberleriniYukleAsync(bool zorla = false)
        {
            if (sektorHaberYukleniyor) return;
            sektorHaberYukleniyor = true;
            try
            {
                if (sektorHaberListesi.Count == 0 && File.Exists(SektorHaberOnbellek))
                {
                    try
                    {
                        var eski = JsonSerializer.Deserialize<List<SektorHaberKaydi>>(
                            File.ReadAllText(SektorHaberOnbellek));
                        if (eski != null && eski.Count > 0)
                        {
                            sektorHaberListesi.AddRange(eski);
                            SonrakiSektorHaberi();
                        }
                    }
                    catch { /* Önceki tek-haber JSON biçimi artık kullanılmaz. */ }
                }
                if (!zorla && sektorHaberListesi.Count > 0 &&
                    DateTime.UtcNow - sektorHaberListesi[0].KontrolUtc < TimeSpan.FromHours(1)) return;
                var sorgular = new[]
                {
                    "tarımsal sulama yağmurlama boru",
                    "PE100 polietilen boru sulama",
                    "tarım sulama teknolojileri Türkiye"
                };
                var yeni = new List<SektorHaberKaydi>();
                using var istemci = new HttpClient { Timeout = TimeSpan.FromSeconds(15) };
                foreach (string sorgu in sorgular)
                {
                    try
                    {
                        string rss = "https://news.google.com/rss/search?q=" +
                            Uri.EscapeDataString(sorgu) + "&hl=tr&gl=TR&ceid=TR:tr";
                        string xml = await istemci.GetStringAsync(rss);
                        var belge = XDocument.Parse(xml);
                        foreach (var item in belge.Descendants("item").Take(25))
                        {
                            string baslik = ((string?)item.Element("title") ?? "").Trim();
                            string link = ((string?)item.Element("link") ?? "").Trim();
                            if (baslik.Length < 12 || !Uri.TryCreate(link, UriKind.Absolute, out var uri) ||
                                uri.Scheme != Uri.UriSchemeHttps) continue;
                            if (yeni.Any(x => string.Equals(x.Baslik, baslik, StringComparison.OrdinalIgnoreCase))) continue;
                            string tarih = (string?)item.Element("pubDate") ?? "Yayın tarihi belirtilmemiş";
                            yeni.Add(new SektorHaberKaydi
                            {
                                Baslik = baslik,
                                Baglanti = link,
                                Tarih = tarih,
                                Ozet = "Sektör haberleri • Ayrıntılar ve doğrulama için kaynağı açın.",
                                KontrolUtc = DateTime.UtcNow
                            });
                        }
                    }
                    catch (HttpRequestException) { }
                    catch (TaskCanceledException) { }
                    catch (System.Xml.XmlException) { }
                }
                if (yeni.Count > 0)
                {
                    sektorHaberListesi.Clear();
                    sektorHaberListesi.AddRange(yeni.Take(40));
                    sektorHaberIndeks = -1;
                    Directory.CreateDirectory(Path.GetDirectoryName(SektorHaberOnbellek)!);
                    File.WriteAllText(SektorHaberOnbellek, JsonSerializer.Serialize(sektorHaberListesi));
                    SonrakiSektorHaberi();
                }
                else if (sektorHaberListesi.Count == 0)
                {
                    SektorHaberiGoster(new SektorHaberKaydi
                    {
                        Baslik = VarsayilanSektorBaslik,
                        Ozet = VarsayilanSektorOzet,
                        Baglanti = VarsayilanSektorUrl,
                        Tarih = "Genel bilgi; güncel haber değil"
                    }, "Haber akışına erişilemedi");
                }
                else TxtSektorKaynak.Text += " | Yeni haber alınamadı; son kayıtlar gösteriliyor.";
            }
            finally { sektorHaberYukleniyor = false; }
        }
        private void SektorHaberiGoster(SektorHaberKaydi haber, string durum)
        {
            TxtSektorBaslik.Text = haber.Baslik;
            TxtSektorOzet.Text = haber.Ozet;
            TxtSektorKaynak.Text = durum + " | Yayın: " + haber.Tarih +
                " | Son kontrol: " + (haber.KontrolUtc == default ? "—" :
                    haber.KontrolUtc.ToLocalTime().ToString("dd.MM.yyyy HH:mm"));
            sektorHaberUrl = haber.Baglanti;
        }
        private async void SektorHaberYenile_Click(object sender, RoutedEventArgs e)
        {
            await SektorHaberleriniYukleAsync(true);
            SonrakiSektorHaberi();
        }
        private void SektorHaberiAc_Click(object sender, RoutedEventArgs e)
        {
            if (Uri.TryCreate(sektorHaberUrl, UriKind.Absolute, out var uri) &&
                (uri.Scheme == Uri.UriSchemeHttps || uri.Scheme == Uri.UriSchemeHttp))
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(
                    uri.AbsoluteUri)
                { UseShellExecute = true });
        }

        private void AnaSayfaIlkYukleme(object sender, RoutedEventArgs e)
        {
            if (anaSayfaZamanlayicilariKuruldu) return;
            anaSayfaZamanlayicilariKuruldu = true;
            anaSaatZamanlayici.Interval = TimeSpan.FromSeconds(1);
            anaSaatZamanlayici.Tick += (_, _) => AnaSaatGuncelle();
            anaSaatZamanlayici.Start();
            AnaSaatGuncelle();

            anaBannerResimleri.Clear();
            // Yalnızca yerel dosyalar: uygulama internete bağlı olmasa da çalışır.
            // Kullanıcı MP4, JPG, PNG veya WEBP dosyalarını Assets/Dashboard içine ekleyebilir.
            DirectoryInfo? klasor = new DirectoryInfo(AppContext.BaseDirectory);
            for (int kat = 0; kat < 7 && klasor != null; kat++, klasor = klasor.Parent)
            {
                string medyaKlasoru = Path.Combine(klasor.FullName, "Assets", "Dashboard");
                if (!Directory.Exists(medyaKlasoru)) continue;
                string[] uzantilar = { ".jpg", ".jpeg", ".png", ".bmp", ".mp4", ".wmv" };
                anaBannerResimleri.AddRange(Directory.GetFiles(medyaKlasoru)
                    .Where(dosya => uzantilar.Contains(Path.GetExtension(dosya).ToLowerInvariant()))
                    .OrderBy(dosya => Path.GetFileName(dosya), StringComparer.OrdinalIgnoreCase));
                if (anaBannerResimleri.Count > 0) break;
            }
            anaBannerIndeksi = 0; varsayilanMedya.Clear(); varsayilanMedya.AddRange(anaBannerResimleri); gorunumMedyaHazir = true; GorunumMedyaYenile();
            anaBannerZamanlayici.Interval = TimeSpan.FromSeconds(10);
            anaBannerZamanlayici.Tick += (_, _) =>
            {
                // Videoyu süre dolunca kesme; yalnızca resimler arasında geçiş yap.
                if (VideoAnasayfaBanner.Visibility != Visibility.Visible)
                    AnaBannerSonrakineGec();
            };
            anaBannerZamanlayici.Start();

            anaVeriZamanlayici.Interval = TimeSpan.FromSeconds(60);
            anaVeriZamanlayici.Tick += async (_, _) =>
            {
                await AnaSayfaVerileriniYukleAsync();
                await AnaSayfaTicariYukleAsync();
            };
            anaVeriZamanlayici.Start();
            anaKurZamanlayici.Interval = TimeSpan.FromMinutes(5);
            anaKurZamanlayici.Tick += async (_, _) => await AnaKurlariYukleAsync();
            anaKurZamanlayici.Start();
            sektorHaberZamanlayici.Interval = TimeSpan.FromHours(1);
            sektorHaberGecisZamanlayici.Interval = TimeSpan.FromSeconds(25);
            sektorHaberGecisZamanlayici.Tick += (_, _) => SonrakiSektorHaberi();
            sektorHaberGecisZamanlayici.Start();
            sektorHaberZamanlayici.Tick += async (_, _) => await SektorHaberleriniYukleAsync(true);
            sektorHaberZamanlayici.Start();
            AnaSayfayiAc();
            AnaKurOnbellektenYukle();
            _ = AnaKurlariYukleAsync();
            _ = SektorHaberleriniYukleAsync();
        }

        private void AnaSayfaKapatildi(object? sender, EventArgs e)
        {
            anaSaatZamanlayici.Stop();
            anaBannerZamanlayici.Stop();
            VideoAnasayfaBanner.Stop();
            VideoAnasayfaBanner.Source = null;
            anaVeriZamanlayici.Stop();
            anaKurZamanlayici.Stop();
            sektorHaberZamanlayici.Stop();
            AgIzlemeyiDurdur();
            takvimZamanlayici.Stop();
        }

        private void AnaSaatGuncelle()
        {
            DateTime simdi = DateTime.Now;
            CultureInfo tr = CultureInfo.GetCultureInfo("tr-TR");
            TxtUstTarih.Text = simdi.ToString("dd MMMM yyyy dddd", tr);
            TxtUstSaat.Text = simdi.ToString("HH:mm:ss", tr);
        }

        private void AnaBannerSonrakineGec()
        {
            if (anaBannerResimleri.Count <= 1 || anaBannerDegisiyor) return;
            anaBannerIndeksi = (anaBannerIndeksi + 1) % anaBannerResimleri.Count;
            AnaBannerGuncelle();
        }

        private void VideoAnasayfaBanner_Bitti(object sender, RoutedEventArgs e)
        { if (anaBannerResimleri.Count == 1) { VideoAnasayfaBanner.Position = TimeSpan.Zero; VideoAnasayfaBanner.Play(); } else AnaBannerSonrakineGec(); }

        private void VideoAnasayfaBanner_Hata(object sender, ExceptionRoutedEventArgs e)
        {
            VideoAnasayfaBanner.Stop(); VideoAnasayfaBanner.Visibility = Visibility.Collapsed;
            TxtBannerSayac.Text = "Video oynatılamadı. Ayarlar'dan farklı bir MP4/WMV seçin.";
            if (anaBannerIndeksi < anaBannerResimleri.Count) anaBannerResimleri.RemoveAt(anaBannerIndeksi);
            anaBannerIndeksi = 0;
            if (anaBannerResimleri.Count > 0) AnaBannerGuncelle(); else anaBannerZamanlayici.Stop();
        }
        private void AnaBannerGuncelle()
        {
            if (anaBannerResimleri.Count == 0)
            {
                TxtBannerSayac.Text = "Assets/Dashboard klasörüne görsel veya video ekleyin";
                return;
            }
            if (anaBannerDegisiyor) return;
            anaBannerDegisiyor = true;
            try
            {
                VideoAnasayfaBanner.Stop();
                VideoAnasayfaBanner.Source = null;
                VideoAnasayfaBanner.Visibility = Visibility.Collapsed;
                ImgAnasayfaBanner.Visibility = Visibility.Collapsed;
                string dosya = anaBannerResimleri[anaBannerIndeksi];
                string uzanti = Path.GetExtension(dosya).ToLowerInvariant();
                if (uzanti == ".mp4" || uzanti == ".wmv")
                {
                    VideoAnasayfaBanner.Source = new Uri(dosya, UriKind.Absolute);
                    VideoAnasayfaBanner.Visibility = Visibility.Visible;
                    // MediaOpened olayı medya hazır olunca oynatmayı başlatır.
                    VideoAnasayfaBanner.Play();
                }
                else
                {
                    var resim = new BitmapImage();
                    resim.BeginInit();
                    resim.UriSource = new Uri(dosya, UriKind.Absolute);
                    resim.CacheOption = BitmapCacheOption.OnLoad;
                    resim.EndInit();
                    resim.Freeze();
                    ImgAnasayfaBanner.Source = resim;
                    ImgAnasayfaBanner.Visibility = Visibility.Visible;
                }
                TxtBannerSayac.Text = (anaBannerIndeksi + 1) + " / " + anaBannerResimleri.Count;
            }
            catch (Exception)
            {
                TxtBannerSayac.Text = "Medya açılamadı";
            }
            finally { anaBannerDegisiyor = false; }
        }

        private static string MiapaxERPBaglantiAyarlariYansit()
        {
            try
            {
                string yol = Path.Combine(Environment.GetFolderPath(
                    Environment.SpecialFolder.LocalApplicationData), "MiapaxERP", "ag-baglantisi.json");
                if (!File.Exists(yol)) return "Rol belirtilmedi";
                using var belge = JsonDocument.Parse(File.ReadAllText(yol));
                if (belge.RootElement.TryGetProperty("Rol", out var deger))
                {
                    string? rol = deger.GetString();
                    if (string.Equals(rol, "Ana", StringComparison.OrdinalIgnoreCase)) return "Ana PC";
                    if (string.Equals(rol, "Yan", StringComparison.OrdinalIgnoreCase)) return "Yan PC";
                }
            }
            catch { /* Rol etiketi için uygulamanın açılışı engellenmez. */ }
            return "Rol belirtilmedi";
        }

        private void AnaSayfayiAc()
        {
            SayfaBasligi.Text = "Ana Sayfa";
            TumIcerikleriGizle();
            AnaSayfaArkaPlan.Visibility = Visibility.Visible;
            AnaSayfaIcerik.Visibility = Visibility.Visible;
            TakvimYenile();
            string surum = System.Reflection.Assembly.GetExecutingAssembly()
                .GetName().Version?.ToString(3) ?? "?";
            string rol = MiapaxERPBaglantiAyarlariYansit();
            TxtAnaSurum.Text = $"MiapaxERP v{surum} | {rol}";
            BrdAnaSurum.Visibility = Visibility.Visible;
            AnaSayfaYardimKatmani.Visibility = DemoModu || aktifKullanici != null
                ? Visibility.Visible : Visibility.Collapsed;
            _ = AnaSayfaVerileriniYukleAsync();
            _ = AnaSayfaTicariYukleAsync();
        }

        private void AnaSayfaYenile_Click(object sender, RoutedEventArgs e)
        {
            _ = AnaSayfaVerileriniYukleAsync();
            _ = AnaSayfaTicariYukleAsync();
        }

        private void AnaYardim_Click(object sender, RoutedEventArgs e)
        {
            YardimPaneliniAcKapat();
        }

        private sealed class AnaSayfaVeriPaketi
        {
            public DataTable Kritik { get; set; } = new DataTable();
            public DataTable Uretim { get; set; } = new DataTable();
            public long KritikSayisi { get; set; }
            public long AktifUretimSayisi { get; set; }
            public bool StokGoruntulemeYetkisi { get; set; }
            public bool UretimGoruntulemeYetkisi { get; set; }
        }

        private async Task AnaSayfaVerileriniYukleAsync()
        {
            if (anaVeriYukleniyor || AnaSayfaIcerik.Visibility != Visibility.Visible) return;
            // İlk açılışta ve çıkış sonrasında girişsiz veri getirilmesin.
            int? oturumId = aktifKullanici?.KullaniciId;
            if (!DemoModu && !oturumId.HasValue)
            {
                AnaKritikStokTablosu.ItemsSource = null;
                AnaAktifUretimTablosu.ItemsSource = null;
                TxtAnaKritikDurum.Text = "Veriler için oturum açın.";
                TxtAnaUretimDurum.Text = "Veriler için oturum açın.";
                return;
            }
            anaVeriYukleniyor = true;
            if (DemoModu)
            {
                TxtAnaKritikDurum.Text = "Bu gösterge SQL Server modunda kullanılabilir.";
                TxtAnaUretimDurum.Text = "Bu gösterge SQL Server modunda kullanılabilir.";
                TxtAnaSonYenileme.Text = "Demo modunda sunucu verisi alınmıyor.";
                anaVeriYukleniyor = false;
                return;
            }
            try
            {
                // DB erişimi UI iş parçacığını dondurmaz; yalnızca SELECT kullanılır.
                AnaSayfaVeriPaketi veri = await Task.Run(() =>
                {
                    var sonuc = new AnaSayfaVeriPaketi();
                    using (var baglanti = new SqlConnection(baglantiAdresi))
                    {
                        baglanti.Open();
                        sonuc.StokGoruntulemeYetkisi = StokSqlYetkisiVar(
                            baglanti, null, oturumId!.Value, "STOCK.VIEW");
                        sonuc.UretimGoruntulemeYetkisi = StokSqlYetkisiVar(
                            baglanti, null, oturumId!.Value, "PRODUCTION.VIEW");
                        const string kritikSql = @"
                            SELECT TOP (5) sk.StokKodu, sk.StokAdi,
                              FORMAT(ISNULL(sb.Miktar,0), '0.###', 'tr-TR') + N' ' + sk.Birim AS MevcutMetin,
                              FORMAT(sk.MinimumStokMiktari, '0.###', 'tr-TR') + N' ' + sk.Birim AS MinimumMetin
                            FROM dbo.StokKartlari sk
                            LEFT JOIN dbo.StokBakiyeleri sb ON sb.StokKartId = sk.Id
                            WHERE sk.Aktif = 1 AND sk.MinimumStokMiktari IS NOT NULL
                                  AND ISNULL(sb.Miktar,0) <= sk.MinimumStokMiktari
                            ORDER BY sk.StokAdi;";
                        if (sonuc.StokGoruntulemeYetkisi)
                        {
                            using (var komut = new SqlCommand(kritikSql, baglanti))
                            using (var okuyucu = komut.ExecuteReader()) sonuc.Kritik.Load(okuyucu);
                            using (var komut = new SqlCommand(@"
                            SELECT COUNT_BIG(*) FROM dbo.StokKartlari sk
                            LEFT JOIN dbo.StokBakiyeleri sb ON sb.StokKartId = sk.Id
                            WHERE sk.Aktif = 1 AND sk.MinimumStokMiktari IS NOT NULL
                                  AND ISNULL(sb.Miktar,0) <= sk.MinimumStokMiktari;", baglanti))
                                sonuc.KritikSayisi = Convert.ToInt64(komut.ExecuteScalar());
                        }
                        const string uretimSql = @"
                            SELECT TOP (5) sk.StokAdi,
                              FORMAT(ue.PlanlananMiktar, '0.###', 'tr-TR') + N' ' + COALESCE(ue.MiktarBirimi,sk.Birim) AS PlanlananMetin,
                              FORMAT(ue.UretilenMiktar, '0.###', 'tr-TR') + N' ' + COALESCE(ue.MiktarBirimi,sk.Birim) AS UretilenMetin,
                              CONVERT(decimal(9,2),CASE WHEN ue.PlanlananMiktar > 0 THEN
                                  CASE WHEN ue.UretilenMiktar * 100.0 / ue.PlanlananMiktar > 100 THEN 100
                                    ELSE ue.UretilenMiktar * 100.0 / ue.PlanlananMiktar END ELSE 0 END) AS Ilerleme,
                              CONVERT(decimal(9,2),CASE WHEN ue.PlanlananMiktar > 0 THEN
                                  CASE WHEN ISNULL(pk.PaketAdet,0)*100.0/ue.PlanlananMiktar > 100 THEN 100
                                  ELSE ISNULL(pk.PaketAdet,0)*100.0/ue.PlanlananMiktar END ELSE 0 END) AS PaketIlerleme
                            FROM dbo.UretimEmirleri ue
                            INNER JOIN dbo.StokKartlari sk ON sk.Id = ue.MamulStokId
                            OUTER APPLY (SELECT SUM(p.ToplamAdet) AS PaketAdet
                                         FROM dbo.UretimPaketlemeKayitlari p WHERE p.UretimEmriId=ue.Id) pk
                            WHERE ue.Durum = N'Üretimde'
                            ORDER BY ue.Id DESC;";
                        if (!SektorUretimOzeti(baglanti,oturumId!.Value,sonuc) && sonuc.UretimGoruntulemeYetkisi)
                        {
                            using (var komut = new SqlCommand(uretimSql, baglanti))
                            using (var okuyucu = komut.ExecuteReader()) sonuc.Uretim.Load(okuyucu);
                            using (var komut = new SqlCommand(
                            "SELECT COUNT_BIG(*) FROM dbo.UretimEmirleri WHERE Durum = N'Üretimde';", baglanti))
                                sonuc.AktifUretimSayisi = Convert.ToInt64(komut.ExecuteScalar());
                        }
                    }
                    return sonuc;
                });
                if (aktifKullanici?.KullaniciId != oturumId) return;
                AnaKritikStokTablosu.ItemsSource = veri.Kritik.DefaultView;
                AnaAktifUretimTablosu.ItemsSource = veri.Uretim.DefaultView;
                TxtAnaKritikSayi.Text = veri.StokGoruntulemeYetkisi ?
                    veri.KritikSayisi + " kritik" : "Yetki yok";
                TxtAnaUretimSayi.Text = veri.UretimGoruntulemeYetkisi ?
                    veri.AktifUretimSayisi + " devam ediyor" : "Yetki yok";
                TxtAnaKritikDurum.Text = !veri.StokGoruntulemeYetkisi ?
                    "Stok görüntüleme yetkiniz yok." : veri.KritikSayisi == 0 ? "Kritik seviyede stok yok." :
                    "Minimum seviyeye inen " + veri.KritikSayisi + " stok kartı var.";
                TxtAnaUretimDurum.Text = !veri.UretimGoruntulemeYetkisi ?
                    "Üretim görüntüleme yetkiniz yok." : veri.AktifUretimSayisi == 0 ? "Şu anda üretimde emir yok." :
                    "Üretimde olan " + veri.AktifUretimSayisi + " emir takip ediliyor.";
                SektorOzetYazilariniUygula(veri);
                TxtAnaSonYenileme.Text = "Stok ve üretim son yenileme: " +
                    DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");
            }
            catch (Exception hata)
            {
                TxtAnaSonYenileme.Text = "Ana sayfa verileri alınamadı: " + hata.Message;
                TxtAnaKritikDurum.Text = "Veri okunamadı.";
                TxtAnaUretimDurum.Text = "Veri okunamadı.";
            }
            finally { anaVeriYukleniyor = false; }
        }

        // Son başarılı kur tarihi/saatini üst çubukta ve kartta görünür tutar.
        // Veri çekilemezse eski fiyatı yeni fiyat gibi sunmayız.
        private void AnaKurUyarisiGuncelle(bool goster, AnaKurBilgisi? sonKur, string aciklama)
        {
            BrdUstKurUyari.Visibility = goster ? Visibility.Visible : Visibility.Collapsed;
            BrdAnaKurUyari.Visibility = goster ? Visibility.Visible : Visibility.Collapsed;
            if (!goster) return;

            string sonAlis = sonKur == null
                ? "Son başarılı kur yok"
                : "Son başarılı: " + sonKur.SonKontrol.ToString("dd.MM.yyyy HH:mm");
            TxtUstKurUyari.Text = sonAlis;
            TxtAnaKurUyari.Text = aciklama + " • " + sonAlis +
                (sonKur == null ? "" : " • TCMB yayın tarihi: " + sonKur.YayinTarihi);
            BrdUstKurUyari.ToolTip = TxtAnaKurUyari.Text;
        }

        private void AnaKuruEkrandaGoster(AnaKurBilgisi kur, bool onbellekten)
        {
            CultureInfo tr = CultureInfo.GetCultureInfo("tr-TR");
            TxtUstUsd.Text = kur.UsdSatis.ToString("N4", tr);
            TxtUstEur.Text = kur.EurSatis.ToString("N4", tr);
            TxtAnaUsdAlis.Text = kur.UsdAlis.ToString("N4", tr);
            TxtAnaUsdSatis.Text = kur.UsdSatis.ToString("N4", tr);
            TxtAnaEurAlis.Text = kur.EurAlis.ToString("N4", tr);
            TxtAnaEurSatis.Text = kur.EurSatis.ToString("N4", tr);

            string yayim = string.IsNullOrWhiteSpace(kur.YayinTarihi)
                ? "Yayın tarihi belirtilmedi" : "Yayın: " + kur.YayinTarihi;
            string durum = (onbellekten ? "Son kayıtlı kur (çevrimdışı)" : "TCMB verisi alındı") +
                " • " + yayim +
                " • Son başarılı erişim: " + kur.SonKontrol.ToString("dd.MM.yyyy HH:mm") +
                " • Günlük gösterge; anlık işlem fiyatı değildir.";
            TxtAnaKurBilgi.Text = durum;
            TxtAnaKurDurum.Text = durum;
            TxtUstUsd.ToolTip = "TCMB USD/TRY döviz satış kuru. " + durum;
            TxtUstEur.ToolTip = "TCMB EUR/TRY döviz satış kuru. " + durum;
            AnaKurUyarisiGuncelle(onbellekten, kur,
                "Bu kurlar son kayıtlı değerlerdir. Bağlantı kontrol edilene kadar güncel kabul etmeyin.");
        }

        private void AnaKurOnbellektenYukle()
        {
            try
            {
                string yol = AnaKurOnbellekYolu;
                if (!File.Exists(yol)) return;
                AnaKurBilgisi? kayit = JsonSerializer.Deserialize<AnaKurBilgisi>(File.ReadAllText(yol));
                if (kayit == null || !AnaKurKaydiGecerli(kayit)) return;
                anaSonBasariliKur = kayit;
                AnaKuruEkrandaGoster(kayit, onbellekten: true);
            }
            catch (Exception)
            {
                // Önbellek isteğe bağlıdır; bozuk dosya programı durdurmaz.
            }
        }

        private static bool AnaKurKaydiGecerli(AnaKurBilgisi kur) =>
            kur.UsdAlis > 0 && kur.UsdSatis > 0 && kur.EurAlis > 0 && kur.EurSatis > 0 &&
            kur.UsdAlis <= kur.UsdSatis && kur.EurAlis <= kur.EurSatis &&
            kur.SonKontrol > new DateTime(2020, 1, 1) &&
            kur.SonKontrol <= DateTime.Now.AddDays(1);

        private static void AnaKurOnbellegeKaydet(AnaKurBilgisi kur)
        {
            try
            {
                string yol = AnaKurOnbellekYolu;
                Directory.CreateDirectory(Path.GetDirectoryName(yol)!);
                string gecici = yol + ".tmp";
                File.WriteAllText(gecici, JsonSerializer.Serialize(kur));
                File.Move(gecici, yol, overwrite: true);
            }
            catch (Exception)
            {
                // Disk erişimi yoksa yalnızca kalıcı önbellek atlanır.
            }
        }

        private async Task AnaKurlariYukleAsync()
        {
            if (anaKurYukleniyor) return;
            anaKurYukleniyor = true;
            try
            {
                TxtAnaKurDurum.Text = "TCMB günlük döviz kurları kontrol ediliyor...";
                // TCMB gün içinde bir kez güncellediği için bu değerler piyasanın anlık teklifi değildir.
                string xml = await anaKurHttp.GetStringAsync("https://www.tcmb.gov.tr/kurlar/today.xml");
                XDocument belge = XDocument.Parse(xml);
                XElement? usd = null;
                XElement? eur = null;
                foreach (XElement satir in belge.Descendants("Currency"))
                {
                    string? kod = (string?)satir.Attribute("Kod");
                    if (kod == "USD") usd = satir;
                    else if (kod == "EUR") eur = satir;
                }
                if (usd == null || eur == null)
                    throw new InvalidDataException("TCMB yanıtında USD/EUR bulunamadı.");

                static decimal Oku(XElement kur, string alan)
                {
                    string? metin = (string?)kur.Element(alan);
                    if (!decimal.TryParse(metin, NumberStyles.AllowDecimalPoint,
                            CultureInfo.InvariantCulture, out decimal sonuc) || sonuc <= 0)
                        throw new InvalidDataException("TCMB kur değeri okunamadı: " + alan);
                    return sonuc;
                }
                var kayit = new AnaKurBilgisi
                {
                    UsdAlis = Oku(usd, "ForexBuying"),
                    UsdSatis = Oku(usd, "ForexSelling"),
                    EurAlis = Oku(eur, "ForexBuying"),
                    EurSatis = Oku(eur, "ForexSelling"),
                    YayinTarihi = ((string?)belge.Root?.Attribute("Tarih"))?.Trim() ?? "",
                    SonKontrol = DateTime.Now
                };
                if (!AnaKurKaydiGecerli(kayit))
                    throw new InvalidDataException("TCMB kurları tutarsız veya eksik.");
                anaSonBasariliKur = kayit;
                AnaKuruEkrandaGoster(kayit, onbellekten: false);
                AnaKurOnbellegeKaydet(kayit);
            }
            catch (Exception)
            {
                if (anaSonBasariliKur != null)
                {
                    AnaKuruEkrandaGoster(anaSonBasariliKur, onbellekten: true);
                    TxtAnaKurDurum.Text = "Kur servisine ulaşılamadı. Son kayıtlı TCMB kuru gösteriliyor (yeni kur değil). " +
                        "Yayın: " + anaSonBasariliKur.YayinTarihi;
                    TxtAnaKurBilgi.Text = TxtAnaKurDurum.Text;
                    AnaKurUyarisiGuncelle(true, anaSonBasariliKur,
                        "İnternet veya TCMB kur servisine ulaşılamıyor. Son başarılı kur gösteriliyor; yeni kur değil.");
                }
                else
                {
                    TxtAnaKurBilgi.Text = "Kur servisine erişilemedi. Şu an doğrulanmış kur gösterilemiyor.";
                    TxtAnaKurDurum.Text = TxtAnaKurBilgi.Text;
                    AnaKurUyarisiGuncelle(true, null,
                        "İnternet veya TCMB kur servisine ulaşılamıyor. Kayıtlı kur bulunamadı.");
                }
            }
            finally
            {
                anaKurYukleniyor = false;
            }
        }

        private void AnaSayfa_Click(object sender, RoutedEventArgs e)
        {
            AnaSayfayiAc();
        }

        private void StokYonetimi_Click(
            object sender, RoutedEventArgs e)
        {
            StokEkraniniAc();
        }

        private void UretimYonetimi_Click(
            object sender, RoutedEventArgs e)
        {
            UretimEkraniniAc();
        }

        private void UretimEkraniniAc()
        {
            if((LisansOturumu.Gecerli?.Sector??gorunum.Sektor)!="BORU"){SektorUretimAc_Click(this,new RoutedEventArgs());return;}
            if(!EskiUretimYetkisi("PRODUCTION.VIEW"))return;
            SayfaBasligi.Text = "Üretim Yönetimi";
            TumIcerikleriGizle();
            UretimIcerik.Visibility = Visibility.Visible;

            UretimMamulListesiniYukle();
            UretimEmirleriniListele();
            UretimFormunuTemizle();
            UretimGunlukOzetYenile();
        }

        private void UretimMamulListesiniYukle()
        {
            try
            {
                DataTable mamuller = new DataTable();

                using (SqlConnection baglanti = new SqlConnection(baglantiAdresi))
                {
                    baglanti.Open();

                    using (SqlCommand komut = new SqlCommand(
                        "SELECT Id, StokKodu + N' - ' + StokAdi AS SecimMetni " +
                        "FROM dbo.StokKartlari " +
                        "WHERE Aktif = 1 AND StokTipi IN (N'Başlık',N'Mandallı',N'Kangal') " +
                        "ORDER BY StokAdi;", baglanti))
                    using (SqlDataReader okuyucu = komut.ExecuteReader())
                    {
                        mamuller.Load(okuyucu);
                    }
                }

                CmbUretimMamul.ItemsSource = mamuller.DefaultView;
                CmbUretimMamul.DisplayMemberPath = "SecimMetni";
                CmbUretimMamul.SelectedValuePath = "Id";
                CmbUretimMamul.SelectedIndex = mamuller.Rows.Count > 0 ? 0 : -1;

                if (mamuller.Rows.Count == 0)
                {
                    MessageBox.Show(
                        "Üretilebilir aktif stok kartı bulunamadı. Stok Yönetimi bölümünden Başlık, Mandallı veya Kangal kartı oluşturun.",
                        "Mamul Bulunamadı",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(
                    "Mamul stokları yüklenemedi:\n\n" + hata.Message,
                    "MiapaxERP",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void UretimEmirleriniListele()
        {
            try
            {
                DataTable emirler = new DataTable();

                using (SqlConnection baglanti = new SqlConnection(baglantiAdresi))
                {
                    baglanti.Open();

                    string sorgu =
                        "SELECT ue.Id, ue.UretimEmriNo, sk.StokKodu, sk.StokAdi, " +
                        "ue.PlanlananMiktar, ue.UretilenMiktar, ue.FireMiktari, " +
                        "ue.PlanlananBaslangic, ue.PlanlananBitis, ue.Durum, ue.KayitTarihi, " +
                        "ISNULL(ue.MiktarBirimi, N'Eski kayıt') AS MiktarBirimi, " +
                        "ue.HedefAgirlikKg, r.ReceteKodu, sk.PaketIciAdet AS PaketVarsayilani, " +
                        "ISNULL(pak.PaketlenenAdet,CONVERT(bigint,0)) AS PaketlenenAdet, " +
                        "CASE WHEN usi.Id IS NOT NULL THEN N'Evet' WHEN ue.Durum=N'Tamamlandı' THEN N'Eski kayıt' ELSE N'Hayır' END AS StokIslemeDurumu " +
                        "FROM dbo.UretimEmirleri AS ue " +
                        "INNER JOIN dbo.StokKartlari AS sk ON sk.Id = ue.MamulStokId " +
                        "LEFT JOIN dbo.UretimReceteleri AS r ON r.Id = ue.ReceteId " +
                        "LEFT JOIN dbo.UretimStokIslemleri AS usi ON usi.UretimEmriId = ue.Id " +
                        "OUTER APPLY (SELECT SUM(pk.ToplamAdet) AS PaketlenenAdet " +
                        "FROM dbo.UretimPaketlemeKayitlari pk WHERE pk.UretimEmriId=ue.Id) pak " +
                        "ORDER BY ue.Id DESC;";

                    using (SqlCommand komut = new SqlCommand(sorgu, baglanti))
                    using (SqlDataReader okuyucu = komut.ExecuteReader())
                    {
                        emirler.Load(okuyucu);
                    }
                }

                int? oncekiEmir = (UretimEmirleriTablosu.SelectedItem as DataRowView)?["Id"] is object eski
                    ? Convert.ToInt32(eski) : null;
                uretimSecimYukleniyor = true;
                UretimEmirleriTablosu.ItemsSource = emirler.DefaultView;
                if (oncekiEmir.HasValue)
                {
                    foreach (DataRowView satir in emirler.DefaultView)
                    {
                        if (Convert.ToInt32(satir["Id"]) == oncekiEmir.Value)
                        {
                            UretimEmirleriTablosu.SelectedItem = satir;
                            break;
                        }
                    }
                }
                uretimSecimYukleniyor = false;
                UretimOperatorSecimYenile();
                UretimGunlukOzetYenile();
            }
            catch (Exception hata)
            {
                MessageBox.Show(
                    "Üretim emirleri yüklenemedi. UretimEmirleri tablosunun oluşturulduğunu kontrol edin.\n\n" +
                    hata.Message,
                    "MiapaxERP",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void UretimEmriNumarasiOlustur()
        {
            TxtUretimEmriNo.Text = "UE-" + DateTime.Now.ToString("yyyyMMdd-HHmmss-fff");
        }

        // Üretim birimi, mamul ve reçete değiştiğinde ilgili reçeteleri/ön izlemesini günceller.
        private void UretimMamul_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbUretimRecete == null || uretimFormYukleniyor) return;
            UretimReceteleriniYukle();
        }

        private void UretimReceteleriniYukle()
        {
            CmbUretimRecete.ItemsSource = null;
            uretimReceteOnizleme.Clear();
            TxtUretimReceteOzet.Text = "Bu mamul için reçete seçilmedi. Stok değişmez.";
            if (CmbUretimMamul.SelectedValue == null) return;
            try
            {
                DataTable receteler = new DataTable();
                using SqlConnection baglanti = new SqlConnection(baglantiAdresi);
                baglanti.Open();
                using SqlCommand komut = new SqlCommand(
                    "SELECT Id, ReceteKodu + N' - ' + ReceteAdi AS SecimMetni " +
                    "FROM dbo.UretimReceteleri WHERE Aktif=1 AND MamulStokId=@Mamul ORDER BY ReceteAdi;", baglanti);
                komut.Parameters.Add("@Mamul", SqlDbType.Int).Value = Convert.ToInt32(CmbUretimMamul.SelectedValue);
                using (SqlDataReader okuyucu = komut.ExecuteReader()) receteler.Load(okuyucu);
                CmbUretimRecete.ItemsSource = receteler.DefaultView;
                CmbUretimRecete.DisplayMemberPath = "SecimMetni";
                CmbUretimRecete.SelectedValuePath = "Id";
                CmbUretimRecete.SelectedIndex = -1; // kullanıcı bilinçli seçsin
            }
            catch (Exception hata)
            {
                MessageBox.Show("Üretim reçeteleri yüklenemedi:\n" + hata.Message,
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private string? UretimSecilenBirimi()
        {
            return (CmbUretimBirim.SelectedItem as ComboBoxItem)?.Tag?.ToString();
        }

        private static bool PozitifUretimSayisi(string metin, out decimal deger)
        {
            bool basarili = decimal.TryParse(metin.Trim().Replace(',', '.'), NumberStyles.AllowDecimalPoint,
                CultureInfo.InvariantCulture, out deger);
            return basarili && deger > 0m && deger <= 999999999999999.999m &&
                   decimal.Round(deger, 3) == deger;
        }

        private void UretimBirim_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UretimOnizlemeyiYenile();
        }

        private void UretimRecete_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UretimOnizlemeyiYenile();
        }

        private void UretimHesapDegisti(object sender, TextChangedEventArgs e)
        {
            UretimOnizlemeyiYenile();
        }

        private void UretimOnizlemeyiYenile()
        {
            if (TxtPlanlananMiktar == null || TxtUretimHedefKg == null ||
                CmbUretimBirim == null || CmbUretimRecete == null ||
                TxtUretimReceteOzet == null || uretimFormYukleniyor) return;

            string? birim = UretimSecilenBirimi();
            bool kgMi = birim == "kg";
            TxtUretimHedefKg.IsReadOnly = kgMi;
            if (kgMi)
            {
                string otomatik = PozitifUretimSayisi(TxtPlanlananMiktar.Text, out decimal plan)
                    ? plan.ToString("0.###", CultureInfo.GetCultureInfo("tr-TR")) : "";
                if (TxtUretimHedefKg.Text != otomatik)
                {
                    TxtUretimHedefKg.Text = otomatik;
                    // WPF TextChanged yeniden çağırabilir, ikinci çağrı aynı değeri değiştirmez.
                }
            }

            uretimReceteOnizleme.Clear();
            if (CmbUretimRecete.SelectedValue == null)
            {
                TxtUretimReceteOzet.Text = "Reçete seçilmedi: hammadde hesabı yapılmaz, stoklar değişmez.";
                return;
            }
            if (!PozitifUretimSayisi(TxtUretimHedefKg.Text, out decimal hedefKg))
            {
                TxtUretimReceteOzet.Text = kgMi
                    ? "Ön izleme için geçerli bir planlanan kg miktarı girin."
                    : "Metre/adet için gerçek hedef toplam ağırlığı kg olarak girin. Metre/adet, kg'ye otomatik eşitlenmez.";
                return;
            }
            try
            {
                decimal toplamOran = 0m;
                decimal toplamKg = 0m;
                using SqlConnection baglanti = new SqlConnection(baglantiAdresi);
                baglanti.Open();
                using SqlCommand komut = new SqlCommand(
                    "SELECT s.StokKodu + N' - ' + s.StokAdi AS Hammadde, k.YuzdeOrani " +
                    "FROM dbo.UretimReceteKalemleri k " +
                    "INNER JOIN dbo.StokKartlari s ON s.Id=k.HammaddeStokId " +
                    "WHERE k.ReceteId=@Recete ORDER BY k.Id;", baglanti);
                komut.Parameters.Add("@Recete", SqlDbType.Int).Value = Convert.ToInt32(CmbUretimRecete.SelectedValue);
                using SqlDataReader okuyucu = komut.ExecuteReader();
                while (okuyucu.Read())
                {
                    decimal oran = okuyucu.GetDecimal(1);
                    decimal kg = decimal.Round(hedefKg * oran / 100m, 3, MidpointRounding.AwayFromZero);
                    uretimReceteOnizleme.Rows.Add(okuyucu.GetString(0), oran, kg);
                    toplamOran += oran;
                    toplamKg += kg;
                }
                TxtUretimReceteOzet.Text = uretimReceteOnizleme.Rows.Count == 0
                    ? "Seçilen reçetede hammadde bulunamadı."
                    : "Hedef: " + hedefKg.ToString("0.###", CultureInfo.GetCultureInfo("tr-TR")) +
                      " kg | Oran toplamı: %" + toplamOran.ToString("0.####", CultureInfo.GetCultureInfo("tr-TR")) +
                      " | Hesaplanan: " + toplamKg.ToString("0.###", CultureInfo.GetCultureInfo("tr-TR")) +
                      " kg" + (toplamOran != 100m ? " | UYARI: Oran toplamı %100 değil!" : "");
            }
            catch (Exception hata)
            {
                uretimReceteOnizleme.Clear();
                TxtUretimReceteOzet.Text = "Ön izleme yapılamadı: " + hata.Message;
            }
        }

        private void UretimEmriKaydet_Click(object sender, RoutedEventArgs e)
        {
            if(!EskiUretimYetkisi("PRODUCTION.COMPLETE"))return;
            if (CmbUretimMamul.SelectedValue == null)
            {
                MessageBox.Show(
                    "Lütfen üretilecek Mamul stok kartını seçin.",
                    "Eksik Bilgi",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
                return;
            }

            string miktarMetni = TxtPlanlananMiktar.Text.Trim().Replace(',', '.');
            if (!decimal.TryParse(
                    miktarMetni,
                    NumberStyles.AllowDecimalPoint,
                    CultureInfo.InvariantCulture,
                    out decimal planlananMiktar) ||
                planlananMiktar <= 0)
            {
                MessageBox.Show(
                    "Planlanan miktar sıfırdan büyük geçerli bir sayı olmalıdır. Örnek: 1500 veya 1500,5",
                    "Geçersiz Miktar",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
                TxtPlanlananMiktar.Focus();
                return;
            }

            if (planlananMiktar > 999999999999999.999m)
            {
                MessageBox.Show("Girilen miktar izin verilen sınırı aşıyor.");
                return;
            }

            string? birim = UretimSecilenBirimi();
            if (birim != "kg" && birim != "metre" && birim != "adet")
            {
                MessageBox.Show("Lütfen üretim miktarı birimini seçin: kg, metre veya adet.",
                    "Eksik Birim", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (birim == "adet" && decimal.Truncate(planlananMiktar) != planlananMiktar)
            {
                MessageBox.Show("Adet cinsinden planlanan miktar tam sayı olmalıdır.",
                    "Geçersiz Adet", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (decimal.Round(planlananMiktar, 3) != planlananMiktar)
            {
                MessageBox.Show("Planlanan miktar en fazla 3 ondalık basamak olabilir.");
                return;
            }
            int? receteId = CmbUretimRecete.SelectedValue == null ? null :
                Convert.ToInt32(CmbUretimRecete.SelectedValue);
            decimal? hedefKg = null;
            if (birim == "kg")
                hedefKg = planlananMiktar;
            else if (!string.IsNullOrWhiteSpace(TxtUretimHedefKg.Text))
            {
                if (!PozitifUretimSayisi(TxtUretimHedefKg.Text, out decimal agirlik))
                {
                    MessageBox.Show("Hedef toplam ağırlık (kg) geçerli, pozitif ve en fazla 3 ondalıklı olmalıdır.");
                    return;
                }
                hedefKg = agirlik;
            }
            if (receteId.HasValue && !hedefKg.HasValue)
            {
                MessageBox.Show("Reçete hesaplamak için metre/adet miktarının yanı sıra toplam ağırlığı da kg olarak girmelisin.",
                    "Hedef Ağırlık Eksik", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (receteId.HasValue)
            {
                try
                {
                    using SqlConnection kontrolBaglantisi = new SqlConnection(baglantiAdresi);
                    kontrolBaglantisi.Open();
                    using SqlCommand kontrol = new SqlCommand(
                        "SELECT COUNT(*), ISNULL(SUM(k.YuzdeOrani),0) " +
                        "FROM dbo.UretimReceteleri r " +
                        "LEFT JOIN dbo.UretimReceteKalemleri k ON k.ReceteId=r.Id " +
                        "WHERE r.Id=@Recete AND r.MamulStokId=@Mamul AND r.Aktif=1;", kontrolBaglantisi);
                    kontrol.Parameters.Add("@Recete", SqlDbType.Int).Value = receteId.Value;
                    kontrol.Parameters.Add("@Mamul", SqlDbType.Int).Value = Convert.ToInt32(CmbUretimMamul.SelectedValue);
                    using SqlDataReader rdr = kontrol.ExecuteReader();
                    rdr.Read();
                    if (rdr.GetInt32(0) == 0 || rdr.GetDecimal(1) != 100m)
                    {
                        MessageBox.Show("Seçilen reçete bu mamule ait aktif bir reçete olmalı ve hammadde oranları %100 etmelidir.",
                            "Reçete Kontrolü", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }
                }
                catch (Exception hata)
                {
                    MessageBox.Show("Reçete doğrulanamadı:\n" + hata.Message);
                    return;
                }
            }

            DateTime? baslangic = DpUretimBaslangic.SelectedDate;
            DateTime? bitis = DpUretimBitis.SelectedDate;

            if (baslangic.HasValue && bitis.HasValue && bitis.Value.Date < baslangic.Value.Date)
            {
                MessageBox.Show(
                    "Planlanan bitiş tarihi başlangıç tarihinden önce olamaz.",
                    "Tarih Hatası",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
                return;
            }

            string emirNo = TxtUretimEmriNo.Text.Trim();
            if (string.IsNullOrWhiteSpace(emirNo))
            {
                UretimEmriNumarasiOlustur();
                emirNo = TxtUretimEmriNo.Text.Trim();
            }

            try
            {
                {new EskiUretimServisi(baglantiAdresi,aktifKullanici!.KullaniciId).EmirKaydet(new(duzenlenenUretimEmriId,emirNo,Convert.ToInt32(CmbUretimMamul.SelectedValue),planlananMiktar,birim!,receteId,hedefKg,baslangic,bitis,TxtUretimAciklama.Text.Trim()));}

                bool duzenlemeMi = duzenlenenUretimEmriId.HasValue;
                MessageBox.Show(
                    duzenlemeMi ? "Üretim emri başarıyla güncellendi." : "Üretim emri başarıyla oluşturuldu. Stok miktarlarında değişiklik yapılmadı.",
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Information);

                UretimEmirleriniListele();
                UretimFormunuTemizle();
            }
            catch (SqlException hata) when (hata.Number == 2601 || hata.Number == 2627)
            {
                MessageBox.Show(
                    "Üretim emri numarası zaten kullanılıyor. Lütfen tekrar deneyin.",
                    "Tekrarlanan Emir Numarası",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
                UretimEmriNumarasiOlustur();
            }
            catch (Exception hata)
            {
                MessageBox.Show(
                    "Üretim emri kaydedilemedi:\n\n" + hata.Message,
                    "MiapaxERP",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }


        private bool SeciliUretimEmriniAl(out int emirId, out string durum)
        {
            emirId = 0;
            durum = string.Empty;
            if (UretimEmirleriTablosu.SelectedItem is not DataRowView satir)
            {
                MessageBox.Show("Lütfen önce listeden bir üretim emri seçin.", "Emir Seçilmedi",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            emirId = Convert.ToInt32(satir["Id"]);
            durum = Convert.ToString(satir["Durum"]) ?? string.Empty;
            return true;
        }

        // Stok kartındaki KG/Metre/Adet ile üretim emrindeki kg/metre/adet uyumunu kontrol eder.
        // Ton gibi dönüşüm gerektiren birimler kasıtlı olarak otomatik çevrilmez.
        private static string? UretimBiriminiNormallestir(string? metin)
        {
            return metin?.Trim().ToLowerInvariant() switch
            {
                "kg" or "kilogram" => "kg",
                "metre" => "metre",
                "adet" => "adet",
                _ => null
            };
        }

        private static void UretimDecimalParametreEkle(SqlCommand komut, string ad,
            decimal deger, byte precision = 18, byte scale = 3)
        {
            SqlParameter p = komut.Parameters.Add(ad, SqlDbType.Decimal);
            p.Precision = precision;
            p.Scale = scale;
            p.Value = deger;
        }

        // Üretim başlatılırken seçili reçetenin sabit bir kopyasını kaydeder.
        // Sonradan reçete düzenlenirse eski üretim emrinin oranları değişmez.
        private void UretimiBaslat_Click(object sender, RoutedEventArgs e)
        {
            if(!EskiUretimYetkisi("PRODUCTION.COMPLETE"))return;
            if (DemoModu)
            {
                MessageBox.Show("Bu işlem SQL Server modunda kullanılabilir.");
                return;
            }
            if (!SeciliUretimEmriniAl(out int emirId, out string durum)) return;
            if (durum != "Planlandı")
            {
                MessageBox.Show("Yalnızca Planlandı durumundaki emir başlatılabilir.");
                return;
            }
            if (MessageBox.Show(
                    "Seçili üretim emri başlatılacak ve geçerli reçete oranları bu emre sabitlenecek.\n\n" +
                    "Bu işlem henüz stoktan malzeme düşmez. Devam edilsin mi?",
                    "Üretimi Başlat", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
            try
            {
                {new EskiUretimServisi(baglantiAdresi,aktifKullanici!.KullaniciId).Baslat(emirId);}
                UretimEmirleriniListele();
                MessageBox.Show("Üretim başlatıldı. Reçete oranları bu emre sabitlendi. Stoklar henüz değişmedi.",
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception hata)
            {
                MessageBox.Show("Üretim başlatılamadı. Yarım kayıt oluşturulmadı.\n\n" + hata.Message,
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool GerceklesenMiktarlariOku(out decimal uretilen, out decimal fire)
        {
            uretilen = 0m;
            fire = 0m;
            string uretilenMetni = TxtGerceklesenUretim.Text.Trim().Replace(',', '.');
            string fireMetni = TxtGerceklesenFire.Text.Trim().Replace(',', '.');
            bool uretilenGecerli = decimal.TryParse(uretilenMetni, NumberStyles.AllowDecimalPoint,
                CultureInfo.InvariantCulture, out uretilen);
            bool fireGecerli = decimal.TryParse(fireMetni, NumberStyles.AllowDecimalPoint,
                CultureInfo.InvariantCulture, out fire);
            if (!uretilenGecerli || !fireGecerli || uretilen < 0m || fire < 0m ||
                uretilen > 999999999999999.999m || fire > 999999999999999.999m)
            {
                MessageBox.Show("Üretilen miktar ve fire sıfır veya daha büyük geçerli sayılar olmalıdır. Örnek: 1200 veya 12,5",
                    "Geçersiz Miktar", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            return true;
        }

        // Emrin kumulatif miktarini degistirirken farki ayni SQL isleminde gunluk deftere yazar.
        private void UretimMiktarlariniKaydet_Click(object sender, RoutedEventArgs e)
        {
            if(!EskiUretimYetkisi("PRODUCTION.COMPLETE"))return;
            if (DemoModu || aktifKullanici == null) return;
            if (!SeciliUretimEmriniAl(out int emirId, out string durum)) return;
            if (durum != "Üretimde")
            {
                MessageBox.Show("Önce üretimi başlatın. Miktarlar yalnızca Üretimde durumunda kaydedilebilir.");
                return;
            }
            if (!GerceklesenMiktarlariOku(out decimal uretilen, out decimal fire)) return;
            if (decimal.Round(uretilen, 3) != uretilen || decimal.Round(fire, 3) != fire)
            {
                MessageBox.Show("Miktarlar en fazla üç ondalık olabilir.");
                return;
            }
            try
            {
                {new EskiUretimServisi(baglantiAdresi,aktifKullanici!.KullaniciId).MiktarKaydet(emirId,uretilen,fire);}
                UretimEmirleriniListele();
                MessageBox.Show("Miktarlar kaydedildi. Bugünkü üretim farkı rapora işlendi. " +
                    "Stok hareketi henüz yapılmadı.", "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception hata)
            {
                MessageBox.Show("Miktarlar kaydedilemedi; değişiklikler geri alındı:\n\n" + hata.Message,
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // 1) Emri kilitle 2) Başlangıçta sabitlenen reçeteyi oku 3) miktarları gram hassasiyetinde paylaştır
        // 4) hammaddeyi düş 5) mamulü ekle 6) stok geçmişini yaz 7) emri tamamla.
        // Her aşama aynı SERIALIZABLE transaction içindedir; hata olursa tamamı geri döner.
        private void UretimiTamamla_Click(object sender, RoutedEventArgs e)
        {
            if(!EskiUretimYetkisi("PRODUCTION.COMPLETE"))return;
            if (DemoModu)
            {
                MessageBox.Show("Otomatik stok hareketleri yalnızca SQL Server modunda kullanılabilir.");
                return;
            }
            if (!SeciliUretimEmriniAl(out int emirId, out string durum)) return;
            if (durum != "Üretimde")
            {
                MessageBox.Show("Yalnızca Üretimde durumundaki emir tamamlanabilir.", "İşlem Yapılamadı",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (!GerceklesenMiktarlariOku(out decimal uretilen, out decimal fire)) return;
            if (uretilen + fire <= 0m)
            {
                MessageBox.Show("Sağlam ürün veya fire miktarından en az biri sıfırdan büyük olmalıdır.");
                return;
            }
            if (decimal.Round(uretilen, 3) != uretilen || decimal.Round(fire, 3) != fire)
            {
                MessageBox.Show("Üretilen ve fire miktarları en fazla üç ondalık basamak olmalıdır.");
                return;
            }
            if (MessageBox.Show(
                "DİKKAT: Bu işlem hammadde stoklarını azaltır, sağlam mamulü stoğa ekler, fireyi kaydeder " +
                "ve üretim emrini TAMAMLANDI yapar.\n\n" +
                "Bu stok işlemi aynı emir için sadece bir kez yapılır. Önce deneme stoklarıyla test edin. Devam edilsin mi?",
                "Stoklara İşleyerek Üretimi Tamamla", MessageBoxButton.YesNo, MessageBoxImage.Warning)
                != MessageBoxResult.Yes) return;

            try
            {
                decimal hesaplananTuketimKg = 0m;
                {hesaplananTuketimKg=new EskiUretimServisi(baglantiAdresi,aktifKullanici!.KullaniciId).Tamamla(emirId,uretilen,fire);}
                UretimEmirleriniListele();
                MessageBox.Show("Üretim tamamlandı. " + hesaplananTuketimKg.ToString("0.###", CultureInfo.GetCultureInfo("tr-TR")) +
                    " KG hammadde tüketildi; " + uretilen.ToString("0.###", CultureInfo.GetCultureInfo("tr-TR")) + " sağlam mamul stoklara işlendi. " +
                    "Fire: " + fire.ToString("0.###", CultureInfo.GetCultureInfo("tr-TR")) + ". İkinci stok işleme engellendi.",
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception hata)
            {
                MessageBox.Show("Üretim tamamlanamadı; SQL işlemi geri alındı, stoklar değişmedi.\n\n" +
                    hata.Message, "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Error);
                UretimEmirleriniListele();
            }
        }

        private void UretimEmriniIptalEt_Click(object sender, RoutedEventArgs e)
        {
            if (!SeciliUretimEmriniAl(out int emirId, out string durum)) return;
            if (durum != "Planlandı")
            {
                MessageBox.Show("Güvenlik için yalnızca henüz başlamamış Planlandı durumundaki emirler iptal edilebilir.",
                    "İşlem Yapılamadı", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            MessageBoxResult onay = MessageBox.Show("Seçili üretim emri iptal edilsin mi? Emir silinmeyecek, geçmişte İptal durumunda kalacak.",
                "Üretim Emrini İptal Et", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (onay != MessageBoxResult.Yes) return;
            try
            {
                {new EskiUretimServisi(baglantiAdresi,aktifKullanici!.KullaniciId).EmirIptal(emirId);}                UretimEmirleriniListele();
                MessageBox.Show("Üretim emri iptal edildi. Kayıt geçmişte korunuyor.", "MiapaxERP",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception hata)
            {
                MessageBox.Show("Üretim emri iptal edilemedi:\n\n" + hata.Message, "MiapaxERP",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UretimEmriYenile_Click(object sender, RoutedEventArgs e)
        {
            UretimMamulListesiniYukle();
            UretimEmirleriniListele();
        }

        private void UretimEmirleriTablosu_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (!uretimSecimYukleniyor) UretimOperatorSecimYenile();
        }

        // v0.14 Operator arayuzu. Paketleme SQL stok bakiyesi degistirmez.
        private static string uretimYazi(decimal sayi) => sayi.ToString("0.###", uretimTr);

        private static decimal UretimPaketlenmisToplam(SqlConnection baglanti,
            SqlTransaction? islem, int emirId)
        {
            using var k = new SqlCommand(
                "SELECT ISNULL(SUM(ToplamAdet),CONVERT(bigint,0)) " +
                "FROM dbo.UretimPaketlemeKayitlari WITH (UPDLOCK,HOLDLOCK) " +
                "WHERE UretimEmriId=@Emir;", baglanti, islem);
            k.Parameters.Add("@Emir", SqlDbType.Int).Value = emirId;
            return Convert.ToDecimal(k.ExecuteScalar());
        }

        private void UretimGunlukFarkKaydet(SqlConnection baglanti, SqlTransaction islem,
            int emirId, decimal uretilenFark, decimal fireFark)
        {
            if (uretilenFark == 0m && fireFark == 0m) return;
            using var k = new SqlCommand(
                "INSERT INTO dbo.UretimGunlukKayitlari " +
                "(UretimEmriId,UretilenFark,FireFark,KaydedenKullaniciId) " +
                "VALUES(@Id,@U,@F,@K);", baglanti, islem);
            k.Parameters.Add("@Id", SqlDbType.Int).Value = emirId;
            UretimDecimalParametreEkle(k, "@U", uretilenFark);
            UretimDecimalParametreEkle(k, "@F", fireFark);
            k.Parameters.Add("@K", SqlDbType.Int).Value = aktifKullanici?.KullaniciId is int id
                ? (object)id : DBNull.Value;
            k.ExecuteNonQuery();
        }

        private void UretimGunlukOzetYenile()
        {
            if (TxtBugunUretilen == null || TxtBugunPaketlenen == null || TxtBugunPaketSayisi == null)
                return;
            if (DemoModu || aktifKullanici == null)
            {
                TxtBugunUretilen.Text = "—";
                TxtBugunPaketlenen.Text = "—";
                TxtBugunPaketSayisi.Text = "—";
                return;
            }
            try
            {
                using var baglanti = new SqlConnection(baglantiAdresi);
                baglanti.Open();
                var bilgiler = new List<string>();
                using (var k = new SqlCommand(@"
                    SELECT COALESCE(ue.MiktarBirimi,N'?') AS Birim,
                           SUM(g.UretilenFark) AS Toplam
                    FROM dbo.UretimGunlukKayitlari g
                    JOIN dbo.UretimEmirleri ue ON ue.Id=g.UretimEmriId
                    WHERE g.KayitTarihi >= CONVERT(date,SYSDATETIME())
                      AND g.KayitTarihi < DATEADD(day,1,CONVERT(date,SYSDATETIME()))
                    GROUP BY ue.MiktarBirimi ORDER BY ue.MiktarBirimi;", baglanti))
                using (var r = k.ExecuteReader())
                {
                    while (r.Read())
                        bilgiler.Add(uretimYazi(r.GetDecimal(1)) + " " + r.GetString(0));
                }
                TxtBugunUretilen.Text = bilgiler.Count == 0 ? "0" : string.Join(" / ", bilgiler);
                using var pk = new SqlCommand(@"
                    SELECT COALESCE(SUM(ToplamAdet),0), COALESCE(SUM(CONVERT(bigint,PaketSayisi)),0)
                    FROM dbo.UretimPaketlemeKayitlari
                    WHERE KayitTarihi >= CONVERT(date,SYSDATETIME())
                      AND KayitTarihi < DATEADD(day,1,CONVERT(date,SYSDATETIME()));", baglanti);
                using var paketOkuyucu = pk.ExecuteReader();
                paketOkuyucu.Read();
                TxtBugunPaketlenen.Text = Convert.ToDecimal(paketOkuyucu.GetValue(0))
                    .ToString("0", uretimTr);
                TxtBugunPaketSayisi.Text = Convert.ToDecimal(paketOkuyucu.GetValue(1))
                    .ToString("0", uretimTr);
            }
            catch (Exception ex)
            {
                TxtBugunUretilen.Text = "Veri yok";
                TxtBugunPaketlenen.Text = "—";
                TxtBugunPaketSayisi.Text = "—";
                TxtUretimSecimBilgi.Text = "Günlük sayım okunamadı: " + ex.Message;
            }
        }

        private void UretimOperatorSecimYenile()
        {
            if (TxtUretimSecimBilgi == null || TxtPaketDurum == null ||
                TxtGerceklesenUretim == null || TxtGerceklesenFire == null ||
                TxtToplamCikan == null || TxtPaketIciAdet == null) return;
            uretimOtomatikFireYukleniyor = true;
            try
            {
                if (UretimEmirleriTablosu.SelectedItem is not DataRowView r)
                {
                    TxtUretimSecimBilgi.Text = "Önce yukarıdan bir üretim emri seçin.";
                    TxtPaketDurum.Text = "Paketleme için üretim emri seçin.";
                    TxtGerceklesenUretim.Clear();
                    TxtGerceklesenFire.Clear();
                    TxtToplamCikan.Clear();
                    TxtPaketIciAdet.Clear();
                    TxtPaketSayisi.Clear();
                    return;
                }
                string durum = Convert.ToString(r["Durum"]) ?? "";
                string birim = Convert.ToString(r["MiktarBirimi"]) ?? "";
                decimal iyi = Convert.ToDecimal(r["UretilenMiktar"]);
                decimal fire = Convert.ToDecimal(r["FireMiktari"]);
                decimal paketli = Convert.ToDecimal(r["PaketlenenAdet"]);
                TxtGerceklesenUretim.Text = uretimYazi(iyi);
                TxtGerceklesenFire.Text = uretimYazi(fire);
                TxtToplamCikan.Text = uretimYazi(iyi + fire);
                TxtUretimSecimBilgi.Text = Convert.ToString(r["UretimEmriNo"]) + "  •  " +
                    Convert.ToString(r["StokAdi"]) + "  •  " + durum +
                    "  •  Hedef " + uretimYazi(Convert.ToDecimal(r["PlanlananMiktar"])) + " " + birim;
                bool paketlenebilir = (durum == "Üretimde" || durum == "Tamamlandı") &&
                    UretimBiriminiNormallestir(birim) == "adet";
                TxtPaketDurum.Text = paketlenebilir
                    ? "Sağlam üretilen: " + uretimYazi(iyi) + " adet  •  Paketli: " + uretimYazi(paketli) +
                      " adet  •  Bekleyen: " + uretimYazi(iyi - paketli) + " adet"
                    : "Paketleme yalnızca Adet birimli, üretimdeki veya tamamlanmış emirlerde kullanılabilir.";
                TxtPaketIciAdet.Text = r["PaketVarsayilani"] == DBNull.Value
                    ? "" : Convert.ToString(r["PaketVarsayilani"], CultureInfo.InvariantCulture) ?? "";
                TxtPaketSayisi.Text = "1";
                ChkPaketVarsayilanKaydet.IsChecked = false;
            }
            finally
            {
                uretimOtomatikFireYukleniyor = false;
                UretimPaketOnizlemeDegisti(this, new TextChangedEventArgs(TextBox.TextChangedEvent, UndoAction.None));
            }
        }

        // Her iki miktar operator tarafindan girilir, fire = toplam cikan - saglam.
        private void UretimFireHesapDegisti(object sender, TextChangedEventArgs e)
        {
            if (uretimOtomatikFireYukleniyor || TxtToplamCikan == null ||
                TxtGerceklesenUretim == null || TxtGerceklesenFire == null) return;
            bool toplamOk = decimal.TryParse(TxtToplamCikan.Text.Trim().Replace(',', '.'),
                NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out decimal toplam);
            bool iyiOk = decimal.TryParse(TxtGerceklesenUretim.Text.Trim().Replace(',', '.'),
                NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out decimal iyi);
            TxtGerceklesenFire.Text = toplamOk && iyiOk && toplam >= iyi && iyi >= 0 && toplam >= 0
                ? uretimYazi(toplam - iyi) : "";
        }

        private void UretimPaketOnizlemeDegisti(object sender, TextChangedEventArgs e)
        {
            if (TxtPaketOnizleme == null || BtnPaketKaydet == null || TxtPaketIciAdet == null ||
                TxtPaketSayisi == null) return;
            bool adetGecerli = int.TryParse(TxtPaketIciAdet.Text.Trim(), out int adet) &&
                               adet > 0 && adet <= 1000000;
            bool paketGecerli = int.TryParse(TxtPaketSayisi.Text.Trim(), out int paket) && paket > 0;
            bool uygun = adetGecerli && paketGecerli;
            bool secimUygun = UretimEmirleriTablosu?.SelectedItem is DataRowView secilen &&
                (Convert.ToString(secilen["Durum"]) == "Üretimde" ||
                 Convert.ToString(secilen["Durum"]) == "Tamamlandı") &&
                UretimBiriminiNormallestir(Convert.ToString(secilen["MiktarBirimi"])) == "adet";
            BtnPaketKaydet.IsEnabled = uygun && secimUygun && !paketKaydiYapiliyor;
            TxtPaketOnizleme.Text = uygun
                ? "Kaydedilecek: " + ((long)adet * paket).ToString("N0", uretimTr) + " boru  (" +
                  adet + " × " + paket + " paket)"
                : "Pozitif tam sayı girin: örn. 25 boru × 4 paket = 100 boru";
        }

        private void UretimPaketKaydet_Click(object sender, RoutedEventArgs e)
        {
            if(!EskiUretimYetkisi("PRODUCTION.COMPLETE"))return;
            if (DemoModu || aktifKullanici == null || paketKaydiYapiliyor) return;
            if (!SeciliUretimEmriniAl(out int emirId, out string durum)) return;
            if (!int.TryParse(TxtPaketIciAdet.Text.Trim(), out int adet) ||
                adet <= 0 || adet > 1000000 ||
                !int.TryParse(TxtPaketSayisi.Text.Trim(), out int paketSayisi) || paketSayisi <= 0)
            {
                MessageBox.Show("Paket içi adet ve paket sayısı pozitif tam sayı olmalıdır.");
                return;
            }
            long toplam = (long)adet * paketSayisi;
            bool varsayilaniKaydet = ChkPaketVarsayilanKaydet.IsChecked == true;
            if (MessageBox.Show(paketSayisi + " paket × " + adet + " boru = " + toplam.ToString("N0", uretimTr) +
                 " adet için yeni paketleme kaydı oluşturulsun mu?\n\n" +
                 "Bu işlem stok bakiyesini değiştirmez. Lütfen fiziksel paketleri kontrol edin.",
                 "Paketleme Kaydı Onayı", MessageBoxButton.YesNo, MessageBoxImage.Question)
                 != MessageBoxResult.Yes) return;
            paketKaydiYapiliyor = true;
            BtnPaketKaydet.IsEnabled = false;
            try
            {
                {new EskiUretimServisi(baglantiAdresi,aktifKullanici!.KullaniciId).Paketle(emirId,adet,paketSayisi,varsayilaniKaydet);}
                UretimEmirleriniListele();
                MessageBox.Show("Paketleme kaydı oluşturuldu: " + paketSayisi + " paket, toplam " +
                    toplam + " adet. Stok bakiyesi değişmedi.", "MiapaxERP", MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Paketleme kaydedilemedi; hiçbir yarım kayıt bırakılmadı.\n\n" +
                    ex.Message, "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                paketKaydiYapiliyor = false;
                UretimPaketOnizlemeDegisti(this,
                    new TextChangedEventArgs(TextBox.TextChangedEvent, UndoAction.None));
            }
        }

        private void UretimEmriDuzenle_Click(object sender, RoutedEventArgs e)
        {
            if (UretimEmirleriTablosu.SelectedItem is not DataRowView satir)
            {
                MessageBox.Show("Lütfen listeden düzenlemek istediğiniz üretim emrini seçin.", "Emir Seçilmedi", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            int emirId = Convert.ToInt32(satir["Id"]);
            try
            {
                using (SqlConnection baglanti = new SqlConnection(baglantiAdresi))
                {
                    baglanti.Open();
                    const string sorgu = "SELECT Id, UretimEmriNo, MamulStokId, PlanlananMiktar, PlanlananBaslangic, PlanlananBitis, Aciklama, Durum, UretilenMiktar, FireMiktari, MiktarBirimi, ReceteId, HedefAgirlikKg FROM dbo.UretimEmirleri WHERE Id = @Id;";
                    using (SqlCommand komut = new SqlCommand(sorgu, baglanti))
                    {
                        komut.Parameters.Add("@Id", SqlDbType.Int).Value = emirId;
                        using (SqlDataReader okuyucu = komut.ExecuteReader())
                        {
                            if (!okuyucu.Read())
                            {
                                MessageBox.Show("Seçilen üretim emri bulunamadı.");
                                return;
                            }
                            if (Convert.ToString(okuyucu["Durum"]) != "Planlandı" || Convert.ToDecimal(okuyucu["UretilenMiktar"]) != 0m || Convert.ToDecimal(okuyucu["FireMiktari"]) != 0m)
                            {
                                MessageBox.Show("Güvenlik için yalnızca 'Planlandı' durumundaki ve üretilen/fire miktarı sıfır olan emirler düzenlenebilir.", "Emir Düzenlenemez", MessageBoxButton.OK, MessageBoxImage.Warning);
                                return;
                            }

                            uretimFormYukleniyor = true;
                            duzenlenenUretimEmriId = emirId;
                            TxtUretimEmriNo.Text = Convert.ToString(okuyucu["UretimEmriNo"]);
                            CmbUretimMamul.SelectedValue = Convert.ToInt32(okuyucu["MamulStokId"]);
                            TxtPlanlananMiktar.Text = Convert.ToDecimal(okuyucu["PlanlananMiktar"]).ToString("0.###", CultureInfo.GetCultureInfo("tr-TR"));
                            DpUretimBaslangic.SelectedDate = okuyucu["PlanlananBaslangic"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(okuyucu["PlanlananBaslangic"]);
                            DpUretimBitis.SelectedDate = okuyucu["PlanlananBitis"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(okuyucu["PlanlananBitis"]);
                            TxtUretimAciklama.Text = okuyucu["Aciklama"] == DBNull.Value ? string.Empty : Convert.ToString(okuyucu["Aciklama"]);
                            string? eskiBirim = okuyucu["MiktarBirimi"] == DBNull.Value ? null : Convert.ToString(okuyucu["MiktarBirimi"]);
                            CmbUretimBirim.SelectedIndex = eskiBirim == "kg" ? 0 :
                                eskiBirim == "metre" ? 1 : eskiBirim == "adet" ? 2 : -1;
                            TxtUretimHedefKg.Text = okuyucu["HedefAgirlikKg"] == DBNull.Value ? "" :
                                Convert.ToDecimal(okuyucu["HedefAgirlikKg"]).ToString("0.###", CultureInfo.GetCultureInfo("tr-TR"));
                            int? eskiReceteId = okuyucu["ReceteId"] == DBNull.Value ? null : Convert.ToInt32(okuyucu["ReceteId"]);
                            uretimFormYukleniyor = false;
                            UretimReceteleriniYukle();
                            if (eskiReceteId.HasValue)
                            {
                                CmbUretimRecete.SelectedValue = eskiReceteId.Value;
                                if (CmbUretimRecete.SelectedValue == null)
                                    MessageBox.Show("Bu emre bağlı reçete artık aktif olmayabilir. Kaydetmeden önce geçerli bir reçete seçin.");
                            }
                            UretimOnizlemeyiYenile();
                        }
                    }
                }

                TxtUretimFormBasligi.Text = "Üretim Emrini Düzenle";
                BtnUretimEmriKaydet.Content = "Değişiklikleri Kaydet";
                BtnUretimDuzenleIptal.Visibility = Visibility.Visible;
            }
            catch (Exception hata)
            {
                uretimFormYukleniyor = false;
                MessageBox.Show("Üretim emri düzenleme için yüklenemedi:\n\n" + hata.Message, "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UretimEmriSil_Click(object sender, RoutedEventArgs e)
        {
            if(!EskiUretimYetkisi("PRODUCTION.COMPLETE"))return;
            if (UretimEmirleriTablosu.SelectedItem is not DataRowView satir)
            {
                MessageBox.Show("Lütfen listeden silmek istediğiniz üretim emrini seçin.", "Emir Seçilmedi", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            int emirId = Convert.ToInt32(satir["Id"]);
            string emirNo = Convert.ToString(satir["UretimEmriNo"]) ?? string.Empty;
            MessageBoxResult onay = MessageBox.Show(
                "'" + emirNo + "' numaralı üretim emrini silmek istediğinizden emin misiniz?\n\nYalnızca Planlandı durumundaki ve üretim/fire miktarı sıfır olan emirler silinebilir.",
                "Üretim Emrini Sil", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (onay != MessageBoxResult.Yes) return;

            try
            {
                {new EskiUretimServisi(baglantiAdresi,aktifKullanici!.KullaniciId).EmirSil(emirId);}
                if (duzenlenenUretimEmriId == emirId) UretimFormunuTemizle();
                UretimEmirleriniListele();
                MessageBox.Show("Üretim emri silindi.", "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception hata)
            {
                MessageBox.Show("Üretim emri silinemedi:\n\n" + hata.Message, "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UretimDuzenleIptal_Click(object sender, RoutedEventArgs e)
        {
            UretimFormunuTemizle();
        }

        private void UretimFormunuTemizle_Click(object sender, RoutedEventArgs e)
        {
            UretimFormunuTemizle();
        }

        private void UretimFormunuTemizle()
        {
            uretimFormYukleniyor = true;
            duzenlenenUretimEmriId = null;
            UretimEmriNumarasiOlustur();
            CmbUretimMamul.SelectedIndex = CmbUretimMamul.Items.Count > 0 ? 0 : -1;
            TxtPlanlananMiktar.Clear();
            CmbUretimBirim.SelectedIndex = -1;
            CmbUretimRecete.SelectedIndex = -1;
            TxtUretimHedefKg.Clear();
            DpUretimBaslangic.SelectedDate = null;
            DpUretimBitis.SelectedDate = null;
            TxtUretimAciklama.Clear();
            TxtUretimFormBasligi.Text = "Yeni Üretim Emri";
            BtnUretimEmriKaydet.Content = "Üretim Emri Oluştur";
            BtnUretimDuzenleIptal.Visibility = Visibility.Collapsed;
            uretimFormYukleniyor = false;
            UretimReceteleriniYukle();
            UretimOnizlemeyiYenile();
        }

        private void UretimReceteleri_Click(object sender, RoutedEventArgs e)
        {
            if((LisansOturumu.Gecerli?.Sector??gorunum.Sektor)!="BORU"){SektorUretimAc_Click(this,new RoutedEventArgs());return;}
            if(!EskiUretimYetkisi("PRODUCTION.VIEW"))return;
            SayfaBasligi.Text = "Üretim Reçeteleri";
            TumIcerikleriGizle();
            ReceteIcerik.Visibility = Visibility.Visible;
            ReceteStoklariniYukle();
            ReceteFormunuTemizle();
            ReceteleriListele();
        }

        private void ReceteStoklariniYukle()
        {
            try
            {
                using (var baglanti = new SqlConnection(baglantiAdresi))
                {
                    baglanti.Open();
                    using (var komut = new SqlCommand("SELECT Id, StokKodu + N' - ' + StokAdi AS Ad, StokTipi FROM dbo.StokKartlari WHERE Aktif=1 AND StokTipi IN (N'Başlık',N'Mandallı',N'Kangal',N'Hammadde') ORDER BY StokAdi", baglanti))
                    using (var okuyucu = komut.ExecuteReader())
                    {
                        var tablo = new DataTable(); tablo.Load(okuyucu);
                        var mamuller = new DataView(tablo) { RowFilter = "StokTipi IN ('Başlık','Mandallı','Kangal')" };
                        var hammaddeler = new DataView(tablo) { RowFilter = "StokTipi = 'Hammadde'" };
                        CmbReceteMamul.ItemsSource = mamuller;
                        CmbReceteMamul.DisplayMemberPath = "Ad"; CmbReceteMamul.SelectedValuePath = "Id";
                        CmbReceteHammadde.ItemsSource = hammaddeler;
                        CmbReceteHammadde.DisplayMemberPath = "Ad"; CmbReceteHammadde.SelectedValuePath = "Id";
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show("Reçete stokları yüklenemedi: " + ex.Message); }
        }

        private void ReceteKalemEkle_Click(object sender, RoutedEventArgs e)
        {
            if (CmbReceteHammadde.SelectedItem is not DataRowView secilen)
            { MessageBox.Show("Önce hammadde seçin. Stok Yönetimi bölümünde Hammadde türünde aktif kart bulunmalıdır."); return; }
            string giris = TxtReceteYuzde.Text.Trim().Replace(',', '.');
            if (!decimal.TryParse(giris, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out decimal yuzde) || yuzde <= 0 || yuzde > 100)
            { MessageBox.Show("0 ile 100 arasında geçerli bir yüzde girin. Örnek: 2,5"); return; }
            if (decimal.Round(yuzde, 4) != yuzde)
            { MessageBox.Show("Oran en fazla dört ondalık basamak içerebilir. Örnek: 2,5125"); return; }
            int stokId = Convert.ToInt32(secilen["Id"]);
            foreach (DataRow satir in receteKalemleri.Rows)
                if (Convert.ToInt32(satir["HammaddeStokId"]) == stokId)
                { MessageBox.Show("Bu hammadde zaten eklendi. Önce mevcut satırı çıkarın."); return; }
            receteKalemleri.Rows.Add(stokId, Convert.ToString(secilen["Ad"]), yuzde);
            ReceteToplamiGoster();
            TxtReceteYuzde.Clear();
        }

        private void ReceteKalemCikar_Click(object sender, RoutedEventArgs e)
        {
            if (ReceteKalemleriTablosu.SelectedItem is DataRowView satir)
            { receteKalemleri.Rows.Remove(satir.Row); ReceteToplamiGoster(); }
        }

        private void ReceteToplamiGoster()
        {
            decimal toplam = 0;
            foreach (DataRow satir in receteKalemleri.Rows) toplam += Convert.ToDecimal(satir["Yuzde"]);
            TxtReceteToplam.Text = "Toplam: %" + toplam.ToString("0.####", CultureInfo.GetCultureInfo("tr-TR"));
            ReceteKilogramHesapla();
        }

        private void ReceteHesapKg_TextChanged(object sender, TextChangedEventArgs e)
        {
            ReceteKilogramHesapla();
        }

        // Reçeteyi KAYDETMEZ; sadece ekranda gösterilen kilogramları hesaplar.
        private void ReceteKilogramHesapla()
        {
            var tr = CultureInfo.GetCultureInfo("tr-TR");
            string giris = TxtReceteHesapKg.Text.Trim().Replace(',', '.');
            bool sayiGecerli = decimal.TryParse(
                giris, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture,
                out decimal toplamKg);

            if (!sayiGecerli || toplamKg <= 0 || toplamKg > 999999999m ||
                decimal.Round(toplamKg, 3) != toplamKg)
            {
                foreach (DataRow satir in receteKalemleri.Rows)
                    satir["GerekliKg"] = DBNull.Value;
                TxtReceteHesapDurum.Text =
                    "Geçerli bir kilogram girin (ör. 750 veya 750,5). Sıfırdan büyük ve en fazla 3 ondalıklı olmalı.";
                TxtReceteHesapDurum.Foreground = System.Windows.Media.Brushes.Firebrick;
                return;
            }

            decimal hesaplananToplam = 0;
            decimal toplamYuzde = 0;
            foreach (DataRow satir in receteKalemleri.Rows)
            {
                decimal oran = Convert.ToDecimal(satir["Yuzde"]);
                decimal gereken = decimal.Round(toplamKg * oran / 100m, 3, MidpointRounding.AwayFromZero);
                satir["GerekliKg"] = gereken;
                hesaplananToplam += gereken;
                toplamYuzde += oran;
            }

            if (receteKalemleri.Rows.Count == 0)
            {
                TxtReceteHesapDurum.Text = "Hesaplama için en az bir hammadde ekleyin.";
            }
            else if (toplamYuzde != 100m)
            {
                TxtReceteHesapDurum.Text =
                    "Ön hesap: " + hesaplananToplam.ToString("0.###", tr) +
                    " kg. Oranlar henüz %100 değil (şu an %" + toplamYuzde.ToString("0.####", tr) + ").";
            }
            else
            {
                TxtReceteHesapDurum.Text =
                    "Hesaplanan hammadde toplamı: " + hesaplananToplam.ToString("0.###", tr) +
                    " kg / Hedef: " + toplamKg.ToString("0.###", tr) + " kg." +
                    (hesaplananToplam != toplamKg ? " Satırların 1 gram hassasiyette yuvarlanmasından küçük fark oluşabilir." : "");
            }
            TxtReceteHesapDurum.Foreground = System.Windows.Media.Brushes.DarkBlue;
        }

        private void ReceteKaydet_Click(object sender, RoutedEventArgs e)
        {
            if(!EskiUretimYetkisi("PRODUCTION.RECIPE"))return;
            string kod = TxtReceteKodu.Text.Trim();
            string ad = TxtReceteAdi.Text.Trim();
            if (kod.Length == 0 || ad.Length == 0 || CmbReceteMamul.SelectedValue == null)
            {
                MessageBox.Show("Reçete kodu, adı ve aktif mamul seçimi zorunludur.");
                return;
            }
            if (kod.Length > 30 || ad.Length > 150)
            {
                MessageBox.Show("Reçete kodu en fazla 30, adı en fazla 150 karakter olmalıdır.");
                return;
            }

            decimal toplam = 0;
            foreach (DataRow satir in receteKalemleri.Rows)
                toplam += Convert.ToDecimal(satir["Yuzde"]);
            if (receteKalemleri.Rows.Count == 0 || toplam != 100m)
            {
                MessageBox.Show("Reçeteyi kaydetmek için hammadde oranlarının toplamı tam %100 olmalıdır.");
                return;
            }

            try
            {
                bool guncelleme = duzenlenenReceteId.HasValue;
                {new EskiUretimServisi(baglantiAdresi,aktifKullanici!.KullaniciId).ReceteKaydet(new(duzenlenenReceteId,kod,ad,Convert.ToInt32(CmbReceteMamul.SelectedValue),receteKalemleri.AsEnumerable().Select(r=>new ErpEskiReceteKalemi(Convert.ToInt32(r["HammaddeStokId"]),Convert.ToDecimal(r["Yuzde"]))).ToArray()));}
                MessageBox.Show(guncelleme ? "Reçete başarıyla güncellendi." : "Reçete ve hammaddeleri kaydedildi.");
                ReceteFormunuTemizle();
                ReceteleriListele();
            }
            catch (SqlException ex) when (ex.Number == 2601 || ex.Number == 2627)
            {
                MessageBox.Show("Bu reçete kodu zaten kullanılıyor veya aynı hammadde tekrarlanıyor.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Reçete kaydedilemedi: " + ex.Message);
            }
        }

        private void ReceteDuzenle_Click(object sender, RoutedEventArgs e)
        {
            if (RecetelerTablosu.SelectedItem is not DataRowView secilen)
            {
                MessageBox.Show("Önce Kayıtlı Reçeteler listesinden bir reçete seçin.");
                return;
            }
            int receteId = Convert.ToInt32(secilen["Id"]);
            if (!Convert.ToBoolean(secilen["Aktif"]))
            {
                MessageBox.Show("Pasif reçeteyi düzenlemek için önce Geri Yükle butonuyla aktifleştirin.");
                return;
            }

            try
            {
                string kod;
                string ad;
                int mamulStokId;
                var kalemler = new DataTable();
                using (var baglanti = new SqlConnection(baglantiAdresi))
                {
                    baglanti.Open();
                    using (var komut = new SqlCommand(
                        "SELECT ReceteKodu,ReceteAdi,MamulStokId FROM dbo.UretimReceteleri WHERE Id=@Id AND Aktif=1;", baglanti))
                    {
                        komut.Parameters.Add("@Id", SqlDbType.Int).Value = receteId;
                        using (var okuyucu = komut.ExecuteReader())
                        {
                            if (!okuyucu.Read())
                            {
                                MessageBox.Show("Reçete bulunamadı veya pasife alındı. Listeyi yenileyin.");
                                return;
                            }
                            kod = Convert.ToString(okuyucu["ReceteKodu"]) ?? "";
                            ad = Convert.ToString(okuyucu["ReceteAdi"]) ?? "";
                            mamulStokId = Convert.ToInt32(okuyucu["MamulStokId"]);
                        }
                    }
                    using (var komut = new SqlCommand(
                        "SELECT k.HammaddeStokId, s.StokKodu + N' - ' + s.StokAdi AS Hammadde, " +
                        "k.YuzdeOrani AS Yuzde FROM dbo.UretimReceteKalemleri k " +
                        "JOIN dbo.StokKartlari s ON s.Id=k.HammaddeStokId " +
                        "WHERE k.ReceteId=@Id ORDER BY k.Id;", baglanti))
                    {
                        komut.Parameters.Add("@Id", SqlDbType.Int).Value = receteId;
                        using (var okuyucu = komut.ExecuteReader()) kalemler.Load(okuyucu);
                    }
                }

                ReceteFormunuTemizle();
                TxtReceteKodu.Text = kod;
                TxtReceteAdi.Text = ad;
                CmbReceteMamul.SelectedValue = mamulStokId;
                foreach (DataRow satir in kalemler.Rows)
                    receteKalemleri.Rows.Add(satir["HammaddeStokId"], satir["Hammadde"], satir["Yuzde"]);
                ReceteToplamiGoster();
                duzenlenenReceteId = receteId;
                TxtReceteFormBasligi.Text = "Üretim Reçetesini Düzenle";
                BtnReceteKaydet.Content = "Değişiklikleri Kaydet";
                BtnReceteDuzenlemeyiIptal.Visibility = Visibility.Visible;
                if (CmbReceteMamul.SelectedValue == null)
                    MessageBox.Show("Reçetenin mamul stok kartı pasif olabilir. Kaydetmeden önce aktif bir mamul seçin.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Reçete düzenleme için yüklenemedi: " + ex.Message);
            }
        }

        private void ReceteSil_Click(object sender, RoutedEventArgs e)
        {
            if(!EskiUretimYetkisi("PRODUCTION.RECIPE"))return;
            if (RecetelerTablosu.SelectedItem is not DataRowView secilen)
            {
                MessageBox.Show("Önce silmek istediğiniz reçeteyi seçin.");
                return;
            }
            if (!Convert.ToBoolean(secilen["Aktif"]))
            {
                MessageBox.Show("Bu reçete zaten pasif durumda.");
                return;
            }
            int receteId = Convert.ToInt32(secilen["Id"]);
            string ad = Convert.ToString(secilen["ReceteAdi"]) ?? "";
            MessageBoxResult onay = MessageBox.Show(
                "'" + ad + "' reçetesini silmek (pasife almak) istiyor musunuz?\n\n" +
                "Reçete ve hammadde kalemleri veritabanında korunur. Geri Yükle ile yeniden kullanılabilir.",
                "Reçeteyi Sil (Pasife Al)", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (onay != MessageBoxResult.Yes) return;
            try
            {
                {new EskiUretimServisi(baglantiAdresi,aktifKullanici!.KullaniciId).RecetePasif(receteId);}
                if (duzenlenenReceteId == receteId) ReceteFormunuTemizle();
                ReceteleriListele();
                MessageBox.Show("Reçete pasife alındı. İsterseniz Geri Yükle ile aktifleştirebilirsiniz.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Reçete pasife alınamadı: " + ex.Message);
            }
        }

        private void ReceteAktiflestir_Click(object sender, RoutedEventArgs e)
        {
            if(!EskiUretimYetkisi("PRODUCTION.RECIPE"))return;
            if (RecetelerTablosu.SelectedItem is not DataRowView secilen)
            {
                MessageBox.Show("Önce geri yüklemek istediğiniz reçeteyi seçin.");
                return;
            }
            if (Convert.ToBoolean(secilen["Aktif"]))
            {
                MessageBox.Show("Bu reçete zaten aktif.");
                return;
            }
            int receteId = Convert.ToInt32(secilen["Id"]);
            try
            {
                {new EskiUretimServisi(baglantiAdresi,aktifKullanici!.KullaniciId).ReceteAktif(receteId);}
                ReceteleriListele();
                MessageBox.Show("Reçete yeniden aktifleştirildi.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Reçete aktifleştirilemedi: " + ex.Message);
            }
        }

        private void ReceteFormunuTemizle()
        {
            duzenlenenReceteId = null;
            TxtReceteKodu.Clear();
            TxtReceteAdi.Clear();
            TxtReceteYuzde.Clear();
            TxtReceteHesapKg.Text = "100";
            CmbReceteMamul.SelectedIndex = -1;
            CmbReceteHammadde.SelectedIndex = -1;
            receteKalemleri.Clear();
            ReceteToplamiGoster();
            TxtReceteFormBasligi.Text = "Yeni Üretim Reçetesi";
            BtnReceteKaydet.Content = "Reçeteyi Kaydet";
            BtnReceteDuzenlemeyiIptal.Visibility = Visibility.Collapsed;
        }

        private void ReceteTemizle_Click(object sender, RoutedEventArgs e) => ReceteFormunuTemizle();
        private void ReceteDuzenlemeyiIptal_Click(object sender, RoutedEventArgs e) => ReceteFormunuTemizle();
        private void ReceteYenile_Click(object sender, RoutedEventArgs e) => ReceteleriListele();

        private void ReceteleriListele()
        {
            try
            {
                var tablo = new DataTable();
                using (var baglanti = new SqlConnection(baglantiAdresi))
                {
                    baglanti.Open();
                    using (var komut = new SqlCommand(
                        "SELECT r.Id,r.ReceteKodu,r.ReceteAdi,s.StokAdi,r.Aktif, " +
                        "CASE WHEN r.Aktif=1 THEN N'Aktif' ELSE N'Pasif' END AS Durum " +
                        "FROM dbo.UretimReceteleri r " +
                        "INNER JOIN dbo.StokKartlari s ON s.Id=r.MamulStokId ORDER BY r.Id DESC;", baglanti))
                    using (var okuyucu = komut.ExecuteReader()) tablo.Load(okuyucu);
                }
                RecetelerTablosu.ItemsSource = tablo.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Reçeteler listelenemedi: " + ex.Message);
            }
        }

        private void TeklifSatisPanel_Click(object sender, RoutedEventArgs e) => MuhasebeBolumAc("teklif");

        private void KisayolTeklif_Click(object sender, RoutedEventArgs e)
            => TeklifSatisPanel_Click(sender, e);

        private void CariHesaplar_Click(
            object sender, RoutedEventArgs e)
        {
            TicariPencereAc(0, "CUSTOMER.VIEW");
        }

        private void Muhasebe_Click(
            object sender, RoutedEventArgs e)
        {
            MuhasebeBolumAc(null);
        }

        private void Raporlar_Click(
            object sender, RoutedEventArgs e)
        {
            TicariPencereAc(2, "REPORT.VIEW");
        }

        // Giriş zorunlu: X veya Esc ile giriş penceresi kapanırsa MiapaxERP kapanır.
        // Bu aşama yalnızca arayüz/oturum kilididir; veri API yetkileri ayrıca uygulanacaktır.
        private void OturumGirisiniGoster()
        {
            if (girisPenceresiAcik) return;
            if (DemoModu)
            {
                TxtUstProfilBaslik.Text = "Demo Modu";
                TxtUstProfil.Text = "SQL kullanıcı girişi kapalı";
                BtnOturumIslem.IsEnabled = false;
                return;
            }

            girisPenceresiAcik = true;
            IsEnabled = false;
            bool girisBasarili = false;
            try
            {
                var pencere = new GirisPenceresi(baglantiAdresi) { Owner = this };
                if (pencere.ShowDialog() == true && pencere.Oturum != null)
                {
                    aktifKullanici = pencere.Oturum;
                    TakvimOturumunuTemizle();
                    GorunumYukle();
                    Dispatcher.BeginInvoke(new Action(() => { TakvimYenile(); TakvimAcilisUyarisi(); }));
                    KayitBeklemeKatmani.Visibility =
                        string.Equals(aktifKullanici.Roller.Trim(), "Kısıtlı Kullanıcı", StringComparison.OrdinalIgnoreCase)
                        ? Visibility.Visible : Visibility.Collapsed;
                    BtnBildirimler.Visibility = aktifKullanici.Roller.Split(',')
                        .Any(x => string.Equals(x.Trim(), "Yönetici", StringComparison.OrdinalIgnoreCase))
                        ? Visibility.Visible : Visibility.Collapsed;
                    bildirimZamanlayici.Start();
                    _ = BildirimleriYenileAsync(false);
                    YardimOturumAcildi();
                    ProfilBilgisiniYenile();
                    StokYetkiGorunumuYenile();
                    _ = AnaSayfaVerileriniYukleAsync();
                    _ = AnaSayfaTicariYukleAsync();
                    girisBasarili = true;
                    IsEnabled = true;
                    _ = AgOnbellekYenileAsync();
                    AgDurumunuEkranaYansit();
                }
            }
            catch (Exception hata)
            {
                MessageBox.Show("Giriş penceresi açılamadı. Güvenlik nedeniyle MiapaxERP kapatılacak.\n\n" +
                    hata.Message, "MiapaxERP | Giriş Hatası", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                girisPenceresiAcik = false;
            }

            if (!girisBasarili)
            {
                MuhasebeOturumunuTemizle();
                DahiliTicariIcerik.Content = null;
                aktifKullanici = null;
                GorunumuUygula(new GorunumTercihleri());
                // X, pencere kapatma, yanlış oturum sonucu ve hatalarda güvenli çıkış.
                Close();
            }
        }

        private void ProfilBilgisiniYenile()
        {
            if (aktifKullanici == null)
            {
                TxtUstProfilBaslik.Text = "Kullanıcı Girişi";
                TxtUstProfil.Text = "Oturum açık değil";
                BtnOturumIslem.Content = "Oturum Aç";
                BtnProfil.ToolTip = "Giriş yapmak için tıklayın";
                return;
            }
            TxtUstProfilBaslik.Text = aktifKullanici.AdSoyad;
            TxtUstProfil.Text = aktifKullanici.Roller;
            BtnOturumIslem.Content = "Çıkış";
            BtnProfil.ToolTip = "Kullanıcı: " + aktifKullanici.KullaniciAdi +
                                 "\nRol: " + aktifKullanici.Roller;
        }

        private void Profil_Click(object sender, RoutedEventArgs e)
        {
            if (aktifKullanici == null)
            {
                OturumGirisiniGoster();
                return;
            }
            MessageBox.Show("Ad Soyad: " + aktifKullanici.AdSoyad +
                "\nKullanıcı adı: " + aktifKullanici.KullaniciAdi +
                "\nRol: " + aktifKullanici.Roller +
                "\n\nStok işlemlerinde kullanıcı yetki kontrolü aktiftir. Diğer modüller sıradaki aşamalardır.",
                "MiapaxERP | Profil", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void OturumIslem_Click(object sender, RoutedEventArgs e)
        {
            if (muhasebePaneli?.IslemSuruyor == true) { MessageBox.Show("Muhasebe işlemi tamamlandıktan sonra çıkış yapabilirsiniz."); return; }
            if (aktifKullanici == null)
            {
                OturumGirisiniGoster();
                return;
            }
            if(HttpsOturumu.Uzak(baglantiAdresi)){Close();return;}
            YardimOturumKapatildi();
            try { BeniHatirlaServisi.OturumuIptalEt(baglantiAdresi); }
            catch (Exception hata) { MessageBox.Show("Hatırlanan oturum sunucuda iptal edilemedi: " + hata.Message); }
            MuhasebeOturumunuTemizle();
            DahiliTicariIcerik.Content = null;
            aktifKullanici = null;
            TakvimOturumunuTemizle();
            GorunumuUygula(new GorunumTercihleri());
            bildirimZamanlayici.Stop();
            BildirimPopup.IsOpen = false;
            BtnBildirimler.Visibility = Visibility.Collapsed;
            KayitBeklemeKatmani.Visibility = Visibility.Collapsed;
            ProfilBilgisiniYenile();
            StokYetkiGorunumuYenile();
            duzenlenenStokId = null;
            StokTablosu.ItemsSource = null;
            StokKritikTablosu.ItemsSource = null;
            StokHareketGecmisiTablosu.ItemsSource = null;
            StokAcilisHareketTablosu.ItemsSource = null;
            StokBakiyeRaporTablosu.ItemsSource = null;
            AnaKritikStokTablosu.ItemsSource = null;
            AnaAktifUretimTablosu.ItemsSource = null;
            AnaBorcluCarilerTablosu.ItemsSource = null;
            AnaBugunEvrakTablosu.ItemsSource = null;
            AnaYaklasanOdemeTablosu.ItemsSource = null;
            TumIcerikleriGizle();
            AnaSayfaIcerik.Visibility = Visibility.Visible;
            // Çıkış yapan kullanıcı menülere erişemez; hemen yeni giriş istenir.
            // Giriş penceresi X ile kapanırsa uygulama da kapanır.
            OturumGirisiniGoster();
        }

        // Yönetim penceresi açılırken yeniden yönetici parolası ister.
        // Bu aşamada mevcut modül işlem yetkileri henüz zorunlu kılınmamıştır.

        private sealed class BildirimSatiri
        {
            public int Id { get; init; }
            public string Gosterim { get; init; } = "";
        }

        private async Task BildirimleriYenileAsync(bool listeyiAc)
        {
            if (bildirimYukleniyor || aktifKullanici == null ||
                BtnBildirimler.Visibility != Visibility.Visible || DemoModu) return;
            int id = aktifKullanici.KullaniciId;
            bildirimYukleniyor = true;
            try
            {
                var sonuc = await Task.Run(() =>
                {
                    var bildirimler = new List<BildirimSatiri>();
                    using var baglanti = new SqlConnection(baglantiAdresi);
                    baglanti.Open();
                    using (var rol = new SqlCommand(@"
SELECT COUNT_BIG(*) FROM dbo.Kullanicilar k
JOIN dbo.KullaniciRolAtamalari a ON a.KullaniciId=k.Id
JOIN dbo.KullaniciRolleri r ON r.Id=a.RolId
WHERE k.Id=@Id AND k.Aktif=1 AND r.Aktif=1 AND r.RolAdi=N'Yönetici';", baglanti))
                    {
                        rol.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                        if (Convert.ToInt64(rol.ExecuteScalar()) == 0)
                            return (Bildirimler: bildirimler, Okunmamis: 0);
                    }
                    int okunmamis;
                    using (var say = new SqlCommand(
                        "SELECT COUNT(*) FROM dbo.Bildirimler WHERE AliciKullaniciId=@Id AND OkunduUtc IS NULL;", baglanti))
                    {
                        say.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                        okunmamis = Convert.ToInt32(say.ExecuteScalar());
                    }
                    if (listeyiAc)
                    {
                        using var oku = new SqlCommand(@"
SELECT TOP (50) Id, Baslik, Mesaj, KayitTarihiUtc, OkunduUtc
FROM dbo.Bildirimler WHERE AliciKullaniciId=@Id
ORDER BY Id DESC;", baglanti);
                        oku.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                        using var okuyucu = oku.ExecuteReader();
                        while (okuyucu.Read())
                        {
                            bool okundu = !okuyucu.IsDBNull(4);
                            bildirimler.Add(new BildirimSatiri
                            {
                                Id = okuyucu.GetInt32(0),
                                Gosterim = (okundu ? "✓ " : "● ") + okuyucu.GetString(1) +
                                    "\n" + okuyucu.GetString(2) + "\n" +
                                    DateTime.SpecifyKind(okuyucu.GetDateTime(3), DateTimeKind.Utc).ToLocalTime().ToString("dd.MM.yyyy HH:mm")
                            });
                        }
                    }
                    return (Bildirimler: bildirimler, Okunmamis: okunmamis);
                });
                if (aktifKullanici?.KullaniciId != id) return;
                BtnBildirimler.Content = "🔔 Bildirim (" + sonuc.Okunmamis + ")";
                if (listeyiAc)
                {
                    BildirimListesi.ItemsSource = sonuc.Bildirimler;
                    goruntulenenBildirimIdleri.Clear();
                    foreach (var b in sonuc.Bildirimler) goruntulenenBildirimIdleri.Add(b.Id);
                    BildirimPopup.IsOpen = true;
                }
            }
            catch (Exception hata)
            {
                if (listeyiAc) MessageBox.Show("Bildirimler okunamadı: " + hata.Message, "MiapaxERP");
            }
            finally { bildirimYukleniyor = false; }
        }

        private async void Bildirimler_Click(object sender, RoutedEventArgs e) =>
            await BildirimleriYenileAsync(true);

        private async void BildirimleriOkunduYap_Click(object sender, RoutedEventArgs e)
        {
            if (aktifKullanici == null || goruntulenenBildirimIdleri.Count == 0) return;
            int id = aktifKullanici.KullaniciId;
            var bildirimIdleri = goruntulenenBildirimIdleri.ToArray();
            try
            {
                await Task.Run(() =>
                {
                    if(HttpsOturumu.Uzak(baglantiAdresi)){new YardimciEkranServisi(baglantiAdresi,id).BildirimOkundu(bildirimIdleri);return;}
                    using var baglanti = new SqlConnection(baglantiAdresi);
                    baglanti.Open();
                    using var islem = baglanti.BeginTransaction();
                    try
                    {
                        foreach (int bildirimId in bildirimIdleri)
                        {
                            using var komut = new SqlCommand(@"
UPDATE dbo.Bildirimler SET OkunduUtc=SYSUTCDATETIME()
WHERE Id=@BildirimId AND AliciKullaniciId=@Id AND OkunduUtc IS NULL
  AND EXISTS(SELECT 1 FROM dbo.Kullanicilar k
      JOIN dbo.KullaniciRolAtamalari a ON a.KullaniciId=k.Id
      JOIN dbo.KullaniciRolleri r ON r.Id=a.RolId
      WHERE k.Id=@Id AND k.Aktif=1 AND r.Aktif=1 AND r.RolAdi=N'Yönetici');", baglanti, islem);
                            komut.Parameters.Add("@BildirimId", SqlDbType.Int).Value = bildirimId;
                            komut.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                            komut.ExecuteNonQuery();
                        }
                        islem.Commit();
                    }
                    catch { islem.Rollback(); throw; }
                });
                if (aktifKullanici?.KullaniciId != id) return;
                BildirimPopup.IsOpen = false;
                await BildirimleriYenileAsync(false);
            }
            catch (Exception hata)
            {
                MessageBox.Show("Bildirimler işaretlenemedi: " + hata.Message, "MiapaxERP");
            }
        }

        private void KullaniciYonetimi_Click(object sender, RoutedEventArgs e)
        {
            if (DemoModu)
            {
                MessageBox.Show("Kullanıcı yönetimi bu aşamada SQL Server modunda çalışır.",
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            var pencere = new KullaniciYonetimiPenceresi(baglantiAdresi)
            {
                Owner = this
            };
            pencere.ShowDialog();
        }

        // Firma kartı artık Ayarlar ekranından bağımsızdır.
        private void FirmaBilgileri_Click(object sender, RoutedEventArgs e)
        {
            if (DemoModu || aktifKullanici == null)
            {
                MessageBox.Show("Firma bilgileri için SQL oturumu açılmalıdır.");
                return;
            }
            var pencere = new FirmaBilgileriPenceresi(baglantiAdresi, aktifKullanici.KullaniciId)
            {
                Owner = this
            };
            pencere.ShowDialog();
        }

        private void Ayarlar_Click(
            object sender, RoutedEventArgs e)
        {
            TicariPencereAc(3, "SETTINGS.VIEW");
        }
    }
}




