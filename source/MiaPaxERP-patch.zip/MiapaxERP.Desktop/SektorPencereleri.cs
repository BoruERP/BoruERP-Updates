using System.Data;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using MiapaxERP.Lisans.Core;
namespace MiapaxERP.Desktop;

static class SektorArayuz
{
    public static DataGrid Grid()
    {
        var grid=new DataGrid{IsReadOnly=true,AutoGenerateColumns=true,CanUserAddRows=false,SelectionMode=DataGridSelectionMode.Single,Margin=new Thickness(0,8,0,8)};
        grid.AutoGeneratingColumn+=(_,e)=>{if(e.Column is DataGridTextColumn c&&c.Binding is System.Windows.Data.Binding b){if(e.PropertyType==typeof(DateTime))b.StringFormat="dd.MM.yyyy HH:mm";if(e.PropertyType==typeof(decimal))b.StringFormat=e.PropertyName is "BirimFiyat" or "Toplam" or "Odenen" or "Kalan" or "Tutar"?"N2":"0.###";}};return grid;
    }
    public static void B(Panel p,string text,Action a)=>ErpModulPenceresi.B(p,text,a);
    public static void Alan(Panel p,string text,Control c){p.Children.Add(new TextBlock{Text=text,Margin=new Thickness(4,8,4,3),TextWrapping=TextWrapping.Wrap});c.MinHeight=32;c.Margin=new Thickness(4);p.Children.Add(c);}
    public static decimal N(string text,int decimals=3)
    {
        if(!decimal.TryParse(text.Trim().Replace(',','.'),NumberStyles.AllowDecimalPoint,CultureInfo.InvariantCulture,out var n)||n<0||decimal.Round(n,decimals)!=n)throw new ArgumentException("Binlik ayırıcı olmadan, en fazla "+decimals+" ondalıklı sayı girin.");return n;
    }
    public static void Combo(ComboBox box,DataTable table,string display="Ad"){box.ItemsSource=table.DefaultView;box.DisplayMemberPath=display;box.SelectedValuePath="Id";box.SelectedIndex=-1;}
    public static long Id(ComboBox c)=>c.SelectedValue is null?throw new ArgumentException("Listeden bir kayıt seçin."):Convert.ToInt64(c.SelectedValue);
    public static void Tab(System.Windows.Controls.TabControl tabs,string name,UIElement content)=>tabs.Items.Add(new TabItem{Header=name,Content=content});
}
public sealed class SektorUretimPenceresi:Window
{
    readonly SektorUretimServisi db;
    readonly ComboBox output=new(),input=new(),recipes=new();
    readonly TextBox code=new(),name=new(),fire=new(){Text="0"},per=new(),qty=new(),document=new();
    readonly DataGrid materials=SektorArayuz.Grid(),history=SektorArayuz.Grid(),recipeList=SektorArayuz.Grid();
    readonly DataTable ingredients=new();Guid productionKey=Guid.NewGuid();
    readonly string sector;
    public SektorUretimPenceresi(string connection,int user,string sector)
    {
        LisansOturumu.Gerekli("URETIM");this.sector=sector;db=new(connection,user);db.Kur();Title="MiapaxERP | "+UrunKatalogu.SektorBul(sector).UretimAdi;Width=1120;Height=800;WindowStartupLocation=WindowStartupLocation.CenterOwner;
        var tabs=new System.Windows.Controls.TabControl{Margin=new Thickness(18)};Content=tabs;
        ingredients.Columns.Add("StokId",typeof(int));ingredients.Columns.Add("Ürün");ingredients.Columns.Add("Birim");ingredients.Columns.Add("Bir çıktı için miktar",typeof(decimal));materials.ItemsSource=ingredients.DefaultView;
        var form=new StackPanel{MaxWidth=780};
        form.Children.Add(new TextBlock{Text="Birim bazlı reçete",FontSize=24,Margin=new Thickness(4,10,4,12)});
        form.Children.Add(new TextBlock{Text="Bir çıktı birimi için gereken her girdiyi kendi stok biriminde girin. KG–M3, metre–adet veya yoğunluk dönüşümü yapılmaz. Fire alanı, reçeteye eklenecek tüketim yüzdesidir. Tüketim stok hassasiyetine göre 0,001 birime yukarı yuvarlanır.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(4)});
        SektorArayuz.Alan(form,"Reçete kodu",code);SektorArayuz.Alan(form,"Reçete adı",name);SektorArayuz.Alan(form,"Çıktı / mamul stok kartı",output);SektorArayuz.Alan(form,"Fire nedeniyle ek tüketim (%) — yoksa 0",fire);
        SektorArayuz.Alan(form,"Girdi stok kartı",input);SektorArayuz.Alan(form,"Bir çıktı birimi için girdi miktarı (en fazla 6 ondalık)",per);
        var add=new WrapPanel();form.Children.Add(add);SektorArayuz.B(add,"Girdiyi ekle",()=>{var id=(int)SektorArayuz.Id(input);var row=(DataRowView)input.SelectedItem;if(ingredients.AsEnumerable().Any(r=>(int)r["StokId"]==id))throw new ArgumentException("Aynı girdiyi bir kez ekleyin.");decimal n=SektorArayuz.N(per.Text,6);if(n<=0)throw new ArgumentException("Girdi miktarı pozitif olmalı.");ingredients.Rows.Add(id,row["StokAdi"],row["Birim"],n);});
        SektorArayuz.B(add,"Seçili girdiyi kaldır",()=>{if(materials.SelectedItem is DataRowView r)r.Delete();});materials.Height=170;form.Children.Add(materials);
        SektorArayuz.B(form,"Yeni reçeteyi kaydet",()=>{db.ReceteKaydet(code.Text,name.Text,(int)SektorArayuz.Id(output),SektorArayuz.N(fire.Text),sector,ingredients.AsEnumerable().Select(r=>new ReceteBileseni((int)r["StokId"],(decimal)r["Bir çıktı için miktar"])).ToArray());ingredients.Clear();code.Clear();name.Clear();Yukle();});
        SektorArayuz.Tab(tabs,"Yeni reçete",new ScrollViewer{Content=form,VerticalScrollBarVisibility=ScrollBarVisibility.Auto});SektorArayuz.Tab(tabs,"Reçeteler",recipeList);
        var run=new StackPanel{MaxWidth=700};run.Children.Add(new TextBlock{Text="Üretim tamamla",FontSize=24,Margin=new Thickness(4,10,4,14)});SektorArayuz.Alan(run,"Reçete",recipes);SektorArayuz.Alan(run,"Gerçekleşen çıktı miktarı (çıktı stok kartının biriminde)",qty);SektorArayuz.Alan(run,"Üretim belge / parti no",document);
        SektorArayuz.B(run,"Tüketimi ve mamul girişini kaydet",()=>{db.Uret(productionKey,SektorArayuz.Id(recipes),SektorArayuz.N(qty.Text),document.Text);productionKey=Guid.NewGuid();qty.Clear();document.Clear();Yukle();});
        run.Children.Add(new TextBlock{Text="Girdilerden biri yetersizse tüm işlem geri alınır. Aynı işlem anahtarı tekrar gönderildiğinde ikinci stok hareketi yazılmaz. Reçeteler geçmiş kayıtları korumak için bu ekranda değiştirilmez; yeni kodla yeni reçete oluşturulur.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(4,20,4,4)});
        SektorArayuz.Tab(tabs,"Üretim kaydı",run);SektorArayuz.Tab(tabs,"Üretim geçmişi",history);Yukle();
    }
    void Yukle(){var stock=db.Oku("stok");SektorArayuz.Combo(output,stock,"Secim");SektorArayuz.Combo(input,stock.Copy(),"Secim");var r=db.Oku("recete");recipeList.ItemsSource=r.DefaultView;SektorArayuz.Combo(recipes,r.Copy());history.ItemsSource=db.Oku("uretim").DefaultView;}
}
public sealed class RestoranPenceresi:Window
{
    readonly RestoranServisi db;
    readonly DataGrid bills=SektorArayuz.Grid(),lines=SektorArayuz.Grid(),kitchen=SektorArayuz.Grid(),payments=SektorArayuz.Grid();
    readonly ComboBox tables=new(),menu=new(),account=new(),method=new(){ItemsSource=new[]{"Nakit","Kart","Havale"},SelectedIndex=0},product=new(),recipe=new(),editMenu=new();
    readonly TextBox quantity=new(){Text="1"},amount=new(),receipt=new(),reason=new(),tableName=new(),menuName=new(),price=new();
    readonly TextBlock summary=new(){Margin=new Thickness(4,12,4,8),TextWrapping=TextWrapping.Wrap};
    readonly SektorUretimServisi production;Guid openKey=Guid.NewGuid(),itemKey=Guid.NewGuid(),payKey=Guid.NewGuid();
    int? editingMenu;byte[]? menuVersion;
    DataRowView Sec()=>bills.SelectedItem as DataRowView??throw new ArgumentException("Önce bir adisyon seçin.");
    long Bill=>(long)Sec()["Id"];byte[] Version=>(byte[])Sec()["Surum"];
    public RestoranPenceresi(string connection,int user)
    {
        LisansOturumu.Gerekli("RESTORAN");db=new(connection,user);db.Kur();production=new(connection,user);
        Title="MiapaxERP | Restoran · Masa / Adisyon / Mutfak";Width=1230;Height=850;WindowStartupLocation=WindowStartupLocation.CenterOwner;
        var tabs=new System.Windows.Controls.TabControl{Margin=new Thickness(18)};Content=tabs;
        var root=new DockPanel();var bar=new WrapPanel();DockPanel.SetDock(bar,Dock.Top);root.Children.Add(bar);tables.Width=160;bar.Children.Add(tables);
        SektorArayuz.B(bar,"Masaya adisyon aç",()=>{db.Ac(openKey,(int)SektorArayuz.Id(tables));openKey=Guid.NewGuid();Yukle();});SektorArayuz.B(bar,"Yenile",Yukle);
        SektorArayuz.B(bar,"Adisyon yazdır / PDF",Yazdir);
        var action=new StackPanel{Margin=new Thickness(10,0,8,0)};var actionScroll=new ScrollViewer{Width=360,Content=action,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};DockPanel.SetDock(actionScroll,Dock.Right);root.Children.Add(actionScroll);action.Children.Add(summary);
        SektorArayuz.Alan(action,"Menü ürünü",menu);SektorArayuz.Alan(action,"Miktar",quantity);SektorArayuz.B(action,"Seçili adisyona ekle",()=>{db.KalemEkle(itemKey,Bill,Version,(int)SektorArayuz.Id(menu),SektorArayuz.N(quantity.Text));itemKey=Guid.NewGuid();Yukle();});
        SektorArayuz.B(action,"Seçili yeni kalemi iptal et",()=>{if(lines.SelectedItem is not DataRowView line)throw new ArgumentException("Alt tablodan kalemi seçin.");db.KalemIptal(Bill,Version,(long)line["Id"]);Yukle();});
        SektorArayuz.B(action,"Yeni kalemleri mutfağa gönder",()=>{db.Mutfak(Bill,Version,false);Yukle();});SektorArayuz.B(action,"Hazırlananları hazır işaretle",()=>{db.Mutfak(Bill,Version,true);Yukle();});
        SektorArayuz.Alan(action,"TRY kasa / banka hesabı",account);SektorArayuz.Alan(action,"Ödeme yöntemi",method);SektorArayuz.Alan(action,"Ödeme tutarı (TRY)",amount);SektorArayuz.Alan(action,"Ödeme belge / POS referansı",receipt);
        SektorArayuz.B(action,"Ödemeyi kaydet",()=>{db.Odeme(payKey,Bill,Version,(int)SektorArayuz.Id(account),SektorArayuz.N(amount.Text,2),(string)method.SelectedItem,receipt.Text);payKey=Guid.NewGuid();amount.Clear();receipt.Clear();Yukle();});
        SektorArayuz.Alan(action,"İptal / tüm ödemeleri iade nedeni",reason);SektorArayuz.B(action,"Adisyonu iptal et / ücretleri iade kaydet",()=>{if(MessageBox.Show("Tüm ödemeler için finans ters kaydı yazılacak. Banka/POS işlemini ayrıca yapmalısınız. Hazırlanan yemeğin hammaddeleri stoka geri eklenmez. Devam edilsin mi?","Adisyon iptal / iade",MessageBoxButton.YesNo)!=MessageBoxResult.Yes)return;db.IptalVeyaIade(Bill,Version,reason.Text);reason.Clear();Yukle();});
        action.Children.Add(new TextBlock{Text="Fiyatlar KDV dahil girilir. Stok tüketimi adisyonun son ödemesinde, tahsilatla aynı işlem içinde yapılır. Kart/Havale seçimi harici ödemenin kaydıdır; bu ekran bankadan para çekmez. Ücret iadesi stok iadesi oluşturmaz.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(4,18,4,4),FontSize=11});
        var left=new Grid();left.RowDefinitions.Add(new(){Height=new GridLength(2,GridUnitType.Star)});left.RowDefinitions.Add(new(){Height=new GridLength(1,GridUnitType.Star)});left.Children.Add(bills);Grid.SetRow(lines,1);left.Children.Add(lines);root.Children.Add(left);SektorArayuz.Tab(tabs,"Masa ve adisyon",root);
        bills.AutoGeneratingColumn+=(_,e)=>{if(e.PropertyName=="Surum")e.Cancel=true;};bills.SelectionChanged+=(_,_)=>Detay();
        SektorArayuz.Tab(tabs,"Mutfak sırası",kitchen);SektorArayuz.Tab(tabs,"Seçili adisyon ödemeleri",payments);
        var settings=new StackPanel{MaxWidth=700};SektorArayuz.Alan(settings,"Yeni masa adı",tableName);SektorArayuz.B(settings,"Masayı ekle",()=>{db.MasaKaydet(tableName.Text);tableName.Clear();Yukle();});
        SektorArayuz.Alan(settings,"Düzenlenecek menü (yeni kayıt için boş bırakın)",editMenu);editMenu.SelectionChanged+=(_,_)=>{if(editMenu.SelectedItem is not DataRowView r)return;editingMenu=(int)r["Id"];menuVersion=(byte[])r["Surum"];menuName.Text=(string)r["Ad"];product.SelectedValue=r["MamulId"];recipe.SelectedValue=r["ReceteId"] is DBNull?null:r["ReceteId"];price.Text=((decimal)r["BirimFiyat"]).ToString("0.00");};
        SektorArayuz.Alan(settings,"Menü adı",menuName);SektorArayuz.Alan(settings,"Satılan / çıktı stok kartı",product);SektorArayuz.Alan(settings,"Reçete (isteğe bağlı; seçilmezse stok kartından doğrudan düşer)",recipe);SektorArayuz.Alan(settings,"KDV dahil birim fiyat (TRY)",price);
        SektorArayuz.B(settings,"Menü ürününü kaydet",()=>{db.MenuKaydet(menuName.Text,(int)SektorArayuz.Id(product),recipe.SelectedValue is null?null:SektorArayuz.Id(recipe),SektorArayuz.N(price.Text,2),editingMenu,menuVersion);menuName.Clear();price.Clear();Yukle();});SektorArayuz.B(settings,"Yeni menü kartı",()=>{editingMenu=null;menuVersion=null;editMenu.SelectedIndex=-1;menuName.Clear();price.Clear();});SektorArayuz.B(settings,"Reçete seçimini temizle",()=>recipe.SelectedIndex=-1);
        SektorArayuz.Tab(tabs,"Masa / Menü tanımları",new ScrollViewer{Content=settings,VerticalScrollBarVisibility=ScrollBarVisibility.Auto});Yukle();
    }
    void Yukle()
    {
        long? selected=(bills.SelectedItem as DataRowView)?["Id"] as long?;var data=db.Oku("adisyon");bills.ItemsSource=data.DefaultView;
        if(selected.HasValue)bills.SelectedItem=data.DefaultView.Cast<DataRowView>().FirstOrDefault(r=>(long)r["Id"]==selected);
        SektorArayuz.Combo(tables,db.Oku("masa"));SektorArayuz.Combo(menu,db.Oku("menu"));SektorArayuz.Combo(editMenu,db.Oku("menu"));editingMenu=null;menuVersion=null;SektorArayuz.Combo(account,db.Oku("hesap"),"HesapAdi");
        try{SektorArayuz.Combo(product,production.Oku("stok"),"Secim");SektorArayuz.Combo(recipe,production.Oku("recete"));}catch(UnauthorizedAccessException){product.ItemsSource=recipe.ItemsSource=null;}
        kitchen.ItemsSource=db.Oku("mutfak").DefaultView;Detay();
    }
    void Yazdir()
    {
        var row=Sec();long id=(long)row["Id"];var items=db.Oku("kalem",id);var paid=db.Oku("odeme",id);
        var doc=new System.Windows.Documents.FlowDocument{PageWidth=793,ColumnWidth=700,PagePadding=new Thickness(36),FontFamily=new FontFamily("Segoe UI"),FontSize=12,Foreground=Brushes.Black,Background=Brushes.White};
        void P(string text,bool title=false)=>doc.Blocks.Add(new System.Windows.Documents.Paragraph(new System.Windows.Documents.Run(text)){FontSize=title?21:12,Margin=new Thickness(0,5,0,5)});
        P(Tema170.Mevcut.FirmaBasligi=="BoruERP"?LisansOturumu.Gecerli?.Company??"Miapax ERP":Tema170.Mevcut.FirmaBasligi,true);P("Adisyon #"+id+" · "+row["Masa"],true);P("Durum: "+row["Durum"]+" · "+DateTime.Now.ToString("dd.MM.yyyy HH:mm"));
        decimal total=0;
        foreach(DataRow item in items.Rows)
        {if((bool)item["Iptal"])continue;decimal n=(decimal)item["Toplam"];total+=n;P($"{item["Ad"]} · {item["Miktar"]:0.###} × {item["BirimFiyat"]:N2} = {n:N2} TRY");}
        decimal received=paid.AsEnumerable().Where(p=>p["IadeFinansId"]is DBNull).Sum(p=>(decimal)p["Tutar"]);
        P($"Toplam: {total:N2} TRY · Net ödeme: {received:N2} TRY",true);P($"Kalan: {((string)row["Durum"]=="İptal"?0:total-received):N2} TRY");P("Bilgi amaçlı adisyon dökümü. Resmî fatura veya mali fiş değildir.");
        var preview=new Window{Title="Adisyon önizleme / Yazdır / PDF",Owner=this,Width=850,Height=720};var root=new DockPanel();var bar=new WrapPanel();DockPanel.SetDock(bar,Dock.Top);root.Children.Add(bar);root.Children.Add(new FlowDocumentScrollViewer{Document=doc});
        SektorArayuz.B(bar,"Yazıcı seç / Microsoft Print to PDF",()=>{var dialog=new PrintDialog();if(dialog.ShowDialog()==true){doc.PageWidth=dialog.PrintableAreaWidth;doc.PageHeight=dialog.PrintableAreaHeight;dialog.PrintDocument(((System.Windows.Documents.IDocumentPaginatorSource)doc).DocumentPaginator,"MiapaxERP Adisyon "+id);}});preview.Content=root;preview.ShowDialog();
    }
    void Detay()
    {
        if(bills.SelectedItem is not DataRowView row){lines.ItemsSource=payments.ItemsSource=null;summary.Text="Adisyon seçin.";return;}
        long id=(long)row["Id"];summary.Text=$"Adisyon #{id} • {row["Masa"]}\nToplam: {row["Toplam"]:N2} TRY • Ödenen: {row["Odenen"]:N2}\nKalan: {row["Kalan"]:N2} TRY";lines.ItemsSource=db.Oku("kalem",id).DefaultView;payments.ItemsSource=db.Oku("odeme",id).DefaultView;
    }
}
public partial class MainWindow
{
    void SektorUretimAc_Click(object sender,RoutedEventArgs e)
    {if(aktifKullanici is null){MessageBox.Show("Önce oturum açın.");return;}try{new SektorUretimPenceresi(baglantiAdresi,aktifKullanici.KullaniciId,LisansOturumu.Gecerli?.Sector??gorunum.Sektor){Owner=this}.ShowDialog();}catch(Exception ex){DestekIzleme.Bildir(ex,"SektorPencereleri");MessageBox.Show(ex.Message,"Sektör üretimi");}}
    void RestoranAc_Click(object sender,RoutedEventArgs e)
    {if(aktifKullanici is null){MessageBox.Show("Önce oturum açın.");return;}try{new RestoranPenceresi(baglantiAdresi,aktifKullanici.KullaniciId){Owner=this}.ShowDialog();}catch(Exception ex){DestekIzleme.Bildir(ex,"SektorPencereleri");MessageBox.Show(ex.Message,"Restoran");}}
}
