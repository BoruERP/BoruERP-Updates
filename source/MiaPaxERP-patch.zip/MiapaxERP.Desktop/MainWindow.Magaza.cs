using SqlConnection = MiapaxERP.Desktop.ErpSqlConnection;
using SqlCommand = MiapaxERP.Desktop.ErpSqlCommand;
using SqlTransaction = MiapaxERP.Desktop.ErpSqlTransaction;
using SqlDataReader = MiapaxERP.Desktop.ErpSqlReader;
using SqlDataAdapter = MiapaxERP.Desktop.ErpSqlDataAdapter;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Net.Http;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

public sealed record PortalAyari(string PanelAdresi="",string LisansAdresi="");
public static class PortalBaglantisi
{
    static string Dosya=>Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"MiapaxERP","Portal","baglanti.json");
    public static Uri Adres(string value,bool yerel=false)
    {
        if(!Uri.TryCreate(value,UriKind.Absolute,out var u)||!string.IsNullOrEmpty(u.UserInfo)||!string.IsNullOrEmpty(u.Query)||!string.IsNullOrEmpty(u.Fragment)||u.AbsolutePath!="/"||u.Scheme!="https"&&!(yerel&&u.Scheme=="http"&&u.IsLoopback))throw new ArgumentException("HTTPS kök adresi girin (örnek: https://panel.firmaniz.com). Yerel panel için http://127.0.0.1:5290 kullanılabilir.");
        return u;
    }
    public static PortalAyari Oku()
    {
        if(!File.Exists(Dosya))return new();
        var a=JsonSerializer.Deserialize<PortalAyari>(File.ReadAllText(Dosya))??throw new InvalidDataException("Panel bağlantı ayarı okunamadı.");
        if(a.PanelAdresi.Length>0)Adres(a.PanelAdresi,true);if(a.LisansAdresi.Length>0)Adres(a.LisansAdresi);return a;
    }
    public static void Kaydet(PortalAyari a)
    {
        if(a.PanelAdresi.Length>0)Adres(a.PanelAdresi,true);if(a.LisansAdresi.Length>0)Adres(a.LisansAdresi);
        Directory.CreateDirectory(Path.GetDirectoryName(Dosya)!);File.WriteAllText(Dosya+".tmp",JsonSerializer.Serialize(a));File.Move(Dosya+".tmp",Dosya,true);
    }
    public static string LisansSunucusu=>Oku().LisansAdresi is {Length:>0} s?s.TrimEnd('/'):LisansOturumu.VarsayilanSunucu;
}
public partial class MainWindow
{
    void MagazaAc_Click(object sender,RoutedEventArgs e)
    {
        if(aktifKullanici is null){MessageBox.Show("Önce oturum açın.");return;}
        bool Admin()
        {
            if(DemoModu||aktifKullanici is null)return false;
            using var c=new SqlConnection(baglantiAdresi);c.Open();using var q=new SqlCommand("SELECT COUNT(*) FROM dbo.Kullanicilar k JOIN dbo.KullaniciRolAtamalari a ON a.KullaniciId=k.Id JOIN dbo.KullaniciRolleri r ON r.Id=a.RolId WHERE k.Id=@id AND k.Aktif=1 AND r.Aktif=1 AND r.RolAdi=N'Yönetici'",c);q.Parameters.AddWithValue("@id",aktifKullanici.KullaniciId);return Convert.ToInt32(q.ExecuteScalar())>0;
        }
        try{new ModulMagazasi(Admin){Owner=this}.ShowDialog();}catch(Exception ex){DestekIzleme.Bildir(ex,"MainWindow.Magaza");MessageBox.Show(ex.Message,"Mağaza");}
    }
}
public sealed class ModulMagazasi:Window
{
    readonly StackPanel cards=new(),root=new(){Margin=new Thickness(28)};
    readonly TextBlock status=new(){TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,12,0,14)};
    readonly ComboBox categories=new(){MinHeight=34,MinWidth=230,DisplayMemberPath="Name",SelectedValuePath="Id"};
    readonly Func<bool> admin;JsonElement[] products=[];PortalAyari ayar;
    public ModulMagazasi(Func<bool> admin)
    {
        this.admin=admin;ayar=PortalBaglantisi.Oku();Title="MiapaxERP | Modül Mağazası · 2.3 ön sürüm";Width=980;Height=760;WindowStartupLocation=WindowStartupLocation.CenterOwner;Background=Brushes.WhiteSmoke;Content=new ScrollViewer{Content=root,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};
        root.Children.Add(new TextBlock{Text="Modül Mağazası",FontSize=28,FontWeight=FontWeights.Bold});
        root.Children.Add(new TextBlock{Text="Üretim, muhasebe ve diğer çalışma ekranlarınız kendi menülerinde kalır. Modül paketlerinin kategorilerini, fiyatlarını ve satın alma bağlantılarını burada bulabilirsiniz.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,10,0,16)});
        var bar=new WrapPanel();root.Children.Add(bar);bar.Children.Add(categories);categories.SelectionChanged+=(_,_)=>Listele();
        void Button(string text,Action work){var b=new Button{Content=text,Padding=new Thickness(12,8,12,8),Margin=new Thickness(8,0,0,0)};bar.Children.Add(b);b.Click+=(_,_)=>{try{work();}catch(Exception ex){status.Text=ex.Message;}};}
        Button("Paketleri yenile",()=>_ = Yukle());Button("Bayi / yönetim paneli",PanelAc);Button("Panel bağlantı ayarları",Ayarlar);
        root.Children.Add(status);root.Children.Add(cards);Loaded+=async(_,_)=>await Yukle();
    }
    async Task Yukle()
    {
        try
        {
            ayar=PortalBaglantisi.Oku();cards.Children.Clear();if(string.IsNullOrEmpty(ayar.PanelAdresi)){status.Text="Bağımsız panel adresi henüz tanımlanmadı. Sunucu kurulduktan sonra yönetici, Panel bağlantı ayarları bölümüne HTTPS adresini girebilir. Satış fiyatları panelde tanımlanır.";return;}
            status.Text="Paketler yükleniyor…";using var http=new HttpClient(new HttpClientHandler{AllowAutoRedirect=false}){Timeout=TimeSpan.FromSeconds(15),MaxResponseContentBufferSize=2*1024*1024};
            using var response=await http.GetAsync(new Uri(PortalBaglantisi.Adres(ayar.PanelAdresi,true),"api/catalog"));response.EnsureSuccessStatusCode();
            using var doc=JsonDocument.Parse(await response.Content.ReadAsStringAsync());products=doc.RootElement.GetProperty("products").EnumerateArray().Select(x=>x.Clone()).ToArray();
            var list=new List<MagazaKategori>{new("","Tüm paketler")};list.AddRange(doc.RootElement.GetProperty("categories").EnumerateArray().Select(c=>new MagazaKategori(c.GetProperty("id").GetString()!,c.GetProperty("name").GetString()!)));categories.ItemsSource=list;categories.SelectedIndex=0;Listele();status.Text="Perakende fiyatlar gösterilir. Bayi alış fiyatları ve lisans hakları, bayinin kendi hesabıyla panelde görüntülenir. Satın alma ödeme altyapısının etkinliğine bağlıdır.";
        }
        catch(Exception ex){status.Text="Mağazaya bağlanılamadı: "+ex.Message;cards.Children.Clear();}
    }
    void Listele()
    {
        cards.Children.Clear();var selected=categories.SelectedValue as string??"";
        foreach(var p in products.Where(p=>selected==""||p.GetProperty("category_id").GetString()==selected))
        {
            var box=new StackPanel{Margin=new Thickness(18)};box.Children.Add(new TextBlock{Text=p.GetProperty("name").GetString(),FontSize=21,FontWeight=FontWeights.SemiBold});
            foreach(var value in new[]{p.GetProperty("description").GetString(),string.Join(" · ",p.GetProperty("modules").GetString() is {} m?JsonSerializer.Deserialize<string[]>(m)??[]:[]),(p.GetProperty("retail_kurus").GetInt64()/100m).ToString("C2",CultureInfo.GetCultureInfo("tr-TR")),p.GetProperty("tax_note").GetString(),p.GetProperty("term_days").ValueKind==JsonValueKind.Null?"Süresiz":p.GetProperty("term_days").GetInt32()+" gün"})box.Children.Add(new TextBlock{Text=value,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,8,0,0)});
            var buy=new Button{Content="Panelde görüntüle",HorizontalAlignment=System.Windows.HorizontalAlignment.Left,Padding=new Thickness(12,8,12,8),Margin=new Thickness(0,12,0,0)};buy.Click+=(_,_)=>{try{PanelAc();}catch(Exception ex){status.Text=ex.Message;}};box.Children.Add(buy);cards.Children.Add(new Border{Child=box,Background=Brushes.White,BorderBrush=Brushes.LightGray,BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(10),Margin=new Thickness(0,0,0,14)});
        }
        if(cards.Children.Count==0)cards.Children.Add(new TextBlock{Text="Bu kategoride satışa açılmış paket bulunmuyor.",Margin=new Thickness(0,18,0,0)});
    }
    void PanelAc(){if(string.IsNullOrEmpty(ayar.PanelAdresi))throw new InvalidOperationException("Önce panel bağlantısını tanımlayın.");Process.Start(new ProcessStartInfo(PortalBaglantisi.Adres(ayar.PanelAdresi,true).ToString()){UseShellExecute=true});}
    void Ayarlar()
    {
        if(!admin())throw new UnauthorizedAccessException("Panel adresini yalnız ERP yöneticisi değiştirebilir.");
        var w=new Window{Title="Bağımsız panel bağlantısı",Owner=this,Width=620,Height=450,WindowStartupLocation=WindowStartupLocation.CenterOwner};var p=new StackPanel{Margin=new Thickness(24)};w.Content=p;
        p.Children.Add(new TextBlock{Text="Mağaza / bayi paneli kök adresi"});var panel=new TextBox{Text=ayar.PanelAdresi,Margin=new Thickness(0,8,0,16)};p.Children.Add(panel);
        p.Children.Add(new TextBlock{Text="Lisans doğrulama kök adresi · boş = mevcut canlı servis"});var license=new TextBox{Text=ayar.LisansAdresi,Margin=new Thickness(0,8,0,16)};p.Children.Add(license);
        p.Children.Add(new TextBlock{Text="Lisans adresini ancak mevcut müşteri, lisans, cihaz kayıtları ve aynı imza anahtarı yeni sunucuya taşındıktan sonra değiştirin. Yanlış adres lisans doğrulamasını engeller. Bu ayar veritabanını değiştirmez.",TextWrapping=TextWrapping.Wrap});var result=new TextBlock{TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,10,0,10)};p.Children.Add(result);
        var save=new Button{Content="Bağlantıları kaydet",Padding=new Thickness(12)};p.Children.Add(save);save.Click+=async(_,_)=>{try{if(!admin())throw new UnauthorizedAccessException("Yönetici oturumunu doğrulayın.");PortalBaglantisi.Kaydet(new(panel.Text.Trim(),license.Text.Trim()));w.Close();await Yukle();}catch(Exception ex){result.Text=ex.Message;}};w.ShowDialog();
    }
    public sealed record MagazaKategori(string Id,string Name);
}
