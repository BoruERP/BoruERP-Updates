using System.Windows;
using System.Windows.Controls;

namespace MiapaxERP.Desktop;

public partial class TicariModullerPaneli
{
    private void OncekiSurum_Click(object sender,RoutedEventArgs e)
    {
        try {
            if(MessageBox.Show("Önceki uygulama sürümü geri yüklenecek. Güncel veritabanı korunur. Açık işlerinizi kaydedin. Devam edilsin mi?","MiapaxERP",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)return;
            MiapaxERPGuncelleme.GeriDonusuHazirla();
            MessageBox.Show("Geri dönüş hazırlandı. Programı kapattığınızda uygulanacak. Sonucu güncelleme günlüğünden kontrol edebilirsiniz.");
        }catch(Exception ex){DestekIzleme.Bildir(ex,"TicariModullerPenceresi.Guncelleme");MessageBox.Show(ex.Message,"MiapaxERP");}
    }
    private async void ProgramiGuncelle_Click(object sender, RoutedEventArgs e)
    {
        var button = (Button)sender;
        button.IsEnabled = false;
        try
        {
            await MiapaxERPGuncelleme.KontrolEtAsync(true);
            MessageBox.Show(MiapaxERPGuncelleme.SonDurum, "MiapaxERP Güncelleme", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        finally { button.IsEnabled = true; }
    }
}

