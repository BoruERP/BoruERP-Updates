using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Web.WebView2.Wpf;
using Microsoft.Web.WebView2.Core;

namespace MiapaxERP.Desktop;
public partial class KrokiYonetimi
{
    private WebView2? web;
    private bool webBasladi;
    private void GelismisKrokiyiBagla()
    {
        var eski=Content;Content=null;
        var sekmeler=new System.Windows.Controls.TabControl();var gelismis=new TabItem{Header="Otomatik plan • Harita • 3D"};
        sekmeler.Items.Add(gelismis);sekmeler.Items.Add(new TabItem{Header="Basit elle çizim",Content=eski});Content=sekmeler;
        web=new WebView2();gelismis.Content=web;
        Loaded+=async (_,_)=>{
            if(webBasladi)return;webBasladi=true;
            try{
                var profile=krokiProfil??Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"BoruERP","KrokiTarayici");
                var env=await CoreWebView2Environment.CreateAsync(null,profile);
                await web.EnsureCoreWebView2Async(env);
                web.CoreWebView2.SetVirtualHostNameToFolderMapping("kroki.boruerp.local",Path.Combine(AppContext.BaseDirectory,"Assets","KrokiWeb"),CoreWebView2HostResourceAccessKind.DenyCors);
                web.CoreWebView2.Settings.AreDevToolsEnabled=false;
                web.CoreWebView2.NavigationStarting+=(_,e)=>{if(!Yerel(e.Uri))e.Cancel=true;};
                web.CoreWebView2.NewWindowRequested+=(_,e)=>{e.Handled=true;};
                web.CoreWebView2.WebMessageReceived+=async (_,e)=>{
                    if(!Yerel(e.Source))return;
                    try{
                        using var msg=JsonDocument.Parse(e.WebMessageAsJson);var root=msg.RootElement;
                        switch(root.GetProperty("action").GetString()){
                            case "map":MessageBox.Show("Harici tarayıcı yerine program içindeki haritayı kullanın.","Kroki");break;
                            case "parcelSettings":ParselServisi.Ayarlar(Window.GetWindow(this));break;
                            case "parcelQuery":
                                try{var geometry=await ParselServisi.Sorgula(root.GetProperty("fields"));web.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new{action="parcelResult",geometry}));}
                                catch(Exception ex){web.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new{action="parcelResult",error=ex.Message}));}break;
                            case "ready":
                                string logo=Tema170.Mevcut.Logo;
                                if(File.Exists(logo) && !GorunumDeposu.EskiUygulamaLogosu(logo)){var image=GorunumDeposu.Resim(logo);var png=new System.Windows.Media.Imaging.PngBitmapEncoder();png.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(image));using var stream=new MemoryStream();png.Save(stream);web.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new{action="logo",url="data:image/png;base64,"+Convert.ToBase64String(stream.ToArray())}));}
                                break;
                            case "pdf":
                                var save=new SaveFileDialog{Filter="PDF belgesi|*.pdf",FileName="MiapaxERP-Sulama-Plani.pdf"};
                                if(save.ShowDialog(Window.GetWindow(this))==true){var settings=env.CreatePrintSettings();settings.PageWidth=8.2677;settings.PageHeight=11.6929;settings.MarginTop=.47;settings.MarginBottom=.47;settings.MarginLeft=.47;settings.MarginRight=.47;settings.ShouldPrintBackgrounds=true;settings.ShouldPrintHeaderAndFooter=false;if(!await web.CoreWebView2.PrintToPdfAsync(save.FileName,settings))throw new IOException("PDF oluşturulamadı.");}
                                await web.ExecuteScriptAsync("document.body.classList.remove('fp-printing')");break;
                        }
                    }catch(Exception ex){DestekIzleme.Bildir(ex,"KrokiYonetimi.Web");MessageBox.Show(Window.GetWindow(this),ex.Message,"Kroki işlemi tamamlanamadı");await web.ExecuteScriptAsync("document.body.classList.remove('fp-printing')");}
                };
                web.Source=new Uri("https://kroki.boruerp.local/index.html?v=2.8.1");
                if(Window.GetWindow(this) is Window owner)owner.Closed+=(_,_)=>web.Dispose();
            }catch(Exception ex){gelismis.Content=new TextBlock{Text="Gelişmiş kroki açılamadı. Microsoft Edge WebView2 Runtime kurulu olmalı. Basit elle çizim sekmesini kullanabilirsiniz.\n"+ex.Message,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(24)};}
        };
    }
    private static bool Yerel(string value)=>Uri.TryCreate(value,UriKind.Absolute,out var uri)&&uri.Scheme=="https"&&uri.Host=="kroki.boruerp.local";
    private static void HaritaAc(string value)
    {
        if(!Uri.TryCreate(value,UriKind.Absolute,out var uri)||uri.Scheme!="https"||!new[]{"parselsorgu.tkgm.gov.tr","www.google.com","earth.google.com","www.openstreetmap.org","openstreetmap.org"}.Contains(uri.Host))return;
        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(uri.AbsoluteUri){UseShellExecute=true});
    }
}


