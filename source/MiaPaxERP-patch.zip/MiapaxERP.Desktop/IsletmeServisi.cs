using System.Data;
using System.IO;
using System.Security.Cryptography;
using System.Text.Json;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

public sealed partial class IsletmeServisi(string connection,int user)
{
    readonly ErpModulServisi access=new(connection,user);
    readonly Action<SqlConnection,SqlTransaction?,string>? fixtureCheck;
    internal IsletmeServisi(string connection,int user,Action<SqlConnection,SqlTransaction?,string> fixtureCheck):this(connection,user){this.fixtureCheck=fixtureCheck;}
    static SqlCommand Q(SqlConnection c,SqlTransaction? t,string sql,params(string,object?)[] ps)
    {var q=ErpModulServisi.Komut(c,t,sql,ps);foreach(SqlParameter p in q.Parameters)if(p.SqlDbType==SqlDbType.Decimal){p.Precision=28;p.Scale=8;}return q;}
    static DataTable Table(SqlCommand q){using(q)using(var r=q.ExecuteReader()){var table=new DataTable();table.Load(r);return table;}}
    void Yetki(SqlConnection c,SqlTransaction? t,string code){if(fixtureCheck is not null)fixtureCheck(c,t,code);else access.Yetki(c,t,code);}
    static string Json<T>(T value)=>JsonSerializer.Serialize(value,HttpsJson.Ayarlar);
    static T Veri<T>(string json)=>JsonSerializer.Deserialize<T>(json,HttpsJson.Ayarlar)??throw new InvalidDataException("Kayıt okunamadı.");
    static void Text(string? value,int min,int max,string name){if(value is null||value.Trim().Length<min||value.Length>max)throw new ArgumentException(name+" alanını kontrol edin.");}
    internal static void Quantity(decimal value){if(value<=0||value>999999999999999.999m||decimal.Round(value,3)!=value)throw new ArgumentException("Miktar pozitif ve en fazla üç ondalıklı olmalı.");}
    internal static decimal Money(decimal value){if(value<0||value>9999999999999999.99m||decimal.Round(value,2)!=value)throw new ArgumentException("Tutar negatif olamaz ve en fazla iki ondalıklı olmalı.");return value;}
    static string Hash(string json)=>Convert.ToHexString(SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(json)));
    void Event(SqlConnection c,SqlTransaction t,long? id,string action,string text){using var q=Q(c,t,"INSERT dbo.MPX310_Olay(KayitId,Tur,Aciklama,Kullanici) VALUES(@id,@a,@v,@u)",("@id",id),("@a",action),("@v",text.Length>2000?text[..2000]:text),("@u",user));q.ExecuteNonQuery();}
    static string ViewPermission(string kind)=>kind switch{"Sevkiyat"=>"SHIPMENT.VIEW","BasincTest"=>"PRESSURE.VIEW","SatinAlma" or "MalKabul" or "AlisFatura"=>"PURCHASE.VIEW","Makine" or "Kapasite"=>"PRODUCTION.CAPACITY","UretimMaliyet"=>"PRODUCTION.COST",_=>throw new ArgumentException("Bölüm bulunamadı.")};
    DataRow Read(SqlConnection c,SqlTransaction? t,long id,string kind,bool locked=false)
    {
        var dt=Table(Q(c,t,"SELECT * FROM dbo.MPX310_Kayit "+(locked?"WITH(UPDLOCK,HOLDLOCK) ":"")+"WHERE Id=@id AND Tur=@tur",("@id",id),("@tur",kind)));
        return dt.Rows.Count==1?dt.Rows[0]:throw new ArgumentException("Kayıt bulunamadı.");
    }
    static void Version(DataRow row,byte[]? value){if(value is null||value.Length!=8||!((byte[])row["Surum"]).AsSpan().SequenceEqual(value))throw new InvalidOperationException("Kayıt başka kullanıcı tarafından değişti. Listeyi yenileyin.");}
    long Create<T>(SqlConnection c,SqlTransaction t,string kind,Guid key,T value,string state="Taslak",long? parent=null)
    {
        if(key==Guid.Empty)throw new ArgumentException("İşlem kimliği gerekli.");string json=Json(value),hash=Hash(json);
        using(var old=Q(c,t,"SELECT Id,Tur,Ozet FROM dbo.MPX310_Kayit WITH(UPDLOCK,HOLDLOCK) WHERE Anahtar=@k",("@k",key)))
        {using var r=old.ExecuteReader();if(r.Read()){if(r.GetString(1)!=kind||r.GetString(2)!=hash)throw new ArgumentException("İşlem kimliği başka kayıtta kullanılmış.");return r.GetInt64(0);}}
        using var q=Q(c,t,"INSERT dbo.MPX310_Kayit(Anahtar,Tur,ParentId,Veri,Ozet,Durum,Olusturan,Guncelleyen) OUTPUT INSERTED.Id VALUES(@k,@tur,@p,@v,@h,@s,@u,@u)",("@k",key),("@tur",kind),("@p",parent),("@v",json),("@h",hash),("@s",state),("@u",user));long id=Convert.ToInt64(q.ExecuteScalar());Event(c,t,id,"Oluşturuldu",kind);return id;
    }
    void Update<T>(SqlConnection c,SqlTransaction t,long id,string kind,byte[] version,T value)
    {
        string json=Json(value);using var q=Q(c,t,"UPDATE dbo.MPX310_Kayit SET Veri=@v,Ozet=@h,Guncelleyen=@u,Guncelleme=SYSDATETIMEOFFSET() WHERE Id=@id AND Tur=@tur AND Durum=N'Taslak' AND Surum=@s",("@v",json),("@h",Hash(json)),("@u",user),("@id",id),("@tur",kind),("@s",version));if(q.ExecuteNonQuery()!=1)throw new InvalidOperationException("Kayıt değişti veya artık düzenlenemez.");Event(c,t,id,"Düzenlendi",kind);
    }
    void State(SqlConnection c,SqlTransaction t,long id,string current,string next,string reason)
    {
        using var q=Q(c,t,"UPDATE dbo.MPX310_Kayit SET Durum=@n,Guncelleyen=@u,Guncelleme=SYSDATETIMEOFFSET() WHERE Id=@id AND Durum=@o",("@n",next),("@u",user),("@id",id),("@o",current));if(q.ExecuteNonQuery()!=1)throw new InvalidOperationException("Kayıt durumu değişti. Yenileyin.");Event(c,t,id,current+" → "+next,reason);
    }
    public void Kur()
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"IsletmeServisi.Kur","",new object?[]{});return;}

        using var c=access.Ac();Yetki(c,null,"MODULES.INSTALL");using var q=Q(c,null,File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"Isletme310.sql")));q.CommandTimeout=120;q.ExecuteNonQuery();
    }
    public DataTable Liste(string kind)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"IsletmeServisi.Liste","",new object?[]{kind});}

        string permission=ViewPermission(kind);using var c=access.Ac();Yetki(c,null,permission);
        if(kind=="SatinAlma")return Table(Q(c,null,"SELECT TOP(500) k.Id,JSON_VALUE(k.Veri,'$.no') BelgeNo,c.Unvan Tedarikci,JSON_VALUE(k.Veri,'$.tarih') SiparisTarihi,JSON_VALUE(k.Veri,'$.termin') Termin,JSON_VALUE(k.Veri,'$.para') Doviz,k.Durum,k.Surum FROM dbo.MPX310_Kayit k LEFT JOIN dbo.CariKartlari c ON c.Id=TRY_CONVERT(int,JSON_VALUE(k.Veri,'$.cari')) WHERE k.Tur='SatinAlma' ORDER BY k.Id DESC"));
        if(kind=="Sevkiyat")return Table(Q(c,null,"SELECT TOP(500) k.Id,JSON_VALUE(k.Veri,'$.no') SevkiyatNo,c.Unvan Musteri,JSON_VALUE(k.Veri,'$.nereden') Nereden,JSON_VALUE(k.Veri,'$.nereye') Nereye,JSON_VALUE(k.Veri,'$.tarih') Tarih,JSON_VALUE(k.Veri,'$.tasima') Tasima,JSON_VALUE(k.Veri,'$.plaka') Plaka,JSON_VALUE(k.Veri,'$.sofor') Sofor,JSON_VALUE(k.Veri,'$.telefon') Telefon,TRY_CONVERT(decimal(18,3),JSON_VALUE(k.Veri,'$.bosKg')) BosKg,TRY_CONVERT(decimal(18,3),JSON_VALUE(k.Veri,'$.doluKg')) DoluKg,TRY_CONVERT(decimal(18,3),JSON_VALUE(k.Veri,'$.doluKg'))-TRY_CONVERT(decimal(18,3),JSON_VALUE(k.Veri,'$.bosKg')) NetKg,k.Durum,k.Surum FROM dbo.MPX310_Kayit k LEFT JOIN dbo.CariKartlari c ON c.Id=TRY_CONVERT(int,JSON_VALUE(k.Veri,'$.cari')) WHERE k.Tur='Sevkiyat' ORDER BY k.Id DESC"));
        if(kind=="BasincTest")return Table(Q(c,null,"SELECT TOP(500) k.Id,JSON_VALUE(k.Veri,'$.no') TestNo,s.StokAdi Urun,l.Kod Parti,JSON_VALUE(k.Veri,'$.yontem') Yontem,JSON_VALUE(k.Veri,'$.standart') Standart,JSON_VALUE(k.Veri,'$.baslangic') Baslangic,JSON_VALUE(k.Veri,'$.bitis') Bitis,JSON_VALUE(k.Veri,'$.sicaklik') Sicaklik,JSON_VALUE(k.Veri,'$.hedefBar') HedefBar,JSON_VALUE(k.Veri,'$.ilkBar') IlkBar,JSON_VALUE(k.Veri,'$.sonBar') SonBar,JSON_VALUE(k.Veri,'$.sizinti') Sizinti,k.Durum,k.Surum FROM dbo.MPX310_Kayit k LEFT JOIN dbo.MPX310_Lot l ON l.Id=TRY_CONVERT(bigint,JSON_VALUE(k.Veri,'$.lot')) LEFT JOIN dbo.StokKartlari s ON s.Id=l.StokId WHERE k.Tur='BasincTest' ORDER BY k.Id DESC"));
        if(kind=="Makine")return Table(Q(c,null,"SELECT Id,JSON_VALUE(Veri,'$.kod') Kod,JSON_VALUE(Veri,'$.ad') Makine,TRY_CONVERT(decimal(18,3),JSON_VALUE(Veri,'$.gunlukDakika')) GunlukDakika,TRY_CONVERT(decimal(18,2),JSON_VALUE(Veri,'$.saatMaliyeti')) MakineSaatTRY,TRY_CONVERT(decimal(18,2),JSON_VALUE(Veri,'$.iscilikSaatMaliyeti')) IscilikSaatTRY,TRY_CONVERT(decimal(18,2),JSON_VALUE(Veri,'$.enerjiSaatMaliyeti')) EnerjiSaatTRY,Surum FROM dbo.MPX310_Kayit WHERE Tur='Makine' ORDER BY Id DESC"));
        if(kind=="Kapasite")return Table(Q(c,null,"SELECT k.Id,JSON_VALUE(m.Veri,'$.ad') Makine,u.UretimEmriNo,JSON_VALUE(k.Veri,'$.baslangic') Baslangic,TRY_CONVERT(decimal(18,3),JSON_VALUE(k.Veri,'$.miktar')) Miktar,TRY_CONVERT(decimal(18,3),JSON_VALUE(k.Veri,'$.hazirlikDakika')) HazirlikDakika,TRY_CONVERT(decimal(18,3),JSON_VALUE(k.Veri,'$.birimDakika')) BirimDakika,JSON_VALUE(k.Veri,'$.aciklama') Aciklama,k.Durum,k.Surum FROM dbo.MPX310_Kayit k JOIN dbo.MPX310_Kayit m ON m.Id=k.ParentId LEFT JOIN dbo.UretimEmirleri u ON u.Id=TRY_CONVERT(int,JSON_VALUE(k.Veri,'$.uretimEmri')) WHERE k.Tur='Kapasite' ORDER BY k.Id DESC"));
        if(kind=="UretimMaliyet")return Table(Q(c,null,"SELECT k.Id,u.UretimEmriNo,JSON_VALUE(k.Veri,'$.makine.ad') Makine,TRY_CONVERT(decimal(18,3),JSON_VALUE(k.Veri,'$.girdi.calismaDakika')) CalismaDakika,TRY_CONVERT(decimal(28,8),JSON_VALUE(k.Veri,'$.malzeme')) MalzemeTRY,TRY_CONVERT(decimal(28,8),JSON_VALUE(k.Veri,'$.donusum')) DonusumTRY,TRY_CONVERT(decimal(28,8),JSON_VALUE(k.Veri,'$.toplam')) ToplamTRY,TRY_CONVERT(decimal(28,8),JSON_VALUE(k.Veri,'$.birim')) BirimMaliyetTRY,JSON_VALUE(k.Veri,'$.girdi.gerekce') Dayanak,k.Durum,k.Surum FROM dbo.MPX310_Kayit k LEFT JOIN dbo.UretimEmirleri u ON u.Id=TRY_CONVERT(int,JSON_VALUE(k.Veri,'$.girdi.uretimEmri')) WHERE k.Tur='UretimMaliyet' ORDER BY k.Id DESC"));
        return Table(Q(c,null,"SELECT TOP(500) Id,JSON_VALUE(Veri,'$.no') AS BelgeNo,COALESCE(JSON_VALUE(Veri,'$.ad'),JSON_VALUE(Veri,'$.yontem'),JSON_VALUE(Veri,'$.aciklama')) AS Aciklama,JSON_VALUE(Veri,'$.tarih') AS Tarih,Durum,Veri,Olusturan,Olusturma,Guncelleme,Surum FROM dbo.MPX310_Kayit WHERE Tur=@tur ORDER BY Id DESC",("@tur",kind)));
    }
    public DataRow Oku(long id,string kind){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataRow>(connection,"IsletmeServisi.Oku","",new object?[]{id,kind});}
using var c=access.Ac();Yetki(c,null,ViewPermission(kind));return Read(c,null,id,kind);}
    public DataTable Gecmis(long id,string kind){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"IsletmeServisi.Gecmis","",new object?[]{id,kind});}
using var c=access.Ac();Yetki(c,null,ViewPermission(kind));Read(c,null,id,kind);return Table(Q(c,null,"SELECT Zaman,Kullanici,Tur,Aciklama FROM dbo.MPX310_Olay WHERE KayitId=@id ORDER BY Id",("@id",id)));}
    public DataTable Secimler(string kind)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"IsletmeServisi.Secimler","",new object?[]{kind});}

        using var c=access.Ac();string permission=kind switch{"stok"=>"STOCK.VIEW","cari"=>"CUSTOMER.VIEW","hesap"=>"FINANCE.VIEW","raf" or "lot"=>"WAREHOUSE.VIEW","cihaz"=>"LAB.VIEW","makine"=>"PRODUCTION.CAPACITY","emir" or "tamamlananEmir"=>"PRODUCTION.VIEW",_=>throw new ArgumentException("Seçim listesi bulunamadı.")};Yetki(c,null,permission);
        return Table(Q(c,null,kind switch{
            "emir"=>"SELECT Id,UretimEmriNo AS Ad FROM dbo.UretimEmirleri WHERE Durum IN(N'Planlandı',N'Üretimde') ORDER BY Id DESC",
            "tamamlananEmir"=>"SELECT Id,UretimEmriNo AS Ad FROM dbo.UretimEmirleri WHERE Durum=N'Tamamlandı' ORDER BY Id DESC",
            "stok"=>"SELECT Id,StokKodu+N' · '+StokAdi+N' ('+Birim+N')' AS Ad,Birim FROM dbo.StokKartlari WHERE Aktif=1 ORDER BY StokAdi",
            "cari"=>"SELECT Id,CariKodu+N' · '+Unvan AS Ad FROM dbo.CariKartlari WHERE Aktif=1 ORDER BY Unvan",
            "hesap"=>"SELECT Id,HesapAdi+N' ('+ParaBirimi+N')' AS Ad,ParaBirimi FROM dbo.FinansHesaplari WHERE Aktif=1 ORDER BY HesapAdi",
            "raf"=>"SELECT r.Id,d.Ad+N' / '+r.Kod+N' · '+r.Ad AS Ad FROM dbo.MPX310_Raf r JOIN dbo.MPX310_Depo d ON d.Id=r.DepoId WHERE r.Aktif=1 AND d.Aktif=1 ORDER BY d.Ad,r.Kod",
            "lot"=>"SELECT l.Id,l.Kod+N' / '+s.StokKodu+N' · '+s.StokAdi AS Ad,l.StokId,l.Kalite FROM dbo.MPX310_Lot l JOIN dbo.StokKartlari s ON s.Id=l.StokId ORDER BY l.Id DESC",
            "cihaz"=>"SELECT Id,Kod+N' · '+Ad+N' / '+CONVERT(nvarchar(10),Gecerlilik,120) AS Ad FROM dbo.BERP260_LabCihaz ORDER BY Kod",
            _=>"SELECT Id,JSON_VALUE(Veri,'$.kod')+N' · '+JSON_VALUE(Veri,'$.ad') AS Ad FROM dbo.MPX310_Kayit WHERE Tur='Makine' ORDER BY Id DESC"}));
    }
}


