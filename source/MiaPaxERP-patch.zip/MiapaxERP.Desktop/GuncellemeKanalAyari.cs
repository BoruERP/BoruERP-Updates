using System.IO;
namespace MiapaxERP.Guncelleme;

public static class GuncellemeKanalAyari
{
 public const string DosyaAdi="MiapaxERP.guncelleme.json";
 public const string EskiDosyaAdi="BoruERP.guncelleme.json";
 public const string OncekiMarkaDosyasi="MiaSoft.guncelleme.json";
 public static string DosyaYolu(string klasor)
 {
  string yeni=Path.Combine(klasor,DosyaAdi);
  return new[]{DosyaAdi,OncekiMarkaDosyasi,EskiDosyaAdi}.Select(x=>Path.Combine(klasor,x)).FirstOrDefault(File.Exists)??yeni;
 }
 public static bool KorunanDosya(string ad)=>new[]{DosyaAdi,OncekiMarkaDosyasi,EskiDosyaAdi}.Contains(ad,StringComparer.OrdinalIgnoreCase);
 public static string ManifestAdresi(string adres,string kanal)
 {
  if(!Uri.TryCreate(adres,UriKind.Absolute,out var uri)||uri.Scheme!="https"||kanal is not ("Ana" or "Yan"))return adres;
  if(!uri.Host.Equals("raw.githubusercontent.com",StringComparison.OrdinalIgnoreCase))return adres;
  string suffix="/main/manifest-"+kanal.ToLowerInvariant()+".json";
  if(new[]{"/BoruERP/BoruERP-Updates","/MiaSoftERP/MiaSoftERP-Updates"}.Any(prefix=>uri.AbsolutePath.Equals(prefix+suffix,StringComparison.OrdinalIgnoreCase)))
   return "https://raw.githubusercontent.com/MiaPaxERP/MiapaxERP-Updates"+suffix;
  return adres;
 }
}
