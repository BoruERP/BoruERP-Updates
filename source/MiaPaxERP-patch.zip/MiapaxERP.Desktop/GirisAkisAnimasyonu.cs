using System.Diagnostics;
using System.Globalization;
using System.Windows;
using System.Windows.Media;
using System.Windows.Threading;
using Point=System.Windows.Point;
namespace MiapaxERP.Desktop;

// Sessiz, yerel çizim: medya dosyası, ağ isteği veya ses aygıtı gerektirmez.
public sealed class GirisAkisAnimasyonu:FrameworkElement
{
    readonly DispatcherTimer timer=new(){Interval=TimeSpan.FromMilliseconds(50)};
    readonly Stopwatch clock=new();
    internal bool Oynuyor=>timer.IsEnabled;
    double onizleme=-1;
    internal double OnizlemeSaniyesi {get=>onizleme;set{onizleme=value;InvalidateVisual();}}
    public GirisAkisAnimasyonu()
    {
        IsHitTestVisible=false;Focusable=false;ClipToBounds=true;
        timer.Tick+=(_,_)=>InvalidateVisual();Loaded+=(_,_)=>Baslat();Unloaded+=(_,_)=>Durdur();IsVisibleChanged+=(_,_)=>{if(IsVisible&&IsLoaded)Baslat();else Durdur();};
    }
    void Baslat(){if(SystemParameters.ClientAreaAnimation){clock.Start();timer.Start();}}
    void Durdur(){timer.Stop();clock.Stop();}
    protected override void OnRender(DrawingContext d)
    {
        base.OnRender(d);if(ActualWidth<1||ActualHeight<1)return;double t=OnizlemeSaniyesi>=0?OnizlemeSaniyesi:clock.Elapsed.TotalSeconds;
        d.PushTransform(new ScaleTransform(ActualWidth/315,ActualHeight/640));
        var teal=new SolidColorBrush(Color.FromArgb(95,53,210,195));var line=new Pen(new SolidColorBrush(Color.FromArgb(75,116,184,217)),1.3);
        var nodes=new[]{new Point(72,425),new Point(242,425),new Point(242,535),new Point(72,535)};
        for(int i=0;i<4;i++)
        {
            var a=nodes[i];var b=nodes[(i+1)%4];d.DrawLine(line,a,b);double p=(t*.16+i*.25)%1;
            var at=new Point(a.X+(b.X-a.X)*p,a.Y+(b.Y-a.Y)*p);d.DrawEllipse(teal,null,at,7,7);d.DrawEllipse(Brushes.LightCyan,null,at,2.5,2.5);
            d.DrawRoundedRectangle(new SolidColorBrush(Color.FromArgb(225,19,44,66)),new Pen(teal,1),new Rect(a.X-48,a.Y-25,96,50),12,12);
            string label=new[]{"STOK","ÜRETİM","SEVKİYAT","FİNANS"}[i];var text=new FormattedText(label,CultureInfo.GetCultureInfo("tr-TR"),System.Windows.FlowDirection.LeftToRight,new Typeface("Segoe UI"),11,Brushes.LightCyan,VisualTreeHelper.GetDpi(this).PixelsPerDip);
            d.DrawText(text,new Point(a.X-text.Width/2,a.Y-text.Height/2));
        }
        d.DrawEllipse(null,new Pen(new SolidColorBrush(Color.FromArgb(30,49,196,191)),1),new Point(158,480),36+Math.Sin(t*.7)*5,36+Math.Sin(t*.7)*5);
        d.Pop();
    }
}
