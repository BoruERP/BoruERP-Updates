namespace MiapaxERP.Desktop;
public sealed partial class IsletmePaneli
{
    void ConfigureProduction()
    {
        if(kind=="Makine")
        {
        Action("Makine tanımla",async()=>{var f=new IsletmeForm(pencere,"Makine kapasitesi ve saat maliyetleri");f.Text("code","Makine kodu",max:40);f.Text("name","Makine adı",max:160);f.Number("minutes","Günlük kullanılabilir dakika",480);f.Number("machine","Makine saat maliyeti (TRY)");f.Number("labor","İşçilik saat maliyeti (TRY)");f.Number("energy","Enerji saat maliyeti (TRY)");if(f.ShowDialog()!=true)return;var g=new MakineGirdisi(Guid.NewGuid(),null,null,f.S("code"),f.S("name"),f.N("minutes"),f.N("machine"),f.N("labor"),f.N("energy"));await Task.Run(()=>db.MakineKaydet(g));await Saved();});
        Action("Kapasite planla",async()=>{var f=new IsletmeForm(pencere,"Makine kapasite planı");f.Select("machine","Makine",await Task.Run(()=>db.Secimler("makine")));f.Select("order","Üretim emri",await Task.Run(()=>db.Secimler("emir")));f.Text("start","Başlangıç (tarih, saat, saat dilimi)",DateTimeOffset.Now.ToString("dd.MM.yyyy HH:mm zzz"),40);f.Number("setup","Hazırlık süresi (dakika)");f.Number("unit","Bir birim için süre (dakika)",1);f.Number("qty","Planlanacak miktar");f.Text("note","Plan açıklaması");if(f.ShowDialog()!=true)return;var g=new KapasiteGirdisi(Guid.NewGuid(),f.L("machine"),f.I("order"),f.Time("start"),f.N("setup"),f.N("unit"),f.N("qty"),f.S("note"));await Task.Run(()=>db.KapasitePlanla(g));await Saved();});
        Action("Kapasite planlarını göster",()=>KapasiteleriYukle());
        }
        else
        {
        Action("Malzeme ihtiyaç planı",async()=>{var f=new IsletmeForm(pencere,"MRP · malzeme ihtiyaç planı");f.Select("order","Üretim emri",await Task.Run(()=>db.Secimler("emir")));f.Note("Hedef KG ve reçete oranlarından ihtiyaç hesaplanır. Serbest parti miktarı, rezervasyonlar ve açık satın alma siparişleri dikkate alınır.");if(f.ShowDialog()!=true)return;MrpGoster(await Task.Run(()=>db.MalzemeIhtiyaci(f.I("order"))));});
        Action("Fiilî maliyet kesinleştir",async()=>{var f=new IsletmeForm(pencere,"Fiilî üretim maliyeti");f.Select("order","Tamamlanmış üretim emri",await Task.Run(()=>db.Secimler("tamamlananEmir")));f.Select("machine","Makine",await Task.Run(()=>db.Secimler("makine")));f.Number("minutes","Gerçek çalışma süresi (dakika)");f.Number("other","Diğer üretim giderleri (TRY)");f.Text("note","Süre ve gider dayanağı");f.Note("Gerçek tüketilen partilerin maliyeti, çalışma süresi ve tanımlı saat maliyetleri kullanılır. Maliyeti eksik hammadde veya mamul çıkışı varsa kesinleştirme engellenir.");if(f.ShowDialog()!=true)return;var g=new FiiliMaliyetGirdisi(Guid.NewGuid(),f.I("order"),f.L("machine"),f.N("minutes"),f.N("other"),f.S("note"));await Task.Run(()=>db.FiiliMaliyet(g));await Saved();});
        }
    }
}
