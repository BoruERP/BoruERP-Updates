using System.Collections.Concurrent;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.Json;
using Microsoft.Win32;
using Microsoft.Data.SqlClient;
using MiapaxERP.Lisans.Core;
namespace MiapaxERP.Desktop;

public sealed record DestekCihazBilgisi(string Name,string Os,string Cpu,double? RamGb,double? DiskTotalGb,double? DiskFreeGb,string Version);
public sealed record DestekHata(Guid Id,string Code,string Module);
public sealed record DestekRapor(Guid Id,string DeviceId,DestekCihazBilgisi Info,DestekHata[] Events);
public static class DestekIzleme
{
    static readonly ConcurrentDictionary<string,DestekRapor> bekleyen=new();
    static readonly object gate=new();static System.Threading.Timer? timer;static int sending,enabled;static DateTimeOffset lastSent=DateTimeOffset.MinValue;
    static readonly System.Runtime.CompilerServices.ConditionalWeakTable<Exception,object> recorded=new();
    static string scope="";
    static string Baglam()=>LisansKripto.Ozet(HttpsOturumu.Istemci is {} remote?remote.Adres:LisansOturumu.Gecerli?.LicenseId??"unbound");
    static string cache=>Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"MiapaxERP","Destek",Baglam(),"bekleyen.json");
    static void KapsamiKontrolEt(){lock(gate){string current=Baglam();if(scope!=current){bekleyen.Clear();scope=current;}}}
    [StructLayout(LayoutKind.Sequential)]struct Bellek{public uint Length,Load;public ulong Total,Available,Page,AvailablePage,Virtual,AvailableVirtual,Extended;}
    [DllImport("kernel32.dll")][return:MarshalAs(UnmanagedType.Bool)]static extern bool GlobalMemoryStatusEx(ref Bellek value);
    static string RegistryText(string path,string key){try{return Convert.ToString(Registry.GetValue(path,key,""))??"";}catch{return "";}}
    internal static (string Code,string Module) Siniflandir(Exception exception,string module)
    {
        string m=module.ToUpperInvariant();m=m.Contains("LAB")||m.Contains("BASINC")?"LABORATUVAR":m.Contains("MUHASEBE")||m.Contains("FINANS")||m.Contains("BORDRO")?"MUHASEBE":m.Contains("DEPO")||m.Contains("STOK")?"STOK":m.Contains("URETIM")||m.Contains("MAKINE")?"URETIM":m.Contains("SATINALMA")?"SATINALMA":m.Contains("SATIS")||m.Contains("TAHSILAT")?"SATIS":"ERP";
        var e=exception.GetBaseException();string message=e.Message.ToLowerInvariant();
        string code=e is SqlException sql?sql.Number is 207 or 208?"SQL_SCHEMA_MISSING":"SQL_CONNECTION":e is UnauthorizedAccessException?message.Contains("lisans")?"MODULE_LICENSE_MISSING":"PERMISSION_DENIED":e is System.Net.Http.HttpRequestException||e is TaskCanceledException?"HTTPS_CONNECTION":message.Contains("hesap")&&(message.Contains("kod")||message.Contains("bulunamad")||message.Contains("geçerli"))?"ACCOUNT_CODE_INVALID":message.Contains("dönem")&&message.Contains("kapal")?"ACCOUNTING_PERIOD_CLOSED":message.Contains("stok")&&message.Contains("yetersiz")?"STOCK_INSUFFICIENT":e is ArgumentException?"VALIDATION_FAILED":"APPLICATION_ERROR";
        return(code,m);
    }
    internal static (string Device,DestekCihazBilgisi Info) Cihaz()
    {
        string machine=RegistryText(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Cryptography","MachineGuid");if(machine.Length==0)machine=Environment.MachineName;
        string path=@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion";string build=RegistryText(path,"CurrentBuildNumber");int.TryParse(build,out int n);
        string os=(n>=22000?"Windows 11":RegistryText(path,"ProductName"))+" "+RegistryText(path,"DisplayVersion")+" ("+build+")";
        var memory=new Bellek{Length=(uint)Marshal.SizeOf<Bellek>()};double? ram=null;try{if(GlobalMemoryStatusEx(ref memory))ram=memory.Total/1073741824d;}catch{}
        double? disk=null,free=null;try{foreach(var drive in DriveInfo.GetDrives().Where(d=>d.DriveType==DriveType.Fixed&&d.IsReady)){disk=(disk??0)+drive.TotalSize/1073741824d;free=(free??0)+drive.AvailableFreeSpace/1073741824d;}}catch{}
        var info=new DestekCihazBilgisi(Environment.MachineName,os.Trim(),RegistryText(@"HKEY_LOCAL_MACHINE\HARDWARE\DESCRIPTION\System\CentralProcessor\0","ProcessorNameString").Trim(),ram,disk,free,typeof(DestekIzleme).Assembly.GetName().Version?.ToString()??"0.0");
        return(LisansKripto.Ozet(machine),info);
    }
    static void Sakla(){try{lock(gate){Directory.CreateDirectory(Path.GetDirectoryName(cache)!);File.WriteAllText(cache,JsonSerializer.Serialize(bekleyen.Values.Take(100).ToArray(),LisansKripto.Json));}}catch{}}
    static void Ekle(DestekRapor report)
    {
        KapsamiKontrolEt();
        if(report.DeviceId.Length!=64||!report.DeviceId.All(Uri.IsHexDigit)||report.Events.Length>10||bekleyen.Count>=100&&!bekleyen.ContainsKey(report.DeviceId))return;
        bekleyen.AddOrUpdate(report.DeviceId,report,(_,old)=>report with{Events=old.Events.Concat(report.Events).DistinctBy(e=>e.Id).TakeLast(10).ToArray()});Sakla();
    }
    public static void Baslat()
    {
        Volatile.Write(ref enabled,1);
        if(timer is not null)return;
        try{if(File.Exists(cache)&&new FileInfo(cache).Length<256000&&File.GetLastWriteTimeUtc(cache)>DateTime.UtcNow.AddDays(-7)){var saved=JsonSerializer.Deserialize<DestekRapor[]>(File.ReadAllText(cache),LisansKripto.Json);foreach(var item in saved??[])if(item.Info is not null&&item.Events is not null)Ekle(item);}}catch{}
        timer=new System.Threading.Timer(_=>_ = Gonder(),null,TimeSpan.FromSeconds(10),TimeSpan.FromMinutes(5));
    }
    public static void Durdur(){timer?.Dispose();timer=null;Volatile.Write(ref enabled,0);}
    public static void Bildir(Exception exception,string module)
    {
        if(Volatile.Read(ref enabled)==0||LisansOturumu.Gecerli is null&&HttpsOturumu.Istemci?.Oturum is null)return;
        lock(recorded){var root=exception.GetBaseException();if(recorded.TryGetValue(root,out _))return;recorded.Add(root,new object());}
        try{var identity=Cihaz();var error=Siniflandir(exception,module);Ekle(new(Guid.NewGuid(),identity.Device,identity.Info,[new(Guid.NewGuid(),error.Code,error.Module)]));_ = Task.Run(async()=>{await Task.Delay(2500).ConfigureAwait(false);await Gonder().ConfigureAwait(false);});}catch{}
    }
    internal static DestekRapor[] Paket()
    {
        KapsamiKontrolEt();
        try{var self=Cihaz();if(!bekleyen.ContainsKey(self.Device))Ekle(new(Guid.NewGuid(),self.Device,self.Info,[]));}catch{}
        return bekleyen.Values.Take(4).ToArray();
    }
    internal static void Onayla(Guid[] ids)
    {
        KapsamiKontrolEt();
        foreach(var pair in bekleyen.ToArray())if(ids.Contains(pair.Value.Id))((ICollection<KeyValuePair<string,DestekRapor>>)bekleyen).Remove(pair);Sakla();
    }
    internal static async Task<bool> Ilet(DestekRapor report)
    {
        if(report is null||report.Info is null||report.Events is null||report.Events.Length>10||report.DeviceId is null||report.DeviceId.Length!=64||!report.DeviceId.All(Uri.IsHexDigit)||report.Info.Name is null||report.Info.Name.Length>80||report.Info.Os is null||report.Info.Os.Length>120||report.Info.Cpu is null||report.Info.Cpu.Length>160||report.Info.Version is null||report.Info.Version.Length>32||report.Events.Any(e=>e is null||e.Code is null||e.Code.Length>48||e.Module is null||e.Module.Length>40||!System.Text.RegularExpressions.Regex.IsMatch(e.Module,"^[-A-Z0-9_]+$")))throw new ArgumentException("Destek bildirimi geçersiz.");
        if(LisansOturumu.Gecerli is null)return false;Volatile.Write(ref enabled,1);Ekle(report);await LisansOturumu.YenileAsync().ConfigureAwait(false);return !bekleyen.Values.Any(r=>r.Id==report.Id);
    }
    static async Task Gonder()
    {
        if(Interlocked.Exchange(ref sending,1)!=0)return;
        try{
            KapsamiKontrolEt();
            if(DateTimeOffset.UtcNow-lastSent<TimeSpan.FromSeconds(30))return;lastSent=DateTimeOffset.UtcNow;
            if(HttpsOturumu.Istemci is {} remote){var self=Cihaz();if(!bekleyen.ContainsKey(self.Device))Ekle(new(Guid.NewGuid(),self.Device,self.Info,[]));foreach(var report in bekleyen.Values.Take(4).ToArray())if(await remote.Cagir<bool>("DestekServisi.Bildir","",[report]).ConfigureAwait(false))Onayla([report.Id]);}
            else if(LisansOturumu.Gecerli is not null)await LisansOturumu.YenileAsync().ConfigureAwait(false);
        }catch{}finally{Interlocked.Exchange(ref sending,0);}
    }
}
public sealed class DestekServisi(string connection,int user)
{
    public bool Bildir(DestekRapor rapor)
    {
        if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<bool>(connection,"DestekServisi.Bildir","",[rapor]);
        if(user<=0)throw new UnauthorizedAccessException();
        return DestekIzleme.Ilet(rapor).GetAwaiter().GetResult();
    }
}
