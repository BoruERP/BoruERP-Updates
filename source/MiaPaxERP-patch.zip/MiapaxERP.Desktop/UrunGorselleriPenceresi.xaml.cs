using SqlConnection = MiapaxERP.Desktop.ErpSqlConnection;
using SqlCommand = MiapaxERP.Desktop.ErpSqlCommand;
using SqlTransaction = MiapaxERP.Desktop.ErpSqlTransaction;
using SqlDataReader = MiapaxERP.Desktop.ErpSqlReader;
using SqlDataAdapter = MiapaxERP.Desktop.ErpSqlDataAdapter;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using Microsoft.Data.SqlClient;
using Microsoft.Win32;

namespace MiapaxERP.Desktop;

public partial class UrunGorselleriPenceresi : Window
{
    private readonly string _baglanti;
    private readonly int _stokId;
    private readonly int _kullanici;
    private sealed record Gorsel(int Id, string DosyaAdi, bool KapakMi)
    {
        public override string ToString() => (KapakMi ? "★ " : "") + DosyaAdi;
    }
    public UrunGorselleriPenceresi(string baglanti, int stokId, string stokAdi, int kullanici)
    {
        InitializeComponent();
        _baglanti = baglanti;
        _stokId = stokId; _kullanici = kullanici;
        TxtBaslik.Text = "Ürün Fotoğrafları | " + stokAdi;
        Yukle();
    }
    private SqlConnection Baglan() { var c = new SqlConnection(_baglanti); try { c.Open(); Yetki(c,null,false); StokGorselServisi.TabloyuDogrula(c); return c; } catch { c.Dispose(); throw; } }
    private void Yetki(SqlConnection db,SqlTransaction? tx,bool yazma) {
        using var cmd=new SqlCommand("SELECT COUNT(DISTINCT YetkiKodu) FROM dbo.vw_KullaniciEtkinYetkileri WHERE KullaniciId=@k AND Yetkili=1 AND (YetkiKodu=N'STOCK.VIEW' OR (@y=1 AND YetkiKodu=N'STOCK.EDIT'))",db,tx);
        cmd.Parameters.Add("@k",SqlDbType.Int).Value=_kullanici;cmd.Parameters.Add("@y",SqlDbType.Bit).Value=yazma;
        if(Convert.ToInt32(cmd.ExecuteScalar())!=(yazma?2:1))throw new UnauthorizedAccessException("Ürün görseli için stok görüntüleme/düzenleme yetkiniz bulunmuyor.");
    }
    private void Yukle()
    {
        try
        {
            using var con = Baglan();
            using var cmd = new SqlCommand("SELECT Id, DosyaAdi, KapakMi FROM dbo.UrunGorselleri WHERE StokKartId=@stok ORDER BY KapakMi DESC, SiraNo, Id", con);
            cmd.Parameters.Add("@stok", SqlDbType.Int).Value = _stokId;
            using var rd = cmd.ExecuteReader();
            var items = new List<Gorsel>();
            while (rd.Read()) items.Add(new Gorsel(rd.GetInt32(0), rd.GetString(1), rd.GetBoolean(2)));
            LstGorseller.ItemsSource = items;
            TxtDurum.Text = $"{items.Count} görsel";
            if (items.Count > 0) LstGorseller.SelectedIndex = 0;
            else ImgOnizleme.Source = null;
        }
        catch (Exception ex) {DestekIzleme.Bildir(ex,"UrunGorselleriPenceresi.xaml"); MessageBox.Show(ex.Message, "Görseller yüklenemedi"); }
    }
    private void GorselSecildi(object sender, SelectionChangedEventArgs e)
    {
        ImgOnizleme.Source = null;
        if (LstGorseller.SelectedItem is not Gorsel g) return;
        try
        {
            using var con = Baglan();
            using var cmd = new SqlCommand("SELECT GorselVerisi FROM dbo.UrunGorselleri WHERE Id=@id AND StokKartId=@stok", con);
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = g.Id;
            cmd.Parameters.Add("@stok", SqlDbType.Int).Value = _stokId;
            var bytes = cmd.ExecuteScalar() as byte[];
            if (bytes == null) return;
            using var stream = new MemoryStream(bytes);
            var bmp = new BitmapImage();
            bmp.BeginInit(); bmp.CacheOption = BitmapCacheOption.OnLoad; bmp.StreamSource = stream; bmp.EndInit(); bmp.Freeze();
            ImgOnizleme.Source = bmp;
        }
        catch (Exception ex) { TxtDurum.Text = "Önizleme hatası: " + ex.Message; }
    }
    private void Ekle_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog { Filter = "Fotoğraflar (*.jpg;*.jpeg;*.png)|*.jpg;*.jpeg;*.png", Multiselect = true };
        if (dlg.ShowDialog(this) != true) return;
        try
        {
            // Tüm dosyalar önce çözümlenir; bir dosya hatalıysa hiçbiri yazılmaz.
            var files=dlg.FileNames.Select(file=>(Name:Path.GetFileNameWithoutExtension(file)+".png",Bytes:StokGorselServisi.Hazirla(file))).ToList();
if(HttpsOturumu.Uzak(_baglanti)){new YardimciEkranServisi(_baglanti,_kullanici).GorselEkle(_stokId,files.Select(f=>new ErpGorselDosyasi(f.Name,f.Bytes)).ToArray());}
else{            using var con=Baglan();using var tx=con.BeginTransaction(IsolationLevel.Serializable);Yetki(con,tx,true);
            foreach(var file in files) {
                using var cmd=new SqlCommand(@"INSERT INTO dbo.UrunGorselleri(StokKartId,DosyaAdi,IcerikTuru,GorselVerisi,KapakMi,SiraNo)
VALUES(@stok,@ad,N'image/png',@veri,CASE WHEN NOT EXISTS(SELECT 1 FROM dbo.UrunGorselleri WITH(UPDLOCK,HOLDLOCK) WHERE StokKartId=@stok AND KapakMi=1) THEN 1 ELSE 0 END,
ISNULL((SELECT MAX(SiraNo)+1 FROM dbo.UrunGorselleri WHERE StokKartId=@stok),0))",con,tx);
                cmd.Parameters.Add("@stok",SqlDbType.Int).Value=_stokId;cmd.Parameters.Add("@ad",SqlDbType.NVarChar,255).Value=file.Name;
                cmd.Parameters.Add("@veri",SqlDbType.VarBinary,-1).Value=file.Bytes;cmd.ExecuteNonQuery();
            }
tx.Commit();}
            Yukle();
        }
        catch (Exception ex) {DestekIzleme.Bildir(ex,"UrunGorselleriPenceresi.xaml"); MessageBox.Show(ex.Message, "Fotoğraf eklenemedi"); Yukle(); }
    }
    private void Kapak_Click(object sender, RoutedEventArgs e)
    {
        if (LstGorseller.SelectedItem is not Gorsel g) return;
        try
        {
if(HttpsOturumu.Uzak(_baglanti)){new YardimciEkranServisi(_baglanti,_kullanici).GorselKapak(_stokId,g.Id);}
else{            using var con = Baglan(); using var tx = con.BeginTransaction(IsolationLevel.Serializable); Yetki(con,tx,true);
            using (var clear = new SqlCommand("UPDATE dbo.UrunGorselleri SET KapakMi=0 WHERE StokKartId=@stok", con, tx))
            { clear.Parameters.Add("@stok", SqlDbType.Int).Value = _stokId; clear.ExecuteNonQuery(); }
            using (var set = new SqlCommand("UPDATE dbo.UrunGorselleri SET KapakMi=1 WHERE Id=@id AND StokKartId=@stok", con, tx))
            { set.Parameters.Add("@id", SqlDbType.Int).Value = g.Id; set.Parameters.Add("@stok", SqlDbType.Int).Value = _stokId; set.ExecuteNonQuery(); }
tx.Commit();}
            Yukle();
        }
        catch (Exception ex) {DestekIzleme.Bildir(ex,"UrunGorselleriPenceresi.xaml"); MessageBox.Show(ex.Message, "Kapak değiştirilemedi"); }
    }
    private void Sil_Click(object sender, RoutedEventArgs e)
    {
        if (LstGorseller.SelectedItem is not Gorsel g) return;
        if (MessageBox.Show("Seçili fotoğraf kaldırılsın mı?", "MiapaxERP", MessageBoxButton.YesNo) != MessageBoxResult.Yes) return;
        try
        {
if(HttpsOturumu.Uzak(_baglanti)){new YardimciEkranServisi(_baglanti,_kullanici).GorselSil(_stokId,g.Id);}
else{            using var con = Baglan(); using var tx = con.BeginTransaction(IsolationLevel.Serializable); Yetki(con,tx,true);
            using (var cmd = new SqlCommand("DELETE FROM dbo.UrunGorselleri WHERE Id=@id AND StokKartId=@stok", con, tx))
            { cmd.Parameters.Add("@id", SqlDbType.Int).Value = g.Id; cmd.Parameters.Add("@stok", SqlDbType.Int).Value = _stokId; cmd.ExecuteNonQuery(); }
            using (var cmd = new SqlCommand(@"IF NOT EXISTS(SELECT 1 FROM dbo.UrunGorselleri WHERE StokKartId=@stok AND KapakMi=1)
UPDATE dbo.UrunGorselleri SET KapakMi=1 WHERE Id=(SELECT TOP 1 Id FROM dbo.UrunGorselleri WHERE StokKartId=@stok ORDER BY SiraNo,Id)", con, tx))
            { cmd.Parameters.Add("@stok", SqlDbType.Int).Value = _stokId; cmd.ExecuteNonQuery(); }
tx.Commit();}
            Yukle();
        }
        catch (Exception ex) {DestekIzleme.Bildir(ex,"UrunGorselleriPenceresi.xaml"); MessageBox.Show(ex.Message, "Fotoğraf kaldırılamadı"); }
    }
}

