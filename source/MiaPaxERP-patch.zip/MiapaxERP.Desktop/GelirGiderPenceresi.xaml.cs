using System.Data;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace MiapaxERP.Desktop;
public partial class GelirGiderPaneli : UserControl
{
    private readonly GelirGiderServisi servis;
    private DataTable hesaplar=new(), detay=new();
    private Guid anahtar=Guid.NewGuid();
    private bool mesgul;
    private bool baslatildi;
    public bool IslemSuruyor => mesgul;
    public GelirGiderPaneli(string baglanti,int kullanici)
    {
        servis=new(baglanti,kullanici);InitializeComponent();
        Language=System.Windows.Markup.XmlLanguage.GetLanguage("tr-TR");
        Tarih.SelectedDate=OdemeTarih.SelectedDate=Bitis.SelectedDate=DateTime.Today;
        Baslangic.SelectedDate=new DateTime(DateTime.Today.Year,DateTime.Today.Month,1);Tur.SelectedIndex=Kirilim.SelectedIndex=0;
        GorunumRenkleri.Uygula(this,GorunumDeposu.Oku(GorunumDeposu.Klasor(baglanti,kullanici)));
        Loaded+=async(_,_)=> { if (baslatildi) return; baslatildi=true; await YenileAsync(); };

    }
    public Task YenileAsync() => Calistir(async()=>{await ListeleriYukle();await RaporYukle();});
    private async Task Calistir(Func<Task> islem)
    {
        if(mesgul)return;mesgul=true;Govde.IsEnabled=false;Durum.Text="İşlem sürüyor…";
        try { await islem();Durum.Text="İşlem tamamlandı."; }
        catch(Exception ex){DestekIzleme.Bildir(ex,"GelirGiderPenceresi.xaml");Durum.Text="İşlem tamamlanamadı: "+ex.Message;MessageBox.Show(Window.GetWindow(this),ex.Message,"MiapaxERP",MessageBoxButton.OK,MessageBoxImage.Warning);}
        finally{mesgul=false;Govde.IsEnabled=true;}
    }
    private async Task ListeleriYukle()
    {
        var secimler = new[] { Hesap, Merkez, Kasa, OdemeKasa, FiltreMerkez, FiltreHesap, EskiHesap, EskiMerkez }.Select(c => (Kontrol:c, Deger:c.SelectedValue)).ToArray();
        hesaplar=await Task.Run(()=>servis.Oku("hesap"));Plan.ItemsSource=hesaplar.DefaultView;HesaplariSuz();
        EskiHesap.ItemsSource=new DataView(hesaplar){RowFilter="Detay=true AND Aktif=true AND Tur='Gider'"};
        var merkezler=await Task.Run(()=>servis.Oku("merkez"));Merkezler.ItemsSource=merkezler.DefaultView;
        Merkez.ItemsSource=new DataView(merkezler){RowFilter="Aktif=true"};EskiMerkez.ItemsSource=new DataView(merkezler){RowFilter="Aktif=true"};
        var mf=new DataTable();mf.Columns.Add("Id",typeof(int));mf.Columns.Add("Secim");mf.Rows.Add(0,"Tüm merkezler");
        foreach(DataRow r in merkezler.Rows)mf.Rows.Add(r["Id"],r["Secim"]);
        FiltreMerkez.ItemsSource=mf.DefaultView;FiltreMerkez.SelectedIndex=0;
        var hf=new DataTable();hf.Columns.Add("Kod");hf.Columns.Add("Secim");hf.Rows.Add("","Tüm hesaplar");
        foreach(DataRow r in hesaplar.Rows)if((bool)r["Detay"])hf.Rows.Add(r["Kod"],r["Secim"]);
        FiltreHesap.ItemsSource=hf.DefaultView;FiltreHesap.SelectedIndex=0;
        var kasa=await Task.Run(()=>servis.Oku("kasa"));Kasa.ItemsSource=new DataView(kasa);OdemeKasa.ItemsSource=new DataView(kasa);
        await EskileriYukle();
        foreach (var secim in secimler) if (secim.Deger != null) secim.Kontrol.SelectedValue = secim.Deger;
    }
    private async Task EskileriYukle()
    {
        var eski=await Task.Run(()=>servis.Oku("eski"));Eskiler.ItemsSource=eski.DefaultView;
        EskiBilgi.Text=$"Hesap ve maliyet merkezi atanmamış {eski.Rows.Count} eski masraf var. Bunlar sınıflandırılana kadar yeni gelir/gider özetine dahil edilmez.";
    }
    private void HesaplariSuz()
    {
        if(Hesap==null||hesaplar.Columns.Count==0)return;
        Hesap.ItemsSource=new DataView(hesaplar){RowFilter="Detay=true AND Aktif=true AND Tur='"+Sec(Tur)+"'"};Hesap.SelectedIndex=-1;
    }
    private void TurDegisti(object s,SelectionChangedEventArgs e)=>HesaplariSuz();
    private void OdemeDegisti(object s,RoutedEventArgs e){if(Kasa!=null)Kasa.IsEnabled=Odendi.IsChecked==true;}
    private static string Sec(ComboBox c)=>(c.SelectedItem as ComboBoxItem)?.Content?.ToString()??"";
    private static int Id(ComboBox c)=>c.SelectedValue is int i&&i>0?i:throw new ArgumentException("Lütfen ilgili listeden seçim yapın.");
    private static string Kod(ComboBox c)=>c.SelectedValue is string s&&s.Length>0?s:throw new ArgumentException("Detay hesabı seçin.");
    private static DateTime Gun(DatePicker p)=>p.SelectedDate?.Date??throw new ArgumentException("Tarih seçin.");
    private long SeciliKayit()=>Kayitlar.SelectedItem is DataRowView r?Convert.ToInt64(r["Id"]):throw new ArgumentException("Kayıt listesinden işlem seçin.");
    private bool Onay(string metin)=>MessageBox.Show(Window.GetWindow(this),metin,"İşlem onayı",MessageBoxButton.YesNo,MessageBoxImage.Question)==MessageBoxResult.Yes;
    private async void Kaydet_Click(object s,RoutedEventArgs e)=>await Calistir(async()=>
    {
        var g=new GelirGiderGirdisi(anahtar,Gun(Tarih),Sec(Tur),Kod(Hesap),Id(Merkez),GelirGiderServisi.TutarOku(Tutar.Text),Belge.Text,Aciklama.Text,Odendi.IsChecked==true?Id(Kasa):null);
        GelirGiderServisi.Dogrula(g);
        if(!Onay($"{g.Tur}: {g.Tutar:N2} TRY\nHesap: {g.Hesap}\n"+(g.Kasa.HasValue?"Kasa/banka hareketi de oluşturulacak.":"Kasa/banka hareketi oluşturulmayacak.")+"\nKaydedilsin mi?"))return;
        await Task.Run(()=>servis.Kaydet(g));anahtar=Guid.NewGuid();Tutar.Clear();Belge.Clear();Aciklama.Clear();Odendi.IsChecked=false;
        await RaporYukle();
    });
    private async Task RaporYukle()
    {
        DateTime bas=Gun(Baslangic),son=Gun(Bitis);int? m=FiltreMerkez.SelectedValue is int i&&i>0?i:null;
        string? h=FiltreHesap.SelectedValue is string str&&str.Length>0?str:null;
        detay=await Task.Run(()=>servis.Rapor(bas,son,m,h));Kayitlar.ItemsSource=detay.DefaultView;OzetYenile();
    }
    private void OzetYenile()
    {
        if(detay.Columns.Count==0)return;
        var ozet=GelirGiderServisi.Ozet(detay,Sec(Kirilim));Ozet.ItemsSource=ozet.DefaultView;
        decimal gelir=ozet.AsEnumerable().Sum(r=>r.Field<decimal>("Gelir")),gider=ozet.AsEnumerable().Sum(r=>r.Field<decimal>("Gider"));
        Toplam.Text=$"Gelir: {gelir:N2} TRY     Gider: {gider:N2} TRY     Fark: {gelir-gider:N2} TRY";
    }
    private async void Rapor_Click(object s,RoutedEventArgs e)=>await Calistir(RaporYukle);
    private void KirilimDegisti(object s,SelectionChangedEventArgs e)=>OzetYenile();
    private async void Ode_Click(object s,RoutedEventArgs e)=>await Calistir(async()=>
    {
        long id=SeciliKayit();int kasa=Id(OdemeKasa);DateTime tarih=Gun(OdemeTarih);
        if(!Onay($"#{id} numaralı kaydın tamamı seçilen kasa/bankadan ödensin veya tahsil edilsin mi?"))return;
        await Task.Run(()=>servis.Ode(id,kasa,tarih));await RaporYukle();
    });
    private async void Iptal_Click(object s,RoutedEventArgs e)=>await Calistir(async()=>
    {
        long id=SeciliKayit();string neden=IptalNedeni.Text;
        if(!Onay($"#{id} iptal edilsin mi? Varsa aktif kasa/banka ödemesi terslenecek; kayıt geçmişi korunacak."))return;
        await Task.Run(()=>servis.Iptal(id,neden));IptalNedeni.Clear();await RaporYukle();
    });
    private async void MerkezEkle_Click(object s,RoutedEventArgs e)=>await Calistir(async()=>
    {string kod=MerkezKod.Text,ad=MerkezAd.Text;await Task.Run(()=>servis.MerkezKaydet(kod,ad));MerkezKod.Clear();MerkezAd.Clear();await ListeleriYukle();await RaporYukle();});
    private async void MerkezDurum_Click(object s,RoutedEventArgs e)=>await Calistir(async()=>
    {
        if(Merkezler.SelectedItem is not DataRowView r)throw new ArgumentException("Merkez seçin.");int id=Convert.ToInt32(r["Id"]);bool yeni=!Convert.ToBoolean(r["Aktif"]);
        await Task.Run(()=>servis.MerkezDurumu(id,yeni));await ListeleriYukle();await RaporYukle();
    });
    private async void EskiSiniflandir_Click(object s,RoutedEventArgs e)=>await Calistir(async()=>
    {
        if(Eskiler.SelectedItem is not DataRowView r)throw new ArgumentException("Eski masrafı seçin.");long id=Convert.ToInt64(r["Id"]);string h=Kod(EskiHesap);int m=Id(EskiMerkez);
        if(!Onay($"Eski masraf #{id}, {h} hesabına bağlansın mı? Yeni kasa hareketi oluşturulmaz."))return;
        await Task.Run(()=>servis.EskiSiniflandir(id,h,m));await EskileriYukle();await RaporYukle();
    });
    private void SutunOlusuyor(object s,DataGridAutoGeneratingColumnEventArgs e)
    {
        if(e.PropertyName=="Secim"){e.Cancel=true;return;}
        if(e.Column is DataGridTextColumn col && col.Binding is System.Windows.Data.Binding b)
        {if(e.PropertyType==typeof(decimal))b.StringFormat="N2";if(e.PropertyType==typeof(DateTime))b.StringFormat="dd.MM.yyyy";}
    }
}
