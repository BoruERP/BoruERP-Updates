using System.Data;
using System.Globalization;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using TreeView=System.Windows.Controls.TreeView;
using ProgressBar=System.Windows.Controls.ProgressBar;
namespace MiapaxERP.Desktop;

public sealed partial class IsletmePaneli
{
    readonly DatePicker ilkTarih=new(){SelectedDate=new DateTime(DateTime.Today.Year,1,1)},sonTarih=new(){SelectedDate=DateTime.Today};
    readonly ComboBox rapor=new(){ItemsSource=new[]{"Mizan","Yevmiye"},SelectedIndex=0};
    readonly TextBox arama=new(){MinWidth=190,MaxWidth=340,MinHeight=34,ToolTip="Bu modüldeki kayıtlarda ara"};
    readonly ComboBox durum=new(){MinWidth=155,MinHeight=34};
    readonly WrapPanel ozet=new();readonly StackPanel detay=new();
    readonly DataGrid ikinci=new(){IsReadOnly=true,AutoGenerateColumns=true,CanUserAddRows=false,MinHeight=150};
    readonly TextBlock ikinciBaslik=new(){FontSize=17,FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,0,0,10)};
    DataTable? veri;string depo="",raf="";TreeView? rafAgaci;long secimSirasi;
    internal string ModulKodu=>kind;
    internal string YerlesimKodu=>kind switch{"Sevkiyat"=>"SevkiyatRotasi","BasincTest"=>"TestOlcumleri","Depo"=>"DepoRafAgaci","SatinAlma"=>"UcluEslesme","Muhasebe"=>"DonemMizani","Tahsilat"=>"DovizliBakiyeler","Makine"=>"MakinePlanlari",_=>"MalzemeMaliyet"};
    static readonly CultureInfo kultur=CultureInfo.GetCultureInfo("tr-TR");
    static TextBlock Metin(string text,int size=13,bool bold=false)=>new(){Text=text,FontSize=size,FontWeight=bold?FontWeights.SemiBold:FontWeights.Normal,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,3,0,5)};
    static Border Kart(UIElement content,Thickness? margin=null)
    {
        var b=new Border{Child=content,Padding=new Thickness(16),Margin=margin??new Thickness(0,0,0,12),BorderThickness=new Thickness(1)};
        b.SetResourceReference(Border.BackgroundProperty,"ErpKart");b.SetResourceReference(Border.BorderBrushProperty,"ErpCizgi");b.SetResourceReference(Border.CornerRadiusProperty,"ErpKose");return b;
    }
    string Aciklama=>kind switch{
        "Sevkiyat"=>"Yükleme, araç ve teslim sürecini aynı sevkiyat üzerinden takip edin.",
        "BasincTest"=>"Boru partilerinin ölçümlerini, teknik onayını ve test kanıtlarını inceleyin.",
        "Depo"=>"Depo ve raf seçerek parti, rezervasyon ve kullanılabilir stokları inceleyin.",
        "SatinAlma"=>"Siparişi seçin; kabul edilen ve faturalanan miktarları satır satır karşılaştırın.",
        "Muhasebe"=>"Dönem seçin; yevmiye kayıtları ile borç, alacak ve mizanı inceleyin.",
        "Tahsilat"=>"Satış bakiyelerini belge dövizinde takip edin, seçili satışa tahsilat girin.",
        "Makine"=>"Makine kapasitesi, saat maliyetleri ve üretim planlarını birlikte inceleyin.",
        _=>"Üretim emrinin malzeme ihtiyacını hesaplayın; gerçekleşen maliyetlerini inceleyin."};
    void PaneliKur()
    {
        var root=new DockPanel{Margin=new Thickness(16)};Content=root;
        var top=new StackPanel();DockPanel.SetDock(top,Dock.Top);root.Children.Add(top);
        top.Children.Add(Tema170.Baslik("MiaPaxERP",sections[kind]));top.Children.Add(Metin(Aciklama));
        top.Children.Add(ozet);
        var tools=new WrapPanel{Margin=new Thickness(0,5,0,8)};
        tools.Children.Add(Metin("Kayıt ara",13,true));arama.Margin=new Thickness(10,0,18,0);arama.SetResourceReference(Control.BackgroundProperty,"ErpKart");arama.SetResourceReference(Control.ForegroundProperty,"ErpMetin");arama.SetResourceReference(Control.BorderBrushProperty,"ErpCizgi");tools.Children.Add(arama);
        if(kind=="Muhasebe")
        {
            tools.Children.Add(Metin("Dönem",13,true));ilkTarih.Margin=sonTarih.Margin=rapor.Margin=new Thickness(8,0,0,0);tools.Children.Add(ilkTarih);tools.Children.Add(sonTarih);tools.Children.Add(rapor);
            var apply=new Button{Content="Raporu getir",Margin=new Thickness(10,0,0,0)};apply.Click+=async(_,_)=>await Run(Load);tools.Children.Add(apply);
        }
        else if(kind is "Sevkiyat" or "BasincTest" or "Tahsilat")
        {
            durum.ItemsSource=kind=="Tahsilat"?new[]{"Tüm satışlar","Bakiyesi açık","Tamamı tahsil edildi"}:kind=="Sevkiyat"?new[]{"Tüm durumlar","Taslak","Sevk edildi","Teslim edildi"}:new[]{"Tüm sonuçlar","Taslak","Onaylandı","Reddedildi"};durum.SelectedIndex=0;tools.Children.Add(durum);
        }
        top.Children.Add(tools);top.Children.Add(actions);DockPanel.SetDock(status,Dock.Bottom);root.Children.Add(status);
        arama.TextChanged+=(_,_)=>Filtrele();durum.SelectionChanged+=(_,_)=>Filtrele();
        var workspace=new Grid();root.Children.Add(workspace);
        workspace.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1,GridUnitType.Star)});
        workspace.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(kind=="Depo"?210:300)});
        if(kind is "SatinAlma" or "Makine" or "UretimMaliyet")
        {
            var split=new Grid();split.RowDefinitions.Add(new RowDefinition{Height=new GridLength(1,GridUnitType.Star)});split.RowDefinitions.Add(new RowDefinition{Height=new GridLength(210)});
            split.Children.Add(Kart(grid,new Thickness(0,0,12,10)));
            var lower=new DockPanel();DockPanel.SetDock(ikinciBaslik,Dock.Top);lower.Children.Add(ikinciBaslik);lower.Children.Add(ikinci);
            ikinciBaslik.Text=kind=="SatinAlma"?"Sipariş · mal kabul · fatura karşılaştırması":kind=="Makine"?"Makineye ait kapasite planları":"Malzeme ihtiyaç planı";
            var lowerCard=Kart(lower,new Thickness(0,0,12,0));Grid.SetRow(lowerCard,1);split.Children.Add(lowerCard);workspace.Children.Add(split);
        }
        else workspace.Children.Add(Kart(grid,new Thickness(0,0,12,0)));
        if(kind=="Depo")
        {
            rafAgaci=new TreeView{BorderThickness=new Thickness(0)};rafAgaci.SetResourceReference(Control.BackgroundProperty,"ErpKart");rafAgaci.SetResourceReference(Control.ForegroundProperty,"ErpMetin");rafAgaci.SelectedItemChanged+=(_,e)=>{if(e.NewValue is TreeViewItem{Tag:string[] parts}){depo=parts[0];raf=parts[1];Filtrele();}};
            var tree=new DockPanel();var caption=Metin("Depo / raf seçimi",17,true);DockPanel.SetDock(caption,Dock.Top);tree.Children.Add(caption);tree.Children.Add(rafAgaci);var card=Kart(tree,new Thickness(0));Grid.SetColumn(card,1);workspace.Children.Add(card);
        }
        else
        {
            var scroll=new ScrollViewer{Content=detay,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};var card=Kart(scroll,new Thickness(0));Grid.SetColumn(card,1);workspace.Children.Add(card);
        }
        grid.SelectionChanged+=async(_,_)=>{DetayiGoster();if(kind=="SatinAlma"&&IsLoaded&&grid.SelectedItem is DataRowView row){long id=Convert.ToInt64(row["Id"]),epoch=++secimSirasi;try{var table=await Task.Run(()=>db.SiparisEslesme(id));if(epoch==secimSirasi&&IsLoaded)EslesmeyiGoster(table);}catch(Exception ex){if(epoch==secimSirasi)status.Text=ex.Message;}}if(kind=="Makine")PlanlariFiltrele();};
        DetayiGoster();
    }
    internal void VeriyiGoster(DataTable table)
    {
        veri=table;
        if(kind=="SatinAlma"&&table.Columns.Contains("Veri"))
        {
            foreach(string name in new[]{"TedarikciId","SiparisTarihi","Termin","Doviz"})if(!table.Columns.Contains(name))table.Columns.Add(name,typeof(string));
            foreach(DataRow row in table.Rows)try{using var doc=JsonDocument.Parse((string)row["Veri"]);foreach(var (col,key) in new[]{("TedarikciId","cari"),("SiparisTarihi","tarih"),("Termin","termin"),("Doviz","para")})if(doc.RootElement.TryGetProperty(key,out var value))row[col]=value.ToString();}catch(JsonException){}
        }
        if(rafAgaci is not null)
        {
            rafAgaci.Items.Clear();rafAgaci.Items.Add(new TreeViewItem{Header="Bütün depolar",Tag=new[]{"",""}});
            if(table.Columns.Contains("Depo"))foreach(var group in table.AsEnumerable().GroupBy(r=>Convert.ToString(r["Depo"])??"")){var item=new TreeViewItem{Header=group.Key,Tag=new[]{group.Key,""},IsExpanded=true};foreach(string shelf in group.Select(r=>Convert.ToString(r["Raf"])??"").Distinct())item.Items.Add(new TreeViewItem{Header=shelf,Tag=new[]{group.Key,shelf}});rafAgaci.Items.Add(item);}
        }
        Filtrele();
    }
    static decimal Sayi(DataRow row,string key)=>row.Table.Columns.Contains(key)&&!row.IsNull(key)?decimal.TryParse(Convert.ToString(row[key],CultureInfo.InvariantCulture),NumberStyles.Any,CultureInfo.InvariantCulture,out var value)?value:0:0;
    static string Alan(DataRow row,string key)=>row.Table.Columns.Contains(key)?Convert.ToString(row[key],kultur)??"":"";
    void Filtrele()
    {
        if(veri is null)return;var result=veri.Clone();string query=MainWindow.MenuAramaMetni(arama.Text.Trim());
        foreach(DataRow row in veri.Rows)
        {
            if(query.Length>0&&!veri.Columns.Cast<DataColumn>().Where(c=>c.DataType!=typeof(byte[])&&c.ColumnName!="Veri").Any(c=>MainWindow.MenuAramaMetni(Alan(row,c.ColumnName)).Contains(query)))continue;
            if(kind=="Depo"&&((depo.Length>0&&Alan(row,"Depo")!=depo)||(raf.Length>0&&Alan(row,"Raf")!=raf)))continue;
            if(durum.SelectedIndex>0){if(kind=="Tahsilat"){if(durum.SelectedIndex==1&&Sayi(row,"Kalan")<=0||durum.SelectedIndex==2&&Sayi(row,"Kalan")!=0)continue;}else if(Alan(row,"Durum")!=Convert.ToString(durum.SelectedItem))continue;}
            result.ImportRow(row);
        }
        grid.ItemsSource=result.DefaultView;if(result.Rows.Count>0)grid.SelectedIndex=0;Ozetle(result);DetayiGoster();
    }
    void OzetKart(string label,string value)
    {
        var p=new StackPanel{MinWidth=150};p.Children.Add(Metin(label));var amount=Metin(value,22,true);amount.SetResourceReference(TextBlock.ForegroundProperty,"ErpVurgu");p.Children.Add(amount);ozet.Children.Add(Kart(p,new Thickness(0,6,10,5)));
    }
    void Ozetle(DataTable table)
    {
        ozet.Children.Clear();var rows=table.AsEnumerable().ToArray();OzetKart(kind=="Depo"?"Parti / raf kaydı":"Görünen kayıt",rows.Length.ToString("N0",kultur));
        if(kind=="Muhasebe"){OzetKart("Toplam borç",rows.Sum(r=>Sayi(r,"Borc")).ToString("N2",kultur)+" TRY");OzetKart("Toplam alacak",rows.Sum(r=>Sayi(r,"Alacak")).ToString("N2",kultur)+" TRY");}
        else if(kind=="Tahsilat")foreach(var group in rows.GroupBy(r=>Alan(r,"Doviz")))OzetKart(group.Key+" açık bakiye",group.Sum(r=>Sayi(r,"Kalan")).ToString("N2",kultur));
        else if(kind=="Depo"){OzetKart("Depo",rows.Select(r=>Alan(r,"Depo")).Distinct().Count().ToString());OzetKart("Kalite bekleyen parti",rows.Where(r=>Alan(r,"Kalite")!="Serbest").Select(r=>Alan(r,"LotId")).Distinct().Count().ToString());}
        else if(kind=="BasincTest"){OzetKart("Teknik onay bekleyen",rows.Count(r=>Alan(r,"Durum")=="Taslak").ToString());OzetKart("Onaylanan test",rows.Count(r=>Alan(r,"Durum")=="Onaylandı").ToString());}
        else if(kind=="Sevkiyat"){OzetKart("Sevkte",rows.Count(r=>Alan(r,"Durum")=="Sevk edildi").ToString());OzetKart("Teslim edilen",rows.Count(r=>Alan(r,"Durum")=="Teslim edildi").ToString());}
        else if(kind=="Makine")OzetKart("Günlük toplam kapasite",rows.Sum(r=>Sayi(r,"GunlukDakika")).ToString("N0",kultur)+" dk");
        else if(kind=="UretimMaliyet")OzetKart("Kesinleşen üretim maliyeti",rows.Sum(r=>Sayi(r,"ToplamTRY")).ToString("N2",kultur)+" TRY");
    }
    void DetayiGoster()
    {
        detay.Children.Clear();detay.Children.Add(Metin(kind switch{"Sevkiyat"=>"Sevkiyat rotası","BasincTest"=>"Basınç ve kalite","Muhasebe"=>"Hesap ayrıntısı","Tahsilat"=>"Tahsilat özeti","Makine"=>"Kapasite ayrıntısı","UretimMaliyet"=>"Maliyet bileşenleri",_=>"Üçlü eşleştirme"},18,true));
        if(grid.SelectedItem is not DataRowView selected){detay.Children.Add(Metin("Ayrıntıları görmek için listeden bir kayıt seçin."));detay.Children.Add(Metin(Aciklama));return;}
        var row=selected.Row;
        string[] fields=kind switch{"Sevkiyat"=>new[]{"Musteri","Nereden","Nereye","Plaka","Sofor","BosKg","DoluKg","NetKg","Durum"},"BasincTest"=>new[]{"Urun","Parti","Yontem","Standart","HedefBar","IlkBar","SonBar","Sicaklik","Baslangic","Bitis","Durum"},"Muhasebe"=>new[]{"Kod","Hesap","Ad","Borc","Alacak","Bakiye"},"Tahsilat"=>new[]{"BelgeNo","Musteri","Doviz","Toplam","Kapanan","Kalan","KalanTRY"},"Makine"=>new[]{"Kod","Makine","GunlukDakika","MakineSaatTRY","IscilikSaatTRY","EnerjiSaatTRY"},"UretimMaliyet"=>new[]{"UretimEmriNo","Makine","MalzemeTRY","DonusumTRY","ToplamTRY","BirimMaliyetTRY"},_=>new[]{"BelgeNo","TedarikciId","SiparisTarihi","Termin","Doviz","Durum"}};
        foreach(string f in fields)if(row.Table.Columns.Contains(f)){detay.Children.Add(Metin(Baslik(f),12));detay.Children.Add(Metin(Alan(row,f),16,true));}
        if(kind=="BasincTest")
        {
            var target=Sayi(row,"HedefBar");var final=Sayi(row,"SonBar");if(target>0){detay.Children.Add(Metin("Son basınç / hedef"));var bar=new ProgressBar{Minimum=0,Maximum=100,Value=(double)Math.Clamp(final/target*100,0,100),Height=12};bar.SetResourceReference(Control.ForegroundProperty,"ErpVurgu");detay.Children.Add(bar);detay.Children.Add(Metin("Teknik inceleme ve parti serbest bırakma ayrı yetkilerle tamamlanır."));}
        }
    }
    static string Baslik(string name)=>name switch{"Musteri"=>"Müşteri","Sofor"=>"Şoför","BosKg"=>"Boş ağırlık (kg)","DoluKg"=>"Dolu ağırlık (kg)","NetKg"=>"Net yük (kg)","HedefBar"=>"Hedef basınç (bar)","IlkBar"=>"İlk basınç (bar)","SonBar"=>"Son basınç (bar)","KalanTRY"=>"Defter bakiyesi (TRY)","GunlukDakika"=>"Günlük kapasite (dk)","MalzemeTRY"=>"Malzeme maliyeti (TRY)","DonusumTRY"=>"Dönüşüm maliyeti (TRY)","ToplamTRY"=>"Toplam maliyet (TRY)","SevkiyatNo"=>"Sevkiyat no","TestNo"=>"Test no","BelgeNo"=>"Belge no","UretimEmriNo"=>"Üretim emri","StokAdi"=>"Ürün / malzeme","StokKodu"=>"Stok kodu","Kullanilabilir"=>"Kullanılabilir","Borc"=>"Borç","Doviz"=>"Döviz","BirimMaliyetTRY"=>"Birim maliyet (TRY)","MakineSaatTRY"=>"Makine / saat (TRY)","IscilikSaatTRY"=>"İşçilik / saat (TRY)","EnerjiSaatTRY"=>"Enerji / saat (TRY)","TedarikciId"=>"Tedarikçi no","SiparisTarihi"=>"Sipariş tarihi","Baslangic"=>"Başlangıç","Bitis"=>"Bitiş","Sicaklik"=>"Sıcaklık (°C)","Yontem"=>"Yöntem","Urun"=>"Ürün",_=>name};
    void EslesmeyiGoster(DataTable table){ikinci.ItemsSource=table.DefaultView;ikinciBaslik.Text="Sipariş · kabul · fatura: seçili siparişin satırları";}
    void MrpGoster(DataTable table){ikinci.ItemsSource=table.DefaultView;ikinciBaslik.Text="Malzeme ihtiyaç planı · stok ve açık siparişler";}
    DataTable? kapasite;
    async Task KapasiteleriYukle(){kapasite=await Task.Run(()=>db.Liste("Kapasite"));PlanlariFiltrele();}
    void PlanlariFiltrele()
    {
        if(kapasite is null)return;var filtered=kapasite.Clone();string machine=grid.SelectedItem is DataRowView row?Alan(row.Row,"Makine"):"";
        foreach(DataRow r in kapasite.Rows)if(machine.Length==0||Alan(r,"Makine")==machine)filtered.ImportRow(r);ikinci.ItemsSource=filtered.DefaultView;ikinciBaslik.Text=machine.Length==0?"Kapasite planları":machine+" · kapasite planları";
    }
}
