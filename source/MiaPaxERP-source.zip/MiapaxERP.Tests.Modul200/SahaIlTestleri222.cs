using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using MiapaxERP.Desktop;
using Microsoft.Data.SqlClient;
static class SahaIlTestleri222{
 static int n;static void Check(bool x,string s){if(!x)throw new Exception(s);n++;Console.WriteLine("PASS IL LISTE "+s);}
 static void Reject(Action action,string label){try{action();}catch(Exception e)when(e is ArgumentException or UnauthorizedAccessException){Check(true,label);return;}throw new Exception(label);}
 public static async Task Run(SqlConnection c,string cs){
  const string il="LISTE-IL-A";var admin=new SahaServisi(cs,1);var accounts=new MobilHesapServisi(cs);
  using(var add=new SqlCommand("INSERT dbo.Kullanicilar VALUES(4,1)",c))add.ExecuteNonQuery();
  var aid=accounts.Kaydet(1,2,"Liste A","SAHA");var bid=accounts.Kaydet(1,4,"Liste B","SAHA");
  string Token(Guid id)=>JsonSerializer.SerializeToElement(accounts.Bagla(accounts.Esle(1,id),"Liste test"),SahaServisi.Json).GetProperty("token").GetString()!;
  string token=Token(aid);var a=new SahaServisi(cs,2,accounts.Dogrula(token));var b=new SahaServisi(cs,4,accounts.Dogrula(Token(bid)));
  SahaMusterisi M(string name,string province=il,string district="ILCE-A")=>new(Guid.NewGuid(),province,district,"Test köyü",name,"05001234567",null,"dekar","",null,"m³/saat",null,"Bilinmiyor","Bilinmiyor","");
  var first=M("Ali Test");var stamp=DateTimeOffset.UtcNow.AddMinutes(-5);string version=admin.Kaydet(first,null,Guid.NewGuid(),stamp,"Eski görüşme");
  admin.Kaydet(first,version,Guid.NewGuid(),stamp.AddMinutes(1),"Yeni görüşme");var blank=M("Henüz görüşülmedi");admin.Kaydet(blank,null,Guid.NewGuid(),stamp,"");
  var own=M("Ayşe Test");a.Kaydet(own,null,Guid.NewGuid(),stamp,"Saha A",Guid.NewGuid());var other=M("Başka satışçı",district:"ILCE-B");b.Kaydet(other,null,Guid.NewGuid(),stamp,"Saha B",Guid.NewGuid());
  var remote=M("Başka il","LISTE-IL-B");admin.Kaydet(remote,null,Guid.NewGuid(),stamp,"Diğer il");
  var all=admin.IlGorusmeleri(il);Check(all.Rows.Length==3,"Yalnız seçili ilde görüşülen kişiler gelir");
  Check(all.Rows.Count(r=>r.Id==first.Id)==1&&all.Rows.First().Sonuc=="Yeni görüşme","Bir kişinin son görüşmesi tek satır gösterilir");
  Check(all.Rows.All(r=>r.Id!=blank.Id&&r.Id!=remote.Id),"Görüşmesiz kartlar ve diğer iller dışarıda kalır");
  Check(all.Rows.All(r=>r.SonGorusme.Kind==DateTimeKind.Utc),"Görüşme tarihleri UTC kimliğiyle döner");
  Check(admin.IlGorusmeleri(il,"ILCE-A").Rows.Length==2&&admin.IlGorusmeleri(il,"ILCE-B").Rows.Length==1,"İlçe filtresi doğru kişileri getirir");
  Check(admin.IlGorusmeleri(il,search:"Ali Test").Rows.Single().Id==first.Id,"Ad araması");Check(admin.IlGorusmeleri(il,search:"0500123").Rows.Length==3,"Telefon araması");
  Check(admin.IlGorusmeleri(il,search:"' OR 1=1--").Rows.Length==0,"Arama metni SQL komutu olarak çalışmaz");
  Reject(()=>new SahaServisi(cs,2).IlGorusmeleri(il),"FIELD.VIEW olmayan masaüstü hesabı listeyi göremez");
  Check(a.IlGorusmeleri(il).Rows.Single().Id==own.Id&&a.IlGorusmeleri(il,"ILCE-B").Rows.Length==0,"Mobil saha hesabı yalnız kendi kişilerini görebilir");
  Check(b.IlGorusmeleri(il).Rows.Single().Id==other.Id,"İkinci satışçının satırları ayrıdır");
  Reject(()=>admin.IlGorusmeleri(il,offset:-1),"Negatif sayfa reddedilir");Reject(()=>admin.IlGorusmeleri(il,search:new string('x',161)),"Uzun arama reddedilir");
  for(int i=0;i<102;i++){var m=M("Sayfa "+i.ToString("D3"),"LISTE-SAYFA");admin.Kaydet(m,null,Guid.NewGuid(),stamp,"Sayfa testi");}
  var page1=admin.IlGorusmeleri("LISTE-SAYFA");var page2=admin.IlGorusmeleri("LISTE-SAYFA",offset:page1.NextOffset);
  Check(page1.Rows.Length==100&&page1.HasMore&&page1.NextOffset==100,"İlk sayfa yüz kişiyle sınırlı");
  Check(page2.Rows.Length==2&&!page2.HasMore&&page2.NextOffset==102,"Sonraki sayfa kalan kişileri getirir");
  Check(page1.Rows.Concat(page2.Rows).Select(r=>r.Id).Distinct().Count()==102,"Sayfalar arasında kişi kaybı veya tekrar yok");
  await using var app=MobilApi220.Olustur(cs,5202);await app.StartAsync();using var http=new HttpClient{BaseAddress=new Uri("http://127.0.0.1:5202")};http.DefaultRequestHeaders.Authorization=new("Bearer",token);
  var response=await http.PostAsJsonAsync("/api/mobile/v2/rpc",new{action="province",il,ilce="",search="",offset=0});
  var body=await response.Content.ReadFromJsonAsync<JsonElement>();Check(response.IsSuccessStatusCode&&body.GetProperty("rows").GetArrayLength()==1,"HTTP il listesi satışçı kapsamını korur");
  accounts.Iptal(1,aid);Check((await http.PostAsJsonAsync("/api/mobile/v2/rpc",new{action="province",il,ilce="",search="",offset=0})).StatusCode==HttpStatusCode.Forbidden,"İptal edilen cihaz il listesine erişemez");
  await app.StopAsync();Console.WriteLine("PASSED IL LISTE222 "+n);
 }
}
