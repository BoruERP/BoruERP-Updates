using System.IO;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Diagnostics;
using System.Text;
using System.Text.Json;
using MiapaxERP.Desktop;
using Microsoft.AspNetCore.Hosting;
static class LanTests221{
 static int count;
 static void Check(bool value,string name){if(!value)throw new Exception(name);count++;Console.WriteLine("PASS LAN "+name);}
 static void Reject(Action action,string label){try{action();}catch(ArgumentException){Check(true,label);return;}throw new Exception(label);}
 static async Task RunProcess(string exe,params string[] args){var start=new ProcessStartInfo(exe){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true};foreach(var a in args)start.ArgumentList.Add(a);using var p=Process.Start(start)!;var stdout=p.StandardOutput.ReadToEndAsync();var stderr=p.StandardError.ReadToEndAsync();await p.WaitForExitAsync();Console.Write(await stdout);Console.Write(await stderr);if(p.ExitCode!=0)throw new Exception("Java TLS testi başarısız.");}
 public static async Task Run(string cs){
  foreach(var ip in new[]{"10.0.0.1","172.16.0.1","172.31.255.254","192.168.0.2"})Check(MobilYerelSunucu.OzelIp(ip),"Özel IPv4 "+ip);
  foreach(var ip in new[]{"8.8.8.8","127.0.0.1","0.0.0.0","172.32.0.1","192.168.01.1","192.168.1.256","::1"})Check(!MobilYerelSunucu.OzelIp(ip),"Özel ağ dışında "+ip);
  using var cert=MobilYerelSunucu.YeniSertifika(IPAddress.Loopback);string pin=Convert.ToHexString(SHA256.HashData(cert.RawData));
  var info=new MobilYerelTanim("https://192.168.1.5:5189",pin,cert.NotAfter);string packet=MobilYerelSunucu.Paket(info,new string('A',64));
  string base64=packet[10..].Replace('-','+').Replace('_','/');base64=base64.PadRight((base64.Length+3)/4*4,'=');using var doc=JsonDocument.Parse(Convert.FromBase64String(base64));
  Check(doc.RootElement.GetProperty("pin").GetString()==pin&&doc.RootElement.GetProperty("address").GetString()==info.Adres,"Telefon kodu adres ve sertifika kimliğini taşır");
  foreach(var url in new[]{"http://192.168.1.5:5189","https://8.8.8.8:5189","https://192.168.1.5:5189/x","https://user@192.168.1.5:5189","https://192.168.1.5:5189?q=x"})Reject(()=>MobilYerelSunucu.Paket(info with{Adres=url},new string('A',64)),"Kod üretimi adres reddi "+url);
  bool active=true;await using var app=MobilApi220.Olustur(cs,listen:o=>o.Listen(IPAddress.Loopback,5201,l=>l.UseHttps(cert)),active:()=>active);await app.StartAsync();
  string? found=AppContext.BaseDirectory;while(found is not null&&!Directory.Exists(Path.Combine(found,"MiapaxERP.Android")))found=Directory.GetParent(found)?.FullName;string source=found??throw new Exception("Kaynak kökü bulunamadı.");var root=Directory.GetParent(source)!.FullName;var results=Path.Combine(root,"Teslim221","Testler");Directory.CreateDirectory(results);
  File.WriteAllBytes(Path.Combine(results,"valid.cer"),cert.RawData);using var other=MobilYerelSunucu.YeniSertifika(IPAddress.Loopback);File.WriteAllBytes(Path.Combine(results,"other.cer"),other.RawData);
  using(var rsa=RSA.Create(2048)){var req=new CertificateRequest("CN=expired",rsa,HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1);using var expired=req.CreateSelfSigned(DateTimeOffset.UtcNow.AddDays(-10),DateTimeOffset.UtcNow.AddDays(-1));File.WriteAllBytes(Path.Combine(results,"expired.cer"),expired.RawData);}
  string javaRoot=Environment.GetEnvironmentVariable("MiapaxERP_TEST_JDK")??Directory.GetDirectories(Path.Combine(root,"MiapaxERP-1.8.1-Gelistirme","AndroidAraclari","jdk"))[0];
  string classes=Path.Combine(results,"java");Directory.CreateDirectory(classes);
  await RunProcess(Path.Combine(javaRoot,"bin","javac.exe"),"-encoding","UTF-8","-d",classes,Path.Combine(source,"MiapaxERP.Android","src","com","MiapaxERP","mobile","LanTls.java"),Path.Combine(source,"MiapaxERP.Tests.MobilWeb","LanTlsTests.java"));
  await RunProcess(Path.Combine(javaRoot,"bin","java.exe"),"-cp",classes,"com.boruerp.mobile.LanTlsTests",Path.Combine(results,"valid.cer"),Path.Combine(results,"other.cer"),Path.Combine(results,"expired.cer"),pin,"https://127.0.0.1:5201/api/mobile/v2/profile");
  using var handler=new HttpClientHandler{ServerCertificateCustomValidationCallback=(_,c,_,errors)=>c is not null&&(errors&System.Net.Security.SslPolicyErrors.RemoteCertificateNameMismatch)==0&&Convert.ToHexString(SHA256.HashData(c.RawData))==pin};
  using var http=new HttpClient(handler);active=false;Check((await http.GetAsync("https://127.0.0.1:5201/api/mobile/v2/profile")).StatusCode==HttpStatusCode.ServiceUnavailable,"Ana oturum kapanınca yerel API erişimi durur");
  await app.StopAsync();Console.WriteLine("PASSED LAN221 "+count);
 }
}
