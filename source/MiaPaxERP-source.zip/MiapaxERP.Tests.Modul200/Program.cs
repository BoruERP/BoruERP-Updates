using System.Data;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using MiapaxERP.Desktop;
using MiapaxERP.Lisans.Core;
using Microsoft.Data.SqlClient;
class Program
{
 static int checks;static void Check(bool value,string label){if(!value)throw new Exception(label);checks++;Console.WriteLine("PASS "+label);}
 static void Reject(Action action,string label){try{action();}catch(Exception e)when(e is ArgumentException or InvalidOperationException or UnauthorizedAccessException or SqlException or CryptographicException or InvalidDataException){Check(true,label);return;}throw new Exception("Reddedilmedi: "+label);}
 static void Sql(SqlConnection c,string s){using var q=new SqlCommand(s,c);q.ExecuteNonQuery();}
 static object Scalar(SqlConnection c,string s){using var q=new SqlCommand(s,c);return q.ExecuteScalar()!;}
 static decimal Balance(SqlConnection c,int id)=>Convert.ToDecimal(Scalar(c,"SELECT Miktar FROM dbo.StokBakiyeleri WHERE StokKartId="+id));
 static byte[] Version(RestoranServisi r,long id)=>(byte[])r.Oku("adisyon").AsEnumerable().Single(x=>(long)x["Id"]==id)["Surum"];
 [STAThread]static int Main(string[] args)
 {
  if(args.Contains("--live")||args.Contains("--live-denied"))return Live(args.Contains("--live-denied")).GetAwaiter().GetResult();
  if(args.Contains("--reentry")){
   Check(LisansOturumu.Zorunlu,"Müşteri sürümünde yeniden etkinleştirme testi");
   var cache=typeof(LisansOturumu).GetField("cached",BindingFlags.NonPublic|BindingFlags.Static)!;
   cache.SetValue(null,new LisansOnbellek(new string('A',64),null,DateTimeOffset.UtcNow.AddDays(-8)));
   Check(!LisansOturumu.YenileAsync().GetAwaiter().GetResult(),"Geçerli çevrimdışı izin yoksa kayıtlı anahtar otomatik gönderilmez");
   Check(((LisansOnbellek)cache.GetValue(null)!).Anahtar=="","Yeniden giriş gereken anahtar önbellekten temizlenir");
   Check(!LisansOturumu.ModulVar("STOK"),"Anahtar yeniden girilmeden modül açılmaz");
   Console.WriteLine("PASSED REENTRY "+checks);return 0;
  }
  if(args.Contains("--guard")){Check(LisansOturumu.Zorunlu,"Müşteri derlemesinde lisans zorunlu");Check(!LisansOturumu.ModulVar("STOK"),"Lisans olmadan modül kapalı");Reject(()=>LisansOturumu.Gerekli("MOBIL"),"Mobil lisans olmadan sunucu işlemleri kapalı");Reject(()=>new ErpModulServisi("",1).Yetki(new SqlConnection(),null,"STOCK.VIEW"),"Yönetici bile lisanssız servis açamaz");return 0;}
  string dbName="MiapaxERP_Test200_"+Guid.NewGuid().ToString("N");SqlConnection? master=null;
  try{
   Check(!LisansOturumu.Zorunlu,"İzole iş akışı testi önizleme derlemesi");Core();
   var b=new SqlConnectionStringBuilder("Server=(localdb)\\MSSQLLocalDB;Integrated Security=true;TrustServerCertificate=true;Pooling=false"){InitialCatalog="master",ConnectTimeout=10};master=new(b.ConnectionString);master.Open();Sql(master,$"CREATE DATABASE [{dbName}]");b.InitialCatalog=dbName;string cs=b.ConnectionString;
   using var c=new SqlConnection(cs);c.Open();Sql(c,"""
    CREATE TABLE dbo.Kullanicilar(Id int PRIMARY KEY,Aktif bit);INSERT dbo.Kullanicilar VALUES(1,1),(2,1);
    CREATE TABLE dbo.KullaniciRolleri(Id int PRIMARY KEY,RolAdi nvarchar(100),Aktif bit);INSERT dbo.KullaniciRolleri VALUES(1,N'Yönetici',1);
    CREATE TABLE dbo.KullaniciRolAtamalari(KullaniciId int,RolId int);INSERT dbo.KullaniciRolAtamalari VALUES(1,1);
    CREATE TABLE dbo.TestYetki(KullaniciId int,YetkiKodu nvarchar(100),Yetkili bit);
    CREATE TABLE dbo.Yetkiler(YetkiKodu nvarchar(100) PRIMARY KEY,Modul nvarchar(100),Islem nvarchar(100),Aciklama nvarchar(200),Aktif bit);
    CREATE TABLE dbo.StokKartlari(Id int PRIMARY KEY,StokKodu nvarchar(50),StokAdi nvarchar(160),Birim nvarchar(20),Aktif bit);
    INSERT dbo.StokKartlari VALUES(1,N'S1',N'Sünger mamul',N'M3',1),(2,N'HM',N'Girdi',N'KG',1),(3,N'YUZ',N'Yüzey malzemesi',N'M2',1),(4,N'Y1',N'Yemek',N'Adet',1),(5,N'G1',N'Gıda',N'KG',1),(6,N'I1',N'İçecek',N'Adet',1);
    CREATE TABLE dbo.StokBakiyeleri(StokKartId int PRIMARY KEY,Birim nvarchar(20),Miktar decimal(18,3),SonGuncelleme datetime2 NULL);
    INSERT dbo.StokBakiyeleri VALUES(1,N'M3',0,NULL),(2,N'KG',1000,NULL),(3,N'M2',50,NULL),(4,N'Adet',0,NULL),(5,N'KG',10,NULL),(6,N'Adet',10,NULL);
    CREATE TABLE dbo.StokHareketleri(Id bigint IDENTITY PRIMARY KEY,StokKartId int,HareketTipi nvarchar(40),Yon nvarchar(1),Miktar decimal(18,3),Birim nvarchar(20),Aciklama nvarchar(500));
    """);Sql(c,"CREATE VIEW dbo.vw_KullaniciEtkinYetkileri AS SELECT KullaniciId,YetkiKodu,Yetkili FROM dbo.TestYetki");
   var production=new SektorUretimServisi(cs,1);production.Kur();production.Kur();Check(Convert.ToInt32(Scalar(c,"SELECT COUNT(*) FROM dbo.BERP_Sema WHERE Surum=200"))==1,"Finans tabloları olmadan sektör üretim kurulumu");
   long recipe=production.ReceteKaydet("SUN-1","Açık birimli sünger",1,10,"SUNGER",[new(2,10.5m),new(3,2)]);
   Guid pkey=Guid.NewGuid();production.Uret(pkey,recipe,2,"U-1");Check(Balance(c,1)==2&&Balance(c,2)==976.9m&&Balance(c,3)==45.6m,"KG ve M2 girdilerden açık M3 üretimi");
   long movements=Convert.ToInt64(Scalar(c,"SELECT COUNT_BIG(*) FROM dbo.StokHareketleri"));production.Uret(pkey,recipe,2,"U-1");Check(Convert.ToInt64(Scalar(c,"SELECT COUNT_BIG(*) FROM dbo.StokHareketleri"))==movements,"Aynı üretim iki kez stok yazmaz");
   Reject(()=>production.Uret(pkey,recipe,3,"U-1"),"Aynı anahtar farklı üretimde reddedilir");Reject(()=>production.Uret(Guid.NewGuid(),recipe,1000,"U-2"),"Yetersiz girdide üretim iptal");Check(Balance(c,1)==2&&Balance(c,2)==976.9m,"Başarısız üretimde stok değişmez");
   Reject(()=>new SektorUretimServisi(cs,2).Uret(Guid.NewGuid(),recipe,1,"X"),"Yetkisiz üretim kapalı");
   Sql(c,"""
    CREATE TABLE dbo.FinansHesaplari(Id int PRIMARY KEY,HesapAdi nvarchar(100),ParaBirimi nvarchar(3),Aktif bit);INSERT dbo.FinansHesaplari VALUES(1,N'Test kasa',N'TRY',1),(2,N'EUR kasa',N'EUR',1);
    CREATE TABLE dbo.FinansHareketleri(Id bigint IDENTITY PRIMARY KEY,HesapId int,CariId int NULL,CariHareketId bigint NULL,Tarih date,HareketTipi nvarchar(20),Tutar decimal(18,2),Aciklama nvarchar(500),YapanKullaniciId int,TersKayitId bigint NULL);
    CREATE UNIQUE INDEX UX_TestTers ON dbo.FinansHareketleri(TersKayitId)WHERE TersKayitId IS NOT NULL;
    """);
   var r=new RestoranServisi(cs,1);r.Kur();r.Kur();Check(Convert.ToInt32(Scalar(c,"SELECT COUNT(*) FROM dbo.BERP_Sema WHERE Surum=201"))==1,"Restoran kurulumunu tekrar çalıştırma");
   long food=production.ReceteKaydet("YEMEK-1","Porsiyon reçetesi",4,0,"RESTORAN",[new(5,.2m)]);r.MasaKaydet("Masa 1");r.MasaKaydet("Masa 2");r.MenuKaydet("Test yemek",4,food,100);
   int menu=(int)r.Oku("menu").Rows[0]["Id"];Guid billKey=Guid.NewGuid();long bill=r.Ac(billKey,1);Check(r.Ac(billKey,1)==bill,"Adisyon açma idempotent");Reject(()=>r.Ac(Guid.NewGuid(),1),"Masada ikinci açık adisyon engellenir");
   Guid itemKey=Guid.NewGuid();long item=r.KalemEkle(itemKey,bill,Version(r,bill),menu,2);Check(r.KalemEkle(itemKey,bill,Version(r,bill),menu,2)==item,"Sipariş kalemi idempotent");Reject(()=>r.KalemEkle(itemKey,bill,Version(r,bill),menu,3),"Farklı miktarla aynı kalem anahtarı reddedilir");
   long cancelled=r.KalemEkle(Guid.NewGuid(),bill,Version(r,bill),menu,1);r.KalemIptal(bill,Version(r,bill),cancelled);Check(Convert.ToDecimal(r.Oku("adisyon").AsEnumerable().Single(x=>(long)x["Id"]==bill)["Toplam"])==200,"İptal edilen kalem adisyon tutarına katılmaz");
   var menuVersion=(byte[])r.Oku("menu").Rows[0]["Surum"];r.MenuKaydet("Test yemek",4,food,120,menu,menuVersion);Reject(()=>r.MenuKaydet("Test yemek",4,food,130,menu,menuVersion),"Eski menü sürümü fiyat değiştiremez");Check(Convert.ToDecimal(r.Oku("kalem",bill).Rows[0]["BirimFiyat"])==100,"Yeni menü fiyatı önceki siparişi değiştirmez");
   byte[] stale=Version(r,bill);r.Mutfak(bill,stale,false);Check(r.Oku("mutfak").Rows.Count==1&&(string)r.Oku("mutfak").Rows[0]["MutfakDurumu"]=="Hazırlanıyor","Mutfak siparişi gönderilir, iptal kalem gönderilmez");Reject(()=>r.KalemIptal(bill,Version(r,bill),item),"Hazırlanan kalem basit iptalle silinemez");Reject(()=>r.Mutfak(bill,stale,true),"Eski adisyon sürümü reddedilir");r.Mutfak(bill,Version(r,bill),true);
   Reject(()=>r.Odeme(Guid.NewGuid(),bill,Version(r,bill),2,10,"Nakit","DOVIZ"),"Farklı döviz kasa seçilemez");
   Guid partialKey=Guid.NewGuid();r.Odeme(partialKey,bill,Version(r,bill),1,30,"Nakit","P1");Check(Balance(c,5)==10,"Kısmi ödemede stok henüz düşmez");
   Reject(()=>r.KalemEkle(Guid.NewGuid(),bill,Version(r,bill),menu,1),"Ödeme başladıktan sonra adisyon değişmez");
   Guid finalKey=Guid.NewGuid();r.Odeme(finalKey,bill,Version(r,bill),1,170,"Kart","POS1");Check(Balance(c,5)==9.6m,"Son ödemede reçete girdisi bir kez düşer");Check((string)r.Oku("adisyon").AsEnumerable().Single(x=>(long)x["Id"]==bill)["Durum"]=="Ödendi","Tam ödemede adisyon kapanır");
   long financeCount=Convert.ToInt64(Scalar(c,"SELECT COUNT_BIG(*) FROM dbo.FinansHareketleri"));r.Odeme(finalKey,bill,Version(r,bill),1,170,"Kart","POS1");Check(Convert.ToInt64(Scalar(c,"SELECT COUNT_BIG(*) FROM dbo.FinansHareketleri"))==financeCount&&Balance(c,5)==9.6m,"Ödeme tekrarı tahsilat/stok çoğaltmaz");
   Check(Convert.ToDecimal(Scalar(c,"SELECT SUM(Tutar)FROM dbo.FinansHareketleri WHERE HareketTipi=N'Giriş'"))==200,"Restoran tahsilatı mevcut finans kayıtlarına yansır");
   r.IptalVeyaIade(bill,Version(r,bill),"Test iadesi");Check(Balance(c,5)==9.6m,"Ücret iadesi hammaddeleri geri üretmez");Check(Convert.ToDecimal(Scalar(c,"SELECT SUM(CASE WHEN HareketTipi=N'Giriş' THEN Tutar ELSE -Tutar END)FROM dbo.FinansHareketleri"))==0,"Tam iadede finans neti sıfır");
   long after=Convert.ToInt64(Scalar(c,"SELECT COUNT_BIG(*)FROM dbo.FinansHareketleri"));r.IptalVeyaIade(bill,Version(r,bill),"Tekrar");Check(Convert.ToInt64(Scalar(c,"SELECT COUNT_BIG(*)FROM dbo.FinansHareketleri"))==after,"İade tekrarı çift ödeme yazmaz");
   Check(Convert.ToDecimal(r.Oku("adisyon").AsEnumerable().Single(x=>(long)x["Id"]==bill)["Kalan"])==0,"İptal/iade adisyonunda borç kalmaz");
   long bill2=r.Ac(Guid.NewGuid(),2);r.KalemEkle(Guid.NewGuid(),bill2,Version(r,bill2),menu,1000);Check(Convert.ToDecimal(r.Oku("kalem",bill2).Rows[0]["BirimFiyat"])==120,"Yeni sipariş güncel menü fiyatını alır");Reject(()=>r.Odeme(Guid.NewGuid(),bill2,Version(r,bill2),1,120000,"Nakit","YETERSIZ"),"Yetersiz stokta son ödeme geri alınır");Check(r.Oku("odeme",bill2).Rows.Count==0&&Balance(c,5)==9.6m,"Başarısız tahsilatta ödeme/stok değişmez");
   Reject(()=>new RestoranServisi(cs,2).Ac(Guid.NewGuid(),1),"Yetkisiz restoran işlemi reddedilir");
   foreach(var (section,sector) in new[]{("uretim","SUNGER"),("uretim","RESTORAN"),("satis","RESTORAN")}){var definition=MobilRaporOku.Tanim(section,sector);using var query=new SqlCommand(definition.Sorgu,c);using var reader=query.ExecuteReader();Check(reader.FieldCount>0,"Mobil sektör raporu SQL doğrulaması: "+sector+" / "+section);}
   SahaTests(c,cs);MobilTests220.Run(c,cs).GetAwaiter().GetResult();SahaIlTestleri222.Run(c,cs).GetAwaiter().GetResult();if(args.Contains("--lan"))LanTests221.Run(cs).GetAwaiter().GetResult();
   var app=new Application{ShutdownMode=ShutdownMode.OnExplicitShutdown};app.Resources.MergedDictionaries.Add(new ResourceDictionary{Source=new Uri("pack://application:,,,/MiapaxERP.Desktop;component/Assets/ModernKontroller.xaml")});Tema170.Uygula(new());
   if(args.Contains("--saha-ui")){
    Console.WriteLine("SAHA UI TESTİ — yalnız izole test veritabanı: "+dbName);
    new SahaPenceresi(cs,1){Title="TEST — Saha pazarlama — izole veritabanı"}.ShowDialog();
    Check(Convert.ToInt32(Scalar(c,"SELECT COUNT(*) FROM dbo.BERP210_SahaMusteri WHERE Ad=N'TEST UI çiftçi'"))==1,"WebView müşteri formu SQL'e kaydedildi");
    Check(Convert.ToInt32(Scalar(c,"SELECT COUNT(*) FROM dbo.BERP210_Gorusme g JOIN dbo.BERP210_SahaMusteri m ON m.Id=g.MusteriId WHERE m.Ad=N'TEST UI çiftçi'"))>=2,"WebView üzerinden tarihli iki görüşme kaydedildi");
    app.Shutdown();Console.WriteLine("PASSED SAHA UI "+checks);return 0;
   }
   var sw=new SektorUretimPenceresi(cs,1,"SUNGER");sw.Show();sw.UpdateLayout();Capture(sw,"SektorUretim200.png");sw.Close();Check(true,"Sektör üretim ekranı açılır");
   var rw=new RestoranPenceresi(cs,1);rw.Show();rw.UpdateLayout();Capture(rw,"Restoran200.png");rw.Close();Check(true,"Restoran ekranı açılır");
   var main=(MainWindow)Activator.CreateInstance(typeof(MainWindow),BindingFlags.Instance|BindingFlags.NonPublic,null,new object[]{true},null)!;main.GorunumuUygula(new(){FirmaBasligi="Örnek Restoran",FirmaMetni="Taze ve lezzetli",FirmaAltMetni="İşletme yönetimi",Sektor="RESTORAN"});main.Show();main.UpdateLayout();Capture(main,"RestoranAnaSayfa200.png");main.Close();Check(true,"Özelleştirilmiş firma alanı ve sektör görünümü");app.Shutdown();
   Console.WriteLine("PASSED "+checks);return 0;
  }catch(Exception ex){Console.WriteLine(ex);return 1;}
  finally{if(master?.State==ConnectionState.Open&&System.Text.RegularExpressions.Regex.IsMatch(dbName,@"^MiapaxERP_Test200_[0-9a-f]{32}$")){SqlConnection.ClearAllPools();Sql(master,$"IF DB_ID('{dbName}') IS NOT NULL BEGIN ALTER DATABASE [{dbName}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;DROP DATABASE [{dbName}];END");master.Dispose();}}
 }
 static void SahaTests(SqlConnection c,string cs){
  var s=new SahaServisi(cs,1);s.Kur();s.Kur();Check(Convert.ToInt32(Scalar(c,"SELECT COUNT(*) FROM dbo.BERP_Sema WHERE Surum=210"))==1,"Saha şeması tekrar güvenle kurulabilir");
  var m=new SahaMusterisi(Guid.NewGuid(),"TR-P-38","TR-D-38-001","Test Köyü","TEST çiftçi","05000000000",25,"dekar","Mısır",30,"m³/saat",null,"Damlama","Kuyu","Test müşteri açıklaması");
  Reject(()=>SahaServisi.Dogrula(m with{Alan=-1}),"Negatif tarla alanı reddedilir");Reject(()=>SahaServisi.Dogrula(m with{DebiBirimi="tahmin"}),"Belirsiz debi birimi reddedilir");Reject(()=>SahaServisi.Dogrula(m with{Telefon="abc"}),"Geçersiz cep telefonu reddedilir");
  s.Kaydet(m,null,Guid.NewGuid(),DateTimeOffset.UtcNow.AddMinutes(-1),"İlk görüşme olumlu; teklif hazırlanacak.");Check(s.Liste(m.IlId,m.IlceId,m.Koy).Length==1,"Saha müşterisi seçili köyde listelenir");Check(s.Liste(m.IlId,m.IlceId,"Başka Köy").Length==0,"Saha müşterileri köye göre ayrılır");
  var first=JsonSerializer.SerializeToElement(s.Oku(m.Id),SahaServisi.Json);Check(first.GetProperty("data").GetProperty("basinc").ValueKind==JsonValueKind.Null,"Bilinmeyen basınç tahmin edilmez");string v=first.GetProperty("version").GetString()!;
  s.Kaydet(m with{Aciklama="Güncellenmiş açıklama"},v,Guid.NewGuid(),DateTimeOffset.UtcNow,"İkinci görüşme; ölçüm beklenecek.");var second=JsonSerializer.SerializeToElement(s.Oku(m.Id),SahaServisi.Json);Check(second.GetProperty("visits").GetArrayLength()==2,"Görüşme geçmişi silinmeden saklanır");
  Reject(()=>s.Kaydet(m,v,Guid.NewGuid(),DateTimeOffset.UtcNow,"Eski sürüm"),"Eski müşteri sürümü güncellenemez");Check(JsonSerializer.SerializeToElement(s.Oku(m.Id),SahaServisi.Json).GetProperty("visits").GetArrayLength()==2,"Başarısız kayıtta görüşme eklenmez");
  Reject(()=>s.Kaydet(m,null,Guid.NewGuid(),DateTimeOffset.UtcNow,"Tekrar"),"Aynı müşteri kimliği çift kayıt oluşturmaz");Reject(()=>new SahaServisi(cs,2).Liste(m.IlId,m.IlceId,m.Koy),"Yetkisiz kullanıcı saha bilgilerini okuyamaz");
  Reject(()=>ParselServisi.AdresDogrula("http://example.test/parcel"),"Parsel bağlantısı HTTPS gerektirir");Reject(()=>ParselServisi.AdresDogrula("https://user:password@example.test/parcel"),"Parsel URL içinde parola reddedilir");Check(ParselServisi.AdresDogrula("https://example.test/parcel").Scheme=="https","Yetkili parsel adresi doğrulanır");
 }
 static async Task<int> Live(bool denied)
 {
    Check(LisansOturumu.Zorunlu,"Canlı doğrulamada müşteri derlemesi");
    LisansOturumu.Hazirla("Server=localhost;Database=MiapaxERP_ClientSmokeOnly;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;");
    if(denied){Check(!await LisansOturumu.YenileAsync(),"Canlı askı/iptal yanıtı müşteriyi durdurur");Check(LisansOturumu.Gecerli is null&&!LisansOturumu.ModulVar("STOK"),"Eski imzalı izin sunucu reddinden sonra kullanılamaz");return 0;}
    string path=Path.GetFullPath(Path.Combine(AppContext.BaseDirectory,"../../../../LisansPaneli/.test-results/live-test-key.txt"));
    Check(await LisansOturumu.YenileAsync(File.ReadAllText(path)),"Canlı sunucu lisansı doğrular ve Windows şifreli önbelleğine yazar");
    Check(LisansOturumu.ModulVar("STOK")&&!LisansOturumu.ModulVar("URETIM"),"Canlı panelde seçilmeyen modül kapalı kalır");
    Reject(()=>LisansOturumu.Gerekli("URETIM"),"Canlı stok lisansı üretim açamaz");
    Check(await LisansOturumu.YenileAsync(),"Cihaz sınırı doluyken kayıtlı cihazın canlı yenilemesi");
    using var http=new System.Net.Http.HttpClient();using var r=await System.Net.Http.Json.HttpClientJsonExtensions.PostAsJsonAsync(http,LisansOturumu.Sunucu+"/api/activate",new{licenseKey=File.ReadAllText(path),deviceId=new string('E',64),databaseId=LisansOturumu.VeritabaniKimligi,deviceName="TEST ikinci cihaz"});
    Check(r.StatusCode==System.Net.HttpStatusCode.Forbidden,"Canlı servis ikinci cihazı reddeder");
    Console.WriteLine("PASSED LIVE "+checks);return 0;
 }
 static void Core()
 {
  Check(SektorUretimServisi.TuketimHesapla(.123456m,2.5m,10)==.34m,"Açık birimli reçete hassasiyetli tüketim");Reject(()=>UrunKatalogu.ModulDogrula(["RESTORAN"]),"Restoran lisans bağımlılıkları");
  using var rsa=RSA.Create(3072);var now=DateTimeOffset.UtcNow;var p=new LisansIcerigi(1,Guid.NewGuid().ToString(),Guid.NewGuid().ToString(),"Test Firma","GENEL",["STOK"],new string('A',64),new string('B',64),now,now.AddDays(-1),null,now.AddDays(7),1);var signed=LisansKripto.Imzala(p,rsa);
  Check(LisansKripto.Dogrula(signed,rsa.ExportSubjectPublicKeyInfoPem(),p.DeviceId,p.DatabaseId,now).Company=="Test Firma",".NET RSA-PSS doğrulama");Reject(()=>LisansKripto.Dogrula(signed with{Payload=Convert.ToBase64String("{}"u8)},rsa.ExportSubjectPublicKeyInfoPem(),p.DeviceId,p.DatabaseId,now),"Lisans içeriği değiştirilemez");Reject(()=>LisansKripto.Dogrula(signed,rsa.ExportSubjectPublicKeyInfoPem(),"other",p.DatabaseId,now),"Başka cihaz lisansı reddedilir");Reject(()=>LisansKripto.Dogrula(signed,rsa.ExportSubjectPublicKeyInfoPem(),p.DeviceId,p.DatabaseId,now.AddDays(8)),"Çevrimdışı süresi dolan lisans reddedilir");
  var nodeDir=Environment.GetEnvironmentVariable("MiapaxERP_TEST_FIXTURES")??Path.Combine(AppContext.BaseDirectory,"Fixtures");var e=JsonSerializer.Deserialize<ImzaliLisans>(File.ReadAllText(Path.Combine(nodeDir,"envelope.json")),LisansKripto.Json)!;var payload=JsonSerializer.Deserialize<LisansIcerigi>(Convert.FromBase64String(e.Payload),LisansKripto.Json)!;
  Check(LisansKripto.Dogrula(e,File.ReadAllText(Path.Combine(nodeDir,"public.pem")),payload.DeviceId,payload.DatabaseId,payload.IssuedAt).LicenseId==payload.LicenseId,"Worker WebCrypto imzası .NET tarafından doğrulanır");
  var preferences=new GorunumTercihleri{FirmaBasligi="Restoran",FirmaMetni="Özel slogan",Sektor="RESTORAN",FirmaLogoBoyutu=90};preferences.Dogrula();Check(preferences.Kopya().FirmaMetni=="Özel slogan","Yeni firma yazısı ayarlarda saklanır");Reject(()=>new GorunumTercihleri{FirmaLogoGoster=false,FirmaAdiGoster=false}.Dogrula(),"Logo ve firma adı birlikte gizlenemez");
 }
 static void Capture(Window w,string name){Directory.CreateDirectory("Sonuclar200");var b=new RenderTargetBitmap((int)w.ActualWidth,(int)w.ActualHeight,96,96,PixelFormats.Pbgra32);b.Render(w);var e=new PngBitmapEncoder();e.Frames.Add(BitmapFrame.Create(b));using var f=File.Create(Path.Combine("Sonuclar200",name));e.Save(f);}
}
