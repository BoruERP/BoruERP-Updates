using System.Data;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using MiapaxERP.Desktop;
using Microsoft.Data.SqlClient;
static class MobilTests220{
 static int n;static void Check(bool x,string s){if(!x)throw new Exception(s);n++;Console.WriteLine("PASS MOBIL "+s);}
 static void Reject(Action a,string s){try{a();}catch(Exception e)when(e is UnauthorizedAccessException or ArgumentException or InvalidOperationException or SqlException){Check(true,s);return;}throw new Exception(s);}
 static JsonElement J(object o)=>JsonSerializer.SerializeToElement(o,SahaServisi.Json);
 public static async Task Run(SqlConnection c,string cs){
  var h=new MobilHesapServisi(cs);h.Kur(1);h.Kur(1);Reject(()=>h.Kaydet(2,2,"Yetkisiz","PATRON"),"Çalışan kendine patron rolü açamaz");
  using(var q=new SqlCommand("INSERT dbo.Kullanicilar VALUES(3,1)",c))q.ExecuteNonQuery();
  var a=h.Kaydet(1,2,"Satışçı A","SAHA");var b=h.Kaydet(1,3,"Satışçı B","SAHA");var boss=h.Kaydet(1,1,"Patron","PATRON");
  string code=h.Esle(1,a);var paired=J(h.Bagla(code,"Test A"));string token=paired.GetProperty("token").GetString()!;Reject(()=>h.Bagla(code,"Tekrar"),"Eşleme kodu tek kullanımlık");
  string codeB=h.Esle(1,b);string tokenB=J(h.Bagla(codeB,"Test B")).GetProperty("token").GetString()!;
  string bossToken=J(h.Bagla(h.Esle(1,boss),"Patron cihazı")).GetProperty("token").GetString()!;
  var ka=h.Dogrula(token);var kb=h.Dogrula(tokenB);var kp=h.Dogrula(bossToken);
  var sa=new SahaServisi(cs,2,ka);var sb=new SahaServisi(cs,3,kb);var sp=new SahaServisi(cs,1,kp);
  var m=new SahaMusterisi(Guid.NewGuid(),"TR-P-38","TR-D-38-001","Mobil test köyü","Satışçı A müşterisi","05001234567",3,"dekar","Buğday",null,"m³/saat",null,"Damlama","Kuyu","Mobil test");
  var op=Guid.NewGuid();var visit=Guid.NewGuid();var date=DateTimeOffset.UtcNow.AddMinutes(-1);string version=sa.Kaydet(m,null,visit,date,"İlk görüşme",op);
  Check(sa.Kaydet(m,null,visit,date,"İlk görüşme",op)==version,"Yanıt kaybolsa da tekrar aynı sonucu verir");
  Reject(()=>sa.Kaydet(m with{Ad="Farklı"},null,visit,date,"İlk görüşme",op),"Aynı işlem kimliği farklı içerikle kullanılamaz");
  Check(sa.Liste(m.IlId,m.IlceId,m.Koy).Length==1&&sb.Liste(m.IlId,m.IlceId,m.Koy).Length==0,"Satışçı yalnız kendi müşterisini listeler");
  Reject(()=>sb.Oku(m.Id),"Başkasının müşteri kimliğiyle ayrıntı açılamaz");Reject(()=>sb.Kaydet(m with{Ad="Saldırı"},version,Guid.NewGuid(),date,"",Guid.NewGuid()),"Başkasının kaydı doğru sürümle bile değiştirilemez");
  Check(sp.Liste(m.IlId,m.IlceId,m.Koy).Length==1,"Patron tüm saha müşterilerini görür");
  string v2=sa.Kaydet(m with{Ad="Güncel"},version,Guid.NewGuid(),date,"Takip görüşmesi",Guid.NewGuid());Reject(()=>sa.Kaydet(m,version,Guid.NewGuid(),date,"",Guid.NewGuid()),"Eski sürüm güncel kaydın üzerine yazamaz");
  var loaded=J(sp.Oku(m.Id));Check(loaded.GetProperty("visits").GetArrayLength()==2,"İki görüşme var; tekrarlanan istek çoğaltmaz");
  Reject(()=>new SahaServisi(cs,2,ka with{Rol="PATRON"}).Oku(m.Id),"İstemci rol değiştirse de sunucu reddeder");
  await using var app=MobilApi220.Olustur(cs,5199);await app.StartAsync();using var http=new HttpClient{BaseAddress=new Uri("http://127.0.0.1:5199")};
  Check((await http.GetAsync("/api/mobile/v2/profile")).StatusCode==HttpStatusCode.Forbidden,"HTTP kimliksiz erişim kapalı");
  http.DefaultRequestHeaders.Authorization=new("Bearer",token);Check((await http.GetAsync("/api/mobile/v2/profile")).IsSuccessStatusCode,"HTTP cihaz profili doğrulanır");
  Check((await http.PostAsJsonAsync("/api/mobile/v2/rpc",new{action="report",section="muhasebe"})).StatusCode==HttpStatusCode.Forbidden,"Saha hesabı muhasebe raporunu çağıramaz");
  Check((await http.PostAsJsonAsync("/api/mobile/v2/rpc",new{action="load",id=m.Id})).IsSuccessStatusCode,"HTTP kendi müşteri ayrıntısı açılır");
  http.DefaultRequestHeaders.Authorization=new("Bearer",tokenB);Check((await http.PostAsJsonAsync("/api/mobile/v2/rpc",new{action="load",id=m.Id})).StatusCode==HttpStatusCode.BadRequest,"HTTP başka satışçının müşteri ayrıntısı kapalı");
  http.DefaultRequestHeaders.Authorization=new("Bearer",bossToken);
  Check((await http.PostAsJsonAsync("/api/mobile/v2/rpc",new{action="report",section="stok"})).IsSuccessStatusCode,"Patron mevcut stok raporunu okuyabilir");
  var pending=m with{Id=Guid.NewGuid(),Ad="HTTP kaydı"};var req=new{action="save",data=pending,version=(string?)null,visitId=Guid.NewGuid(),visitDate=date,visit="HTTP görüşme",operation=Guid.NewGuid()};
  http.DefaultRequestHeaders.Authorization=new("Bearer",token);
  var first=await http.PostAsJsonAsync("/api/mobile/v2/rpc",req);var repeat=await http.PostAsJsonAsync("/api/mobile/v2/rpc",req);
  Check(first.IsSuccessStatusCode&&repeat.IsSuccessStatusCode&&await first.Content.ReadAsStringAsync()==await repeat.Content.ReadAsStringAsync(),"HTTP tekrar gönderim aynı sürümü döndürür");
  using(var count=new SqlCommand("SELECT COUNT(*) FROM dbo.BERP210_Gorusme WHERE MusteriId=@id",c)){count.Parameters.AddWithValue("@id",pending.Id);Check(Convert.ToInt32(count.ExecuteScalar())==1,"HTTP tekrarında tek görüşme yazılır");}
  Check((await http.PostAsJsonAsync("/api/mobile/v2/rpc",new{action="save"})).StatusCode==HttpStatusCode.BadRequest,"Eksik JSON alanı 400 olarak reddedilir");
  string expired=h.Esle(1,b);using(var expire=new SqlCommand("UPDATE dbo.BERP220_Esleme SET Bitis=DATEADD(minute,-1,SYSUTCDATETIME())",c))expire.ExecuteNonQuery();Reject(()=>h.Bagla(expired,"Süresi dolmuş"),"Süresi dolmuş eşleme kodu kapalı");
  h.Kaydet(1,3,"Patron B","PATRON");http.DefaultRequestHeaders.Authorization=new("Bearer",tokenB);
  Check((await http.PostAsJsonAsync("/api/mobile/v2/rpc",new{action="report",section="muhasebe"})).StatusCode==HttpStatusCode.Forbidden,"Patron rolü ERP finans yetkisini aşamaz");
  using(var disable=new SqlCommand("UPDATE dbo.Kullanicilar SET Aktif=0 WHERE Id=3",c))disable.ExecuteNonQuery();
  Check((await http.GetAsync("/api/mobile/v2/profile")).StatusCode==HttpStatusCode.Forbidden,"ERP kullanıcısı kapatıldığında mobil cihaz da kapanır");
  h.Iptal(1,a);Reject(()=>sa.Kaydet(m,v2,Guid.NewGuid(),date,"",Guid.NewGuid()),"İptal edilen cihaz servis katmanında yazamaz");
  http.DefaultRequestHeaders.Authorization=new("Bearer",token);Check((await http.GetAsync("/api/mobile/v2/profile")).StatusCode==HttpStatusCode.Forbidden,"HTTP cihaz iptali anında uygulanır");
  h.Kaydet(1,2,"A","SAHA");Reject(()=>h.Dogrula(token),"Hesap yeniden açılsa da eski cihaz açılmaz");
  await app.StopAsync();Console.WriteLine("PASSED MOBILE220 "+n);
 }
}
