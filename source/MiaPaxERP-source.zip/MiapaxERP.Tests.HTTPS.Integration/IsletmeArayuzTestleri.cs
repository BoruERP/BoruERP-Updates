using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using MiapaxERP.Desktop;
using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;
public sealed class IsletmeArayuzTestleri
{
    [Fact] public async Task MenuVeFormlarSqlBaglantisiOlmadanOlusturulur()
    {
        var result=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);var thread=new Thread(()=>{try{
            var main=new MainWindow(true);var menu=Assert.IsType<WrapPanel>(main.FindName("TemaMenuOgeleri"));var names=menu.Children.OfType<Button>().Select(b=>Convert.ToString(b.Content)).ToArray();foreach(string name in new[]{"Sevkiyat ve kantar","Boru basınç testleri","Depo · raf · parti","Satın alma eşleştirme","Genel muhasebe","Makine ve kapasite","MRP ve üretim maliyeti"})Assert.Contains(name,names);
            var form=new IsletmeForm(null!,"Sunum kontrolü · sevkiyat");form.Text("no","Sevkiyat numarası","SVK-2026-001");form.Text("customer","Müşteri","Örnek müşteri");form.Text("from","Nereden","İstanbul fabrikası");form.Text("to","Nereye","Ankara depo");form.Date("date","Sevkiyat tarihi",new DateTime(2026,11,13));form.Choice("transport","Taşıma şekli",new[]{"Karayolu","Denizyolu"});form.Text("plate","Araç plakası","34 ABC 123");form.Text("driver","Şoför","Örnek şoför");form.Number("empty","Boş ağırlık (KG)",5000);form.Number("full","Dolu ağırlık (KG)",6500);
            var visual=(FrameworkElement)form.Content;visual.Measure(new Size(980,760));visual.Arrange(new Rect(0,0,980,760));visual.UpdateLayout();var bitmap=new RenderTargetBitmap(980,760,96,96,PixelFormats.Pbgra32);bitmap.Render(visual);string folder=Path.Combine(AppContext.BaseDirectory,"TestResults","Ui");Directory.CreateDirectory(folder);var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(bitmap));using(var file=File.Create(Path.Combine(folder,"sevkiyat-form.png")))encoder.Save(file);Assert.True(new FileInfo(Path.Combine(folder,"sevkiyat-form.png")).Length>1000);form.Close();main.Close();result.SetResult();
        }catch(Exception e){result.SetException(e);}});thread.SetApartmentState(ApartmentState.STA);thread.Start();await result.Task.WaitAsync(TimeSpan.FromSeconds(45));
    }
    [Fact] public void SaglayiciSonucunuIstemciDegistiremez(){foreach(string name in new[]{"EbelgeDeposu.Baslat","EbelgeDeposu.Sonuc","EbelgeDeposu.SorguKaydet","EbelgeDeposu.BelgeAl"})Assert.DoesNotContain(name,HttpsIslemKatalogu.Adlar);foreach(string name in new[]{"EbelgeHttpsServisi.Gonder","EbelgeHttpsServisi.YerelSorgula","EbelgeHttpsServisi.BelgeAl"})Assert.Contains(name,HttpsIslemKatalogu.Adlar);}
}



