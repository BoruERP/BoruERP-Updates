using System.IO;
using System.Text.Json;
using Microsoft.Data.SqlClient;
using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;

public sealed class WindowsBaglantiTestleri
{
    static void Sonuc(string name,bool ok,Exception? error=null)
    {
        string folder=Path.Combine(AppContext.BaseDirectory,"TestResults","Connection");Directory.CreateDirectory(folder);
        File.WriteAllText(Path.Combine(folder,name+".json"),JsonSerializer.Serialize(new{test=name,ok,tarih=DateTimeOffset.UtcNow,error=error?.ToString()},new JsonSerializerOptions{WriteIndented=true}));
    }
    [Fact]
    public async Task Gercek_Https_Sertifika_Ve_Alan_Adi_Dogrulamasi()
    {
        try{await HttpsTlsTestleri.Run();Sonuc("TLS",true);}
        catch(Exception e){Sonuc("TLS",false,e);throw;}
    }
    [Fact]
    public async Task Gercek_Sql_Sifreli_Baglanti_Salt_Okunur_Kontrol()
    {
        try
        {
            await using var c=new SqlConnection(Environment.GetEnvironmentVariable("MIAPAX_TEST_SQL")??"Server=localhost;Database=master;Integrated Security=true;Encrypt=true;TrustServerCertificate=true;Connect Timeout=5;Pooling=false");
            await c.OpenAsync();using var q=new SqlCommand("SELECT CAST(1 AS int)",c);Assert.Equal(1,Convert.ToInt32(await q.ExecuteScalarAsync()));Sonuc("SQL",true);
        }
        catch(Exception e){Sonuc("SQL",false,e);throw;}
    }
}

