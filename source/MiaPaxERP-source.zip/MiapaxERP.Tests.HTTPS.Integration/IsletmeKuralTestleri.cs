using System.Data;
using System.Text.Json;
using MiapaxERP.Desktop;
using Xunit;
namespace MiapaxERP.Tests.HTTPS.Integration;
public sealed class IsletmeKuralTestleri
{
    static MuhasebeFisi Fis(decimal debit,decimal credit)=>new(Guid.NewGuid(),DateTime.Today,"Test fişi",new[]{new MuhasebeKalemi("100",debit,0,null,"Kasa"),new MuhasebeKalemi("500",0,credit,null,"Sermaye")});
    [Fact] public void DengeliFisKabulEdilir()=>IsletmeServisi.FisDogrula(Fis(100,100));
    [Theory][InlineData(100,99.99)][InlineData(-1,-1)][InlineData(0,0)][InlineData(1.001,1.001)] public void GecersizFisEngellenir(decimal debit,decimal credit)=>Assert.Throws<ArgumentException>(()=>IsletmeServisi.FisDogrula(Fis(debit,credit)));
    [Fact] public void AyniKalemdeBorcVeAlacakEngellenir(){var g=Fis(100,100) with{Kalemler=new[]{new MuhasebeKalemi("100",100,100,null,"hatalı"),new MuhasebeKalemi("500",0,1,null,"test")}};Assert.Throws<ArgumentException>(()=>IsletmeServisi.FisDogrula(g));}
    static SevkiyatGirdisi Shipment()=>new(Guid.NewGuid(),null,null,"SVK-1",1,"Fabrika","Müşteri",DateTime.Today,"Karayolu","34 ABC 123","Şoför","",5000,6000,null,new[]{new SevkiyatKalemi(1,null,1,10)},"");
    [Fact] public void SevkiyatAgirlikVeSoforDogrulanir(){IsletmeServisi.SevkiyatDogrula(Shipment());Assert.Throws<ArgumentException>(()=>IsletmeServisi.SevkiyatDogrula(Shipment() with{DoluKg=4000}));Assert.Throws<ArgumentException>(()=>IsletmeServisi.SevkiyatDogrula(Shipment() with{Sofor=""}));}
    [Theory][InlineData(0)][InlineData(-1)][InlineData(0.0001)] public void SevkiyatMiktariDogrulanir(decimal qty)=>Assert.Throws<ArgumentException>(()=>IsletmeServisi.SevkiyatDogrula(Shipment() with{Kalemler=new[]{new SevkiyatKalemi(1,null,1,qty)}}));
    [Fact] public void MedyaIcerigiVeUzantisiUyusmali(){byte[] bytes=new byte[20];new byte[]{137,80,78,71,13,10,26,10}.CopyTo(bytes,0);Assert.Equal("image/png",IsletmeServisi.MedyaDogrula(new("foto.png","image/png",bytes)));Assert.Throws<ArgumentException>(()=>IsletmeServisi.MedyaDogrula(new("foto.mp4","video/mp4",bytes)));Assert.Throws<ArgumentException>(()=>IsletmeServisi.MedyaDogrula(new("../foto.png","image/png",bytes)));}
    [Fact] public void KapasiteHazirlikVeBirimSuresiniKapsar(){var g=new KapasiteGirdisi(Guid.NewGuid(),1,1,DateTimeOffset.Now,20,2,100,"Test");Assert.Equal(220,IsletmeServisi.KapasiteSuresi(g));Assert.Throws<ArgumentException>(()=>IsletmeServisi.KapasiteSuresi(g with{Miktar=1000}));}
    [Fact] public void HttpsTekSatirVeTupleVeriyiKorur(){var table=new DataTable();table.Columns.Add("Id",typeof(long));table.Columns.Add("Surum",typeof(byte[]));table.Rows.Add(12L,new byte[]{1,2,3,4,5,6,7,8});string json=JsonSerializer.Serialize<DataRow>(table.Rows[0],HttpsJson.Ayarlar);var row=JsonSerializer.Deserialize<DataRow>(json,HttpsJson.Ayarlar)!;Assert.Equal(12L,row["Id"]);Assert.Equal((byte[])table.Rows[0]["Surum"],(byte[])row["Surum"]);var pair=(Ad:"belge.pdf",Veri:new byte[]{1,2,3});var restored=JsonSerializer.Deserialize<(string Ad,byte[] Veri)>(JsonSerializer.Serialize(pair,HttpsJson.Ayarlar),HttpsJson.Ayarlar);Assert.Equal(pair.Ad,restored.Ad);Assert.Equal(pair.Veri,restored.Veri);}
    [Fact] public void TumIsletmeRpcMetotlariTamImzaliKayitli(){var types=typeof(IsletmeServisi).GetMethods(System.Reflection.BindingFlags.Public|System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.DeclaredOnly);Assert.NotEmpty(types);foreach(var m in types){Assert.Contains("IsletmeServisi."+m.Name,HttpsIslemKatalogu.Adlar);Assert.DoesNotContain(m.GetParameters(),p=>p.ParameterType.FullName?.Contains("SqlClient")==true);}}
}
