using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

Console.OutputEncoding = Encoding.UTF8;

string anahtarKlasoru = Path.Combine(
    Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
    "BoruERP_GizliAnahtarlar");

string ozelAnahtar = Path.Combine(anahtarKlasoru, "boruerp-private.pem");
string acikAnahtar = Path.Combine(anahtarKlasoru, "boruerp-public.pem");

Console.WriteLine("====================================");
Console.WriteLine("    MIAPAX ERP GUNCELLEME YAYIN ARACI");
Console.WriteLine("====================================");
Console.WriteLine();
Console.WriteLine("1 - RSA anahtarlarını kontrol et");
Console.WriteLine("2 - Güncelleme paketi imzala");
Console.WriteLine("0 - Çıkış");
Console.WriteLine();

Console.Write("Seçiminiz: ");
string? secim = Console.ReadLine();

if (secim == "0")
    return;

if (secim == "1")
{
    Console.WriteLine();

    if (!File.Exists(ozelAnahtar) || !File.Exists(acikAnahtar))
    {
        Console.WriteLine("HATA: RSA anahtarları bulunamadı.");
        return;
    }

    try
    {
        using RSA rsa = RSA.Create();
        rsa.ImportFromPem(File.ReadAllText(ozelAnahtar));

        using RSA publicRsa = RSA.Create();
        publicRsa.ImportFromPem(File.ReadAllText(acikAnahtar));

        byte[] test = Encoding.UTF8.GetBytes("MiapaxERP-Anahtar-Testi");

        byte[] imza = rsa.SignData(
            test,
            HashAlgorithmName.SHA256,
            RSASignaturePadding.Pss);

        bool dogru = publicRsa.VerifyData(
            test,
            imza,
            HashAlgorithmName.SHA256,
            RSASignaturePadding.Pss);

        Console.WriteLine(dogru
            ? "BAŞARILI: RSA anahtarları eşleşiyor."
            : "HATA: RSA anahtarları eşleşmiyor.");
    }
    catch (Exception ex)
    {
        Console.WriteLine("HATA: " + ex.Message);
    }

    return;
}

if (secim != "2")
{
    Console.WriteLine("Geçersiz seçim.");
    return;
}

if (!File.Exists(ozelAnahtar))
{
    Console.WriteLine("HATA: Özel RSA anahtarı bulunamadı.");
    return;
}

Console.Write("Güncelleme ZIP dosyasının tam yolu: ");
string zipYolu = (Console.ReadLine() ?? "").Trim().Trim('"');

if (!File.Exists(zipYolu))
{
    Console.WriteLine("HATA: ZIP dosyası bulunamadı.");
    return;
}

Console.Write("Sürüm numarası (örnek 1.5.1): ");
string surum = (Console.ReadLine() ?? "").Trim();

if (!Version.TryParse(surum, out Version? parsedVersion) ||
    parsedVersion.Major < 0 ||
    parsedVersion.Minor < 0 ||
    parsedVersion.Build < 0 ||
    parsedVersion.Revision > 0)
{
    Console.WriteLine("HATA: Sürüm numarası geçersiz. Örnek: 1.5.1");
    return;
}

Console.Write("Kanal (Ana/Yan): ");
string kanal = (Console.ReadLine() ?? "").Trim();

if (kanal != "Ana" && kanal != "Yan")
{
    Console.WriteLine("HATA: Kanal Ana veya Yan olmalıdır.");
    return;
}

Console.Write("GitHub paket indirme adresi (HTTPS): ");
string paketUrl = (Console.ReadLine() ?? "").Trim();

if (!Uri.TryCreate(paketUrl, UriKind.Absolute, out Uri? uri) ||
    uri.Scheme != Uri.UriSchemeHttps)
{
    Console.WriteLine("HATA: Geçerli bir HTTPS adresi girin.");
    return;
}

try
{
    Console.WriteLine("SHA-256 hesaplanıyor...");

    using FileStream stream = File.OpenRead(zipYolu);

    byte[] hashBytes = SHA256.HashData(stream);
    string sha256 = Convert.ToHexString(hashBytes).ToLowerInvariant();

    // MiapaxERP.GuncellemeYoneticisi.cs ile birebir aynı imza formatı.
    string payload =
        surum + "\n" +
        kanal + "\n" +
        paketUrl + "\n" +
        sha256 + "\n";

    using RSA rsa = RSA.Create();
    rsa.ImportFromPem(File.ReadAllText(ozelAnahtar));

    byte[] signature = rsa.SignData(
        Encoding.UTF8.GetBytes(payload),
        HashAlgorithmName.SHA256,
        RSASignaturePadding.Pss);

    // Oluşturulan imzayı açık anahtarla tekrar doğrula.
    using RSA publicRsa = RSA.Create();
    publicRsa.ImportFromPem(File.ReadAllText(acikAnahtar));

    if (!publicRsa.VerifyData(
        Encoding.UTF8.GetBytes(payload),
        signature,
        HashAlgorithmName.SHA256,
        RSASignaturePadding.Pss))
    {
        throw new CryptographicException(
            "İmza doğrulanamadı. Anahtarları kontrol edin.");
    }

    var manifest = new
    {
        Version = surum,
        Channel = kanal,
        PackageUrl = paketUrl,
        Sha256 = sha256,
        Signature = Convert.ToBase64String(signature)
    };

    string dosyaAdi = kanal == "Ana"
        ? "manifest-ana.json"
        : "manifest-yan.json";

    string ciktiKlasoru = Path.GetDirectoryName(
        Path.GetFullPath(zipYolu))!;

    string ciktiYolu = Path.Combine(ciktiKlasoru, dosyaAdi);

    string json = JsonSerializer.Serialize(
        manifest,
        new JsonSerializerOptions
        {
            WriteIndented = true
        });

    File.WriteAllText(ciktiYolu, json, Encoding.UTF8);

    Console.WriteLine();
    Console.WriteLine("====================================");
    Console.WriteLine("GÜNCELLEME PAKETİ İMZALANDI!");
    Console.WriteLine("====================================");
    Console.WriteLine("Sürüm: " + surum);
    Console.WriteLine("Kanal: " + kanal);
    Console.WriteLine("SHA-256: " + sha256);
    Console.WriteLine("Manifest: " + ciktiYolu);
    Console.WriteLine();
    Console.WriteLine("Özel anahtar pakete eklenmedi.");
}
catch (Exception ex)
{
    Console.WriteLine("HATA: " + ex.Message);
}