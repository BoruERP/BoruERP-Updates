using System.Diagnostics;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MiapaxERP.Guncelleme;
if(args.Length==3&&args[0]=="source")
{
 string source=Path.GetFullPath(args[1]);var skip=new HashSet<string>(new[]{"bin","obj",".git",".vs","node_modules",".test-results","test-results",".sites-checkout","AndroidAraclari","__pycache__",".gradle","build"},StringComparer.OrdinalIgnoreCase);var bad=new HashSet<string>(new[]{".dpapi",".sqlite",".sqlite3",".db",".mdf",".ldf",".bak",".jks",".pfx",".user",".suo",".zip",".apk",".aab",".log"},StringComparer.OrdinalIgnoreCase);int count=0;
 using var archive=new ZipArchive(File.Create(args[2]),ZipArchiveMode.Create);foreach(string file in Directory.GetFiles(source,"*",SearchOption.AllDirectories).OrderBy(x=>x,StringComparer.OrdinalIgnoreCase))
 {string rel=Path.GetRelativePath(source,file).Replace('\\','/');string name=Path.GetFileName(file);if(rel.Split('/').Any(skip.Contains)||rel.StartsWith("MobilKurulum/Sunucu/",StringComparison.OrdinalIgnoreCase)||rel.Contains("Assets/EBelge/aindoc/",StringComparison.Ordinal)||rel.Contains("Assets/EBelge/ommon/",StringComparison.Ordinal)||name.Contains("private",StringComparison.OrdinalIgnoreCase)||name.StartsWith(".env",StringComparison.OrdinalIgnoreCase)||name.Contains(".sqlite-",StringComparison.OrdinalIgnoreCase)||bad.Contains(Path.GetExtension(file)))continue;
  if(new[]{".cs",".js",".json",".txt",".pem",".ps1",".yml"}.Contains(Path.GetExtension(file),StringComparer.OrdinalIgnoreCase)&&System.Text.RegularExpressions.Regex.IsMatch(File.ReadAllText(file),"-----BEGIN (?:RSA )?PRIVATE KEY-----[\\r\\n]+[A-Za-z0-9+/=]{20}"))throw new Exception("Kaynak arşivi özel anahtar içeremez.");LegacyPath(rel);archive.CreateEntryFromFile(file,"MiapaxERP-2.8.1-Gelistirme/"+rel,CompressionLevel.Optimal);count++;
 }Console.WriteLine("Kaynak arşivi oluşturuldu. Dosya sayısı: "+count+"; derleme/özel veri dosyaları dışarıda.");return 0;
}
if(args.Length==3&&args[0]=="pack")
{
 string source=Path.GetFullPath(args[1]),output=Path.GetFullPath(args[2]);Directory.CreateDirectory(output);var list=Directory.GetFiles(source,"*",SearchOption.AllDirectories).Select(f=>(File:f,Relative:Path.GetRelativePath(source,f).Replace('\\','/'))).Where(x=>!x.Relative.EndsWith(".pdb",StringComparison.OrdinalIgnoreCase)&&!GuncellemeKanalAyari.KorunanDosya(Path.GetFileName(x.Relative))).ToArray();foreach(var file in list){UpdateSafety.ValidateRelative(file.Relative);LegacyPath(file.Relative); }
 foreach(string channel in new[]{"Ana","Yan"}){string path=Path.Combine(output,"MiapaxERP-"+channel+"-v2.8.1.zip");using var zip=new ZipArchive(File.Create(path),ZipArchiveMode.Create);foreach(var f in list)zip.CreateEntryFromFile(f.File,f.Relative,CompressionLevel.Optimal);
  var template=new{ManifestUrl="https://raw.githubusercontent.com/MiaPaxERP/MiapaxERP-Updates/main/manifest-"+channel.ToLowerInvariant()+".json",Channel=channel,Enabled=true};using(var w=new StreamWriter(zip.CreateEntry("MiapaxERP.kanal-sablonu.txt").Open(),new UTF8Encoding(false)))w.Write(JsonSerializer.Serialize(template));
  using(var w=new StreamWriter(zip.CreateEntry("IlkBaslat.cmd").Open(),Encoding.ASCII))w.Write("@echo off\r\nif not exist \"%~dp0MiapaxERP.guncelleme.json\" if not exist \"%~dp0MiaSoft.guncelleme.json\" if not exist \"%~dp0BoruERP.guncelleme.json\" copy /y \"%~dp0MiapaxERP.kanal-sablonu.txt\" \"%~dp0MiapaxERP.guncelleme.json\" >nul\r\nstart \"\" \"%~dp0MiapaxERP.Desktop.exe\"\r\n");
 }Console.WriteLine("Ana/Yan paketleri oluşturuldu; ayar, veritabanı veya özel anahtar içermez.");return 0;
}
if(args.Length>=3&&args[0]=="verify")
{
 var j=JsonDocument.Parse(File.ReadAllText(args[2])).RootElement;string S(string n)=>j.GetProperty(n).GetString()!;string hash=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[1]))).ToLowerInvariant();if(hash!=S("Sha256"))throw new Exception("Paket özeti uyuşmuyor.");using var rsa=RSA.Create();rsa.ImportFromPem(GuncellemeAnahtari.Pem);if(!rsa.VerifyData(Encoding.UTF8.GetBytes(S("Version")+"\n"+S("Channel")+"\n"+S("PackageUrl")+"\n"+hash+"\n"),Convert.FromBase64String(S("Signature")),HashAlgorithmName.SHA256,RSASignaturePadding.Pss))throw new Exception("İmza uyuşmuyor.");
 using var zip=ZipFile.OpenRead(args[1]);var paths=new HashSet<string>(StringComparer.OrdinalIgnoreCase);long total=0;foreach(var e in zip.Entries){LegacyPath(e.FullName);string rel=UpdateSafety.ValidateRelative(e.FullName);if(!paths.Add(rel))throw new Exception("Tekrarlı paket yolu.");total+=e.Length;}if(total>1200L*1024*1024||zip.Entries.Count>10000)throw new Exception("Paket sınırı aşıldı.");foreach(string required in new[]{"MiapaxERP.Desktop.exe","MiapaxERP.Desktop.dll","MiapaxERP.Updater.exe","EBelge270.sql","EBelge271.sql","EBelge280.sql","Muhasebe280.sql","IlkBaslat.cmd"})if(!paths.Contains(required))throw new Exception("Eksik paket dosyası: "+required);
 string temp=Path.Combine(Path.GetTempPath(),"MiapaxERP-PaketSurum-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(temp);foreach(string name in new[]{"MiapaxERP.Desktop.exe"}){string dest=Path.Combine(temp,name);zip.GetEntry(name)!.ExtractToFile(dest);if(UpdateSafety.Normalize(Version.Parse(FileVersionInfo.GetVersionInfo(dest).FileVersion!))!=UpdateSafety.Normalize(Version.Parse(S("Version"))))throw new Exception("Dosya sürümü uyuşmuyor.");File.Delete(dest);}Directory.Delete(temp);Console.WriteLine("PASS "+S("Channel")+": üretim imzası, SHA256, dosya yolları, veri/ayar koruması, sürüm ve temiz dosya adları doğrulandı.");return 0;
}
return 2;
static void LegacyPath(string path){if(System.Text.RegularExpressions.Regex.IsMatch(path,"boruerp|miasoft",System.Text.RegularExpressions.RegexOptions.IgnoreCase))throw new InvalidDataException("Eski marka içeren dosya yolu: "+path);}

