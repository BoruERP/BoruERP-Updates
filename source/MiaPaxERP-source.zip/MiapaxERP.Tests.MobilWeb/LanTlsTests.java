package com.miapaxerp.mobile;
import java.net.*;
import java.nio.file.*;
import java.security.cert.*;
import java.security.*;
import javax.net.ssl.*;
public class LanTlsTests{
 static int count;static void check(boolean v,String label){if(!v)throw new AssertionError(label);count++;System.out.println("PASS LAN JAVA "+label);}
 interface Run{void run()throws Exception;}
 static void reject(Run r,String label)throws Exception{try{r.run();}catch(Exception e){check(true,label);return;}throw new AssertionError(label);}
 static X509Certificate cert(String file)throws Exception{try(java.io.InputStream in=Files.newInputStream(Paths.get(file))){return (X509Certificate)CertificateFactory.getInstance("X.509").generateCertificate(in);}}
 public static void main(String[] args)throws Exception{
  String pin=args[3];
  for(String ip:new String[]{"10.0.0.1","172.16.0.2","172.31.255.1","192.168.1.5"}){check(LanTls.privateIp(ip),"Özel IPv4 "+ip);LanTls.validate("https://"+ip+":5189",pin);}
  for(String ip:new String[]{"127.0.0.1","0.0.0.0","169.254.1.1","172.15.0.1","172.32.0.1","8.8.8.8","192.168.1.256","192.168.01.1","192.168.1","[::1]"})check(!LanTls.privateIp(ip),"Yerel eşleme dışında "+ip);
  for(String url:new String[]{"http://192.168.1.5:5189","https://192.168.1.5:5188","https://192.168.1.5:5189/x","https://u@192.168.1.5:5189","https://192.168.1.5:5189?x","https://example.com:5189","https://8.8.8.8:5189"})reject(()->LanTls.validate(url,pin),"Adres reddi "+url);
  LanTls.validate("https://mobile.example.com","");check(true,"Genel HTTPS modu korunur");
  reject(()->LanTls.validate("https://192.168.1.5:5189",""),"Kimliksiz özel IP kapalı");
  LanTls.verify(cert(args[0]),pin);check(true,"Doğru bilgisayar sertifikası doğrulanır");
  reject(()->LanTls.verify(cert(args[1]),pin),"Başka bilgisayar sertifikası reddedilir");
  reject(()->LanTls.verify(cert(args[2]),pin),"Süresi dolmuş sertifika reddedilir");
  HttpsURLConnection c=(HttpsURLConnection)new URL(args[4]).openConnection();c.setSSLSocketFactory(LanTls.factory(pin));c.setConnectTimeout(5000);c.setReadTimeout(5000);
  check(c.getResponseCode()==403,"Gerçek TLS bağlantısı doğru kimlikle API'ye ulaşır");c.disconnect();
  reject(()->{HttpsURLConnection bad=(HttpsURLConnection)new URL(args[4]).openConnection();bad.setConnectTimeout(5000);bad.setReadTimeout(5000);bad.setSSLSocketFactory(LanTls.factory(new String(new char[64]).replace('\0','0')));try{bad.getResponseCode();}finally{bad.disconnect();}},"Gerçek TLS bağlantısında yanlış kimlik reddedilir");
  HttpsURLConnection badHost=(HttpsURLConnection)new URL(args[4].replace("127.0.0.1","localhost")).openConnection();badHost.setConnectTimeout(5000);badHost.setReadTimeout(5000);badHost.setSSLSocketFactory(LanTls.factory(pin));reject(()->{try{badHost.getResponseCode();}finally{badHost.disconnect();}},"Doğru kimlik olsa da yanlış sunucu adı reddedilir");
  System.out.println("PASSED LAN JAVA "+count);
 }
}
