import {createRequire} from 'node:module';import fs from 'node:fs';import path from 'node:path';import http from 'node:http';import assert from 'node:assert/strict';
const require=createRequire(process.env.MIAPAXERP_NODE_MODULES+'/package.json');const {chromium}=require('playwright');
const root=path.resolve('MiapaxERP.Desktop/Assets/SahaWeb');
const provinces=JSON.parse(fs.readFileSync(path.join(root,'provinces.json'))),districts=JSON.parse(fs.readFileSync(path.join(root,'districts.json')));
const kayseri=provinces.find(p=>p.name==='Kayseri'),adana=provinces.find(p=>p.name==='Adana'),ds=districts.filter(d=>d.parent_id===kayseri.id).slice(0,2);
const types={'.html':'text/html','.js':'application/javascript','.css':'text/css','.json':'application/json','.geojson':'application/json'};
const server=http.createServer((req,res)=>{const pathname=new URL(req.url,'http://localhost').pathname;const name=pathname==='/'?'index.html':pathname.slice(1);if(!/^[a-zA-Z0-9_.-]+$/.test(name)){res.writeHead(404).end();return;}try{res.setHeader('Content-Type',types[path.extname(name)]||'text/plain');res.end(fs.readFileSync(path.join(root,name)));}catch{res.writeHead(404).end();}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));let browser;
try{
 browser=await chromium.launch({channel:'chrome',headless:true});const page=await browser.newPage({viewport:{width:1360,height:1000}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(({p,ds})=>{
  window.rpcCalls=[];window.inflight=0;window.delayProvince=false;window.pageMode=false;
  window.records=[
   {id:'11111111-1111-4111-8111-111111111111',ad:'Ali Test',telefon:'05001234567',ilceId:ds[0].id,koy:'Örnek Köy',sonGorusme:'2026-11-09T08:00:00Z',sonuc:'Teklif hazırlanacak.'},
   {id:'22222222-2222-4222-8222-222222222222',ad:'Ayşe Test',telefon:'05007654321',ilceId:ds[1].id,koy:'Örnek Mahalle',sonGorusme:'2026-11-08T08:00:00Z',sonuc:'Ölçüm beklenecek.'}];
  window.chrome={webview:{addEventListener:(name,cb)=>window.rpcReceive=cb,postMessage:d=>{
   window.rpcCalls.push(d);window.inflight++;const rows=window.pageMode?Array.from({length:101},(_,i)=>({...window.records[0],id:'page-'+i,ad:'Sayfa '+i})):window.records;
   let result=null;
   if(d.action==='province'){let filtered=d.il===p.id?rows.filter(r=>(!d.ilce||r.ilceId===d.ilce)&&(!d.search||(r.ad+' '+r.telefon).includes(d.search))):[];result={rows:filtered.slice(d.offset,d.offset+100),hasMore:filtered.length>d.offset+100,nextOffset:Math.min(d.offset+100,filtered.length)};}
   if(d.action==='list')result=[];
   if(d.action==='load'){const r=window.records.find(r=>r.id===d.id);result={data:{...r,ilId:p.id,alan:25,alanBirimi:'dekar',urunler:'Mısır',debi:null,debiBirimi:'m³/saat',basinc:null,sulama:'Damlama',suKaynagi:'Kuyu',aciklama:''},version:'AAAAAAAAAAE=',visits:[{tarih:r.sonGorusme,sonuc:r.sonuc,kullanici:1}]};}
   setTimeout(()=>{window.inflight--;window.rpcReceive({data:{request:d.request,result}});},d.action==='province'&&window.delayProvince&&d.il===p.id?250:0);
  }}};
 },{p:kayseri,ds});
 await page.goto('http://127.0.0.1:'+server.address().port);await page.waitForFunction(()=>document.querySelectorAll('#map path').length===81);
 await page.locator('#map path[aria-label="Kayseri"]').press('Enter');await page.waitForFunction(()=>document.querySelectorAll('#visitedRows button').length===2);
 assert.match(await page.locator('#visitedHeading').innerText(),/Kayseri/);assert.match(await page.locator('#visitedRows').innerText(),new RegExp(ds[0].name));assert.match(await page.locator('#visitedRows').innerText(),new RegExp(ds[1].name));console.log('PASS İl seçimiyle sol listede kişiler ve ilçeler görünür');
 await page.locator('#visitedRows button').filter({hasText:'Ali Test'}).click();await page.waitForSelector('#editor[open]');
 assert.match(await page.locator('#location').innerText(),new RegExp(ds[0].name));assert.match(await page.locator('#history').innerText(),/Teklif hazırlanacak/);assert.equal(await page.locator('#district').inputValue(),'');await page.click('#cancel');console.log('PASS İlçe seçmeden listeden müşteri/görüşme açılır');
 await page.locator('#map path').filter({has:page.locator('title')}).count();
 await page.selectOption('#district',ds[1].id);await page.waitForFunction(()=>document.querySelectorAll('#visitedRows button').length===1);assert.match(await page.locator('#visitedRows').innerText(),/Ayşe/);console.log('PASS İlçe seçimi listeyi daraltır');
 await page.selectOption('#district','');await page.waitForFunction(()=>document.querySelectorAll('#visitedRows button').length===2);
 await page.fill('#visitedSearch','0500765');await page.waitForFunction(()=>document.querySelectorAll('#visitedRows button').length===1);assert.match(await page.locator('#visitedRows').innerText(),/Ayşe/);console.log('PASS Telefon araması');
 await page.fill('#visitedSearch','Bulunmayan');await page.waitForFunction(()=>document.getElementById('visitedStatus').textContent.includes('bulunamadı'));assert.equal(await page.locator('#visitedRows button').count(),0);console.log('PASS Boş arama sonucu açıkça gösterilir');
 await page.evaluate(()=>window.delayProvince=true);await page.selectOption('#province',kayseri.id);await page.selectOption('#province',adana.id);await page.waitForFunction(()=>window.inflight===0);
 assert.match(await page.locator('#visitedHeading').innerText(),/Adana/);assert.equal(await page.locator('#visitedRows button').count(),0);console.log('PASS Eski ilin gecikmiş cevabı yeni ili bozamaz');
 await page.evaluate(()=>{window.delayProvince=false;window.pageMode=true;});await page.selectOption('#province',kayseri.id);await page.waitForFunction(()=>document.querySelectorAll('#visitedRows button').length===100);
 await page.click('#visitedMore');await page.waitForFunction(()=>document.querySelectorAll('#visitedRows button').length===101);assert.equal(await page.locator('#visitedMore').isVisible(),false);console.log('PASS Devamını yükle yüz kişiden sonrasını gösterir');
 await page.evaluate(()=>window.pageMode=false);await page.click('#visitedRefresh');await page.waitForFunction(()=>document.querySelectorAll('#visitedRows button').length===2);
 fs.mkdirSync('Teslim222/Testler',{recursive:true});await page.screenshot({path:'Teslim222/Testler/Saha-Il-Listesi.png',fullPage:true});
 await page.setViewportSize({width:412,height:915});assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);console.log('PASS Küçük ekranda yatay taşma yok');
 await page.click('#home');assert.equal(await page.locator('#visitedPanel').isVisible(),false);console.log('PASS Türkiye görünümüne dönünce il listesi kapanır');
 assert.deepEqual(errors,[]);console.log('PASSED IL WEB222 10');
}finally{if(browser)await browser.close();await new Promise(r=>server.close(r));}
