import {createRequire} from 'node:module';
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
const require=createRequire(process.env.MIAPAXERP_NODE_MODULES+'/package.json');
const {chromium}=require('playwright');
const root=path.resolve('MiapaxERP.Android/assets');
const types={'.html':'text/html','.js':'application/javascript','.css':'text/css','.json':'application/json','.geojson':'application/json'};
const server=http.createServer((req,res)=>{const pathname=new URL(req.url,'http://localhost').pathname;const name=pathname==='/'?'index.html':pathname.slice(1);if(!/^[a-zA-Z0-9_.-]+$/.test(name)){res.writeHead(404).end();return;}try{res.setHeader('Content-Type',types[path.extname(name)]||'text/plain');res.end(fs.readFileSync(path.join(root,name)));}catch{res.writeHead(404).end();}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
let browser;
try{
 browser=await chromium.launch({channel:'chrome',headless:true});
 const page=await browser.newPage({viewport:{width:412,height:915},deviceScaleFactor:1});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>{
  window.testRows=[];window.testSaved=null;window.testQueue=[];window.testCalls=[];
  window.BoruMobile={postMessage:raw=>{const d=JSON.parse(raw);window.testCalls.push(d);let result=null,error=null;
   if(d.action==='list')result=window.testRows;
   if(d.action==='queue')result=window.testQueue;
   if(d.action==='drop'){window.testQueue=window.testQueue.filter(x=>x.operation!==d.operation);result={ok:true};}
   if(d.action==='save'){window.testSaved=d;window.testRows=[{id:d.data.id,ad:d.data.ad,telefon:d.data.telefon}];result={queued:true};}
   if(d.action==='load')result={data:window.testSaved.data,version:'AAAAAAAAAAE=',visits:[{tarih:new Date().toISOString(),sonuc:'Görüşme kaydı',kullanici:2}]};
   if(d.action==='report')result={kayitlar:[{'Ürün':'Test ürün','Bakiye':12}],okumaZamani:new Date().toISOString()};
   setTimeout(()=>window.mobileReceive({request:d.request,result,error}),0);
  }};
  window.alert=()=>{};
 });
 await page.goto('http://127.0.0.1:'+server.address().port);
 await page.waitForFunction(()=>document.querySelectorAll('#map path').length===81);
 console.log('PASS 81 il harita yolu');
 await page.evaluate(()=>{window.mobileProfile={ad:'Satışçı A',rol:'SAHA'};window.dispatchEvent(new Event('mobile-ready'));});
 assert.equal(await page.getByRole('button',{name:'Muhasebe',exact:true}).count(),0);console.log('PASS Saha hesabında patron rapor düğmesi yok');
 await page.selectOption('#province',{label:'Kayseri'});await page.waitForFunction(()=>document.querySelectorAll('#district option').length>1);
 const district=await page.locator('#district option').nth(1).getAttribute('value');await page.selectOption('#district',district);
 await page.locator('#villages button').first().click();await page.click('#new');await page.fill('#ad','Mobil test çiftçi');await page.fill('#telefon','05001234567');await page.fill('#alan','25');await page.fill('#urunler','Mısır');await page.selectOption('#suKaynagi','Kuyu');await page.fill('#visit','Teklif hazırlanacak.');
 await page.click('#save');await page.waitForFunction(()=>window.testSaved!==null&&!document.getElementById('editor').open);
 const saved=await page.evaluate(()=>window.testSaved);
 assert.equal(saved.data.alan,25);assert.equal(saved.data.basinc,null);assert.equal(saved.data.suKaynagi,'Kuyu');assert.equal(saved.visit,'Teklif hazırlanacak.');console.log('PASS Mobil müşteri formu, birimler ve bilinmeyen basınç');
 await page.locator('#customers button').first().click();await page.waitForSelector('#editor[open]');assert.match(await page.locator('#history').innerText(),/Görüşme kaydı/);await page.click('#cancel');console.log('PASS Mobil müşteri ayrıntısı ve görüşme geçmişi');
 await page.evaluate(()=>{window.testQueue=[{operation:'op1',data:{ad:'Bekleyen müşteri',alan:5},visit:'Taslak not',error:'Çakışma'}];});
 await page.getByRole('button',{name:'Bekleyen kayıtlar',exact:true}).click();await page.waitForSelector('dialog[open] pre');
 assert.match(await page.locator('dialog[open] pre').innerText(),/Taslak not/);
 page.once('dialog',d=>d.dismiss());await page.getByRole('button',{name:'Bu bekleyen kaydı kaldır',exact:true}).click();assert.equal(await page.evaluate(()=>window.testQueue.length),1);console.log('PASS Kuyruk silme iptal edilince taslak korunur');
 await page.getByRole('button',{name:'Kapat',exact:true}).click();
 await page.evaluate(()=>{window.mobileProfile={ad:'Patron',rol:'PATRON'};window.dispatchEvent(new Event('mobile-ready'));});
 await page.getByRole('button',{name:'Stok',exact:true}).click();await page.waitForFunction(()=>document.querySelector('.reports').textContent.includes('Test ürün'));console.log('PASS Patron stok raporu');
 assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth),false);console.log('PASS 412px ekranda yatay taşma yok');
 fs.mkdirSync(process.env.MIAPAXERP_QA_DIR||'MiapaxERP-Testler',{recursive:true});await page.screenshot({path:path.join(process.env.MIAPAXERP_QA_DIR||'MiapaxERP-Testler','Mobil-412px.png'),fullPage:true});
 assert.deepEqual(errors,[]);console.log('PASSED MOBILE WEB 8');
}finally{if(browser)await browser.close();await new Promise(r=>server.close(r));}
