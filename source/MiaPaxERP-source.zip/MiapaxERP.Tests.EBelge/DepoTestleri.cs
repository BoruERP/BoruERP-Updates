using System.Data;
using System.Text.Json;
using Microsoft.Data.SqlClient;
using MiapaxERP.Desktop.EBelge;
internal static class DepoTestleri
{
 static int passed;
 static void Check(bool ok,string name){if(!ok)throw new Exception(name);passed++;Console.WriteLine("PASS "+name);}
 static void Reject(Action action,string name){try{action();}catch(Exception e)when(e is ArgumentException or InvalidOperationException or UnauthorizedAccessException or SqlException or EbelgeHatasi){Check(true,name);return;}throw new Exception("Accepted: "+name);}
 static object? Scalar(SqlConnection c,string sql){using var q=new SqlCommand(sql,c);return q.ExecuteScalar();}
 static void Sql(SqlConnection c,string sql){using var q=new SqlCommand(sql,c);q.ExecuteNonQuery();}
 public static string Xml(Guid id,string no="TST2026000000001")=>$"""
 <Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2" xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2" xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2">
 <cbc:ID>{no}</cbc:ID><cbc:UUID>{id:D}</cbc:UUID><cbc:IssueDate>2026-11-11</cbc:IssueDate><cbc:ProfileID>TEMELFATURA</cbc:ProfileID><cbc:InvoiceTypeCode>SATIS</cbc:InvoiceTypeCode>
 <cac:AccountingSupplierParty><cac:Party><cac:PartyIdentification><cbc:ID schemeID="VKN">1234567890</cbc:ID></cac:PartyIdentification></cac:Party></cac:AccountingSupplierParty>
 <cac:AccountingCustomerParty><cac:Party><cac:PartyIdentification><cbc:ID schemeID="VKN">9876543210</cbc:ID></cac:PartyIdentification></cac:Party></cac:AccountingCustomerParty>
 </Invoice>
 """;
 static HizliKimlik Key=>new(EbelgeOrtam.Test,"1234567890","fixture-api","enc-user","enc-password");
 public static int Run()
 {
  Guid uuid=Guid.NewGuid();string xml=Xml(uuid);var u=UblKimlik.Oku(xml);var input=new HizliGonderi(1,"urn:mail:sender@example.invalid","9876543210","urn:mail:recipient@example.invalid",xml,uuid.ToString(),u.No,"2026-11-11","caller-value");
  Check(u.Ettn==uuid&&u.Gonderen==Key.Vkn&&!u.Irsaliye,"UBL party, UUID and root identity preserved");u.Esle(Key,input);Check(true,"UBL identity agrees with request");
  Reject(()=>UblKimlik.Oku("<!DOCTYPE Invoice [<!ENTITY x SYSTEM 'file:///C:/Windows/win.ini'>]>"+xml),"external entity and DTD prohibited");
  Reject(()=>UblKimlik.Oku(xml.Replace("urn:oasis:names:specification:ubl:schema:xsd:Invoice-2","urn:spoof")),"forged UBL namespace rejected");
  Reject(()=>UblKimlik.Oku(xml.Replace("<cbc:UUID>","<cbc:UUID>"+uuid+"</cbc:UUID><cbc:UUID>")),"duplicate UUID rejected");
  Reject(()=>u.Esle(Key,input with{DocumentUUID=Guid.NewGuid().ToString()}),"request ETTN mismatch rejected before send");
  Reject(()=>u.Esle(Key,input with{DestinationIdentifier="1111111111"}),"recipient mismatch rejected");
  Reject(()=>u.Esle(Key with{Vkn="1111111111"},input),"wrong ERP account cannot send another company UBL");
  Reject(()=>u.Esle(Key,input with{AppType=5}),"invoice cannot be submitted as despatch");
  Reject(()=>u.Esle(Key,input with{DocumentDate="2026-11-12"}),"request date cannot be silently replaced");
  Check(EbelgeTarihi.Oku("/Date(1794344400000+0300)/").Kind==DateTimeKind.Unspecified,"WCF date preserves explicit provider offset");
  Reject(()=>EbelgeTarihi.Oku("unknown"),"missing issue date never defaults to today");
  foreach(var tokenJson in new[]{"\"fixture.payload.signature\"","{\"Token\":\"fixture.payload.signature\"}","{\"data\":{\"accessToken\":\"Bearer fixture.payload.signature\"}}","[\"fixture.payload.signature\"]","[{\"IsSucceeded\":true,\"Token\":\"fixture.payload.signature\"}]"}){using var j=JsonDocument.Parse(tokenJson);Check(HizliTokenYaniti.Oku(j.RootElement)=="fixture.payload.signature","documented bearer response containers parse without leaking token");}
  using(var j=JsonDocument.Parse("{\"IsSucceeded\":false,\"Token\":\"fixture.payload.signature\"}"))Reject(()=>HizliTokenYaniti.Oku(j.RootElement),"failed auth flag cannot be overridden by token-looking field");
  foreach(string payload in new[]{"[]","[\"fixture.payload.signature\",\"fixture.payload.signature\"]","[{\"IsSucceeded\":false,\"Token\":\"fixture.payload.signature\"}]"}){using var j=JsonDocument.Parse(payload);Reject(()=>HizliTokenYaniti.Oku(j.RootElement),"empty, ambiguous or rejected login lists cannot authenticate");}
  using(var j=JsonDocument.Parse("{\"Message\":\"private-fixture-message\",\"SecretKey\":\"private-fixture-secret\"}")){string shape=HizliTokenYaniti.Bicim(j.RootElement);Check(!shape.Contains("private-fixture")&&!shape.Contains("SecretKey"),"auth diagnostics expose neither values nor unknown sensitive fields");}
  string db="MiapaxERPEbelgeTest_"+Guid.NewGuid().ToString("N");string master="Server=(localdb)\\MSSQLLocalDB;Database=master;Integrated Security=true;TrustServerCertificate=true;Pooling=false;Connect Timeout=20";using var admin=new SqlConnection(master);admin.Open();Sql(admin,"CREATE DATABASE ["+db+"]");
  try
  {
   var cs=new SqlConnectionStringBuilder(master){InitialCatalog=db}.ConnectionString;using var c=new SqlConnection(cs);c.Open();Sql(c,"CREATE TABLE dbo.Yetkiler(YetkiKodu varchar(100) PRIMARY KEY,Modul nvarchar(100),Islem nvarchar(100),Aciklama nvarchar(200),Aktif bit);CREATE TABLE dbo.FactorySentinel(Id int PRIMARY KEY,Amount decimal(18,2));INSERT dbo.FactorySentinel VALUES(1,12345.67);");
   EbelgeDeposu S(int user)=>new(cs,user,(x,t,p)=>{if(user!=1&&!(user==2&&p=="FINANCE.EBELGE.VIEW"))throw new UnauthorizedAccessException();});var d=S(1);d.Kur();d.Kur();Check(Convert.ToInt32(Scalar(c,"SELECT COUNT(*) FROM dbo.Yetkiler WHERE YetkiKodu LIKE 'FINANCE.EBELGE.%'"))==9,"schema install and permission registration idempotent");
   Reject(()=>S(2).Hazirla(Key,input),"view-only user cannot prepare document");long id=d.Hazirla(Key,input);Check(d.Hazirla(Key,input)==id,"same UUID and same content create only one immutable draft");
   Reject(()=>d.Hazirla(Key,input with{XmlContent=xml+"\n"}),"same UUID with changed raw XML rejected");
   Reject(()=>d.Hazirla(Key,input with{SourceUrn="urn:mail:different@example.invalid"}),"same UUID cannot switch sender alias");
   var row=d.Liste(Key).Rows[0];var version=(byte[])row["Surum"];
   Reject(()=>S(2).Baslat(Key,id,version),"view-only cannot submit draft");
   Reject(()=>d.Baslat(Key with{Ortam=EbelgeOrtam.Canli},id,version),"test draft cannot be sent in live environment");
   Reject(()=>d.Baslat(Key with{Vkn="1111111111"},id,version),"draft tenant isolation enforced");
   var outgoing=d.Baslat(Key,id,version);Check(outgoing.IsDraft&&!outgoing.IsDraftSend&&outgoing.LocalId=="MIAPAX ERP-"+uuid.ToString("N"),"stable server-generated LocalId and draft flags survive prepare/start");
   Check((string)d.Liste(Key).Rows[0]["Durum"]=="Gönderim başladı","durable in-flight state exists before any network request");
   Reject(()=>d.Baslat(Key,id,version),"concurrent or repeated start rejected by rowversion and state");
   row=d.Liste(Key).Rows[0];Reject(()=>d.Baslat(Key,id,(byte[])row["Surum"]),"crashed in-flight operation not auto-retried after reload");
   d.Sonuc(Key,id,"Belirsiz","Timeout fixture; query before any retry.");row=d.Liste(Key).Rows[0];Reject(()=>d.Baslat(Key,id,(byte[])row["Surum"]),"ambiguous result cannot be resent by refreshing version");
   d.Sonuc(Key,id,"Taslak kabul edildi","Provider acceptance is not GIB delivery.");Check((string)d.Liste(Key).Rows[0]["Durum"]=="Taslak kabul edildi","provider acceptance remains explicitly draft status");
   Check(Convert.ToInt32(Scalar(c,"SELECT COUNT(*) FROM dbo.BERP270_EBelgeOlay"))==4,"prepare, start and result audit events retained");
   Check(Convert.ToDecimal(Scalar(c,"SELECT Amount FROM dbo.FactorySentinel WHERE Id=1"))==12345.67m,"schema and draft lifecycle preserve pre-existing business data");
   Check(d.Liste(Key with{Ortam=EbelgeOrtam.Canli}).Rows.Count==0,"live history cannot include test documents");
   var found=new HizliKayit(uuid,2,u.No,"Test","9876543210","TEMELFATURA","SATIS","TRY",20,120,0,"Provider state",0,"Draft state","2026-11-11","MIAPAX ERP-"+uuid.ToString("N"));
   Reject(()=>d.SorguKaydet(Key,id,found with{UUID=Guid.NewGuid()}),"lookup cannot overwrite another local document");
   d.SorguKaydet(Key,id,found);Check((string)d.Liste(Key).Rows[0]["Durum"]=="Sağlayıcıda bulundu","lookup result persists without inventing final GIB delivery status");
  }
  finally{if(!System.Text.RegularExpressions.Regex.IsMatch(db,"^MiapaxERPEbelgeTest_[a-f0-9]{32}$"))throw new Exception("Test database cleanup guard");Sql(admin,"ALTER DATABASE ["+db+"] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;DROP DATABASE ["+db+"]");}
  Console.WriteLine($"Passed {passed} UBL/auth/outbox checks in an isolated temporary SQL database.");return passed;
 }
}
