using System.Net;
using System.Net.Http;
using System.IO;
using System.Text;
using System.Text.Json;
using MiapaxERP.Desktop.EBelge;

sealed class Fake(Func<HttpRequestMessage,Task<HttpResponseMessage>> send):HttpMessageHandler
{protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken ct)=>send(request);}
internal static class Program
{
 static int passed;
 static void Check(bool ok,string name){if(!ok)throw new Exception(name);passed++;Console.WriteLine("PASS "+name);}
 static async Task Reject(Func<Task> action,string name){try{await action();}catch(Exception e)when(e is EbelgeHatasi or ArgumentException){Check(true,name);return;}throw new Exception("Accepted: "+name);}
 static HttpResponseMessage Json(object value,HttpStatusCode code=HttpStatusCode.OK)=>new(code){Content=new StringContent(JsonSerializer.Serialize(value),Encoding.UTF8,"application/json")};
 static HizliKimlik Kimlik=>new(EbelgeOrtam.Test,"1234567890","fixture-api","encrypted-user","encrypted-password");
 static object Doc(Guid id,int type=2)=>new{UUID=id,AppType=type,DocumentId="TEST2026000000001",TargetTitle="TEST",TargetIdentifier="1234567890",ProfileId="TEMELFATURA",DocumentTypeCode="SATIS",DocumentCurrencyCode="TRY",TaxTotal=20m,PayableAmount=120m,Status=0,StatusExp="Taslak",EnvelopeStatus=0,EnvelopeExp="GİB'e gönderilmedi",IssueDate="2026-11-11T00:00:00",LocalReferenceId="fixture-local"};
 public static async Task Main()
 {
  int encrypt=0,logins=0,sends=0;bool legacyHeaders=false;Guid id=Guid.NewGuid();var handler=new Fake(async q=>{
   Check(q.RequestUri!.Scheme=="https"&&q.RequestUri.Host=="econnecttest.hizliteknoloji.com.tr","credentials stay on exact HTTPS test host");string name=q.RequestUri.AbsolutePath.Split('/').Last();string raw=q.Content is null?"":await q.Content.ReadAsStringAsync();
   if(name=="UtilEncrypt"){encrypt++;var body=JsonDocument.Parse(raw).RootElement;Check(body.GetProperty("secretKey").GetString()=="one-time-secret","secret sent only to provider UtilEncrypt");Check(q.Headers.Authorization is null,"one-time encryption has no unrelated auth header");return Json(new{username="encrypted-user",password="encrypted-password"});}
   if(name=="Login"){logins++;var b=JsonDocument.Parse(raw).RootElement;Check(b.GetProperty("apiKey").GetString()=="fixture-api"&&b.GetProperty("username").GetString()=="encrypted-user","Login uses API key and encrypted credentials");Check(!raw.Contains("one-time-secret")&&!raw.Contains("plain-password"),"Login never reuses plain secret or password");return Json("fixture.payload.signature");}
   Check(q.Headers.Authorization?.Scheme=="Bearer"&&q.Headers.Authorization.Parameter=="fixture.payload.signature","authorized calls use documented bearer token");legacyHeaders|=q.Headers.Contains("username")||q.Headers.Contains("password");
   if(name=="GetGibUserList")return Json(new{IsSucceeded=true,gibUserLists=new[]{new{Identifier="1234567890",Alias="urn:mail:test@example.invalid",Title="TEST",Type="OZEL"}}});
   if(name=="GetDocumentList")return Json(new{IsSucceeded=true,documents=new[]{Doc(id)}});
   if(name=="GetDocumentListGUID"){Check(q.Method==HttpMethod.Post,"ETTN lookup uses documented POST variant");var b=JsonDocument.Parse(raw).RootElement;Check(b.GetProperty("AppType").GetInt32()==2&&Guid.Parse(b.GetProperty("GUIDList")[0].GetString()!)==id,"outgoing e-invoice lookup uses box 2 rather than send type 1");return Json(new{IsSucceeded=true,documents=new[]{Doc(id)}});}
   if(name=="GetDocumentFile"){Check(q.Headers.GetValues("IssueDate").Single()=="2026-11-11","download preserves source issue date in header");return Json(new{IsSucceeded=true,DocumentFile=Convert.ToBase64String("<test/>"u8)});}
   if(name=="SendDocument"){sends++;var b=JsonDocument.Parse(raw).RootElement;Check(b.ValueKind==JsonValueKind.Array&&b.GetArrayLength()==1,"SendDocument is one-element JSON array");Check(b[0].GetProperty("AppType").GetInt32()==1&&b[0].GetProperty("IsDraft").GetBoolean(),"test draft send type differs from outgoing list type");return Json(new[]{new{IsSucceeded=true,Message="Draft accepted"}});}
   throw new Exception("Unexpected test route");
  });
  HizliKimlik key;using(var api=new HizliApi(EbelgeOrtam.Test,testHandler:handler))key=await api.IlkKurulum("1234567890","fixture-api","one-time-secret","plain-user","plain-password",default);Check(encrypt==1,"one-time credential transformation performed once");
  // Each fake handler belongs to one HttpClient; the account fixture is newly issued per client.
  var h2=new Fake(async q=>{
   string path=q.RequestUri!.AbsolutePath.Split('/').Last();if(path=="Login"){logins++;return Json("fixture.payload.signature");}
   legacyHeaders|=q.Headers.Contains("username")||q.Headers.Contains("password");Check(q.RequestUri!.Host=="econnecttest.hizliteknoloji.com.tr"&&q.Headers.Authorization?.Scheme=="Bearer","subsequent request stays on test host with bearer token");
   if(path=="GetGibUserList")return Json(new{IsSucceeded=true,gibUserLists=new[]{new{Identifier="1234567890",Alias="urn:mail:test@example.invalid",Title="TEST",Type="OZEL"}}});
   if(path=="GetDocumentList")return Json(new{IsSucceeded=true,documents=new[]{Doc(id)}});
   if(path=="GetDocumentListGUID"){Check(q.Method==HttpMethod.Post,"GUID lookup uses POST");var b=JsonDocument.Parse(await q.Content!.ReadAsStringAsync()).RootElement;Check(b.GetProperty("AppType").GetInt32()==2,"outgoing invoice query box kept distinct");return Json(new{IsSucceeded=true,documents=new[]{Doc(id)}});}
   if(path=="GetDocumentFile"){Check(q.Headers.GetValues("IssueDate").Single()=="2026-11-11","file query source date retained");return Json(new{IsSucceeded=true,DocumentFile=Convert.ToBase64String("<test/>"u8)});}
   var body=JsonDocument.Parse(await q.Content!.ReadAsStringAsync()).RootElement;Check(body.ValueKind==JsonValueKind.Array&&body.GetArrayLength()==1,"single outgoing document serialized as list");Check(body[0].GetProperty("IsDraft").GetBoolean()&&body[0].GetProperty("AppType").GetInt32()==1,"draft flags and sending app type preserved");sends++;return Json(new[]{new{IsSucceeded=true}});
  });using(var api=new HizliApi(EbelgeOrtam.Test,key,h2)){await api.Giris(default);await api.Giris(default);Check(logins==1,"in-memory token reused without storing or repeating login");Check((await api.Mukellef(1,"GB",key.Vkn,default)).Length==1,"registry lookup parsed");Check((await api.Liste(EbelgeKutusu.GidenFatura,new(2026,11,1),new(2026,11,11),true,default)).Single().UUID==id,"document listing preserves ETTN");Check((await api.Sorgula(EbelgeKutusu.GidenFatura,id,default))!.UUID==id,"ETTN result verified");Check(Encoding.UTF8.GetString(await api.Dosya(EbelgeKutusu.GidenFatura,id,"XML",true,new(2026,11,11),default))=="<test/>","base64 document decoded");await api.Gonder(new(1,"urn:mail:test@example.invalid","1234567890","urn:mail:pk@example.invalid","<test/>",id.ToString(),"TEST2026000000001","2026-11-11","fixture-local"),default);await Reject(()=>api.Dosya(EbelgeKutusu.GidenFatura,id,"HTML",true,new(2026,11,11),default),"active HTML download not enabled");await Reject(()=>api.Liste(EbelgeKutusu.GidenFatura,new(2026,1,1),new(2026,11,11),null,default),"unbounded list query rejected");}Check(sends==1&&!legacyHeaders,"one explicit send only; no legacy plain credential headers");
  using(var api=new HizliApi(EbelgeOrtam.Test,key,new Fake(_=>Task.FromResult(Json(new{IsSucceeded=false})))))await Reject(()=>api.Giris(default),"failed login not treated as token");
  int requests=0;using(var api=new HizliApi(EbelgeOrtam.Test,key,new Fake(_=>Task.FromResult(++requests==1?Json("fixture.payload.signature"):new HttpResponseMessage(HttpStatusCode.Redirect){Headers={Location=new Uri("https://other.invalid/")}}))))await Reject(()=>api.Mukellef(1,"GB",key.Vkn,default),"redirect never followed with token");
  requests=0;using(var api=new HizliApi(EbelgeOrtam.Test,key,new Fake(_=>Task.FromResult(++requests==1?Json("fixture.payload.signature"):Json(new{IsSucceeded=false})))))await Reject(()=>api.Mukellef(1,"GB",key.Vkn,default),"registry error does not mean non-taxpayer");
  requests=0;using(var api=new HizliApi(EbelgeOrtam.Test,key,new Fake(_=>Task.FromResult(++requests==1?Json("fixture.payload.signature"):Json(new{IsSucceeded=true,documents=new[]{Doc(Guid.NewGuid())}})))))await Reject(()=>api.Sorgula(EbelgeKutusu.GidenFatura,id,default),"mismatched ETTN rejected");
  string folder=Path.Combine(Path.GetTempPath(),"MiapaxERP-EbelgeTest-"+Guid.NewGuid().ToString("N"));try{string path=HizliAyarDeposu.Kaydet(folder,key);var raw=File.ReadAllBytes(path);Check(!Encoding.UTF8.GetString(raw).Contains("fixture-api"),"API key not plaintext on disk");Check(HizliAyarDeposu.Oku(path)==key,"encrypted configuration roundtrip");Check(!key.ToString().Contains("fixture-api"),"configuration ToString redacts secrets");Check(!EbelgeJson.Yaz(key).Contains("one-time-secret")&&!EbelgeJson.Yaz(key).Contains("plain-password"),"persistent model contains only encrypted account credentials");}finally{foreach(var f in Directory.EnumerateFiles(folder))File.Delete(f);Directory.Delete(folder);}
  Console.WriteLine($"Passed {passed} e-document transport checks. Fake HTTP only; no customer credentials or external document submissions used.");
  DepoTestleri.Run();GonderimTestleri.Run();GorunumTestleri.Run();
 }
}
