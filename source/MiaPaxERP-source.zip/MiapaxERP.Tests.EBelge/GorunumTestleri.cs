using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using MiapaxERP.Desktop.EBelge;
internal static class GorunumTestleri
{
 public static void Run()
 {
  Exception? failure=null;var thread=new Thread(()=>{try{
   var panel=new EbelgePaneli("Server=(localdb)\\MSSQLLocalDB;Database=MiapaxERP_OnlyUi_Render;Integrated Security=true;TrustServerCertificate=true",1);var root=new Border{Background=Brushes.White,Child=panel};var size=new Size(1360,900);root.Measure(size);root.Arrange(new Rect(size));root.UpdateLayout();
   var image=new RenderTargetBitmap(1360,900,96,96,PixelFormats.Pbgra32);image.Render(root);var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(image));string path=Path.Combine(AppContext.BaseDirectory,"ebelge-arayuz.png");using var output=File.Create(path);encoder.Save(output);Console.WriteLine("PASS e-document panel constructs and lays out on STA without database access or desktop input");
  }catch(Exception e){failure=e;}});thread.SetApartmentState(ApartmentState.STA);thread.Start();thread.Join();if(failure is not null)throw new Exception("Offscreen WPF layout failed",failure);
 }
}
