using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace MiapaxERP.Lisans.Core;

public sealed record Sektor(string Kod,string Ad,string UretimAdi,string StokAdi,string Aciklama,string[] OnerilenModuller);
public sealed record Modul(string Kod,string Ad);
public static class UrunKatalogu
{
    public static readonly Modul[] Moduller=[new("STOK","Stok ve hareketler"),new("URETIM","Reçete ve üretim"),new("SATIS","Cari ve satış"),new("FINANS","Muhasebe ve finans"),new("SATINALMA","Satın alma"),new("IK","İnsan kaynakları"),new("CRM","CRM"),new("ETICARET","E-ticaret"),new("DISTICARET","Dış ticaret"),new("KROKI","Sulama ve kroki"),new("RESTORAN","Masa, adisyon ve mutfak"),new("MOBIL","Mobil saha ve yönetim"),new("LABORATUVAR","Laboratuvar ve kalite kontrol"),new("RAPOR","Raporlar")];
    public static readonly Sektor[] Sektorler=[
        new("BORU","Boru üretimi","Üretim ve paketleme","Hammadde / mamul","Metre, adet ve KG kendi stok birimleriyle izlenir.",["STOK","URETIM","SATIS","FINANS","KROKI","RAPOR"]),
        new("YEDEK","Yedek parça","Montaj / kit hazırlama","Parça ve ürün","Parça kodu ve birim bazında stok, alış ve satış.",["STOK","SATIS","FINANS","SATINALMA","RAPOR"]),
        new("RESTORAN","Restoran","Mutfak reçeteleri","Malzeme / menü","Masa, adisyon, mutfak, ödeme ve reçeteli tüketim.",["STOK","URETIM","SATIS","FINANS","RESTORAN","RAPOR"]),
        new("SUNGER","Sünger üretimi","Üretim / kesim reçeteleri","Hammadde / sünger","KG, M3, M2 ve adet dönüşümleri yalnız açık reçete verisiyle yapılır.",["STOK","URETIM","SATIS","FINANS","RAPOR"]),
        new("GENEL","Genel işletme","Reçeteli üretim","Stok kartları","Sektör bağımsız birim ve miktar takibi.",["STOK","SATIS","FINANS","RAPOR"])
    ];
    public static Sektor SektorBul(string code)=>Sektorler.SingleOrDefault(x=>x.Kod==code)??throw new ArgumentException("Sektör bulunamadı.");
    public static void ModulDogrula(IEnumerable<string> modules)
    {
        var m=modules.ToHashSet(StringComparer.Ordinal);
        if(m.Count==0||m.Any(x=>!Moduller.Any(a=>a.Kod==x)))throw new ArgumentException("Geçersiz modül seçimi.");
        foreach(var (parent,required) in new[]{("LABORATUVAR","STOK"),("URETIM","STOK"),("RESTORAN","STOK"),("RESTORAN","SATIS"),("RESTORAN","FINANS"),("RESTORAN","URETIM")})
            if(m.Contains(parent)&&!m.Contains(required))throw new ArgumentException(parent+" için "+required+" modülü gerekli.");
    }
    public static string? YetkiModulu(string permission)=>permission.Split('.')[0] switch
    {"STOCK" or "WAREHOUSE" or "SHIPMENT"=>"STOK","PRODUCTION"=>"URETIM","CUSTOMER" or "SALES"=>"SATIS","FINANCE" or "CHECKNOTE" or "ACCOUNTING"=>"FINANS","PURCHASE"=>"SATINALMA","HR"=>"IK","CRM" or "FIELD"=>"CRM","ECOM"=>"ETICARET","LAB" or "PRESSURE"=>"LABORATUVAR","TRADE"=>"DISTICARET","REPORT"=>"RAPOR","RESTAURANT"=>"RESTORAN",_=>null};
}
public sealed record ImzaliLisans(int Version,string Payload,string Signature);
public sealed record LisansIcerigi(int Schema,string LicenseId,string CustomerId,string Company,string Sector,string[] Modules,string DeviceId,string DatabaseId,DateTimeOffset IssuedAt,DateTimeOffset NotBefore,DateTimeOffset? ExpiresAt,DateTimeOffset ValidUntil,int Revision);
public static class LisansKripto
{
    public static readonly JsonSerializerOptions Json=new(JsonSerializerDefaults.Web);
    public static string Ozet(string text)=>Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(text)));
    public static LisansIcerigi Dogrula(ImzaliLisans envelope,string publicKey,string device,string database,DateTimeOffset now)
    {
        if(envelope.Version!=1 || envelope.Payload.Length>24000 || envelope.Signature.Length>2048)throw new InvalidDataException("Lisans biçimi geçersiz.");
        byte[] body,signature;try{body=Convert.FromBase64String(envelope.Payload);signature=Convert.FromBase64String(envelope.Signature);}catch(FormatException){throw new InvalidDataException("Lisans kodlaması geçersiz.");}
        using var rsa=RSA.Create();rsa.ImportFromPem(publicKey);
        if(rsa.KeySize<3072||!rsa.VerifyData(body,signature,HashAlgorithmName.SHA256,RSASignaturePadding.Pss))throw new CryptographicException("Lisans imzası doğrulanamadı.");
        var p=JsonSerializer.Deserialize<LisansIcerigi>(body,Json)??throw new InvalidDataException("Lisans boş.");
        if(p.Schema!=1||!Guid.TryParse(p.LicenseId,out _)||!Guid.TryParse(p.CustomerId,out _)||string.IsNullOrWhiteSpace(p.Company)||p.Company.Length>160||p.Revision<1)throw new InvalidDataException("Lisans bilgileri geçersiz.");
        UrunKatalogu.SektorBul(p.Sector);UrunKatalogu.ModulDogrula(p.Modules);
        if(p.DeviceId!=device||p.DatabaseId!=database)throw new UnauthorizedAccessException("Lisans bu cihaz veya veritabanına ait değil.");
        if(p.IssuedAt>now.AddMinutes(5)||p.NotBefore>now||p.ValidUntil<=now||p.ExpiresAt<=now||p.ValidUntil<=p.IssuedAt||p.ValidUntil>p.IssuedAt.AddDays(7).AddMinutes(1)||p.ExpiresAt.HasValue&&p.ValidUntil>p.ExpiresAt.Value)
            throw new UnauthorizedAccessException("Lisansın süresi veya doğrulama süresi geçersiz. İnternetten yenileyin.");
        return p;
    }
    public static ImzaliLisans Imzala(LisansIcerigi payload,RSA privateKey)
    {
        byte[] data=JsonSerializer.SerializeToUtf8Bytes(payload,Json);
        return new(1,Convert.ToBase64String(data),Convert.ToBase64String(privateKey.SignData(data,HashAlgorithmName.SHA256,RSASignaturePadding.Pss)));
    }
}
