package com.miapaxerp.mobile;
import java.net.URL;
import java.security.*;
import java.security.cert.*;
import javax.net.ssl.*;

public final class LanTls {
 private LanTls(){}
 public static boolean privateIp(String host){
  String[] p=host.split("\\.",-1);if(p.length!=4)return false;
  int[] n=new int[4];try{for(int i=0;i<4;i++){if(!p[i].matches("0|[1-9][0-9]{0,2}"))return false;n[i]=Integer.parseInt(p[i]);if(n[i]>255)return false;}}catch(Exception e){return false;}
  return n[0]==10||(n[0]==172&&n[1]>=16&&n[1]<=31)||(n[0]==192&&n[1]==168);
 }
 public static void validate(String base,String pin)throws Exception{
  URL u=new URL(base);
  if(!u.getProtocol().equals("https")||u.getUserInfo()!=null||u.getQuery()!=null||u.getRef()!=null||!(u.getPath().isEmpty()||u.getPath().equals("/")))throw new IllegalArgumentException("HTTPS adresi geçersiz.");
  if(pin.isEmpty()){
   if(!u.getHost().matches("(?i)[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+")||u.getHost().length()>253||u.getHost().matches("[0-9.]+")||!(u.getPort()==-1||u.getPort()==443||u.getPort()==8443))throw new IllegalArgumentException("HTTPS alan adı ve 443 / 8443 portu gerekli.");
  }else if(!pin.matches("[0-9A-Fa-f]{64}")||!privateIp(u.getHost())||u.getPort()!=5189)throw new IllegalArgumentException("Yerel ağ adresi veya bilgisayar kimliği geçersiz.");
 }
 public static byte[] decodeHex(String s){if(!s.matches("[0-9a-fA-F]{64}"))throw new IllegalArgumentException("Kimlik geçersiz.");byte[] b=new byte[32];for(int i=0;i<32;i++)b[i]=(byte)Integer.parseInt(s.substring(i*2,i*2+2),16);return b;}
 public static void verify(X509Certificate certificate,String pin)throws CertificateException{
  certificate.checkValidity();
  try{if(!MessageDigest.isEqual(decodeHex(pin),MessageDigest.getInstance("SHA-256").digest(certificate.getEncoded())))throw new CertificateException("Fabrika bilgisayarının kimliği eşleşmiyor.");}
  catch(GeneralSecurityException e){if(e instanceof CertificateException)throw (CertificateException)e;throw new CertificateException(e);}
  catch(IllegalArgumentException e){throw new CertificateException(e);}
 }
 public static SSLSocketFactory factory(final String pin)throws GeneralSecurityException{
  decodeHex(pin);SSLContext context=SSLContext.getInstance("TLS");
  context.init(null,new TrustManager[]{new X509TrustManager(){
   public X509Certificate[] getAcceptedIssuers(){return new X509Certificate[0];}
   public void checkClientTrusted(X509Certificate[] chain,String auth)throws CertificateException{throw new CertificateException("İstemci sertifikası desteklenmiyor.");}
   public void checkServerTrusted(X509Certificate[] chain,String auth)throws CertificateException{if(chain==null||chain.length==0)throw new CertificateException("Sertifika yok.");verify(chain[0],pin);}
  }},new SecureRandom());return context.getSocketFactory();
 }
}
