package com.miapaxerp.mobile;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import android.security.keystore.*;
import android.util.Base64;
import java.net.*;
import javax.net.ssl.HttpsURLConnection;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.SecretKey;
import java.security.*;
import java.nio.charset.StandardCharsets;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

public class MainActivity extends Activity {
 final ExecutorService worker=Executors.newSingleThreadExecutor();
 final Handler ui=new Handler(Looper.getMainLooper());
 JSONObject state=new JSONObject(); WebView web; LinearLayout root; TextView status,localStatus;
 volatile boolean active=false,checking=false,locked=false; int generation=0;
 static final String ORIGIN="https://appassets.boruerp.local/";
 final Runnable ticker=new Runnable(){public void run(){if(active&&!locked&&!state.optString("token").isEmpty())sync();ui.postDelayed(this,5000);}};
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,WindowManager.LayoutParams.FLAG_SECURE);try{load();}catch(Exception e){layout("Cihaz kaydı açılamadı");root.addView(text("Şifreli kayıt okunamadı. Veri kaybını önlemek için yeni eşleme yapılmadı. Uygulama verilerini silmeden destek alın.",16));return;}if(!state.optString("token").isEmpty()&&!locked)connect();else setup();}
 @Override public void onResume(){super.onResume();active=true;ui.removeCallbacks(ticker);ui.post(ticker);}
 @Override public void onPause(){active=false;ui.removeCallbacks(ticker);super.onPause();}
 @Override public void onDestroy(){generation++;if(web!=null)web.destroy();worker.shutdownNow();super.onDestroy();}
 TextView text(String s,int size){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(Color.rgb(25,43,53));v.setPadding(0,14,0,10);return v;}
 void layout(String title){if(web!=null){web.destroy();web=null;}root=new LinearLayout(this);root.setOrientation(1);root.setPadding(24,24,24,20);root.setBackgroundColor(Color.rgb(243,247,248));root.setOnApplyWindowInsetsListener((v,insets)->{v.setPadding(16+insets.getSystemWindowInsetLeft(),16+insets.getSystemWindowInsetTop(),16+insets.getSystemWindowInsetRight(),16+insets.getSystemWindowInsetBottom());return insets;});setContentView(root);ImageView logo=new ImageView(this);logo.setImageResource(getResources().getIdentifier("miapaxerp","drawable",getPackageName()));root.addView(logo,new LinearLayout.LayoutParams(120,120));root.addView(text(title,25));}
 void notice(String message){if(status!=null)status.setText(message);if(localStatus!=null)localStatus.setText(message);Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
 void setup(){
  localStatus=null;generation++;layout("MiaPaxERP Mobil · 2.8.1");ScrollView setupScroll=new ScrollView(this);ViewParent previousParent=root.getParent();if(previousParent instanceof ViewGroup)((ViewGroup)previousParent).removeView(root);setupScroll.addView(root);setContentView(setupScroll);
  root.addView(text("Yönetici panelinden size özel 15 dakikalık eşleme kodu alın. Her çalışan ayrı hesapla bağlanır.",16));
  EditText address=new EditText(this);address.setHint("https://mobil.firmaniz.com");address.setSingleLine();address.setInputType(17);address.setText(state.optString("base"));root.addView(address);
  EditText code=new EditText(this);code.setHint("Tek kullanımlık eşleme kodu");code.setInputType(129);code.setSingleLine();root.addView(code);
  status=text(locked?"Erişim kapalı. Yöneticiden yeni eşleme kodu alın.":"İnternet bağlantısı için üstteki alanları, aynı Wi-Fi için aşağıdaki bölümü kullanın.",15);root.addView(status);
  Button b=new Button(this);b.setText("Hesabımı bağla");root.addView(b);b.setOnClickListener(v->{
   
   String key=code.getText().toString().trim();if(key.startsWith("BERP-LAN1:")){localPair(key,b,code);return;}
   if(key.startsWith("MPX-HTTPS1:")||key.startsWith("MPX-CONNECT1:")){internetPacket(key,address,code,b);return;}
   try{URL u=new URL(address.getText().toString().trim());
    LanTls.validate(address.getText().toString().trim(),"");
    if(!key.matches("[0-9a-fA-F]{64}"))throw new Exception();
    beginPair("https://"+u.getHost()+(u.getPort()==8443?":8443":""),key,"",b,code);
   }catch(Exception ex){notice("HTTPS alan adı ve 64 karakterlik eşleme kodunu kontrol edin.");}
  });
  root.addView(text("Sunucudan gelen bağlantı kodu",20));
  root.addView(text("Ana sunucunun bağlantı panelinden MPX-CONNECT1: veya yönetici hesabından MPX-HTTPS1: ile başlayan kodu alın. Adres kodu tek başına hesap açmaz.",14));
  EditText serverCode=new EditText(this);serverCode.setHint("Bağlantı / HTTPS telefon kodunu yapıştırın");serverCode.setSingleLine();serverCode.setInputType(129);root.addView(serverCode);
  Button useCode=new Button(this);useCode.setText("Bağlantı kodunu uygula");root.addView(useCode);useCode.setOnClickListener(v->internetPacket(serverCode.getText().toString().trim(),address,code,b));
  Button health=new Button(this);health.setText("İnternet bağlantısını kontrol et");root.addView(health);health.setOnClickListener(v->{
   final String base=address.getText().toString().trim();try{LanTls.validate(base,"");}catch(Exception ex){notice("Önce geçerli mobil HTTPS adresini girin veya bağlantı kodunu uygulayın.");return;}
   health.setEnabled(false);notice("HTTPS ve mobil servis kontrol ediliyor…");worker.execute(()->{try{JSONObject h=new JSONObject(net(base,"/api/mobile/v2/health",null,"",""));if(!h.optString("service").equals("MiapaxERP.MobileServer")||h.optInt("api")!=2)throw new IOException();ui.post(()->notice("HTTPS ve MiaPaxERP mobil servisi doğrulandı. Hesap erişimi eşleme sırasında doğrulanır."));}catch(Exception ex){ui.post(()->notice("Mobil HTTPS doğrulanamadı. Alan adı, sertifika ve modem 443 / 8443 yönlendirmesini kontrol edin."));}finally{ui.post(()->health.setEnabled(true));}});
  });
  root.addView(text("Aynı Wi-Fi ile bağlantı",20));
  root.addView(text("Ana bilgisayarda Android / Mobil hesaplar menüsünden 'Aynı Wi-Fi için telefon kodu' üretin. Kodu aşağıya bütünüyle yapıştırın; yukarıdaki adresi doldurmanız gerekmez.",14));
  EditText localCode=new EditText(this);localCode.setHint("BERP-LAN1: ile başlayan kod");localCode.setInputType(129);localCode.setSingleLine();root.addView(localCode);
  Button localButton=new Button(this);localButton.setText("Aynı Wi-Fi ile bağlan");root.addView(localButton);
  localStatus=text("Kodu yapıştırdıktan sonra 'Aynı Wi-Fi ile bağlan' düğmesine basın.",14);root.addView(localStatus);
  localButton.setOnClickListener(v->localPair(localCode.getText().toString().trim(),localButton,localCode));
 }
 void internetPacket(String raw,EditText address,EditText code,Button connectButton){try{
  if(raw.length()>8192)throw new Exception();boolean pair=raw.startsWith("MPX-HTTPS1:");int prefix=pair?11:raw.startsWith("MPX-CONNECT1:")?13:0;if(prefix==0)throw new Exception();
  JSONObject packet=new JSONObject(new String(Base64.decode(raw.substring(prefix),Base64.URL_SAFE|Base64.NO_PADDING|Base64.NO_WRAP),StandardCharsets.UTF_8));
  if(pair&&packet.getInt("v")!=1)throw new Exception();String endpoint=pair?packet.getString("address"):packet.getString("MobilHttps");LanTls.validate(endpoint,"");
  String key=pair?packet.getString("code"):"";if(pair&&!key.matches("[0-9a-fA-F]{64}"))throw new Exception();
  new AlertDialog.Builder(this).setTitle("Ana sunucu adresini doğrula").setMessage(endpoint+"\n\nBu kodu kendi firmanızdaki MiaPaxERP ana sunucusundan aldıysanız uygulayın. Adres kodu tek başına erişim yetkisi vermez.")
   .setNegativeButton("Vazgeç",null).setPositiveButton("Bilgileri uygula",(dialog,which)->{address.setText(endpoint);code.setText(key);notice(pair?"Adres ve tek kullanımlık kod dolduruldu. 'Hesabımı bağla' düğmesine basın.":"Mobil adres dolduruldu. Yönetici hesabınızdan size özel 15 dakikalık eşleme kodunu alın.");}).show();
 }catch(Exception ex){notice("Bağlantı kodu geçersiz veya mobil HTTPS adresi içermiyor. Ana sunucudan yeni kod alın.");}}
 void localPair(String raw,Button button,EditText code){try{
  if(!raw.startsWith("BERP-LAN1:")||raw.length()>4096)throw new Exception();   JSONObject packet=new JSONObject(new String(Base64.decode(raw.substring(10),Base64.URL_SAFE|Base64.NO_PADDING|Base64.NO_WRAP),StandardCharsets.UTF_8));
   if(packet.getInt("v")!=1)throw new Exception();String endpoint=packet.getString("address"),pin=packet.getString("pin"),pairCode=packet.getString("code");
   if(!pairCode.matches("[0-9a-fA-F]{64}"))throw new Exception();LanTls.validate(endpoint,pin);
   new AlertDialog.Builder(this).setTitle("Fabrika bilgisayarını doğrula").setMessage("Adres: "+endpoint+"\nBilgisayar kimliği: "+pin.substring(0,16)+"…\n\nBu kodu kendi ana bilgisayarınızdaki Miapax ERP ekranından aldıysanız bağlanın.")
    .setNegativeButton("Vazgeç",null).setPositiveButton("Bağlan",(dialog,which)->beginPair(endpoint,pairCode,pin,button,code)).show();
 }catch(Exception ex){notice("Yerel eşleme kodu geçersiz. Bilgisayarda 'Aynı Wi-Fi için telefon kodu' düğmesinden yeni kod üretip tamamını yapıştırın.");}}
 void beginPair(String base,String key,String pin,Button button,EditText code){
  button.setEnabled(false);code.setText("");notice("Fabrika hesabı doğrulanıyor…");
  worker.execute(()->{try{
   JSONObject d=new JSONObject();d.put("code",key);d.put("name",Build.MANUFACTURER+" "+Build.MODEL);
   JSONObject paired=new JSONObject(net(base,"/api/mobile/v2/pair",d,"",pin));
   if(state.optJSONArray("queue")!=null&&state.optJSONArray("queue").length()>0){if(!base.equals(state.optString("base"))||!paired.getString("id").equals(state.getJSONObject("profile").getString("id")))throw new IOException("Bekleyen kayıtlar farklı hesaba taşınamaz.");}
   else{state=new JSONObject();state.put("queue",new JSONArray());state.put("cache",new JSONObject());}
   state.put("base",base);state.put("token",paired.getString("token"));state.put("pin",pin);save();locked=false;
   ui.post(()->{if(!isFinishing()&&!isDestroyed())connect();});
  }catch(Exception ex){ui.post(()->{button.setEnabled(true);notice(message(ex));});}});
 }
 static class ServerError extends IOException{int code;ServerError(int c,String msg){super(msg);code=c;}}
 String message(Exception e){if(e instanceof ServerError){int c=((ServerError)e).code;return c==403?"Hesap, cihaz, lisans veya modül erişimi kapalı.":c==409?"Çakışma: fabrika kaydı değişmiş; bekleyen kayıtları inceleyin.":c==400?"Girdi bilgilerini kontrol edin.":"Sunucu yanıtı: "+c;}return state.optString("pin").isEmpty()?"HTTPS bağlantısı kurulamadı. Mobil internet, sunucunun alan adı/sertifikası ve 443 / 8443 yönlendirmesini kontrol edin. Kodun süresi dolduysa yeni kod alın.":"Yerel bağlantı kurulamadı. Ana program, aynı Wi-Fi ve Windows yerel ağ iznini kontrol edin. Kodun süresi dolduysa yeni kod alın.";}
 String net(String base,String path,JSONObject body,String token)throws Exception{return net(base,path,body,token,state.optString("pin"));}
 String net(String base,String path,JSONObject body,String token,String pin)throws Exception{
  LanTls.validate(base,pin);
  HttpsURLConnection c=(HttpsURLConnection)new URL(base+path).openConnection();
  if(!pin.isEmpty())c.setSSLSocketFactory(LanTls.factory(pin));
  try{c.setInstanceFollowRedirects(false);c.setConnectTimeout(10000);c.setReadTimeout(15000);c.setUseCaches(false);c.setRequestProperty("Accept","application/json");
   if(!token.isEmpty())c.setRequestProperty("Authorization","Bearer "+token);
   if(body!=null){c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=utf-8");byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8);c.setFixedLengthStreamingMode(bytes.length);try(OutputStream out=c.getOutputStream()){out.write(bytes);}}
   int code=c.getResponseCode();if(code!=200)throw new ServerError(code,"HTTP "+code);
   ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){bytes.write(b,0,n);if(bytes.size()>4*1024*1024)throw new IOException("Yanıt çok büyük.");}}
   return new String(bytes.toByteArray(),StandardCharsets.UTF_8);
  }finally{c.disconnect();}
 }
 Object call(JSONObject body)throws Exception{String raw=net(state.getString("base"),"/api/mobile/v2/rpc",body,state.getString("token"));return new JSONTokener(raw).nextValue();}
 void profile()throws Exception{
  JSONObject profile=new JSONObject(net(state.getString("base"),"/api/mobile/v2/profile",null,state.getString("token")));
  long now=System.currentTimeMillis();state.put("profile",profile);state.put("verified",now);long until=java.time.OffsetDateTime.parse(profile.getString("offlineUntil")).toInstant().toEpochMilli();state.put("until",Math.min(until,now+7L*86400000));save();
 }
 boolean offlineAllowed(){long now=System.currentTimeMillis();return now>=state.optLong("verified")-300000&&now<state.optLong("until")&&state.has("profile")&&!locked;}
 void connect(){layout("Hesap doğrulanıyor…");worker.execute(()->{try{profile();ui.post(()->dashboard());}
  catch(Exception ex){if(ex instanceof ServerError&&((ServerError)ex).code==403){locked=true;ui.post(()->setup());}
   else if(offlineAllowed())ui.post(()->dashboard());else ui.post(()->{setup();notice("Hesap çevrimiçi doğrulanmalı. "+message(ex));});}});}
 void dashboard(){
  generation++;layout(state.optJSONObject("profile").optString("ad")+" · "+state.optJSONObject("profile").optString("rol"));
  root.removeAllViews();web=new WebView(this);WebView.setWebContentsDebuggingEnabled(false);
  WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setDomStorageEnabled(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);s.setSupportMultipleWindows(false);
  web.addJavascriptInterface(new Bridge(),"BoruMobile");
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return !r.getUrl().toString().equals(ORIGIN+"index.html");}
   @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){
    try{Uri u=r.getUrl();String path=u.getPath();if(!u.toString().startsWith(ORIGIN)||path==null||!path.matches("/[a-zA-Z0-9_.-]+"))throw new IOException();
     String mime=path.endsWith(".html")?"text/html":path.endsWith(".css")?"text/css":path.endsWith(".js")?"application/javascript":"application/json";
     Map<String,String> headers=new HashMap<>();headers.put("Content-Security-Policy","default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'");headers.put("X-Content-Type-Options","nosniff");
     return new WebResourceResponse(mime,"utf-8",200,"OK",headers,getAssets().open(path.substring(1)));
    }catch(Exception e){return new WebResourceResponse("text/plain","utf-8",403,"Blocked",new HashMap<>(),new ByteArrayInputStream(new byte[0]));}
   }
   @Override public void onPageFinished(WebView v,String url){if(url.equals(ORIGIN+"index.html")){String p=state.optJSONObject("profile").toString();v.evaluateJavascript("window.mobileProfile="+p+"; window.dispatchEvent(new Event('mobile-ready'));",null);}}
  });root.addView(web,new LinearLayout.LayoutParams(-1,-1));web.loadUrl(ORIGIN+"index.html");
 }
 String cacheKey(JSONObject d){String a=d.optString("action");return a.equals("province")?"province:"+d.optString("il")+":"+d.optString("ilce")+":"+d.optString("search")+":"+d.optInt("offset"):a.equals("load")?"load:"+d.optString("id"):a.equals("list")?"list:"+d.optString("il")+":"+d.optString("ilce")+":"+d.optString("koy"):"";}
 JSONArray queue()throws Exception{if(!state.has("queue"))state.put("queue",new JSONArray());return state.getJSONArray("queue");}
 void remove(int i)throws Exception{queue().remove(i);save();}
 void sync(){if(checking||state.optString("token").isEmpty())return;checking=true;worker.execute(()->{try{profile();sendQueue();ui.post(()->{if(web!=null)web.evaluateJavascript("window.dispatchEvent(new Event('mobile-sync'));",null);});}
  catch(Exception e){if(e instanceof ServerError&&((ServerError)e).code==403){locked=true;ui.post(()->{if(web!=null)web.evaluateJavascript("document.body.textContent='Mobil erişim kapalı. Yöneticinize başvurun.';",null);});}}
  finally{checking=false;}});}
 void sendQueue()throws Exception{
  for(int i=0;i<queue().length();){JSONObject item=queue().getJSONObject(i);if(item.has("error")){i++;continue;}
   try{call(item);state.put("cache",new JSONObject());remove(i);}
   catch(ServerError e){if(e.code==409||e.code==400){item.put("error",message(e));save();i++;}else throw e;}
  }
 }
 class Bridge{
  @JavascriptInterface public void postMessage(String raw){if(raw.length()>32768)return;final int stamp=generation;worker.execute(()->{String request="";JSONObject answer=new JSONObject();try{
   JSONObject d=new JSONObject(raw);request=d.getString("request");answer.put("request",request);
   if(locked||!offlineAllowed())throw new IOException("Hesap doğrulanmalı.");
   String action=d.optString("action");Object result;
   if(action.equals("queue"))result=queue();
   else if(action.equals("drop")){String op=d.getString("operation");for(int i=0;i<queue().length();i++)if(queue().getJSONObject(i).optString("operation").equals(op)){remove(i);break;}result=new JSONObject().put("ok",true);}
   else if(action.equals("logout")){if(queue().length()>0)throw new IOException("Gönderilmemiş kayıtlar var.");state=new JSONObject();save();locked=true;ui.post(()->setup());return;}
   else if(action.equals("save")){
    if(queue().length()>=1000)throw new IOException("1000 bekleyen kayıt sınırı doldu. Önce sunucuyla eşitleyin.");JSONObject data=d.getJSONObject("data");for(int i=0;i<queue().length();i++)if(queue().getJSONObject(i).getJSONObject("data").getString("id").equals(data.getString("id")))throw new IOException("Bu müşteri için bekleyen kayıt var. Önce eşitleyin veya çakışmayı çözün.");
    d.put("operation",UUID.randomUUID().toString());queue().put(d);save();
    try{sendQueue();}catch(Exception ex){if(ex instanceof ServerError&&((ServerError)ex).code==403){locked=true;throw ex;}}
    result=new JSONObject().put("queued",queue().length()>0);
   }else if(action.equals("list")||action.equals("load")||action.equals("province")||action.equals("report")){
    String key=cacheKey(d);try{result=call(d);if(!key.isEmpty()){state.getJSONObject("cache").put(key,result);save();}}
    catch(IOException e){if(e instanceof ServerError)throw e;if(key.isEmpty()||!state.getJSONObject("cache").has(key))throw e;result=state.getJSONObject("cache").get(key);}
   }else throw new IOException("İşlem desteklenmiyor.");
   answer.put("result",result);
  }catch(Exception ex){try{answer.put("request",request);answer.put("error",ex instanceof IOException&&!(ex instanceof ServerError)&&ex.getMessage()!=null?ex.getMessage():message(ex));}catch(Exception ignored){}}
  final String response=answer.toString();ui.post(()->{if(stamp==generation&&web!=null)web.evaluateJavascript("window.mobileReceive("+response+");",null);});});}
 }
 SecretKey key()throws Exception{KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(!ks.containsAlias("BoruERP.Mobile220")){KeyGenerator g=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");g.init(new KeyGenParameterSpec.Builder("BoruERP.Mobile220",KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());g.generateKey();}return (SecretKey)ks.getKey("BoruERP.Mobile220",null);}
 void save()throws Exception{Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());String iv=Base64.encodeToString(c.getIV(),Base64.NO_WRAP),data=Base64.encodeToString(c.doFinal(state.toString().getBytes(StandardCharsets.UTF_8)),Base64.NO_WRAP);if(!getSharedPreferences("mobile220",MODE_PRIVATE).edit().putString("iv",iv).putString("data",data).commit())throw new IOException("Cihaz kaydı yazılamadı.");}
 void load()throws Exception{SharedPreferences p=getSharedPreferences("mobile220",MODE_PRIVATE);if(!p.contains("data"))return;Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(p.getString("iv",""),Base64.NO_WRAP)));state=new JSONObject(new String(c.doFinal(Base64.decode(p.getString("data",""),Base64.NO_WRAP)),StandardCharsets.UTF_8));}
}
