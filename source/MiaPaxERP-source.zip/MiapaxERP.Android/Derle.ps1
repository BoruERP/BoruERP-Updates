param([string]$Araclar=(Join-Path $PSScriptRoot '..\AndroidAraclari'),[string]$Cikti=(Join-Path $PSScriptRoot '..\MiapaxERP-Teslim'),[switch]$Imzasiz,[string]$PlatformJar="")
$ErrorActionPreference='Stop'
$java=(Get-ChildItem (Join-Path $Araclar 'jdk') -Directory | Select-Object -First 1).FullName
$sdk=(Get-ChildItem (Join-Path $Araclar 'build-tools') -Directory | Select-Object -First 1).FullName
$platform=(Get-ChildItem (Join-Path $Araclar 'platform') -Directory | Select-Object -First 1).FullName
$platformKaynak=$platform
$platform=Join-Path $PSScriptRoot 'build\platform'
New-Item -ItemType Directory -Path $platform -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $platformKaynak 'android.jar') -Destination (Join-Path $platform 'android.jar') -Force
$env:JAVA_HOME=$java
$build=Join-Path $PSScriptRoot 'build'
foreach($folder in @($build,$Cikti,(Join-Path $build 'classes'),(Join-Path $build 'dex'),(Join-Path $PSScriptRoot 'res\drawable'))){New-Item -ItemType Directory -Path $folder -Force | Out-Null}
Copy-Item -LiteralPath (Join-Path $PSScriptRoot '..\MiapaxERP.Desktop\Assets\MiapaxERP_App.png') -Destination (Join-Path $PSScriptRoot 'res\drawable\miapaxerp.png') -Force
function Run([string]$exe,[string[]]$arguments){& $exe @arguments;if($LASTEXITCODE -ne 0){throw "$exe başarısız: $LASTEXITCODE"}}
$sources=@(Get-ChildItem (Join-Path $PSScriptRoot 'src') -Recurse -Filter '*.java' | ForEach-Object FullName)
if([string]::IsNullOrWhiteSpace($PlatformJar)){$PlatformJar=Join-Path $platform 'android.jar'}
if((Get-FileHash -LiteralPath $PlatformJar).Hash -ne (Get-FileHash -LiteralPath (Join-Path $platform 'android.jar')).Hash){throw 'PlatformJar seçilen Android SDK ile aynı değil.'}
Run (Join-Path $java 'bin\javac.exe') (@('-encoding','UTF-8','-source','8','-target','8','-classpath',$PlatformJar,'-d',(Join-Path $build 'classes'))+$sources)
Run (Join-Path $java 'bin\jar.exe') @('cf',(Join-Path $build 'classes.jar'),'-C',(Join-Path $build 'classes'),'.')
Run (Join-Path $sdk 'd8.bat') @('--min-api','26','--lib',(Join-Path $platform 'android.jar'),'--output',(Join-Path $build 'dex'),(Join-Path $build 'classes.jar'))
Run (Join-Path $sdk 'aapt2.exe') @('compile','--dir',(Join-Path $PSScriptRoot 'res'),'-o',(Join-Path $build 'res.zip'))
Run (Join-Path $sdk 'aapt2.exe') @('link','-o',(Join-Path $build 'unsigned.apk'),'-A',(Join-Path $PSScriptRoot 'assets'),'--manifest',(Join-Path $PSScriptRoot 'AndroidManifest.xml'),'-I',(Join-Path $platform 'android.jar'),(Join-Path $build 'res.zip'))
Add-Type -AssemblyName System.IO.Compression
$archive=[IO.Compression.ZipFile]::Open((Join-Path $build 'unsigned.apk'),[IO.Compression.ZipArchiveMode]::Update)
try{[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $build 'dex\classes.dex'),'classes.dex')|Out-Null}finally{$archive.Dispose()}
Run (Join-Path $sdk 'zipalign.exe') @('-f','-p','4',(Join-Path $build 'unsigned.apk'),(Join-Path $build 'aligned.apk'))
if($Imzasiz){Copy-Item -LiteralPath (Join-Path $build 'aligned.apk') -Destination (Join-Path $Cikti 'MiapaxERP-Mobil-v2.8.1-imzasiz.apk') -Force;Write-Output 'MiapaxERP Android derlemesi tamamlandi; mevcut anahtarla imzalama bekliyor.';exit 0}
$private=Join-Path $env:USERPROFILE 'BoruERP_GizliAnahtarlar';if(!(Test-Path -LiteralPath $private)){throw 'Mevcut Android imza anahtarı klasörü bulunamadı.'}
$passFile=Join-Path $private 'android-signing-password.dpapi';$keystore=Join-Path $private 'boruerp-android.jks'
if(!(Test-Path -LiteralPath $passFile) -or !(Test-Path -LiteralPath $keystore)){throw 'Mevcut Android imza anahtarı veya parola kaydı bulunamadı. Yeni anahtar oluşturulmadı.'}
if(!(Test-Path -LiteralPath $passFile)){
    if(Test-Path -LiteralPath $keystore){throw 'Mevcut Android anahtarının parola dosyası bulunamadı. Yeni anahtar oluşturulmadı.'}
    $password=[Convert]::ToBase64String([Security.Cryptography.RandomNumberGenerator]::GetBytes(32))
    [IO.File]::WriteAllBytes($passFile,[Security.Cryptography.ProtectedData]::Protect([Text.Encoding]::UTF8.GetBytes($password),$null,[Security.Cryptography.DataProtectionScope]::CurrentUser))
}
$env:BORUERP_ANDROID_STOREPASS=[Text.Encoding]::UTF8.GetString([Security.Cryptography.ProtectedData]::Unprotect([IO.File]::ReadAllBytes($passFile),$null,[Security.Cryptography.DataProtectionScope]::CurrentUser))
try{
    if(!(Test-Path -LiteralPath $keystore)){Run (Join-Path $java 'bin\keytool.exe') @('-genkeypair','-keystore',$keystore,'-storetype','JKS','-alias','MiapaxERP','-keyalg','RSA','-keysize','3072','-validity','10000','-dname','CN=MiapaxERP Mobil,O=MiapaxERP,C=TR','-storepass:env','BORUERP_ANDROID_STOREPASS','-keypass:env','BORUERP_ANDROID_STOREPASS')}
    $apk=Join-Path $Cikti 'MiapaxERP-Mobil-v2.8.1.apk'
    Run (Join-Path $sdk 'apksigner.bat') @('sign','--ks',$keystore,'--ks-key-alias','boruerp','--ks-pass','env:BORUERP_ANDROID_STOREPASS','--key-pass','env:BORUERP_ANDROID_STOREPASS','--out',$apk,(Join-Path $build 'aligned.apk'))
    Run (Join-Path $sdk 'apksigner.bat') @('verify','--verbose','--print-certs',$apk)
    Run (Join-Path $sdk 'aapt2.exe') @('dump','badging',$apk)
    Get-FileHash -LiteralPath $apk -Algorithm SHA256
}finally{Remove-Item Env:BORUERP_ANDROID_STOREPASS -ErrorAction SilentlyContinue}
