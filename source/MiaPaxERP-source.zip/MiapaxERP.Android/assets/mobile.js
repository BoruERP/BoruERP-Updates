'use strict';
window.chrome={webview:{postMessage:d=>BoruMobile.postMessage(JSON.stringify(d)),addEventListener:(name,handler)=>window.mobileReceive=d=>handler({data:d})}};
const mobileBar=document.createElement('section');mobileBar.className='mobilebar';
const who=document.createElement('strong');who.textContent='Hesap yükleniyor…';mobileBar.append(who);
const syncStatus=document.createElement('span');mobileBar.append(syncStatus);
const pendingButton=document.createElement('button');pendingButton.textContent='Bekleyen kayıtlar';mobileBar.append(pendingButton);
const logoutButton=document.createElement('button');logoutButton.textContent='Çıkış';mobileBar.append(logoutButton);
document.body.prepend(mobileBar);
const reportPanel=document.createElement('section');reportPanel.className='reports';reportPanel.hidden=true;document.querySelector('main').before(reportPanel);
const sections=[['stok','Stok'],['satinalma','Satın alma'],['satis','Satış'],['uretim','Üretim'],['muhasebe','Muhasebe'],['gelirgider','Gelir / gider']];
let reportBody=null;
async function report(section){reportPanel.hidden=false;reportPanel.replaceChildren();const close=document.createElement('button');close.textContent='Raporu kapat';close.onclick=()=>reportPanel.hidden=true;reportPanel.append(close);
 const h=document.createElement('h2');h.textContent='Fabrika raporu';reportPanel.append(h);
 try{const data=await rpc('report',{section});const stamp=document.createElement('p');stamp.textContent='Sunucudan okundu: '+new Date(data.okumaZamani).toLocaleString('tr-TR')+' · En fazla 200 kayıt';reportPanel.append(stamp);
 for(const row of data.kayitlar){const card=document.createElement('article');for(const [key,value] of Object.entries(row)){const p=document.createElement('p');p.textContent=key+': '+(value??'—');card.append(p);}reportPanel.append(card);}}
 catch(e){const p=document.createElement('p');p.textContent=e.message;reportPanel.append(p);}}
async function queueStatus(){try{const rows=await rpc('queue');syncStatus.textContent=rows.length?rows.length+' kayıt gönderilmeyi bekliyor'+(rows.some(x=>x.error)?' · Çakışma / girdi hatası var':''):'Kuyruk boş';}catch(e){syncStatus.textContent=e.message;}}
pendingButton.onclick=async()=>{try{const rows=await rpc('queue');const d=document.createElement('dialog');const h=document.createElement('h2');h.textContent='Gönderilmemiş kayıtlar';d.append(h);
 if(!rows.length){const p=document.createElement('p');p.textContent='Gönderilmemiş kayıt yok.';d.append(p);}
 for(const item of rows){const a=document.createElement('article');const p=document.createElement('pre');p.textContent=(item.error||'Bağlantı gelince gönderilecek')+'\n'+JSON.stringify(item.data,null,2)+'\nGörüşme: '+item.visit;a.append(p);
 const b=document.createElement('button');b.textContent='Bu bekleyen kaydı kaldır';b.onclick=async()=>{if(!confirm('Bu kayıt henüz fabrikaya gönderilmemiş olabilir. Gerekli bilgileri kopyaladınız mı? Kuyruktan kaldırma geri alınamaz.'))return;await rpc('drop',{operation:item.operation});a.remove();queueStatus();};a.append(b);d.append(a);}
 const close=document.createElement('button');close.textContent='Kapat';close.onclick=()=>{d.close();d.remove();};d.append(close);document.body.append(d);d.showModal();}catch(e){syncStatus.textContent=e.message;}};
logoutButton.onclick=()=>{if(confirm('Bu cihazdaki hesap oturumunu kapatmak istiyor musunuz? Bekleyen kayıt varsa çıkış engellenir.'))rpc('logout').catch(e=>syncStatus.textContent=e.message);};
window.addEventListener('mobile-ready',()=>{who.textContent=window.mobileProfile.ad+' · '+(window.mobileProfile.rol==='SAHA'?'Saha satış':'Patron');if(window.mobileProfile.rol==='PATRON')for(const [code,title] of sections){const b=document.createElement('button');b.textContent=title;b.onclick=()=>report(code);mobileBar.append(b);}if(Array.isArray(window.mobileProfile.modules)&&!window.mobileProfile.modules.includes('CRM')){document.querySelector('main').style.display='none';document.querySelector('.controls').style.display='none';document.getElementById('status').textContent='Saha müşteri girişi için CRM modülü lisansınıza eklenmeli.';}queueStatus();});
window.addEventListener('mobile-sync',()=>{queueStatus();if(!document.querySelector('dialog[open]'))document.getElementById('refresh').click();});
document.getElementById('kroki').hidden=true;
setInterval(queueStatus,10000);
