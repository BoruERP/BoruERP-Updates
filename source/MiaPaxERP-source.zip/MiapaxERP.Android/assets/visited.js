'use strict';
const provinceContacts={epoch:0,busy:false,next:0,more:false,rows:new Map(),timer:null};
function provinceContactsReset(){
 clearTimeout(provinceContacts.timer);provinceContacts.epoch++;provinceContacts.busy=false;provinceContacts.next=0;provinceContacts.more=false;provinceContacts.rows.clear();
 $('visitedPanel').hidden=!province;$('visitedRows').replaceChildren();$('visitedSearch').value='';$('visitedStatus').textContent='';$('visitedMore').hidden=true;
 if(province){$('visitedHeading').textContent=province.name+(district?' / '+district.name:'')+' · Görüşülen kişiler';provinceContactsLoad(true);}
}
async function provinceContactsLoad(reset){
 if(!province||provinceContacts.busy||(!reset&&!provinceContacts.more))return;
 const epoch=provinceContacts.epoch,il=province.id,ilce=district?.id||'',search=$('visitedSearch').value.trim(),offset=reset?0:provinceContacts.next;
 provinceContacts.busy=true;$('visitedMore').disabled=$('visitedRefresh').disabled=true;$('visitedStatus').textContent='Görüşülen kişiler yükleniyor…';
 try{
  const page=await rpc('province',{il,ilce,search,offset});
  if(epoch!==provinceContacts.epoch)return;
  if(reset)provinceContacts.rows.clear();
  for(const row of page.rows)provinceContacts.rows.set(row.id,row);
  provinceContacts.next=page.nextOffset;provinceContacts.more=page.hasMore;
  $('visitedRows').replaceChildren();
  for(const row of provinceContacts.rows.values()){
   const button=document.createElement('button');button.type='button';
   const name=document.createElement('strong');name.textContent=row.ad;
   const where=document.createElement('span');where.textContent=(districts.find(d=>d.id===row.ilceId)?.name||row.ilceId)+' / '+row.koy;
   const when=document.createElement('small');when.textContent=new Date(row.sonGorusme).toLocaleString('tr-TR')+' · '+row.telefon;
   const preview=document.createElement('span');preview.className='visitPreview';preview.textContent=row.sonuc;
   button.append(name,where,when,preview);button.onclick=()=>edit(row.id);$('visitedRows').append(button);
  }
  $('visitedStatus').textContent=provinceContacts.rows.size?provinceContacts.rows.size+' kişi gösteriliyor':'Bu seçimde görüşme kaydı bulunamadı.';
  $('visitedMore').hidden=!page.hasMore;
 }catch(e){if(epoch===provinceContacts.epoch)$('visitedStatus').textContent=e.message||String(e);}
 finally{if(epoch===provinceContacts.epoch){provinceContacts.busy=false;$('visitedMore').disabled=$('visitedRefresh').disabled=false;}}
}
async function provinceContactsRefresh(force=false){
 if(!province||document.querySelector('dialog[open]')||(!force&&(provinceContacts.rows.size>100||document.activeElement===$('visitedSearch'))))return;
 await provinceContactsLoad(true);
}
$('visitedSearch').oninput=()=>{clearTimeout(provinceContacts.timer);provinceContacts.timer=setTimeout(()=>{provinceContacts.epoch++;provinceContacts.busy=false;provinceContactsLoad(true);},300);};
$('visitedRefresh').onclick=()=>provinceContactsRefresh(true);
$('visitedMore').onclick=()=>provinceContactsLoad(false);
window.addEventListener('mobile-sync',()=>provinceContactsRefresh());
setInterval(()=>{if(!document.hidden)provinceContactsRefresh();},5000);
