# Tema ve takvim değişiklikleri — 4 Kasım 2026

Ana proje: `C:\MiapaxERP\MiapaxERP\MiapaxERP.Desktop`

## Kullanım

Visual Studio'da eski çalışan derlemeyi durdurun ve yeniden çalıştırın.
Ayarlar içindeki **Tema ve Ana Sayfayı Özelleştir…** düğmesiyle koleksiyonu seçin.
VIP, Modern, Doğal, Eskitme, Kültürel ve önceki temalar desteklenir.
Menü konumu, bölüm sırası, yoğunluk, kısayol sütunları, köşe ve gölge ayrı ayarlanır.
Önceden bulunan renk, yazı tipi, boyut, logo, arka plan ve kart görünürlüğü ayarları korunmuştur.
Tercihler kullanıcıya ve bilgisayara özeldir.

Uygulamadaki MessageBox çağrıları ortak modern WPF penceresine yönlendirilir.
Evet/Hayır ve Vazgeç sonuçları korunur; pencereyi kapatmak onay vermez.

Takvim açılışta bugün, yarın ve gecikmiş bekleyen işleri okur. Uygulama açıkken
30 saniyede bir zamanı gelen işleri kontrol eder. Her plan/tarih aynı oturumda bir kez
bildirilir; yeniden girişte bekleyen işler tekrar özetlenir. Tamamlanan/iptal edilen
planlar bildirilmez. Üst çubuktaki **Takvim** düğmesi özeti yeniden açar.
SQL bağlantısı düzelince otomatik kontrol tekrar dener. Mevcut takvim yetkileri korunur.
Program tamamen kapalıyken bildirim veren bir Windows hizmeti kurulmamıştır.

## Doğrulama

```powershell
dotnet run --project MiapaxERP.Tests.TemaTakvim/TemaTakvimTestleri.csproj -c Release
dotnet build MiapaxERP.slnx -c Release
dotnet test MiapaxERP.Tests/MiapaxERP.Tests.csproj -c Release
```

53 WPF/hatırlatma/tercih kontrolü ve mevcut 3 test başarılıdır.
Test programı SQL, güncelleyici veya normal giriş akışını başlatmadan izole görünüm
pencereleri oluşturur. Görseller `bin/Release/net10.0-windows/Sonuclar` klasöründedir.
Takvim SQL sunucusuyla uçtan uca giriş/kayıt/bildirim testi yapılmamıştır.
Tam yeniden derlemede önceden mevcut ExcelVeYazdirmaPenceresi.xaml.cs:574 CS8629 uyarısı sürer.

Değişiklik öncesi kaynak yedeği: `C:\MiapaxERP\MiapaxERP\TemaTakvimYedek-20261104-142524`.
SQL şeması, kayıtları ve güncelleme manifestleri bu çalışma kapsamında değiştirilmedi.
Bu değişiklikler yereldir; GitHub'daki 1.7.1 yayını güncellenmedi.
