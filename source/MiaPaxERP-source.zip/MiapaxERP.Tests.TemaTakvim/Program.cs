using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using MiapaxERP.Desktop;

internal static class Program
{
    private static int count;
    private static readonly string output = Path.Combine(AppContext.BaseDirectory, "Sonuclar");
    [STAThread]
    static int Main()
    {
        Directory.CreateDirectory(output);

        var app = new Application { ShutdownMode = ShutdownMode.OnExplicitShutdown };
        app.Resources.MergedDictionaries.Add(new ResourceDictionary { Source = new Uri("pack://application:,,,/MiapaxERP.Desktop;component/Assets/ModernKontroller.xaml") });
        Tema170.Uygula(new GorunumTercihleri());
        TemaPencereServisi.Baslat();
        var now = new DateTime(2026,11,4,14,30,0);
        Check("Bugünkü plan açılışta görünür", new TakvimHatirlatma(1, now.AddHours(2), "Sevkiyat", "Bekliyor").OzetteGoster(now));
        Check("Yarınki plan açılışta görünür", new TakvimHatirlatma(1, now.AddDays(1), "Sevkiyat", "Bekliyor").OzetteGoster(now));
        Check("Eski gecikmiş plan kaybolmaz", new TakvimHatirlatma(1, now.AddDays(-60), "Sevkiyat", "Bekliyor").OzetteGoster(now));
        Check("Gelecek gün özete erken girmez", !new TakvimHatirlatma(1, now.Date.AddDays(2), "Sevkiyat", "Bekliyor").OzetteGoster(now));
        foreach (string status in new[] { "Tamamlandı", "İptal" }) Check(status+" bildirilmez", !new TakvimHatirlatma(1,now.AddMinutes(-2),"Plan",status).ZamaniGeldi(now));
        Check("14:30 gibi serbest saatte çalışır",new TakvimHatirlatma(1,now,"Plan","Bekliyor").ZamaniGeldi(now));
        Check("Henüz zamanı gelmeyen plan",!new TakvimHatirlatma(1,now.AddSeconds(1),"Plan","Bekliyor").ZamaniGeldi(now));
        Check("Ertelenen plan ayrı bildirim olur",new TakvimHatirlatma(1,now,"Plan","Bekliyor").Anahtar!=new TakvimHatirlatma(1,now.AddHours(1),"Plan","Bekliyor").Anahtar);
        string folder=Path.Combine(output,"TercihTesti");
        var prefs=new GorunumTercihleri { Tema="Kültürel", Yerlesim="Üst menü", Yogunluk="Kompakt", Kose=6, KisayolSutun=3, Golge=false };
        GorunumDeposu.Kaydet(folder,prefs);var read=GorunumDeposu.Oku(folder);
        Check("Tercihler yeniden açılışta korunur",read.Tema==prefs.Tema && read.Yerlesim==prefs.Yerlesim && read.Kose==6 && !read.Golge && read.KisayolSutun==3);
        File.WriteAllText(Path.Combine(folder,"tercihler.json"),"{\"Tema\":\"Modern\"}");
        Check("Eski tercihler uyumlu",GorunumDeposu.Oku(folder).Yerlesim=="Temaya göre");
        File.WriteAllText(Path.Combine(folder,"tercihler.json"),"{\"Kose\":90}");
        Check("Bozuk tercihte güvenli varsayılan",GorunumDeposu.Oku(folder).Kose==-1);
        var main=(MainWindow)Activator.CreateInstance(typeof(MainWindow),BindingFlags.Instance|BindingFlags.NonPublic,null,new object[]{true},null)!;
        main.Width=1280;main.Height=850;
        ((FrameworkElement)main.FindName("AnaSayfaIcerik")).Visibility=Visibility.Visible;
        ((FrameworkElement)main.FindName("GenelIcerik")).Visibility=Visibility.Collapsed;
        ((FrameworkElement)main.FindName("BrdIsTakvimi")).Visibility=Visibility.Visible;
        ((TextBlock)main.FindName("TxtTakvimDurum")).Text="4 Kasım 2026 • Tasarım önizlemesi / örnek veriler";
        ((TextBlock)main.FindName("TxtSektorBaslik")).Text="İşinin tüm ayrıntıları, sana ait bir çalışma alanında.";
        main.Show(); Pump();
        foreach(string theme in Tema170.Adlar)
        {
            var p=new GorunumTercihleri { Tema=theme,MedyaModu="Düz renk" };
            p.Dogrula();main.GorunumuUygula(p);Pump();
            var shell=(Grid)main.FindName("TemaKabuk");var nav=(Border)main.FindName("TemaMenu");var body=(Grid)main.FindName("TemaIcerik");
            Check(theme+" menü yerleşimi",Tema170.Yerlesim(p)=="Üst menü" ? Grid.GetRow(body)==1 : Grid.GetColumn(nav)==(Tema170.Yerlesim(p)=="Sağ menü"?1:0));
            Check(theme+" içerik ölçüleri",body.ActualWidth>500 && body.ActualHeight>200);
            if(new[]{"VIP","Modern","Doğal","Eskitme","Kültürel"}.Contains(theme)) Save(main,theme+"-ekran.png");
        }
        main.GorunumuUygula(new GorunumTercihleri {Tema="VIP",Yerlesim="Sağ menü",KisayolSutun=3,Kose=24,Yogunluk="Kompakt",Golge=false});Pump();
        Check("Özelleştirme koleksiyonu geçersiz kılar",Grid.GetColumn((Border)main.FindName("TemaMenu"))==1 && ((System.Windows.Controls.Primitives.UniformGrid)main.FindName("KartKisayol")).Columns==3 && ((CornerRadius)app.Resources["ErpKose"]).TopLeft==24);
        main.Width=950; main.Height=600;main.GorunumuUygula(new GorunumTercihleri {Tema="VIP",Olcek=1.3});Pump();
        var button=(Button)main.FindName("BtnTakvimBildirim");var bounds=button.TransformToAncestor(main).TransformBounds(new Rect(button.RenderSize));
        Check("%130 ölçekte takvim düğmesi ekran içinde",bounds.Right<=main.ActualWidth && bounds.Bottom<main.ActualHeight);
        Check("Dar ekranda takvim alt alta yerleşir",Grid.GetRow((FrameworkElement)main.FindName("TemaTakvimListeAlani"))==1);
        var sidebar=(Border)main.FindName("TemaMenu");
        foreach(string layout in new[]{"Sol menü","Üst menü","Sağ menü"})
        {
            main.GorunumuUygula(new GorunumTercihleri{Tema="Doğal",Yerlesim=layout,AnaSayfaDuzeni="Haber odaklı"});Pump();
            var dashboard=(StackPanel)((FrameworkElement)main.FindName("KartHaber")).Parent;
            Check(layout+" özel bölüm sırasını korur",dashboard.Children[0]==main.FindName("KartHaber"));
        }
        ((DataGrid)main.FindName("IsTakvimiListe")).ItemsSource=new[]{"Önceki hesabın planı"};
        typeof(MainWindow).GetMethod("TakvimOturumunuTemizle",BindingFlags.Instance|BindingFlags.NonPublic)!.Invoke(main,null);
        Check("Oturum değişiminde önceki planlar temizlenir",((DataGrid)main.FindName("IsTakvimiListe")).ItemsSource==null && ((FrameworkElement)main.FindName("BrdIsTakvimi")).Visibility==Visibility.Collapsed);
        main.Close();
        Tema170.Uygula(new GorunumTercihleri{Tema="VIP"});
        foreach(var combo in new[]{(MessageBoxButton.OK,MessageBoxResult.OK),(MessageBoxButton.OKCancel,MessageBoxResult.Cancel),(MessageBoxButton.YesNo,MessageBoxResult.No),(MessageBoxButton.YesNoCancel,MessageBoxResult.Cancel)})
        {
            var d=new ModernMesajPenceresi("Bir işlem onaylanmadan kapatılıyor.","Güvenli kapatma",combo.Item1,MessageBoxImage.Question,MessageBoxResult.None);
            d.Show();Pump();d.Close();Check(combo.Item1+" kapatınca güvenli sonuç",d.Sonuc==combo.Item2);
        }
        var dialog=new ModernMesajPenceresi("Bugün 3 bekleyen işin var.\n\n14:30 • Sevkiyat planını kontrol et\n16:00 • Hammadde transferi\nYarın 10:00 • Üretim toplantısı", "İş takvimi • Hatırlatmalar",MessageBoxButton.OK,MessageBoxImage.Information,MessageBoxResult.OK);
        dialog.Show();Pump();Save(dialog,"VIP-bildirim.png");dialog.Close();
        var yes=new ModernMesajPenceresi("Onay testi","Test",MessageBoxButton.YesNo,MessageBoxImage.Question,MessageBoxResult.None);yes.Show();Pump();
        Descendants(yes).OfType<Button>().Single(b=>Equals(b.Content,"Evet")).RaiseEvent(new RoutedEventArgs(Button.ClickEvent));Check("Evet düğmesi sonucu",yes.Sonuc==MessageBoxResult.Yes);
        var longDialog=new ModernMesajPenceresi(string.Join("\n",Enumerable.Repeat("Uzun uyarı metni ve işlem açıklaması",150)),"Uzun bildirim",MessageBoxButton.OKCancel,MessageBoxImage.Warning,MessageBoxResult.None);
        longDialog.Show();Pump();Check("Uzun metin ekran yüksekliğini aşmaz",longDialog.ActualHeight<=SystemParameters.WorkArea.Height);
        longDialog.RaiseEvent(new System.Windows.Input.KeyEventArgs(System.Windows.Input.Keyboard.PrimaryDevice,PresentationSource.FromVisual(longDialog),0,System.Windows.Input.Key.Escape){RoutedEvent=System.Windows.Input.Keyboard.PreviewKeyDownEvent});
        Check("Escape güvenle vazgeçer",!longDialog.IsVisible && longDialog.Sonuc==MessageBoxResult.Cancel);
        foreach(string t in new[]{"VIP","Koyu"})
        {
            Tema170.Uygula(new GorunumTercihleri{Tema=t});var plan=new TakvimPlanPenceresi();plan.Show();Pump();
            Check(t+" yeni açılan pencereye uygulanır",ReferenceEquals(plan.Background,app.Resources["ErpZemin"]));plan.Close();
        }
        Tema170.Uygula(new GorunumTercihleri{Tema="VIP"});
        var settings=new GorunumPenceresi(folder,new GorunumTercihleri{Tema="VIP"},()=>{},_=>{});settings.Show();Pump();Save(settings,"Tema-ayarlari.png");settings.Close();
        GorunumTercihleri? saved=null;
        var edit=new GorunumPenceresi(folder,new GorunumTercihleri{Tema="VIP"},()=>{},a=>saved=a);
        app.Dispatcher.BeginInvoke(new Action(()=>{
            ((ComboBox)typeof(GorunumPenceresi).GetField("yerlesim",BindingFlags.Instance|BindingFlags.NonPublic)!.GetValue(edit)!).SelectedItem="Sağ menü";
            Descendants(edit).OfType<Button>().Single(b=>Equals(b.Content,"Kaydet ve uygula")).RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        }),DispatcherPriority.ApplicationIdle);
        edit.ShowDialog();Check("Ayar penceresi Kaydet ve uygula",saved?.Yerlesim=="Sağ menü" && GorunumDeposu.Oku(folder).Yerlesim=="Sağ menü");
        Console.WriteLine($"PASS: {count} kontrol. {output}"); File.WriteAllText(Path.Combine(output,"test-sonucu.txt"),$"{DateTime.Now:O}\n{count} kontrol başarılı. SQL bağlantısı veya veri değişikliği yapılmadı.");
        app.Shutdown();return 0;
    }
    static void Check(string name,bool value) {if(!value)throw new Exception("FAIL: "+name); count++;Console.WriteLine("PASS: "+name);}
    static void Pump() {Application.Current.Dispatcher.Invoke(()=>{},DispatcherPriority.ApplicationIdle);}
    static IEnumerable<DependencyObject> Descendants(DependencyObject node) {for(int i=0;i<VisualTreeHelper.GetChildrenCount(node);i++){var c=VisualTreeHelper.GetChild(node,i);yield return c;foreach(var d in Descendants(c))yield return d;}}
    static void Save(Window window,string name) {window.UpdateLayout();var bitmap=new RenderTargetBitmap((int)window.ActualWidth,(int)window.ActualHeight,96,96,PixelFormats.Pbgra32);bitmap.Render(window);var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(bitmap));using var file=File.Create(Path.Combine(output,name));encoder.Save(file);}
}



