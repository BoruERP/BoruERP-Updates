using System.Text.Json;
using System.IO;
using System.Net.Http;
using System.Net;
using System.Net.Sockets;
using Microsoft.Data.SqlClient;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Hosting.Server.Features;
using Microsoft.Extensions.DependencyInjection;
using MiapaxERP.Desktop;
using MiapaxERP.MobileServer;

internal static class Program
{
 static int passed;
 static void Check(bool value,string name){if(!value)throw new Exception(name);passed++;Console.WriteLine("PASS "+name);}
 static void Reject(Action work,string name){bool rejected=false;try{work();}catch(ArgumentException){rejected=true;}Check(rejected,name);}
 [STAThread] static int Main(string[] args)
 {
  if(args.Length>=2&&args[0]=="--baglanti-render"){KolayBaglantiTestleri.Render(args[1],args.Length>2?int.Parse(args[2]):0);return 0;}
  try { KolayBaglantiTestleri.Run();
  Run().GetAwaiter().GetResult();HttpsTestleri.Run().GetAwaiter().GetResult();
  try{HttpsTlsTestleri.Run().GetAwaiter().GetResult();}
  catch(System.Net.Http.HttpRequestException e)when(e.GetBaseException() is System.ComponentModel.Win32Exception w&&w.NativeErrorCode==unchecked((int)0x8009030E))
  {Console.WriteLine("SKIP TLS handshake checks: Windows test identity cannot acquire Schannel credentials (0x8009030E). Run again in the normal Windows account. Certificate checks were NOT bypassed.");}
  Console.WriteLine($"Passed {passed} remote-work checks");return 0; } catch(Exception e) {Console.Error.WriteLine(e);return 1;}
 }
 static async Task Run()
 {
  foreach(var ip in new[]{"10.0.0.1","172.16.0.1","172.31.255.254","192.168.1.20"})Check(UzakCalismaGuvenligi.OzelIpv4(ip),"private "+ip);
  foreach(var ip in new[]{"8.8.8.8","172.15.1.1","172.32.0.1","127.0.0.1","169.254.1.1","100.64.0.1","010.0.0.1","10.0.0.256","10.1","10.0.0.1\r\npassword:s:x"})Check(!UzakCalismaGuvenligi.OzelIpv4(ip),"reject non-private/noncanonical "+ip.Replace("\r\n"," "));
  var old=JsonSerializer.Deserialize<MiapaxERPBaglantiAyarlari>("{\"Rol\":\"Yan\",\"Sunucu\":\"FABRIKA-PC\\\\SQLEXPRESS\",\"Veritabani\":\"MiapaxERP\",\"KimlikDogrulama\":\"Windows\"}")!;
  var oldCs=new SqlConnectionStringBuilder(old.BaglantiDizesi());Check(oldCs.DataSource=="FABRIKA-PC\\SQLEXPRESS"&&oldCs.TrustServerCertificate&&oldCs.ConnectTimeout==3&&!old.UzakVpn,"old LAN configuration preserved without writing files");
  var remote=new MiapaxERPBaglantiAyarlari{Rol="Yan",UzakVpn=true,Sunucu="10.80.0.1,1433",Veritabani="BoruERP",BaglantiZamanAsimi=3};
  var cs=new SqlConnectionStringBuilder(remote.BaglantiDizesi());Check(cs.DataSource=="tcp:10.80.0.1,1433","VPN explicit TCP route");Check(!cs.TrustServerCertificate&&cs.Encrypt==SqlConnectionEncryptOption.Mandatory,"remote TLS cannot be disabled by legacy trust setting");Check(cs.ConnectTimeout==15,"VPN timeout minimum");
  remote.SertifikaSunucuAdi="sql.fabrika.local";cs=new(remote.BaglantiDizesi());Check(cs.HostNameInCertificate=="sql.fabrika.local","SQL certificate expected name");
  foreach(var target in new[]{"88.1.1.1,1433","127.0.0.1,1433","FABRIKA\\SQL","10.80.0.1","10.80.0.1,0","10.80.0.1,65536","10.80.0.1,1433;TrustServerCertificate=true","http://10.80.0.1,1433"}){remote.Sunucu=target;Reject(()=>remote.BaglantiDizesi(),"reject unsafe SQL target "+target);}
  remote.Sunucu="10.80.0.1,1433";foreach(var name in new[]{"*.fabrika.local","sql/x","user@sql.local","sql.local\r\nfoo"}){remote.SertifikaSunucuAdi=name;Reject(()=>remote.BaglantiDizesi(),"reject invalid certificate name");}
  int calls=0,errors=0;await MobilLisansBakimi.Deneme(()=>{calls++;throw new IOException("fake disk failure");},_=>errors++);await MobilLisansBakimi.Deneme(()=>{calls++;return Task.CompletedTask;},_=>errors++);Check(calls==2&&errors==1,"license maintenance recovers after failed attempt");
  using(var stop=new CancellationTokenSource()){int ticks=0;var loop=MobilLisansBakimi.Dongu(()=>{if(Interlocked.Increment(ref ticks)==1)throw new IOException("fixture");if(ticks>=3)stop.Cancel();return Task.CompletedTask;},TimeSpan.FromMilliseconds(5),_=>{},stop.Token);await loop.WaitAsync(TimeSpan.FromSeconds(3));Check(ticks>=3,"scheduled maintenance keeps retrying and stops cleanly");}
  Check(LisansOturumu.Zorunlu,"customer build licensing remains enforced");
  await using var app=MobilApi220.Olustur("Server=127.0.0.1,1;Database=NeverOpened;Integrated Security=true;Connect Timeout=1",0);await app.StartAsync();
  try{var addr=app.Services.GetRequiredService<IServer>().Features.Get<IServerAddressesFeature>()!.Addresses.Single();using var http=new HttpClient{BaseAddress=new Uri(addr)};var health=await http.GetAsync("/api/mobile/v2/health");Check(health.IsSuccessStatusCode,"anonymous liveness available without SQL/license data");Check((await http.GetAsync("/internal/ready")).StatusCode==HttpStatusCode.ServiceUnavailable,"installer readiness fails with no server license and does not open SQL");string body=await health.Content.ReadAsStringAsync();Check(body.Contains("MiapaxERP.MobileServer")&&!body.Contains("NeverOpened")&&!body.Contains("license",StringComparison.OrdinalIgnoreCase),"health exposes no factory/license data");Check((await http.GetAsync("/api/mobile/v2/profile")).StatusCode==HttpStatusCode.Forbidden,"health does not bypass profile license guard");Check((await http.PostAsync("/api/mobile/v2/rpc",new StringContent("{}"))).StatusCode==HttpStatusCode.Forbidden,"RPC remains protected");var replies=await Task.WhenAll(Enumerable.Range(0,20).Select(_=>http.GetAsync("/api/mobile/v2/health")));Check(replies.All(r=>r.IsSuccessStatusCode||r.StatusCode==HttpStatusCode.TooManyRequests),"20 concurrent liveness clients remain bounded");foreach(var r in replies)r.Dispose();}finally{await app.StopAsync();}
 }
}
