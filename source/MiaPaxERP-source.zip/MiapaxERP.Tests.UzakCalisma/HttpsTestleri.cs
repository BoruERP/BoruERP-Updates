using System.Data;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using MiapaxERP.Desktop;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Hosting.Server.Features;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

static class HttpsTestleri
{
    static int checks;
    static void Check(bool v,string n){if(!v)throw new Exception(n);checks++;Console.WriteLine("PASS HTTPS "+n);}
    static void Reject(Action a,string n){try{a();}catch(Exception e)when(e is UnauthorizedAccessException or ArgumentException){Check(true,n);return;}throw new Exception(n);}
    sealed class Clock:TimeProvider{public DateTimeOffset Now=DateTimeOffset.UtcNow;public override DateTimeOffset GetUtcNow()=>Now;}
    sealed class Accounts:IHttpsHesapDeposu
    {
        public bool Enabled=true;public int Checks;
        public HttpsDogrulanmisHesap Giris(HttpsGiris i){if(i.Kullanici!="ayse"||i.Parola!="valid password")throw new UnauthorizedAccessException();return new(new(7,"ayse","Ayşe Test","Çalışan"),"stamp");}
        public bool Gecerli(int id,string stamp){Checks++;return Enabled&&id==7&&stamp=="stamp";}
    }
    sealed class Wire : HttpMessageHandler
    {
        public int Calls;public bool Timeout;public readonly List<string> Operations=[];
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage r,CancellationToken ct)
        {
            Check(r.RequestUri!.Scheme=="https"&&r.RequestUri.Host=="erp.example.com","client uses configured HTTPS endpoint");
            if(r.RequestUri.AbsolutePath.EndsWith("/login"))return new(HttpStatusCode.OK){Content=JsonContent.Create(new HttpsGirisYaniti(new string('A',64),new(7,"ayse","Ayşe","Çalışan"),["STOK"],"GENEL",DateTimeOffset.UtcNow.AddHours(8)),options:HttpsJson.Ayarlar)};
            if(r.RequestUri.AbsolutePath.EndsWith("/logout"))return new(HttpStatusCode.NoContent);
            Calls++;if(Timeout)throw new TaskCanceledException("simulated response lost after commit");
            Check(r.Headers.Authorization?.Parameter==new string('A',64),"business call carries session token");
            var call=JsonSerializer.Deserialize<HttpsCagri>(await r.Content!.ReadAsStringAsync(ct),HttpsJson.Ayarlar)!;Operations.Add(call.Islem);
            var entries=(Dictionary<string,HttpsIslem>)typeof(HttpsIslemKatalogu).GetField("islemler",System.Reflection.BindingFlags.Static|System.Reflection.BindingFlags.NonPublic)!.GetValue(null)!;
            var type=entries[call.Islem].Metot.ReturnType;object? result=type==typeof(SahaIlSayfasi)?new SahaIlSayfasi([],false,0):type==typeof(void)?null:type==typeof(DataTable)?new DataTable():type==typeof(string)?"ok":type.IsArray?Array.CreateInstance(type.GetElementType()!,0):type==typeof(object)?new {ok=true}:type.IsValueType?Activator.CreateInstance(type):null;
            return new(HttpStatusCode.OK){Content=new StringContent(JsonSerializer.Serialize(result,HttpsJson.Ayarlar),System.Text.Encoding.UTF8,"application/json")};
        }
    }
    public static async Task Run()
    {
        var table=new DataTable();table.Columns.Add("Id",typeof(int));table.Columns.Add("Tutar",typeof(decimal));table.Columns.Add("Surum",typeof(byte[]));table.Columns.Add("Tarih",typeof(DateTime));table.Columns.Add("Aciklama");table.Columns.Add("Aktif",typeof(bool));
        var date=new DateTime(2026,11,12,10,30,5);table.Rows.Add(9,123456.7890m,new byte[]{0,1,255},date,DBNull.Value,true);
        var copy=JsonSerializer.Deserialize<DataTable>(JsonSerializer.Serialize(table,HttpsJson.Ayarlar),HttpsJson.Ayarlar)!;
        Check((decimal)copy.Rows[0]["Tutar"]==123456.7890m,"decimal precision survives wire");
        Check(((byte[])copy.Rows[0]["Surum"]).SequenceEqual(new byte[]{0,1,255}),"optimistic rowversion survives wire");
        Check((DateTime)copy.Rows[0]["Tarih"]==date&&copy.Rows[0].IsNull("Aciklama")&&(bool)copy.Rows[0]["Aktif"],"date/null/bool preserve types");
        bool unsafeType=false;try{JsonSerializer.Deserialize<DataTable>("{\"columns\":[{\"name\":\"x\",\"type\":\"System.IO.FileInfo\"}],\"rows\":[]}",HttpsJson.Ayarlar);}catch(JsonException){unsafeType=true;}Check(unsafeType,"wire cannot load CLR types");
        string hash=GirisPenceresi.SifreOzetiOlustur("Sifre-123456789");Check(GirisPenceresi.SifreDogrula("Sifre-123456789",hash)&&!GirisPenceresi.SifreDogrula("wrong",hash),"same PBKDF2 password policy as native login");
        int operationCount=HttpsIslemKatalogu.Adlar.Length;Check(operationCount>=200,"complete explicit business operation catalogue registered");
        Check(HttpsIslemKatalogu.Adlar.Contains("RestoranServisi.Ac")&&!HttpsIslemKatalogu.Adlar.Contains("ErpModulServisi.Ac")&&!HttpsIslemKatalogu.Adlar.Contains("ErpModulServisi.Komut"),"no connection or arbitrary SQL operation exposed");
        var wire=new Wire();using(var client=new HttpsIstemci("https://erp.example.com",wire))
        {
            await client.Giris("ayse","password");HttpsOturumu.Baslat(client);
            var operations=(Dictionary<string,HttpsIslem>)typeof(HttpsIslemKatalogu).GetField("islemler",System.Reflection.BindingFlags.Static|System.Reflection.BindingFlags.NonPublic)!.GetValue(null)!;
            foreach(var pair in operations)
            {
                object? Sample(Type t)=>t==typeof(string)?"sample":t.IsValueType?Activator.CreateInstance(t):null;
                var method=pair.Value.Metot;var parameters=method.GetParameters().Select(p=>Sample(p.ParameterType)).ToArray();
                method.Invoke(pair.Value.Olustur(HttpsOturumu.Baglanti,7,"SALES"),parameters);
                Check(wire.Operations.Last()==pair.Key,"native service dispatches through HTTPS before opening SQL: "+pair.Key);
            }
            Check(wire.Calls==operationCount,"every registered native operation uses HTTPS without client SQL");
            wire.Timeout=true;try{new GelirGiderServisi(HttpsOturumu.Baglanti,7).Kaydet(new(Guid.NewGuid(),DateTime.Today,"Gider","100.01.001",1,10,"test","test",null));throw new Exception("timeout expected");}catch(InvalidOperationException e){Check(e.Message.Contains("otomatik tekrarlanmadı")&&wire.Calls==operationCount+1,"uncertain write is never automatically retried");}
            await client.Cikis();HttpsOturumu.Temizle();
        }
        foreach(string id in new[]{"System.IO.File.Delete","ErpModulServisi.Komut","SELECT * FROM Kullanicilar"})Reject(()=>HttpsIslemKatalogu.Calistir("NeverOpened",999,new(id,"",[])),"unknown operation rejected before SQL: "+id);
        Reject(()=>HttpsIslemKatalogu.Calistir("NeverOpened",999,new("TicaretDosyalari.Liste","SALES;DROP TABLE x",[])),"scope injection rejected before SQL");
        Reject(()=>HttpsIslemKatalogu.Calistir("NeverOpened",999,new("GelirGiderServisi.Oku","",[])),"wrong argument count rejected before SQL");
        var accounts=new Accounts();var clock=new Clock();var sessions=new HttpsOturumDeposu(accounts,clock);
        var first=await sessions.Giris(new("ayse","valid password"),default);var second=await sessions.Giris(new("ayse","valid password"),default);
        Check(first.Token.Length==64&&first.Token!=second.Token,"independent random 256-bit session tokens");
        Check(sessions.Dogrula(first.Token).Id==7&&accounts.Checks==1,"identity bound by server and revalidated");
        sessions.Cikis(first.Token);Reject(()=>sessions.Dogrula(first.Token),"logout revokes token");Check(sessions.Dogrula(second.Token).Id==7,"logout does not revoke other device");
        accounts.Enabled=false;Reject(()=>sessions.Dogrula(second.Token),"disabled account immediately rejected");accounts.Enabled=true;
        var idle=await sessions.Giris(new("ayse","valid password"),default);clock.Now=clock.Now.AddMinutes(16);Reject(()=>sessions.Dogrula(idle.Token),"15 minute idle expiry");
        var absolute=await sessions.Giris(new("ayse","valid password"),default);for(int i=0;i<47;i++){clock.Now=clock.Now.AddMinutes(10);sessions.Dogrula(absolute.Token);}clock.Now=clock.Now.AddMinutes(10);Reject(()=>sessions.Dogrula(absolute.Token),"8 hour absolute expiry even with activity");
        Reject(()=>sessions.Dogrula(new string('x',9000)),"oversized/invalid token rejected");
        var b=WebApplication.CreateSlimBuilder();b.Logging.ClearProviders();b.WebHost.UseKestrel(o=>o.Listen(IPAddress.Loopback,0));await using var app=b.Build();bool licensed=true;
        HttpsApi.Kur(app,"NeverOpened",accounts,()=>licensed);await app.StartAsync();
        try
        {
            string address=app.Services.GetRequiredService<IServer>().Features.Get<IServerAddressesFeature>()!.Addresses.Single();using var http=new HttpClient{BaseAddress=new Uri(address)};
            using var health=await http.GetAsync(HttpsApi.Kok+"/health");Check(health.IsSuccessStatusCode&&health.Headers.CacheControl?.NoStore==true,"public health bounded and no-store");
            Check((await http.GetAsync(HttpsApi.Kok+"/profile")).StatusCode==HttpStatusCode.Unauthorized,"anonymous profile denied");
            Check((await http.PostAsJsonAsync(HttpsApi.Kok+"/login",new HttpsGiris("ayse","wrong"))).StatusCode==HttpStatusCode.Unauthorized,"bad credentials rejected");
            using var login=await http.PostAsJsonAsync(HttpsApi.Kok+"/login",new HttpsGiris("ayse","valid password"));var result=await login.Content.ReadFromJsonAsync<HttpsGirisYaniti>(HttpsJson.Ayarlar)??throw new Exception("login body");Check(login.IsSuccessStatusCode&&result.Kullanici.Id==7,"native ERP HTTPS login succeeds");
            string body=await login.Content.ReadAsStringAsync();Check(!body.Contains("stamp")&&!body.Contains("SifreOzeti")&&!body.Contains("NeverOpened"),"login never returns hash or SQL credentials");
            http.DefaultRequestHeaders.Authorization=new AuthenticationHeaderValue("Bearer",result.Token);
            Check((await http.GetAsync(HttpsApi.Kok+"/profile")).IsSuccessStatusCode,"authenticated profile succeeds");
            Check((await http.PostAsJsonAsync(HttpsApi.Kok+"/rpc",new HttpsCagri("ExecuteSql","",[]))).StatusCode==HttpStatusCode.BadRequest,"HTTP arbitrary SQL rejected");
            Check((await http.PostAsJsonAsync(HttpsApi.Kok+"/rpc",new{islem="TicaretDosyalari.Liste",kapsam="BOGUS",argumanlar=Array.Empty<object>(),kullaniciId=1})).StatusCode==HttpStatusCode.BadRequest,"HTTP forged scope rejected");
            accounts.Enabled=false;Check((await http.GetAsync(HttpsApi.Kok+"/profile")).StatusCode==HttpStatusCode.Unauthorized,"HTTP account deactivation revokes session");accounts.Enabled=true;
            using var again=await http.PostAsJsonAsync(HttpsApi.Kok+"/login",new HttpsGiris("ayse","valid password"));var s=await again.Content.ReadFromJsonAsync<HttpsGirisYaniti>(HttpsJson.Ayarlar);http.DefaultRequestHeaders.Authorization=new AuthenticationHeaderValue("Bearer",s!.Token);
            Check((await http.PostAsync(HttpsApi.Kok+"/logout",null)).IsSuccessStatusCode&&(await http.GetAsync(HttpsApi.Kok+"/profile")).StatusCode==HttpStatusCode.Unauthorized,"HTTP logout revokes actual session");
            licensed=false;Check((await http.PostAsJsonAsync(HttpsApi.Kok+"/login",new HttpsGiris("ayse","valid password"))).StatusCode==HttpStatusCode.Forbidden,"server license required for desktop login");Check((await http.GetAsync(HttpsApi.Kok+"/health")).IsSuccessStatusCode,"health does not imply license readiness");
        }
        finally{await app.StopAsync();}
        Console.WriteLine("HTTPS infrastructure checks: "+checks);
    }
}
