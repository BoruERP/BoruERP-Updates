﻿$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
dotnet run --project (Join-Path $PSScriptRoot 'MiapaxERP.Tests.UzakCalisma.csproj') --disable-build-servers
if($LASTEXITCODE -ne 0){throw 'HTTPS kurulum testleri başarısız.'}
