using System.Net;
using System.Net.Http;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Hosting.Server.Features;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using MiapaxERP.Desktop;

static class HttpsTlsTestleri
{
    sealed class Accounts:IHttpsHesapDeposu
    {
        public HttpsDogrulanmisHesap Giris(HttpsGiris i)=>i.Kullanici=="tls"&&i.Parola=="test"?new(new(71,"tls","TLS Test","Çalışan"),"stamp"):throw new UnauthorizedAccessException();
        public bool Gecerli(int id,string stamp)=>id==71&&stamp=="stamp";
    }
    public static async Task Run()
    {
        using var key=RSA.Create(2048);var rootRequest=new CertificateRequest("CN=Miapax Test Root",key,HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1);
        rootRequest.CertificateExtensions.Add(new X509BasicConstraintsExtension(true,false,0,true));rootRequest.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.KeyCertSign,true));
        using var root=rootRequest.CreateSelfSigned(DateTimeOffset.UtcNow.AddMinutes(-5),DateTimeOffset.UtcNow.AddDays(1));
        using var leafKey=RSA.Create(2048);var request=new CertificateRequest("CN=erp.example.com",leafKey,HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1);
        var san=new SubjectAlternativeNameBuilder();san.AddDnsName("erp.example.com");request.CertificateExtensions.Add(san.Build());
        request.CertificateExtensions.Add(new X509BasicConstraintsExtension(false,false,0,true));request.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.DigitalSignature|X509KeyUsageFlags.KeyEncipherment,true));
        request.CertificateExtensions.Add(new X509EnhancedKeyUsageExtension(new OidCollection{new("1.3.6.1.5.5.7.3.1")},true));
        using var unsigned=request.Create(root,DateTimeOffset.UtcNow.AddMinutes(-1),DateTimeOffset.UtcNow.AddHours(1),RandomNumberGenerator.GetBytes(16));
        using var ephemeral=unsigned.CopyWithPrivateKey(leafKey);byte[] pfx=ephemeral.Export(X509ContentType.Pkcs12,"only-a-random-test-key");
        using var certificate=X509CertificateLoader.LoadPkcs12(pfx,"only-a-random-test-key",X509KeyStorageFlags.UserKeySet|X509KeyStorageFlags.Exportable);
        CryptographicOperations.ZeroMemory(pfx);
        var b=WebApplication.CreateSlimBuilder();b.Logging.ClearProviders();b.WebHost.UseKestrel(o=>o.Listen(IPAddress.Loopback,0,l=>l.UseHttps(certificate)));await using var app=b.Build();HttpsApi.Kur(app,"NeverOpened",new Accounts(),()=>true);await app.StartAsync();
        try
        {
            var port=new Uri(app.Services.GetRequiredService<IServer>().Features.Get<IServerAddressesFeature>()!.Addresses.Single()).Port;
            SocketsHttpHandler Handler(bool trust)
            {
                var handler=new SocketsHttpHandler{AllowAutoRedirect=false,UseProxy=false,ConnectCallback=async(_,ct)=>{var socket=new Socket(SocketType.Stream,ProtocolType.Tcp);try{await socket.ConnectAsync(IPAddress.Loopback,port,ct);return new NetworkStream(socket,true);}catch{socket.Dispose();throw;}}};
                if(trust){var policy=new X509ChainPolicy{TrustMode=X509ChainTrustMode.CustomRootTrust,RevocationMode=X509RevocationMode.NoCheck};policy.CustomTrustStore.Add(root);handler.SslOptions.CertificateChainPolicy=policy;}
                return handler;
            }
            using(var client=new HttpsIstemci("https://erp.example.com",Handler(true)))
            {await client.Giris("tls","test");if(client.Oturum?.Kullanici.Id!=71)throw new Exception("TLS login identity");await client.Cikis();Console.WriteLine("PASS TLS real encrypted native login/logout with hostname and chain validation");}
            bool untrusted=false;using(var client=new HttpClient(Handler(false))){try{await client.GetAsync("https://erp.example.com/api/desktop/v1/health");}catch(HttpRequestException){untrusted=true;}}if(!untrusted)throw new Exception("Untrusted certificate accepted");Console.WriteLine("PASS TLS untrusted certificate rejected");
            bool mismatch=false;using(var client=new HttpClient(Handler(true))){try{await client.GetAsync("https://wrong.example.com/api/desktop/v1/health");}catch(HttpRequestException){mismatch=true;}}if(!mismatch)throw new Exception("Hostname mismatch accepted");Console.WriteLine("PASS TLS certificate hostname mismatch rejected");
        }
        finally{await app.StopAsync();}
    }
}
