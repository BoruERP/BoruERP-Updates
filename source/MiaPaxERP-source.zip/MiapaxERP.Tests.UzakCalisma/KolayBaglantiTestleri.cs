using MiapaxERP.Desktop;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.IO;

internal static class KolayBaglantiTestleri
{
    static int checks;
    static void Check(bool v,string n){if(!v)throw new Exception(n);checks++;Console.WriteLine("PASS easy-connect "+n);}
    static void Reject(Action a,string n){try{a();}catch(ArgumentException){Check(true,n);return;}throw new Exception("Accepted "+n);}
    public static void Run()
    {
        var p=new KolayBaglantiProfili{Rol="Yan",MasaustuHttps="https://erp.example.com",MobilHttps="https://erp.example.com"};p.Dogrula(true);
        Check(KolayBaglantiProfili.KoduOku(p.PaylasimKodu(),"Yan").MasaustuHttps==p.MasaustuHttps,"PC address packet roundtrip");
        Check(KolayBaglantiProfili.KoduOku(p.PaylasimKodu(),"Mobil").MobilHttps==p.MobilHttps,"mobile shares same HTTPS endpoint");
        foreach(string bad in new[]{"http://erp.example.com","https://user:secret@erp.example.com","https://erp.example.com/path","https://erp.example.com?sql=x","https://erp.example.com:5188","https://127.0.0.1","https://erp.example.com\nhandle *"})Reject(()=>KolayBaglantiProfili.Https(bad),"reject invalid endpoint "+bad.Replace("\n"," "));
        Check(KolayBaglantiProfili.Https("https://erp.example.com:8443",true).Port==8443,"desktop alternate HTTPS port supported");
        foreach(string ip in new[]{"10.1.1.1","127.0.0.1","100.64.0.1","169.254.1.2","203.0.113.10","224.1.1.1"})Check(!KolayBaglantiProfili.GenelIpv4(ip),"reject non-public IP "+ip);
        Reject(()=>KolayBaglantiProfili.KoduOku("MPX-CONNECT1:bad!","Yan"),"bad packet");
        Reject(()=>KolayBaglantiProfili.KoduOku(new string('x',9000),"Yan"),"oversize packet");
        Reject(()=>new KolayBaglantiProfili{Rol="Yan",MobilHttps=p.MobilHttps}.Dogrula(true),"desktop requires own API address");
        string proxy=MiapaxERP.MobileServer.MobilHttpsKurucu.CaddyConfig(p.MasaustuHttps,Path.Combine(Path.GetTempPath(),"mpx-certificates"));
        Check(proxy.Contains("/api/desktop/v1/*")&&proxy.Contains("/api/mobile/v2/*")&&proxy.Contains("127.0.0.1:5188"),"one reverse proxy for PC/mobile, loopback SQL-facing backend");
        Check(proxy.Contains("admin off")&&proxy.Contains("404")&&!proxy.Contains("tls_insecure_skip_verify"),"proxy denies unrelated routes, no TLS bypass");
        Reject(()=>MiapaxERP.MobileServer.MobilHttpsKurucu.CaddyConfig("https://erp.example.com\nhandle *",Path.GetTempPath()),"configuration injection rejected");
        Check(!KolayKurulumRehberi.Metin(p).Contains("RDS"),"guide contains HTTPS only");
        Console.WriteLine("HTTPS connection checks: "+checks);
    }
    public static void Render(string file,int role=0)
    {
        var app=new System.Windows.Application();Tema170.Uygula(new GorunumTercihleri());
        var window=new BaglantiAyarlariPenceresi{WindowStartupLocation=WindowStartupLocation.Manual,Left=0,Top=0};window.Show();window.UpdateLayout();
        IEnumerable<DependencyObject> Children(DependencyObject parent){for(int i=0;i<VisualTreeHelper.GetChildrenCount(parent);i++){var child=VisualTreeHelper.GetChild(parent,i);yield return child;foreach(var nested in Children(child))yield return nested;}}
        var choices=Children(window).OfType<System.Windows.Controls.ComboBox>().First(c=>c.Items.Count==3&&Convert.ToString(c.Items[0])!.StartsWith("Ana sunucu"));choices.SelectedIndex=role;window.UpdateLayout();
        var frame=new System.Windows.Threading.DispatcherFrame();var timer=new System.Windows.Threading.DispatcherTimer{Interval=TimeSpan.FromMilliseconds(400)};timer.Tick+=(_,_)=>{timer.Stop();frame.Continue=false;};timer.Start();System.Windows.Threading.Dispatcher.PushFrame(frame);window.UpdateLayout();
        var surface=(FrameworkElement)window.Content;
        var bitmap=new RenderTargetBitmap((int)surface.ActualWidth,(int)surface.ActualHeight,96,96,PixelFormats.Pbgra32);
        var backdrop=new DrawingVisual();using(var draw=backdrop.RenderOpen())draw.DrawRectangle(window.Background,null,new Rect(0,0,surface.ActualWidth,surface.ActualHeight));bitmap.Render(backdrop);bitmap.Render(surface);
        var png=new PngBitmapEncoder();png.Frames.Add(BitmapFrame.Create(bitmap));using(var f=File.Create(file))png.Save(f);window.Close();app.Shutdown();
    }
}
