using System.Diagnostics;
using System.Reflection;
using MiapaxERP.Desktop;

public class GuncelleyiciYetkiTestleri
{
    static object Invoke(string method, params object[] args) => typeof(LisansOturumu).Assembly
        .GetType("MiapaxERP.Desktop.GuncelleyiciBaslatma")!
        .GetMethod(method, BindingFlags.NonPublic | BindingFlags.Static)!.Invoke(null, args)!;

    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public void YalnizGuncelleyiciGerektigindeYukseltilir(bool writable)
    {
        var updater = @"C:\Users\Örnek Kullanıcı\Cache\MiapaxERP.Updater.exe";
        var install = @"C:\Program Files\MiapaxERP\";
        var manifest = @"C:\Users\Örnek Kullanıcı\Cache\pending.json";
        var start = (ProcessStartInfo)Invoke("Olustur", updater, @"C:\Users\Örnek Kullanıcı\Cache", install, 42, manifest, false, writable);
        Assert.Equal(updater, start.FileName);
        Assert.Equal(new[] { "apply", "42", install, manifest }, start.ArgumentList.ToArray());
        Assert.Equal(!writable, start.UseShellExecute);
        Assert.Equal(writable ? "" : "runas", start.Verb);
        Assert.Equal(writable, start.CreateNoWindow);
    }

    [Fact]
    public void YetkiKontroluKlasordeDosyaBirakmaz()
    {
        var directory = Path.Combine(Path.GetTempPath(), "MiapaxERP-yetki-test-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(directory);
        try
        {
            Assert.True((bool)Invoke("Yazilabilir", directory));
            Assert.Empty(Directory.GetFileSystemEntries(directory));
            Assert.False((bool)Invoke("Yazilabilir", Path.Combine(directory, "olmayan-klasor")));
        }
        finally { Directory.Delete(directory); }
    }
}
