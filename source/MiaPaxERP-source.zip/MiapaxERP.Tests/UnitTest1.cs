
using System;
using System.Security.Cryptography;
using System.Text;
using Xunit;
using MiapaxERP.Desktop;

namespace MiapaxERP.Tests
{
    public class UnitTest1
    {
        [Fact]
        public void DogruImzaliLisansKabulEdilmeli()
        {
            using RSA rsa = RSA.Create(2048);

            string belge = "Firma=ABC Boru Fabrikasi;Lisans=BORU-2026-0001";

            byte[] imza = rsa.SignData(
                Encoding.UTF8.GetBytes(belge),
                HashAlgorithmName.SHA256,
                RSASignaturePadding.Pss);

            string acikAnahtar = rsa.ExportSubjectPublicKeyInfoPem();

            bool sonuc = LisansImzaDogrulayici.ImzayiDogrula(
                belge,
                Convert.ToBase64String(imza),
                acikAnahtar);

            Assert.True(sonuc);
        }

        [Fact]
        public void DegistirilmisLisansReddedilmeli()
        {
            using RSA rsa = RSA.Create(2048);

            string orijinalBelge = "Firma=ABC Boru Fabrikasi";

            byte[] imza = rsa.SignData(
                Encoding.UTF8.GetBytes(orijinalBelge),
                HashAlgorithmName.SHA256,
                RSASignaturePadding.Pss);

            string degistirilmisBelge = "Firma=XYZ Boru Fabrikasi";

            bool sonuc = LisansImzaDogrulayici.ImzayiDogrula(
                degistirilmisBelge,
                Convert.ToBase64String(imza),
                rsa.ExportSubjectPublicKeyInfoPem());

            Assert.False(sonuc);
        }

        [Fact]
        public void GecersizImzaReddedilmeli()
        {
            using RSA rsa = RSA.Create(2048);

            bool sonuc = LisansImzaDogrulayici.ImzayiDogrula(
                "Firma=ABC",
                "bu-gecersiz-bir-imzadir",
                rsa.ExportSubjectPublicKeyInfoPem());

            Assert.False(sonuc);
        }
    }
}
