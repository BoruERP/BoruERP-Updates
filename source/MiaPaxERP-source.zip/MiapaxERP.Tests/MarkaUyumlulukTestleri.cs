using System.IO;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MiapaxERP.Desktop;
using MiapaxERP.Guncelleme;
using MiapaxERP.Lisans.Core;

public class MarkaUyumlulukTestleri
{
 [Fact] public void AraMarkaKanalDosyasiOkunurVePaketleDegistirilemez()
 {
  string dir=Path.Combine(Path.GetTempPath(),"MiapaxERP-MiddleBrand-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(dir);
  try{File.WriteAllText(Path.Combine(dir,"BoruERP.guncelleme.json"),"{\"Channel\":\"Ana\"}");string previous=Path.Combine(dir,"MiaSoft.guncelleme.json");File.WriteAllText(previous,"{\"Channel\":\"Yan\"}");Assert.Equal(previous,GuncellemeKanalAyari.DosyaYolu(dir));Assert.True(GuncellemeKanalAyari.KorunanDosya("MiaSoft.guncelleme.json"));Assert.True(GuncellemeKanalAyari.KorunanDosya("MiapaxERP.guncelleme.json"));Assert.True(GuncellemeKanalAyari.KorunanDosya("BoruERP.guncelleme.json"));}
  finally{foreach(var f in Directory.EnumerateFiles(dir))File.Delete(f);Directory.Delete(dir);}
 }
 [Fact] public void EskiKanalDosyasiYeniAdlaOkunabilirVeDegismez()
 {
  string dir=Path.Combine(Path.GetTempPath(),"MiapaxERP-BrandTest-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(dir);
  try{string old=Path.Combine(dir,"BoruERP.guncelleme.json"),current=Path.Combine(dir,"MiapaxERP.guncelleme.json");File.WriteAllText(old,"{\"Channel\":\"Ana\"}");Assert.Equal("Ana",JsonDocument.Parse(File.ReadAllText(GuncellemeKanalAyari.DosyaYolu(dir))).RootElement.GetProperty("Channel").GetString());File.WriteAllText(current,"{\"Channel\":\"Yan\"}");Assert.Equal("Yan",JsonDocument.Parse(File.ReadAllText(GuncellemeKanalAyari.DosyaYolu(dir))).RootElement.GetProperty("Channel").GetString());Assert.Equal("{\"Channel\":\"Ana\"}",File.ReadAllText(old));}
  finally{foreach(var f in Directory.EnumerateFiles(dir))File.Delete(f);Directory.Delete(dir);}
 }
 [Fact] public void EskiSurumdeImzalanmisBelgeYeniAdAlanindaDogrulanir()
 {
  string dir=Path.Combine(AppContext.BaseDirectory,"Fixtures");var e=JsonSerializer.Deserialize<ImzaliLisans>(File.ReadAllText(Path.Combine(dir,"envelope.json")),LisansKripto.Json)!;var p=JsonSerializer.Deserialize<LisansIcerigi>(Convert.FromBase64String(e.Payload),LisansKripto.Json)!;
  Assert.Equal(p.LicenseId,LisansKripto.Dogrula(e,File.ReadAllText(Path.Combine(dir,"public.pem")),p.DeviceId,p.DatabaseId,p.IssuedAt).LicenseId);
 }
 [Fact] public void HatirlananOturumunEskiDpapiAmaciKorunur()
 {
  byte[] oldPurpose=Encoding.UTF8.GetBytes("BoruERP.RememberMe.v1");byte[] data=Encoding.UTF8.GetBytes("Yalnız test oturumu");byte[] encoded=ProtectedData.Protect(data,oldPurpose,DataProtectionScope.CurrentUser);
  var type=typeof(LisansOturumu).Assembly.GetType("MiapaxERP.Desktop.BeniHatirlaServisi")!;var purpose=(byte[])type.GetField("EkVeri",BindingFlags.NonPublic|BindingFlags.Static)!.GetValue(null)!;
  Assert.Equal(data,ProtectedData.Unprotect(encoded,purpose,DataProtectionScope.CurrentUser));
 }
}
