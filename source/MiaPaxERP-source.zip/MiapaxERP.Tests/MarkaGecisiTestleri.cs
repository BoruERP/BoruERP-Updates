using System.IO;
using System.IO.Compression;
using MiapaxERP.Desktop;

public class MarkaGecisiTestleri
{
    [Fact] public void EskiProgramlarYedeklenirVerilerVeYeniProgramDegismez()
    {
        string root = Path.Combine(Path.GetTempPath(), "MiapaxERP-GecisTest-" + Guid.NewGuid().ToString("N"));
        string app = Path.Combine(root, "app"), backup = Path.Combine(root, "backup"); Directory.CreateDirectory(app);
        try
        {
            string[] eski = ["BoruERP.Desktop.exe", "BoruERP.Desktop.dll", "MiaSoft.Desktop.exe"];
            string[] korunacak = ["MiapaxERP.Desktop.exe", "musteriler.mdf", "lisans.dpapi", "BoruERP-musteri-raporu.xlsx"];
            foreach (string name in eski.Concat(korunacak)) File.WriteAllText(Path.Combine(app, name), name);
            File.WriteAllText(Path.Combine(app, "BoruERP.guncelleme.json"), "{\"Channel\":\"Yan\"}");
            string archive = MarkaGecisi.Temizle(app, backup)!;
            Assert.Equal("{\"Channel\":\"Yan\"}", File.ReadAllText(Path.Combine(app, "MiapaxERP.guncelleme.json")));
            Assert.False(File.Exists(Path.Combine(app, "BoruERP.guncelleme.json")));
            Assert.Empty(MarkaGecisi.EskiProgramDosyalari(app));
            using (var zip = ZipFile.OpenRead(archive)) foreach (string name in eski)
            { using var reader = new StreamReader(zip.GetEntry(name)!.Open()); Assert.Equal(name, reader.ReadToEnd()); }
            foreach (string name in korunacak) Assert.Equal(name, File.ReadAllText(Path.Combine(app, name)));
            Assert.Null(MarkaGecisi.Temizle(app, backup));
        }
        finally { Directory.Delete(root, true); }
    }
    [Fact] public void KurulumIcineYedekYazilamaz()
    {
        string root = Path.Combine(Path.GetTempPath(), "MiapaxERP-GecisTest-" + Guid.NewGuid().ToString("N")); Directory.CreateDirectory(root);
        try { File.WriteAllText(Path.Combine(root, "BoruERP.Desktop.exe"), "eski"); Assert.Throws<IOException>(() => MarkaGecisi.Temizle(root, Path.Combine(root, "yedek"))); Assert.True(File.Exists(Path.Combine(root, "BoruERP.Desktop.exe"))); }
        finally { Directory.Delete(root, true); }
    }
    [Fact] public void KilitliDosyadaSilinenProgramlarVeAyarGeriAlinir()
    {
        string root = Path.Combine(Path.GetTempPath(), "MiapaxERP-KilitTest-" + Guid.NewGuid().ToString("N"));
        string app = Path.Combine(root, "app"); Directory.CreateDirectory(app);
        try
        {
            string exe = Path.Combine(app, "BoruERP.Desktop.exe"), dll = Path.Combine(app, "BoruERP.Desktop.dll");
            File.WriteAllText(exe, "eski exe"); File.WriteAllText(dll, "eski dll");
            File.WriteAllText(Path.Combine(app, "BoruERP.guncelleme.json"), "{\"Channel\":\"Ana\"}");
            using (var locked = File.Open(dll, FileMode.Open, FileAccess.Read, FileShare.Read))
                Assert.Throws<IOException>(() => MarkaGecisi.Temizle(app, Path.Combine(root, "backup")));
            Assert.Equal("eski exe", File.ReadAllText(exe)); Assert.Equal("eski dll", File.ReadAllText(dll));
            Assert.False(File.Exists(Path.Combine(app, "MiapaxERP.guncelleme.json")));
            Assert.True(File.Exists(Path.Combine(app, "BoruERP.guncelleme.json")));
        }
        finally { Directory.Delete(root, true); }
    }
    [Fact] public void VarOlanYeniKanalAyariKorunur()
    {
        string root = Path.Combine(Path.GetTempPath(), "MiapaxERP-KanalTest-" + Guid.NewGuid().ToString("N"));
        string app = Path.Combine(root, "app"); Directory.CreateDirectory(app);
        try
        {
            File.WriteAllText(Path.Combine(app, "BoruERP.guncelleme.json"), "{\"Channel\":\"Ana\"}");
            File.WriteAllText(Path.Combine(app, "MiapaxERP.guncelleme.json"), "{\"Channel\":\"Yan\"}");
            MarkaGecisi.Temizle(app, Path.Combine(root, "backup"));
            Assert.Equal("{\"Channel\":\"Yan\"}", File.ReadAllText(Path.Combine(app, "MiapaxERP.guncelleme.json")));
        }
        finally { Directory.Delete(root, true); }
    }
}
