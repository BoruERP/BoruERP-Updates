using System.Text.Json;
using MiapaxERP.Desktop;
int passed=0;
void Check(bool value,string name){if(!value)throw new Exception(name);passed++;Console.WriteLine("PASS "+name);}
foreach(var value in new[]{"https://panel.example.com","https://panel.example.com/","https://panel.example.com:8443"})Check(PortalBaglantisi.Adres(value).Scheme=="https","HTTPS "+value);
foreach(var value in new[]{"http://panel.example.com","https://user:password@panel.example.com","https://panel.example.com/path","https://panel.example.com/?token=secret","https://panel.example.com/#x","file:///C:/test","javascript:alert(1)","","//panel.example.com"}){bool rejected=false;try{PortalBaglantisi.Adres(value);}catch(ArgumentException){rejected=true;}Check(rejected,"Reject "+value);}
Check(PortalBaglantisi.Adres("http://127.0.0.1:5290",true).IsLoopback,"Local preview explicitly allowed");
bool remoteHttpRejected=false;try{PortalBaglantisi.Adres("http://192.168.1.1:5290",true);}catch(ArgumentException){remoteHttpRejected=true;}Check(remoteHttpRejected,"LAN cleartext rejected");
Check(LisansOturumu.Zorunlu,"Customer build requires license");
Check(LisansOturumu.VarsayilanSunucu=="https://boruerp-lisans-yonetimi.ali-can-0001.chatgpt.site","Existing activation default retained");
using var http=new System.Net.Http.HttpClient();using var response=await http.GetAsync("http://127.0.0.1:5291/api/catalog");response.EnsureSuccessStatusCode();using var doc=JsonDocument.Parse(await response.Content.ReadAsStringAsync());
var products=doc.RootElement.GetProperty("products").EnumerateArray().ToArray();Check(products.Length>=3,"Independent portal catalogue HTTP");Check(products.All(p=>!p.TryGetProperty("dealer_kurus",out _)),"Public catalogue never exposes wholesale prices");Check(products.All(p=>!p.GetProperty("name").GetString()!.Contains("Taslak")),"Draft hidden from desktop");
Console.WriteLine($"Passed {passed} checks");
