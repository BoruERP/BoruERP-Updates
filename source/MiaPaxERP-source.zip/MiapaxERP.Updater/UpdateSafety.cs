using System.Diagnostics;

internal static class UpdateSafety
{
    public static string ValidateRelative(string path)
    {
        string rel = path.Replace('\\', '/');
        var parts = rel.Split('/');
        if (string.IsNullOrWhiteSpace(rel) || Path.IsPathRooted(rel) || rel.Length > 220 ||
            rel.Contains(':') || parts.Any(s => s.Length == 0 || s is "." or ".." ||
                s.EndsWith('.') || s.EndsWith(' ') || s.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0))
            throw new InvalidDataException("Güvensiz paket yolu: " + rel);
        string name = parts[^1];
        string ext = Path.GetExtension(name);
        if (parts.Any(s => s.Equals("Data", StringComparison.OrdinalIgnoreCase) ||
                s.Equals("UserData", StringComparison.OrdinalIgnoreCase)) ||
            MiapaxERP.Guncelleme.GuncellemeKanalAyari.KorunanDosya(name) ||
            name.Equals("ag-baglantisi.json", StringComparison.OrdinalIgnoreCase) ||
            name.Contains("lisans", StringComparison.OrdinalIgnoreCase) && ext != ".dll" ||
            new[] { ".db", ".sqlite", ".sqlite3", ".mdf", ".ldf", ".bak", ".pem", ".pfx", ".dpapi" }
                .Contains(ext, StringComparer.OrdinalIgnoreCase))
            throw new InvalidDataException("Kullanıcı verisi/ayarı güncelleme paketinde bulunamaz: " + rel);
        return rel;
    }

    public static string SafeTarget(string root, string relative)
    {
        relative = ValidateRelative(relative);
        string fullRoot = Path.GetFullPath(root).TrimEnd('\\', '/');
        string target = Path.GetFullPath(Path.Combine(fullRoot, relative));
        if (!target.StartsWith(fullRoot + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Kurulum dışına yazılamaz.");
        for (string? path = target; path != null; path = Path.GetDirectoryName(path))
        {
            if ((File.Exists(path) || Directory.Exists(path)) &&
                (File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0)
                throw new InvalidDataException("Bağlantı içeren kurulum yolu kullanılamaz: " + path);
        }
        return target;
    }

    public static void CheckInstalledVersion(string installDir, string remoteVersion, string channel)
    {
        if (channel is not ("Ana" or "Yan") || !Version.TryParse(remoteVersion, out var remote))
            throw new InvalidDataException("Sürüm veya kanal geçersiz.");
        var config = System.Text.Json.JsonDocument.Parse(File.ReadAllText(MiapaxERP.Guncelleme.GuncellemeKanalAyari.DosyaYolu(installDir)));
        using (config)
        {
            if (!string.Equals(config.RootElement.GetProperty("Channel").GetString(), channel, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Güncelleme başka bilgisayar kanalına ait.");
        }
        string exe = Path.Combine(installDir, "MiapaxERP.Desktop.exe");
        var installed = Version.Parse(FileVersionInfo.GetVersionInfo(exe).FileVersion ?? "0.0.0.0");
        if (Normalize(remote) <= Normalize(installed))
            throw new InvalidDataException("Aynı veya eski sürüm kurulamaz.");
    }

    public static Version Normalize(Version version) => new(version.Major, version.Minor,
        Math.Max(0, version.Build), Math.Max(0, version.Revision));
}
