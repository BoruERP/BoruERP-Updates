using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

internal sealed record RestoreEntry(string Path, string? Hash);
internal sealed record RestoreIndex(string Install, string Backup, RestoreEntry[] Files);

internal static class VersionRestore
{
    public static void Save(string local, string install, string backup, List<string> overwritten, List<string> created)
    {
        var files = overwritten.Select(r => new RestoreEntry(r, Hash(UpdateSafety.SafeTarget(backup, r))))
            .Concat(created.Select(r => new RestoreEntry(r, null))).ToArray();
        File.WriteAllText(Path.Combine(local, "previous.json.tmp"), JsonSerializer.Serialize(new RestoreIndex(install, backup, files)));
        File.Move(Path.Combine(local, "previous.json.tmp"), Path.Combine(local, "previous.json"), true);
    }

    private static string Hash(string path)
    {
        using var stream = File.OpenRead(path);
        return Convert.ToHexString(SHA256.HashData(stream));
    }

    // 1.5.2 güncelleyicisi dosyaları yedekler fakat previous.json oluşturmaz.
    // Yalnızca kurulu paketle birebir eşleşen açılmış arşiv ve tek yedek kabul edilir.
    private static void RecoverLegacyIndex(string local, string install, string indexPath)
    {
        if (File.Exists(indexPath)) return;
        string version = FileVersionInfo.GetVersionInfo(Path.Combine(install, "MiapaxERP.Desktop.exe")).FileVersion
            ?? throw new IOException("Kurulu sürüm okunamadı.");
        string release = Version.Parse(version).ToString(3);
        string backups = Path.Combine(local, "yedek");
        var candidates = Directory.Exists(backups)
            ? Directory.GetDirectories(backups).Where(p =>
                Path.GetFileName(p).Equals(release, StringComparison.OrdinalIgnoreCase) ||
                Path.GetFileName(p).StartsWith(release + "-", StringComparison.OrdinalIgnoreCase)).ToArray()
            : Array.Empty<string>();
        if (candidates.Length != 1) throw new IOException("Eski güncelleyicinin yedeği tekil olarak belirlenemedi.");
        string backup = candidates[0];
        string staging = Path.Combine(local, "acilan");
        if (!File.Exists(Path.Combine(backup, "MiapaxERP.Desktop.exe")) || !File.Exists(Path.Combine(backup, "MiapaxERP.Desktop.dll")))
            throw new IOException("Eski sürümün uygulama yedeği eksik.");
        string oldVersion = FileVersionInfo.GetVersionInfo(Path.Combine(backup, "MiapaxERP.Desktop.exe")).FileVersion ?? "0.0";
        if (UpdateSafety.Normalize(Version.Parse(oldVersion)) >= UpdateSafety.Normalize(Version.Parse(version)))
            throw new IOException("Yedek önceki sürüme ait değil.");
        var overwritten = new List<string>();
        var created = new List<string>();
        foreach (string file in Directory.GetFiles(staging, "*", SearchOption.AllDirectories))
        {
            string rel = UpdateSafety.ValidateRelative(Path.GetRelativePath(staging, file));
            string dest = UpdateSafety.SafeTarget(install, rel);
            if (!File.Exists(dest) || Hash(UpdateSafety.SafeTarget(staging, rel)) != Hash(dest))
                throw new IOException("Eski güncelleme dosyaları kurulumla eşleşmiyor: " + rel);
            if (File.Exists(UpdateSafety.SafeTarget(backup, rel))) overwritten.Add(rel);
            else created.Add(rel);
        }
        if (!overwritten.Contains("MiapaxERP.Desktop.exe", StringComparer.OrdinalIgnoreCase))
            throw new IOException("Eski güncelleyicinin dosya listesi eksik.");
        Save(local, install, backup, overwritten, created);
    }

    public static int Run(string[] args)
    {
        string local = Path.GetDirectoryName(Path.GetFullPath(args[3]))!;
        string install = Path.GetFullPath(args[2]);
        using var updateLock = new Mutex(false, @"Local\BoruERP.Update." +
            Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(install.ToUpperInvariant())))[..24]);
        bool locked = false;
        try
        {
            try { locked = updateLock.WaitOne(0); } catch (AbandonedMutexException) { locked = true; }
            if (!locked) throw new IOException("Başka bir güncelleme çalışıyor.");
            if (!int.TryParse(args[1], out int pid)) throw new IOException("PID geçersiz.");
            try { if (!Process.GetProcessById(pid).WaitForExit(120000)) throw new IOException("Program kapanmadı."); }
            catch (ArgumentException) { }
            if (Process.GetProcessesByName("MiapaxERP.Desktop").Any(p =>
            {
                try { return string.Equals(Path.GetDirectoryName(p.MainModule?.FileName)?.TrimEnd('\\'), install.TrimEnd('\\'), StringComparison.OrdinalIgnoreCase); }
                catch { return true; }
            })) throw new IOException("Program hâlâ açık.");
            RecoverLegacyIndex(local, install, args[3]);
            var index = JsonSerializer.Deserialize<RestoreIndex>(File.ReadAllText(args[3])) ?? throw new IOException("Sürüm geçmişi yok.");
            if (!string.Equals(install.TrimEnd('\\', '/'), Path.GetFullPath(index.Install).TrimEnd('\\', '/'), StringComparison.OrdinalIgnoreCase))
                throw new IOException("Yedek başka kuruluma ait.");
            if (!Path.GetFullPath(index.Backup).StartsWith(Path.GetFullPath(local) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                throw new IOException("Yedek konumu geçersiz.");
            var unique = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var entry in index.Files)
            {
                string rel = UpdateSafety.ValidateRelative(entry.Path);
                if (!unique.Add(rel)) throw new IOException("Tekrarlanan yedek yolu.");
                _ = UpdateSafety.SafeTarget(install, rel);
                if (entry.Hash != null && !Hash(UpdateSafety.SafeTarget(index.Backup, rel)).Equals(entry.Hash, StringComparison.OrdinalIgnoreCase))
                    throw new IOException("Yedek doğrulanamadı: " + rel);
            }
            string rescue = Path.Combine(local, "restore-rescue-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(rescue);
            var existed = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var entry in index.Files)
            {
                string dest = UpdateSafety.SafeTarget(install, entry.Path);
                if (!File.Exists(dest)) continue;
                string back = UpdateSafety.SafeTarget(rescue, entry.Path);
                Directory.CreateDirectory(Path.GetDirectoryName(back)!);
                File.Copy(dest, back);
                existed.Add(entry.Path);
            }
            try
            {
                foreach (var entry in index.Files)
                {
                    string dest = UpdateSafety.SafeTarget(install, entry.Path);
                    if (entry.Hash == null) File.Delete(dest);
                    else
                    {
                        Directory.CreateDirectory(Path.GetDirectoryName(dest)!);
                        File.Copy(UpdateSafety.SafeTarget(index.Backup, entry.Path), dest, true);
                    }
                }
            }
            catch
            {
                foreach (var entry in index.Files)
                {
                    string dest = UpdateSafety.SafeTarget(install, entry.Path);
                    if (existed.Contains(entry.Path)) File.Copy(UpdateSafety.SafeTarget(rescue, entry.Path), dest, true);
                    else File.Delete(dest);
                }
                throw;
            }
            File.WriteAllText(Path.Combine(local, "paused"), "Otomatik güncelleme geri dönüşten sonra duraklatıldı.");
            File.Delete(Path.Combine(local, "pending.json"));
            File.Move(args[3], args[3] + ".restored", true);
            File.AppendAllText(Path.Combine(local, "updater.log"), "Önceki sürüm geri yüklendi.\n");
            return 0;
        }
        catch (Exception ex)
        {
            try { File.AppendAllText(Path.Combine(local, "updater.log"), "Geri dönüş başarısız: " + ex + "\n"); } catch { }
            return 1;
        }
        finally { if (locked) updateLock.ReleaseMutex(); }
    }
}
