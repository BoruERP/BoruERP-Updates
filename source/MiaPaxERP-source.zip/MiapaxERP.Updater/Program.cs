using System.Diagnostics;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MiapaxERP.Guncelleme;

if(args.Length == 3 && args[0] == "cleanup")
{
    try
    {
        string app = Path.GetFullPath(args[1]);
        if (Path.GetFullPath(AppContext.BaseDirectory).TrimEnd(Path.DirectorySeparatorChar) != app.TrimEnd(Path.DirectorySeparatorChar)) return 2;
        if (!File.Exists(Path.Combine(app, "MiapaxERP.Desktop.dll"))) return 2;
        MiapaxERP.Desktop.MarkaGecisi.Temizle(app, args[2]); return 0;
    }
    catch { return 1; }
}
// MiapaxERP uygulaması KAPANDIKTAN SONRA çalışır. Kimlik doğrulaması + rollback.
if (args.Length == 4 && args[0] == "rollback") return VersionRestore.Run(args);
if (args.Length != 4 || args[0] != "apply" || !int.TryParse(args[1], out int pid)) return 2;
string installDir = Path.GetFullPath(args[2]);
string manifestPath = Path.GetFullPath(args[3]);
string local = Path.GetDirectoryName(manifestPath)!;
string log = Path.Combine(local, "updater.log");
using var updateLock = new Mutex(false, "Local\\BoruERP.Update." +
    Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(installDir.ToUpperInvariant())))[..24]);
bool locked = false;
void Log(string s)
{
    try { Directory.CreateDirectory(local); File.AppendAllText(log, DateTimeOffset.Now.ToString("O") + " " + s + Environment.NewLine); }
    catch { }
}
try
{
    try { locked = updateLock.WaitOne(0); } catch (AbandonedMutexException) { locked = true; }
    if (!locked) throw new InvalidOperationException("Bu kurulum için başka güncelleme çalışıyor.");
    try { if (!Process.GetProcessById(pid).WaitForExit(120000)) throw new TimeoutException("Uygulama 120 saniyede kapanmadı."); }
    catch (ArgumentException) { /* PID kapanmış */ }
    // Hâlâ çalışan uygulamanın dosyaları üzerine yazma.
    if (Process.GetProcessesByName("MiapaxERP.Desktop").Any(p =>
    {
        try { return Path.GetDirectoryName(p.MainModule?.FileName)?.TrimEnd('\\') == installDir.TrimEnd('\\'); }
        catch { return true; } // Emin değilsek güncellemeyi yapmayız.
    })) throw new InvalidOperationException("Uygulama hâlâ açık; güncelleme ertelendi.");

    if (GuncellemeAnahtari.Pem.Contains("PUBLIC_KEY_NOT_CONFIGURED"))
        throw new InvalidOperationException("Güncelleme imzalama anahtarı yapılandırılmadı.");
    var m = JsonSerializer.Deserialize<Manifest>(File.ReadAllText(manifestPath))
        ?? throw new InvalidDataException("Manifest okunamadı.");
    if (!Uri.TryCreate(m.PackageUrl, UriKind.Absolute, out var u) || u.Scheme != Uri.UriSchemeHttps)
        throw new InvalidDataException("Paket URL HTTPS değil.");
    if (m.Sha256.Length != 64 || !System.Text.RegularExpressions.Regex.IsMatch(m.Sha256, "^[a-fA-F0-9]{64}$"))
        throw new InvalidDataException("SHA geçersiz.");
    using (RSA rsa = RSA.Create())
    {
        rsa.ImportFromPem(GuncellemeAnahtari.Pem);
        string signed = m.Version + "\n" + m.Channel + "\n" + m.PackageUrl + "\n" + m.Sha256.ToLowerInvariant() + "\n";
        if (!rsa.VerifyData(Encoding.UTF8.GetBytes(signed), Convert.FromBase64String(m.Signature),
            HashAlgorithmName.SHA256, RSASignaturePadding.Pss))
            throw new CryptographicException("İmza doğrulanamadı.");
    }
    UpdateSafety.CheckInstalledVersion(installDir, m.Version, m.Channel);
    string zipFile = Path.Combine(local, "paket.zip");
    if (!File.Exists(zipFile)) throw new FileNotFoundException("İndirilen paket bulunamadı.");
    using var zipStream = File.OpenRead(zipFile);
    string actualHash = Convert.ToHexString(SHA256.HashData(zipStream));
    if (!actualHash.Equals(m.Sha256, StringComparison.OrdinalIgnoreCase))
        throw new CryptographicException("Güncelleme zip dosyası değişmiş.");

    // Güncelleme uygulama kurulum klasörünün dışından çalışır. Kurulumun kullanıcı-yazılabilir olmasını bekler.
    string staging = Path.Combine(local, "acilan");
    string backup = Path.Combine(local, "yedek", m.Version + "-" + Guid.NewGuid().ToString("N"));
    if (Directory.Exists(staging)) Directory.Delete(staging, true);
    Directory.CreateDirectory(staging);
    Directory.CreateDirectory(backup);
    var paths = new List<string>();
    var uniquePaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
    long uncompressed = 0;
    using (var archive = ZipFile.OpenRead(zipFile))
    {
        if (archive.Entries.Count > 10000) throw new InvalidDataException("Çok fazla arşiv dosyası.");
        foreach (var item in archive.Entries)
        {
            string relative = item.FullName.Replace('\\', '/');
            if (relative.EndsWith('/')) continue;
            relative = UpdateSafety.ValidateRelative(relative);
            if (!uniquePaths.Add(relative)) throw new InvalidDataException("Tekrarlanan paket yolu: " + relative);
            // Zip Slip, alternatif disk, ayar/veri dosyası üstüne yazma yok.
            if (Path.IsPathRooted(relative) || relative.Split('/').Any(s => s == ".." || s == ".") ||
                relative.Contains(':') || relative.Length > 220 ||
                MiapaxERP.Guncelleme.GuncellemeKanalAyari.KorunanDosya(relative) ||
                relative.StartsWith("Data/", StringComparison.OrdinalIgnoreCase) ||
                relative.StartsWith("UserData/", StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Güvensiz arşiv yolu: " + relative);
            uncompressed += item.Length;
            if (uncompressed > 1200L * 1024 * 1024) throw new InvalidDataException("Açılan paket çok büyük.");
            string target = UpdateSafety.SafeTarget(staging, relative);
            if (!target.StartsWith(Path.GetFullPath(staging) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Arşiv dışına yazma girişimi.");
            Directory.CreateDirectory(Path.GetDirectoryName(target)!);
            item.ExtractToFile(target);
            paths.Add(relative);
        }
    }
    if (!paths.Contains("MiapaxERP.Desktop.exe", StringComparer.OrdinalIgnoreCase))
        throw new InvalidDataException("Pakette MiapaxERP.Desktop.exe bulunamadı.");
    string? packagedVersion = FileVersionInfo.GetVersionInfo(Path.Combine(staging, "MiapaxERP.Desktop.exe")).FileVersion;
    if (!Version.TryParse(packagedVersion, out var packageVersion) ||
        UpdateSafety.Normalize(packageVersion) != UpdateSafety.Normalize(Version.Parse(m.Version)))
        throw new InvalidDataException("Paketin dosya sürümü imzalı bildirimle eşleşmiyor.");

    // Önce tüm değişecek dosyaları yedekle, sonra sırayla yükle.
    var overwritten = new List<string>();
    var created = new List<string>();
    foreach (string rel in paths)
    {
        string dest = UpdateSafety.SafeTarget(installDir, rel);
        if (!dest.StartsWith(installDir.TrimEnd('\\', '/') + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Kurulum sınırı dışına çıkılamaz.");
        if (File.Exists(dest))
        {
            string back = Path.Combine(backup, rel);
            Directory.CreateDirectory(Path.GetDirectoryName(back)!);
            File.Copy(dest, back, true);
            overwritten.Add(rel);
        }
        else created.Add(rel);
    }
    try
    {
        foreach (string rel in paths)
        {
            string dest = UpdateSafety.SafeTarget(installDir, rel);
            Directory.CreateDirectory(Path.GetDirectoryName(dest)!);
            // Dosya başına geçici dosya; eski dosya başarıyla indirilmeden değişmez.
            string tmp = dest + ".MiapaxERP_new";
            File.Copy(Path.Combine(staging, rel), tmp, true);
            File.Move(tmp, dest, true);
        }
        // Geri dönüş kaydı da işlemin parçasıdır; kaydedilemezse dosyaları geri yükle.
        VersionRestore.Save(local, installDir, backup, overwritten, created);
    }
    catch
    {
        foreach (string rel in overwritten)
        {
            try { File.Copy(Path.Combine(backup, rel), Path.Combine(installDir, rel), true); }
            catch (Exception ex) { Log("GERI ALMA HATASI " + rel + " " + ex.Message); }
        }
        foreach (string rel in created)
        {
            try { File.Delete(Path.Combine(installDir, rel)); }
            catch { }
        }
        throw;
    }
    File.Delete(manifestPath);
    Log("Güncelleme başarıyla tamamlandı: " + m.Version);
    return 0;
}
catch (Exception ex)
{
    Log("GÜNCELLEME BAŞARISIZ: " + ex);
    return 1;
}
finally { if (locked) updateLock.ReleaseMutex(); }

internal sealed class Manifest
{
    public string Version { get; set; } = "";
    public string Channel { get; set; } = "";
    public string PackageUrl { get; set; } = "";
    public string Sha256 { get; set; } = "";
    public string Signature { get; set; } = "";
}

