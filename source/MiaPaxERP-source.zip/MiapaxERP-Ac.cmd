@echo off
start "" "%~dp0MiapaxERP.slnx"
