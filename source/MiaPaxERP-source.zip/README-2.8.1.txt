Miapax ERP 2.8.1 — temiz adlandırma yayını

Resmi depo: https://github.com/MiaPaxERP/MiapaxERP-Updates
Visual Studio çözümü: MiapaxERP.slnx
Program: MiapaxERP.Desktop.exe

Bu sürümde indirme arşivlerinin ve Visual Studio projelerinin dosya/klasör
adları MiapaxERP olarak düzenlenmiştir. Eski marka adıyla EXE/DLL köprüleri
artık dağıtılmaz. Logo ve uygulama simgeleri Miapax ERP'dir.

2.8.0 kurulumunda Ayarlar > Programı güncelle kullanılabilir. İlk açılışta
eski dağıtımın bilinen EXE/DLL dosyaları program klasöründen kaldırılır;
öncesinde kullanıcının yerel MiapaxERP/GecisYedekleri klasörüne yedeklenir.
Program Files kurulumu yönetici onayı isteyebilir. Eski kısayolunuz çalışmazsa
kurulumdaki MiapaxERP.Desktop.exe üzerinden yeni kısayol oluşturun.
Güncelleme kanalı ayarları içeriği korunarak yeni dosya adına taşınır.

Yeni kurulumda Ana veya Yan ZIP'i yeni ve boş bir klasöre çıkartıp
IlkBaslat.cmd dosyasını çalıştırın. Ana fabrika, Yan istemci içindir.
Veritabanı, bağlantı ayarları ve lisans dosyaları bu arşivlerde bulunmaz.
Mevcut fabrikanın verilerini ve SQL bağlantısını koruyun.

2.2.x ve daha eski güncelleyiciler eski EXE adını zorunlu tutabilir.
Bu sürümlerde temiz ZIP'i ayrı klasöre çıkartarak bağlantı ayarlarını
mevcut SQL veritabanına yönlendirin; veritabanını yeniden oluşturmayın.
Önceki kurulumun ve verilerin yedeğini almadan üzerine manuel kopyalamayın.

Mevcut SQL tablo/veritabanı kimlikleri, imzalı lisans kimlikleri, korumalı
oturum verileri ve Android uygulama/imza kimliği uyumluluk amacıyla korunur.
Bu teknik kimlikler yeniden adlandırılmadı; müşteri verileri taşınmadı.
Android sürümü 2.8.1 mevcut uygulamanın üzerine aynı imzayla güncellenir.

Muhasebe, bordro ve e-belge işlevleri 2.8.0 kapsamını korur. Bordro resmi
SGK/GİB beyan gönderimi değildir. BA/BS geçmiş arşiv/mutabakat içindir.
Fabrika veritabanında ve canlı e-belge servisinde test gönderimi yapılmaz.

Saha pazarlama ve mobil amblemi yenilendi. Kroki PDF/yazdırma çıktıları
Miapax ERP logosunu kullanır. Ayarlardan seçilmiş özel firma logosu korunur;
bilinen eski uygulama logoları yeni logo ile değiştirilir.
