using System.IO;
using System.Text;
using System.Text.Json;
using MiapaxERP.Desktop.EBelge;
internal static class MaliE2eTest
{
 sealed record Record(string Senaryo,HizliGonderi Belge,string Durum,string Aciklama);
 public static async Task<int> Dogrula()
 {
  var key=HizliAyarDeposu.Oku(HizliAyarDeposu.AktifTestDosyasi(HizliAyarDeposu.KurulumKlasoru));if(key.Ortam!=EbelgeOrtam.Test)throw new InvalidOperationException("Yalnız TEST");using var api=new HizliApi(EbelgeOrtam.Test,key);
  string dir=Path.Combine(HizliAyarDeposu.KurulumKlasoru,"MaliTest280");var rows=Directory.GetFiles(dir,"mali-*.json").OrderBy(x=>x,StringComparer.Ordinal).SelectMany(f=>JsonSerializer.Deserialize<Record[]>(File.ReadAllText(f))!).Where(x=>x.Durum=="ETTN/XML/PDF doğrulandı").GroupBy(x=>x.Senaryo).Select(x=>x.Last()).ToArray();int failed=0;
  foreach(var row in rows)try{var sent=row.Belge;var box=sent.AppType==3?EbelgeKutusu.GidenArsiv:EbelgeKutusu.GidenFatura;var remote=await api.Sorgula(box,Guid.Parse(sent.DocumentUUID),default)??throw new EbelgeHatasi("Belge doğrulanamadı.");var data=await api.Dosya(box,remote.UUID,"XML",false,EbelgeTarihi.Oku(remote.RawIssueDate),default);var actual=UblBelge.Oku(new UTF8Encoding(false,true).GetString(data).TrimStart('\uFEFF'));var expected=UblBelge.Oku(sent.XmlContent);if(actual.Odenecek!=expected.Odenecek||actual.Tevkifat!=expected.Tevkifat||actual.Doviz!=expected.Doviz)throw new EbelgeHatasi("Mali alanlar uyuşmuyor.");Console.WriteLine("PASS TEST "+row.Senaryo+": sıkı mali alan kontrolü ve sağlayıcı XML eşleşmesi.");}catch(EbelgeHatasi e){failed++;Console.WriteLine(row.Senaryo+": "+e.Message);}
  return failed==0&&rows.Length==5?0:1;
 }
 public static async Task<int> Run(bool dovizOnly=false)
 {
  var key=HizliAyarDeposu.Oku(HizliAyarDeposu.AktifTestDosyasi(HizliAyarDeposu.KurulumKlasoru));if(key.Ortam!=EbelgeOrtam.Test)throw new InvalidOperationException("Yalnız TEST");using var api=new HizliApi(EbelgeOrtam.Test,key);await api.Giris(default);
  var docs=await api.Liste(EbelgeKutusu.GidenFatura,DateTime.Today.AddDays(-7),DateTime.Today.AddDays(1).AddTicks(-1),false,default);if(docs.Length==0)throw new InvalidOperationException("TEST alıcısı yok.");var bytes=await api.Dosya(EbelgeKutusu.GidenFatura,docs[0].UUID,"XML",false,EbelgeTarihi.Oku(docs[0].RawIssueDate),default);var reference=UblKimlik.Oku(new UTF8Encoding(false,true).GetString(bytes).TrimStart('\uFEFF'));if(reference.Gonderen!=key.Vkn)throw new InvalidOperationException("TEST hesabı uyuşmuyor.");
  var source=(await api.Mukellef(1,"GB",key.Vkn,default)).First().Alias;var target=(await api.Mukellef(1,"PK",reference.Alici,default)).First().Alias;var now=DateTime.Now;
  var cases=new[]{("TEVKIFAT-TRY",1,new UblMaliAyar(Tevkifat:UblMaliHesap.Tevkifat("624")),0m),("DOVIZ-USD",1,new UblMaliAyar("USD",35.123456m,now.Date,"SADECE TEST KURU"),0m),("TEVKIFAT-EUR",1,new UblMaliAyar("EUR",40.123456m,now.Date,"SADECE TEST KURU",UblMaliHesap.Tevkifat("624")),0m),("ESKI-BRUT-INDIRIM",1,new UblMaliAyar(),1200m),("EARSIV-DOVIZ-TEVKIFAT",3,new UblMaliAyar("USD",35.123456m,now.Date,"SADECE TEST KURU",UblMaliHesap.Tevkifat("624")),0m)};
  string dir=Path.Combine(HizliAyarDeposu.KurulumKlasoru,"MaliTest280");Directory.CreateDirectory(dir);string path=Path.Combine(dir,"mali-"+DateTime.UtcNow.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N")+".json");var records=new List<Record>();int failed=0;
  void Save(){string temp=path+".tmp";File.WriteAllText(temp,JsonSerializer.Serialize(records));File.Move(temp,path,true);}
  foreach(var(name,app,settings,discount) in cases)
  {
   if(dovizOnly&&settings.Doviz=="TRY")continue;
   string recipient=app==3?"10000000146":reference.Alici;var seller=new UblTaraf(key.Vkn,"MIAPAX ENTEGRASYON TEST","TEST","Yalnız TEST adresi","Kayseri","Kocasinan",PostaKodu:"38000");var buyer=new UblTaraf(recipient,"MIAPAX TEST ALICI","TEST","Yalnız TEST adresi","Kayseri","Melikgazi",Ad:recipient.Length==11?"TEST":"",Soyad:recipient.Length==11?"ALICI":"",PostaKodu:"38000");
   Guid uuid=Guid.NewGuid();string no="MPX"+now.Year+Random.Shared.NextInt64(1,999999999).ToString("D9");var rows=new[]{new UblSatir("1","TEST","SADECE ENTEGRASYON TESTI - MALI ISLEM DEGILDIR",1,"C62",20000,20)};var m=settings;
   if(discount>0){var calc=UblMaliHesap.EskiBrutIndirim(rows,discount);rows=calc.Satirlar;m=m with{Yuvarlama=calc.Yuvarlama,IndirimAciklamasi="TEST eski brüt indirim dağılımı"};}
   string xml=UblBelge.Olustur(uuid,no,now,app,app==3?"EARSIVFATURA":"TEMELFATURA",seller,buyer,rows,gonderimSekli:app==3?"KAGIT":null,mali:m);UblSema.Dogrula(xml);var input=new HizliGonderi(app,source,recipient,app==3?"":target,xml,uuid.ToString(),no,now.ToString("yyyy-MM-dd"),"MIAPAX-TEST-"+uuid.ToString("N"),IsDraft:false);
   records.Add(new(name,input,"Hazır","Yalnız test. Gerçek muhasebe/stok/e-posta işlemi yok."));Save();
   try
   {
    records[^1]=records[^1] with{Durum="Gönderim başladı"};Save();await api.Gonder(input,default);records[^1]=records[^1] with{Durum="Kabul edildi"};Save();Console.WriteLine("TEST "+name+": sağlayıcı kabul etti.");
    var box=app==3?EbelgeKutusu.GidenArsiv:EbelgeKutusu.GidenFatura;var found=await api.Sorgula(box,uuid,default);if(found?.DocumentId!=no)throw new EbelgeHatasi("Gönderim sonrası ETTN kaydı henüz doğrulanamadı.");
    var returned=await api.Dosya(box,uuid,"XML",false,EbelgeTarihi.Oku(found.RawIssueDate),default);var parsed=UblBelge.Oku(new UTF8Encoding(false,true).GetString(returned).TrimStart('\uFEFF'));var expected=UblBelge.Oku(xml);if(parsed.Kimlik.Ettn!=uuid||parsed.Odenecek!=expected.Odenecek||parsed.Doviz!=expected.Doviz||parsed.Tevkifat!=expected.Tevkifat)throw new EbelgeHatasi("Sağlayıcı XML mali toplamları beklenenle uyuşmuyor.");
    var pdf=await api.Dosya(box,uuid,"PDF",false,EbelgeTarihi.Oku(found.RawIssueDate),default);if(!pdf.AsSpan().StartsWith("%PDF-"u8))throw new EbelgeHatasi("PDF doğrulanamadı.");records[^1]=records[^1] with{Durum="ETTN/XML/PDF doğrulandı",Aciklama="TEST sağlayıcı kabulü; CANLI GİB teslimi iddiası değildir."};Save();Console.WriteLine("TEST "+name+": ETTN, XML döviz/tevkifat/ödenecek ve PDF doğrulandı.");
   }
   catch(EbelgeHatasi e){failed++;records[^1]=records[^1] with{Durum=e.Belirsiz?"Belirsiz":"Kontrol gerekli",Aciklama=e.Message};Save();Console.WriteLine("TEST "+name+": "+e.Message);}
  }
  return failed==0?0:1;
 }
}
