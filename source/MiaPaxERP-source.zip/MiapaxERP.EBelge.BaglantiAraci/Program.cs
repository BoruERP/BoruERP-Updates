using System.Windows;
using System.IO;
using System.Text.Json;
using MiapaxERP.Desktop.EBelge;
internal static class Program
{
 [STAThread]static int Main(string[] args)
 {
  Console.OutputEncoding=new System.Text.UTF8Encoding(false);
  if(args.SequenceEqual(new[]{"--mali-280-sonuc-dogrula"}))return MaliE2eTest.Dogrula().GetAwaiter().GetResult();
  if(args.SequenceEqual(new[]{"--mali-280-yalniz-test"}))return MaliE2eTest.Run().GetAwaiter().GetResult();
  if(args.SequenceEqual(new[]{"--mali-280-doviz-test"}))return MaliE2eTest.Run(true).GetAwaiter().GetResult();
  if(args.SequenceEqual(new[]{"--kayitli-test-baglantisini-denetle"}))return Denetle().GetAwaiter().GetResult();
  if(args.SequenceEqual(new[]{"--test-servis-sorgularini-denetle"}))return Sorgular().GetAwaiter().GetResult();
  if(args.SequenceEqual(new[]{"--test-belge-okumasini-denetle"}))return Belgeler().GetAwaiter().GetResult();
  if(args.SequenceEqual(new[]{"--test-firma-kimligini-denetle"}))return Firma(false).GetAwaiter().GetResult();
  if(args.SequenceEqual(new[]{"--test-firma-ayarini-hazirla"}))return Firma(true).GetAwaiter().GetResult();
  if(args.SequenceEqual(new[]{"--yalniz-test-gonderim-denetimi"}))return HizliE2eTest.Run().GetAwaiter().GetResult();
  if(args.SequenceEqual(new[]{"--test-ubl-sozlesmesini-incele"})){HizliE2eTest.Inspect().GetAwaiter().GetResult();return 0;}
  if(args.SequenceEqual(new[]{"--test-arsiv-irsaliye-revizyon-2"}))return HizliE2eTest.Run(new[]{3,5}).GetAwaiter().GetResult();
  if(args.SequenceEqual(new[]{"--test-irsaliye-revizyon-3"}))return HizliE2eTest.Run(new[]{5}).GetAwaiter().GetResult();
  if(args.SequenceEqual(new[]{"--test-gonderim-sonuclarini-dogrula"}))return HizliE2eTest.SonuclariDogrula().GetAwaiter().GetResult();
  if(args.SequenceEqual(new[]{"--test-taslak-hazirla"}))return HizliE2eTest.Run(new[]{1,3,5},true).GetAwaiter().GetResult();
  if(args.SequenceEqual(new[]{"--test-taslaklari-gonder"}))return HizliE2eTest.TaslaklariGonder().GetAwaiter().GetResult();
  new Application().Run(new HizliBaglantiPenceresi());return 0;
 }
 static async Task<int> Denetle()
 {
  // Yalnız kullanıcının bu Windows hesabında test aracıyla hazırladığı tek bekleyen bağlantı.
  string folder=Path.Combine(HizliAyarDeposu.KurulumKlasoru,"Bekleyen");var files=Directory.Exists(folder)?Directory.GetFiles(folder,"hizli-Test-*.dpapi"):Array.Empty<string>();
  if(files.Length!=1){Console.WriteLine("Tek bir bekleyen TEST bağlantısı gerekli. Anahtar veya parola okunmadı.");return 2;}
  try
  {
   var key=HizliAyarDeposu.Oku(files[0]);if(key.Ortam!=EbelgeOrtam.Test)throw new ArgumentException("Bu denetim yalnız test ortamına açıktır.");using var api=new HizliApi(EbelgeOrtam.Test,key);await api.Giris(default);HizliAyarDeposu.Kaydet(HizliAyarDeposu.KurulumKlasoru,key);
   var report=new{Saglayici="HizliBilisim",Ortam="Test",GirisBasarili=true,VknSonDort=key.Vkn[^4..],TarihUtc=DateTimeOffset.UtcNow,ResmiBelgeGonderildi=false};File.WriteAllText(Path.Combine(HizliAyarDeposu.KurulumKlasoru,"test-baglanti-sonucu.json"),JsonSerializer.Serialize(report));Console.WriteLine("TEST hesabına giriş başarılı. Resmî belge gönderilmedi.");return 0;
  }
  catch(Exception e){Console.WriteLine(e is EbelgeHatasi or ArgumentException?e.Message:"Şifreli test bağlantısı okunamadı. Windows hesabını ve ayar dosyasını kontrol edin.");return 1;}
 }
 static async Task<int> Sorgular()
 {
  string root=HizliAyarDeposu.KurulumKlasoru;var key=HizliAyarDeposu.Oku(HizliAyarDeposu.AktifTestDosyasi(root));if(key.Ortam!=EbelgeOrtam.Test)return 2;using var api=new HizliApi(key.Ortam,key);var results=new List<object>();int failed=0;
  async Task Check(string name,Func<Task<int>> call){try{int count=await call();results.Add(new{Sorgu=name,Basarili=true,KayitSayisi=count});Console.WriteLine(name+": başarılı; kayıt sayısı "+count);}catch(EbelgeHatasi e){failed++;results.Add(new{Sorgu=name,Basarili=false,Hata=e.Message});Console.WriteLine(name+": "+e.Message);}}
  await Check("TEST giriş",async()=>{await api.Giris(default);return 1;});
  foreach(int app in new[]{1,5})await Check("Gönderici etiket / "+app,async()=>(await api.Mukellef(app,"GB",key.Vkn,default)).Length);
  foreach(var box in Enum.GetValues<EbelgeKutusu>())await Check("Belge kutusu / "+box,async()=>(await api.Liste(box,DateTime.Today.AddDays(-7),DateTime.Today.AddDays(1).AddTicks(-1),false,default)).Length);
  File.WriteAllText(Path.Combine(root,"test-servis-sorgulari.json"),JsonSerializer.Serialize(new{Ortam="Test",TarihUtc=DateTimeOffset.UtcNow,Sonuclar=results,ResmiBelgeGonderildi=false},new JsonSerializerOptions{WriteIndented=true}));return failed==0?0:1;
 }
 static async Task<int> Belgeler()
 {
  var key=HizliAyarDeposu.Oku(HizliAyarDeposu.AktifTestDosyasi(HizliAyarDeposu.KurulumKlasoru));if(key.Ortam!=EbelgeOrtam.Test)return 2;using var api=new HizliApi(key.Ortam,key);int failed=0;
  foreach(var box in Enum.GetValues<EbelgeKutusu>())
  {
   try
   {
    var docs=await api.Liste(box,DateTime.Today.AddDays(-7),DateTime.Today.AddDays(1).AddTicks(-1),false,default);if(docs.Length==0){Console.WriteLine(box+": örnek belge yok.");continue;}var doc=docs[0];var found=await api.Sorgula(box,doc.UUID,default);if(found?.UUID!=doc.UUID)throw new EbelgeHatasi("ETTN sorgusu belge kimliğini doğrulamadı.");Console.WriteLine(box+": ETTN sorgusu başarılı.");var date=EbelgeTarihi.Oku(doc.RawIssueDate);var bytes=await api.Dosya(box,doc.UUID,"XML",false,date,default);var text=new System.Text.UTF8Encoding(false,true).GetString(bytes).TrimStart('\uFEFF');var u=UblKimlik.Oku(text);if(u.Ettn!=doc.UUID)throw new EbelgeHatasi("İndirilen XML ile liste ETTN'si uyuşmuyor.");Console.WriteLine(box+": XML kimlik kontrolü başarılı; gönderici, girilen VKN ile "+(u.Gonderen==key.Vkn?"aynı":"farklı")+".");
    var pdf=await api.Dosya(box,doc.UUID,"PDF",false,date,default);if(!pdf.AsSpan().StartsWith("%PDF-"u8))throw new EbelgeHatasi("PDF yerine farklı içerik döndü.");Console.WriteLine(box+": PDF biçimi doğrulandı.");
   }
   catch(Exception e){failed++;Console.WriteLine(box+": "+(e is EbelgeHatasi or ArgumentException?e.Message:"Belge okuma doğrulanamadı."));}
  }
  return failed==0?0:1;
 }
 static async Task<int> Firma(bool configure)
 {
  var key=HizliAyarDeposu.Oku(HizliAyarDeposu.AktifTestDosyasi(HizliAyarDeposu.KurulumKlasoru));if(key.Ortam!=EbelgeOrtam.Test)return 2;using var api=new HizliApi(key.Ortam,key);var senders=new HashSet<string>();
  foreach(var box in new[]{EbelgeKutusu.GidenFatura,EbelgeKutusu.GidenArsiv,EbelgeKutusu.GidenIrsaliye})
  {
   var docs=await api.Liste(box,DateTime.Today.AddDays(-7),DateTime.Today.AddDays(1).AddTicks(-1),false,default);foreach(var d in docs.Take(2)){var bytes=await api.Dosya(box,d.UUID,"XML",false,EbelgeTarihi.Oku(d.RawIssueDate),default);var u=UblKimlik.Oku(new System.Text.UTF8Encoding(false,true).GetString(bytes).TrimStart('\uFEFF'));if(u.Ettn!=d.UUID)throw new EbelgeHatasi("Kimlik doğrulanamadı.");senders.Add(u.Gonderen);}
  }
  Console.WriteLine("Örnek giden belgelerde farklı gönderici sayısı: "+senders.Count+".");if(senders.Count!=1)return 2;
  int verified=0;string vkn=senders.Single();foreach(int app in new[]{1,5})try{var aliases=await api.Mukellef(app,"GB",vkn,default);Console.WriteLine("Belge göndericisi / "+app+": kayıtlı GB etiketi sayısı "+aliases.Length);if(aliases.Length>0)verified++;}catch(EbelgeHatasi e){Console.WriteLine("Belge göndericisi / "+app+": "+e.Message);}
  if(configure){if(verified!=2)throw new EbelgeHatasi("Test firma etiketi doğrulanamadı; ayar değiştirilmedi.");HizliAyarDeposu.AktifTestSec(HizliAyarDeposu.KurulumKlasoru,key with{Vkn=vkn});Console.WriteLine("Test belgelerinin göndericisi iki uygulamanın GB kayıtlarıyla doğrulanarak TEST bağlantısına seçildi. Gerçek firma ayarları değiştirilmedi.");}
  return 0;
 }
}
