from pathlib import Path
import zipfile, json, hashlib, re

root=Path(__file__).resolve().parents[2]
panel=root/'BoruERP-BayiPaneli-3.0'
source=root/'BoruERP-2.3-Gelistirme'
out=root/'Teslim230'
out.mkdir(exist_ok=True)
skip={'bin','obj','.git','node_modules','.sites-export','.sites-checkout','.test-results','test-results','AndroidAraclari','data','secrets','__pycache__'}
def allowed(p,base):
    rel=p.relative_to(base)
    if any(x in skip for x in rel.parts): return False
    name=p.name.lower()
    return not (name=='.env' or name=='ilk-giris.txt' or 'private' in name or name.endswith(('.dpapi','.sqlite','.sqlite-wal','.sqlite-shm','.db','.bak','.jks','.pfx','.user','.suo')))
def addtree(z,base,prefix=''):
    for p in sorted(base.rglob('*')):
        if p.is_file() and allowed(p,base):
            # Only private-key *material*, not the string used to detect it, is forbidden.
            if p.suffix.lower() in {'.pem','.json','.txt','.js','.mjs','.cs','.ps1','.py'}:
                raw=p.read_bytes()
                if re.search(rb'-----BEGIN (?:RSA )?PRIVATE KEY-----[\r\n]+[A-Za-z0-9+/=]{20}',raw):
                    raise RuntimeError('Private key material detected; packaging aborted: '+str(p))
            z.write(p,prefix+p.relative_to(base).as_posix())
def create(name,writer):
    target=out/name
    if target.exists(): raise RuntimeError('Will not overwrite '+str(target))
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z: writer(z)
    with zipfile.ZipFile(target) as z:
        if z.testzip(): raise RuntimeError('ZIP integrity failure')
    return target
outputs=[]
outputs.append(create('BoruERP-BayiPaneli-3.0-RC1-Sunucu.zip',lambda z:addtree(z,panel)))
def allsource(z):
    addtree(z,panel,'BoruERP-BayiPaneli-3.0/')
    addtree(z,source,'BoruERP-2.3-Gelistirme/')
outputs.append(create('BoruERP-2.3-RC1-Tam-Kaynak.zip',allsource))
for channel in ['Ana','Yan']:
    def desktop(z,channel=channel):
        base=out/'Masaustu-OnSurum'
        for p in sorted(base.rglob('*')):
            if not p.is_file(): continue
            rel=p.relative_to(base).as_posix()
            if rel=='BoruERP.guncelleme.json':
                z.writestr(rel,json.dumps({'ManifestUrl':f'https://raw.githubusercontent.com/BoruERP/BoruERP-Updates/main/manifest-{channel.lower()}.json','Channel':channel,'CheckMinutes':30},ensure_ascii=False,indent=2))
            else: z.write(p,rel)
        z.write(source/'BASLANGIC-2.3-RC1.txt','ONCE-OKUYUN-RC1.txt')
    outputs.append(create(f'BoruERP-2.3-RC1-{channel}.zip',desktop))
hashes=[]
for p in outputs:
    sha=hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
    hashes.append(sha+'  '+p.name)
    print(json.dumps({'file':p.name,'bytes':p.stat().st_size,'sha256':sha}))
(out/'SHA256.txt').write_text('\n'.join(hashes)+'\n',encoding='utf-8')
