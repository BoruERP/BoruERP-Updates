$ErrorActionPreference='Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
$privateFolder=Join-Path $env:USERPROFILE 'BoruERP_GizliAnahtarlar\BayiPaneli30'
if (-not (Test-Path (Join-Path $privateFolder 'portal.sqlite'))) { throw 'Önce kurulum / veri aktarımı yapılmalı. KILAVUZ.txt dosyasını okuyun.' }
$nodePath=(Get-Command node -ErrorAction SilentlyContinue).Source
if (-not $nodePath) { $nodePath=Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' }
if (-not (Test-Path $nodePath)) { throw 'Node.js 24 kurun. https://nodejs.org/en/download' }
$env:DB_PATH=Join-Path $privateFolder 'portal.sqlite'
$env:PORTAL_SECRET_FILE=Join-Path $privateFolder 'secrets.dpapi'
$env:PUBLIC_ORIGIN='http://127.0.0.1:5290'
$env:HOST='127.0.0.1'
$env:PORT='5290'
$env:PAYMENTS_ENABLED='false'
Write-Host 'Panel: http://127.0.0.1:5290 — bu pencere açık kalmalı.'
& $nodePath src/server.js
