import {DatabaseSync,backup} from 'node:sqlite';
import {mkdirSync,writeFileSync,readFileSync,existsSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {loadConfig} from '../src/config.js';
// Export is deliberately separate from distributable packaging. Destination must be private.
const dest=process.argv[2];if(!dest)throw Error('Kullanım: node kurulum/sunucuya-aktar.mjs ÖZEL_HEDEF_KLASÖR');
const c=loadConfig();if(!c.LICENSE_PRIVATE_PKCS8)throw Error('İmza anahtarı eksik; taşıma iptal edildi.');
const folder=resolve(dest);if(existsSync(folder))throw Error('Hedef önceden var; üzerine yazılmaz.');mkdirSync(join(folder,'data'),{recursive:true,mode:0o700});mkdirSync(join(folder,'secrets'),{mode:0o700});
const db=new DatabaseSync(c.DB_PATH,{readOnly:true});await backup(db,join(folder,'data/portal.sqlite'));db.close();
writeFileSync(join(folder,'secrets/portal.private.json'),JSON.stringify(Object.fromEntries(['LICENSE_PRIVATE_PKCS8','GMAIL_CLIENT_ID','GMAIL_CLIENT_SECRET','IYZICO_API_KEY','IYZICO_SECRET_KEY'].filter(k=>c[k]).map(k=>[k,c[k]]))),{mode:0o600,flag:'wx'});
console.log('Özel sunucu taşıma kopyası hazır. Anahtar içerikleri gösterilmedi. Bu klasörü GitHub veya genel ZIP paketine koymayın.');
