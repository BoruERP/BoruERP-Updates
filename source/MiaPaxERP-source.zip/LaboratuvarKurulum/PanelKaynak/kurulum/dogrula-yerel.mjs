import {DatabaseSync} from 'node:sqlite';
import {loadConfig} from '../src/config.js';
import {unseal} from '../src/legacy/mail.js';
import {hash} from '../src/legacy/index.js';
const c=loadConfig(),db=new DatabaseSync(c.DB_PATH,{readOnly:true});let verified=0;
for(const l of db.prepare('SELECT key_cipher,key_hash FROM licenses WHERE key_cipher IS NOT NULL').all()){const key=await unseal(c,l.key_cipher);if(key.length!==64||await hash(key)!==l.key_hash)throw Error('Taşınan anahtar özeti uyuşmuyor.');verified++;}
const check=db.prepare('PRAGMA integrity_check').get();if(check.integrity_check!=='ok')throw Error('SQLite bütünlük denetimi başarısız.');
db.close();console.log(JSON.stringify({encryptedLicenseKeysVerified:verified,databaseIntegrity:'ok',readOnly:true}));
