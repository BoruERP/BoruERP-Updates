import {DatabaseSync,backup} from 'node:sqlite';
import {mkdirSync,existsSync,writeFileSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {loadConfig} from '../src/config.js';
const c=loadConfig(),folder=resolve(process.env.BACKUP_DIR||'data/yedek');mkdirSync(folder,{recursive:true,mode:0o700});
const target=join(folder,'portal-'+new Date().toISOString().replace(/[:.]/g,'-')+'.sqlite');
const db=new DatabaseSync(c.DB_PATH,{readOnly:true});await backup(db,target);db.close();console.log('Tutarlı veritabanı yedeği oluşturuldu: '+target);
