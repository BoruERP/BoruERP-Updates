import {readFileSync,writeFileSync,unlinkSync} from 'node:fs';
import {join} from 'node:path';
import {spawnSync} from 'node:child_process';
import {createPrivateKey,createPublicKey} from 'node:crypto';
import {openDatabase,transaction} from '../src/database.js';
import {protect} from '../src/config.js';
const root=join(process.env.USERPROFILE,'MiapaxERP_GizliAnahtarlar'),folder=join(root,'BayiPaneli30');
const result=spawnSync('powershell.exe',['-NoProfile','-NonInteractive','-Command',"Add-Type -AssemblyName System.Security; $b=[IO.File]::ReadAllBytes((Join-Path $env:USERPROFILE 'MiapaxERP_GizliAnahtarlar\\license-v2-private.dpapi')); [Console]::Write([Convert]::ToBase64String([Security.Cryptography.ProtectedData]::Unprotect($b,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser)))"],{encoding:'utf8',windowsHide:true});
if(result.status!==0)throw Error('Mevcut imza anahtarı açılamadı.');
const secret=result.stdout.trim();const pk=createPrivateKey({key:Buffer.from(secret,'base64'),format:'der',type:'pkcs8'});
const actual=createPublicKey(pk).export({type:'spki',format:'der'}),expected=createPublicKey(readFileSync(join(root,'license-v2-public.pem'))).export({type:'spki',format:'der'});if(!actual.equals(expected))throw Error('Anahtarlar uyuşmuyor.');
const snapshotPath=join(folder,'snapshot.private.json'),data=JSON.parse(readFileSync(snapshotPath,'utf8'));const db=openDatabase(join(folder,'portal.sqlite'));
const protectedSecrets=protect(JSON.stringify({LICENSE_PRIVATE_PKCS8:secret}));
// A previous interrupted first import may have committed the identical snapshot.
if(!db.prepare('SELECT COUNT(*) n FROM customers').get().n)transaction(db,()=>{for(const table of ['customers','licenses','activations','audit','mail_settings']){if(db.prepare('SELECT COUNT(*) n FROM '+table).get().n)throw Error('Boş olmayan hedefe aktarma yapılmaz.');const {columns,rows}=data[table];for(const r of rows)db.prepare('INSERT INTO '+table+' ('+columns.join(',')+') VALUES ('+columns.map(()=>'?').join(',')+')').run(...(Array.isArray(r)?r:columns.map(k=>r[k])));}});
else for(const table of ['customers','licenses','activations','audit','mail_settings']){const {columns,rows}=data[table];if(db.prepare('SELECT COUNT(*) n FROM '+table).get().n!==rows.length)throw Error('Hedef değişmiş; aktarım durdu.');for(const row of rows){const values=Array.isArray(row)?row:columns.map(k=>row[k]);const saved=db.prepare('SELECT '+columns.join(',')+' FROM '+table+' WHERE '+columns[0]+'=?').get(values[0]);if(!saved||columns.some((k,i)=>saved[k]!==values[i]))throw Error('Hedef değişmiş; aktarım durdu.');}}
writeFileSync(join(folder,'secrets.dpapi'),protectedSecrets,{mode:0o600,flag:'wx'});
const counts=Object.fromEntries(['customers','licenses','activations'].map(t=>[t,db.prepare('SELECT COUNT(*) n FROM '+t).get().n]));db.close();unlinkSync(snapshotPath);console.log(JSON.stringify({ok:true,counts,signingKeyMatched:true,gmailCredentialsTransferred:false}));
