CREATE TABLE customers(id TEXT PRIMARY KEY,name TEXT NOT NULL,sector TEXT NOT NULL,contact TEXT NOT NULL DEFAULT '',notes TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1,revision INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL);
--> statement-breakpoint
CREATE TABLE licenses(id TEXT PRIMARY KEY,customer_id TEXT NOT NULL REFERENCES customers(id),key_hash TEXT NOT NULL UNIQUE,label TEXT NOT NULL,modules TEXT NOT NULL,max_devices INTEGER NOT NULL CHECK(max_devices BETWEEN 1 AND 1000),starts_at TEXT NOT NULL,expires_at TEXT,active INTEGER NOT NULL DEFAULT 1,revision INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL);
--> statement-breakpoint
CREATE TABLE activations(id TEXT PRIMARY KEY,license_id TEXT NOT NULL REFERENCES licenses(id),device_id TEXT NOT NULL,database_id TEXT NOT NULL,device_name TEXT NOT NULL,revoked INTEGER NOT NULL DEFAULT 0,first_seen TEXT NOT NULL,last_seen TEXT NOT NULL,UNIQUE(license_id,device_id,database_id));
--> statement-breakpoint
CREATE TABLE audit(id INTEGER PRIMARY KEY AUTOINCREMENT,at TEXT NOT NULL,actor TEXT NOT NULL,action TEXT NOT NULL,record_id TEXT NOT NULL,detail TEXT NOT NULL);
--> statement-breakpoint
CREATE TABLE rate_limits(bucket TEXT PRIMARY KEY,count INTEGER NOT NULL,expires_at INTEGER NOT NULL);
