ALTER TABLE customers ADD COLUMN email TEXT NOT NULL DEFAULT '';
ALTER TABLE licenses ADD COLUMN key_cipher TEXT;
ALTER TABLE licenses ADD COLUMN mail_status TEXT NOT NULL DEFAULT 'not_sent';
ALTER TABLE licenses ADD COLUMN mail_sent_at TEXT;
