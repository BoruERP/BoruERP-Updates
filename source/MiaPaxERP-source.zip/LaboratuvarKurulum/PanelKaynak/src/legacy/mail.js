const encoder=new TextEncoder();
const url64=b=>btoa(String.fromCharCode(...new Uint8Array(b))).replaceAll('+','-').replaceAll('/','_').replaceAll('=','');
const un64=s=>Uint8Array.from(atob(s.replaceAll('-','+').replaceAll('_','/')),c=>c.charCodeAt(0));
const nonce=()=>url64(crypto.getRandomValues(new Uint8Array(32)));
async function vault(env){if(!env.LICENSE_PRIVATE_PKCS8)throw Error('İmza ayarı eksik');return crypto.subtle.importKey('raw',await crypto.subtle.digest('SHA-256',encoder.encode('MiapaxERP-mail-v1:'+env.LICENSE_PRIVATE_PKCS8)),{name:'AES-GCM'},false,['encrypt','decrypt']);}
export async function seal(env,value){const iv=crypto.getRandomValues(new Uint8Array(12));return url64(iv)+'.'+url64(await crypto.subtle.encrypt({name:'AES-GCM',iv},await vault(env),encoder.encode(value)));}
export async function unseal(env,value){const [iv,data]=value.split('.');return new TextDecoder().decode(await crypto.subtle.decrypt({name:'AES-GCM',iv:un64(iv)},await vault(env),un64(data)));}
const setting=async(env,id)=>(await env.DB.prepare('SELECT value FROM mail_settings WHERE id=?').bind(id).first())?.value;
const put=(env,id,value)=>env.DB.prepare('INSERT INTO mail_settings(id,value) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET value=excluded.value').bind(id,value).run();
const redirect=url=>new Response(null,{status:303,headers:{location:url,'cache-control':'no-store'}});
async function token(env,values){const response=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:new URLSearchParams({client_id:env.GMAIL_CLIENT_ID,client_secret:env.GMAIL_CLIENT_SECRET,...values}),signal:AbortSignal.timeout(20000)});if(!response.ok)throw Object.assign(Error('Google bağlantısı tamamlanamadı; yeniden bağlayın.'),{status:502});return response.json();}
export async function gmailRoute(req,env,url,actor){
 const path=url.pathname;
 if(path==='/api/admin/gmail/status')return Response.json({configured:!!env.GMAIL_CLIENT_ID&&!!env.GMAIL_CLIENT_SECRET,connected:!!await setting(env,'refresh')},{headers:{'cache-control':'no-store'}});
 if(path==='/api/admin/gmail/start'&&req.method==='POST'){
  if(req.headers.get('origin')!==url.origin)throw Object.assign(Error('İstek kaynağı geçersiz.'),{status:403});
  if(!env.GMAIL_CLIENT_ID||!env.GMAIL_CLIENT_SECRET)throw Object.assign(Error('Google istemci ayarları eksik.'),{status:503});
  const state=nonce(),verifier=nonce();await env.DB.prepare('DELETE FROM oauth_requests WHERE expires<?').bind(Date.now()).run();await env.DB.prepare('INSERT INTO oauth_requests(state,actor,verifier,expires) VALUES(?,?,?,?)').bind(state,actor,verifier,Date.now()+600000).run();
  const query=new URLSearchParams({client_id:env.GMAIL_CLIENT_ID,redirect_uri:url.origin+'/api/admin/gmail/callback',response_type:'code',scope:'https://www.googleapis.com/auth/gmail.send',access_type:'offline',prompt:'consent',state,code_challenge:url64(await crypto.subtle.digest('SHA-256',encoder.encode(verifier))),code_challenge_method:'S256'});return redirect('https://accounts.google.com/o/oauth2/v2/auth?'+query);
 }
 if(path==='/api/admin/gmail/callback'&&req.method==='GET'){
  const state=url.searchParams.get('state')||'';const row=await env.DB.prepare('DELETE FROM oauth_requests WHERE state=? AND actor=? AND expires>? RETURNING verifier').bind(state,actor,Date.now()).first();if(!row||!url.searchParams.get('code'))throw Object.assign(Error('Google onayı iptal edildi veya süresi doldu. Yeniden bağlayın.'),{status:400});
  const data=await token(env,{code:url.searchParams.get('code'),code_verifier:row.verifier,redirect_uri:url.origin+'/api/admin/gmail/callback',grant_type:'authorization_code'});if(!data.refresh_token||!String(data.scope||'').split(' ').includes('https://www.googleapis.com/auth/gmail.send'))throw Object.assign(Error('Google gönderim izni vermedi.'),{status:400});await put(env,'refresh',await seal(env,data.refresh_token));return redirect('/?gmail=connected');
 }
 return new Response('Bulunamadı',{status:404});
}
export async function sendLicenseMail(env,to,key,company){
 const saved=await setting(env,'refresh');if(!saved)throw Error('Gmail henüz bağlanmadı.');
 if(!/^[^\s@<>\r\n]+@[^\s@<>\r\n]+\.[^\s@<>\r\n]+$/.test(to))throw Error('E-posta geçersiz.');
 const auth=await token(env,{refresh_token:await unseal(env,saved),grant_type:'refresh_token'});
 const content=company+'\n\nLisans anahtarınız: '+key+'\n\nLisans anahtarınızı saklayın ve başkalarıyla paylaşmayın. Programın Lisans / Etkinleştirme ekranına girin.';
 const raw=url64(encoder.encode('To: '+to+'\r\nSubject: =?UTF-8?B?'+btoa('MiapaxERP Lisans Bilgileri')+'?=\r\nMIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n'+btoa(String.fromCharCode(...encoder.encode(content)))));
 const response=await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send',{method:'POST',headers:{authorization:'Bearer '+auth.access_token,'content-type':'application/json'},body:JSON.stringify({raw}),signal:AbortSignal.timeout(20000)});if(!response.ok)throw Error('E-posta Google tarafından kabul edilmedi.');return (await response.json()).id;
}
