import {gmailRoute,seal,unseal,sendLicenseMail} from './mail.js';
import {panelPage,loginPage,setupPage} from './ui.js';
export const modules=[['STOK','Stok ve hareketler'],['URETIM','Reçete ve üretim'],['SATIS','Cari ve satış'],['FINANS','Muhasebe ve finans'],['SATINALMA','Satın alma'],['IK','İnsan kaynakları'],['CRM','CRM'],['ETICARET','E-ticaret'],['DISTICARET','Dış ticaret'],['KROKI','Sulama ve kroki'],['RESTORAN','Masa, adisyon ve mutfak'],['MOBIL','Mobil raporlar'],['LABORATUVAR','Laboratuvar ve kalite kontrol'],['RAPOR','Raporlar']];
export const sectors=[['BORU','Boru üretimi'],['YEDEK','Yedek parça'],['RESTORAN','Restoran'],['SUNGER','Sünger üretimi'],['GENEL','Genel işletme']];
const enc=new TextEncoder();
const fail=(message,status=400)=>{throw Object.assign(new Error(message),{status});};
const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'}});
export const hash=async v=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',enc.encode(v))),x=>x.toString(16).padStart(2,'0')).join('');
const random=()=>Array.from(crypto.getRandomValues(new Uint8Array(32)),x=>x.toString(16).padStart(2,'0')).join('');
const b64=v=>btoa(String.fromCharCode(...new Uint8Array(v)));
const from64=v=>Uint8Array.from(atob(v),x=>x.charCodeAt(0));
const text=(v,max,label)=>{if(typeof v!=='string'||!v.trim()||v.length>max||/[\x00-\x1f]/.test(v))fail(label+' geçersiz.');return v.trim();};
export function validModules(m){if(!Array.isArray(m)||!m.length||m.some(x=>!modules.some(a=>a[0]===x))||new Set(m).size!==m.length)fail('Modül seçimi geçersiz.');for(const [a,b]of [['LABORATUVAR','STOK'],['URETIM','STOK'],['RESTORAN','STOK'],['RESTORAN','URETIM'],['RESTORAN','SATIS'],['RESTORAN','FINANS']])if(m.includes(a)&&!m.includes(b))fail(a+' için '+b+' gerekli.');return m;}
function date(v,nullable=false){if(nullable&&(v===null||v===''))return null;const d=new Date(v);if(!Number.isFinite(d.valueOf()))fail('Tarih geçersiz.');return d.toISOString();}
async function body(req){if(Number(req.headers.get('content-length')||0)>32768)fail('İstek çok büyük.',413);const s=await req.text();if(s.length>32768)fail('İstek çok büyük.',413);try{return JSON.parse(s);}catch{fail('JSON gerekli.');}}
function admin(req,env){const id=req.headers.get('oai-authenticated-user-id');if(!id)fail('Oturum açın.',401);if(!env.ADMIN_USER_ID)fail('Yönetici hesabı henüz bağlanmadı.',503);if(id!==env.ADMIN_USER_ID)fail('Bu panel hesabınıza açık değil.',403);return id;}
const audit=(db,actor,action,id,detail='')=>db.prepare('INSERT INTO audit(at,actor,action,record_id,detail) SELECT ?,?,?,?,? WHERE changes()>0').bind(new Date().toISOString(),actor,action,id,detail);
async function limited(db,scope,limit){const window=Math.floor(Date.now()/60000),bucket=await hash(scope+':'+window);const r=await db.prepare('INSERT INTO rate_limits(bucket,count,expires_at) VALUES(?,1,?) ON CONFLICT(bucket) DO UPDATE SET count=count+1 RETURNING count').bind(bucket,window*60+180).first();if(r.count>limit)fail('İstek sınırı aşıldı. Bir dakika sonra deneyin.',429);if(Math.random()<.01)await db.prepare('DELETE FROM rate_limits WHERE expires_at<?').bind(Math.floor(Date.now()/1000)).run();}
export async function activate(req,env){
 const b=await body(req),key=text(b.licenseKey,100,'Lisans anahtarı'),device=text(b.deviceId,128,'Cihaz').toUpperCase(),database=text(b.databaseId,128,'Veritabanı').toUpperCase();
 if(!/^[A-F0-9]{64}$/.test(device)||!/^[A-F0-9]{64}$/.test(database))fail('Cihaz kimliği geçersiz.');
 await limited(env.DB,'ip:'+(req.headers.get('cf-connecting-ip')||'unknown'),30);const digest=await hash(key);await limited(env.DB,'key:'+digest,20);
 const now=new Date().toISOString();const query='SELECT l.*,c.name,c.sector,c.active AS customer_active,c.revision AS customer_revision FROM licenses l JOIN customers c ON c.id=l.customer_id';
 const l=await env.DB.prepare(query+' WHERE l.key_hash=?').bind(digest).first();
 if(!l||!l.active||!l.customer_active||l.starts_at>now||l.expires_at&&l.expires_at<=now)fail('Lisans bulunamadı, etkin değil veya süresi dolmuş.',403);
 if(!env.LICENSE_PRIVATE_PKCS8)fail('İmza servisi yapılandırılmamış.',503);
 const a=await env.DB.prepare('INSERT INTO activations(id,license_id,device_id,database_id,device_name,first_seen,last_seen) SELECT ?,?,?,?,?,?,? WHERE (SELECT COUNT(*) FROM activations WHERE license_id=? AND revoked=0)<(SELECT max_devices FROM licenses WHERE id=? AND active=1) ON CONFLICT(license_id,device_id,database_id) DO UPDATE SET last_seen=excluded.last_seen WHERE activations.revoked=0 RETURNING *').bind(crypto.randomUUID(),l.id,device,database,text(b.deviceName||'Müşteri bilgisayarı',80,'Cihaz adı'),now,now,l.id,l.id).first();
 let activation=a;if(!activation)activation=await env.DB.prepare('UPDATE activations SET last_seen=? WHERE license_id=? AND device_id=? AND database_id=? AND revoked=0 RETURNING *').bind(now,l.id,device,database).first();
 if(!activation)fail('Cihaz sınırına ulaşıldı veya cihaz iptal edildi.',403);
 const current=await env.DB.prepare(query+' WHERE l.id=?').bind(l.id).first();if(!current.active||!current.customer_active||current.starts_at>now||current.expires_at&&current.expires_at<=now)fail('Lisans etkin değil.',403);
 const until=new Date(Math.min(Date.now()+7*86400000,current.expires_at?Date.parse(current.expires_at):Infinity)).toISOString();
 const payload={schema:1,licenseId:current.id,customerId:current.customer_id,company:current.name,sector:current.sector,modules:validModules(JSON.parse(current.modules)),deviceId:device,databaseId:database,issuedAt:now,notBefore:current.starts_at,expiresAt:current.expires_at,validUntil:until,revision:current.revision+current.customer_revision};
 const bytes=enc.encode(JSON.stringify(payload));const pk=await crypto.subtle.importKey('pkcs8',from64(env.LICENSE_PRIVATE_PKCS8),{name:'RSA-PSS',hash:'SHA-256'},false,['sign']);
 return json({version:1,payload:b64(bytes),signature:b64(await crypto.subtle.sign({name:'RSA-PSS',saltLength:32},pk,bytes))});
}
async function deliverLicense(env,id){
 const l=await env.DB.prepare('SELECT l.key_cipher,l.key_hash,l.mail_status,c.email,c.name FROM licenses l JOIN customers c ON c.id=l.customer_id WHERE l.id=?').bind(id).first();
 if(!l?.key_cipher||!l.email)return 'E-posta veya saklanan anahtar eksik; müşteri bilgilerini güncelleyin.';
 if(l.mail_status==='sent')return 'Google gönderimi daha önce kabul etti.';
 const claim=await env.DB.prepare("UPDATE licenses SET mail_status='sending' WHERE id=? AND key_hash=? AND mail_status IN ('not_sent','failed') RETURNING id").bind(id,l.key_hash).first();if(!claim)return 'Gönderim sürüyor veya sonuç belirsiz; yinelenen gönderim yapılmadı.';
 try{await sendLicenseMail(env,l.email,await unseal(env,l.key_cipher),l.name);await env.DB.prepare("UPDATE licenses SET mail_status='sent',mail_sent_at=? WHERE id=? AND key_hash=?").bind(new Date().toISOString(),id,l.key_hash).run();return 'Google e-postayı göndermek üzere kabul etti. Teslim durumu alıcı posta kutusundan kontrol edilmelidir.';}
 catch{await env.DB.prepare("UPDATE licenses SET mail_status='failed' WHERE id=? AND key_hash=?").bind(id,l.key_hash).run();return 'E-posta gönderimi doğrulanamadı. Gmail bağlantısını kontrol edin; tekrar denemek yinelenen e-postaya yol açabilir.';}
}
async function handleAdmin(req,env,url){
 const actor=admin(req,env);if(url.pathname.startsWith('/api/admin/gmail/'))return gmailRoute(req,env,url,actor);if(req.method!=='GET'&&req.headers.get('origin')!==url.origin)fail('İstek kaynağı geçersiz.',403);
 if(url.pathname==='/api/admin/state'&&req.method==='GET'){
  const [c,l,a,h]=await env.DB.batch([env.DB.prepare('SELECT * FROM customers ORDER BY created_at DESC LIMIT 500'),env.DB.prepare('SELECT id,customer_id,label,modules,max_devices,starts_at,expires_at,active,revision,created_at,mail_status,mail_sent_at FROM licenses ORDER BY created_at DESC LIMIT 2000'),env.DB.prepare('SELECT * FROM activations ORDER BY last_seen DESC LIMIT 2000'),env.DB.prepare('SELECT * FROM audit ORDER BY id DESC LIMIT 100')]);
  return json({customers:c.results,licenses:l.results,activations:a.results,audit:h.results,modules,sectors});
 }
 if(req.method!=='POST')fail('İşlem bulunamadı.',404);const b=await body(req),now=new Date().toISOString();
 if(url.pathname==='/api/admin/customer'){
  const name=text(b.name,160,'Firma adı');if(!sectors.some(x=>x[0]===b.sector))fail('Sektör seçin.');
  const email=text(b.email,254,'E-posta');if(!/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(email))fail('E-posta geçersiz.');
  const contact=String(b.contact||'').slice(0,200),notes=String(b.notes||'').slice(0,1000);
  const tax={};for(const [k,max]of Object.entries({title:160,office:100,number:11,address:500,activity:200,startDate:10})){
   const value=b.tax?.[k]??'';if(typeof value!=='string'||value.length>max||/[\x00-\x1f]/.test(value))fail('Vergi bilgisi geçersiz: '+k);tax[k]=value.trim();
  }
  if(tax.number&&!/^\d{10,11}$/.test(tax.number))fail('VKN 10, TCKN 11 rakam olmalı.');
  if(tax.startDate&&(!/^\d{4}-\d{2}-\d{2}$/.test(tax.startDate)||(!Number.isFinite(Date.parse(tax.startDate))||new Date(tax.startDate).toISOString().slice(0,10)!==tax.startDate)))fail('İşe başlama tarihi geçersiz.');
  if(b.id){const r=await env.DB.batch([env.DB.prepare('UPDATE customers SET name=?,sector=?,contact=?,notes=?,tax_info=?,email=?,active=?,revision=revision+1 WHERE id=? AND revision=? RETURNING id').bind(name,b.sector,contact,notes,JSON.stringify(tax),email,b.active?1:0,b.id,b.revision),audit(env.DB,actor,'Müşteri güncellendi',b.id,name)]);if(!r[0].results.length)fail('Kayıt değişti; yenileyin.',409);return json({ok:true});}
  const i=b.initialLicense;if(!i)fail('İlk lisansın modül, süre ve cihaz bilgilerini seçin.');
  const m=validModules(i.modules),start=date(i.startsAt),end=date(i.expiresAt,true);
  if(end&&end<=start)fail('Bitiş başlangıçtan sonra olmalı.');if(!Number.isInteger(i.maxDevices)||i.maxDevices<1||i.maxDevices>1000)fail('Cihaz sınırı 1–1000 olmalı.');
  const id=crypto.randomUUID(),lid=crypto.randomUUID(),key=random();
  await env.DB.batch([
   env.DB.prepare('INSERT INTO customers(id,name,sector,contact,notes,tax_info,email,created_at) VALUES(?,?,?,?,?,?,?,?)').bind(id,name,b.sector,contact,notes,JSON.stringify(tax),email,now),
   audit(env.DB,actor,'Müşteri oluşturuldu',id,name),
   env.DB.prepare('INSERT INTO licenses(id,customer_id,key_hash,key_cipher,label,modules,max_devices,starts_at,expires_at,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)').bind(lid,id,await hash(key),await seal(env,key),'İlk müşteri lisansı',JSON.stringify(m),i.maxDevices,start,end,now),
   audit(env.DB,actor,'Otomatik lisans oluşturuldu',lid,'Müşteriyle birlikte oluşturuldu')
  ]);return json({ok:true,id,licenseId:lid,key,mail:await deliverLicense(env,lid)});
 }
 if(url.pathname==='/api/admin/license'){
  const label=text(b.label,100,'Lisans adı'),m=validModules(b.modules),start=date(b.startsAt),end=date(b.expiresAt,true);if(end&&end<=start)fail('Bitiş başlangıçtan sonra olmalı.');if(!Number.isInteger(b.maxDevices)||b.maxDevices<1||b.maxDevices>1000)fail('Cihaz sınırı 1–1000 olmalı.');
  if(!await env.DB.prepare('SELECT id FROM customers WHERE id=?').bind(b.customerId).first())fail('Müşteri seçin.');
  let key=null,id=b.id||crypto.randomUUID();
  if(b.id){const r=await env.DB.batch([env.DB.prepare('UPDATE licenses SET label=?,modules=?,max_devices=?,starts_at=?,expires_at=?,active=?,revision=revision+1 WHERE id=? AND customer_id=? AND revision=? AND (SELECT COUNT(*) FROM activations WHERE license_id=? AND revoked=0)<=? RETURNING id').bind(label,JSON.stringify(m),b.maxDevices,start,end,b.active?1:0,id,b.customerId,b.revision,id,b.maxDevices),audit(env.DB,actor,'Lisans güncellendi',id,JSON.stringify({modules:m,active:!!b.active,maxDevices:b.maxDevices,expiresAt:end}))]);if(!r[0].results.length)fail('Kayıt değişti veya cihaz sınırı mevcut cihaz sayısından düşük.',409);}
  else{key=random();await env.DB.batch([env.DB.prepare('INSERT INTO licenses(id,customer_id,key_hash,key_cipher,label,modules,max_devices,starts_at,expires_at,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)').bind(id,b.customerId,await hash(key),await seal(env,key),label,JSON.stringify(m),b.maxDevices,start,end,now),audit(env.DB,actor,'Lisans oluşturuldu',id,label)]);}
  return json({ok:true,key,id,...(key?{mail:await deliverLicense(env,id)}:{})});
 }
 if(url.pathname==='/api/admin/key'){
  const l=await env.DB.prepare('SELECT key_cipher FROM licenses WHERE id=?').bind(b.id).first();if(!l?.key_cipher)fail('Eski lisansın anahtarı geri okunamaz. Anahtar yenile işlemini kullanın.',409);
  await audit(env.DB,actor,'Lisans anahtarı görüntülendi',b.id).run();return json({key:await unseal(env,l.key_cipher)});
 }
 if(url.pathname==='/api/admin/send-mail')return json({mail:await deliverLicense(env,b.id)});
 if(url.pathname==='/api/admin/device'){

  const d=await env.DB.prepare('SELECT a.*,l.max_devices FROM activations a JOIN licenses l ON l.id=a.license_id WHERE a.id=?').bind(b.id).first();if(!d)fail('Cihaz bulunamadı.',404);
  const r=await env.DB.batch([env.DB.prepare('UPDATE activations SET revoked=? WHERE id=? AND (?=1 OR (SELECT COUNT(*) FROM activations WHERE license_id=? AND revoked=0)<? OR revoked=0) RETURNING id').bind(b.revoked?1:0,b.id,b.revoked?1:0,d.license_id,d.max_devices),audit(env.DB,actor,b.revoked?'Cihaz iptal edildi':'Cihaz açıldı',b.id)]);if(!r[0].results.length)fail('Cihaz sınırı dolu.',409);return json({ok:true});
 }
 if(url.pathname==='/api/admin/rotate'){
  const key=random();const r=await env.DB.batch([env.DB.prepare("UPDATE licenses SET key_hash=?,key_cipher=?,mail_status='not_sent',mail_sent_at=NULL,revision=revision+1 WHERE id=? AND revision=? RETURNING id").bind(await hash(key),await seal(env,key),b.id,b.revision),audit(env.DB,actor,'Lisans anahtarı yenilendi',b.id)]);if(!r[0].results.length)fail('Kayıt değişti.',409);return json({key,mail:await deliverLicense(env,b.id)});
 }
 fail('İşlem bulunamadı.',404);
}
export default {async fetch(req,env){const url=new URL(req.url);try{
 if(url.pathname==='/api/me')return json({userId:req.headers.get('oai-authenticated-user-id'),configured:!!env.ADMIN_USER_ID});
 if(url.pathname==='/api/activate'&&req.method==='POST')return await activate(req,env);
 if(url.pathname.startsWith('/api/admin/'))return await handleAdmin(req,env,url);
 if(url.pathname!=='/')return new Response('Bulunamadı',{status:404});
 const user=req.headers.get('oai-authenticated-user-id');let page;if(!user)page=loginPage;else if(!env.ADMIN_USER_ID)page=setupPage(user);else{admin(req,env);page=panelPage;}
 return new Response(page,{headers:{'content-type':'text/html; charset=utf-8','cache-control':'no-store','x-frame-options':'DENY','referrer-policy':'same-origin','content-security-policy':"default-src 'self'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self' https://accounts.google.com"}});
 }catch(e){return json({message:e.status?e.message:'İşlem tamamlanamadı. Daha sonra tekrar deneyin.'},e.status||500);}}};
