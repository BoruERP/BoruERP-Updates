import {randomBytes,createHmac,timingSafeEqual} from 'node:crypto';
import {reject} from './security.js';
export const INIT='/payment/iyzipos/checkoutform/initialize/auth/ecom';
export const RETRIEVE='/payment/iyzipos/checkoutform/auth/ecom/detail';
export function amount(kurus){if(!Number.isSafeInteger(kurus)||kurus<=0)reject('Tutar geçersiz.');return (kurus/100).toFixed(2);}
export function toKurus(v){const s=String(v);if(!/^\d{1,10}(\.\d{1,2})?$/.test(s))reject('Ödeme tutarı biçimi geçersiz.',502);const [a,b='']=s.split('.');return Number(a)*100+Number(b.padEnd(2,'0'));}
const canonical=v=>String(v).includes('.')?String(v).replace(/0+$/,'').replace(/\.$/,''):String(v);
export function responseSignature(secret,data,kind) {const fields=kind==='init'?['conversationId','token']:['paymentStatus','paymentId','currency','basketId','conversationId','paidPrice','price','token'];if(fields.some(k=>data[k]===undefined||data[k]===null))return '';return createHmac('sha256',secret).update(fields.map(k=>k==='price'||k==='paidPrice'?canonical(data[k]):String(data[k])).join(':')).digest('hex');}
export function verifySignature(secret,data,kind){const signature=responseSignature(secret,data,kind);if(!signature||typeof data.signature!=='string'||!/^[a-f0-9]{64}$/i.test(data.signature)||!timingSafeEqual(Buffer.from(signature,'hex'),Buffer.from(data.signature,'hex')))reject('Ödeme yanıtı doğrulanamadı.',502);}
export function enabled(config){return config.PAYMENTS_ENABLED==='true'&&!!config.IYZICO_API_KEY&&!!config.IYZICO_SECRET_KEY&&config.PAYMENT_ENV==='production'&&config.PUBLIC_ORIGIN?.startsWith('https://');}
export async function callProvider(config,path,data,transport=fetch) {
 const raw=JSON.stringify(data),rnd=randomBytes(24).toString('hex');
 const sig=createHmac('sha256',config.IYZICO_SECRET_KEY).update(rnd+path+raw).digest('hex');
 const authorization='IYZWSv2 '+Buffer.from(`apiKey:${config.IYZICO_API_KEY}&randomKey:${rnd}&signature:${sig}`).toString('base64');
 const base=config.PAYMENT_ENV==='production'?'https://api.iyzipay.com':'https://sandbox-api.iyzipay.com';
 const r=await transport(base+path,{method:'POST',headers:{authorization,'content-type':'application/json','x-iyzi-rnd':rnd},body:raw,signal:AbortSignal.timeout(20000)});
 if(!r.ok)reject('Ödeme kuruluşuna ulaşılamadı.',502);const result=await r.json();if(result.status!=='success')reject('Ödeme kuruluşu işlemi kabul etmedi.',502);verifySignature(config.IYZICO_SECRET_KEY,result,path===INIT?'init':'retrieve');return result;
}
export function approved(order,r){return r.status==='success'&&r.paymentStatus==='SUCCESS'&&r.fraudStatus===1&&r.token===order.token&&r.basketId===order.id&&r.conversationId===order.id&&r.currency==='TRY'&&typeof r.paymentId==='string'&&r.paymentId.length>0&&toKurus(r.price)===order.amount_kurus&&toKurus(r.paidPrice)===order.amount_kurus;}
export function checkoutBody(config,order,buyer,ip){
 for(const k of ['name','surname','identityNumber','email','gsmNumber','registrationAddress','city','country'])if(typeof buyer?.[k]!=='string'||!buyer[k].trim()||buyer[k].length>500)reject('Fatura/alıcı bilgisi eksik: '+k);
 if(!/^\d{11}$/.test(buyer.identityNumber)||!/^\+?[\d ]{10,18}$/.test(buyer.gsmNumber)||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(buyer.email))reject('Alıcı kimlik, telefon veya e-posta bilgisi geçersiz.');
 const snapshot=JSON.parse(order.snapshot),price=amount(order.amount_kurus);
 return {locale:'tr',conversationId:order.id,basketId:order.id,price,paidPrice:price,currency:'TRY',paymentGroup:'PRODUCT',callbackUrl:config.PUBLIC_ORIGIN+'/api/payment/callback',enabledInstallments:[1],buyer:{...Object.fromEntries(['name','surname','identityNumber','email','gsmNumber','registrationAddress','city','country'].map(k=>[k,buyer[k].trim()])),id:order.account_id,ip},billingAddress:{address:buyer.registrationAddress,contactName:buyer.name+' '+buyer.surname,city:buyer.city,country:buyer.country},basketItems:[{id:order.product_id,price,name:snapshot.name,category1:snapshot.categoryName,itemType:'VIRTUAL'}]};
}
