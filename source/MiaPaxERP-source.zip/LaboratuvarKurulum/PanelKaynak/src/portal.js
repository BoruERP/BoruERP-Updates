import legacy,{activate,modules,sectors,validModules,hash} from './legacy/index.js';
import {seal,unseal,sendLicenseMail} from './legacy/mail.js';
import {adapter,transaction} from './database.js';
import {token,digest,passwordHash,passwordMatches,passwordPolicy,reject,text,limited,audit} from './security.js';
import {enabled,callProvider,INIT,RETRIEVE,checkoutBody,approved} from './payment.js';
import {readFileSync} from 'node:fs';
const json=(data,status=200)=>Response.json(data,{status,headers:{'cache-control':'no-store'}});
const safeAccount=a=>({id:a.id,username:a.username,name:a.name,role:a.role,active:a.active,mustChange:!!a.must_change,settings:JSON.parse(a.settings)});
const safeLicense='l.id,l.customer_id,l.label,l.modules,l.max_devices,l.starts_at,l.expires_at,l.active,l.revision,l.created_at,l.mail_status,l.mail_sent_at';
const money=(v,label)=>{if(!Number.isSafeInteger(v)||v<=0||v>10000000000)reject(label+' pozitif kuruş tutarı olmalı.');return v;};
const taxFields={title:160,office:100,number:11,address:500,activity:200,startDate:10};
export async function createAccount(db,{username,name,role,password}) {
 username=text(username,100,'Kullanıcı adı').toLowerCase();if(!/^[a-z0-9_.@+-]{3,100}$/.test(username))reject('Kullanıcı adında Latin harf ve rakam kullanın.');
 const id=crypto.randomUUID(),ph=await passwordHash(password);db.prepare('INSERT INTO accounts(id,username,name,role,password_hash,created_at) VALUES(?,?,?,?,?,?)').run(id,username,text(name,160,'Ad'),role,ph,new Date().toISOString());return id;
}
export function seedCategories(db){for(const [id,name,n]of [['full','Tam Program',0],['entegrasyon','Entegrasyon',1],['hizli-satis','Hızlı Satış',2],['uretim','Üretim',3],['muhasebe','Muhasebe',4],['mobil','Mobil',5],['diger','Diğer Modüller',6]])db.prepare('INSERT OR IGNORE INTO categories VALUES(?,?,?)').run(id,name,n);}
export function completePayment(db,order,result) {
 if(!approved(order,result))reject('Ödeme onaylı değil veya sipariş bilgileri eşleşmiyor.',409);
 return transaction(db,()=>{
  const current=db.prepare('SELECT * FROM orders WHERE id=?').get(order.id);if(!current)reject('Sipariş bulunamadı.',404);
  if(current.status==='PAID'){if(current.payment_id!==result.paymentId)reject('Ödeme kimliği çakışıyor.',409);return db.prepare('SELECT id FROM entitlements WHERE order_id=?').get(order.id);}
  if(!['PENDING','REVIEW'].includes(current.status))reject('Sipariş ödeme beklemiyor.',409);
  db.prepare("UPDATE orders SET status='PAID',payment_id=?,provider_result=? WHERE id=?").run(result.paymentId,JSON.stringify({paymentId:result.paymentId,paymentStatus:result.paymentStatus,fraudStatus:result.fraudStatus,amount:result.paidPrice,transactions:(result.itemTransactions||[]).map(t=>({itemId:t.itemId,id:t.paymentTransactionId}))}),order.id);
  const id=crypto.randomUUID();db.prepare('INSERT INTO entitlements(id,order_id,account_id) VALUES(?,?,?)').run(id,order.id,order.account_id);audit(db,'iyzico','Ödeme doğrulandı',order.id);return {id};
 });
}
export function createPortal(db,config,{provider=callProvider,sendMail=sendLicenseMail}={}) {
 seedCategories(db);const env={...config,DB:adapter(db),ADMIN_USER_ID:'standalone-owner'};
 const secure=new URL(config.PUBLIC_ORIGIN).protocol==='https:',cookieName=secure?'__Host-berp':'berp-local';
 const cookie=(value,maxAge=28800)=>`${cookieName}=${value}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAge}${secure?'; Secure':''}`;
 const owner=a=>{if(a.role!=='OWNER')reject('Yönetici yetkisi gerekli.',403);};
 const scopedCustomer=(a,id)=>{const c=db.prepare('SELECT * FROM customers WHERE id=?').get(id);if(!c||(a.role!=='OWNER'&&c.dealer_id!==a.id))reject('Müşteri bulunamadı.',404);return c;};
 const scopedLicense=(a,id)=>{const l=db.prepare('SELECT l.*,c.dealer_id FROM licenses l JOIN customers c ON c.id=l.customer_id WHERE l.id=?').get(id);if(!l||(a.role!=='OWNER'&&l.dealer_id!==a.id))reject('Lisans bulunamadı.',404);return l;};
 async function mail(id){const l=db.prepare('SELECT l.*,c.email,c.name FROM licenses l JOIN customers c ON c.id=l.customer_id WHERE l.id=?').get(id);if(!l?.key_cipher)return 'Anahtar bulunamadı.';if(l.mail_status==='sent')return 'Daha önce gönderildi.';const claim=db.prepare("UPDATE licenses SET mail_status='sending' WHERE id=? AND mail_status IN ('not_sent','failed') RETURNING id").get(id);if(!claim)return 'Gönderim sürüyor veya sonucu belirsiz.';try{await sendMail(env,l.email,await unseal(env,l.key_cipher),l.name);db.prepare("UPDATE licenses SET mail_status='sent',mail_sent_at=? WHERE id=?").run(new Date().toISOString(),id);return 'E-posta gönderim servisi kabul etti.';}catch{db.prepare("UPDATE licenses SET mail_status='failed' WHERE id=?").run(id);return 'E-posta gönderilemedi. Gmail bağlantısını kontrol edin.';}}
 async function read(req){const raw=await req.text();if(raw.length>32768)reject('İstek çok büyük.',413);try{return JSON.parse(raw);}catch{reject('JSON gerekli.');}}
 async function route(req,ip) {
  const url=new URL(req.url),path=url.pathname;
  if(path==='/api/activate'&&req.method==='POST'){const h=new Headers(req.headers);h.set('cf-connecting-ip',ip);return activate(new Request(req,{headers:h}),env);}
  if(path==='/api/health')return json({ok:true,version:'3.0.0-rc.1'});
  if(path==='/api/catalog'&&req.method==='GET')return json({categories:db.prepare('SELECT * FROM categories ORDER BY sort,name').all(),products:db.prepare('SELECT id,category_id,name,description,modules,retail_kurus,term_days,max_devices,tax_note FROM products WHERE published=1 ORDER BY name').all()});
  if(path==='/api/payment/callback'&&req.method==='POST'){
   limited(db,'payment-callback:'+ip,40,60);if(!enabled(config))reject('Ödeme servisi devrede değil.',503);
   const form=new URLSearchParams(await req.text()),t=form.get('token');if(!t||t.length>1000)reject('Ödeme belirteci geçersiz.');const o=db.prepare('SELECT * FROM orders WHERE token=?').get(t);if(!o)reject('Sipariş bulunamadı.',404);
   if(o.status!=='PAID'){const r=await provider(config,RETRIEVE,{locale:'tr',conversationId:o.id,token:o.token});if(r.fraudStatus===0){db.prepare("UPDATE orders SET status='REVIEW' WHERE id=? AND status='PENDING'").run(o.id);return Response.redirect(config.PUBLIC_ORIGIN+'/?odeme=incelemede',303);}completePayment(db,o,r);}
   return Response.redirect(config.PUBLIC_ORIGIN+'/?odeme=tamam',303);
  }
  // Host headers and OpenAI identity headers are never authentication input.
  if(!['GET','HEAD'].includes(req.method)&&req.headers.get('origin')!==config.PUBLIC_ORIGIN)reject('İstek kaynağı geçersiz.',403);
  if(path==='/api/login'&&req.method==='POST'){
   limited(db,'login-ip:'+ip,30);const b=await read(req),username=String(b.username||'').toLowerCase();limited(db,'login-user:'+username,12);
   const a=db.prepare('SELECT * FROM accounts WHERE username=? COLLATE NOCASE').get(username);const valid=await passwordMatches(b.password,a?.password_hash);if(!valid||!a?.active)reject('Kullanıcı adı veya parola hatalı.',401);
   const t=token();db.prepare('DELETE FROM sessions WHERE expires<?').run(Date.now());db.prepare('INSERT INTO sessions VALUES(?,?,?)').run(digest(t),a.id,Date.now()+28800000);audit(db,a.id,'Oturum açıldı',a.id);return new Response(JSON.stringify({account:safeAccount(a)}),{headers:{'content-type':'application/json','set-cookie':cookie(t),'cache-control':'no-store'}});
  }
  if(path==='/api/logout'&&req.method==='POST'){const t=(req.headers.get('cookie')||'').split(';').map(s=>s.trim()).find(s=>s.startsWith(cookieName+'='))?.slice(cookieName.length+1);if(t)db.prepare('DELETE FROM sessions WHERE token_hash=?').run(digest(t));return new Response('{}',{headers:{'set-cookie':cookie('',0),'content-type':'application/json'}});}
  if(!path.startsWith('/api/')) {
   if(!['GET','HEAD'].includes(req.method))reject('Bulunamadı.',404);const files={'/':'index.html','/app.js':'app.js','/style.css':'style.css','/miapaxerp.png':'miapaxerp.png','/favicon.ico':'favicon.ico'};if(!files[path])reject('Bulunamadı.',404);return new Response(readFileSync(new URL('../public/'+files[path],import.meta.url)),{headers:{'content-type':path.endsWith('.png')?'image/png':path.endsWith('.ico')?'image/x-icon':path.endsWith('.js')?'text/javascript; charset=utf-8':path.endsWith('.css')?'text/css; charset=utf-8':'text/html; charset=utf-8'}});
  }
  const t=(req.headers.get('cookie')||'').split(';').map(s=>s.trim()).find(s=>s.startsWith(cookieName+'='))?.slice(cookieName.length+1);
  const a=t?db.prepare('SELECT a.* FROM sessions s JOIN accounts a ON a.id=s.account_id WHERE s.token_hash=? AND s.expires>? AND a.active=1').get(digest(t),Date.now()):null;if(!a)reject('Oturum açın.',401);
  if(path==='/api/me')return json({account:safeAccount(a),paymentsEnabled:enabled(config),licenseReady:!!config.LICENSE_PRIVATE_PKCS8});
  if(path==='/api/password'&&req.method==='POST'){
   limited(db,'password:'+a.id,8);const b=await read(req);if(!await passwordMatches(b.current,a.password_hash))reject('Mevcut parola hatalı.',403);passwordPolicy(b.next);if(b.next===b.current)reject('Yeni parola farklı olmalı.');const ph=await passwordHash(b.next);
   transaction(db,()=>{const r=db.prepare('UPDATE accounts SET password_hash=?,must_change=0 WHERE id=? AND password_hash=?').run(ph,a.id,a.password_hash);if(!r.changes)reject('Parola değişti. Yeniden oturum açın.',409);db.prepare('DELETE FROM sessions WHERE account_id=?').run(a.id);audit(db,a.id,'Parola değiştirildi',a.id);});return new Response(JSON.stringify({ok:true,relogin:true}),{headers:{'content-type':'application/json','set-cookie':cookie('',0)}});
  }
  if(a.must_change)reject('İlk girişte parolanızı değiştirin.',428);
  if(path==='/api/settings'&&req.method==='POST') {const b=await read(req),settings={shopName:text(b.shopName||a.name,160,'Mağaza adı'),phone:String(b.phone||'').slice(0,40),address:String(b.address||'').slice(0,500),description:String(b.description||'').slice(0,1000)};db.prepare('UPDATE accounts SET settings=? WHERE id=?').run(JSON.stringify(settings),a.id);audit(db,a.id,'Mağaza ayarları güncellendi',a.id);return json({ok:true});}
  if(path==='/api/state'&&req.method==='GET'){
   const own=a.role==='OWNER',w=own?'':' WHERE c.dealer_id=?',args=own?[]:[a.id];
   return json({account:safeAccount(a),modules,sectors,paymentsEnabled:enabled(config),licenseReady:!!config.LICENSE_PRIVATE_PKCS8,
    customers:db.prepare('SELECT c.*,a.name AS dealer_name FROM customers c LEFT JOIN accounts a ON a.id=c.dealer_id'+w+' ORDER BY c.created_at DESC LIMIT 2000').all(...args),
    licenses:db.prepare('SELECT '+safeLicense+' FROM licenses l JOIN customers c ON c.id=l.customer_id'+w+' ORDER BY l.created_at DESC LIMIT 5000').all(...args),
    activations:db.prepare('SELECT d.* FROM activations d JOIN licenses l ON l.id=d.license_id JOIN customers c ON c.id=l.customer_id'+w+' ORDER BY d.last_seen DESC LIMIT 5000').all(...args),
    dealers:own?db.prepare("SELECT id,username,name,role,active,settings,created_at FROM accounts WHERE role='DEALER' ORDER BY name").all():[],
    categories:db.prepare('SELECT * FROM categories ORDER BY sort,name').all(),products:db.prepare('SELECT * FROM products'+(own?'':' WHERE published=1')+' ORDER BY name').all(),
    orders:db.prepare('SELECT o.id,o.account_id,a.name AS account_name,o.product_id,o.snapshot,o.amount_kurus,o.currency,o.status,o.payment_id,o.created_at FROM orders o JOIN accounts a ON a.id=o.account_id'+(own?'':' WHERE o.account_id=?')+' ORDER BY o.created_at DESC LIMIT 2000').all(...args),
    entitlements:db.prepare('SELECT e.*,o.snapshot,a.name AS account_name FROM entitlements e JOIN orders o ON o.id=e.order_id JOIN accounts a ON a.id=e.account_id'+(own?'':' WHERE e.account_id=?')+' ORDER BY o.created_at DESC LIMIT 2000').all(...args),
    audit:own?db.prepare('SELECT h.*,a.name AS actor_name FROM audit h LEFT JOIN accounts a ON a.id=h.actor ORDER BY h.id DESC LIMIT 100').all():[]});
  }
  if(path==='/api/dealer'&&req.method==='POST'){
   owner(a);const b=await read(req);if(b.id){if(!db.prepare("SELECT id FROM accounts WHERE id=? AND role='DEALER'").get(b.id))reject('Bayi bulunamadı.',404);transaction(db,()=>{db.prepare("UPDATE accounts SET active=? WHERE id=? AND role='DEALER'").run(b.active?1:0,b.id);if(!b.active)db.prepare('DELETE FROM sessions WHERE account_id=?').run(b.id);audit(db,a.id,'Bayi erişimi değişti',b.id);});return json({ok:true});}
   const temporaryPassword=token(),id=await createAccount(db,{username:b.username,name:b.name,role:'DEALER',password:temporaryPassword});audit(db,a.id,'Bayi oluşturuldu',id);return json({id,username:b.username,temporaryPassword});
  }
  if(path==='/api/category'&&req.method==='POST'){owner(a);const b=await read(req),id=b.id||crypto.randomUUID();db.prepare('INSERT INTO categories VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,sort=excluded.sort').run(id,text(b.name,80,'Kategori'),Number.isInteger(b.sort)?b.sort:0);audit(db,a.id,'Kategori kaydedildi',id);return json({ok:true,id});}
  if(path==='/api/product'&&req.method==='POST'){
   owner(a);const b=await read(req),id=b.id||crypto.randomUUID(),m=validModules(b.modules);if(!db.prepare('SELECT id FROM categories WHERE id=?').get(b.categoryId))reject('Kategori seçin.');if(b.termDays!==null&&(!Number.isInteger(b.termDays)||b.termDays<1||b.termDays>36500))reject('Süre geçersiz.');if(!Number.isInteger(b.maxDevices)||b.maxDevices<1||b.maxDevices>1000)reject('Cihaz sınırı geçersiz.');
   const vals=[b.categoryId,text(b.name,160,'Ürün adı'),String(b.description||'').slice(0,3000),JSON.stringify(m),money(b.retailKurus,'Perakende'),money(b.dealerKurus,'Bayi'),b.termDays,b.maxDevices,b.published?1:0,text(b.taxNote,300,'Vergi/fatura açıklaması')];
   if(b.id){const r=db.prepare('UPDATE products SET category_id=?,name=?,description=?,modules=?,retail_kurus=?,dealer_kurus=?,term_days=?,max_devices=?,published=?,tax_note=?,revision=revision+1 WHERE id=? AND revision=?').run(...vals,id,b.revision);if(!r.changes)reject('Ürün değişti. Yenileyin.',409);}else db.prepare('INSERT INTO products(category_id,name,description,modules,retail_kurus,dealer_kurus,term_days,max_devices,published,tax_note,id,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)').run(...vals,id,new Date().toISOString());audit(db,a.id,'Ürün kaydedildi',id);return json({ok:true,id});
  }
  if(path==='/api/customer'&&req.method==='POST'){
   const b=await read(req),name=text(b.name,160,'Firma adı'),email=text(b.email,254,'E-posta');if(!/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(email))reject('E-posta geçersiz.');if(!sectors.some(s=>s[0]===b.sector))reject('Sektör seçin.');const tax={};for(const[k,max]of Object.entries(taxFields)){const v=b.tax?.[k]||'';if(typeof v!=='string'||v.length>max||/[\x00-\x1f]/.test(v))reject('Vergi bilgisi geçersiz.');tax[k]=v.trim();}if(tax.number&&!/^\d{10,11}$/.test(tax.number))reject('VKN 10, TCKN 11 rakam olmalı.');if(tax.startDate&&(!/^\d{4}-\d{2}-\d{2}$/.test(tax.startDate)||!Number.isFinite(Date.parse(tax.startDate))||new Date(tax.startDate).toISOString().slice(0,10)!==tax.startDate))reject('İşe başlama tarihi geçersiz.');
   const id=b.id||crypto.randomUUID();if(b.id)scopedCustomer(a,id);let dealer=a.role==='OWNER'?(b.dealerId||null):a.id;if(dealer&&!db.prepare("SELECT id FROM accounts WHERE id=? AND role='DEALER' AND active=1").get(dealer))reject('Etkin bayi seçin.');
   let initial=null;if(!b.id&&!dealer){owner(a);const i=b.initialLicense;if(!i)reject('İlk lisansın modül, süre ve cihaz bilgilerini seçin.');const m=validModules(i.modules);if(!Number.isInteger(i.maxDevices)||i.maxDevices<1||i.maxDevices>1000)reject('Cihaz sınırı geçersiz.');if(i.termDays!==null&&(!Number.isInteger(i.termDays)||i.termDays<1||i.termDays>36500))reject('Süre geçersiz.');const key=Array.from(crypto.getRandomValues(new Uint8Array(32)),x=>x.toString(16).padStart(2,'0')).join('');initial={id:crypto.randomUUID(),keyHash:await hash(key),cipher:await seal(env,key),modules:JSON.stringify(m),maxDevices:i.maxDevices,end:i.termDays?new Date(Date.now()+i.termDays*86400000).toISOString():null};}
   transaction(db,()=>{if(b.id){const r=db.prepare('UPDATE customers SET name=?,sector=?,email=?,contact=?,notes=?,tax_info=?,active=?,revision=revision+1 WHERE id=? AND revision=?').run(name,b.sector,email,String(b.contact||'').slice(0,200),String(b.notes||'').slice(0,1000),JSON.stringify(tax),b.active?1:0,id,b.revision);if(!r.changes)reject('Müşteri değişti. Yenileyin.',409);}else db.prepare('INSERT INTO customers(id,name,sector,email,contact,notes,tax_info,dealer_id,created_at) VALUES(?,?,?,?,?,?,?,?,?)').run(id,name,b.sector,email,String(b.contact||'').slice(0,200),String(b.notes||'').slice(0,1000),JSON.stringify(tax),dealer,new Date().toISOString());if(initial){const now=new Date().toISOString();db.prepare('INSERT INTO licenses(id,customer_id,key_hash,key_cipher,label,modules,max_devices,starts_at,expires_at,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)').run(initial.id,id,initial.keyHash,initial.cipher,'İlk müşteri lisansı',initial.modules,initial.maxDevices,now,initial.end,now);}audit(db,a.id,b.id?'Müşteri güncellendi':initial?'Müşteri ve lisans oluşturuldu':'Lisans bekleyen müşteri oluşturuldu',id);});return json({ok:true,id,licenseId:initial?.id,mail:initial?await mail(initial.id):undefined});
  }
  if(path==='/api/key'&&req.method==='POST'){const b=await read(req),l=scopedLicense(a,b.id);if(!l.key_cipher)reject('Eski anahtar saklanmamış.',409);audit(db,a.id,'Anahtar görüntülendi',l.id);return json({key:await unseal(env,l.key_cipher)});}
  if(path==='/api/send-mail'&&req.method==='POST'){const b=await read(req);scopedLicense(a,b.id);limited(db,'mail:'+a.id,10);return json({mail:await mail(b.id)});}
  if(path==='/api/order'&&req.method==='POST'){
   const b=await read(req),p=db.prepare('SELECT p.*,c.name AS categoryName FROM products p JOIN categories c ON c.id=p.category_id WHERE p.id=? AND p.published=1').get(b.productId);if(!p)reject('Ürün satışta değil.',404);if(!enabled(config))reject('Ödeme altyapısı henüz devrede değil. Sipariş ve tahsilat yapılmadı.',503);limited(db,'order:'+a.id,10);
   const id=crypto.randomUUID(),o={id,account_id:a.id,product_id:p.id,snapshot:JSON.stringify(p),amount_kurus:a.role==='DEALER'?p.dealer_kurus:p.retail_kurus};const body=checkoutBody(config,o,b.buyer,ip);
   db.prepare("INSERT INTO orders(id,account_id,product_id,snapshot,amount_kurus,status,created_at) VALUES(?,?,?,?,?,'CREATED',?)").run(id,a.id,p.id,o.snapshot,o.amount_kurus,new Date().toISOString());
   try{const r=await provider(config,INIT,body);if(r.conversationId!==id||!r.token||typeof r.paymentPageUrl!=='string')reject('Ödeme bağlantısı doğrulanamadı.',502);const pu=new URL(r.paymentPageUrl);if(pu.protocol!=='https:'||!(pu.hostname==='iyzipay.com'||pu.hostname.endsWith('.iyzipay.com')))reject('Ödeme bağlantısı geçersiz.',502);db.prepare("UPDATE orders SET token=?,status='PENDING' WHERE id=? AND status='CREATED'").run(r.token,id);audit(db,a.id,'Ödeme başlatıldı',id);return json({id,url:r.paymentPageUrl});}catch(e){db.prepare("UPDATE orders SET status='FAILED' WHERE id=? AND status='CREATED'").run(id);throw e;}
  }
  if(path==='/api/assign'&&req.method==='POST'){
   const b=await read(req),e=db.prepare('SELECT e.*,o.snapshot,o.status FROM entitlements e JOIN orders o ON o.id=e.order_id WHERE e.id=?').get(b.entitlementId);if(!e||(a.role!=='OWNER'&&e.account_id!==a.id))reject('Lisans hakkı bulunamadı.',404);const c=scopedCustomer(a,b.customerId);if(!c.active)reject('Müşteri etkin değil.');const account=db.prepare('SELECT role FROM accounts WHERE id=?').get(e.account_id);if(account.role==='DEALER'&&c.dealer_id!==e.account_id)reject('Hak yalnız satın alan bayinin müşterisine atanabilir.',403);if(e.status!=='PAID')reject('Ödeme onaylı değil.',409);
   if(e.license_id){if(e.customer_id!==c.id)reject('Hak başka müşteriye atanmış.',409);return json({ok:true,id:e.license_id,alreadyAssigned:true});}
   const p=JSON.parse(e.snapshot),key=Array.from(crypto.getRandomValues(new Uint8Array(32)),x=>x.toString(16).padStart(2,'0')).join(''),id=crypto.randomUUID(),now=new Date().toISOString(),end=p.term_days?new Date(Date.now()+p.term_days*86400000).toISOString():null,cipher=await seal(env,key),kh=await hash(key);if(b.resaleKurus!==null&&b.resaleKurus!==undefined)money(b.resaleKurus,'Satış');
   const result=transaction(db,()=>{const cur=db.prepare('SELECT * FROM entitlements WHERE id=?').get(e.id);if(cur.license_id){if(cur.customer_id!==c.id)reject('Hak başka müşteriye atanmış.',409);return {id:cur.license_id,alreadyAssigned:true};}db.prepare('INSERT INTO licenses(id,customer_id,key_hash,key_cipher,label,modules,max_devices,starts_at,expires_at,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)').run(id,c.id,kh,cipher,p.name,p.modules,p.max_devices,now,end,now);db.prepare('UPDATE entitlements SET license_id=?,customer_id=?,resale_kurus=?,assigned_at=? WHERE id=? AND license_id IS NULL').run(id,c.id,b.resaleKurus??null,now,e.id);audit(db,a.id,'Satın alınan lisans atandı',id,e.id);return {id};});return json({ok:true,...result,mail:result.alreadyAssigned?undefined:await mail(id)});
  }
  if(path.startsWith('/api/admin/')){
   owner(a);const allowed=['license','device','rotate','gmail/status','gmail/start','gmail/callback'];if(!allowed.includes(path.slice('/api/admin/'.length)))reject('İşlem bulunamadı.',404);
   const h=new Headers(req.headers);h.delete('oai-authenticated-user-id');h.delete('oai-authenticated-user-email');h.set('oai-authenticated-user-id',env.ADMIN_USER_ID);audit(db,a.id,'Yönetici lisans işlemi',path);return legacy.fetch(new Request(req,{headers:h}),env);
  }
  reject('İşlem bulunamadı.',404);
 }
 return async function handle(req,ip='127.0.0.1') {try{const r=await route(req,ip);const h=new Headers(r.headers);h.set('x-content-type-options','nosniff');h.set('x-frame-options','DENY');h.set('referrer-policy','same-origin');h.set('cache-control','no-store');h.set('content-security-policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self' https://accounts.google.com");if(secure)h.set('strict-transport-security','max-age=31536000');return new Response(r.body,{status:r.status,headers:h});}catch(e){if(!e.status)console.error('Portal request failed:',e.code||e.name);return json({message:e.status?e.message:'İşlem tamamlanamadı. Sunucu günlüğünü kontrol edin.'},e.status||500);}};
}
