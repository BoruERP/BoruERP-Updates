import {readFileSync,writeFileSync,mkdirSync,existsSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {openDatabase} from './database.js';
import {createAccount,seedCategories} from './portal.js';
import {token} from './security.js';
import {protect} from './config.js';
// Setup reads private input from stdin. No passwords or keys in shell arguments.
let raw='';for await(const c of process.stdin)raw+=c;const input=raw.trim()?JSON.parse(raw):{};
const root=resolve(process.env.PORTAL_PRIVATE_DIR||'data'),dbPath=resolve(process.env.DB_PATH||root+'/portal.sqlite');mkdirSync(root,{recursive:true,mode:0o700});
const db=openDatabase(dbPath);if(db.prepare("SELECT id FROM accounts WHERE role='OWNER'").get())throw Error('Yönetici zaten var; mevcut parola veya veriler değiştirilmedi.');
if(input.snapshot){const tables=['customers','licenses','activations','audit','mail_settings'];db.exec('BEGIN IMMEDIATE');try{for(const table of tables){if(db.prepare('SELECT COUNT(*) n FROM '+table).get().n)throw Error('Boş olmayan veritabanına aktarım yapılmaz.');const {rows,columns}=input.snapshot[table];for(const row of rows){const values=Array.isArray(row)?row:columns.map(k=>row[k]);db.prepare('INSERT INTO '+table+' ('+columns.join(',')+') VALUES ('+columns.map(()=>'?').join(',')+')').run(...values);}}db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}}
const password=input.password||token(),username=input.username||'yonetici';await createAccount(db,{username,name:input.name||'MiapaxERP Yönetici',role:'OWNER',password});seedCategories(db);
const secretPath=resolve(root,process.platform==='win32'?'secrets.dpapi':'secrets.private.json');
if(input.secrets){const value=JSON.stringify(input.secrets);writeFileSync(secretPath,process.platform==='win32'?protect(value):value,{mode:0o600,flag:'wx'});}
const credentials=resolve(root,'ilk-giris.txt');writeFileSync(credentials,`MiapaxERP bağımsız panel — yalnız size özel\nAdres: http://127.0.0.1:5290\nKullanıcı: ${username}\nGeçici parola: ${password}\nİlk girişte parola değişimi zorunludur. Değiştirdikten sonra bu dosyayı silin.\nVeritabanı: ${dbPath}\n${input.snapshot?'Eski panelin salt okunur anlık kopyası alındı. Canlı lisans adresi değiştirilmedi.':''}\n`,{mode:0o600,flag:'wx'});
db.close();console.log(JSON.stringify({ok:true,dbPath,secretPath:input.secrets?secretPath:null,credentials}));
