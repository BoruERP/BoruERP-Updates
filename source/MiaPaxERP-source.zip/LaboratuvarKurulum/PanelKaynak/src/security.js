import { randomBytes,createHash,pbkdf2,timingSafeEqual } from 'node:crypto';
import {promisify} from 'node:util';
const derive=promisify(pbkdf2);
export const token=()=>randomBytes(32).toString('base64url');
export const digest=s=>createHash('sha256').update(s).digest('hex');
export const reject=(message,status=400)=>{throw Object.assign(Error(message),{status});};
export function text(v,max,label) {if(typeof v!=='string'||!v.trim()||v.length>max||/[\x00-\x1f]/.test(v))reject(label+' geçersiz.');return v.trim();}
export function passwordPolicy(s){if(typeof s!=='string'||s.length<14||s.length>128)reject('Parola 14–128 karakter olmalı.');return s;}
export async function passwordHash(s){passwordPolicy(s);const salt=randomBytes(24).toString('hex');return `pbkdf2:600000:${salt}:${(await derive(s,salt,600000,32,'sha256')).toString('hex')}`;}
const dummy='pbkdf2:600000:000000000000000000000000000000000000000000000000:0000000000000000000000000000000000000000000000000000000000000000';
export async function passwordMatches(s,hash=dummy){if(typeof s!=='string'||s.length>128)return false;const [alg,count,salt,key]=hash.split(':');if(alg!=='pbkdf2'||count!=='600000'||!salt||!key)return false;const actual=await derive(s,salt,600000,32,'sha256');const expected=Buffer.from(key,'hex');return actual.length===expected.length&&timingSafeEqual(actual,expected);}
export function limited(db,scope,limit,seconds=600) {const now=Math.floor(Date.now()/1000),bucket=digest(scope+':'+Math.floor(now/seconds));const r=db.prepare('INSERT INTO auth_limits VALUES(?,1,?) ON CONFLICT(bucket) DO UPDATE SET count=count+1 RETURNING count').get(bucket,now+seconds);if(r.count>limit)reject('Çok sayıda deneme. Daha sonra tekrar deneyin.',429);db.prepare('DELETE FROM auth_limits WHERE expires<?').run(now);}
export const audit=(db,actor,action,id,detail='')=>db.prepare('INSERT INTO audit(at,actor,action,record_id,detail) VALUES(?,?,?,?,?)').run(new Date().toISOString(),actor,action,id,detail);
