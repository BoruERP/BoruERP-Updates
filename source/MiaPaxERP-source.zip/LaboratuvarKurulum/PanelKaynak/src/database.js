import { DatabaseSync } from 'node:sqlite';
import { readFileSync, mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
const migration = new URL('./legacy/migrations/', import.meta.url);
export function openDatabase(path) {
 if(path!==':memory:') mkdirSync(dirname(path),{recursive:true,mode:0o700});
 const db=new DatabaseSync(path); db.exec('PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;');
 db.exec('CREATE TABLE IF NOT EXISTS portal_migrations(id TEXT PRIMARY KEY)');
 for(const name of ['0000_license.sql','0001_customer_tax.sql','0002_mail.sql','0003_customer_mail.sql']) {
  if(!db.prepare('SELECT id FROM portal_migrations WHERE id=?').get(name)) transaction(db,()=>{db.exec(readFileSync(new URL(name,migration),'utf8'));db.prepare('INSERT INTO portal_migrations VALUES(?)').run(name);});
 }
 if(!db.prepare('SELECT id FROM portal_migrations WHERE id=?').get('portal-v1')) transaction(db,()=>{
 db.exec(`
 CREATE TABLE accounts(id TEXT PRIMARY KEY,username TEXT NOT NULL UNIQUE COLLATE NOCASE,name TEXT NOT NULL,role TEXT NOT NULL CHECK(role IN ('OWNER','DEALER')),password_hash TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,must_change INTEGER NOT NULL DEFAULT 1,settings TEXT NOT NULL DEFAULT '{}',created_at TEXT NOT NULL);
 CREATE UNIQUE INDEX single_owner ON accounts(role) WHERE role='OWNER';
 ALTER TABLE customers ADD COLUMN dealer_id TEXT REFERENCES accounts(id);
 CREATE INDEX customer_dealer ON customers(dealer_id);
 CREATE TABLE sessions(token_hash TEXT PRIMARY KEY,account_id TEXT NOT NULL REFERENCES accounts(id),expires INTEGER NOT NULL);
 CREATE TABLE auth_limits(bucket TEXT PRIMARY KEY,count INTEGER NOT NULL,expires INTEGER NOT NULL);
 CREATE TABLE categories(id TEXT PRIMARY KEY,name TEXT NOT NULL UNIQUE,sort INTEGER NOT NULL DEFAULT 0);
 CREATE TABLE products(id TEXT PRIMARY KEY,category_id TEXT NOT NULL REFERENCES categories(id),name TEXT NOT NULL,description TEXT NOT NULL DEFAULT '',modules TEXT NOT NULL,retail_kurus INTEGER NOT NULL CHECK(retail_kurus>0),dealer_kurus INTEGER NOT NULL CHECK(dealer_kurus>0),term_days INTEGER CHECK(term_days BETWEEN 1 AND 36500),max_devices INTEGER NOT NULL CHECK(max_devices BETWEEN 1 AND 1000),published INTEGER NOT NULL DEFAULT 0,revision INTEGER NOT NULL DEFAULT 1,tax_note TEXT NOT NULL,created_at TEXT NOT NULL);
 CREATE TABLE orders(id TEXT PRIMARY KEY,account_id TEXT NOT NULL REFERENCES accounts(id),product_id TEXT NOT NULL REFERENCES products(id),snapshot TEXT NOT NULL,amount_kurus INTEGER NOT NULL CHECK(amount_kurus>0),currency TEXT NOT NULL DEFAULT 'TRY',status TEXT NOT NULL CHECK(status IN ('CREATED','PENDING','PAID','REVIEW','FAILED')),token TEXT UNIQUE,payment_id TEXT UNIQUE,provider_result TEXT,created_at TEXT NOT NULL);
 CREATE TABLE entitlements(id TEXT PRIMARY KEY,order_id TEXT NOT NULL UNIQUE REFERENCES orders(id),account_id TEXT NOT NULL REFERENCES accounts(id),license_id TEXT UNIQUE REFERENCES licenses(id),customer_id TEXT REFERENCES customers(id),resale_kurus INTEGER,assigned_at TEXT);
 CREATE TABLE portal_settings(id TEXT PRIMARY KEY,value TEXT NOT NULL);
 INSERT INTO portal_migrations VALUES('portal-v1');`);
 });
 return db;
}
export function transaction(db,work) {db.exec('BEGIN IMMEDIATE');try{const value=work();if(value?.then)throw Error('Async transaction is forbidden');db.exec('COMMIT');return value;}catch(e){db.exec('ROLLBACK');throw e;}}
export function adapter(db) {
 const prepare=(sql)=>{let args=[];const p={bind(...v){args=v;return p;},async first(){return db.prepare(sql).get(...args)||null;},async all(){return {results:db.prepare(sql).all(...args),success:true};},async run(){const r=db.prepare(sql).run(...args);return {success:true,meta:{changes:Number(r.changes)}};},_exec(){const s=db.prepare(sql);return {results:s.columns().length?s.all(...args):[],...(!s.columns().length?{meta:s.run(...args)}:{}),success:true};}};return p;};
 return {prepare,async batch(items){return transaction(db,()=>items.map(x=>x._exec()));}};
}
