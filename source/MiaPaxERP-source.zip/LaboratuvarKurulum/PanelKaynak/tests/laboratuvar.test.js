import test from 'node:test';
import assert from 'node:assert/strict';
import {modules,validModules} from '../src/legacy/index.js';
test('laboratory module listed exactly once',()=>assert.equal(modules.filter(x=>x[0]==='LABORATUVAR').length,1));
test('laboratory requires stock',()=>assert.throws(()=>validModules(['LABORATUVAR'])));
test('laboratory stock combination allowed',()=>assert.deepEqual(validModules(['LABORATUVAR','STOK']),['LABORATUVAR','STOK']));
