# MiapaxERP bağımsız bayi ve lisans paneli · 3.0 RC1

Kendi sunucusunda çalışan Node.js 24 uygulaması. ChatGPT hesabına veya Sites kimlik başlıklarına ihtiyaç duymaz. Yönetici ve bayi girişleri, parola değişimi, müşteri/vergi bilgileri, lisanslar, kategori ve fiyat yönetimi, iyzico Checkout Form ve lisans hakkı ataması içerir.

Kurulum ve mevcut panelden geçiş: [kurulum/KILAVUZ.txt](kurulum/KILAVUZ.txt).

Yerel hazırlanmış panel: `http://127.0.0.1:5290`. Dışarıdan erişim için alan adı ve HTTPS sunucusu henüz sağlanmadı. Ödemeler varsayılan olarak kapalıdır. Genel paket hiçbir müşteri verisi, gerçek lisans anahtarı, yönetici parolası veya özel imza anahtarı içermez.

`node --test --test-concurrency=1 tests/portal.test.js` ile 29 sunucu testi; UI testleri ayrı geçici veritabanında yapılır. `tests/preview-fixture.mjs` yalnız sahte test verisi oluşturur, canlı veriyle kullanılmaz. Docker/HTTPS kurulumu ve iyzico sandbox/üretim hesabıyla uçtan uca test bu ortamda yapılamadı.

Mevcut RSA-PSS aktivasyon sözleşmesi ve 7 günlük çevrim dışı belge korunur. Masaüstü 2.3 RC1 Mağaza ekranı, bu panelin `/api/catalog` adresine bağlanır. Varsayılan eski lisans doğrulama adresi, son veri taşıma ve kontrollü pilot tamamlanana kadar değişmez.

Bu RC tek uygulama süreci/SQLite veritabanı kullanır. Panel listeleri istekte 2.000 müşteri, 5.000 lisans/cihaz ve 2.000 siparişle sınırlıdır; daha büyük kurulumda sayfalama ve yük testi tamamlanmalıdır. İade/chargeback uzlaştırması otomatik değildir. Bu sınırlamalar nedeniyle genel satışa hazır olduğuna dair bir beyan değildir.
