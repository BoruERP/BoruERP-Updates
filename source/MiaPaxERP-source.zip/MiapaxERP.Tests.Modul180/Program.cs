using System.Data;
using System.IO;
using System.Reflection;
using System.Text.Json;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using MiapaxERP.Desktop;
using Microsoft.Data.SqlClient;
class Program
{
 static int checks;static readonly List<string> results=new();
 static void Check(string label,bool ok){if(!ok)throw new Exception(label);checks++;results.Add("PASS "+label);Console.WriteLine("PASS "+label);}
 static void Reject(string label,Action a){try{a();}catch(InvalidDataException){Check(label,true);return;}catch(ArgumentException){Check(label,true);return;}catch(InvalidOperationException){Check(label,true);return;}catch(UnauthorizedAccessException){Check(label,true);return;}catch(SqlException){Check(label,true);return;}throw new Exception("Rejected expected: "+label);}
 static void Sql(SqlConnection c,string text){using var q=new SqlCommand(text,c){CommandTimeout=90};q.ExecuteNonQuery();}
 static object Scalar(SqlConnection c,string text){using var q=new SqlCommand(text,c);return q.ExecuteScalar()!;}
 [STAThread]static int Main()
 {
  string name="MiapaxERP_Test180_"+Guid.NewGuid().ToString("N");SqlConnection? master=null;string output=Path.Combine(AppContext.BaseDirectory,"Sonuclar");Directory.CreateDirectory(output);
  try{
   var prefs=new GorunumTercihleri{FirmaBasligi="  Örnek Fabrika  "};prefs.Dogrula();Check("Firma başlığı temizlenir",prefs.FirmaBasligi=="Örnek Fabrika");GorunumDeposu.Kaydet(Path.Combine(output,"Gorunum"),prefs);Check("Firma başlığı yeniden açılır",GorunumDeposu.Oku(Path.Combine(output,"Gorunum")).FirmaBasligi==prefs.FirmaBasligi);
   Reject("Firma adı uzunluk sınırı",()=>new GorunumTercihleri{FirmaBasligi=new string('a',61)}.Dogrula());
   var item=new TicaretKalem("P1","Boru",3,100,10,20,"METRE");Check("İndirim vergi ve toplam",item.Net()==270&&item.Vergi()==54&&item.Toplam()==324);Reject("Negatif vergi",()=>new TicaretKalem("","X",1,1,0,-1).Toplam());
   Check("Tamamlanan e-ticarette iade",IsAkisi.Getir("ECOM").Sonrakiler("Tamamlandı").Contains("İade edildi"));
   Reject("Kargo zorunlu alanları",()=>TicaretDosyalari.GecisDogrula("ECOM","Kargoda",new()));
   Reject("Gümrük beyanname kontrolü",()=>TicaretDosyalari.GecisDogrula("TRADE","Gümrük",new()));
   Reject("İK gün miktarı sınırı",()=>ErpModulServisi.IKDogrula("Yıllık İzin",DateTime.Today,DateTime.Today,2));
   Connectors();
   var builder=new SqlConnectionStringBuilder("Server=(localdb)\\MSSQLLocalDB;Integrated Security=true;TrustServerCertificate=true;Pooling=false"){InitialCatalog="master",ConnectTimeout=10};master=new SqlConnection(builder.ConnectionString);master.Open();Sql(master,$"CREATE DATABASE [{name}]");builder.InitialCatalog=name;string cs=builder.ConnectionString;
   using(var db=new SqlConnection(cs)){db.Open();Sql(db,"""
    CREATE TABLE dbo.Kullanicilar(Id int PRIMARY KEY,Aktif bit);INSERT dbo.Kullanicilar VALUES(1,1),(2,0),(3,1);
    CREATE TABLE dbo.KullaniciRolleri(Id int PRIMARY KEY,RolAdi nvarchar(100),Aktif bit);INSERT dbo.KullaniciRolleri VALUES(1,N'Yönetici',1);
    CREATE TABLE dbo.KullaniciRolAtamalari(KullaniciId int,RolId int);INSERT dbo.KullaniciRolAtamalari VALUES(1,1),(2,1);
    CREATE TABLE dbo.TestYetki(KullaniciId int,YetkiKodu nvarchar(100),Yetkili bit);
    CREATE TABLE dbo.Yetkiler(YetkiKodu nvarchar(100) PRIMARY KEY,Modul nvarchar(100),Islem nvarchar(100),Aciklama nvarchar(200),Aktif bit);
    CREATE TABLE dbo.StokKartlari(Id int PRIMARY KEY,StokKodu nvarchar(50),StokAdi nvarchar(100),Aktif bit,Birim nvarchar(20));
    CREATE TABLE dbo.StokHareketleri(Id bigint IDENTITY PRIMARY KEY,StokKartId int,HareketTipi nvarchar(40),Yon nvarchar(1),Miktar decimal(18,3),Birim nvarchar(20),Aciklama nvarchar(500));
    CREATE TABLE dbo.StokBakiyeleri(StokKartId int PRIMARY KEY,Birim nvarchar(20),Miktar decimal(18,3),SonGuncelleme datetime2);
    """);Sql(db,"CREATE VIEW dbo.vw_KullaniciEtkinYetkileri AS SELECT KullaniciId,YetkiKodu,Yetkili FROM dbo.TestYetki");}
   ModulKurulumu180.Hazirla(cs,1);ModulKurulumu180.Hazirla(cs,1);Check("Sıfırdan şema ve tekrar kurulum",true);
   using var sql=new SqlConnection(cs);sql.Open();foreach(var file in new[]{"Moduller160.sql","Ticaret170.sql","Moduller180.sql"})Sql(sql,File.ReadAllText(Path.Combine(AppContext.BaseDirectory,file)));Check("SQL migration tekrar çalışır",Convert.ToInt32(Scalar(sql,"SELECT COUNT(*) FROM dbo.BERP_Sema WHERE Surum=180"))==1);
   Sql(sql,"DELETE dbo.BERP_Sema WHERE Surum=181; ALTER TABLE dbo.BERP_TicaretDosya DROP CONSTRAINT CK_BERP_Modul181; ALTER TABLE dbo.BERP_TicaretDosya ADD CONSTRAINT CK_TestEskiModul CHECK(Modul IN('CRM','ECOM','TRADE'));");
   ModulKurulumu180.Hazirla(cs,1);Check("180 kayıtlı eski kısıt 181 yükseltmesinde onarılır",Convert.ToInt32(Scalar(sql,"SELECT COUNT(*) FROM dbo.BERP_Sema WHERE Surum=181"))==1);
   foreach(string module in new[]{"SALES","PURCHASE","ECOM","TRADE","CRM"})
   {
    var svc=new TicaretDosyalari(cs,1,module);var g=new TicaretGirdi("TEST-"+module,svc.Akis.Turler[0],"Test şirketi","Test belge","Test",DateTime.Today,DateTime.Today.AddDays(7),324,"TRY",new(){["Kalemler"]=JsonSerializer.Serialize(new[]{item})},"");long id=svc.Kaydet(g);Check(module+" kayıt kalemleri",svc.Liste().Rows.Count==1);
    var r=svc.Liste().Rows[0];svc.Kaydet(g with{Baslik="Yeni konu"},id,(byte[])r["Surum"]);Reject(module+" eski sürüm reddi",()=>svc.Kaydet(g,id,(byte[])r["Surum"]));Reject(module+" mükerrer referans",()=>svc.Kaydet(g));
    Reject(module+" yetkisiz görüntüleme",()=>new TicaretDosyalari(cs,3,module).Liste());Reject(module+" pasif yönetici",()=>new TicaretDosyalari(cs,2,module).Kaydet(g));
    if(module!="CRM"){
     Guid key=Guid.NewGuid();svc.Odeme(key,id,DateTime.Today,100,"Ödeme","Banka","D1","");svc.Odeme(key,id,DateTime.Today,100,"Ödeme","Banka","D1","");Check(module+" ödeme idempotent",svc.Odemeler(id).Rows.Count==1);Reject(module+" fazla ödeme",()=>svc.Odeme(Guid.NewGuid(),id,DateTime.Today,225,"Ödeme","Banka","D2",""));Reject(module+" fazla iade",()=>svc.Odeme(Guid.NewGuid(),id,DateTime.Today,101,"İade","Banka","D3",""));svc.Odeme(Guid.NewGuid(),id,DateTime.Today,100,"İade","Banka","D4","");Check(module+" iade kaydı",svc.Odemeler(id).Rows.Count==2);
    }
    Reject(module+" atlanan aşama",()=>svc.Ilerle(id,(byte[])svc.Liste().Rows[0]["Surum"],svc.Akis.Adimlar[0],svc.Akis.Adimlar[^1]));
    svc.Ilerle(id,(byte[])svc.Liste().Rows[0]["Surum"],svc.Akis.Adimlar[0],svc.Akis.Sonuc);Reject(module+" kapanmış belge değişmez",()=>svc.Kaydet(g,id,(byte[])svc.Liste().Rows[0]["Surum"]));
   }
   var hr=new ErpModulServisi(cs,1);hr.Personel("P1","Test Personel","Üretim","Operatör",DateTime.Today.AddYears(-1),"","","");int person=Convert.ToInt32(hr.Liste("personel").Rows[0]["Id"]);
   hr.IK(Guid.NewGuid(),person,"Yıllık İzin",DateTime.Today,DateTime.Today.AddDays(1),2,"Test izin");var leave=hr.Liste("ik").Rows[0];hr.Durum("ik",(int)leave["Id"],(byte[])leave["Surum"],"Taslak","Onaylandı");Check("İK izin onayı",(string)hr.Liste("ik").Rows[0]["Durum"]=="Onaylandı");
   hr.IK(Guid.NewGuid(),person,"Rapor",DateTime.Today,DateTime.Today,1,"Çakışma");leave=hr.Liste("ik").Rows[0];Reject("Çakışan izin onaylanmaz",()=>hr.Durum("ik",(int)leave["Id"],(byte[])leave["Surum"],"Taslak","Onaylandı"));Check("İK birimler raporda ayrı",hr.IKRapor(DateTime.Today,DateTime.Today).Rows.Count==2);
   Check("Operasyon kayıtları stok değiştirmedi",Convert.ToInt32(Scalar(sql,"SELECT COUNT(*) FROM dbo.StokHareketleri"))==0);
   Mobil181Testleri.Run(cs).GetAwaiter().GetResult();
   var app=new Application{ShutdownMode=ShutdownMode.OnExplicitShutdown};app.Resources.MergedDictionaries.Add(new ResourceDictionary{Source=new Uri("pack://application:,,,/MiapaxERP.Desktop;component/Assets/ModernKontroller.xaml")});Tema170.Uygula(prefs);
   foreach(string code in new[]{"SALES","PURCHASE","ECOM","TRADE"}){var w=new TicaretMerkezi(cs,1,code);w.Show();w.UpdateLayout();Capture(w,Path.Combine(output,code+".png"));w.Close();Check(code+" ekran açılışı",true);}
   var ecom=new TicaretDosyalari(cs,1,"ECOM");
   foreach(string channel in new[]{"Trendyol","Shopify"})ecom.Kaydet(new("FILTER-"+channel,"Pazaryeri siparişi","Test müşteri","Kanal testi","",DateTime.Today,DateTime.Today,0,"TRY",new(){["Kanal / mağaza"]=channel+" / test"},""));
   var ew=new TicaretMerkezi(cs,1,"ECOM");
   var cf=(System.Windows.Controls.ComboBox)typeof(TicaretMerkezi).GetField("kanalFiltre",BindingFlags.Instance|BindingFlags.NonPublic)!.GetValue(ew)!;
   var eg=(System.Windows.Controls.DataGrid)typeof(TicaretMerkezi).GetField("liste",BindingFlags.Instance|BindingFlags.NonPublic)!.GetValue(ew)!;
   foreach(string channel in new[]{"Trendyol","Shopify","Manuel / diğer"}){cf.SelectedItem=channel;Check(channel+" siparişleri ayrı filtrelenir",eg.Items.Count==1);}ew.Close();
   var shops=new MagazaPenceresi(cs,1);shops.Show();shops.UpdateLayout();Capture(shops,Path.Combine(output,"Magazalar181.png"));shops.Close();Check("Kategorili mağazalar ekran açılışı",true);
   var ik=new ErpModulPenceresi(cs,1,"ik");ik.Show();ik.UpdateLayout();Capture(ik,Path.Combine(output,"IK.png"));ik.Close();Check("İK ekran açılışı",true);
   var main=(MainWindow)Activator.CreateInstance(typeof(MainWindow),BindingFlags.Instance|BindingFlags.NonPublic,null,new object[]{true},null)!;main.GorunumuUygula(prefs);Check("Uygulama adı sabit",main.Title.StartsWith("MiapaxERP"));Check("Firma adı ana sayfada",((System.Windows.Controls.TextBlock)main.FindName("TxtFirmaBasligi")).Text==prefs.FirmaBasligi);main.Close();app.Shutdown();
   Console.WriteLine($"PASSED {checks}");return 0;
  }catch(Exception ex){Console.WriteLine(ex.GetType().Name+": "+ex.Message);Console.WriteLine(ex.StackTrace);return 1;}
  finally{File.WriteAllLines(Path.Combine(output,"sonuclar.txt"),results);if(master!=null&&master.State==ConnectionState.Open&&name.StartsWith("MiapaxERP_Test180_")&&name.Length==47){SqlConnection.ClearAllPools();Sql(master,$"IF DB_ID('{name}') IS NOT NULL BEGIN ALTER DATABASE [{name}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; DROP DATABASE [{name}]; END");master.Dispose();}}
 }
 static void Capture(Window w,string file){var b=new RenderTargetBitmap((int)w.ActualWidth,(int)w.ActualHeight,96,96,PixelFormats.Pbgra32);b.Render(w);var e=new PngBitmapEncoder();e.Frames.Add(BitmapFrame.Create(b));using var stream=File.Create(file);e.Save(stream);}
 static void Connectors()
 {
  foreach(string c in MagazaBaglantisi.Kanallar){var a=new MagazaAyar(c,c=="Trendyol"?"123":c=="Hepsiburada"?Guid.Empty.ToString():c=="Shopify"?"test.myshopify.com":"shop.example.com","key","secret","test_integrator");using var r=MagazaBaglantisi.Istek(a,null);Check(c+" HTTPS yetkili istek",r.RequestUri!.Scheme=="https"&&(r.Headers.Authorization!=null||r.Headers.Contains("X-Shopify-Access-Token")));Check(c+" güvenli URL",!r.RequestUri.ToString().Contains("secret"));}
  Reject("Shopify token yabancı domaine gitmez",()=>MagazaBaglantisi.Dogrula(new("Shopify","evil.example.com","secret","")));
  var woo=MagazaBaglantisi.Coz("WooCommerce","""[{"id":1,"number":"W1","date_created":"2026-11-04T10:00:00","total":"123.45","currency":"TRY","status":"processing","billing":{"first_name":"Test","last_name":"Müşteri"},"shipping":{"city":"Ankara"},"line_items":[{"name":"Boru","quantity":2}]}]""",null);Check("WooCommerce veri çözümleme",woo.Siparisler[0].Tutar==123.45m);
  var shop=MagazaBaglantisi.Coz("Shopify","""{"data":{"orders":{"nodes":[{"id":"gid://shopify/Order/1","name":"S1","createdAt":"2026-11-04T10:00:00Z","displayFinancialStatus":"PAID","totalPriceSet":{"shopMoney":{"amount":"100.00","currencyCode":"TRY"}},"shippingAddress":null,"lineItems":{"nodes":[]}}],"pageInfo":{"hasNextPage":true,"endCursor":"next"}}}}""",null);Check("Shopify cursor ve boş adres",shop.Sonraki=="next"&&shop.Siparisler.Length==1);
  var ty=MagazaBaglantisi.Coz("Trendyol","""{"content":[{"id":1,"orderNumber":"T1","orderDate":1793786400000,"totalPrice":99.5,"currencyCode":"TRY","customerFirstName":"Test","customerLastName":"X","status":"Created","shipmentAddress":{"fullAddress":"Test adres"},"lines":[]}],"totalPages":2}""",null);Check("Trendyol sayfalama",ty.Sonraki=="1"&&ty.Siparisler[0].Tutar==99.5m);
  var hb=MagazaBaglantisi.Coz("Hepsiburada","""{"items":[{"id":"line-1","orderNumber":"H1","customerName":"Test","orderDate":"2026-11-04T10:00:00Z","totalPrice":{"amount":45.5,"currency":"TRY"},"status":"Open","shippingAddress":{"address":"Test"},"productName":"Boru","quantity":1}]}""",null);Check("Hepsiburada satır çözümleme",hb.Siparisler[0].Tutar==45.5m);
 }
}
