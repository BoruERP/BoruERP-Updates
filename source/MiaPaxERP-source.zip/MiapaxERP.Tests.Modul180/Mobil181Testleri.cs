using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using MiapaxERP.Desktop;
using Microsoft.Data.SqlClient;

static class Mobil181Testleri
{
    static void Assert(bool ok,string message){if(!ok)throw new Exception(message);Console.WriteLine("PASS Mobil: "+message);}
    static void Sql(string connection,string text){using var c=new SqlConnection(connection);c.Open();using var q=new SqlCommand(text,c);q.ExecuteNonQuery();}
    public static async Task Run(string connection)
    {
        if(!new SqlConnectionStringBuilder(connection).InitialCatalog.StartsWith("MiapaxERP_Test180_"))throw new Exception("Test veritabanı zorunlu.");
        string token=MobilRaporSunucusu.YeniAnahtar(),digest=MobilRaporSunucusu.Ozet(token);
        Assert(token.Length==64 && token!=MobilRaporSunucusu.YeniAnahtar(),"Rastgele cihaz anahtarları");
        Assert(MobilRaporSunucusu.AnahtarDogru("Bearer "+token,digest),"Doğru bearer anahtarı");
        Assert(!MobilRaporSunucusu.AnahtarDogru("Bearer "+new string('A',64),digest),"Yanlış anahtar reddi");
        foreach(string bad in new[]{"http://example.com","https://localhost","https://127.0.0.1","https://user:password@example.com","https://example.com/api","https://example.com/?key=secret"})
        {bool rejected=false;try{MobilRaporSunucusu.AdresDogrula(bad);}catch(ArgumentException){rejected=true;}Assert(rejected,"Güvensiz adres reddi: "+bad);}
        Sql(connection,"""
            CREATE TABLE dbo.CariKartlari(Id int PRIMARY KEY,Unvan nvarchar(100));INSERT dbo.CariKartlari VALUES(1,N'Test Müşteri');
            CREATE TABLE dbo.BoruERP_YeniBelgeler(Id int PRIMARY KEY,BelgeNo nvarchar(30),CariId int,Tarih date,GenelToplam decimal(18,2),OdemeDurumu nvarchar(30),BelgeTuru nchar(1));
            INSERT dbo.BoruERP_YeniBelgeler VALUES(1,N'S-1',1,'2026-11-05',250,N'Ödendi',N'S'),(2,N'T-1',1,'2026-11-05',999,N'Bekliyor',N'T');
            INSERT dbo.StokKartlari VALUES(1,N'B1',N'Test Boru',1,N'METRE');
            CREATE TABLE dbo.UretimEmirleri(Id int PRIMARY KEY,MamulStokId int,Durum nvarchar(30),PlanlananMiktar decimal(18,3),UretilenMiktar decimal(18,3),MiktarBirimi nvarchar(20));
            INSERT dbo.UretimEmirleri VALUES(1,1,N'Üretimde',100,20,N'METRE');
            CREATE TABLE dbo.FinansHesaplari(Id int PRIMARY KEY,HesapAdi nvarchar(100),ParaBirimi nvarchar(3),Aktif bit);
            INSERT dbo.FinansHesaplari VALUES(1,N'TRY Banka',N'TRY',1),(2,N'EUR Banka',N'EUR',1);
            CREATE TABLE dbo.FinansHareketleri(Id int PRIMARY KEY,HesapId int,HareketTipi nvarchar(20),Tutar decimal(18,2));
            INSERT dbo.FinansHareketleri VALUES(1,1,N'Giriş',100),(2,1,N'Çıkış',25),(3,2,N'Giriş',60);
            CREATE TABLE dbo.BoruERP_GGHesaplar(Kod nvarchar(20) PRIMARY KEY,Ad nvarchar(100));INSERT dbo.BoruERP_GGHesaplar VALUES(N'600.01.001',N'Satış geliri');
            CREATE TABLE dbo.BoruERP_GelirGider(Id int PRIMARY KEY,Tarih date,Tur nvarchar(20),HesapKodu nvarchar(20),Tutar decimal(18,2),BelgeNo nvarchar(80),Aciklama nvarchar(400),Iptal bit);
            INSERT dbo.BoruERP_GelirGider VALUES(1,'2026-11-05',N'Gelir',N'600.01.001',125,N'G1',N'Test kayıt',0);
            """);
        foreach(string section in new[]{"satis","uretim","muhasebe","gelirgider"})
        {
            var data=MobilRaporOku.Oku(connection,1,section);Assert(data.Kayitlar.Length>0,section+" gerçek tablo sorgusu");
            bool denied=false;try{MobilRaporOku.Oku(connection,3,section);}catch(UnauthorizedAccessException){denied=true;}Assert(denied,section+" yetki denetimi");
        }
        var finance=JsonSerializer.Serialize(MobilRaporOku.Oku(connection,1,"muhasebe"));Assert(finance.Contains("75.00")&&finance.Contains("60.00"),"TRY ve EUR bakiyeleri karıştırılmaz");
        Assert(MobilRaporOku.Oku(connection,1,"satis").Kayitlar.Length==1,"Teklifler satış raporuna girmez");
        bool active=true;await using var server=new MobilRaporSunucusu();await server.Baslat(connection,1,digest,()=>active);
        using var client=new HttpClient{BaseAddress=new Uri("http://127.0.0.1:5188"),Timeout=TimeSpan.FromSeconds(10)};
        using(var response=await client.GetAsync("/api/mobile/rapor/satis"))Assert(response.StatusCode==HttpStatusCode.Unauthorized,"HTTP yetkisiz istek 401");
        client.DefaultRequestHeaders.Authorization=new AuthenticationHeaderValue("Bearer",token);
        using(var response=await client.GetAsync("/api/mobile/rapor/uretim"))
        {Assert(response.IsSuccessStatusCode,"HTTP kimlik doğrulamalı rapor");Assert(response.Headers.CacheControl?.NoStore==true,"Rapor yanıtı no-store");Assert((await response.Content.ReadAsStringAsync()).Contains("20.000"),"İlk üretim miktarı");}
        Sql(connection,"UPDATE dbo.UretimEmirleri SET UretilenMiktar=21 WHERE Id=1");
        Assert((await client.GetStringAsync("/api/mobile/rapor/uretim")).Contains("21.000"),"Sonraki istek güncel fabrika verisini okur");
        Sql(connection,"UPDATE dbo.Kullanicilar SET Aktif=0 WHERE Id=1");
        using(var response=await client.GetAsync("/api/mobile/rapor/satis"))Assert(response.StatusCode==HttpStatusCode.Forbidden,"Kullanıcı iptali sonraki istekte 403");
        Sql(connection,"UPDATE dbo.Kullanicilar SET Aktif=1 WHERE Id=1");
        active=false;using(var response=await client.GetAsync("/api/mobile/rapor/satis"))Assert(response.StatusCode==HttpStatusCode.ServiceUnavailable,"Kapalı oturum 503");
        active=true;using(var response=await client.GetAsync("/api/mobile/rapor/bilinmeyen"))Assert(response.StatusCode==HttpStatusCode.NotFound,"Keyfi SQL yolu yok");
        await server.DisposeAsync();Assert(!server.Calisiyor,"Sunucu durduruldu");
        Sql(connection,"""
            DROP TABLE dbo.BoruERP_YeniBelgeler;DROP TABLE dbo.CariKartlari;DROP TABLE dbo.UretimEmirleri;
            DROP TABLE dbo.FinansHareketleri;DROP TABLE dbo.FinansHesaplari;DROP TABLE dbo.BoruERP_GelirGider;DROP TABLE dbo.BoruERP_GGHesaplar;
            DELETE dbo.StokKartlari WHERE Id=1;
            """);
    }
}
