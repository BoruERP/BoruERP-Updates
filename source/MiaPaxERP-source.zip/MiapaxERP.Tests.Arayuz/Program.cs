internal static class Program{[STAThread]static void Main()=>BordroUiHost.Run();}
