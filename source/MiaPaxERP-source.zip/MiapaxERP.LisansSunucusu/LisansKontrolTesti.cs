
using System;
using System.Text;
using System.Threading.Tasks;

namespace MiapaxERP.LisansSunucusu
{
    public static class LisansKontrolTesti
    {
        public static async Task<string> TestleriCalistirAsync(
            string gecerliLisansAnahtari)
        {
            if (string.IsNullOrWhiteSpace(gecerliLisansAnahtari))
            {
                return "Test lisans anahtarı boş olamaz.";
            }

            int basarili = 0;
            int basarisiz = 0;

            StringBuilder rapor = new StringBuilder();

            async Task TestEt(
                string testAdi,
                string anahtar,
                bool beklenenGecerlilik,
                string beklenenDurum)
            {
                LisansKontrolSonucu sonuc =
                    await LisansVeritabani.LisansiKontrolEtAsync(anahtar);

                bool gecti =
                    sonuc.Gecerli == beklenenGecerlilik &&
                    sonuc.Durum == beklenenDurum;

                if (gecti)
                    basarili++;
                else
                    basarisiz++;

                rapor.AppendLine(
                    $"{testAdi}: {(gecti ? "BAŞARILI" : "BAŞARISIZ")}");

                rapor.AppendLine(
                    $"  Beklenen durum: {beklenenDurum}");

                rapor.AppendLine(
                    $"  Gerçek durum: {sonuc.Durum}");

                rapor.AppendLine(
                    $"  Açıklama: {sonuc.Mesaj}");

                rapor.AppendLine();
            }

            await TestEt(
                "TEST 1 - Aktif lisans",
                gecerliLisansAnahtari,
                true,
                "Aktif");

            await TestEt(
                "TEST 2 - Geçersiz lisans",
                "GECERSIZ-TEST-" + Guid.NewGuid().ToString("N"),
                false,
                "Bulunamadi");

            await TestEt(
                "TEST 3 - Boş lisans",
                "",
                false,
                "Gecersiz");

            await TestEt(
                "TEST 4 - Askıya alınmış lisans",
                "BORU-TEST-ASKIDA",
                false,
                "Askida");

            await TestEt(
                "TEST 5 - Süresi dolmuş lisans",
                "BORU-TEST-SURESI-DOLDU",
                false,
                "SuresiDolmus");

            rapor.AppendLine("------------------------");
            rapor.AppendLine($"Başarılı: {basarili}");
            rapor.AppendLine($"Başarısız: {basarisiz}");

            return rapor.ToString();
        }
    }
}
