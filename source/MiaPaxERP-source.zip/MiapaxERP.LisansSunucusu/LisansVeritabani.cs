
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace MiapaxERP.LisansSunucusu
{
    public sealed class LisansBilgisi
    {
        public int LisansId { get; set; }
        public string FirmaAdi { get; set; } = string.Empty;
        public string LisansDurumu { get; set; } = string.Empty;
        public DateTime BaslangicTarihiUtc { get; set; }
        public DateTime? BitisTarihiUtc { get; set; }
    }

    public sealed class LisansKontrolSonucu
    {
        public bool Gecerli { get; set; }
        public string Durum { get; set; } = string.Empty;
        public string Mesaj { get; set; } = string.Empty;
        public string FirmaAdi { get; set; } = string.Empty;
        public DateTime? BitisTarihiUtc { get; set; }
    }

    public static class LisansVeritabani
    {
        // Yalnızca yerel geliştirme ortamı içindir.
        private const string BaglantiCumlesi =
            "Server=localhost;" +
            "Database=BoruERP_Lisans;" +
            "Integrated Security=True;" +
            "Encrypt=True;" +
            "TrustServerCertificate=True;";

        public static async Task<bool> BaglantiyiTestEtAsync()
        {
            try
            {
                await using SqlConnection baglanti =
                    new SqlConnection(BaglantiCumlesi);

                await baglanti.OpenAsync();

                return baglanti.State == ConnectionState.Open;
            }
            catch (SqlException)
            {
                return false;
            }
            catch (InvalidOperationException)
            {
                return false;
            }
        }

        public static async Task<List<LisansBilgisi>> LisanslariGetirAsync()
        {
            List<LisansBilgisi> lisanslar = new();

            await using SqlConnection baglanti =
                new SqlConnection(BaglantiCumlesi);

            await baglanti.OpenAsync();

            const string sorgu = @"
                SELECT
                    L.LisansId,
                    F.FirmaAdi,
                    L.LisansDurumu,
                    L.BaslangicTarihiUtc,
                    L.BitisTarihiUtc
                FROM dbo.Lisanslar AS L
                INNER JOIN dbo.Firmalar AS F
                    ON F.FirmaId = L.FirmaId
                ORDER BY L.LisansId;";

            await using SqlCommand komut =
                new SqlCommand(sorgu, baglanti);

            await using SqlDataReader okuyucu =
                await komut.ExecuteReaderAsync();

            while (await okuyucu.ReadAsync())
            {
                lisanslar.Add(new LisansBilgisi
                {
                    LisansId = okuyucu.GetInt32(0),
                    FirmaAdi = okuyucu.GetString(1),
                    LisansDurumu = okuyucu.GetString(2),
                    BaslangicTarihiUtc = okuyucu.GetDateTime(3),
                    BitisTarihiUtc = okuyucu.IsDBNull(4)
                        ? null
                        : okuyucu.GetDateTime(4)
                });
            }

            return lisanslar;
        }

        public static async Task<LisansKontrolSonucu>
            LisansiKontrolEtAsync(string? lisansAnahtari)
        {
            if (string.IsNullOrWhiteSpace(lisansAnahtari))
            {
                return new LisansKontrolSonucu
                {
                    Gecerli = false,
                    Durum = "Gecersiz",
                    Mesaj = "Lisans anahtarı boş olamaz."
                };
            }

            await using SqlConnection baglanti =
                new SqlConnection(BaglantiCumlesi);

            await baglanti.OpenAsync();

            const string sorgu = @"
                SELECT TOP (1)
                    F.FirmaAdi,
                    F.Aktif,
                    L.LisansDurumu,
                    L.BaslangicTarihiUtc,
                    L.BitisTarihiUtc
                FROM dbo.Lisanslar AS L
                INNER JOIN dbo.Firmalar AS F
                    ON F.FirmaId = L.FirmaId
                WHERE L.LisansAnahtari = @LisansAnahtari;";

            await using SqlCommand komut =
                new SqlCommand(sorgu, baglanti);

            komut.Parameters.Add(
                "@LisansAnahtari",
                SqlDbType.NVarChar,
                100
            ).Value = lisansAnahtari.Trim();

            await using SqlDataReader okuyucu =
                await komut.ExecuteReaderAsync();

            if (!await okuyucu.ReadAsync())
            {
                return new LisansKontrolSonucu
                {
                    Gecerli = false,
                    Durum = "Bulunamadi",
                    Mesaj = "Lisans bulunamadı."
                };
            }

            string firmaAdi = okuyucu.GetString(0);
            bool firmaAktif = okuyucu.GetBoolean(1);
            string lisansDurumu = okuyucu.GetString(2);
            DateTime baslangic = okuyucu.GetDateTime(3);

            DateTime? bitis = okuyucu.IsDBNull(4)
                ? null
                : okuyucu.GetDateTime(4);

            DateTime simdiUtc = DateTime.UtcNow;

            // Önce firma ve lisans durumunu kontrol ediyoruz.
            if (!firmaAktif)
            {
                return new LisansKontrolSonucu
                {
                    Gecerli = false,
                    Durum = "FirmaPasif",
                    Mesaj = "Firma hesabı pasif."
                };
            }

            if (lisansDurumu == "Askida")
            {
                return new LisansKontrolSonucu
                {
                    Gecerli = false,
                    Durum = "Askida",
                    Mesaj = "Lisans askıya alınmış."
                };
            }

            if (lisansDurumu == "Iptal")
            {
                return new LisansKontrolSonucu
                {
                    Gecerli = false,
                    Durum = "Iptal",
                    Mesaj = "Lisans iptal edilmiş."
                };
            }

            if (lisansDurumu != "Aktif")
            {
                return new LisansKontrolSonucu
                {
                    Gecerli = false,
                    Durum = "Gecersiz",
                    Mesaj = "Bilinmeyen lisans durumu."
                };
            }

            if (simdiUtc < baslangic)
            {
                return new LisansKontrolSonucu
                {
                    Gecerli = false,
                    Durum = "Baslamadi",
                    Mesaj = "Lisansın başlangıç tarihi gelmedi."
                };
            }

            if (bitis.HasValue && simdiUtc >= bitis.Value)
            {
                return new LisansKontrolSonucu
                {
                    Gecerli = false,
                    Durum = "SuresiDolmus",
                    Mesaj = "Lisansın süresi dolmuş."
                };
            }

            return new LisansKontrolSonucu
            {
                Gecerli = true,
                Durum = "Aktif",
                Mesaj = "Lisans geçerli.",
                FirmaAdi = firmaAdi,
                BitisTarihiUtc = bitis
            };
        }
    }
}
