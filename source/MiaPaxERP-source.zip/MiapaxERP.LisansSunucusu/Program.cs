
using System;
using MiapaxERP.LisansSunucusu;

var builder = WebApplication.CreateBuilder(args);

var app = builder.Build();

app.UseHttpsRedirection();

// Sunucunun çalıştığını kontrol eder.
app.MapGet("/api/durum", () =>
{
    return Results.Ok(new
    {
        Uygulama = "MiapaxERP Lisans Sunucusu",
        Durum = "Calisiyor",
        SunucuZamaniUtc = DateTimeOffset.UtcNow
    });
});

// Yalnızca geliştirme ortamında veritabanı bağlantı testi.
if (app.Environment.IsDevelopment())
{
    app.MapGet("/api/veritabani-test", async () =>
    {
        bool baglandi =
            await LisansVeritabani.BaglantiyiTestEtAsync();

        return Results.Ok(new
        {
            Veritabani = "BoruERP_Lisans",
            Baglanti = baglandi ? "Basarili" : "Basarisiz"
        });
    });
}

// Lisans testleri için anahtar, çalıştırma sırasında
// konsoldan alınır; kaynak kodda saklanmaz.
if (app.Environment.IsDevelopment() &&
    args.Contains("--lisans-test"))
{
    Console.Write("Test lisans anahtarını girin: ");

    string? lisansAnahtari = Console.ReadLine();

    try
    {
        string sonuc =
            await LisansKontrolTesti.TestleriCalistirAsync(
                lisansAnahtari ?? string.Empty);

        Console.WriteLine(sonuc);
    }
    catch (Exception hata)
    {
        Console.WriteLine(
            "Test çalıştırılamadı: " + hata.Message);
    }

    return;
}

app.Run();
