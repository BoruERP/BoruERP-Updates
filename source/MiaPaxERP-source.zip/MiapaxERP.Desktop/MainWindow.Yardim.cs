using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

namespace MiapaxERP.Desktop
{
    // MiapaxERP Yardım v0.7: rehber yalnızca sayfalarda gezinir. SQL INSERT/UPDATE/DELETE çağırmaz.
    public partial class MainWindow
    {
        
        private readonly List<YardimRehberAdimi> yardimTurAdimlari = new List<YardimRehberAdimi>();
        private int yardimTurIndeksi;
        private string yardimTurSayfasi = "";
        private bool yardimOtomatikGecis;
        private bool yardimSoruIsleniyor;
        private AdornerLayer? yardimVurguKatmani;
        private Adorner? yardimVurgu;

        private sealed class YardimRehberAdimi
        {
            public string Sayfa { get; }
            public string Hedef { get; }
            public string Baslik { get; }
            public string Aciklama { get; }
            public YardimRehberAdimi(string sayfa, string hedef, string baslik, string aciklama)
            {
                Sayfa = sayfa; Hedef = hedef; Baslik = baslik; Aciklama = aciklama;
            }
        }

        private sealed class YardimVurguCercevesi : Adorner
        {
            public YardimVurguCercevesi(UIElement hedef) : base(hedef)
            {
                IsHitTestVisible = false;
            }
            protected override void OnRender(DrawingContext dc)
            {
                var boyut = AdornedElement.RenderSize;
                if (boyut.Width <= 0 || boyut.Height <= 0) return;
                var firca = new SolidColorBrush(Color.FromRgb(245, 158, 11));
                dc.DrawRoundedRectangle(null, new Pen(firca, 3),
                    new Rect(-3, -3, boyut.Width + 6, boyut.Height + 6), 8, 8);
            }
        }

        private void YardimBaslat()
        {
            YardimMesajEkle(false,
                "Merhaba! Ben MiapaxERP yardım asistanıyım. Stok, üretim, reçete, cari, " +
                "muhasebe, raporlar ve ayarlar hakkında soru sorabilirsin. " +
                "Üstten eğitim seçebilir, ‘bu ekranı anlat’ diyebilir veya ‘devam’, ‘geri’, ‘örnek ver’ ile öğrenebilirsin. Genel sohbet sunucu bağlantısıyla çalışır. " +
                "Rehber kayıt oluşturmaz.");
        }

        private void YardimOturumAcildi()
        {
            AsistanOturumTemizle();AsistanHazirla();
            AnaSayfaYardimKatmani.Visibility = Visibility.Visible;
            YardimMesajEkle(false, "Oturum açıldı. Hazırsan birlikte başlayabiliriz.");
        }

        private void YardimOturumKapatildi()
        {
            AsistanOturumTemizle();
            YardimRehberiniBitir(false);
            AnaYardimPenceresi.Visibility = Visibility.Collapsed;
            AnaSayfaYardimKatmani.Visibility = Visibility.Collapsed;
            YardimMesajListesi.Children.Clear();
            YardimBaslat();
        }

        private void YardimPaneliniAcKapat()
        {
            if (!DemoModu && aktifKullanici == null) return;
            AnaYardimPenceresi.Visibility = AnaYardimPenceresi.Visibility == Visibility.Visible
                ? Visibility.Collapsed : Visibility.Visible;
            if (AnaYardimPenceresi.Visibility == Visibility.Visible)
            {
                YardimMesajAkisi.ScrollToEnd();
                YardimSoruMetni.Focus();
            }
        }

        private void YardimKapat_Click(object sender, RoutedEventArgs e) =>
            AnaYardimPenceresi.Visibility = Visibility.Collapsed;

        private void YardimMesajEkle(bool kullanici, string metin)
        {
            var cerceve = new Border
            {
                Background = new SolidColorBrush(kullanici
                    ? Color.FromRgb(226, 237, 255) : Color.FromRgb(244, 247, 251)),
                BorderBrush = new SolidColorBrush(Color.FromRgb(226, 232, 240)),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(10),
                Padding = new Thickness(10, 8, 10, 8),
                Margin = new Thickness(kullanici ? 42 : 0, 4, kullanici ? 0 : 32, 4),
                HorizontalAlignment = kullanici ? System.Windows.HorizontalAlignment.Right : System.Windows.HorizontalAlignment.Left,
                Child = new TextBlock
                {
                    Text = metin,
                    TextWrapping = TextWrapping.Wrap,
                    Foreground = new SolidColorBrush(Color.FromRgb(37, 55, 78)),
                    FontSize = 12
                }
            };
            YardimMesajListesi.Children.Add(cerceve);
            AsistanGecmiseEkle(kullanici,metin);
            YardimMesajAkisi.ScrollToEnd();
        }

        private async void YardimSoruGonder_Click(object sender, RoutedEventArgs e) => await YardimSorAsync();

        private async void YardimSoru_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key != Key.Enter) return;
            e.Handled = true;
            await YardimSorAsync();
        }

        private async Task YardimSorAsync()
        {
            if (yardimSoruIsleniyor || (!DemoModu && aktifKullanici == null)) return;
            string soru = YardimSoruMetni.Text.Trim();
            if (soru.Length == 0) return;
            YardimSoruMetni.Clear();
            YardimMesajEkle(true, soru);

            await AsistanSorAsync(soru);
        }

        private static string YerlesikYardimCevabi(string soru) => AsistanBilgisi.Bul(soru) is {} d ? AsistanBilgisi.Anlat(d) : "Eğitim listesinden bir konu seçebilirsin.";

        private void YardimStokRehberi_Click(object sender, RoutedEventArgs e) => YardimRehberBaslat("stok");
        private void YardimHareketRehberi_Click(object sender, RoutedEventArgs e) => YardimRehberBaslat("hareket");
        private void YardimUretimRehberi_Click(object sender, RoutedEventArgs e) => YardimRehberBaslat("uretim");
        private void YardimReceteRehberi_Click(object sender, RoutedEventArgs e) => YardimRehberBaslat("recete");

        private void YardimRehberBaslat(string tur)
        {
            if (!DemoModu && aktifKullanici == null) return;
            // Asistan hiçbir kullanıcıya yeni yetki tanımaz; mevcut SQL izinleriyle çalışır.
            string? yetki = tur switch
            {
                "stok" => "STOCK.VIEW",
                "hareket" => "STOCK.VIEW",
                "uretim" => "PRODUCTION.VIEW",
                "recete" => "RECIPE.VIEW",
                "merkez" or "eski" => "FINANCE.VIEW",
                "ayar" => "SETTINGS.VIEW",
                _ => MuhasebePaneli.Bolumler.FirstOrDefault(b=>b.Kod==tur)?.Yetki
            };
            if (yetki != null && !StokYetkisiVar(yetki))
            {
                YardimMesajEkle(false, "Bu rehberi açmak için " + yetki + " iznin olmalı. Yöneticinle görüşebilirsin.");
                AnaYardimPenceresi.Visibility = Visibility.Visible;
                return;
            }
            if (tur == "hareket" && !DemoModu &&
                !StokYetkisiVar("STOCK.RECEIVE") && !StokYetkisiVar("STOCK.ISSUE") &&
                !StokYetkisiVar("STOCK.HISTORY") && !StokYetkisiVar("STOCK.MINIMUM"))
            {
                YardimMesajEkle(false, "Stok Hareketleri ekranını açma iznin yok. Yöneticinle görüş.");
                return;
            }
            YardimRehberiniBitir(false);
            switch (tur)
            {
                case "stok":
                    yardimTurAdimlari.Add(new("stok", "BtnMenuStok", "1. Stok Yönetimi", "Sol menüdeki Stok Yönetimi bölümü açıldı. Burada kayıtlı stok kartlarını görürsün."));
                    yardimTurAdimlari.Add(new("stok", "TxtStokAra", "2. Arama", "Stok kodu veya adı yazarak ürünleri filtreleyebilirsin."));
                    yardimTurAdimlari.Add(new("stok", "BtnYeniStokEkle", "3. Yeni stok kartı", "Yeni Stok Ekle düğmesinden ürün kartı açılır. Bu rehber düğmeye basmaz veya kayıt yapmaz."));
                    yardimTurAdimlari.Add(new("stok", "StokKritikTablosu", "4. Kritik stoklar", "Minimum seviyeye ulaşan stoklar burada görünür. Limiti Stok Hareketleri bölümünde tanımlarsın."));
                    break;
                case "hareket":
                    yardimTurAdimlari.Add(new("hareket", "BtnMenuStokHareket", "1. Stok Hareketleri", "Bu bölüm alıştan gelen girişler ve üretim dışı çıkışları izlemek içindir."));
                    yardimTurAdimlari.Add(new("hareket", "CmbHareketStok", "2. Stok seçimi", "Önce işlem yapacağın stok kartını seç."));
                    yardimTurAdimlari.Add(new("hareket", "CmbHareketTur", "3. Giriş / Çıkış", "Giriş veya çıkış türünü seç. Yetkin olmayan işlem kaydedilemez."));
                    yardimTurAdimlari.Add(new("hareket", "TxtHareketMiktar", "4. Miktar", "Seçilen stok kartının birimine göre pozitif miktarı gir."));
                    yardimTurAdimlari.Add(new("hareket", "BtnHareketKaydet", "5. Kontrol ve kayıt", "Tutarı ve türü kontrol ettikten sonra kendin kaydetmelisin. Asistan bunu senin yerine yapmaz."));
                    break;
                case "uretim":
                    yardimTurAdimlari.Add(new("uretim", "BtnMenuUretim", "1. Üretim Yönetimi", "Üretim emirlerini bu bölümden yönetirsin."));
                    yardimTurAdimlari.Add(new("uretim", "CmbUretimMamul", "2. Mamul", "Üretilecek mamul stok kartını seç."));
                    yardimTurAdimlari.Add(new("uretim", "TxtPlanlananMiktar", "3. Planlanan miktar", "Üretim planını gir. Birimi kg, metre veya adet olabilir."));
                    yardimTurAdimlari.Add(new("uretim", "CmbUretimRecete", "4. Üretim reçetesi", "Mamule uygun aktif reçeteyi seç. Metre/adet kullanılıyorsa hammadde hesabı için kg karşılığını kontrol et."));
                    yardimTurAdimlari.Add(new("uretim", "BtnUretimEmriKaydet", "5. Emir oluşturma", "Bilgileri kontrol ettikten sonra emir kaydı yapılır. Asistan kesinlikle kaydet düğmesine basmaz."));
                    yardimTurAdimlari.Add(new("uretim", "UretimEmirleriTablosu", "6. Üretim takibi", "Emirleri listede izleyebilir, üretimi başlatıp tamamlayabilirsin. Tamamlama stokları etkileyebilir."));
                    break;
                case "recete":
                    yardimTurAdimlari.Add(new("recete", "BtnMenuRecete", "1. Üretim Reçeteleri", "Mamuller için hammadde karışımlarını bu bölümde tanımlarsın."));
                    yardimTurAdimlari.Add(new("recete", "TxtReceteKodu", "2. Reçete kodu", "Her reçeteye benzersiz bir kod ver."));
                    yardimTurAdimlari.Add(new("recete", "CmbReceteHammadde", "3. Hammadde seç", "Reçetede kullanılacak hammadde stok kartını seç."));
                    yardimTurAdimlari.Add(new("recete", "TxtReceteYuzde", "4. Karışım yüzdesi", "Hammadde oranlarını gir. Toplam %100 olmalı."));
                    yardimTurAdimlari.Add(new("recete", "BtnReceteKaydet", "5. Reçete kaydı", "Reçeteyi kontrol edip kendin kaydet. Rehber kayıt oluşturmaz."));
                    break;
                case "ana":
                    yardimTurAdimlari.Add(new("ana", "AnaKritikStokTablosu", "1. Kritik stok", "Ana sayfada minimum miktara düşen ürünleri görürsün."));
                    yardimTurAdimlari.Add(new("ana", "AnaAktifUretimTablosu", "2. Devam eden üretimler", "Üretimde durumundaki iş emirlerini ve ilerlemelerini burada takip edersin."));
                    break;
                default:
                    if(!AsistanMuhasebeTuru(tur)){YardimMesajEkle(false, YerlesikYardimCevabi(tur));return;}
                    break;
            }
            yardimTurIndeksi = 0;
            YardimMesajEkle(false, "Ekran üzerinde " + yardimTurAdimlari.Count + " adımlı rehber açılıyor. Tur sırasında hiçbir kayıt değiştirilmeyecek.");
            AnaYardimPenceresi.Visibility = Visibility.Collapsed;
            YardimRehberAdiminiGoster();
        }

        private void YardimRehberAdiminiGoster()
        {
            if (yardimTurAdimlari.Count == 0) return;
            var adim = yardimTurAdimlari[yardimTurIndeksi];
            YardimVurguTemizle();
            YardimAdimBalonu.IsOpen = false;
            if (yardimTurSayfasi != adim.Sayfa)
            {
                yardimOtomatikGecis = true;
                try
                {
                    if(adim.Sayfa.StartsWith("muhasebe:")) {
                        string kod=adim.Sayfa.Split(':')[1];
                        string route=kod is "merkez" or "eski"?"gelir":kod;
                        if(DemoModu){YardimRehberiniBitir(false);YardimMesajEkle(false,"Muhasebe ekran turu için oturum açmalısın. Yazılı eğitim demo modunda da kullanılabilir.");AnaYardimPenceresi.Visibility=Visibility.Visible;return;}
                        MuhasebeBolumAc(route);
                        if(muhasebePaneli?.AktifBolum!=route || MuhasebeIcerik.Visibility!=Visibility.Visible){YardimRehberiniBitir(false);return;}
                        if(route=="gelir")muhasebePaneli.RehberGelirSekmesi(kod=="merkez"?2:kod=="eski"?3:0);
                    } else switch (adim.Sayfa)
                    {
                        case "stok": StokEkraniniAc(); break;
                        case "hareket": StokHareketleriAc_Click(this, new RoutedEventArgs()); break;
                        case "uretim": UretimEkraniniAc(); break;
                        case "recete": UretimReceteleri_Click(this, new RoutedEventArgs()); break;
                        default: AnaSayfayiAc(); break;
                    }
                    yardimTurSayfasi = adim.Sayfa;
                }
                finally { yardimOtomatikGecis = false; }
            }
            Dispatcher.BeginInvoke(new Action(() =>
            {
                if (yardimTurAdimlari.Count == 0 || yardimTurIndeksi >= yardimTurAdimlari.Count) return;
                var suanki = yardimTurAdimlari[yardimTurIndeksi];
                if (!ReferenceEquals(suanki, adim)) return;
                FrameworkElement? hedef = AsistanHedefBul(adim.Hedef);
                bool hedefGorunur = hedef?.IsVisible == true;
                // Gizli sekmeler veya sürüme göre değişen alanlar turu sonlandırmasın.
                if (!hedefGorunur || hedef == null) hedef = this;
                hedef.BringIntoView();
                hedef.UpdateLayout();
                YardimAdimBalonu.PlacementTarget = hedef;
                YardimAdimSayaci.Text = "MiapaxERP Rehberi • " + (yardimTurIndeksi + 1) + "/" + yardimTurAdimlari.Count;
                YardimAdimBasligi.Text = adim.Baslik;
                YardimAdimMetni.Text = adim.Aciklama + (hedefGorunur ? "" :
                    "\n\nBu alan şu anda görünmüyor. İlgili sekmeyi açabilir veya İleri ile devam edebilirsiniz.");
                YardimGeriButonu.IsEnabled = yardimTurIndeksi > 0;
                YardimIleriButonu.Content = yardimTurIndeksi == yardimTurAdimlari.Count - 1 ? "Tamam ✓" : "İleri ▶";
                // Popup pencereye bağlı, açıklama gerçek alanın yakınında gösterilir.
                YardimAdimBalonu.IsOpen = true;
                yardimVurguKatmani = AdornerLayer.GetAdornerLayer(hedef);
                if (yardimVurguKatmani != null)
                {
                    yardimVurgu = new YardimVurguCercevesi(hedef);
                    yardimVurguKatmani.Add(yardimVurgu);
                }
            }), DispatcherPriority.Loaded);
        }

        private void YardimIleri_Click(object sender, RoutedEventArgs e)
        {
            if (yardimTurAdimlari.Count == 0) return;
            if (yardimTurIndeksi == yardimTurAdimlari.Count - 1)
            {
                YardimRehberiniBitir(true);
                return;
            }
            yardimTurIndeksi++;
            YardimRehberAdiminiGoster();
        }
        private void YardimGeri_Click(object sender, RoutedEventArgs e)
        {
            if (yardimTurIndeksi == 0) return;
            yardimTurIndeksi--;
            YardimRehberAdiminiGoster();
        }
        private void YardimBitir_Click(object sender, RoutedEventArgs e) => YardimRehberiniBitir(true);

        private void YardimVurguTemizle()
        {
            YardimAdimBalonu.IsOpen = false;
            if (yardimVurguKatmani != null && yardimVurgu != null)
            {
                try { yardimVurguKatmani.Remove(yardimVurgu); }
                catch (InvalidOperationException) { /* hedef ekran kapanmış olabilir */ }
            }
            yardimVurguKatmani = null;
            yardimVurgu = null;
        }

        private void YardimRehberiniBitir(bool haberVer)
        {
            bool vardi = yardimTurAdimlari.Count > 0;
            YardimVurguTemizle();
            yardimTurAdimlari.Clear();
            yardimTurSayfasi = "";
            yardimTurIndeksi = 0;
            if (haberVer && vardi)
            {
                YardimMesajEkle(false, "Rehber tamamlandı. Kayıtlar değiştirilmedi. Başka bir işlem için bana sorabilirsin.");
                AnaYardimPenceresi.Visibility = Visibility.Visible;
            }
        }
    }
}

