SET XACT_ABORT ON;
BEGIN TRANSACTION;
DECLARE @lock int;
EXEC @lock=sys.sp_getapplock @Resource=N'MiapaxERP.Moduller.160',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=15000;
IF @lock<0 THROW 51000,N'Modül kurulumu kilidi alınamadı.',1;
IF OBJECT_ID(N'dbo.BERP_Personel',N'U') IS NULL
CREATE TABLE dbo.BERP_Personel(Id int IDENTITY PRIMARY KEY,Sicil nvarchar(30) NOT NULL UNIQUE,AdSoyad nvarchar(150) NOT NULL,Departman nvarchar(100) NOT NULL,Gorev nvarchar(100) NOT NULL,IseGiris date NOT NULL,IstenCikis date NULL,Telefon nvarchar(40) NOT NULL DEFAULT '',Eposta nvarchar(150) NOT NULL DEFAULT '',Aciklama nvarchar(1000) NOT NULL DEFAULT '',Surum rowversion);
IF OBJECT_ID(N'dbo.BERP_IKIslem',N'U') IS NULL
CREATE TABLE dbo.BERP_IKIslem(Id int IDENTITY PRIMARY KEY,Anahtar uniqueidentifier NOT NULL UNIQUE,PersonelId int NOT NULL REFERENCES dbo.BERP_Personel(Id),Tur nvarchar(40) NOT NULL,Baslangic date NOT NULL,Bitis date NOT NULL,Miktar decimal(18,3) NOT NULL DEFAULT 0,Aciklama nvarchar(1000) NOT NULL,Durum nvarchar(30) NOT NULL DEFAULT N'Taslak',KullaniciId int NOT NULL,Onaylayan int NULL,Surum rowversion,CHECK(Bitis>=Baslangic),CHECK(Miktar>=0));
IF OBJECT_ID(N'dbo.BERP_SatinAlma',N'U') IS NULL
CREATE TABLE dbo.BERP_SatinAlma(Id int IDENTITY PRIMARY KEY,Anahtar uniqueidentifier NOT NULL UNIQUE,BelgeNo nvarchar(60) NOT NULL UNIQUE,Tarih date NOT NULL,Tedarikci nvarchar(150) NOT NULL,Malzeme nvarchar(150) NOT NULL,Miktar decimal(18,3) NOT NULL,Birim nvarchar(20) NOT NULL,BirimFiyat decimal(18,4) NOT NULL,ParaBirimi nvarchar(3) NOT NULL,Vade date NOT NULL,Aciklama nvarchar(1000) NOT NULL,Durum nvarchar(30) NOT NULL DEFAULT N'Talep',KullaniciId int NOT NULL,Onaylayan int NULL,Surum rowversion,CHECK(Miktar>0),CHECK(BirimFiyat>=0));
IF OBJECT_ID(N'dbo.BERP_Parti',N'U') IS NULL
CREATE TABLE dbo.BERP_Parti(Id bigint IDENTITY PRIMARY KEY,Anahtar uniqueidentifier NOT NULL UNIQUE,BelgeNo nvarchar(60) NOT NULL,Tedarikci nvarchar(150) NOT NULL,PartiNo nvarchar(60) NOT NULL UNIQUE,StokId int NOT NULL REFERENCES dbo.StokKartlari(Id),Tarih date NOT NULL,Icerik nvarchar(500) NOT NULL,Kg decimal(18,3) NOT NULL,PaketAdet int NOT NULL,HareketId bigint NOT NULL UNIQUE REFERENCES dbo.StokHareketleri(Id),KullaniciId int NOT NULL,CHECK(Kg>0),CHECK(PaketAdet BETWEEN 1 AND 1000),UNIQUE(Tedarikci,BelgeNo,StokId));
IF OBJECT_ID(N'dbo.BERP_Paket',N'U') IS NULL
CREATE TABLE dbo.BERP_Paket(Id bigint IDENTITY PRIMARY KEY,PartiId bigint NOT NULL REFERENCES dbo.BERP_Parti(Id),Barkod varchar(40) NOT NULL UNIQUE,Sira int NOT NULL,Kg decimal(18,3) NOT NULL,CHECK(Kg>0),UNIQUE(PartiId,Sira));
IF OBJECT_ID(N'dbo.BERP_Denetim',N'U') IS NULL
CREATE TABLE dbo.BERP_Denetim(Id bigint IDENTITY PRIMARY KEY,Tarih datetime2 NOT NULL DEFAULT SYSUTCDATETIME(),KullaniciId int NOT NULL,Modul nvarchar(40) NOT NULL,KayitId bigint NOT NULL,Islem nvarchar(100) NOT NULL);
IF OBJECT_ID(N'dbo.Yetkiler',N'U') IS NOT NULL
BEGIN
 INSERT dbo.Yetkiler(YetkiKodu,Modul,Islem,Aciklama,Aktif)
 SELECT v.Kod,v.Modul,v.Islem,v.Aciklama,1 FROM (VALUES
 (N'HR.VIEW',N'İnsan Kaynakları',N'Görüntüle',N'Personel ve İK işlemleri'),
 (N'HR.EDIT',N'İnsan Kaynakları',N'Kaydet',N'Personel ve işlem oluştur'),
 (N'HR.APPROVE',N'İnsan Kaynakları',N'Onayla',N'İK işlem onayı'),
 (N'PURCHASE.VIEW',N'Satın Alma',N'Görüntüle',N'Talep ve siparişleri görüntüle'),
 (N'PURCHASE.EDIT',N'Satın Alma',N'Kaydet',N'Satın alma talebi oluştur'),
 (N'PURCHASE.APPROVE',N'Satın Alma',N'Onayla',N'Talep onayla ve sipariş durumunu değiştir')
 ) v(Kod,Modul,Islem,Aciklama) WHERE NOT EXISTS(SELECT 1 FROM dbo.Yetkiler y WHERE y.YetkiKodu=v.Kod);
END;
COMMIT;

