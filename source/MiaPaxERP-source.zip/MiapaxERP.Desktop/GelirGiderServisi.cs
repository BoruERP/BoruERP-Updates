using System.Data;
using System.Globalization;
using Microsoft.Data.SqlClient;

namespace MiapaxERP.Desktop;

public sealed record GelirGiderGirdisi(Guid Anahtar, DateTime Tarih, string Tur, string Hesap, int Merkez, decimal Tutar, string Belge, string Aciklama, int? Kasa);
public sealed class GelirGiderServisi(string baglanti, int kullaniciId)
{
    public static decimal TutarOku(string metin)
    {
        string s=metin.Trim().Replace(',','.');
        if (!System.Text.RegularExpressions.Regex.IsMatch(s,@"^\d+(\.\d{1,2})?$") ||
            !decimal.TryParse(s,NumberStyles.AllowDecimalPoint,CultureInfo.InvariantCulture,out decimal n) || n<=0 || n>999999999999m)
            throw new ArgumentException("Tutar pozitif ve en fazla iki ondalıklı olmalı. Binlik ayıracı kullanmayın: 1250,50.");
        return n;
    }
    public static void Dogrula(GelirGiderGirdisi g)
    {
        if (g.Anahtar==Guid.Empty || g.Tur is not ("Gelir" or "Gider") || g.Merkez<=0 || g.Tutar<=0 || g.Tutar>999999999999m || decimal.Round(g.Tutar,2)!=g.Tutar)
            throw new ArgumentException("Tür, maliyet merkezi ve tutarı kontrol edin.");
        if (!System.Text.RegularExpressions.Regex.IsMatch(g.Hesap,@"^\d{3}\.\d{2}\.\d{3}$")) throw new ArgumentException("Bir detay hesabı seçin.");
        if (g.Belge.Length>80 || g.Aciklama.Trim().Length<3 || g.Aciklama.Length>400) throw new ArgumentException("Açıklama 3–400, belge no en fazla 80 karakter olmalı.");
    }
    private SqlConnection Ac() { var c=new SqlConnection(baglanti); c.Open(); return c; }
    private static SqlCommand Cmd(SqlConnection c,SqlTransaction? tx,string sql,params (string,object?)[] args)
    {
        var cmd=new SqlCommand(sql,c,tx){CommandTimeout=30};
        foreach(var (ad,v) in args)
        {
            if(v is decimal d) { var p=cmd.Parameters.Add(ad,SqlDbType.Decimal); p.Precision=18;p.Scale=2;p.Value=d; }
            else cmd.Parameters.AddWithValue(ad,v??DBNull.Value);
        }
        return cmd;
    }
    private void Yetki(SqlConnection c,SqlTransaction? tx,string kod)
    {
        LisansOturumu.YetkiGerekli(kod);
        using var cmd=Cmd(c,tx,"""
        SELECT CASE WHEN EXISTS(SELECT 1 FROM dbo.Kullanicilar WHERE Id=@u AND Aktif=1)
        AND EXISTS(SELECT 1 FROM dbo.vw_KullaniciEtkinYetkileri WHERE KullaniciId=@u AND YetkiKodu=@p AND Yetkili=1) THEN 1 ELSE 0 END
        """,("@u",kullaniciId),("@p",kod));
        if(Convert.ToInt32(cmd.ExecuteScalar())!=1)throw new UnauthorizedAccessException("Bu işlem için yetkiniz yok: "+kod);
    }
    public DataTable Oku(string tur)
    {
if(HttpsOturumu.Uzak(baglanti)){return HttpsOturumu.Cagir<DataTable>(baglanti,"GelirGiderServisi.Oku","",new object?[]{tur});}

        string sql=tur switch {
            "hesap"=>"SELECT Kod,Ad,GrupKodu,Tur,Detay,Aktif,Kod+N' — '+Ad AS Secim FROM dbo.BoruERP_GGHesaplar ORDER BY Kod",
            "merkez"=>"SELECT Id,Kod,Ad,Aktif,Kod+N' — '+Ad AS Secim FROM dbo.BoruERP_MaliyetMerkezleri ORDER BY Kod",
            "kasa"=>"SELECT Id,HesapAdi+N' (TRY)' AS Secim FROM dbo.FinansHesaplari WHERE Aktif=1 AND ParaBirimi=N'TRY' ORDER BY HesapAdi",
            "eski"=>"""
            SELECT m.Id,m.Tarih,m.Kategori,m.Tutar,m.Aciklama FROM dbo.BoruERP_YeniMasraflar m
            WHERE NOT EXISTS(SELECT 1 FROM dbo.BoruERP_GelirGider g WHERE g.EskiMasrafId=m.Id) ORDER BY m.Id DESC
            """,
            _=>throw new ArgumentException("Geçersiz liste.")};
        using var c=Ac();Yetki(c,null,"FINANCE.VIEW");
        if(tur=="eski") { using var check=Cmd(c,null,"SELECT OBJECT_ID(N'dbo.BoruERP_YeniMasraflar',N'U')");if(check.ExecuteScalar() is DBNull) return new DataTable(); }
        using var cmd=Cmd(c,null,sql);using var r=cmd.ExecuteReader();var t=new DataTable();t.Load(r);return t;
    }
    public void MerkezKaydet(string kod,string ad)
    {
if(HttpsOturumu.Uzak(baglanti)){HttpsOturumu.Cagir<object?>(baglanti,"GelirGiderServisi.MerkezKaydet","",new object?[]{kod,ad});return;}

        kod=kod.Trim().ToUpperInvariant();ad=ad.Trim();
        if(!System.Text.RegularExpressions.Regex.IsMatch(kod,@"^[A-Z0-9_-]{2,30}$")||ad.Length<2||ad.Length>150)throw new ArgumentException("Merkez kodu 2–30 harf/rakam, adı 2–150 karakter olmalı.");
        using var c=Ac();using var tx=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,tx,"FINANCE.PAYMENT");
        using var cmd=Cmd(c,tx,"INSERT INTO dbo.BoruERP_MaliyetMerkezleri(Kod,Ad) VALUES(@k,@a)",("@k",kod),("@a",ad));cmd.ExecuteNonQuery();tx.Commit();
    }
    public void MerkezDurumu(int id,bool aktif)
    {
if(HttpsOturumu.Uzak(baglanti)){HttpsOturumu.Cagir<object?>(baglanti,"GelirGiderServisi.MerkezDurumu","",new object?[]{id,aktif});return;}

        using var c=Ac();using var tx=c.BeginTransaction();Yetki(c,tx,"FINANCE.PAYMENT");
        using var cmd=Cmd(c,tx,"UPDATE dbo.BoruERP_MaliyetMerkezleri SET Aktif=@a WHERE Id=@id",("@a",aktif),("@id",id));
        if(cmd.ExecuteNonQuery()!=1)throw new InvalidOperationException("Merkez bulunamadı.");tx.Commit();
    }
    private static void SinifDogrula(SqlConnection c,SqlTransaction tx,string hesap,int merkez,string tur)
    {
        using var cmd=Cmd(c,tx,"""
        SELECT CASE WHEN EXISTS(SELECT 1 FROM dbo.BoruERP_GGHesaplar WITH(UPDLOCK,HOLDLOCK) WHERE Kod=@h AND Aktif=1 AND Detay=1 AND Tur=@t)
        AND EXISTS(SELECT 1 FROM dbo.BoruERP_MaliyetMerkezleri WITH(UPDLOCK,HOLDLOCK) WHERE Id=@m AND Aktif=1) THEN 1 ELSE 0 END
        """,("@h",hesap),("@m",merkez),("@t",tur));
        if(Convert.ToInt32(cmd.ExecuteScalar())!=1)throw new InvalidOperationException("Hesap türü uygun değil veya hesap/maliyet merkezi pasif.");
    }
    public long Kaydet(GelirGiderGirdisi g)
    {
if(HttpsOturumu.Uzak(baglanti)){return HttpsOturumu.Cagir<long>(baglanti,"GelirGiderServisi.Kaydet","",new object?[]{g});}

        Dogrula(g);using var c=Ac();using var tx=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,tx,"FINANCE.PAYMENT");
        using(var once=Cmd(c,tx,"SELECT Id FROM dbo.BoruERP_GelirGider WITH(UPDLOCK,HOLDLOCK) WHERE IslemAnahtari=@key",("@key",g.Anahtar)))
        {
            var id=once.ExecuteScalar();
            if(id!=null)
            {
                using var ayni=Cmd(c,tx,"""
                SELECT COUNT(*) FROM dbo.BoruERP_GelirGider WHERE Id=@id AND Tarih=@d AND Tur=@t AND HesapKodu=@h
                AND MaliyetMerkeziId=@m AND Tutar=@v AND BelgeNo=@b AND Aciklama=@a AND YapanKullaniciId=@u
                """,("@id",id),("@d",g.Tarih.Date),("@t",g.Tur),("@h",g.Hesap),("@m",g.Merkez),("@v",g.Tutar),("@b",g.Belge.Trim()),("@a",g.Aciklama.Trim()),("@u",kullaniciId));
                if(Convert.ToInt32(ayni.ExecuteScalar())!=1)throw new InvalidOperationException("Bu kayıt daha önce farklı bilgilerle kaydedildi. Kayıtlar bölümünü kontrol edip pencereyi yeniden açın.");
                tx.Commit();return Convert.ToInt64(id);
            }
        }
        SinifDogrula(c,tx,g.Hesap,g.Merkez,g.Tur);
        using var cmd=Cmd(c,tx,"""
        INSERT INTO dbo.BoruERP_GelirGider(IslemAnahtari,Tarih,Tur,HesapKodu,MaliyetMerkeziId,Tutar,BelgeNo,Aciklama,YapanKullaniciId)
        OUTPUT INSERTED.Id VALUES(@key,@d,@t,@h,@m,@v,@b,@a,@u)
        """,("@key",g.Anahtar),("@d",g.Tarih.Date),("@t",g.Tur),("@h",g.Hesap),("@m",g.Merkez),("@v",g.Tutar),("@b",g.Belge.Trim()),("@a",g.Aciklama.Trim()),("@u",kullaniciId));
        long yeni=Convert.ToInt64(cmd.ExecuteScalar());
        if(g.Kasa is int kasa) OdemeEkle(c,tx,yeni,kasa,g.Tarih.Date,g.Tur,g.Tutar);
        tx.Commit();return yeni;
    }
    private void OdemeEkle(SqlConnection c,SqlTransaction tx,long id,int kasa,DateTime tarih,string tur,decimal tutar)
    {
        using(var check=Cmd(c,tx,"SELECT COUNT(*) FROM dbo.FinansHesaplari WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Aktif=1 AND ParaBirimi=N'TRY'",("@id",kasa)))
            if(Convert.ToInt32(check.ExecuteScalar())!=1)throw new InvalidOperationException("Aktif bir TRY kasa/banka hesabı seçin.");
        using var cmd=Cmd(c,tx,"""
        INSERT INTO dbo.FinansHareketleri(HesapId,CariId,CariHareketId,Tarih,HareketTipi,Tutar,Aciklama,YapanKullaniciId)
        OUTPUT INSERTED.Id VALUES(@k,NULL,NULL,@d,@t,@v,@a,@u)
        """,("@k",kasa),("@d",tarih),("@t",tur=="Gelir"?"Giriş":"Çıkış"),("@v",tutar),("@a",$"Gelir/gider #{id} — {tur}"),("@u",kullaniciId));
        long finans=Convert.ToInt64(cmd.ExecuteScalar());
        using var link=Cmd(c,tx,"INSERT INTO dbo.BoruERP_GGOdemeler(KayitId,FinansHareketId) VALUES(@id,@f)",("@id",id),("@f",finans));link.ExecuteNonQuery();
    }
    private static readonly string AktifOdemeSql="""
        SELECT f.Id FROM dbo.BoruERP_GGOdemeler o WITH(UPDLOCK,HOLDLOCK)
        JOIN dbo.FinansHareketleri f WITH(UPDLOCK,HOLDLOCK) ON f.Id=o.FinansHareketId
        WHERE o.KayitId=@id AND NOT EXISTS(SELECT 1 FROM dbo.FinansHareketleri r WITH(UPDLOCK,HOLDLOCK) WHERE r.TersKayitId=f.Id)
        """;
    public void Ode(long id,int kasa,DateTime tarih)
    {
if(HttpsOturumu.Uzak(baglanti)){HttpsOturumu.Cagir<object?>(baglanti,"GelirGiderServisi.Ode","",new object?[]{id,kasa,tarih});return;}

        using var c=Ac();using var tx=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,tx,"FINANCE.PAYMENT");
        string tur; decimal tutar;DateTime kayitTarihi;
        using(var cmd=Cmd(c,tx,"SELECT Tur,Tutar,Tarih FROM dbo.BoruERP_GelirGider WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Iptal=0",("@id",id)))
        using(var r=cmd.ExecuteReader()) { if(!r.Read())throw new InvalidOperationException("Kayıt yok veya iptal edilmiş.");tur=r.GetString(0);tutar=r.GetDecimal(1);kayitTarihi=r.GetDateTime(2); }
        if(tarih.Date<kayitTarihi)throw new ArgumentException("Ödeme tarihi kayıt tarihinden önce olamaz.");
        using(var check=Cmd(c,tx,AktifOdemeSql,("@id",id))) if(check.ExecuteScalar()!=null)throw new InvalidOperationException("Bu kayıt zaten ödenmiş/tahsil edilmiş.");
        OdemeEkle(c,tx,id,kasa,tarih.Date,tur,tutar);tx.Commit();
    }
    public void Iptal(long id,string neden)
    {
if(HttpsOturumu.Uzak(baglanti)){HttpsOturumu.Cagir<object?>(baglanti,"GelirGiderServisi.Iptal","",new object?[]{id,neden});return;}

        neden=neden.Trim();if(neden.Length<3||neden.Length>400)throw new ArgumentException("İptal açıklaması 3–400 karakter olmalı.");
        using var c=Ac();using var tx=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,tx,"FINANCE.PAYMENT");
        using(var check=Cmd(c,tx,"SELECT COUNT(*) FROM dbo.BoruERP_GelirGider WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Iptal=0",("@id",id)))
            if(Convert.ToInt32(check.ExecuteScalar())!=1)throw new InvalidOperationException("Kayıt bulunamadı veya zaten iptal edilmiş.");
        var finanslar=new List<long>();
        using(var cmd=Cmd(c,tx,AktifOdemeSql,("@id",id)))using(var r=cmd.ExecuteReader())while(r.Read())finanslar.Add(r.GetInt64(0));
        foreach(long f in finanslar)
        {
            using(var check=Cmd(c,tx,"SELECT CariHareketId FROM dbo.FinansHareketleri WHERE Id=@f",("@f",f)))
                if(check.ExecuteScalar() is not DBNull)throw new InvalidOperationException("Cari bağlantılı eski ödeme önce Muhasebe ekranından terslenmelidir.");
            using var ters=Cmd(c,tx,"""
            INSERT INTO dbo.FinansHareketleri(HesapId,CariId,CariHareketId,TersKayitId,Tarih,HareketTipi,Tutar,Aciklama,YapanKullaniciId)
            SELECT HesapId,CariId,NULL,Id,CONVERT(date,GETDATE()),CASE WHEN HareketTipi=N'Giriş' THEN N'Çıkış' ELSE N'Giriş' END,Tutar,@a,@u
            FROM dbo.FinansHareketleri WHERE Id=@f
            """,("@a",$"Gelir/gider #{id} iptali"),("@u",kullaniciId),("@f",f));ters.ExecuteNonQuery();
        }
        using var iptal=Cmd(c,tx,"UPDATE dbo.BoruERP_GelirGider SET Iptal=1,IptalNedeni=@n,IptalZamani=SYSDATETIME(),IptalKullaniciId=@u WHERE Id=@id",("@n",neden),("@u",kullaniciId),("@id",id));
        iptal.ExecuteNonQuery();tx.Commit();
    }
    public void EskiSiniflandir(long eskiId,string hesap,int merkez)
    {
if(HttpsOturumu.Uzak(baglanti)){HttpsOturumu.Cagir<object?>(baglanti,"GelirGiderServisi.EskiSiniflandir","",new object?[]{eskiId,hesap,merkez});return;}

        using var c=Ac();using var tx=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,tx,"FINANCE.PAYMENT");SinifDogrula(c,tx,hesap,merkez,"Gider");
        using(var check=Cmd(c,tx,"SELECT COUNT(*) FROM dbo.BoruERP_GelirGider WITH(UPDLOCK,HOLDLOCK) WHERE EskiMasrafId=@e",("@e",eskiId)))
            if(Convert.ToInt32(check.ExecuteScalar())!=0)throw new InvalidOperationException("Bu eski masraf daha önce sınıflandırılmış.");
        using var cmd=Cmd(c,tx,"""
        INSERT INTO dbo.BoruERP_GelirGider(IslemAnahtari,Tarih,Tur,HesapKodu,MaliyetMerkeziId,Tutar,BelgeNo,Aciklama,EskiMasrafId,YapanKullaniciId)
        OUTPUT INSERTED.Id SELECT NEWID(),Tarih,N'Gider',@h,@m,Tutar,N'',LEFT(Kategori+N' / '+COALESCE(Aciklama,N''),400),Id,@u
        FROM dbo.BoruERP_YeniMasraflar WITH(UPDLOCK,HOLDLOCK) WHERE Id=@e
        """,("@h",hesap),("@m",merkez),("@u",kullaniciId),("@e",eskiId));
        var result=cmd.ExecuteScalar();if(result==null)throw new InvalidOperationException("Eski masraf bulunamadı.");long id=Convert.ToInt64(result);
        using var link=Cmd(c,tx,"""
        INSERT INTO dbo.BoruERP_GGOdemeler(KayitId,FinansHareketId)
        SELECT @id,FinansHareketId FROM dbo.BoruERP_YeniMasraflar WHERE Id=@e AND FinansHareketId IS NOT NULL
        """,("@id",id),("@e",eskiId));link.ExecuteNonQuery();tx.Commit();
    }
    public DataTable Rapor(DateTime bas,DateTime son,int? merkez,string? hesap)
    {
if(HttpsOturumu.Uzak(baglanti)){return HttpsOturumu.Cagir<DataTable>(baglanti,"GelirGiderServisi.Rapor","",new object?[]{bas,son,merkez,hesap});}

        if(bas.Date>son.Date || son.Date==DateTime.MaxValue.Date)throw new ArgumentException("Geçerli bir tarih aralığı seçin.");
        using var c=Ac();Yetki(c,null,"FINANCE.VIEW");
        using var cmd=Cmd(c,null,"""
        SELECT g.Id,g.Tarih,g.Tur,g.HesapKodu,h.Ad AS HesapAdi,h.GrupKodu,m.Kod AS MerkezKodu,m.Ad AS MaliyetMerkezi,g.Tutar,
        g.BelgeNo,g.Aciklama,g.Iptal,g.IptalNedeni,g.EskiMasrafId,
        CASE WHEN g.Iptal=1 THEN N'İptal' WHEN EXISTS(
          SELECT 1 FROM dbo.BoruERP_GGOdemeler o JOIN dbo.FinansHareketleri f ON f.Id=o.FinansHareketId
          WHERE o.KayitId=g.Id AND NOT EXISTS(SELECT 1 FROM dbo.FinansHareketleri r WHERE r.TersKayitId=f.Id))
        THEN CASE WHEN g.Tur=N'Gelir' THEN N'Tahsil edildi' ELSE N'Ödendi' END ELSE N'Bekliyor' END AS OdemeDurumu
        FROM dbo.BoruERP_GelirGider g JOIN dbo.BoruERP_GGHesaplar h ON h.Kod=g.HesapKodu
        JOIN dbo.BoruERP_MaliyetMerkezleri m ON m.Id=g.MaliyetMerkeziId
        WHERE g.Tarih>=@bas AND g.Tarih<@son AND (@m IS NULL OR g.MaliyetMerkeziId=@m) AND (@h IS NULL OR g.HesapKodu=@h)
        ORDER BY g.Tarih DESC,g.Id DESC
        """,("@bas",bas.Date),("@son",son.Date.AddDays(1)),("@m",merkez),("@h",hesap));
        using var r=cmd.ExecuteReader();var t=new DataTable();t.Load(r);return t;
    }
    public static DataTable Ozet(DataTable detay,string kirilim)
    {
        var t=new DataTable();t.Columns.Add("Grup");t.Columns.Add("Gelir",typeof(decimal));t.Columns.Add("Gider",typeof(decimal));t.Columns.Add("Fark",typeof(decimal));
        string Key(DataRow r)=>kirilim switch { "Hesap"=>r["HesapKodu"]+" — "+r["HesapAdi"],"Ay"=>((DateTime)r["Tarih"]).ToString("yyyy-MM"),_=>r["MaliyetMerkezi"].ToString()! };
        foreach(var g in detay.AsEnumerable().Where(r=>!r.Field<bool>("Iptal")).GroupBy(Key).OrderBy(g=>g.Key))
        { decimal gelir=g.Where(r=>r.Field<string>("Tur")=="Gelir").Sum(r=>r.Field<decimal>("Tutar")), gider=g.Where(r=>r.Field<string>("Tur")=="Gider").Sum(r=>r.Field<decimal>("Tutar"));t.Rows.Add(g.Key,gelir,gider,gelir-gider); }
        return t;
    }
}
