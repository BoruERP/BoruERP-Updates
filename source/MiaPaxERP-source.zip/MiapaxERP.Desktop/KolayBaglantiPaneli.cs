using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
namespace MiapaxERP.Desktop;

public sealed class KolayBaglantiPaneli : UserControl
{
    readonly ComboBox rol=new(){ItemsSource=new[]{"Ana sunucu","Yan PC","Mobil"},MinHeight=38};
    readonly TextBox address=new(){MinHeight=36,MaxLength=300},ip=new(){MinHeight=36,MaxLength=15},code=new(){AcceptsReturn=true,MinHeight=80,TextWrapping=TextWrapping.Wrap,MaxLength=8192};
    readonly TextBlock status=new(){TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,16,0,0)},info=new(){TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,10,0,14)};
    readonly StackPanel server=new(),root=new(){Margin=new Thickness(26),MaxWidth=800};
    readonly Window owner;bool busy;readonly CancellationTokenSource stop=new();
    string Rol=>rol.SelectedIndex switch{1=>"Yan",2=>"Mobil",_=>"Ana"};
    public KolayBaglantiPaneli(Window owner,Action local)
    {
        this.owner=owner;Content=new ScrollViewer{Content=root,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};
        root.Children.Add(new TextBlock{Text="Her yerden MiaPaxERP",FontSize=26,FontWeight=FontWeights.SemiBold});
        root.Children.Add(new TextBlock{Text="Ana sunucuyu bir kez hazırlayın. Diğer cihazları aynı HTTPS adresiyle bağlayın.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,10,0,18)});
        Field(root,"Bu cihaz",rol);root.Children.Add(info);
        Field(root,"Sunucunun HTTPS adresi",address);root.Children.Add(new TextBlock{Text="Örnek: https://erp.firmaniz.com",Margin=new Thickness(0,4,0,10)});
        Field(server,"Sabit dış IP",ip);var setup=new WrapPanel();server.Children.Add(setup);
        Button(setup,"HTTPS sunucusunu hazırla",Hazirla);Button(setup,"Yerel veritabanı ayarları",local);
        root.Children.Add(server);
        var actions=new WrapPanel();root.Children.Add(actions);
        Button(actions,"Kaydet",()=>{Profil().Kaydet();status.Text="Bağlantı adresi kaydedildi.";});
        AsyncButton(actions,"Bağlantıyı kontrol et",async()=>
        {
            var p=Profil();p.Dogrula(true);status.Text="Bağlantı kontrol ediliyor…";
            var dns=await KolayBaglantiKontrolu.Dns(address.Text.Trim(),Rol=="Ana"?ip.Text.Trim():"",Rol!="Mobil",stop.Token);
            status.Text=dns.Mesaj;if(dns.Basarili)status.Text+="\n\n"+(await KolayBaglantiKontrolu.Https(address.Text.Trim(),Rol!="Mobil",stop.Token)).Mesaj;
        });
        Button(actions,"Programa bağlan",()=>
        {
            if(Rol=="Ana"){status.Text="Ana sunucuda mevcut yerel ERP hesabınızla çalışın. Önce HTTPS sunucusunu hazırlayın; ardından diğer cihazlara bağlantı kodunu verin.";return;}
            Profil().Kaydet();
            if(Rol=="Mobil"){status.Text="Android uygulamasında bu adresi veya bağlantı kodunu kullanın. Yöneticinizin verdiği kişisel eşleme koduyla giriş yapın.";return;}
            if(Application.Current.MainWindow is MainWindow)
            {
                var start=new ProcessStartInfo(Environment.ProcessPath!){UseShellExecute=true};start.ArgumentList.Add("--https-client");Process.Start(start);
            }
            owner.DialogResult=true;
        });
        Field(root,"Bağlantı kodu",code);var shares=new WrapPanel();root.Children.Add(shares);
        Button(shares,"Kod oluştur",()=>code.Text=Profil().PaylasimKodu());
        Button(shares,"Kopyala",()=>{if(code.Text.Length==0)throw new ArgumentException("Önce kod oluşturun.");Clipboard.SetText(code.Text);status.Text="Adres kodu kopyalandı. Kod giriş yetkisi veya parola içermez.";});
        Button(shares,"Kodu uygula",()=>{var p=KolayBaglantiProfili.KoduOku(code.Text.Trim(),Rol);address.Text=Rol=="Mobil"?p.MobilHttps:p.MasaustuHttps;status.Text="Sunucu adresi alındı. Firmanızın adresiyle karşılaştırıp kaydedin.";});
        root.Children.Add(status);root.Children.Add(new TextBlock{Text="Ana sunucu açık ve internete bağlı kalmalı. DNS kaydı sabit dış IP'yi göstermeli; modemde 80 ve HTTPS portu ana sunucuya yönlenmeli. Bağlantıyı farklı bir internet bağlantısından da deneyin.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,20,0,0),FontSize=12});
        rol.SelectionChanged+=(_,_)=>{server.Visibility=Rol=="Ana"?Visibility.Visible:Visibility.Collapsed;info.Text=Rol switch{"Ana"=>"Yerel veritabanı bilgileri yalnız bu bilgisayarda tutulur. PC ve telefon için tek HTTPS adresi hazırlayın.","Yan"=>"Program bu bilgisayarda açılır. İşlemler ana sunucuya güvenli bağlantıyla gönderilir. ERP kullanıcı adınız ve şifrenizle giriş yapın.",_=>"Telefondaki MiaPaxERP uygulaması aynı HTTPS adresine bağlanır. Her çalışan kendi eşleme kodunu kullanır."};};
        try{var p=KolayBaglantiProfili.Oku();address.Text=p.MasaustuHttps.Length>0?p.MasaustuHttps:p.MobilHttps;ip.Text=p.SabitDisIp;rol.SelectedIndex=p.Rol switch{"Yan"=>1,"Mobil"=>2,_=>0};}catch(Exception e)when(e is IOException or System.Text.Json.JsonException or ArgumentException or UnauthorizedAccessException){rol.SelectedIndex=0;status.Text="Kayıtlı adres okunamadı. Sunucu adresini yeniden girin.";}
        owner.Closed+=(_,_)=>stop.Cancel();
    }
    KolayBaglantiProfili Profil()=>new(){Rol=Rol,SabitDisIp=Rol=="Ana"?ip.Text.Trim():"",MasaustuHttps=address.Text.Trim(),MobilHttps=address.Text.Trim()};
    static void Field(Panel p,string label,Control c){p.Children.Add(new TextBlock{Text=label,FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,12,0,5)});p.Children.Add(c);}
    void Button(Panel p,string label,Action action){var b=new Button{Content=label,Padding=new Thickness(12,8,12,8),Margin=new Thickness(0,10,8,0)};p.Children.Add(b);b.Click+=(_,_)=>{if(busy)return;try{action();}catch(Exception e){status.Text=e.Message;}};}
    void AsyncButton(Panel p,string label,Func<Task> action){var b=new Button{Content=label,Padding=new Thickness(12,8,12,8),Margin=new Thickness(0,10,8,0)};p.Children.Add(b);b.Click+=async(_,_)=>{if(busy)return;busy=true;b.IsEnabled=false;try{await action();}catch(OperationCanceledException){status.Text="Kontrol iptal edildi.";}catch(Exception e){status.Text=e.Message;}finally{busy=false;b.IsEnabled=true;}};}
    void Hazirla()
    {
        var p=Profil();p.Dogrula(true);p.Kaydet();var exe=SunucuAraciBul()??throw new FileNotFoundException("Tam kurulum paketindeki MobilKurulum / Sunucu klasörü bulunamadı.");
        var start=new ProcessStartInfo(exe){UseShellExecute=true,Verb="runas",WorkingDirectory=Path.GetDirectoryName(exe)!};start.ArgumentList.Add("setup");start.ArgumentList.Add(p.MasaustuHttps);Process.Start(start);
        status.Text="Ana sunucu kurulum penceresi açıldı. Veritabanı ve lisans bilgilerini bu pencerede girin.";
    }
    public static string? SunucuAraciBul()=>new[]{Path.Combine(AppContext.BaseDirectory,"MobilKurulum","Sunucu","MiapaxERP.MobileServer.exe"),Path.Combine(AppContext.BaseDirectory,"..","MobilKurulum","Sunucu","MiapaxERP.MobileServer.exe")}.Select(Path.GetFullPath).FirstOrDefault(File.Exists);
}
public static class KolayKurulumRehberi
{
    public static string Metin(KolayBaglantiProfili p)=>$"MiaPaxERP HTTPS kurulumu\nSunucu: {p.MasaustuHttps}\nSabit dış IP: {p.SabitDisIp}\n\n1. DNS A kaydını sabit dış IP'ye yönlendirin.\n2. Modemde TCP 80 ve HTTPS portunu (genellikle 443) ana bilgisayara yönlendirin. SQL portunu internete açmayın.\n3. Ana sunucu panelinden HTTPS sunucusunu hazırlayın.\n4. Yan PC'de sunucu adresini veya adres kodunu girip ERP hesabınızla giriş yapın.\n5. Android uygulamasında aynı adresi ve kişisel eşleme kodunu kullanın.\n6. Farklı internet bağlantısından bağlantıyı doğrulayın.\n";
}
