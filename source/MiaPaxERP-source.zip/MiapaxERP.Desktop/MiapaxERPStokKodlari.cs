using System;

namespace MiapaxERP.Desktop
{
    internal static class MiapaxERPStokKodlari
    {
        internal static string YeniKod(string stokTipi)
        {
            string onek = stokTipi switch
            {
                "Hammadde" => "HM",
                "Yardımcı Malzeme" => "YM",
                "Başlık" => "BS",
                "Yedek Parça" => "YP",
                "Mandallı" => "MD",
                "Kangal" => "KG",
                _ => "ST"
            };
            return onek + "-" + Guid.NewGuid().ToString("N")[..16].ToUpperInvariant();
        }
    }
}
