using System.Data;
using System.IO;
using System.Security.Cryptography;
namespace MiapaxERP.Desktop.Laboratuvar;

public sealed record LabDosyaPaketi(string Ad,byte[] Veri);
public sealed partial class LabServisi
{
    internal static void PdfDogrula(string name,byte[] bytes)
    {
        if(string.IsNullOrWhiteSpace(name)||name.Length>180||Path.GetFileName(name)!=name||!name.EndsWith(".pdf",StringComparison.OrdinalIgnoreCase)||bytes is null||bytes.Length is <5 or >10485760||!bytes.AsSpan(0,5).SequenceEqual("%PDF-"u8))throw new ArgumentException("Geçerli, en fazla 10 MB PDF dosyası gerekli.");
    }
    public long CihazPdfEkle(Guid key,long device,string name,byte[] bytes)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"LabServisi.CihazPdfEkle","",new object?[]{key,device,name,bytes});}

        PdfDogrula(name,bytes);if(key==Guid.Empty||device<1)throw new ArgumentException("Cihaz ve işlem kimliği gerekli.");string hash=Convert.ToHexString(SHA256.HashData(bytes));
        using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"LAB.CONFIG");
        using(var old=Q(c,t,"SELECT Id,CihazId,Ad,Sha256 FROM dbo.BERP260_LabCihazPdf WITH(UPDLOCK,HOLDLOCK) WHERE Anahtar=@k",("@k",key)))
        {using var r=old.ExecuteReader();if(r.Read()){if(r.GetInt64(1)!=device||r.GetString(2)!=name||r.GetString(3)!=hash)throw new ArgumentException("İşlem kimliği başka dosyada kullanılmış.");long id=r.GetInt64(0);r.Close();t.Commit();return id;}}
        using(var exists=Q(c,t,"SELECT COUNT(*) FROM dbo.BERP260_LabCihaz WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id",("@id",device)))if(Convert.ToInt32(exists.ExecuteScalar())!=1)throw new ArgumentException("Kalibrasyon kaydı bulunamadı.");
        using var q=Q(c,t,"INSERT dbo.BERP260_LabCihazPdf(Anahtar,CihazId,Ad,Veri,Sha256,Ekleyen) OUTPUT INSERTED.Id VALUES(@k,@id,@a,@v,@h,@u)",("@k",key),("@id",device),("@a",name),("@v",bytes),("@h",hash),("@u",user));long result=Convert.ToInt64(q.ExecuteScalar());Olay(c,t,null,"Kalibrasyon PDF eklendi","Cihaz "+device+" / "+name+" / SHA256 "+hash);t.Commit();return result;
    }
    public DataTable CihazPdfListesi(long device)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"LabServisi.CihazPdfListesi","",new object?[]{device});}
using var c=Ac();check(c,null,"LAB.VIEW");return Table(Q(c,null,"SELECT Id,Ad AS DosyaAdi,Sha256,Eklenme FROM dbo.BERP260_LabCihazPdf WHERE CihazId=@id ORDER BY Id DESC",("@id",device)));}
    public LabDosyaPaketi CihazPdfOku(long id)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<LabDosyaPaketi>(connection,"LabServisi.CihazPdfOku","",new object?[]{id});}

        using var c=Ac();check(c,null,"LAB.EXPORT");using var q=Q(c,null,"SELECT Ad,Veri,Sha256 FROM dbo.BERP260_LabCihazPdf WHERE Id=@id",("@id",id));using var r=q.ExecuteReader();if(!r.Read())throw new ArgumentException("PDF bulunamadı.");var bytes=(byte[])r[1];if(Convert.ToHexString(SHA256.HashData(bytes))!=r.GetString(2))throw new InvalidDataException("PDF bütünlük kontrolü başarısız.");return new(r.GetString(0),bytes);
    }
}
