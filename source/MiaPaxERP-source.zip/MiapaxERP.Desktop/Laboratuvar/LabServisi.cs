using System.Data;
using System.IO;
using System.Security.Cryptography;
using Microsoft.Data.SqlClient;
using MiapaxERP.Lisans.Core;
using static MiapaxERP.Desktop.Laboratuvar.LabKurallari;
namespace MiapaxERP.Desktop.Laboratuvar;

public sealed partial class LabServisi
{
 readonly string connection;readonly int user;readonly Action<SqlConnection,SqlTransaction?,string> check;
 public LabServisi(string connection,int user):this(connection,user,(c,t,p)=>new ErpModulServisi(connection,user).Yetki(c,t,p)){}
 internal LabServisi(string connection,int user,Action<SqlConnection,SqlTransaction?,string> check){this.connection=connection;this.user=user;this.check=check;}
 SqlConnection Ac(){var c=new SqlConnection(connection);c.Open();return c;}
 static SqlCommand Q(SqlConnection c,SqlTransaction? t,string sql,params(string,object?)[] ps)=>ErpModulServisi.Komut(c,t,sql,ps);
 static DataTable Table(SqlCommand q){using(q)using(var r=q.ExecuteReader()){var dt=new DataTable();dt.Load(r);return dt;}}
 void Olay(SqlConnection c,SqlTransaction t,long? id,string action,string why){using var q=Q(c,t,"INSERT dbo.BERP260_LabOlay(NumuneId,Kullanici,Olay,Gerekce) VALUES(@id,@u,@a,@g)",("@id",id),("@u",user),("@a",action),("@g",why));q.ExecuteNonQuery();}
 public void Kur(){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"LabServisi.Kur","",new object?[]{});return;}
using var c=Ac();check(c,null,"MODULES.INSTALL");check(c,null,"LAB.CONFIG");using var q=Q(c,null,File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"Laboratuvar260.sql")));q.ExecuteNonQuery();}
 public DataTable Liste(string type,string search="")
 {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"LabServisi.Liste","",new object?[]{type,search});}

  if(search.Length>100)throw new ArgumentException("Arama çok uzun.");using var c=Ac();check(c,null,"LAB.VIEW");
  string sql=type switch{
   "numune"=>"SELECT TOP(500) n.Id,N'LAB-'+CONVERT(nvarchar(20),n.Id) AS Barkod,s.StokKodu,s.StokAdi,n.Kaynak,n.KaynakBilgi,n.Durum,n.Termin,n.Alindi,n.Alan,n.Surum FROM dbo.BERP260_LabNumune n JOIN dbo.StokKartlari s ON s.Id=n.StokId WHERE s.StokAdi LIKE @q OR n.KaynakBilgi LIKE @q OR CONVERT(nvarchar(20),n.Id)=@s ORDER BY n.Id DESC",
   "plan"=>"SELECT Id,Ad,Aile,Olusturan,Onaylayan,OnayZamani,Veri,Surum FROM dbo.BERP260_LabPlan ORDER BY Id DESC",
   "cihaz"=>"SELECT Id,Kod,Ad,Kalibrasyon,Gecerlilik,Belge FROM dbo.BERP260_LabCihaz ORDER BY Id DESC",
   "bloke"=>"SELECT b.NumuneId,b.StokId,s.StokKodu,s.StokAdi,n.KaynakBilgi,n.Durum,n.Termin FROM dbo.BERP260_LabBloke b JOIN dbo.StokKartlari s ON s.Id=b.StokId JOIN dbo.BERP260_LabNumune n ON n.Id=b.NumuneId WHERE b.Aktif=1 ORDER BY n.Id DESC",
   "gorev"=>"SELECT g.Id,g.NumuneId,g.TestKodu,g.Baslangic,g.BeklenenBitis,g.Kullanici,c.Kod AS Cihaz,CASE WHEN g.BeklenenBitis<SYSDATETIMEOFFSET() THEN N'Gecikmiş' ELSE N'Devam ediyor' END AS Durum FROM dbo.BERP260_LabGorev g JOIN dbo.BERP260_LabCihaz c ON c.Id=g.CihazId WHERE g.Bitis IS NULL ORDER BY g.BeklenenBitis",
   _=>throw new ArgumentException("Liste geçersiz.")};return Table(Q(c,null,sql,("@q","%"+search+"%"),("@s",search.StartsWith("LAB-",StringComparison.OrdinalIgnoreCase)?search[4..]:search)));
 }
 public DataTable Kaynaklar(string kind,string search="")
 {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"LabServisi.Kaynaklar","",new object?[]{kind,search});}

  if(search.Length>100)throw new ArgumentException("Arama çok uzun.");using var c=Ac();check(c,null,"LAB.VIEW");string sql=kind switch{
   "Stok numunesi"=>"SELECT TOP(200) Id,Id AS StokId,StokKodu+N' / '+StokAdi AS Ad FROM dbo.StokKartlari WHERE Aktif=1 AND (StokKodu LIKE @q OR StokAdi LIKE @q) ORDER BY Id DESC",
   "Hammadde partisi"=>"SELECT TOP(200) p.Id,p.StokId,p.PartiNo+N' / '+p.Tedarikci+N' / '+s.StokAdi AS Ad FROM dbo.BERP_Parti p JOIN dbo.StokKartlari s ON s.Id=p.StokId WHERE p.PartiNo LIKE @q OR s.StokAdi LIKE @q ORDER BY p.Id DESC",
   "Üretim emri"=>"SELECT TOP(200) e.Id,e.MamulStokId AS StokId,e.UretimEmriNo+N' / '+s.StokAdi AS Ad FROM dbo.UretimEmirleri e JOIN dbo.StokKartlari s ON s.Id=e.MamulStokId WHERE e.UretimEmriNo LIKE @q OR s.StokAdi LIKE @q ORDER BY e.Id DESC",
   "Sektör üretimi"=>"SELECT TOP(200) u.Id,r.MamulId AS StokId,u.Belge+N' / '+s.StokAdi AS Ad FROM dbo.BERP200_Uretim u JOIN dbo.BERP200_Recete r ON r.Id=u.ReceteId JOIN dbo.StokKartlari s ON s.Id=r.MamulId WHERE u.Belge LIKE @q OR s.StokAdi LIKE @q ORDER BY u.Id DESC",
   _=>throw new ArgumentException("Kaynak türü geçersiz.")};return Table(Q(c,null,sql,("@q","%"+search+"%")));
 }
 public long PlanEkle(LabPlan plan){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"LabServisi.PlanEkle","",new object?[]{plan});}
PlanDogrula(plan);using var c=Ac();using var t=c.BeginTransaction();check(c,t,"LAB.CONFIG");using var q=Q(c,t,"INSERT dbo.BERP260_LabPlan(Ad,Aile,Veri,Olusturan) OUTPUT INSERTED.Id VALUES(@a,@f,@v,@u)",("@a",plan.Ad),("@f",plan.Aile),("@v",Yaz(plan)),("@u",user));long id=Convert.ToInt64(q.ExecuteScalar());Olay(c,t,null,"Test planı oluşturuldu","Plan "+id+" / "+plan.Ad);t.Commit();return id;}
 public void PlanOnay(long id,byte[] version){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"LabServisi.PlanOnay","",new object?[]{id,version});return;}
using var c=Ac();using var t=c.BeginTransaction();check(c,t,"LAB.PLAN_APPROVE");using(var read=Q(c,t,"SELECT Veri,Olusturan FROM dbo.BERP260_LabPlan WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Onaylayan IS NULL",("@id",id))){using var r=read.ExecuteReader();if(!r.Read())throw new InvalidOperationException("Onaysız plan bulunamadı.");if(r.GetInt32(1)==user)throw new UnauthorizedAccessException("Kendi oluşturduğunuz planı onaylayamazsınız.");PlanDogrula(Oku<LabPlan>(r.GetString(0)));}using var q=Q(c,t,"UPDATE dbo.BERP260_LabPlan SET Onaylayan=@u,OnayZamani=SYSDATETIMEOFFSET() WHERE Id=@id AND Surum=@v AND Onaylayan IS NULL",("@u",user),("@id",id),("@v",version));if(q.ExecuteNonQuery()!=1)throw new InvalidOperationException("Plan değişti. Yenileyin.");Olay(c,t,null,"Test planı onaylandı","Plan "+id);t.Commit();}
 public long CihazEkle(LabCihaz cihaz){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"LabServisi.CihazEkle","",new object?[]{cihaz});}
CihazDogrula(cihaz);using var c=Ac();using var t=c.BeginTransaction();check(c,t,"LAB.CONFIG");using var q=Q(c,t,"INSERT dbo.BERP260_LabCihaz(Kod,Ad,Kalibrasyon,Gecerlilik,Belge,Olusturan) OUTPUT INSERTED.Id VALUES(@k,@a,@d,@g,@b,@u)",("@k",cihaz.Kod),("@a",cihaz.Ad),("@d",cihaz.Kalibrasyon.Date),("@g",cihaz.Gecerlilik.Date),("@b",cihaz.Belge),("@u",user));long id=Convert.ToInt64(q.ExecuteScalar());Olay(c,t,null,"Cihaz doğrulaması kaydedildi",cihaz.Kod+" / kayıt "+id);t.Commit();return id;}
 public long NumuneEkle(Guid key,int stok,string kind,long source,long planId,DateTime termin,string note)
 {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"LabServisi.NumuneEkle","",new object?[]{key,stok,kind,source,planId,termin,note});}

  if(key==Guid.Empty||stok<1||source<1||planId<1||termin.Date<DateTime.UtcNow.Date)throw new ArgumentException("Kaynak, plan ve termin gerekli.");Metin(note,2000,"Numune açıklaması / hat / vardiya / numune alma bilgileri");string digest=LisansKripto.Ozet(Yaz(new{stok,kind,source,planId,termin=termin.Date,note,user}));
  using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"LAB.SAMPLE");
  using(var old=Q(c,t,"SELECT Id,Ozet FROM dbo.BERP260_LabNumune WITH(UPDLOCK,HOLDLOCK) WHERE Anahtar=@k",("@k",key))){using var r=old.ExecuteReader();if(r.Read()){if(r.GetString(1)!=digest)throw new ArgumentException("İşlem anahtarı farklı numunede kullanıldı.");long existing=r.GetInt64(0);r.Close();t.Commit();return existing;}}
  using(var stock=Q(c,t,"SELECT Id FROM dbo.StokKartlari WITH(UPDLOCK,HOLDLOCK) WHERE Id=@s AND Aktif=1",("@s",stok)))if(stock.ExecuteScalar() is null)throw new ArgumentException("Aktif stok bulunamadı.");
  string info;string sourceSql=kind switch{"Stok numunesi"=>"SELECT StokKodu+N' / '+StokAdi FROM dbo.StokKartlari WHERE Id=@id AND Id=@s","Hammadde partisi"=>"SELECT PartiNo+N' / '+Tedarikci FROM dbo.BERP_Parti WHERE Id=@id AND StokId=@s","Üretim emri"=>"SELECT UretimEmriNo FROM dbo.UretimEmirleri WHERE Id=@id AND MamulStokId=@s","Sektör üretimi"=>"SELECT u.Belge FROM dbo.BERP200_Uretim u JOIN dbo.BERP200_Recete r ON r.Id=u.ReceteId WHERE u.Id=@id AND r.MamulId=@s",_=>throw new ArgumentException("Kaynak geçersiz.")};
  using(var sourceQ=Q(c,t,sourceSql,("@id",source),("@s",stok)))info=Convert.ToString(sourceQ.ExecuteScalar())??"";Metin(info,1000,"Kaynak kaydı");
  string plan;using(var q=Q(c,t,"SELECT Veri FROM dbo.BERP260_LabPlan WITH(HOLDLOCK) WHERE Id=@id AND Onaylayan IS NOT NULL",("@id",planId)))plan=Convert.ToString(q.ExecuteScalar())??"";PlanDogrula(Oku<LabPlan>(plan));
  using var insert=Q(c,t,"INSERT dbo.BERP260_LabNumune(Anahtar,Ozet,StokId,Kaynak,KaynakId,KaynakBilgi,PlanId,PlanAnlik,Aciklama,Alan,Termin) OUTPUT INSERTED.Id VALUES(@k,@h,@s,@kind,@sid,@info,@p,@plan,@n,@u,@d)",("@k",key),("@h",digest),("@s",stok),("@kind",kind),("@sid",source),("@info",info),("@p",planId),("@plan",plan),("@n",note),("@u",user),("@d",termin.Date));long id=Convert.ToInt64(insert.ExecuteScalar());using(var hold=Q(c,t,"INSERT dbo.BERP260_LabBloke(NumuneId,StokId) VALUES(@id,@s)",("@id",id),("@s",stok)))hold.ExecuteNonQuery();Olay(c,t,id,"Numune kabul edildi","Stok kartının tüm çıkışları karantinada. "+note);t.Commit();return id;
 }
 DataRow Numune(SqlConnection c,SqlTransaction? t,long id,bool locked=false){var dt=Table(Q(c,t,"SELECT n.*,s.StokKodu,s.StokAdi FROM dbo.BERP260_LabNumune n "+(locked?"WITH(UPDLOCK,HOLDLOCK) ":"")+"JOIN dbo.StokKartlari s ON s.Id=n.StokId WHERE n.Id=@id",("@id",id)));return dt.Rows.Count==1?dt.Rows[0]:throw new ArgumentException("Numune bulunamadı.");}
 public DataRow Numune(long id){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataRow>(connection,"LabServisi.Numune","",new object?[]{id});}
using var c=Ac();check(c,null,"LAB.VIEW");return Numune(c,null,id);}
 static DataTable Sonuclar(SqlConnection c,SqlTransaction? t,long id)=>Table(Q(c,t,"SELECT *,ROW_NUMBER() OVER(PARTITION BY TestKodu ORDER BY Id DESC) AS Sira FROM dbo.BERP260_LabSonuc WHERE NumuneId=@id ORDER BY Id DESC",("@id",id)));
 public DataTable Detay(long id,string type){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"LabServisi.Detay","",new object?[]{id,type});}
using var c=Ac();check(c,null,"LAB.VIEW");return type=="sonuc"?Sonuclar(c,null,id):Table(Q(c,null,type switch{"olay"=>"SELECT Id,Kullanici,Olay,Gerekce,Zaman FROM dbo.BERP260_LabOlay WHERE NumuneId=@id ORDER BY Id","ek"=>"SELECT Id,Ad,Tur,Sha256,Ekleyen,Zaman FROM dbo.BERP260_LabEk WHERE NumuneId=@id ORDER BY Id","gorev"=>"SELECT * FROM dbo.BERP260_LabGorev WHERE NumuneId=@id ORDER BY Id DESC","bag"=>"SELECT b.*,n.KaynakBilgi AS HammaddeKaynak,n.Durum AS HammaddeDurum FROM dbo.BERP260_LabBag b JOIN dbo.BERP260_LabNumune n ON n.Id=b.HammaddeNumune WHERE b.UrunNumune=@id OR b.HammaddeNumune=@id ORDER BY b.Id",_=>throw new ArgumentException("Detay geçersiz.")},("@id",id)));}
 public long SonucEkle(Guid key,long id,byte[] version,LabOlcum value)
 {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"LabServisi.SonucEkle","",new object?[]{key,id,version,value});}

  if(key==Guid.Empty)throw new ArgumentException("İşlem anahtarı gerekli.");string digest=LisansKripto.Ozet(Yaz(new{id,value,user}));using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"LAB.RESULT");
  using(var old=Q(c,t,"SELECT Id,Ozet FROM dbo.BERP260_LabSonuc WITH(UPDLOCK,HOLDLOCK) WHERE Anahtar=@k",("@k",key))){using var r=old.ExecuteReader();if(r.Read()){if(r.GetString(1)!=digest)throw new ArgumentException("İşlem anahtarı farklı sonuçta kullanıldı.");long existing=r.GetInt64(0);r.Close();t.Commit();return existing;}}
  var sample=Numune(c,t,id,true);Version(sample,version);if((string)sample["Durum"]!="Çalışılıyor")throw new InvalidOperationException("Sonuç için numune çalışılıyor durumunda olmalı.");var plan=Oku<LabPlan>((string)sample["PlanAnlik"]);var test=plan.Testler.SingleOrDefault(x=>x.Kod==value.TestKodu)??throw new ArgumentException("Test numune planında yok.");
  using(var prior=Q(c,t,"SELECT COUNT(*) FROM dbo.BERP260_LabSonuc WHERE NumuneId=@id AND TestKodu=@k",("@id",id),("@k",test.Kod)))if(Convert.ToInt32(prior.ExecuteScalar())>0)Metin(value.Not,2000,"Tekrar test / düzeltme gerekçesi");
  LabCihaz device;using(var q=Q(c,t,"SELECT Kod,Ad,Kalibrasyon,Gecerlilik,Belge FROM dbo.BERP260_LabCihaz WITH(HOLDLOCK) WHERE Id=@id",("@id",value.CihazId))){using var r=q.ExecuteReader();if(!r.Read())throw new ArgumentException("Cihaz kaydı bulunamadı.");device=new(r.GetString(0),r.GetString(1),r.GetDateTime(2),r.GetDateTime(3),r.GetString(4));}
  using(var work=Q(c,t,"SELECT CihazId,Baslangic FROM dbo.BERP260_LabGorev WITH(UPDLOCK,HOLDLOCK) WHERE NumuneId=@id AND TestKodu=@k AND Bitis IS NULL",("@id",id),("@k",test.Kod))){using var r=work.ExecuteReader();if(r.Read()&&(r.GetInt64(0)!=value.CihazId||value.Zaman<r.GetFieldValue<DateTimeOffset>(1)))throw new ArgumentException("Devam eden testin cihazı ve başlangıç zamanı sonuçla uyuşmuyor.");}
  var result=Degerlendir(test,value,device,(DateTimeOffset)sample["Alindi"],DateTimeOffset.UtcNow);
  using var insert=Q(c,t,"INSERT dbo.BERP260_LabSonuc(Anahtar,Ozet,NumuneId,TestKodu,Veri,CihazId,CihazAnlik,Degerlendirme,Durum,Yapan) OUTPUT INSERTED.Id VALUES(@k,@h,@id,@code,@v,@d,@ds,@r,@state,@u)",("@k",key),("@h",digest),("@id",id),("@code",test.Kod),("@v",Yaz(value)),("@d",value.CihazId),("@ds",Yaz(device)),("@r",Yaz(result)),("@state",result.Durum),("@u",user));long rid=Convert.ToInt64(insert.ExecuteScalar());using(var finish=Q(c,t,"UPDATE dbo.BERP260_LabGorev SET Bitis=@z WHERE NumuneId=@id AND TestKodu=@k AND Bitis IS NULL",("@z",value.Zaman),("@id",id),("@k",test.Kod)))finish.ExecuteNonQuery();using(var bump=Q(c,t,"UPDATE dbo.BERP260_LabNumune SET Aciklama=Aciklama WHERE Id=@id",("@id",id)))bump.ExecuteNonQuery();Olay(c,t,id,"Test sonucu kaydedildi",test.Kod+" / "+result.Durum+" / "+value.Not);t.Commit();return rid;
 }
 static void Version(DataRow row,byte[] version){if(!((byte[])row["Surum"]).SequenceEqual(version))throw new InvalidOperationException("Numune başka kullanıcı tarafından değişti. Yenileyin.");}
 public void Durum(long id,byte[] version,string next,string why)
 {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"LabServisi.Durum","",new object?[]{id,version,next,why});return;}

  Metin(why,2000,"İşlem gerekçesi");using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);string perm=next=="İncelemede"?"LAB.RESULT":next is "Serbest" or "İptal"?"LAB.RELEASE":"LAB.REVIEW";check(c,t,perm);
  var sample=Numune(c,t,id,true);Version(sample,version);string current=(string)sample["Durum"];var results=Sonuclar(c,t,id).AsEnumerable().ToArray();var latest=results.Where(r=>Convert.ToInt64(r["Sira"])==1).ToArray();var plan=Oku<LabPlan>((string)sample["PlanAnlik"]);
  bool all=plan.Testler.All(p=>latest.Any(r=>(string)r["TestKodu"]==p.Kod));using(var running=Q(c,t,"SELECT COUNT(*) FROM dbo.BERP260_LabGorev WHERE NumuneId=@id AND Bitis IS NULL",("@id",id)))if(next is "İncelemede" or "Onaylandı" or "Serbest" or "İptal"&&Convert.ToInt32(running.ExecuteScalar())>0)throw new InvalidOperationException("Devam eden test varken bu işlem yapılamaz.");
  if(next=="İncelemede"){if(current!="Çalışılıyor"||!all)throw new InvalidOperationException("Bütün plan testleri girilmeden incelemeye gönderilemez.");}
  else if(next is "Onaylandı" or "Reddedildi"){if(current!="İncelemede")throw new InvalidOperationException("Numune incelemede değil.");var makers=results.Select(r=>(int)r["Yapan"]).ToList();using(var works=Q(c,t,"SELECT Kullanici FROM dbo.BERP260_LabGorev WHERE NumuneId=@id",("@id",id))){using var rr=works.ExecuteReader();while(rr.Read())makers.Add(rr.GetInt32(0));}IncelemeDogrula(next,user,makers,latest.Select(r=>(string)r["Durum"]));if(next=="Onaylandı"&&!all)throw new InvalidOperationException("Eksik test var.");}
  else if(next=="Serbest"){if(current!="Onaylandı"||!all||latest.Any(r=>(string)r["Durum"]!="Uygun"))throw new InvalidOperationException("Yalnız tüm testleri uygun ve teknik onaylı numune serbest bırakılır.");}
  else if(next=="İptal"){if(current!="Çalışılıyor"||results.Length>0)throw new InvalidOperationException("Yalnız sonuç girilmemiş hatalı numune iptal edilebilir.");}
  else if(next=="Çalışılıyor"){if(current is not("İncelemede" or "Reddedildi" or "Onaylandı"))throw new InvalidOperationException("Bu numune yeniden çalışmaya açılamaz.");}
  else throw new ArgumentException("Durum geçişi geçersiz.");
  if(next is "Onaylandı" or "Serbest"){using var linked=Q(c,t,"SELECT COUNT(*) FROM dbo.BERP260_LabBag b JOIN dbo.BERP260_LabNumune p WITH(HOLDLOCK) ON p.Id=b.HammaddeNumune WHERE b.UrunNumune=@id AND p.Durum<>N'Serbest'",("@id",id));if(Convert.ToInt32(linked.ExecuteScalar())>0)throw new InvalidOperationException("Bağlı hammadde numuneleri serbest bırakılmadan ürün onaylanamaz.");}
  using(var q=Q(c,t,"UPDATE dbo.BERP260_LabNumune SET Durum=@n,Inceleyen=CASE WHEN @n IN(N'Onaylandı',N'Reddedildi') THEN @u WHEN @n=N'Çalışılıyor' THEN NULL ELSE Inceleyen END,IncelemeZamani=CASE WHEN @n IN(N'Onaylandı',N'Reddedildi') THEN SYSDATETIMEOFFSET() WHEN @n=N'Çalışılıyor' THEN NULL ELSE IncelemeZamani END,SerbestBirakan=CASE WHEN @n IN(N'Serbest',N'İptal') THEN @u ELSE SerbestBirakan END,SerbestZamani=CASE WHEN @n IN(N'Serbest',N'İptal') THEN SYSDATETIMEOFFSET() ELSE SerbestZamani END WHERE Id=@id",("@n",next),("@u",user),("@id",id)))q.ExecuteNonQuery();
  if(next is "Serbest" or "İptal"){using(var stock=Q(c,t,"SELECT Id FROM dbo.StokKartlari WITH(UPDLOCK,HOLDLOCK) WHERE Id=@s",("@s",sample["StokId"])))stock.ExecuteScalar();using var release=Q(c,t,"UPDATE dbo.BERP260_LabBloke SET Aktif=0 WHERE NumuneId=@id",("@id",id));release.ExecuteNonQuery();}
  Olay(c,t,id,current+" → "+next,why);t.Commit();
 }
 public long EkEkle(Guid key,long id,byte[] version,string path)
 {
  var f=new FileInfo(path);if(f.Length is <1 or >10485760)throw new ArgumentException("Dosya en fazla 10 MB olmalı.");
  return EkEkleVeri(key,id,version,Path.GetFileName(path),File.ReadAllBytes(path));
 }
 public long EkEkleVeri(Guid key,long id,byte[] version,string name,byte[] bytes)
 {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"LabServisi.EkEkleVeri","",new object?[]{key,id,version,name,bytes});}

  if(key==Guid.Empty||id<1||bytes is null||bytes.Length is <1 or >10485760||string.IsNullOrWhiteSpace(name)||name.Length>180||Path.GetFileName(name)!=name)throw new ArgumentException("Dosya adı veya boyutu geçersiz.");
  string ext=Path.GetExtension(name).ToLowerInvariant();
  if(ext is not(".pdf" or ".png" or ".jpg" or ".jpeg" or ".csv" or ".txt"))throw new ArgumentException("PDF, PNG, JPEG, CSV veya TXT ekleyin.");
  if(ext==".pdf")PdfDogrula(name,bytes);
string sha=Convert.ToHexString(SHA256.HashData(bytes));using var c=Ac();using var t=c.BeginTransaction();check(c,t,"LAB.RESULT");
  using(var old=Q(c,t,"SELECT Id,NumuneId,Sha256,Ad FROM dbo.BERP260_LabEk WHERE Anahtar=@k",("@k",key))){using var r=old.ExecuteReader();if(r.Read()){if(r.GetInt64(1)!=id||r.GetString(2)!=sha||r.GetString(3)!=name)throw new ArgumentException("Ek işlem anahtarı uyuşmuyor.");long oldId=r.GetInt64(0);r.Close();t.Commit();return oldId;}}
  var sample=Numune(c,t,id,true);Version(sample,version);if((string)sample["Durum"]!="Çalışılıyor")throw new InvalidOperationException("Onaya gönderilmiş numuneye ek eklenemez.");
  using var q=Q(c,t,"INSERT dbo.BERP260_LabEk(Anahtar,NumuneId,Ad,Tur,Veri,Sha256,Ekleyen) OUTPUT INSERTED.Id VALUES(@k,@id,@a,@t,@v,@h,@u)",("@k",key),("@id",id),("@a",name),("@t",ext),("@v",bytes),("@h",sha),("@u",user));long result=Convert.ToInt64(q.ExecuteScalar());using(var bump=Q(c,t,"UPDATE dbo.BERP260_LabNumune SET Aciklama=Aciklama WHERE Id=@id",("@id",id)))bump.ExecuteNonQuery();Olay(c,t,id,"Ham veri / rapor eklendi",name+" / SHA256 "+sha);t.Commit();return result;

 }
 public (string Ad,byte[] Veri) EkOku(long id){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<(string Ad,byte[] Veri)>(connection,"LabServisi.EkOku","",new object?[]{id});}
using var c=Ac();check(c,null,"LAB.EXPORT");using var q=Q(c,null,"SELECT Ad,Veri,Sha256 FROM dbo.BERP260_LabEk WHERE Id=@id",("@id",id));using var r=q.ExecuteReader();if(!r.Read())throw new ArgumentException("Ek bulunamadı.");byte[] bytes=(byte[])r[1];if(Convert.ToHexString(SHA256.HashData(bytes))!=r.GetString(2))throw new InvalidDataException("Ek bütünlük kontrolü başarısız.");return(r.GetString(0),bytes);}
 public void DisariAktarYetkisi(){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"LabServisi.DisariAktarYetkisi","",new object?[]{});return;}
using var c=Ac();check(c,null,"LAB.EXPORT");}
 public string EtiketHtml(long id,string company="")
 {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<string>(connection,"LabServisi.EtiketHtml","",new object?[]{id,company});}

  using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.RepeatableRead);check(c,t,"LAB.VIEW");check(c,t,"LAB.EXPORT");var s=Numune(c,t,id);string E(object v)=>System.Net.WebUtility.HtmlEncode(Convert.ToString(v)??"");string html="<!doctype html><html lang='tr'><meta charset='utf-8'><meta http-equiv='Content-Security-Policy' content=\"default-src 'none'; style-src 'unsafe-inline'; img-src data:\"><style>@page{margin:5mm}body{font:12px Arial}.label{width:75mm;overflow-wrap:anywhere;border:1px solid;padding:3mm;box-sizing:border-box}img{width:100%;height:15mm}</style><div class='label'><b>"+E(company)+" · Laboratuvar numunesi</b><p>"+E(s["StokKodu"])+" / "+E(s["StokAdi"])+"</p><img alt='Barkod' src='"+LabRapor.Barkod(id)+"'><b>LAB-"+id+"</b><p>"+E(s["Kaynak"])+" / "+E(s["KaynakBilgi"])+"<br>Kabul: "+E(s["Alindi"])+"</p><small>Etiket kalite uygunluk veya serbest bırakma belgesi değildir.</small></div></html>";Olay(c,t,id,"Numune etiketi açıldı","Etiket yazdırma / PDF önizleme");t.Commit();return html;
 }
 public long TestBaslat(Guid key,long id,byte[] version,string code,long device,DateTimeOffset end,string note)
 {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"LabServisi.TestBaslat","",new object?[]{key,id,version,code,device,end,note});}

  Metin(note,2000,"Test başlatma açıklaması / deney düzeneği");if(key==Guid.Empty)throw new ArgumentException("İşlem kimliği ve gelecekteki beklenen bitiş gerekli.");string digest=LisansKripto.Ozet(Yaz(new{id,code,device,end,note,user}));using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"LAB.RESULT");
  using(var old=Q(c,t,"SELECT Id,Ozet FROM dbo.BERP260_LabGorev WITH(UPDLOCK,HOLDLOCK) WHERE Anahtar=@k",("@k",key))){using var r=old.ExecuteReader();if(r.Read()){if(r.GetString(1)!=digest)throw new ArgumentException("Test başlatma anahtarı uyuşmuyor.");long prior=r.GetInt64(0);r.Close();t.Commit();return prior;}}
  if(end<=DateTimeOffset.UtcNow)throw new ArgumentException("Beklenen bitiş gelecekte olmalı.");var s=Numune(c,t,id,true);Version(s,version);if((string)s["Durum"]!="Çalışılıyor"||!Oku<LabPlan>((string)s["PlanAnlik"]).Testler.Any(x=>x.Kod==code))throw new ArgumentException("Çalışılan numuneden bir test seçin.");using(var d=Q(c,t,"SELECT COUNT(*) FROM dbo.BERP260_LabCihaz WITH(HOLDLOCK) WHERE Id=@id AND Kalibrasyon<=CONVERT(date,SYSUTCDATETIME()) AND Gecerlilik>=CONVERT(date,@end)",("@id",device),("@end",end.UtcDateTime.Date)))if(Convert.ToInt32(d.ExecuteScalar())!=1)throw new ArgumentException("Cihaz kalibrasyonu şimdi ve beklenen bitiş tarihinde geçerli olmalı.");using(var old=Q(c,t,"SELECT COUNT(*) FROM dbo.BERP260_LabGorev WHERE NumuneId=@id AND TestKodu=@k AND Bitis IS NULL",("@id",id),("@k",code)))if(Convert.ToInt32(old.ExecuteScalar())>0)throw new InvalidOperationException("Bu test zaten devam ediyor.");
  using var q=Q(c,t,"INSERT dbo.BERP260_LabGorev(Anahtar,Ozet,NumuneId,TestKodu,CihazId,BeklenenBitis,Kullanici,Aciklama) OUTPUT INSERTED.Id VALUES(@k,@h,@id,@code,@d,@end,@u,@n)",("@k",key),("@h",digest),("@id",id),("@code",code),("@d",device),("@end",end),("@u",user),("@n",note));long result=Convert.ToInt64(q.ExecuteScalar());using(var bump=Q(c,t,"UPDATE dbo.BERP260_LabNumune SET Aciklama=Aciklama WHERE Id=@id",("@id",id)))bump.ExecuteNonQuery();Olay(c,t,id,"Test başlatıldı",code+" / cihaz "+device+" / beklenen bitiş "+end.ToString("O")+" / "+note);t.Commit();return result;
 }
 public void TestIptal(long id,byte[] version,long work,string why)
 {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"LabServisi.TestIptal","",new object?[]{id,version,work,why});return;}

  Metin(why,2000,"Test durdurma gerekçesi");using var c=Ac();using var t=c.BeginTransaction();check(c,t,"LAB.REVIEW");var s=Numune(c,t,id,true);Version(s,version);if((string)s["Durum"]!="Çalışılıyor")throw new InvalidOperationException("Numune çalışılıyor durumunda olmalı.");using var q=Q(c,t,"UPDATE dbo.BERP260_LabGorev SET Bitis=SYSDATETIMEOFFSET(),Iptal=1 WHERE Id=@w AND NumuneId=@id AND Bitis IS NULL AND Kullanici<>@u",("@w",work),("@id",id),("@u",user));if(q.ExecuteNonQuery()!=1)throw new InvalidOperationException("Aktif test bulunamadı veya kendi başlattığınız testi durduramazsınız.");using(var bump=Q(c,t,"UPDATE dbo.BERP260_LabNumune SET Aciklama=Aciklama WHERE Id=@id",("@id",id)))bump.ExecuteNonQuery();Olay(c,t,id,"Test gerekçeyle durduruldu","Görev "+work+" / "+why);t.Commit();
 }
 public void HammaddeBagla(long child,byte[] version,long parent,string why)
 {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"LabServisi.HammaddeBagla","",new object?[]{child,version,parent,why});return;}

  Metin(why,2000,"Hammadde kullanım bildirimi / üretim belge dayanağı");if(child==parent)throw new ArgumentException("Numune kendine bağlanamaz.");using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"LAB.RESULT");var product=Numune(c,t,child,true);Version(product,version);if((string)product["Durum"]!="Çalışılıyor"||(string)product["Kaynak"] is not("Üretim emri" or "Sektör üretimi"))throw new ArgumentException("Bağlantı yalnız çalışılan üretim numunesine eklenir.");var raw=Numune(c,t,parent);if((string)raw["Kaynak"]!="Hammadde partisi")throw new ArgumentException("Kaynak bir hammadde partisi numunesi olmalı.");using var q=Q(c,t,"INSERT dbo.BERP260_LabBag(HammaddeNumune,UrunNumune,Kullanici,Aciklama) VALUES(@p,@c,@u,@n)",("@p",parent),("@c",child),("@u",user),("@n",why));q.ExecuteNonQuery();using(var bump=Q(c,t,"UPDATE dbo.BERP260_LabNumune SET Aciklama=Aciklama WHERE Id=@id",("@id",child)))bump.ExecuteNonQuery();Olay(c,t,child,"Hammadde bağlantısı bildirildi","LAB-"+parent+" / "+why+". Bildirimdir; otomatik parti bazlı tüketim hesabı değildir.");t.Commit();
 }
 public string RaporHtml(long id,string company="",string logo="")
 {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<string>(connection,"LabServisi.RaporHtml","",new object?[]{id,company,""});}

  using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"LAB.VIEW");check(c,t,"LAB.EXPORT");var sample=Numune(c,t,id);var results=Sonuclar(c,t,id);var audit=Table(Q(c,t,"SELECT Kullanici,Olay,Gerekce,Zaman FROM dbo.BERP260_LabOlay WHERE NumuneId=@id ORDER BY Id",("@id",id)));var files=Table(Q(c,t,"SELECT Ad,Sha256 FROM dbo.BERP260_LabEk WHERE NumuneId=@id ORDER BY Id",("@id",id)));var works=Table(Q(c,t,"SELECT * FROM dbo.BERP260_LabGorev WHERE NumuneId=@id ORDER BY Id",("@id",id)));var links=Table(Q(c,t,"SELECT * FROM dbo.BERP260_LabBag WHERE UrunNumune=@id OR HammaddeNumune=@id ORDER BY Id",("@id",id)));string html=LabRapor.Html(sample,results,audit,files,company,logo,works,links);Olay(c,t,id,"Rapor dışa aktarmaya açıldı","Ekran / PDF / yazıcı için tutarlı anlık kopya oluşturuldu.");t.Commit();return html;
 }
 public DataTable Trend(long planId,string code)
 {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"LabServisi.Trend","",new object?[]{planId,code});}

  using var c=Ac();check(c,null,"LAB.VIEW");var rows=Table(Q(c,null,"SELECT TOP(500) n.Id AS Numune,n.KaynakBilgi,r.Durum,r.Yapan,r.KayitZamani,r.Veri,r.Degerlendirme FROM dbo.BERP260_LabSonuc r JOIN dbo.BERP260_LabNumune n ON n.Id=r.NumuneId WHERE n.PlanId=@p AND r.TestKodu=@k AND NOT EXISTS(SELECT 1 FROM dbo.BERP260_LabSonuc newer WHERE newer.NumuneId=r.NumuneId AND newer.TestKodu=r.TestKodu AND newer.Id>r.Id) ORDER BY r.Id DESC",("@p",planId),("@k",code)));rows.Columns.Add("Ölçümler",typeof(string));rows.Columns.Add("Hesaplanan / ortalama (bilgi)",typeof(decimal));foreach(DataRow r in rows.Rows){var v=Oku<LabOlcum>((string)r["Veri"]);var d=Oku<LabDegerlendirme>((string)r["Degerlendirme"]);r["Ölçümler"]=string.Join("; ",v.Degerler)+v.Metin;if(v.Degerler.Length>0)r["Hesaplanan / ortalama (bilgi)"]=d.Hesaplanan??v.Degerler.Average();}rows.Columns.Remove("Veri");rows.Columns.Remove("Degerlendirme");return rows;
 }
}
