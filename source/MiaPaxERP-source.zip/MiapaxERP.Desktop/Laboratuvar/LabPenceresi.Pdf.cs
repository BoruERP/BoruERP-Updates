using System.Data;
using System.IO;
using System.Net;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
namespace MiapaxERP.Desktop.Laboratuvar;
public sealed partial class LabPenceresi
{
    async Task PdfBelgeleri()
    {
        if(Type is not("cihaz" or "numune"))throw new ArgumentException("Önce Numuneler veya Cihazlar / kalibrasyon listesinden bir kayıt seçin.");
        bool calibration=Type=="cihaz";var selected=Selected();long id=Convert.ToInt64(selected["Id"]);
        var w=Dialog(calibration?"Kalibrasyon PDF belgeleri":"Numune PDF belgeleri",1000,650);var root=new DockPanel{Margin=new Thickness(20)};w.Content=root;
        var bar=new WrapPanel();DockPanel.SetDock(bar,Dock.Top);root.Children.Add(bar);var state=new TextBlock{TextWrapping=TextWrapping.Wrap,Margin=new Thickness(4,10,4,10)};DockPanel.SetDock(state,Dock.Bottom);root.Children.Add(state);
        var records=new DataGrid{IsReadOnly=true,AutoGenerateColumns=true,CanUserAddRows=false,SelectionMode=DataGridSelectionMode.Single};root.Children.Add(records);
        bool working=false;
        async Task Load()
        {
            var table=await Task.Run(()=>calibration?db.CihazPdfListesi(id):db.Detay(id,"ek"));
            if(!calibration){var pdf=table.Clone();foreach(DataRow row in table.Rows)if(((string)row["Ad"]).EndsWith(".pdf",StringComparison.OrdinalIgnoreCase))pdf.ImportRow(row);table=pdf;}
            records.ItemsSource=table.DefaultView;state.Text=table.Rows.Count+" PDF. Dosyalar sunucuda saklanır; SHA256 ile bütünlükleri denetlenir.";
        }
        void Action(string title,Func<Task> action)
        {
            var b=new Button{Content=title,Padding=new Thickness(12,8,12,8),Margin=new Thickness(0,0,8,10)};bar.Children.Add(b);
            b.Click+=async(_,_)=>{if(working)return;working=true;bar.IsEnabled=false;try{await action();}catch(Exception e){state.Text=e.Message;}finally{working=false;bar.IsEnabled=true;}};
        }
        async Task<LabDosyaPaketi> Read()
        {
            if(records.SelectedItem is not DataRowView row)throw new ArgumentException("Listeden bir PDF seçin.");long document=Convert.ToInt64(row["Id"]);
            if(calibration)return await Task.Run(()=>db.CihazPdfOku(document));
            var file=await Task.Run(()=>db.EkOku(document));return new(file.Ad,file.Veri);
        }
        Action("PDF içe aktar",async()=>
        {
            var open=new OpenFileDialog{Filter="PDF belgesi|*.pdf",CheckFileExists=true};if(open.ShowDialog(w)!=true)return;
            if(new FileInfo(open.FileName).Length>10*1024*1024)throw new ArgumentException("PDF en fazla 10 MB olmalı.");
            string name=Path.GetFileName(open.FileName);byte[] bytes=await File.ReadAllBytesAsync(open.FileName);LabServisi.PdfDogrula(name,bytes);Guid key=Guid.NewGuid();
            if(calibration)await Task.Run(()=>db.CihazPdfEkle(key,id,name,bytes));
            else{var sample=await Task.Run(()=>db.Numune(id));await Task.Run(()=>db.EkEkleVeri(key,id,(byte[])sample["Surum"],name,bytes));}
            await Load();
        });
        Action("PDF dışa aktar",async()=>{var file=await Read();var save=new SaveFileDialog{Filter="PDF belgesi|*.pdf",FileName=file.Ad};if(save.ShowDialog(w)==true){await File.WriteAllBytesAsync(save.FileName,file.Veri);state.Text="PDF kaydedildi.";}});
        Action("PDF aç / yazdır",async()=>
        {
            var file=await Read();string folder=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"MiapaxERP","Laboratuvar","PdfOnizleme");Directory.CreateDirectory(folder);
            string path=Path.Combine(folder,Guid.NewGuid().ToString("N")+".pdf");await File.WriteAllBytesAsync(path,file.Veri);
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(path){UseShellExecute=true});state.Text="PDF görüntüleyici açıldı. Oradan yazdırabilirsiniz; geçici kopya bu cihazda kalır.";
        });
        Action("Kayıt özeti / PDF çıktı",async()=>
        {
            if(!calibration){string html=await Task.Run(()=>db.RaporHtml(id,company,logo));await LabRapor.Goster(w,html,db.DisariAktarYetkisi);return;}
            await Task.Run(db.DisariAktarYetkisi);var rows=await Task.Run(()=>db.CihazPdfListesi(id));string E(object? v)=>WebUtility.HtmlEncode(Convert.ToString(v)??"");
            var text=new StringBuilder("<!doctype html><html lang='tr'><meta charset='utf-8'><style>body{font:14px Arial;margin:28px}table{border-collapse:collapse;width:100%}td,th{border:1px solid #bbb;padding:9px}h1{color:#17446b}</style><h1>").Append(E(company.Length>0?company:"MiaPaxERP")).Append(" · Kalibrasyon kayıt özeti</h1><table>");
            foreach(DataColumn column in selected.Table.Columns)text.Append("<tr><th>").Append(E(column.ColumnName)).Append("</th><td>").Append(E(selected[column])).Append("</td></tr>");
            text.Append("</table><h2>Arşivdeki PDF belgeleri</h2><table><tr><th>Dosya</th><th>SHA256</th><th>Eklenme</th></tr>");foreach(DataRow row in rows.Rows)text.Append("<tr><td>").Append(E(row["DosyaAdi"])).Append("</td><td>").Append(E(row["Sha256"])).Append("</td><td>").Append(E(row["Eklenme"])).Append("</td></tr>");
            text.Append("</table><p>Bu çıktı kayıt özetidir. Kalibrasyon sertifikasının aslı PDF arşivindedir.</p></html>");await LabRapor.Goster(w,text.ToString(),db.DisariAktarYetkisi);
        });
        Action("Yenile",Load);await Load();w.ShowDialog();
    }
}
