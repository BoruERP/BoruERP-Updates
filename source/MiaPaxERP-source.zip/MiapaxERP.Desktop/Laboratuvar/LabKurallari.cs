using System.Globalization;
using System.Text.Json;
namespace MiapaxERP.Desktop.Laboratuvar;

public sealed record LabTest(string Kod,string Ad,string Yontem,string Birim,string Kosul,string Kural="",decimal? Alt=null,decimal? Ust=null,string Beklenen="",int Tekrar=0,string Hesap="Her ölçüm",string Baski="");
public sealed record LabPlan(string Ad,string Aile,string Sartname,string NumunePlani,LabTest[] Testler);
public sealed record LabOlcum(string TestKodu,decimal[] Degerler,string Metin,string Kosul,decimal? Belirsizlik,DateTimeOffset Zaman,long CihazId,string Not);
public sealed record LabDegerlendirme(string Durum,string Ozet,decimal? Hesaplanan=null);
public sealed record LabCihaz(string Kod,string Ad,DateTime Kalibrasyon,DateTime Gecerlilik,string Belge);
public static class LabKurallari
{
 public static readonly JsonSerializerOptions Json=new(JsonSerializerDefaults.Web);
 public static string Yaz<T>(T value)=>JsonSerializer.Serialize(value,Json);
 public static T Oku<T>(string value)=>JsonSerializer.Deserialize<T>(value,Json)??throw new ArgumentException("Laboratuvar kaydı okunamadı.");
 public static readonly string[] Aileler=["PE hammadde","PE boru","Damlama borusu","PVC-U boru","Diğer"];
 public static LabTest[] Sablon(string aile)=>aile switch{
  "PE hammadde"=>[T("MFR","Erime akış hızı","ISO 1133-1","g/10 min"),T("YOG","Yoğunluk","ISO 1183-1","kg/m³"),T("OIT","Oksidasyon indüksiyon süresi","ISO 11357-6","min"),T("CB","Karbon siyahı miktarı","ISO 6964","%"),T("DISP","Karbon siyahı / pigment dağılımı","ISO 18553","derece"),T("NEM","Nem / uçucu madde","Onaylı yöntem girilmeli","mg/kg"),T("KUL","Kül miktarı","ISO 3451 ilgili bölüm","%")],
  "PE boru"=>[T("CAP","Dış çap","ISO 3126","mm"),T("ET","Et kalınlığı","ISO 3126","mm"),T("BAS","İç basınca dayanım","ISO 1167","h"),T("UZAMA","Kopmada uzama","ISO 6259 ilgili bölüm","%"),T("BOY","Boyuna değişim","ISO 2505","%"),T("MFR","Erime akış hızı","ISO 1133-1","g/10 min"),T("OIT","Oksidasyon indüksiyon süresi","ISO 11357-6","min")],
  "Damlama borusu"=>[T("CAP","Çap","Onaylı ürün şartnamesi","mm"),T("ET","Et kalınlığı","Onaylı ürün şartnamesi","mm"),T("DEBI","Damlatıcı debisi","ISO 9261","L/h"),T("CV","Debi değişim katsayısı","ISO 9261","L/h") with{Hesap="CV (%)"},T("BAS","Basınca dayanım","ISO 9261","h")],
  "PVC-U boru"=>[T("CAP","Dış çap","ISO 3126","mm"),T("ET","Et kalınlığı","ISO 3126","mm"),T("DARBE","Darbe dayanımı","ISO 3127","%"),T("DCM","Diklorometan dayanımı","ISO 9852","sonuç"),T("BOY","Boyuna değişim","ISO 2505","%"),T("BAS","İç basınca dayanım","ISO 1167","h"),T("HALKA","Halka rijitliği (uygunsa)","ISO 9969","kN/m²")],
  _=>[T("OZEL","Özel test","Onaylı yöntem girilmeli","birim")]
 };
 static LabTest T(string code,string name,string method,string unit)=>new(code,name,method,unit,"");
 public static void Metin(string value,int max,string name){if(string.IsNullOrWhiteSpace(value)||value.Length>max||value.Any(c=>char.IsControl(c)&&c is not('\r' or '\n' or '\t')))throw new ArgumentException(name+" gerekli veya çok uzun.");}
 public static decimal Sayi(string value){if(!decimal.TryParse(value.Trim().Replace(',','.'),NumberStyles.AllowDecimalPoint|NumberStyles.AllowLeadingSign,CultureInfo.InvariantCulture,out var n)||Math.Abs(n)>100000000000m||decimal.Round(n,6)!=n)throw new ArgumentException("Sayı en fazla 6 ondalıklı olmalı; binlik ayırıcı kullanmayın.");return n;}
 public static void PlanDogrula(LabPlan p)
 {
  Metin(p.Ad,160,"Plan adı");Metin(p.Sartname,2000,"Ürün standardı/şartname sürümü ve karar kuralı dayanağı");Metin(p.NumunePlani,2000,"Numune alma sıklığı / rutin-tip-dış laboratuvar kapsamı");
  if(!Aileler.Contains(p.Aile)||p.Testler.Length is <1 or >60||p.Testler.Select(t=>t.Kod).Distinct(StringComparer.Ordinal).Count()!=p.Testler.Length)throw new ArgumentException("Test listesi/aile geçersiz.");
  foreach(var t in p.Testler){Metin(t.Kod,30,"Test kodu");if(t.Kod.Any(c=>!char.IsAsciiLetterOrDigit(c)&&c!='_'))throw new ArgumentException("Test kodunda harf, rakam ve alt çizgi kullanın.");Metin(t.Ad,160,"Test adı");Metin(t.Yontem,200,"Yöntem");Metin(t.Baski,100,"Yöntem baskısı / revizyonu");if(t.Yontem.StartsWith("Onaylı",StringComparison.Ordinal)||t.Yontem.Contains("ilgili bölüm",StringComparison.OrdinalIgnoreCase))throw new ArgumentException("Şablon yöntemini gerçek yöntem ve ilgili standart bölümüyle değiştirin.");Metin(t.Birim,30,"Birim");Metin(t.Kosul,2000,"Test koşulları");if(t.Tekrar is <1 or >100||t.Kural is not("Sayısal" or "Koruma bandı" or "Metin")||t.Hesap is not("Her ölçüm" or "Ortalama" or "CV (%)"))throw new ArgumentException("Kural, tekrar ve hesap şekli açıkça seçilmeli.");if(t.Kural=="Metin"){Metin(t.Beklenen,200,"Beklenen sonuç");if(t.Tekrar!=1||t.Hesap!="Her ölçüm"||t.Alt is not null||t.Ust is not null)throw new ArgumentException("Metin testinde tek sonuç kullanılır; sayısal limit girilmez.");}else{if(t.Alt is null&&t.Ust is null||t.Alt>t.Ust)throw new ArgumentException("Onaylı alt veya üst sınır gerekli.");foreach(var n in new[]{t.Alt,t.Ust}.OfType<decimal>())_=Sayi(n.ToString(CultureInfo.InvariantCulture));if(t.Hesap=="CV (%)"&&(t.Tekrar<2||t.Kural=="Koruma bandı"))throw new ArgumentException("CV için en az iki ölçüm gerekir. CV belirsizliği bu sürümde otomatik türetilmez.");}}
 }
 public static void CihazDogrula(LabCihaz c){Metin(c.Kod,40,"Cihaz kodu");Metin(c.Ad,160,"Cihaz adı");Metin(c.Belge,250,"Kalibrasyon/doğrulama belgesi ve kapsamı");if(c.Gecerlilik.Date<c.Kalibrasyon.Date||c.Kalibrasyon.Date>DateTime.UtcNow.Date)throw new ArgumentException("Kalibrasyon tarihleri geçersiz.");}
 public static LabDegerlendirme Degerlendir(LabTest test,LabOlcum o,LabCihaz cihaz,DateTimeOffset alindi,DateTimeOffset now)
 {
  if(o.TestKodu!=test.Kod||o.Not.Length>2000||o.Metin.Length>2000||o.Kosul.Length>2000)throw new ArgumentException("Test/sonuç alanı geçersiz.");
  if(o.Zaman<alindi||o.Zaman>now.AddMinutes(1))throw new ArgumentException("Ölçüm tarihi numune kabulünden önce veya gelecekte olamaz.");
  if(o.Zaman.UtcDateTime.Date<cihaz.Kalibrasyon.Date||o.Zaman.UtcDateTime.Date>cihaz.Gecerlilik.Date)throw new ArgumentException("Cihaz ölçüm tarihinde geçerli kalibrasyona sahip değil.");
  bool kosulUygun=o.Kosul.Trim()==test.Kosul.Trim();
  if(test.Kural=="Metin"){if(o.Degerler.Length!=0)throw new ArgumentException("Metin testine sayı girilmez.");Metin(o.Metin,2000,"Ölçülen sonuç");return new(!kosulUygun?"Belirsiz":o.Metin.Trim()==test.Beklenen.Trim()?"Uygun":"Uygunsuz","Onaylı metin sonucu ile birebir karşılaştırıldı.");}
  if(o.Degerler.Length!=test.Tekrar||o.Metin.Length>0)throw new ArgumentException("Onaylı planın tekrar sayısı kadar sayısal ölçüm girin.");foreach(var n in o.Degerler)_=Sayi(n.ToString(CultureInfo.InvariantCulture));
  if(test.Kural=="Koruma bandı"&&(o.Belirsizlik is null||o.Belirsizlik<0))throw new ArgumentException("Bu karar kuralı için genişletilmiş ölçüm belirsizliği gerekir.");
  if(test.Kural!="Koruma bandı"&&o.Belirsizlik is not null)throw new ArgumentException("Belirsizlik için koruma bandı kuralı seçilmiş plan kullanın.");
  if(o.Belirsizlik is decimal u)_=Sayi(u.ToString(CultureInfo.InvariantCulture));
  decimal mean=o.Degerler.Average();decimal[] values=o.Degerler;decimal? calculated=null;
  if(test.Hesap=="Ortalama"){calculated=mean;values=[mean];}
  if(test.Hesap=="CV (%)"){if(mean<=0)throw new ArgumentException("CV hesabında ortalama pozitif olmalı.");decimal variance=o.Degerler.Sum(x=>(x-mean)*(x-mean))/(o.Degerler.Length-1);calculated=Kok(variance)/mean*100;values=[calculated.Value];}
  string One(decimal x){var band=o.Belirsizlik??0;bool outside=test.Alt.HasValue&&x+band<test.Alt||test.Ust.HasValue&&x-band>test.Ust;bool inside=(!test.Alt.HasValue||x-band>=test.Alt)&&(!test.Ust.HasValue||x+band<=test.Ust);return outside?"Uygunsuz":inside?"Uygun":"Belirsiz";}
  var states=values.Select(One).ToArray();if(!kosulUygun)return new("Belirsiz","Gerçek koşul onaylı koşulla uyuşmuyor. Sapma incelemesi gerekli.",calculated);return new(states.Contains("Uygunsuz")?"Uygunsuz":states.Contains("Belirsiz")?"Belirsiz":"Uygun",test.Hesap+"; limitler dahil. CV: örnek standart sapma (n−1). Yuvarlanmamış değer karşılaştırılır.",calculated);
 }
 static decimal Kok(decimal x){if(x==0)return 0;decimal y=(decimal)Math.Sqrt((double)x);for(int i=0;i<12;i++)y=(y+x/y)/2;return y;}
 public static void IncelemeDogrula(string karar,int user,IEnumerable<int> yapanlar,IEnumerable<string> durumlar){if(yapanlar.Contains(user))throw new UnauthorizedAccessException("Kendi girdiğiniz test sonuçlarını onaylayamaz veya reddedemezsiniz.");if(karar is not("Onaylandı" or "Reddedildi"))throw new ArgumentException("İnceleme kararı geçersiz.");if(karar=="Onaylandı"&&(!durumlar.Any()||durumlar.Any(s=>s!="Uygun")))throw new InvalidOperationException("Tüm testler tamamlanıp uygun olmadan onaylanamaz.");}
}
