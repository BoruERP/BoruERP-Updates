using System.Data;
using System.Globalization;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
namespace MiapaxERP.Desktop;
public sealed partial class TicaretMerkezi
{
    void OdemeSekmesi()
    {
        var root=new DockPanel();var tools=new WrapPanel();var grid=Tablo();var summary=new TextBlock{Margin=new Thickness(8)};
        var date=new DatePicker{SelectedDate=DateTime.Today};var type=new ComboBox{ItemsSource=new[]{"Ödeme","İade"},SelectedIndex=0};
        var method=new ComboBox{ItemsSource=new[]{"Banka","Nakit","Kredi kartı","Pazaryeri","Diğer"},SelectedIndex=0};
        var amount=new TextBox{Width=110,ToolTip="Belgenin dövizinde tutar"};var doc=new TextBox{Width=150,MaxLength=120,ToolTip="Dekont / belge no"};
        var note=new TextBox{Width=180,MaxLength=320,ToolTip="Açıklama"};Guid key=Guid.NewGuid();
        void Load(){var row=Sec();var data=db.Odemeler((long)row["Id"]);grid.ItemsSource=data.DefaultView;decimal net=data.AsEnumerable().Sum(r=>(string)r["Tur"]=="İade"?-(decimal)r["Tutar"]:(decimal)r["Tutar"]);summary.Text=$"{row["Referans"]} • Belge: {row["Tutar"]:N2} • Net ödeme: {net:N2} • Kalan: {(decimal)row["Tutar"]-net:N2} {row["Doviz"]}";}
        foreach(var c in new Control[]{date,type,method,amount,doc,note}){c.Margin=new Thickness(4);tools.Children.Add(c);}
        Dugme(tools,"Seçili dosyanın ödemeleri",Load);
        Dugme(tools,"Ödeme / iade kaydet",()=>{if(!decimal.TryParse(amount.Text.Replace(',','.'),NumberStyles.AllowDecimalPoint,CultureInfo.InvariantCulture,out var n))throw new ArgumentException("Geçerli tutar girin.");db.Odeme(key,(long)Sec()["Id"],date.SelectedDate??throw new ArgumentException("Tarih seçin."),n,(string)type.SelectedItem,(string)method.SelectedItem,doc.Text.Trim(),note.Text.Trim());key=Guid.NewGuid();amount.Clear();doc.Clear();note.Clear();Load();});
        DockPanel.SetDock(tools,Dock.Top);root.Children.Add(tools);DockPanel.SetDock(summary,Dock.Top);root.Children.Add(summary);root.Children.Add(grid);
        liste.SelectionChanged+=(_,_)=>{grid.ItemsSource=null;summary.Text="Kayıtlar sekmesinden dosya seçin, ardından ödemeleri yükleyin.";key=Guid.NewGuid();amount.Clear();doc.Clear();note.Clear();};
        Tab("Ödeme ve iade",Tema170.Kart(root,"Dosya bazında ödeme takibi • muhasebe fişi oluşturmaz"));
    }
    void BelgeYazdir()
    {
        var r=Sec();var details=JsonSerializer.Deserialize<Dictionary<string,string>>((string)r["Detay"])??new();
        var document=new FlowDocument{PageWidth=793,PagePadding=new Thickness(40),FontFamily=new FontFamily("Segoe UI"),FontSize=11,ColumnWidth=700,Foreground=Brushes.Black,Background=Brushes.White};
        if(System.IO.File.Exists(Tema170.Mevcut.Logo))document.Blocks.Add(new BlockUIContainer(new System.Windows.Controls.Image{Source=GorunumDeposu.Resim(Tema170.Mevcut.Logo),Height=60,HorizontalAlignment=System.Windows.HorizontalAlignment.Left}));
        void P(string text,bool title=false)=>document.Blocks.Add(new Paragraph(new Run(text)){FontSize=title?21:11,Margin=new Thickness(0,5,0,5)});
        P(Tema170.Mevcut.FirmaBasligi,true);P(db.Akis.Ad+" • "+r["Referans"],true);
        P($"{r["Firma"]}  |  {(DateTime)r["Tarih"]:dd.MM.yyyy}  |  {r["Durum"]}");P(Convert.ToString(r["Baslik"])!);
        if(details.TryGetValue("Kalemler",out var json))foreach(var k in JsonSerializer.Deserialize<TicaretKalem[]>(json)??[])P($"{k.Kod} • {k.Urun} • {k.Adet:N3} {k.Birim} × {k.Fiyat:N2} • İndirim %{k.Indirim} • Vergi %{k.VergiOrani} • {k.Toplam():N2}");
        P($"Belge toplamı: {r["Tutar"]:N2} {r["Doviz"]}",true);
        foreach(var item in details.Where(x=>x.Key!="Kalemler"&&!string.IsNullOrWhiteSpace(x.Value)))P(item.Key+": "+item.Value);
        P(Convert.ToString(r["Aciklama"])!);P("MiapaxERP operasyon belgesi • Resmi fatura yerine geçmez.");
        var preview=new Window{Title="Belge önizleme / Yazdır / PDF",Width=900,Height=780,Owner=this};var root=new DockPanel();var bar=new WrapPanel();DockPanel.SetDock(bar,Dock.Top);root.Children.Add(bar);root.Children.Add(new FlowDocumentScrollViewer{Document=document});
        Dugme(bar,"Yazıcı seç / Microsoft Print to PDF",()=>{var dialog=new PrintDialog();if(dialog.ShowDialog()==true){document.PageWidth=dialog.PrintableAreaWidth;document.PageHeight=dialog.PrintableAreaHeight;dialog.PrintDocument(((IDocumentPaginatorSource)document).DocumentPaginator,"MiapaxERP "+r["Referans"]);}});preview.Content=root;preview.ShowDialog();
    }
}
