using System.IO;
using System.Text.Json;
using System.Windows;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.Wpf;
namespace MiapaxERP.Desktop;
public sealed class SahaPenceresi:Window
{
 readonly WebView2 web=new();readonly SahaServisi service;
 public SahaPenceresi(string connection,int user){LisansOturumu.Gerekli("CRM");service=new(connection,user);service.Kur();Title="Saha pazarlama · Türkiye / İl / İlçe / Köy";Width=1360;Height=880;WindowStartupLocation=WindowStartupLocation.CenterOwner;Content=web;Loaded+=Start;Closed+=(_,_)=>web.Dispose();}
 async void Start(object sender,RoutedEventArgs args){try{
  var env=await CoreWebView2Environment.CreateAsync(null,Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"MiapaxERP","SahaTarayici"));await web.EnsureCoreWebView2Async(env);
  web.CoreWebView2.SetVirtualHostNameToFolderMapping("saha.boruerp.local",Path.Combine(AppContext.BaseDirectory,"Assets","SahaWeb"),CoreWebView2HostResourceAccessKind.DenyCors);
  web.CoreWebView2.Settings.AreDevToolsEnabled=false;
  web.CoreWebView2.NavigationStarting+=(_,e)=>{if(!Local(e.Uri))e.Cancel=true;};web.CoreWebView2.NewWindowRequested+=(_,e)=>e.Handled=true;
  web.CoreWebView2.WebMessageReceived+=async(_,e)=>{if(!Local(e.Source))return;string? request=null;try{
   if(e.WebMessageAsJson.Length>24000)throw new ArgumentException("İstek çok büyük.");using var doc=JsonDocument.Parse(e.WebMessageAsJson);var b=doc.RootElement;request=b.GetProperty("request").GetString();var action=b.GetProperty("action").GetString();object? result=null;
   if(action=="list")result=await Task.Run(()=>service.Liste(b.GetProperty("il").GetString()!,b.GetProperty("ilce").GetString()!,b.GetProperty("koy").GetString()!));
   else if(action=="province")result=await Task.Run(()=>service.IlGorusmeleri(b.GetProperty("il").GetString()!,b.GetProperty("ilce").GetString(),b.GetProperty("search").GetString(),b.GetProperty("offset").GetInt32()));
   else if(action=="load")result=await Task.Run(()=>service.Oku(b.GetProperty("id").GetGuid()));
   else if(action=="save"){var data=b.GetProperty("data").Deserialize<SahaMusterisi>(SahaServisi.Json)!;await Task.Run(()=>service.Kaydet(data,b.GetProperty("version").ValueKind==JsonValueKind.Null?null:b.GetProperty("version").GetString(),b.GetProperty("visitId").GetGuid(),b.GetProperty("visitDate").GetDateTimeOffset(),b.GetProperty("visit").GetString()!));result=new{ok=true};}
   else if(action=="kroki"){LisansOturumu.Gerekli("KROKI");new Window{Owner=this,Title="Tarla krokisi",Width=1300,Height=850,Content=new KrokiYonetimi()}.Show();result=new{ok=true};}
   else throw new ArgumentException("İşlem tanınmadı.");
   web.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new{request,result},SahaServisi.Json));
  }catch(Exception ex){web.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new{request,error=ex.Message},SahaServisi.Json));}};
  web.Source=new Uri("https://saha.boruerp.local/index.html?v=2.8.1");
 }catch(Exception ex){Content=new System.Windows.Controls.TextBlock{Text="Saha ekranı açılamadı. WebView2 Runtime kurulumunu kontrol edin.\n"+ex.Message,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(24)};}}
 static bool Local(string uri)=>Uri.TryCreate(uri,UriKind.Absolute,out var u)&&u.Scheme=="https"&&u.Host=="saha.boruerp.local";
}
public partial class MainWindow{
 void SahaPazarlama_Click(object sender,RoutedEventArgs e){if(aktifKullanici is null){MessageBox.Show("Önce oturum açın.");return;}try{new SahaPenceresi(baglantiAdresi,aktifKullanici.KullaniciId){Owner=this}.ShowDialog();}catch(Exception ex){MessageBox.Show(ex.Message,"Saha pazarlama");}}
}
