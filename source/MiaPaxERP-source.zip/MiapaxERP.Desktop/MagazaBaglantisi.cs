using System.Globalization;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
namespace MiapaxERP.Desktop;
public record MagazaAyar(string Kanal,string Magaza,string Anahtar,string Gizli,string Entegrator = "");
public record MagazaSiparis(string Kimlik,string Numara,string Musteri,DateTime Tarih,decimal Tutar,string Doviz,string Durum,string Adres,string Urunler);
public record MagazaSayfa(MagazaSiparis[] Siparisler,string? Sonraki);
public static class MagazaBaglantisi
{
    public static readonly string[] Kanallar=["Trendyol","Hepsiburada","Shopify","WooCommerce"];
    public static void Kaydet(string folder,MagazaAyar a){Directory.CreateDirectory(folder);Dogrula(a);var bytes=ProtectedData.Protect(JsonSerializer.SerializeToUtf8Bytes(a),null,DataProtectionScope.CurrentUser);string path=Path.Combine(folder,a.Kanal+".dpapi");File.WriteAllBytes(path+".tmp",bytes);File.Move(path+".tmp",path,true);}
    public static MagazaAyar? Oku(string folder,string kanal){if(!Kanallar.Contains(kanal))throw new ArgumentException("Kanal geçersiz.");string p=Path.Combine(folder,kanal+".dpapi");return File.Exists(p)?JsonSerializer.Deserialize<MagazaAyar>(ProtectedData.Unprotect(File.ReadAllBytes(p),null,DataProtectionScope.CurrentUser)):null;}
    public static Uri Dogrula(MagazaAyar a)
    {
        if(!Kanallar.Contains(a.Kanal)||string.IsNullOrWhiteSpace(a.Magaza)||string.IsNullOrWhiteSpace(a.Anahtar)||a.Anahtar.Any(char.IsControl)||a.Gizli.Any(char.IsControl))throw new ArgumentException("Kanal, mağaza ve API bilgilerini girin.");
        if(a.Kanal!="Shopify" && string.IsNullOrWhiteSpace(a.Gizli))throw new ArgumentException("API gizli anahtarı gerekli.");
        if(a.Kanal=="Trendyol"){if(!a.Magaza.All(char.IsAsciiDigit))throw new ArgumentException("Trendyol satıcı numarası sayısal olmalı.");return new Uri("https://apigw.trendyol.com/");}
        if(a.Kanal=="Hepsiburada"){if(!Guid.TryParse(a.Magaza,out _))throw new ArgumentException("Hepsiburada merchantId bir UUID olmalı.");if(string.IsNullOrWhiteSpace(a.Entegrator)||a.Entegrator.Any(char.IsControl))throw new ArgumentException("Hepsiburada entegratör User-Agent bilgisini girin.");return new Uri("https://oms-external.hepsiburada.com/");}
        if(!Uri.TryCreate(a.Magaza.StartsWith("https://",StringComparison.OrdinalIgnoreCase)?a.Magaza:"https://"+a.Magaza,UriKind.Absolute,out var uri)||uri.Scheme!="https"||uri.IsLoopback||!string.IsNullOrEmpty(uri.UserInfo)||!string.IsNullOrEmpty(uri.Query)||!string.IsNullOrEmpty(uri.Fragment)||uri.AbsolutePath!="/"||!uri.IsDefaultPort)throw new ArgumentException("Mağazanın yalnızca HTTPS alan adını girin.");
        if(a.Kanal=="Shopify"&&!uri.Host.EndsWith(".myshopify.com",StringComparison.OrdinalIgnoreCase))throw new ArgumentException("Shopify için mağaza.myshopify.com alan adını girin.");return uri;
    }
    public static HttpRequestMessage Istek(MagazaAyar a,string? cursor)
    {
        var root=Dogrula(a);int page=0;if(a.Kanal!="Shopify"&&cursor!=null&&(!int.TryParse(cursor,out page)||page<0))throw new ArgumentException("Sayfa geçersiz.");
        string path=a.Kanal switch{
            "Trendyol"=>$"integration/order/sellers/{a.Magaza}/v2/orders?page={page}&size=100&orderByField=PackageLastModifiedDate&orderByDirection=DESC",
            "Hepsiburada"=>$"orders/merchantid/{a.Magaza}?offset={page*100}&limit=100",
            "WooCommerce"=>$"wp-json/wc/v3/orders?per_page=100&page={page+1}&orderby=date&order=desc",
            _=>"admin/api/2026-10/graphql.json"};
        var q=new HttpRequestMessage(a.Kanal=="Shopify"?HttpMethod.Post:HttpMethod.Get,new Uri(root,path));
        q.Headers.UserAgent.ParseAdd("MiapaxERP/1.8.1"); if(a.Kanal=="Hepsiburada"){q.Headers.UserAgent.Clear();q.Headers.TryAddWithoutValidation("User-Agent",a.Entegrator);}
        if(a.Kanal=="Shopify")
        {
            q.Headers.Add("X-Shopify-Access-Token",a.Anahtar);
            q.Content=new StringContent(JsonSerializer.Serialize(new{query="query($cursor:String){orders(first:100,after:$cursor,sortKey:CREATED_AT,reverse:true){nodes{id name createdAt displayFinancialStatus totalPriceSet{shopMoney{amount currencyCode}} shippingAddress{name formatted} lineItems(first:100){nodes{name quantity}}} pageInfo{hasNextPage endCursor}}}",variables=new{cursor}}),Encoding.UTF8,"application/json");
        }
        else {q.Headers.Authorization=new AuthenticationHeaderValue("Basic",Convert.ToBase64String(Encoding.UTF8.GetBytes(a.Anahtar+":"+a.Gizli)));if(a.Kanal=="Trendyol"){q.Headers.UserAgent.Clear();q.Headers.TryAddWithoutValidation("User-Agent",a.Magaza+" - MiapaxERP");}}
        return q;
    }
    public static async Task<MagazaSayfa> Getir(MagazaAyar a,string? cursor,CancellationToken ct)
    {
        using var client=new HttpClient(new HttpClientHandler{AllowAutoRedirect=false}){Timeout=TimeSpan.FromSeconds(45),MaxResponseContentBufferSize=10*1024*1024};using var req=Istek(a,cursor);using var response=await client.SendAsync(req,ct);
        if(!response.IsSuccessStatusCode)throw new InvalidOperationException($"{a.Kanal}: HTTP {(int)response.StatusCode}. API yetkilerini kontrol edin; 429 ise bir süre sonra tekrar deneyin.");
        return Coz(a.Kanal,await response.Content.ReadAsStringAsync(ct),cursor);
    }
    static JsonElement P(JsonElement j,string k)=>j.ValueKind==JsonValueKind.Object&&j.TryGetProperty(k,out var v)?v:default;
    static string S(JsonElement j,string k)=>P(j,k).ValueKind is JsonValueKind.Undefined or JsonValueKind.Null?"":P(j,k).ToString();
    static IEnumerable<JsonElement> A(JsonElement j)=>j.ValueKind==JsonValueKind.Array?j.EnumerateArray():[];
    static decimal N(string s)=>decimal.Parse(s,NumberStyles.Number,CultureInfo.InvariantCulture);
    static DateTime D(string s)=>DateTimeOffset.Parse(s,CultureInfo.InvariantCulture).LocalDateTime;
    public static MagazaSayfa Coz(string kanal,string json,string? cursor)
    {
        using var doc=JsonDocument.Parse(json);var r=doc.RootElement;var orders=new List<MagazaSiparis>();int page=cursor!=null&&int.TryParse(cursor,out var n)?n:0;string? next=null;
        if(kanal=="Shopify")
        {
            if(P(r,"errors").ValueKind!=JsonValueKind.Undefined)throw new InvalidDataException("Shopify sorguyu reddetti. Sipariş okuma yetkisini ve API sürümünü kontrol edin.");
            var data=P(P(r,"data"),"orders");if(data.ValueKind!=JsonValueKind.Object)throw new InvalidDataException("Shopify yanıtı geçersiz.");
            foreach(var o in A(P(data,"nodes"))){var money=P(P(o,"totalPriceSet"),"shopMoney");var addr=P(o,"shippingAddress");orders.Add(new(S(o,"id"),S(o,"name"),S(addr,"name"),D(S(o,"createdAt")),N(S(money,"amount")),S(money,"currencyCode"),S(o,"displayFinancialStatus"),string.Join(" ",A(P(addr,"formatted")).Select(x=>x.ToString())),string.Join("; ",A(P(P(o,"lineItems"),"nodes")).Select(x=>S(x,"name")+" × "+S(x,"quantity")))));}
            if(P(P(data,"pageInfo"),"hasNextPage").ValueKind==JsonValueKind.True)next=S(P(data,"pageInfo"),"endCursor");
        }
        else if(kanal=="Trendyol")
        {
            if(P(r,"content").ValueKind!=JsonValueKind.Array)throw new InvalidDataException("Trendyol sipariş yanıtı geçersiz.");
            foreach(var o in A(P(r,"content"))){var addr=P(o,"shipmentAddress");orders.Add(new(S(o,"id"),S(o,"orderNumber"),S(o,"customerFirstName")+" "+S(o,"customerLastName"),DateTimeOffset.FromUnixTimeMilliseconds(long.Parse(S(o,"orderDate"))).LocalDateTime,N(S(o,"totalPrice")),S(o,"currencyCode"),S(o,"status"),S(addr,"fullAddress"),string.Join("; ",A(P(o,"lines")).Select(x=>S(x,"productName")+" × "+S(x,"quantity")))));}
            if(page+1<int.Parse(S(r,"totalPages")))next=(page+1).ToString();
        }
        else if(kanal=="WooCommerce")
        {
            if(r.ValueKind!=JsonValueKind.Array)throw new InvalidDataException("WooCommerce sipariş yanıtı geçersiz.");
            foreach(var o in A(r)){var b=P(o,"billing");var a=P(o,"shipping");orders.Add(new(S(o,"id"),S(o,"number"),S(b,"first_name")+" "+S(b,"last_name"),D(S(o,"date_created")),N(S(o,"total")),S(o,"currency"),S(o,"status"),string.Join(" ",new[]{"address_1","address_2","city","state","postcode","country"}.Select(k=>S(a,k))),string.Join("; ",A(P(o,"line_items")).Select(x=>S(x,"name")+" × "+S(x,"quantity")))));}
            if(orders.Count==100)next=(page+1).ToString();
        }
        else if(kanal=="Hepsiburada")
        {
            if(P(r,"items").ValueKind!=JsonValueKind.Array)throw new InvalidDataException("Hepsiburada sipariş yanıtı geçersiz; satıcı API sözleşmesini kontrol edin.");
            foreach(var o in A(P(r,"items"))){var price=P(o,"totalPrice");var addr=P(o,"shippingAddress");orders.Add(new(S(o,"id"),S(o,"orderNumber"),S(o,"customerName"),D(S(o,"orderDate")),N(S(price,"amount")),S(price,"currency"),S(o,"status"),S(addr,"address"),S(o,"productName")+" × "+S(o,"quantity")));}
            if(orders.Count==100)next=(page+1).ToString();
        }
        else throw new ArgumentException("Kanal desteklenmiyor.");
        if(orders.Any(x=>string.IsNullOrWhiteSpace(x.Kimlik)||x.Tutar<0||string.IsNullOrWhiteSpace(x.Doviz)))throw new InvalidDataException("Siparişte kimlik, tutar veya döviz eksik.");
        return new(orders.ToArray(),next);
    }
    public static TicaretGirdi Girdi(MagazaAyar a,MagazaSiparis s)
    {
        string hash=Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(a.Kanal+"|"+Dogrula(a).Host+"|"+a.Magaza.Trim().ToLowerInvariant()+"|"+s.Kimlik)));
        string Cut(string v,int len)=>v.Length>len?v[..len]:v;
        return new(a.Kanal+"-"+hash[..48],"Pazaryeri siparişi",string.IsNullOrWhiteSpace(s.Musteri)?a.Kanal+" müşterisi":Cut(s.Musteri,160),Cut("Sipariş "+s.Numara,180),"",s.Tarih.Date,s.Tarih.Date,s.Tutar,s.Doviz,new(){["Kanal / mağaza"]=a.Kanal+" / "+a.Magaza,["Kaynak kimliği"]=s.Kimlik,["Kaynak sipariş no"]=s.Numara,["Kaynak durumu"]=s.Durum,["Teslimat adresi"]=s.Adres,["Ürünler ve adetleri"]=s.Urunler},"Mağazadan aktarıldı. Kaynak durumunu kontrol ederek MiapaxERP aşamalarını ilerletin.");
    }
}
