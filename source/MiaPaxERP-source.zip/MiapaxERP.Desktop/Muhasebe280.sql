SET XACT_ABORT ON;
BEGIN TRANSACTION;
DECLARE @lock int;EXEC @lock=sys.sp_getapplock @Resource=N'MiapaxERP.Muhasebe.280',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=15000;
IF @lock<0 THROW 51280,N'Muhasebe kurulum kilidi alınamadı.',1;
IF COL_LENGTH('dbo.BERP_Personel','IstenCikis') IS NULL ALTER TABLE dbo.BERP_Personel ADD IstenCikis date NULL;
IF OBJECT_ID('dbo.MPX280_Bordro','U') IS NULL
BEGIN
 CREATE TABLE dbo.MPX280_Bordro(Id bigint IDENTITY PRIMARY KEY,Anahtar uniqueidentifier NOT NULL UNIQUE,
 PersonelId int NOT NULL REFERENCES dbo.BERP_Personel(Id),CariId int NOT NULL REFERENCES dbo.CariKartlari(Id),
 Yil int NOT NULL,Ay int NOT NULL CHECK(Ay BETWEEN 1 AND 12),Girdi nvarchar(max) NOT NULL CHECK(ISJSON(Girdi)=1),Sonuc nvarchar(max) NOT NULL CHECK(ISJSON(Sonuc)=1),
 Brut decimal(18,2) NOT NULL,Net decimal(18,2) NOT NULL,Odenecek decimal(18,2) NOT NULL,
 Durum nvarchar(20) NOT NULL DEFAULT N'Taslak' CHECK(Durum IN(N'Taslak',N'Onaylandı',N'Ödendi',N'İptal')),
 Gerekce nvarchar(400) NOT NULL,Olusturan int NOT NULL,Onaylayan int NULL,Olusma datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET(),Surum rowversion,
 CariHareketId bigint NULL,FinansHareketId bigint NULL);
 CREATE UNIQUE INDEX UX_MPX280_Bordro_Donem ON dbo.MPX280_Bordro(PersonelId,Yil,Ay) WHERE Durum<>N'İptal';
 CREATE TABLE dbo.MPX280_BordroOlay(Id bigint IDENTITY PRIMARY KEY,BordroId bigint NOT NULL REFERENCES dbo.MPX280_Bordro(Id),Islem nvarchar(50) NOT NULL,Gerekce nvarchar(400) NOT NULL,Kullanici int NOT NULL,Zaman datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET());
END;
IF COL_LENGTH('dbo.MPX280_Bordro','AvansCariHareketId') IS NULL ALTER TABLE dbo.MPX280_Bordro ADD AvansCariHareketId bigint NULL;
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID('dbo.MPX280_Bordro') AND name='UX_MPX280_Bordro_Avans') EXEC(N'CREATE UNIQUE INDEX UX_MPX280_Bordro_Avans ON dbo.MPX280_Bordro(AvansCariHareketId) WHERE AvansCariHareketId IS NOT NULL AND Durum<>N''İptal''');
INSERT dbo.Yetkiler(YetkiKodu,Modul,Islem,Aciklama,Aktif)
SELECT p.Kod,N'İnsan Kaynakları',p.Islem,p.Aciklama,1 FROM(VALUES
('HR.PAYROLL.VIEW',N'Bordro görüntüle',N'Ücret ve kesinti bilgilerine erişim'),
('HR.PAYROLL.EDIT',N'Bordro hazırla',N'Net/brüt ücret bordrosu hazırlama'),
('HR.PAYROLL.APPROVE',N'Bordro onayla',N'Ücret tahakkuku ve personel cari bağlantısı'),
('HR.PAYROLL.PAY',N'Bordro öde',N'Kasa/bankadan personel ücret ödemesi'),
('HR.PAYROLL.CANCEL',N'Bordro iptal',N'Ödenmemiş bordro tahakkukunu ters kayıtla iptal'),
('HR.PAYROLL.REVERSE',N'Bordro ödeme ters kaydı',N'Ücret ödemesini kasa/banka ve cari ters kaydıyla düzeltme'))p(Kod,Islem,Aciklama)
WHERE NOT EXISTS(SELECT 1 FROM dbo.Yetkiler y WHERE y.YetkiKodu=p.Kod);
COMMIT;
