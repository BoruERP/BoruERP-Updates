SET XACT_ABORT ON;
BEGIN TRANSACTION;
DECLARE @lock int;
EXEC @lock=sys.sp_getapplock @Resource=N'MiapaxERP.Moduller180',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=15000;
IF @lock<0 THROW 51000,N'Kurulum kilidi alınamadı.',1;
IF OBJECT_ID('dbo.BERP_Sema','U') IS NULL CREATE TABLE dbo.BERP_Sema(Surum int PRIMARY KEY,Tarih datetime2 NOT NULL DEFAULT SYSUTCDATETIME());
IF NOT EXISTS(SELECT 1 FROM dbo.BERP_Sema WHERE Surum=180)
BEGIN
 DECLARE @name sysname, @sql nvarchar(max);
 DECLARE checks CURSOR LOCAL FAST_FORWARD FOR SELECT name FROM sys.check_constraints WHERE parent_object_id=OBJECT_ID('dbo.BERP_TicaretDosya') AND CHARINDEX(N'Modul',definition)>0;
 OPEN checks; FETCH NEXT FROM checks INTO @name;
 WHILE @@FETCH_STATUS=0 BEGIN SET @sql=N'ALTER TABLE dbo.BERP_TicaretDosya DROP CONSTRAINT '+QUOTENAME(@name);EXEC sys.sp_executesql @sql;FETCH NEXT FROM checks INTO @name;END;
 CLOSE checks; DEALLOCATE checks;
 ALTER TABLE dbo.BERP_TicaretDosya WITH CHECK ADD CONSTRAINT CK_BERP_Modul180 CHECK(Modul IN ('CRM','ECOM','TRADE','SALES','PURCHASE'));
 CREATE TABLE dbo.BERP_TicaretOdeme(Id bigint IDENTITY PRIMARY KEY,Anahtar uniqueidentifier NOT NULL UNIQUE,DosyaId bigint NOT NULL REFERENCES dbo.BERP_TicaretDosya(Id),Tarih date NOT NULL,Tutar decimal(18,2) NOT NULL CHECK(Tutar>0),Tur nvarchar(20) NOT NULL CHECK(Tur IN(N'Ödeme',N'İade')),Yontem nvarchar(40) NOT NULL,Belge nvarchar(120) NOT NULL,Aciklama nvarchar(320) NOT NULL,KullaniciId int NOT NULL);
 CREATE INDEX IX_BERP_OdemeDosya ON dbo.BERP_TicaretOdeme(DosyaId);
 INSERT dbo.BERP_Sema(Surum) VALUES(180);
END;
INSERT dbo.Yetkiler(YetkiKodu,Modul,Islem,Aciklama,Aktif)
SELECT m.Kod+'.'+p.Kod,m.Ad,p.Ad,m.Ad+' '+p.Ad,1
FROM (VALUES('SALES',N'Satış'),('PURCHASE',N'Satın alma'),('ECOM',N'E-ticaret'),('TRADE',N'Dış ticaret')) m(Kod,Ad)
CROSS JOIN (VALUES('VIEW',N'Görüntüle'),('EDIT',N'Kaydet'),('APPROVE',N'Onayla'),('PAYMENT',N'Ödeme işlemi')) p(Kod,Ad)
WHERE NOT EXISTS(SELECT 1 FROM dbo.Yetkiler WHERE YetkiKodu=m.Kod+'.'+p.Kod);
COMMIT;
