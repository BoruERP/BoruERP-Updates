using System.Windows;
namespace MiapaxERP.Desktop;
public partial class MainWindow
{
    void UzakCalismaAc_Click(object sender,RoutedEventArgs e)
    {
        try {new BaglantiAyarlariPenceresi{Owner=this}.ShowDialog();}
        catch(Exception ex){MessageBox.Show(ex.Message,"MiaPaxERP bağlantısı");}
    }
}
