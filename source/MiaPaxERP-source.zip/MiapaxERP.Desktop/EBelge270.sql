SET XACT_ABORT ON;
BEGIN TRANSACTION;
DECLARE @lock int;
EXEC @lock=sys.sp_getapplock @Resource=N'MiapaxERP.EBelge.270',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=15000;
IF @lock<0 THROW 51270,N'E-belge kurulum kilidi alınamadı.',1;
IF OBJECT_ID(N'dbo.Yetkiler',N'U') IS NULL THROW 51270,N'Önce ana yetki tabloları kurulmalıdır.',1;
INSERT dbo.Yetkiler(YetkiKodu,Modul,Islem,Aciklama,Aktif)
SELECT p.Kod,N'Muhasebe',p.Islem,p.Aciklama,1 FROM(VALUES
 ('FINANCE.EBELGE.VIEW',N'Görüntüle',N'E-belge merkezi ve gönderim geçmişi'),
 ('FINANCE.EBELGE.CONFIG',N'Ayar',N'E-belge şifreli servis bağlantısı'),
 ('FINANCE.EBELGE.QUERY',N'Sorgula',N'Sağlayıcı belge ve mükellef sorguları'),
 ('FINANCE.EBELGE.DRAFT',N'Taslak',N'UBL hazırlama ve sağlayıcıya taslak gönderme'),
 ('FINANCE.EBELGE.DOWNLOAD',N'İndir',N'E-belge XML ve PDF indirme')
)p(Kod,Islem,Aciklama) WHERE NOT EXISTS(SELECT 1 FROM dbo.Yetkiler y WHERE y.YetkiKodu=p.Kod);
IF OBJECT_ID(N'dbo.BERP270_EBelge',N'U') IS NULL
BEGIN
 CREATE TABLE dbo.BERP270_EBelge(
  Id bigint IDENTITY PRIMARY KEY, Ortam varchar(10) NOT NULL CHECK(Ortam IN('Test','Canli')),
  Vkn varchar(11) NOT NULL, Ettn uniqueidentifier NOT NULL, BelgeNo varchar(16) NOT NULL, BelgeTarihi date NOT NULL,
  AppType int NOT NULL CHECK(AppType IN(1,3,5)), Alici varchar(11) NOT NULL,
  KaynakEtiket nvarchar(250) NOT NULL, HedefEtiket nvarchar(250) NOT NULL,
  YerelId varchar(100) NOT NULL, Xml nvarchar(max) NOT NULL, Ozet char(64) NOT NULL,
  Durum nvarchar(40) NOT NULL DEFAULT N'Hazır', Sonuc nvarchar(1000) NOT NULL DEFAULT N'',
  Olusturan int NOT NULL, Olusma datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET(),
  Guncelleme datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET(), Surum rowversion,
  CONSTRAINT UX_EBelge_Ettn UNIQUE(Ortam,Vkn,Ettn),
  CONSTRAINT UX_EBelge_No UNIQUE(Ortam,Vkn,BelgeNo),
  CONSTRAINT UX_EBelge_Local UNIQUE(Ortam,Vkn,YerelId),
  CHECK(Durum IN(N'Hazır',N'Gönderim başladı',N'Taslak kabul edildi',N'Belirsiz',N'Reddedildi',N'Sağlayıcıda bulundu'))
 );
 CREATE TABLE dbo.BERP270_EBelgeOlay(Id bigint IDENTITY PRIMARY KEY,BelgeId bigint NOT NULL REFERENCES dbo.BERP270_EBelge(Id),Kullanici int NOT NULL,Islem nvarchar(100) NOT NULL,Aciklama nvarchar(1000) NOT NULL,Zaman datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET());
END;
COMMIT;
