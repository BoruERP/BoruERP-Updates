using System.Data;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed partial class YardimciEkranServisi{
public string VeritabaniAdi(){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<string>(connection,"YardimciEkranServisi.VeritabaniAdi","",new object?[]{});}
using var c=access.Ac();Yonetici(c,null);return c.Database;}
public int VeriSifirla(bool stok,bool ticari,string veritabani,string onay,bool yedek){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<int>(connection,"YardimciEkranServisi.VeriSifirla","",new object?[]{stok,ticari,veritabani,onay,yedek});}

if(!stok&&!ticari||!yedek||onay!="VERILERI SIL")throw new ArgumentException("Modül, yedek ve silme onayı gerekli.");
using var con=access.Ac();using var tran=con.BeginTransaction(IsolationLevel.Serializable);Yonetici(con,tran);if(con.Database!=veritabani)throw new ArgumentException("Veritabanı adı uyuşmuyor.");
using(var q=Q(con,tran,"IF OBJECT_ID('dbo.MPX310_Fis') IS NOT NULL EXEC(N'SELECT COUNT(*) FROM dbo.MPX310_Fis');ELSE SELECT 0;"))if(Convert.ToInt32(q.ExecuteScalar())>0)throw new InvalidOperationException("Kesin muhasebe geçmişi olan veritabanı sıfırlanamaz. Ayrı sunum/test veritabanı oluşturun.");
                var stock = new[] { "UretimEmriReceteAnlikKalemleri", "UretimPaketlemeKayitlari",
                    "UretimGunlukKayitlari", "StokHareketleri", "UretimStokIslemleri",
                    "UretimEmirleri", "UretimReceteKalemleri", "UretimReceteleri",
                    "UrunGorselleri", "StokOzellikDegerleri", "StokKategoriSecimleri",
                    "StokBakiyeleri", "StokKartlari", "StokKategorileri", "StokOzellikTanimlari",
                    "StokAlimKayitlari", "StokFiyatlari", "StokAileleri", "PiyasaFiyatlari" };
                var commerce = new[] { "CekSenetDurumGecmisi", "CekSenetler", "PlanliOdemeler",
                    "BoruERP_YeniBelgeKalemleri", "BoruERP_YeniBelgeler", "BoruERP_YeniMasraflar",
                    "BoruERP_GelenEFaturalar", "TicariBelgeler", "FinansHareketleri",
                    "CariHareketleri", "FinansHesaplari", "CariKartlari" };
                var chosen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                if (stok) foreach (var s in stock) chosen.Add(s);
                if (ticari) foreach (var s in commerce) chosen.Add(s);
                    // Yalnızca mevcut tabloları kullan; seçili olmayan tablodan FK varsa silmeyi reddet.
                    var present = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    using (var cmd = new SqlCommand("SELECT name FROM sys.tables WHERE schema_id=SCHEMA_ID('dbo')", con, tran))
                    using (var rd = cmd.ExecuteReader()) while (rd.Read()) present.Add(rd.GetString(0));
                    chosen.IntersectWith(present);
                    var edges = new List<(string child,string parent)>();
                    using (var cmd = new SqlCommand(@"SELECT OBJECT_NAME(parent_object_id), OBJECT_NAME(referenced_object_id)
 FROM sys.foreign_keys WHERE is_disabled=0", con, tran))
                    using (var rd = cmd.ExecuteReader()) while (rd.Read())
                        edges.Add((rd.GetString(0), rd.GetString(1)));
                    foreach (var relation in edges)
                        if (chosen.Contains(relation.parent) && !chosen.Contains(relation.child))
                            throw new InvalidOperationException("Seçilmeyen '" + relation.child + "' tablosu, silinecek '" + relation.parent + "' tablosuna bağlı. İlgili modülleri birlikte seçin.");
                    // Bağımlı (child) tablolar önce silinir. Döngüsel FK varsa işlem güvenli biçimde iptal edilir.
                    var pending = new HashSet<string>(chosen, StringComparer.OrdinalIgnoreCase);
                    var ordered = new List<string>();
                    while (pending.Count > 0)
                    {
                        string? next = pending.FirstOrDefault(name => !edges.Any(relation =>
                            relation.parent.Equals(name, StringComparison.OrdinalIgnoreCase) &&
                            pending.Contains(relation.child) && !relation.child.Equals(name, StringComparison.OrdinalIgnoreCase)));
                        if (next == null) throw new InvalidOperationException("Döngüsel veya kendi kendine bağlı tablo ilişkisi var; sıfırlama iptal edildi.");
                        ordered.Add(next); pending.Remove(next);
                    }
                    foreach (var name in ordered)
                    {
                        // Tablo adları yalnızca yukarıdaki sabit listeden gelir.
                        using var cmd = new SqlCommand("DELETE FROM dbo.[" + name + "]", con, tran);
                        cmd.CommandTimeout = 120;
                        cmd.ExecuteNonQuery();
                    }
                    tran.Commit();return ordered.Count;
}
}