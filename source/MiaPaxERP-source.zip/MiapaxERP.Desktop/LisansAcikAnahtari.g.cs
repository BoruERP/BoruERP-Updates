namespace MiapaxERP.Desktop; public static class LisansAcikAnahtari { public const string Pem = """
-----BEGIN PUBLIC KEY-----
MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAumj2n4raagEYQkSJRL9w
yRzLqPyieU21UqCzBrb+N5Ny1MNeSQwo26xKTGmgXp7dsvctlAfGSA9kcX9vjb/K
UqQvLrp6PdtVmCvotB59RtRmyFWiSPZP1hMzsbL2OCVf/S6uMj24LE38FeKIgfzR
zF8cL9tKOiI+xCD5IwTV3zFokqkBmPlJagZ9BcDaKoDoY82KCC+d7QAG0PeI7f2P
oxw2TXygMGWYr5BDmDW8YwpiDM/r+3uGBDr9natYz8Y1kkjRvdoR1v/IeKL0Mf2v
CPaMfE8ltpuOWBw5L047UbA6ntK5c9viL29vlXlW5UJo6Do7M5GiFkLkbl7Fisuz
M3aU6hxgrqZ9xsirwuL/Dh5tjdrTAdnYcPE2pFXZyHnjO6vcmGKZ1CU26jFjivGb
EkZmqbrxQy+ut6/EHN7Y7HFqgstNW+VGcnfwyxT+6MtOj6tsX+ycM2phb/JdGCWe
jc3sy3KUQn24PkIKMRT3TuG28O0rp8sVvlh496mOeJ0pAgMBAAE=
-----END PUBLIC KEY-----
"""; }