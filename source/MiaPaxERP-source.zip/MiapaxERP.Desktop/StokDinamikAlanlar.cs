using SqlConnection = MiapaxERP.Desktop.ErpSqlConnection;
using SqlCommand = MiapaxERP.Desktop.ErpSqlCommand;
using SqlTransaction = MiapaxERP.Desktop.ErpSqlTransaction;
using SqlDataReader = MiapaxERP.Desktop.ErpSqlReader;
using SqlDataAdapter = MiapaxERP.Desktop.ErpSqlDataAdapter;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;

namespace MiapaxERP.Desktop
{
    // MainWindow'ın ayrı bir partial sınıfı; mevcut stok, üretim ve reçete kodlarına dokunmaz.
    public partial class MainWindow
    {
        private bool _stokSiniflandirmaYukleniyor;
        private int? _stokOzellikleriStokId;
        private readonly Dictionary<int, DinamikStokAlani> _stokDinamikAlanlar = new();
        private sealed record StokKategoriSecim(int Id, bool Boru, string Ad);
        private sealed class DinamikStokAlani
        {
            public int Id { get; init; }
            public string Ad { get; init; } = "";
            public string Tur { get; init; } = "";
            public bool Zorunlu { get; init; }
            public Control Kontrol { get; init; } = null!;
        }

        private static string ComboAd(ComboBox combo) =>
            (combo.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "";
        private static int? ComboId(ComboBox combo) =>
            (combo.SelectedItem as ComboBoxItem)?.Tag is int id ? id : null;
        private static StokKategoriSecim? SeciliKategori(ComboBox combo) =>
            (combo.SelectedItem as ComboBoxItem)?.Tag as StokKategoriSecim;
        private int? StokSeciliKategoriId => SeciliKategori(CmbStokAltKategori)?.Id ?? SeciliKategori(CmbStokKategori)?.Id;
        private static ComboBoxItem ComboSatiri(string ad, object tag) => new() { Content = ad, Tag = tag };

        private void StokDinamikBagla()
        {
            CmbStokTipi.SelectionChanged += (_, _) =>
            {
                if (_stokSiniflandirmaYukleniyor) return;
                _stokOzellikleriStokId = null;
                StokKategorileriniYukle();
            };
            CmbStokKategori.SelectionChanged += (_, _) =>
            {
                if (_stokSiniflandirmaYukleniyor) return;
                _stokOzellikleriStokId = null;
                StokAltKategorileriniYukle();
            };
            CmbStokAltKategori.SelectionChanged += (_, _) =>
            {
                if (_stokSiniflandirmaYukleniyor) return;
                _stokOzellikleriStokId = null;
                StokOzelAlanlariYukle();
            };
        }

        private void StokTipleriniYukle(string? ilkSecim = null)
        {
            if (DemoModu) return;
            string? filtre = ComboAd(CmbStokFiltre);
            _stokSiniflandirmaYukleniyor = true;
            try
            {
                using var con = new SqlConnection(baglantiAdresi);
                con.Open();
                CmbStokTipi.Items.Clear();
                CmbStokFiltre.Items.Clear();
                CmbStokFiltre.Items.Add(ComboSatiri("Tümü", 0));
                using var cmd = new SqlCommand("SELECT Id,Ad FROM dbo.StokTipleri WHERE Aktif=1 ORDER BY Id", con);
                using var rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    var id = rd.GetInt32(0);
                    var ad = rd.GetString(1);
                    CmbStokTipi.Items.Add(ComboSatiri(ad, id));
                    CmbStokFiltre.Items.Add(ComboSatiri(ad, id));
                }
                if (!string.IsNullOrWhiteSpace(ilkSecim)) ComboSec(CmbStokTipi, ilkSecim);
                else if (CmbStokTipi.Items.Count > 0) CmbStokTipi.SelectedIndex = 0;
                ComboSec(CmbStokFiltre, filtre ?? "Tümü");
                if (CmbStokFiltre.SelectedIndex < 0) CmbStokFiltre.SelectedIndex = 0;
            }
            finally { _stokSiniflandirmaYukleniyor = false; }
            StokKategorileriniYukle();
        }

        private void StokKategorileriniYukle(int? secilecekKokId = null)
        {
            if (DemoModu) return;
            _stokSiniflandirmaYukleniyor = true;
            try
            {
                CmbStokKategori.Items.Clear();
                CmbStokAltKategori.Items.Clear();
                CmbStokKategori.Items.Add(ComboSatiri("(Kategori seçilmedi)", 0));
                int? tipId = ComboId(CmbStokTipi);
                if (tipId.HasValue)
                {
                    using var con = new SqlConnection(baglantiAdresi);
                    con.Open();
                    using var cmd = new SqlCommand(@"SELECT Id,Ad,BoruOzellikleri FROM dbo.StokKategorileri
WHERE StokTipId=@Tip AND UstKategoriId IS NULL AND Aktif=1 ORDER BY Ad", con);
                    cmd.Parameters.Add("@Tip", SqlDbType.Int).Value = tipId.Value;
                    using var rd = cmd.ExecuteReader();
                    while (rd.Read())
                        CmbStokKategori.Items.Add(ComboSatiri(rd.GetString(1),
                            new StokKategoriSecim(rd.GetInt32(0), rd.GetBoolean(2), rd.GetString(1))));
                }
                CmbStokKategori.SelectedIndex = 0;
                if (secilecekKokId.HasValue)
                    foreach (ComboBoxItem ci in CmbStokKategori.Items)
                        if (ci.Tag is StokKategoriSecim c && c.Id == secilecekKokId.Value)
                        { CmbStokKategori.SelectedItem = ci; break; }
            }
            finally { _stokSiniflandirmaYukleniyor = false; }
            StokAltKategorileriniYukle();
        }

        private void StokAltKategorileriniYukle(int? secilecekAltId = null)
        {
            if (DemoModu) return;
            _stokSiniflandirmaYukleniyor = true;
            try
            {
                CmbStokAltKategori.Items.Clear();
                CmbStokAltKategori.Items.Add(ComboSatiri("(Alt kategori yok)", 0));
                StokKategoriSecim? ust = SeciliKategori(CmbStokKategori);
                if (ust != null)
                {
                    using var con = new SqlConnection(baglantiAdresi);
                    con.Open();
                    using var cmd = new SqlCommand(@"SELECT Id,Ad,BoruOzellikleri FROM dbo.StokKategorileri
WHERE UstKategoriId=@Ust AND StokTipId=@Tip AND Aktif=1 ORDER BY Ad", con);
                    cmd.Parameters.Add("@Ust", SqlDbType.Int).Value = ust.Id;
                    cmd.Parameters.Add("@Tip", SqlDbType.Int).Value = ComboId(CmbStokTipi) ?? -1;
                    using var rd = cmd.ExecuteReader();
                    while (rd.Read()) CmbStokAltKategori.Items.Add(ComboSatiri(rd.GetString(1),
                        new StokKategoriSecim(rd.GetInt32(0), rd.GetBoolean(2), rd.GetString(1))));
                }
                CmbStokAltKategori.SelectedIndex = 0;
                if (secilecekAltId.HasValue)
                    foreach (ComboBoxItem ci in CmbStokAltKategori.Items)
                        if (ci.Tag is StokKategoriSecim c && c.Id == secilecekAltId.Value)
                        { CmbStokAltKategori.SelectedItem = ci; break; }
            }
            finally { _stokSiniflandirmaYukleniyor = false; }
            StokOzelAlanlariYukle();
        }

        private void StokOzelAlanlariYukle()
        {
            if (DemoModu) return;
            bool ham = string.Equals(ComboAd(CmbStokTipi), "Hammadde", StringComparison.OrdinalIgnoreCase);
            var secili = SeciliKategori(CmbStokAltKategori) ?? SeciliKategori(CmbStokKategori);
            bool boru = !ham && (secili?.Boru == true || SeciliKategori(CmbStokKategori)?.Boru == true);
            bool boruSektoru=(LisansOturumu.Gecerli?.Sector??gorunum.Sektor)=="BORU";
            PanelBoruOzellikleri.Visibility = boru&&boruSektoru ? Visibility.Visible : Visibility.Collapsed;
            PanelHammaddeOzellikleri.Visibility = ham&&boruSektoru ? Visibility.Visible : Visibility.Collapsed;
            PanelDinamikOzellikler.Children.Clear();
            _stokDinamikAlanlar.Clear();
            int? tipId = ComboId(CmbStokTipi);
            if (!tipId.HasValue) return;
            using var con = new SqlConnection(baglantiAdresi);
            con.Open();
            using var cmd = new SqlCommand(@"SELECT Id,AlanAdi,AlanTuru,Secenekler,Zorunlu
FROM dbo.StokOzellikTanimlari
WHERE StokTipId=@Tip AND Aktif=1
AND (KategoriId IS NULL OR KategoriId=@Kok OR KategoriId=@Alt)
ORDER BY KategoriId,Id", con);
            cmd.Parameters.Add("@Tip", SqlDbType.Int).Value = tipId.Value;
            cmd.Parameters.Add("@Kok", SqlDbType.Int).Value = (object?)SeciliKategori(CmbStokKategori)?.Id ?? DBNull.Value;
            cmd.Parameters.Add("@Alt", SqlDbType.Int).Value = (object?)SeciliKategori(CmbStokAltKategori)?.Id ?? DBNull.Value;
            using var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                int id = rd.GetInt32(0);
                string adi = rd.GetString(1);
                string tur = rd.GetString(2);
                string opts = rd.IsDBNull(3) ? "" : rd.GetString(3);
                bool required = rd.GetBoolean(4);
                PanelDinamikOzellikler.Children.Add(new TextBlock
                {
                    Text = adi + (required ? " *" : ""), Margin = new Thickness(0, 10, 0, 5)
                });
                Control control;
                if (tur == "Tarih") control = new DatePicker { Height = 35 };
                else if (tur == "Seçim")
                {
                    var cb = new ComboBox { Height = 35 };
                    cb.Items.Add("");
                    foreach (string option in opts.Split('|', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
                        if (!cb.Items.Contains(option)) cb.Items.Add(option);
                    cb.SelectedIndex = 0;
                    control = cb;
                }
                else control = new TextBox { Height = 35, Padding = new Thickness(8, 5, 8, 5), MaxLength = 450,
                    ToolTip = tur == "Sayı" ? "Örnek: 0,950" : null };
                PanelDinamikOzellikler.Children.Add(control);
                _stokDinamikAlanlar[id] = new DinamikStokAlani { Id=id, Ad=adi, Tur=tur,
                    Zorunlu=required, Kontrol=control };
            }
            if (_stokOzellikleriStokId.HasValue) StokOzelDegerleriniGetir(_stokOzellikleriStokId.Value);
        }

        private void StokDinamikDuzenlemeYukle(int stokId)
        {
            if (DemoModu) return;
            _stokOzellikleriStokId = null;
            int? kategoriId = null;
            int? ustId = null;
            using (var con = new SqlConnection(baglantiAdresi))
            {
                con.Open();
                using var cmd = new SqlCommand(@"SELECT k.Id,k.UstKategoriId
FROM dbo.StokKategoriSecimleri s JOIN dbo.StokKategorileri k ON k.Id=s.KategoriId
WHERE s.StokKartId=@Stok", con);
                cmd.Parameters.Add("@Stok", SqlDbType.Int).Value = stokId;
                using var rd = cmd.ExecuteReader();
                if (rd.Read())
                {
                    kategoriId = rd.GetInt32(0);
                    ustId = rd.IsDBNull(1) ? null : rd.GetInt32(1);
                }
            }
            if (kategoriId.HasValue)
            {
                StokKategorileriniYukle(ustId ?? kategoriId);
                if (ustId.HasValue) StokAltKategorileriniYukle(kategoriId.Value);
            }
            _stokOzellikleriStokId = stokId;
            StokOzelAlanlariYukle();
        }

        private void StokOzelDegerleriniGetir(int stokId)
        {
            if (_stokDinamikAlanlar.Count == 0) return;
            using var con = new SqlConnection(baglantiAdresi);
            con.Open();
            using var cmd = new SqlCommand(@"SELECT OzellikId,Deger FROM dbo.StokOzellikDegerleri
WHERE StokKartId=@Stok", con);
            cmd.Parameters.Add("@Stok", SqlDbType.Int).Value = stokId;
            using var rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                if (!_stokDinamikAlanlar.TryGetValue(rd.GetInt32(0), out var alan)) continue;
                string value = rd.GetString(1);
                if (alan.Kontrol is TextBox txt) txt.Text = value;
                else if (alan.Kontrol is ComboBox box) box.SelectedItem = value;
                else if (alan.Kontrol is DatePicker date && DateTime.TryParseExact(value, "yyyy-MM-dd",
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime dt)) date.SelectedDate = dt;
            }
        }

        private static string StokOzelMetin(DinamikStokAlani alan)
        {
            if (alan.Kontrol is TextBox txt) return txt.Text.Trim();
            if (alan.Kontrol is ComboBox box) return box.SelectedItem?.ToString()?.Trim() ?? "";
            if (alan.Kontrol is DatePicker date) return date.SelectedDate?.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) ?? "";
            return "";
        }
        private bool StokOzelAlanlariDogrula()
        {
            if (DemoModu) return true;
            if (ComboId(CmbStokTipi) == null)
            { MessageBox.Show("Geçerli bir stok tipi seçin."); return false; }
            foreach (var alan in _stokDinamikAlanlar.Values)
            {
                string metin = StokOzelMetin(alan);
                if (alan.Zorunlu && metin.Length == 0)
                { MessageBox.Show("Zorunlu alanı doldurun: " + alan.Ad); alan.Kontrol.Focus(); return false; }
                if (alan.Tur == "Sayı" && metin.Length > 0 &&
                    (!decimal.TryParse(metin, NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign,
                        CultureInfo.GetCultureInfo("tr-TR"), out decimal sayi) || sayi < 0))
                { MessageBox.Show(alan.Ad + " için geçerli bir pozitif sayı girin. Örn. 0,950"); alan.Kontrol.Focus(); return false; }
            }
            return true;
        }

        private void StokDinamikSqlKaydet(SqlConnection con, SqlTransaction tx, int stokId)
        {
            int tipId = ComboId(CmbStokTipi) ?? throw new InvalidOperationException("Stok tipi seçilmedi.");
            int? kategoriId = StokSeciliKategoriId;
            if (kategoriId.HasValue)
            {
                using var kontrol = new SqlCommand(@"SELECT COUNT(1) FROM dbo.StokKategorileri
WHERE Id=@Kategori AND StokTipId=@Tip AND Aktif=1", con, tx);
                kontrol.Parameters.Add("@Kategori", SqlDbType.Int).Value = kategoriId.Value;
                kontrol.Parameters.Add("@Tip", SqlDbType.Int).Value = tipId;
                if (Convert.ToInt32(kontrol.ExecuteScalar()) != 1)
                    throw new InvalidOperationException("Kategori seçimi stok tipiyle uyuşmuyor.");
            }
            using (var sil = new SqlCommand("DELETE FROM dbo.StokKategoriSecimleri WHERE StokKartId=@Stok", con, tx))
            { sil.Parameters.Add("@Stok", SqlDbType.Int).Value = stokId; sil.ExecuteNonQuery(); }
            if (kategoriId.HasValue)
            {
                using var ekle = new SqlCommand(@"INSERT INTO dbo.StokKategoriSecimleri(StokKartId,KategoriId)
VALUES(@Stok,@Kategori)", con, tx);
                ekle.Parameters.Add("@Stok", SqlDbType.Int).Value = stokId;
                ekle.Parameters.Add("@Kategori", SqlDbType.Int).Value = kategoriId.Value;
                ekle.ExecuteNonQuery();
            }
            // Tip veya kategori değiştiğinde eski tipin alanlarını artık taşımayalım.
            // Bu yalnızca özel alan değerlerini etkiler; stok hareketi ve bakiye korunur.
            using (var sil = new SqlCommand("DELETE FROM dbo.StokOzellikDegerleri WHERE StokKartId=@Stok", con, tx))
            {
                sil.Parameters.Add("@Stok", SqlDbType.Int).Value = stokId;
                sil.ExecuteNonQuery();
            }
            foreach (var alan in _stokDinamikAlanlar.Values)
            {
                string metin = StokOzelMetin(alan);
                if (metin.Length == 0) continue;
                if (alan.Tur == "Sayı") metin = decimal.Parse(metin,
                    NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign,
                    CultureInfo.GetCultureInfo("tr-TR")).ToString(CultureInfo.InvariantCulture);
                using var cmd = new SqlCommand(@"INSERT dbo.StokOzellikDegerleri(StokKartId,OzellikId,Deger)
SELECT @Stok,t.Id,@Deger FROM dbo.StokOzellikTanimlari t
WHERE t.Id=@Ozellik AND t.StokTipId=@Tip AND t.Aktif=1
AND (t.KategoriId IS NULL OR t.KategoriId=@Kok OR t.KategoriId=@Alt)", con, tx);
                cmd.Parameters.Add("@Stok", SqlDbType.Int).Value = stokId;
                cmd.Parameters.Add("@Ozellik", SqlDbType.Int).Value = alan.Id;
                cmd.Parameters.Add("@Tip", SqlDbType.Int).Value = tipId;
                cmd.Parameters.Add("@Kok", SqlDbType.Int).Value = (object?)SeciliKategori(CmbStokKategori)?.Id ?? DBNull.Value;
                cmd.Parameters.Add("@Alt", SqlDbType.Int).Value = (object?)SeciliKategori(CmbStokAltKategori)?.Id ?? DBNull.Value;
                cmd.Parameters.Add("@Deger", SqlDbType.NVarChar, 450).Value = metin;
                if (cmd.ExecuteNonQuery() != 1)
                    throw new InvalidOperationException("Özel stok alanı tanımı artık geçerli değil: " + alan.Ad);
            }
        }

        private void StokTipiOzellikYonetimi_Click(object sender, RoutedEventArgs e)
        {
            if (DemoModu) { MessageBox.Show("Dinamik stok yönetimi SQL Server modunda kullanılabilir."); return; }
            if (aktifKullanici == null || !aktifKullanici.Roller.Split(',')
                .Any(r => r.Trim().Equals("Yönetici", StringComparison.OrdinalIgnoreCase)))
            { MessageBox.Show("Yeni stok tipi ve özellik tanımlamak için Yönetici rolü gereklidir."); return; }
            if (!StokYetkisiGerekli("STOCK.EDIT")) return;
            try
            {
                string eskiTip = ComboAd(CmbStokTipi);
                var pencere = new StokTipiYonetimiPenceresi(baglantiAdresi, aktifKullanici.KullaniciId) { Owner = this };
                pencere.ShowDialog();
                StokTipleriniYukle(eskiTip);
            }
            catch (Exception ex) { MessageBox.Show("Stok tipi yönetimi açılamadı: " + ex.Message); }
        }
    }
}
