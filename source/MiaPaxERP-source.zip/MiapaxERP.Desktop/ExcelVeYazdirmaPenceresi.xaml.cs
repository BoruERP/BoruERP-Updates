using SqlConnection = MiapaxERP.Desktop.ErpSqlConnection;
using SqlCommand = MiapaxERP.Desktop.ErpSqlCommand;
using SqlTransaction = MiapaxERP.Desktop.ErpSqlTransaction;
using SqlDataReader = MiapaxERP.Desktop.ErpSqlReader;
using SqlDataAdapter = MiapaxERP.Desktop.ErpSqlDataAdapter;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using ClosedXML.Excel;
using Microsoft.Data.SqlClient;
using Microsoft.Win32;

namespace MiapaxERP.Desktop
{
    public partial class ExcelVeYazdirmaPenceresi : Window
    {
        private readonly string _baglanti;
        private readonly int _kullaniciId;
        private DataTable? _liste;
        private readonly List<StokSatiri> _aktarim = new();
        private bool _aktarimOnizlemesi;
        private const int MaxAktarim = 2000;

        public sealed class StokSatiri
        {
            public int ExcelSatiri { get; init; }
            public string Kod { get; set; } = "";
            public string Ad { get; init; } = "";
            public string Tip { get; init; } = "";
            public string Birim { get; init; } = "";
            public string Aciklama { get; init; } = "";
            public decimal? Minimum { get; init; }
            public decimal? Acilis { get; init; }
            public bool Aktif { get; init; } = true;
            public string Hata { get; set; } = "";
        }

        private sealed record ListeSecimi(string Ad, string Yetki, string Sql);

        private static readonly List<ListeSecimi> Listeler = new()
        {
            new("Stok Kartları", "STOCK.VIEW", @"
SELECT TOP (10000) s.StokKodu AS [Stok Kodu], s.StokAdi AS [Stok Adı],
 s.StokTipi AS [Stok Tipi], s.Birim, COALESCE(b.Miktar,0) AS [Mevcut Miktar],
 s.MinimumStokMiktari AS [Minimum Stok], CASE WHEN s.Aktif=1 THEN N'Aktif' ELSE N'Pasif' END AS Durum
FROM dbo.StokKartlari s LEFT JOIN dbo.StokBakiyeleri b ON b.StokKartId=s.Id
ORDER BY s.StokAdi, s.StokKodu"),
            new("Stok Hareketleri (son 2000)", "STOCK.HISTORY", @"
SELECT TOP (2000) h.KayitTarihi AS Tarih, s.StokKodu AS [Stok Kodu],
 s.StokAdi AS [Stok Adı], h.HareketTipi AS [Hareket], h.Yon AS [Yön],
 h.Miktar, h.Birim, h.Aciklama AS [Açıklama]
FROM dbo.StokHareketleri h JOIN dbo.StokKartlari s ON s.Id=h.StokKartId
ORDER BY h.Id DESC"),
            new("Üretim Emirleri", "PRODUCTION.VIEW", @"
SELECT TOP (10000) e.UretimEmriNo AS [Emir No], s.StokKodu AS [Mamul Kodu],
 s.StokAdi AS [Mamul], e.MiktarBirimi AS [Birim],
 e.PlanlananMiktar AS [Planlanan], e.UretilenMiktar AS [Üretilen],
 e.FireMiktari AS [Fire], e.Durum, e.PlanlananBaslangic AS [Başlangıç],
 e.PlanlananBitis AS [Bitiş]
FROM dbo.UretimEmirleri e JOIN dbo.StokKartlari s ON s.Id=e.MamulStokId
ORDER BY e.Id DESC"),
            new("Cari Kartları", "CUSTOMER.VIEW", @"
SELECT TOP (10000) CariKodu AS [Cari Kodu], Unvan AS [Ünvan], CariTipi AS [Tür],
 VergiNo AS [Vergi No], Telefon, Eposta AS [E-posta], Adres,
 CASE WHEN Aktif=1 THEN N'Aktif' ELSE N'Pasif' END AS Durum
FROM dbo.CariKartlari ORDER BY Unvan"),
            new("Cari Bakiyeleri", "CUSTOMER.VIEW", @"
SELECT TOP (10000) c.CariKodu AS [Cari Kodu], c.Unvan AS [Ünvan], c.CariTipi AS [Tür],
 CAST(COALESCE(SUM(CASE WHEN h.HareketTipi=N'Borç' THEN h.Tutar ELSE -h.Tutar END),0)
      AS decimal(18,2)) AS [Bakiye TRY]
FROM dbo.CariKartlari c LEFT JOIN dbo.CariHareketleri h ON h.CariId=c.Id
GROUP BY c.CariKodu,c.Unvan,c.CariTipi ORDER BY c.Unvan"),
            new("Cari Hareketleri (son 2000)", "CUSTOMER.VIEW", @"
SELECT TOP (2000) h.Tarih, c.CariKodu AS [Cari Kodu], c.Unvan AS [Ünvan],
 h.HareketTipi AS [İşlem], h.Tutar, h.Aciklama AS [Açıklama], h.Kaynak
FROM dbo.CariHareketleri h JOIN dbo.CariKartlari c ON c.Id=h.CariId
ORDER BY h.Id DESC")
        };

        public ExcelVeYazdirmaPenceresi(string baglanti, int kullaniciId)
        {
            _baglanti = baglanti;
            _kullaniciId = kullaniciId;
            InitializeComponent();
            foreach (var item in Listeler) CmbListe.Items.Add(item.Ad);
            CmbListe.SelectedIndex = 0;
        }

        private SqlConnection Baglan()
        {
            var con = new SqlConnection(_baglanti);
            con.Open();
            return con;
        }

        private bool Yetkili(SqlConnection con, string kod, SqlTransaction? tx = null)
        {
            using var cmd = new SqlCommand(@"
SELECT CASE WHEN EXISTS(SELECT 1 FROM dbo.Kullanicilar WHERE Id=@id AND Aktif=1)
AND EXISTS(SELECT 1 FROM dbo.vw_KullaniciEtkinYetkileri
           WHERE KullaniciId=@id AND YetkiKodu=@yetki AND Yetkili=1)
THEN 1 ELSE 0 END", con, tx);
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = _kullaniciId;
            cmd.Parameters.Add("@yetki", SqlDbType.NVarChar, 80).Value = kod;
            return Convert.ToInt32(cmd.ExecuteScalar()) == 1;
        }

        private void ZorunluYetki(SqlConnection con, string kod, SqlTransaction? tx = null)
        {
            if (!Yetkili(con, kod, tx))
                throw new UnauthorizedAccessException("Bu işlem için kullanıcı yetkisi yok: " + kod);
        }

        private static void Hata(Exception ex) => MessageBox.Show(
            ex.Message, "MiapaxERP | Excel ve Yazdırma", MessageBoxButton.OK, MessageBoxImage.Warning);

        private void CmbListe_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (!IsLoaded) return;
            _liste = null;
            _aktarimOnizlemesi = false;
            _aktarim.Clear();
            BtnTopluKaydet.IsEnabled = false;
            GridOnizleme.ItemsSource = null;
            TxtDurum.Text = "Yeni listeyi yüklemek için 'Listeyi Yükle' düğmesine basın.";
        }

        private void Listele_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var secim = Listeler[CmbListe.SelectedIndex];
                using var con = Baglan();
                ZorunluYetki(con, secim.Yetki);
                var tablo = new DataTable();
                using (var cmd = new SqlCommand(secim.Sql, con))
                using (var rdr = cmd.ExecuteReader()) tablo.Load(rdr);
                _liste = tablo;
                _aktarimOnizlemesi = false;
                _aktarim.Clear();
                BtnTopluKaydet.IsEnabled = false;
                GridOnizleme.ItemsSource = tablo.DefaultView;
                TxtDurum.Text = $"{secim.Ad} — {tablo.Rows.Count} satır. (Bazı listeler en son 2000 kayıtla sınırlıdır.)";
            }
            catch (Exception ex) { Hata(ex); }
        }

        private static string TemizDosyaAdi(string value) => string.Concat(
            value.Select(c => Path.GetInvalidFileNameChars().Contains(c) ? '_' : c));

        private static void TabloyuXlsxKaydet(DataTable tablo, string sayfaAdi, string dosya)
        {
            using var wb = new XLWorkbook();
            var ws = wb.Worksheets.Add(sayfaAdi);
            for (int c = 0; c < tablo.Columns.Count; c++)
            {
                var cell = ws.Cell(1, c + 1);
                cell.Value = tablo.Columns[c].ColumnName;
                cell.Style.Font.Bold = true;
                cell.Style.Fill.BackgroundColor = XLColor.FromHtml("#173458");
                cell.Style.Font.FontColor = XLColor.White;
            }
            for (int r = 0; r < tablo.Rows.Count; r++)
                for (int c = 0; c < tablo.Columns.Count; c++)
                {
                    object value = tablo.Rows[r][c];
                    var cell = ws.Cell(r + 2, c + 1);
                    if (value is DBNull) continue;
                    if (value is DateTime date) { cell.Value = date; cell.Style.DateFormat.Format = "dd.MM.yyyy HH:mm"; }
                    else if (value is decimal dec) { cell.Value = (double)dec; cell.Style.NumberFormat.Format = "#,##0.###"; }
                    else if (value is int i) cell.Value = i;
                    else if (value is long l) cell.Value = (double)l;
                    // Metinler formül olarak değil, değer olarak yazılır.
                    else
                    {
                        string metin = Convert.ToString(value, CultureInfo.GetCultureInfo("tr-TR")) ?? "";
                        // Excel formül enjeksiyonunu engelle: kullanıcı metnini metin olarak tut.
                        if (metin.Length > 0 && ("=+-@\t\r".Contains(metin[0]))) metin = "'" + metin;
                        cell.Value = metin;
                    }
                }
            ws.SheetView.FreezeRows(1);
            ws.Columns(1, tablo.Columns.Count).AdjustToContents(1, Math.Min(tablo.Rows.Count + 1, 40));
            wb.SaveAs(dosya);
        }

        private void ExcelAktar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (_liste == null || _aktarimOnizlemesi) throw new InvalidOperationException("Önce bir rapor listesini yükleyin.");
                var secim = Listeler[CmbListe.SelectedIndex];
                using (var con = Baglan()) ZorunluYetki(con, secim.Yetki);
                var dlg = new SaveFileDialog
                {
                    Filter = "Excel çalışma kitabı (*.xlsx)|*.xlsx",
                    FileName = TemizDosyaAdi(secim.Ad) + "_" + DateTime.Now.ToString("yyyyMMdd_HHmm") + ".xlsx"
                };
                if (dlg.ShowDialog(this) != true) return;
                TabloyuXlsxKaydet(_liste, "MiapaxERP Rapor", dlg.FileName);
                TxtDurum.Text = "Excel aktarıldı: " + dlg.FileName;
            }
            catch (Exception ex) { Hata(ex); }
        }

        private void Yazdir_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (_liste == null || _aktarimOnizlemesi) throw new InvalidOperationException("Önce yazdırılacak listeyi yükleyin.");
                var secim = Listeler[CmbListe.SelectedIndex];
                using (var con = Baglan()) ZorunluYetki(con, secim.Yetki);
                if (_liste.Rows.Count == 0) throw new InvalidOperationException("Yazdırılacak kayıt yok.");
                if (_liste.Rows.Count > 500)
                {
                    MessageBox.Show("Yazdırma en çok 500 satırla sınırlandırıldı. Eksiksiz veri için Excel'e aktarın.",
                        "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                var dialog = new PrintDialog();
                if (dialog.ShowDialog() != true) return;
                var doc = new FlowDocument
                {
                    FontFamily = new FontFamily("Segoe UI"),
                    FontSize = 9,
                    PagePadding = new Thickness(30),
                    ColumnGap = 0,
                    PageWidth = dialog.PrintableAreaWidth,
                    PageHeight = dialog.PrintableAreaHeight,
                    ColumnWidth = Math.Max(200, dialog.PrintableAreaWidth - 60)
                };
                doc.Blocks.Add(new Paragraph(new Run("MiapaxERP | " + secim.Ad))
                { FontSize = 16, FontWeight = FontWeights.Bold, Margin = new Thickness(0, 0, 0, 6) });
                doc.Blocks.Add(new Paragraph(new Run("Yazdırma tarihi: " + DateTime.Now.ToString("dd.MM.yyyy HH:mm") +
                    " | Kayıt: " + _liste.Rows.Count))
                { Margin = new Thickness(0, 0, 0, 12) });
                var table = new Table { CellSpacing = 0 };
                foreach (DataColumn _ in _liste.Columns) table.Columns.Add(new TableColumn());
                var group = new TableRowGroup();
                table.RowGroups.Add(group);
                var header = new TableRow { Background = new SolidColorBrush(Color.FromRgb(224, 235, 246)) };
                foreach (DataColumn col in _liste.Columns)
                    header.Cells.Add(new TableCell(new Paragraph(new Run(col.ColumnName)) { FontWeight = FontWeights.Bold })
                    { BorderBrush = Brushes.LightGray, BorderThickness = new Thickness(0.4), Padding = new Thickness(3) });
                group.Rows.Add(header);
                foreach (DataRow dataRow in _liste.Rows)
                {
                    var row = new TableRow();
                    foreach (DataColumn col in _liste.Columns)
                    {
                        var value = dataRow[col];
                        var text = value is DBNull
                            ? ""
                            : value is decimal or double or float
                                ? Convert.ToDecimal(value).ToString("0.###", CultureInfo.GetCultureInfo("tr-TR"))
                                : Convert.ToString(value, CultureInfo.GetCultureInfo("tr-TR")) ?? "";
                        row.Cells.Add(new TableCell(new Paragraph(new Run(text)) { Margin = new Thickness(0) })
                        { BorderBrush = Brushes.LightGray, BorderThickness = new Thickness(0.4), Padding = new Thickness(3) });
                    }
                    group.Rows.Add(row);
                }
                doc.Blocks.Add(table);
                dialog.PrintDocument(((IDocumentPaginatorSource)doc).DocumentPaginator, "MiapaxERP - " + secim.Ad);
                TxtDurum.Text = "Yazdırma işi yazıcıya gönderildi.";
            }
            catch (Exception ex) { Hata(ex); }
        }

        private void Sablon_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dlg = new SaveFileDialog
                {
                    Filter = "Excel çalışma kitabı (*.xlsx)|*.xlsx",
                    FileName = "MiapaxERP_TopluStok_Sablon.xlsx"
                };
                if (dlg.ShowDialog(this) != true) return;
                using var wb = new XLWorkbook();
                var ws = wb.Worksheets.Add("StokKartlari");
                string[] titles = { "StokKodu", "StokAdi", "StokTipi", "Birim", "Aciklama", "MinimumStokMiktari", "AcilisMiktari", "Durum" };
                for (int col = 0; col < titles.Length; col++)
                {
                    ws.Cell(1, col + 1).Value = titles[col];
                    ws.Cell(1, col + 1).Style.Font.Bold = true;
                    ws.Cell(1, col + 1).Style.Fill.BackgroundColor = XLColor.FromHtml("#173458");
                    ws.Cell(1, col + 1).Style.Font.FontColor = XLColor.White;
                    ws.Column(col + 1).Width = col == 4 ? 34 : 24;
                }
                // Alana metin biçimi ver, örn. 000123 stok kodunun sıfırları korunur.
                ws.Column(1).Style.NumberFormat.Format = "@";
                ws.SheetView.FreezeRows(1);
                var guide = wb.Worksheets.Add("Kullanim");
                guide.Cell("A1").Value = "Stok Tipi: Hammadde, Yardımcı Malzeme, Başlık, Yedek Parça, Mandallı, Kangal";
                guide.Cell("A2").Value = "Birim: KG, Metre, Adet, Ton";
                guide.Cell("A3").Value = "Açılış miktarı isteğe bağlıdır. Boşsa stok bakiyesi oluşturulmaz.";
                guide.Cell("A4").Value = "Ondalık miktarlar için virgül kullanın. Aynı stok kodu ikinci kez eklenmez.";
                guide.Cell("A5").Value = "Stok kodu ve adı zorunludur. Dosyada formül kullanmayın.";
                guide.Cell("A6").Value = "Durum: Aktif veya Pasif yazın. Boş bırakılırsa Aktif kabul edilir.";
                guide.Cell("A7").Value = "Eski 7 sütunlu stok şablonları da desteklenir (Durum varsayılan: Aktif).";
                guide.Cell("A8").Value = "Excel'e Aktar ile oluşturulan RAPOR dosyası toplu içe aktarma şablonu değildir.";
                guide.Cell("A9").Value = "Gerçek fabrikaya aktarmadan önce test veritabanında deneyin.";
                guide.Column(1).Width = 94;
                wb.SaveAs(dlg.FileName);
                TxtExcelBilgi.Text = "Şablon kaydedildi: " + dlg.FileName;
            }
            catch (Exception ex) { Hata(ex); }
        }

        private static string OkuMetin(IXLCell cell)
        {
            if (cell.HasFormula) throw new FormatException("Excel formülü kullanılamaz: " + cell.Address);
            return cell.GetFormattedString().Trim();
        }

        private static decimal? MiktarOku(IXLCell cell, string alan)
        {
            if (cell.HasFormula) throw new FormatException("Formül kabul edilmiyor: " + alan);
            if (cell.IsEmpty()) return null;
            decimal value;
            if (cell.DataType == XLDataType.Number)
                value = Convert.ToDecimal(cell.GetDouble());
            else
            {
                string text = cell.GetFormattedString().Trim();
                // 1.000 gibi belirsiz binlik ayırıcılarını reddet.
                if (!Regex.IsMatch(text, @"^\d+(,\d{1,3})?$", RegexOptions.CultureInvariant) ||
                    !decimal.TryParse(text, NumberStyles.AllowDecimalPoint,
                        CultureInfo.GetCultureInfo("tr-TR"), out value))
                    throw new FormatException(alan + " miktarını '1000' veya '1000,500' biçiminde girin.");
            }
            if (value < 0 || value > 999999999999999m || decimal.Round(value, 3) != value)
                throw new FormatException(alan + " negatif olamaz ve en fazla 3 ondalık basamak içerebilir.");
            return value;
        }

        // Excel'deki büyük/küçük harf farkları yüzünden geçerli stokları reddetme.
        // SQL'de saklanan standart değerleri koru.
        private static string StokTipiDuzelt(string metin)
        {
            string t = Regex.Replace(metin.Trim(), @"\s+", " ")
                .ToUpper(CultureInfo.GetCultureInfo("tr-TR"));
            return t switch
            {
                "HAMMADDE" => "Hammadde",
                "YARDIMCI MALZEME" => "Yardımcı Malzeme",
                "BAŞLIK" or "BASLIK" => "Başlık",
                "YEDEK PARÇA" or "YEDEK PARCA" => "Yedek Parça",
                "MANDALLI" => "Mandallı",
                "KANGAL" => "Kangal",
                _ => metin.Trim()
            };
        }

        private static string BirimDuzelt(string metin)
        {
            string t = metin.Trim().ToUpper(CultureInfo.GetCultureInfo("tr-TR"));
            return t switch
            {
                "KG" or "KİLOGRAM" or "KILOGRAM" => "KG",
                "METRE" or "M" => "Metre",
                "ADET" => "Adet",
                "TON" => "Ton", "GRAM" or "GR" => "Gram", "LITRE" or "LİTRE" or "LT" => "Litre", "M2" or "M²" => "M2", "M3" or "M³" => "M3",
                _ => metin.Trim()
            };
        }

        // 8. Durum sütunu isteğe bağlıdır. Eski 7 sütunlu şablon: Aktif.
        private static bool DurumOku(IXLCell cell)
        {
            string t = OkuMetin(cell).ToUpper(CultureInfo.GetCultureInfo("tr-TR"));
            return t switch
            {
                "" or "AKTİF" or "AKTIF" or "1" or "EVET" or "TRUE" => true,
                "PASİF" or "PASIF" or "0" or "HAYIR" or "FALSE" => false,
                _ => throw new FormatException("Durum yalnızca Aktif veya Pasif olmalı: " + cell.Address)
            };
        }

        private void ExcelOku_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dlg = new OpenFileDialog { Filter = "Excel dosyası (*.xlsx)|*.xlsx", CheckFileExists = true };
                if (dlg.ShowDialog(this) != true) return;
                _aktarim.Clear();
                _liste = null;
                _aktarimOnizlemesi = true;
                BtnTopluKaydet.IsEnabled = false;
                GridOnizleme.ItemsSource = null;
                if (new FileInfo(dlg.FileName).Length > 8 * 1024 * 1024)
                    throw new InvalidOperationException("Excel en fazla 8 MB olabilir.");
                using var con = Baglan();
                ZorunluYetki(con, "STOCK.CREATE");
                using var wb = new XLWorkbook(dlg.FileName);
                if (!wb.Worksheets.TryGetWorksheet("StokKartlari", out IXLWorksheet? ws) || ws == null)
                    throw new FormatException("Excel'de 'StokKartlari' adlı sayfa bulunmalı.");
                string[] header = { "StokKodu", "StokAdi", "StokTipi", "Birim", "Aciklama", "MinimumStokMiktari", "AcilisMiktari" };
                for (int c = 0; c < header.Length; c++)
                    if (!string.Equals(OkuMetin(ws.Cell(1, c + 1)), header[c], StringComparison.OrdinalIgnoreCase))
                        throw new FormatException($"{c + 1}. sütun başlığı '{header[c]}' olmalı. 'Boş Excel Şablonu' ile oluşturulmuş dosyayı kullanın; rapor Excel'i bu şablon değildir.");
                string durumBasligi = OkuMetin(ws.Cell(1, 8));
                bool durumSutunuVar = durumBasligi.Length != 0;
                if (durumSutunuVar && !string.Equals(durumBasligi, "Durum", StringComparison.OrdinalIgnoreCase))
                    throw new FormatException("8. sütun adı 'Durum' olmalı (Aktif/Pasif). Eski 7 sütunlu şablonlar da kullanılabilir.");
                int end = ws.LastRowUsed()?.RowNumber() ?? 1;
                if (end - 1 > MaxAktarim) throw new InvalidOperationException("Tek seferde en fazla 2000 stok kartı.");
                var kodlar = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                for (int r = 2; r <= end; r++)
                {
                    if (Enumerable.Range(1, durumSutunuVar ? 8 : 7).All(c => ws.Cell(r, c).IsEmpty())) continue;
                    string problem = "";
                    StokSatiri satir;
                    try
                    {
                        satir = new StokSatiri
                        {
                            ExcelSatiri = r,
                            Kod = OkuMetin(ws.Cell(r, 1)),
                            Ad = OkuMetin(ws.Cell(r, 2)),
                            Tip = StokTipiDuzelt(OkuMetin(ws.Cell(r, 3))),
                            Birim = BirimDuzelt(OkuMetin(ws.Cell(r, 4))),
                            Aciklama = OkuMetin(ws.Cell(r, 5)),
                            Minimum = MiktarOku(ws.Cell(r, 6), "Minimum stok"),
                            Acilis = MiktarOku(ws.Cell(r, 7), "Açılış"),
                            Aktif = !durumSutunuVar || DurumOku(ws.Cell(r, 8))
                        };
                        if (satir.Kod.Length == 0 &&
                            new[] { "Hammadde", "Yardımcı Malzeme", "Başlık", "Yedek Parça", "Mandallı", "Kangal" }.Contains(satir.Tip))
                        {
                            satir.Kod = MiapaxERPStokKodlari.YeniKod(satir.Tip);
                        }
                        if (satir.Kod.Length == 0 || satir.Kod.Length > 50) problem = "Stok kodu boş/çok uzun";
                        else if (satir.Ad.Length == 0 || satir.Ad.Length > 200) problem = "Stok adı boş/çok uzun";
                        else if (!new[] { "Hammadde", "Yardımcı Malzeme", "Başlık", "Yedek Parça", "Mandallı", "Kangal" }.Contains(satir.Tip)) problem = "Geçersiz stok tipi (izin verilenler: Hammadde, Yardımcı Malzeme, Başlık, Yedek Parça, Mandallı, Kangal)";
                        else if (!new[] { "KG", "Metre", "Adet", "Ton", "Gram", "Litre", "M2", "M3" }.Contains(satir.Birim)) problem = "Geçersiz birim";
                        else if (satir.Aciklama.Length > 500) problem = "Açıklama 500 karakteri geçti";
                        else if (!satir.Aktif && satir.Acilis.GetValueOrDefault() > 0) problem = "Pasif karta açılış miktarı girilemez";
                        else if (!kodlar.Add(satir.Kod)) problem = "Excel içinde yinelenen stok kodu";
                    }
                    catch (Exception ex)
                    {
                        satir = new StokSatiri { ExcelSatiri = r };
                        problem = ex.Message;
                    }
                    satir.Hata = problem;
                    _aktarim.Add(satir);
                }
                var mevcutKodlar = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                using (var cmd = new SqlCommand("SELECT StokKodu FROM dbo.StokKartlari", con))
                using (var reader = cmd.ExecuteReader())
                    while (reader.Read()) mevcutKodlar.Add(reader.GetString(0));
                foreach (var s in _aktarim)
                    if (string.IsNullOrEmpty(s.Hata) && mevcutKodlar.Contains(s.Kod)) s.Hata = "Bu stok kodu veritabanında zaten var";
                DataTable preview = new();
                foreach (string c in new[] { "Satır", "Stok Kodu", "Stok Adı", "Tip", "Birim", "Minimum", "Açılış", "Durum", "KontrolDurumu" })
                    preview.Columns.Add(c);
                foreach (var s in _aktarim)
                    preview.Rows.Add(s.ExcelSatiri, s.Kod, s.Ad, s.Tip, s.Birim,
                        s.Minimum?.ToString(CultureInfo.GetCultureInfo("tr-TR")),
                        s.Acilis?.ToString(CultureInfo.GetCultureInfo("tr-TR")),
                        s.Aktif ? "Aktif" : "Pasif",
                        s.Hata.Length == 0 ? "Geçerli" : s.Hata);
                GridOnizleme.ItemsSource = preview.DefaultView;
                KontrolSutununuDuzenle();
                int hatali = _aktarim.Count(r => r.Hata.Length != 0);
                bool openings = _aktarim.Any(r => r.Acilis.HasValue && r.Acilis > 0);
                bool yetkiVar = !openings || Yetkili(con, "STOCK.OPENING");
                // Hatalı satırlar diğer ürünlerin aktarımını engellemez.
                BtnTopluKaydet.IsEnabled = _aktarim.Any(r => r.Hata.Length == 0 &&
                    (!r.Acilis.HasValue || r.Acilis.Value <= 0 || yetkiVar));
                var hataDetaylari = _aktarim.Where(r => r.Hata.Length != 0)
                    .Select(r => $"Satır {r.ExcelSatiri} ({(r.Kod.Length == 0 ? "stok kodu yok" : r.Kod)}): {r.Hata}")
                    .ToList();
                if (!yetkiVar)
                    hataDetaylari.AddRange(_aktarim.Where(r => r.Hata.Length == 0 && r.Acilis.GetValueOrDefault() > 0)
                        .Select(r => $"Satır {r.ExcelSatiri} ({r.Kod}): Açılış stoku yetkisi yok (STOCK.OPENING)"));
                TxtExcelBilgi.Text = $"{_aktarim.Count} satır | {_aktarim.Count - hatali} geçerli | {hatali} hatalı | Açılış stoku izni: {(yetkiVar ? "Uygun" : "Yok")}. " +
                    (hataDetaylari.Count == 0
                        ? "Tüm satırlar uygun. Geçerli satırlar kaydedilebilir."
                        : "Hata nedenleri: " + string.Join(" | ", hataDetaylari.Take(8)) +
                          (hataDetaylari.Count > 8 ? $" | ... ve {hataDetaylari.Count - 8} hata daha (tabloda)." : ""));
                TxtDurum.Text = BtnTopluKaydet.IsEnabled
                    ? "Önizleme başarılı. Veritabanına henüz kayıt yapılmadı; 'Onayla ve Kaydet' butonuyla devam edin."
                    : "Önizleme tamamlandı. Hatalar/izinler giderilince kaydetme aktifleşir; henüz kayıt yapılmadı.";
            }
            catch (Exception ex) { BtnTopluKaydet.IsEnabled = false; Hata(ex); }
        }

        private void KontrolSutununuDuzenle()
        {
            foreach (var sutun in GridOnizleme.Columns)
            {
                if (string.Equals(sutun.Header?.ToString(), "KontrolDurumu", StringComparison.Ordinal))
                {
                    sutun.Header = "Kontrol / Hata";
                    sutun.Width = new DataGridLength(1, DataGridLengthUnitType.Star);
                    break;
                }
            }
        }

        private void TopluKaydet_Click(object sender, RoutedEventArgs e)
        {
            if (!_aktarimOnizlemesi || _aktarim.Count == 0) return;
            try
            {
                using var con = Baglan();
                ZorunluYetki(con, "STOCK.CREATE");
                bool acilisIzni = Yetkili(con, "STOCK.OPENING");
                var uygun = _aktarim.Where(s => s.Hata.Length == 0 &&
                    (!s.Acilis.HasValue || s.Acilis.Value <= 0 || acilisIzni)).ToList();
                if (uygun.Count == 0)
                {
                    MessageBox.Show("Kaydedilebilecek geçerli ve yetkili satır bulunamadı.", "MiapaxERP");
                    return;
                }
                if (MessageBox.Show($"{uygun.Count} geçerli stok kartı kaydedilecek. Hatalı/yetkisiz satırlar atlanacak. Devam edilsin mi?",
                    "Toplu stok aktarımı", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;

                int kaydedilen = 0;
                foreach (var s in _aktarim)
                {
                    if (s.Hata.Length != 0) continue;
                    if (s.Acilis.GetValueOrDefault() > 0 && !acilisIzni)
                    {
                        s.Hata = "Açılış stoku yetkisi yok (STOCK.OPENING)";
                        continue;
                    }
                    // Her satır kendi transaction'ında: tek satırın SQL hatası diğerlerini geri almaz.
                    try
                    {
                        new IsletmeServisi(_baglanti,_kullaniciId).ExcelStokKaydet(s);
                        kaydedilen++;s.Hata="Kaydedildi";
                    }
                    catch(Exception ex){s.Hata="Kayıt yapılamadı: "+ex.Message;}
                }
                var sonuc = new DataTable();
                foreach (string c in new[] { "Satır", "Stok Kodu", "Stok Adı", "Tip", "Birim", "Minimum", "Açılış", "Durum", "KontrolDurumu" })
                    sonuc.Columns.Add(c);
                foreach (var s in _aktarim)
                    sonuc.Rows.Add(s.ExcelSatiri, s.Kod, s.Ad, s.Tip, s.Birim,
                        s.Minimum?.ToString(CultureInfo.GetCultureInfo("tr-TR")),
                        s.Acilis?.ToString(CultureInfo.GetCultureInfo("tr-TR")),
                        s.Aktif ? "Aktif" : "Pasif", s.Hata);
                GridOnizleme.ItemsSource = sonuc.DefaultView;
                KontrolSutununuDuzenle();
                int atlanan = _aktarim.Count - kaydedilen;
                var atlananDetaylari = _aktarim.Where(r => r.Hata != "Kaydedildi")
                    .Select(r => $"Satır {r.ExcelSatiri} ({(r.Kod.Length == 0 ? "stok kodu yok" : r.Kod)}): {(r.Hata.Length == 0 ? "İşlenemedi" : r.Hata)}")
                    .ToList();
                TxtExcelBilgi.Text = $"Kaydedilen: {kaydedilen} | Atlanan: {atlanan}. " +
                    (atlananDetaylari.Count == 0 ? "Tüm uygun kayıtlar kaydedildi."
                        : "Atlanma nedenleri: " + string.Join(" | ", atlananDetaylari.Take(8)) +
                          (atlananDetaylari.Count > 8 ? $" | ... ve {atlananDetaylari.Count - 8} satır daha (tabloda)." : ""));
                TxtDurum.Text = "İşlem tamamlandı. Atlanan satırları düzelterek yeni bir dosya ile tekrar deneyebilirsiniz.";
                BtnTopluKaydet.IsEnabled = false;
                _aktarimOnizlemesi = false;
                MessageBox.Show($"{kaydedilen} ürün kaydedildi, {atlanan} ürün atlandı. Ayrıntılar tabloda.",
                    "MiapaxERP | Toplu aktarım", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex) { Hata(ex); }
        }
    }
}
