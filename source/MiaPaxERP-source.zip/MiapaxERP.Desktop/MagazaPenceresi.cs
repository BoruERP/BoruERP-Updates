using System.IO;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed class MagazaPenceresi:Window
{
    readonly string connection;readonly int user;
    readonly ComboBox kanal=new(){ItemsSource=MagazaBaglantisi.Kanallar};readonly TextBox store=new(), integrator=new();readonly PasswordBox key=new(),secret=new();
    readonly DataGrid grid=new(){AutoGenerateColumns=true,IsReadOnly=true,SelectionMode=DataGridSelectionMode.Extended,CanUserAddRows=false};
    readonly TextBlock status=new(){TextWrapping=TextWrapping.Wrap,Margin=new Thickness(8)};readonly string folder;readonly ErpModulServisi access;readonly TicaretDosyalari db;
    readonly CancellationTokenSource cancellation=new();string? next;bool busy;MagazaAyar? loaded;
    public MagazaPenceresi(string connection,int user)
    {
        this.connection=connection;this.user=user;access=new(connection,user);db=new(connection,user,"ECOM");Check("ECOM.VIEW");folder=Path.Combine(GorunumDeposu.Klasor(connection,user),"Magazalar");
        Title="MiapaxERP | Mağaza bağlantıları";Width=1150;Height=760;WindowStartupLocation=WindowStartupLocation.CenterOwner;
        var outer=new DockPanel{Margin=new Thickness(18)};Content=outer;
        var navigation=new System.Windows.Controls.TreeView{Width=205,Margin=new Thickness(0,0,18,0)};
        DockPanel.SetDock(navigation,Dock.Left);outer.Children.Add(navigation);
        var root=new DockPanel();outer.Children.Add(root);var form=new StackPanel();DockPanel.SetDock(form,Dock.Top);root.Children.Add(form);
        var title=new TextBlock{FontSize=22};form.Children.Add(title);
        var requirements=new TextBlock{TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,8,0,8)};form.Children.Add(requirements);
        var setup=new StackPanel();form.Children.Add(setup);
        foreach(var group in PazaryeriKatalogu.Tum.GroupBy(x=>x.Kategori))
        {
            var category=new TreeViewItem{Header=group.Key,IsExpanded=true};navigation.Items.Add(category);
            foreach(var provider in group)
            {
                var item=new TreeViewItem{Header=provider.Ad,Tag=provider};category.Items.Add(item);
                item.Selected+=(_,e)=>{e.Handled=true;if(busy)return;title.Text=provider.Ad;requirements.Text=provider.Gerekenler;
                    setup.Visibility=provider.SiparisOkumaHazir?Visibility.Visible:Visibility.Collapsed;
                    grid.ItemsSource=null;loaded=null;next=null;
                    status.Text=provider.SiparisOkumaHazir?"API bilgilerini girip siparişleri getirerek bağlantıyı doğrulayın.":"Hazırlık aşamasında • Canlı bağlantı ve sipariş aktarımı kullanıma hazır değil. Satıcı API hesabı açılınca sağlayıcı sözleşmesine göre bağdaştırıcı eklenecek.";
                    if(provider.SiparisOkumaHazir)kanal.SelectedItem=provider.Ad;
                };
            }
        }
        var help=new Button{Content="Seçili sağlayıcının resmî sayfası",Margin=new Thickness(4)};form.Children.Add(help);
        help.Click+=(_,_)=>{if(navigation.SelectedItem is TreeViewItem {Tag:PazaryeriTanimi p})System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(p.Dokuman){UseShellExecute=true});};
        form.Children.Add(new TextBlock{Text="Sipariş okuma bağlantıları. Her sayfada en fazla 100 kayıt; sonraki sayfayı düğmeyle yükleyin. Seçilen siparişler aktarılır, aynı kaynak kayıt tekrar eklenmez. Stok/fiyat gönderimi ve mağazada durum değiştirme yapılmaz.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,10,0,10)});
        foreach(var (label,control) in new (string,Control)[]{("Kanal",kanal),("Satıcı / merchant ID veya mağaza alan adı",store),("API anahtarı / kullanıcı adı / Shopify access token",key),("API secret / şifre (Shopify için boş)",secret),("Hepsiburada entegratör User-Agent (diğerlerinde boş)",integrator)}){setup.Children.Add(new TextBlock{Text=label});control.MinHeight=30;setup.Children.Add(control);}
        form.Children.Add(new TextBlock{Text="Bağlantı bilgileri işlemi yürüten ana sunucuda şifreli saklanır; yan cihazda kayıtlı anahtarlar gösterilmez. Hepsiburada'da API kullanıcı adı ve şifreyi kullanın. Shopify: read_orders erişimi olan token.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,8,0,8)});
        var bar=new WrapPanel();setup.Children.Add(bar);
        ErpModulPenceresi.B(bar,"Bağlantıyı kaydet",()=>{if(busy)return;Check("ECOM.EDIT");if(HttpsOturumu.Uzak(connection))new MagazaHttpsServisi(connection,user).Kaydet(Ayar());else MagazaBaglantisi.Kaydet(folder,Ayar());status.Text="Bağlantı bilgileri şifreli kaydedildi. Canlı doğrulama için Siparişleri getir düğmesini kullanın.";});
        Add(bar,"Siparişleri getir",()=>Fetch(false));Add(bar,"Sonraki sayfa",()=>Fetch(true));Add(bar,"Seçilenleri aktar",Import);
        form.Children.Add(status);root.Children.Add(grid);kanal.SelectionChanged+=(_,_)=>{if(busy)return;grid.ItemsSource=null;loaded=null;next=null;try{var a=Stored((string)kanal.SelectedItem);store.Text=a?.Magaza??"";key.Password=a?.Anahtar??"";secret.Password=a?.Gizli??"";status.Text="Hesap bağlanmadı; getirerek doğrulayın.";}catch{status.Text="Kayıtlı bilgiler bu Windows hesabıyla açılamadı; yeniden girin.";store.Clear();key.Clear();secret.Clear();}};kanal.SelectedIndex=0;
        kanal.SelectionChanged+=(_,_)=>{try{integrator.Text=Stored((string)kanal.SelectedItem)?.Entegrator??"";}catch{integrator.Clear();}};
        ((TreeViewItem)((TreeViewItem)navigation.Items[0]).Items[0]).IsSelected=true;
        Closed+=(_,_)=>cancellation.Cancel();
    }
    MagazaAyar? Stored(string channel)=>HttpsOturumu.Uzak(connection)?new MagazaHttpsServisi(connection,user).Oku(channel):MagazaBaglantisi.Oku(folder,channel);
    void Check(string permission){if(HttpsOturumu.Uzak(connection))new MagazaHttpsServisi(connection,user).Yetki(permission);else{using var c=access.Ac();access.Yetki(c,null,permission);}}
    MagazaAyar Ayar()=>new((string)kanal.SelectedItem,store.Text.Trim(),key.Password,secret.Password,integrator.Text.Trim());
    void Add(Panel p,string text,Func<Task> action){var b=new Button{Content=text,Margin=new Thickness(4),Padding=new Thickness(10)};p.Children.Add(b);b.Click+=async(_,_)=>{if(busy)return;busy=true;kanal.IsEnabled=store.IsEnabled=key.IsEnabled=secret.IsEnabled=false;try{await action();}catch(OperationCanceledException){status.Text="İşlem iptal edildi veya zaman aşımına uğradı.";}catch(Exception ex){status.Text=ex is SqlException?"SQL işlemi tamamlanamadı. Yetki, döviz veya mükerrer referans kontrolü gerekli.":ex.Message;}finally{busy=false;kanal.IsEnabled=store.IsEnabled=key.IsEnabled=secret.IsEnabled=true;}};}
    async Task Fetch(bool more)
    {
        Check("ECOM.EDIT");if(more&&next==null){status.Text="Sonraki sayfa yok. Önce ilk sayfayı getirin.";return;}
        var a=more?loaded??throw new InvalidOperationException("Önce ilk sayfayı getirin."):Ayar();status.Text="Siparişler getiriliyor…";
        var cursor=more?next:null;var result=HttpsOturumu.Uzak(connection)?await Task.Run(()=>new MagazaHttpsServisi(connection,user).Getir(a,cursor),cancellation.Token):await MagazaBaglantisi.Getir(a,cursor,cancellation.Token);loaded=a;next=result.Sonraki;grid.ItemsSource=result.Siparisler;status.Text=$"{result.Siparisler.Length} kayıt geldi. {(next==null?"Son sayfa.":"Devamı var; sonraki sayfayı açabilirsiniz.")} Aktarmak istediklerinizi seçin.";
    }
    async Task Import()
    {
        Check("ECOM.EDIT");var a=loaded??throw new ArgumentException("Önce siparişleri getirin.");var rows=grid.SelectedItems.Cast<MagazaSiparis>().ToArray();if(rows.Length==0)throw new ArgumentException("Aktarılacak siparişleri seçin.");int added=0,duplicate=0,failed=0;
        await Task.Run(()=>{foreach(var s in rows){cancellation.Token.ThrowIfCancellationRequested();try{db.Kaydet(MagazaBaglantisi.Girdi(a,s));added++;}catch(SqlException ex)when(ex.Number is 2601 or 2627){duplicate++;}catch(ArgumentException){failed++;}}},cancellation.Token);
        status.Text=$"{added} eklendi; {duplicate} mevcut kayıt atlandı; {failed} kayıt tutar/döviz/alan kontrolünden geçemedi. Kaynak siparişler değiştirilmedi. Listeyi yenileyerek kontrol edin.";
    }
}
