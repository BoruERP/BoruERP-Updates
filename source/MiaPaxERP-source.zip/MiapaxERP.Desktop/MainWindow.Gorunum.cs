using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace MiapaxERP.Desktop;

public partial class MainWindow
{
    private GorunumTercihleri gorunum = new();
    private readonly List<string> varsayilanMedya = new();
    private bool gorunumMedyaHazir;

    private void GorunumYukle()
    {
        GorunumuUygula(GorunumDeposu.Oku(GorunumDeposu.Klasor(baglantiAdresi, aktifKullanici?.KullaniciId ?? 0)));
    }
    public void GorunumuUygula(GorunumTercihleri a)
    {
        a.Dogrula();
        TxtFirmaBasligi.Text = a.FirmaBasligi=="MiapaxERP"&&LisansOturumu.Gecerli is { } license?license.Company:a.FirmaBasligi;
        TxtFirmaMetni.Text=a.FirmaMetni;TxtFirmaAltMetni.Text=a.FirmaAltMetni;
        TxtFirmaBasligi.Visibility=a.FirmaAdiGoster?Visibility.Visible:Visibility.Collapsed;
        ImgFirmaLogosu.Visibility=a.FirmaLogoGoster?Visibility.Visible:Visibility.Collapsed;
        ImgFirmaLogosu.Width=ImgFirmaLogosu.Height=a.FirmaLogoBoyutu;
        var sektor=MiapaxERP.Lisans.Core.UrunKatalogu.SektorBul(LisansOturumu.Gecerli?.Sector??a.Sektor);
        TxtProfilUretimBaslik.Text=sektor.Kod=="BORU"?"▥  Aktif Üretimler":sektor.Kod=="RESTORAN"?"▥  Adisyon / Mutfak":"▥  Son Üretim Kayıtları";
        BtnMenuSektorUretim.Content="≡   "+sektor.UretimAdi;
        BtnMenuUretim.Visibility=BtnMenuRecete.Visibility=sektor.Kod=="BORU"&&LisansOturumu.ModulVar("URETIM")?Visibility.Visible:Visibility.Collapsed;
        gorunum = a; Tema170.Uygula(a);
        KabukYerlesiminiUygula(a);
        muhasebePaneli?.TemayiUygula(a);
        GorunumRenkleri.Uygula(this, a);
        if (Content is FrameworkElement root) root.LayoutTransform = new ScaleTransform(a.Olcek, a.Olcek);
        try { ImgFirmaLogosu.Source = string.IsNullOrEmpty(a.Logo) ? new System.Windows.Media.Imaging.BitmapImage(new Uri("pack://application:,,,/MiapaxERP.Desktop;component/Assets/MiapaxERP_App.png")) : GorunumDeposu.Resim(a.Logo); }
        catch { ImgFirmaLogosu.Source = new System.Windows.Media.Imaging.BitmapImage(new Uri("pack://application:,,,/MiapaxERP.Desktop;component/Assets/MiapaxERP_App.png")); }
        foreach (var k in GorunumTercihleri.Kartlar)
            if (FindName("Kart" + k.Id) is FrameworkElement kart) kart.Visibility = a.GizliKartlar.Contains(k.Id) ? Visibility.Collapsed : Visibility.Visible;
        if(sektor.Kod!="BORU"){KartHaber.Visibility=KartPiyasa.Visibility=Visibility.Collapsed;}
        foreach (string id in new[] { "Cari", "Uretim" })
            if (FindName("Kart" + id) is FrameworkElement kart && kart.Parent is Grid grid)
            {
                bool herhangi = false;
                foreach (FrameworkElement child in grid.Children)
                {
                    bool visible = child.Visibility == Visibility.Visible; herhangi |= visible;
                    grid.ColumnDefinitions[Grid.GetColumn(child)].Width = visible ? new GridLength(1, GridUnitType.Star) : new GridLength(0);
                }
                grid.Visibility = herhangi ? Visibility.Visible : Visibility.Collapsed;
            }
        MedyaKarartma.Background = new SolidColorBrush(Color.FromArgb((byte)(a.Karartma * 255), 0, 0, 0));
        if (gorunumMedyaHazir) GorunumMedyaYenile();
    }
    private void GorunumMedyaYenile()
    {
        anaBannerZamanlayici.Stop(); VideoAnasayfaBanner.Stop(); VideoAnasayfaBanner.Source = null;
        VideoAnasayfaBanner.Visibility = Visibility.Collapsed; ImgAnasayfaBanner.Visibility = Visibility.Collapsed;
        ImgAnasayfaBanner.Source = null; anaBannerResimleri.Clear(); anaBannerIndeksi = 0;
        string sector=LisansOturumu.Gecerli?.Sector??gorunum.Sektor;
        if(gorunum.MedyaModu is "Varsayılan" or "Sektöre göre")
        {
            if(gorunum.SektorMedyalari.TryGetValue(sector,out var custom)&&custom.Count>0)anaBannerResimleri.AddRange(custom.Where(File.Exists));
            else
            {
                string folder=Path.Combine(AppContext.BaseDirectory,"Assets","Dashboard","Sectors",sector);
                if(Directory.Exists(folder))anaBannerResimleri.AddRange(Directory.GetFiles(folder).Where(f=>new[]{".mp4",".wmv",".jpg",".jpeg",".png",".bmp"}.Contains(Path.GetExtension(f).ToLowerInvariant())));
                else if(sector=="BORU")anaBannerResimleri.AddRange(varsayilanMedya.Where(File.Exists));
            }
        }
        else if (gorunum.MedyaModu is "Video" or "Görsel" && File.Exists(gorunum.Medya)) anaBannerResimleri.Add(gorunum.Medya);
        if (!gorunum.VideoOynat) anaBannerResimleri.RemoveAll(f => Path.GetExtension(f).Equals(".mp4", StringComparison.OrdinalIgnoreCase) || Path.GetExtension(f).Equals(".wmv", StringComparison.OrdinalIgnoreCase));
        if (anaBannerResimleri.Count > 0) { AnaBannerGuncelle(); anaBannerZamanlayici.Start(); }
        else TxtBannerSayac.Text = gorunum.MedyaModu == "Düz renk" || !gorunum.VideoOynat ? "" : "Arka plan dosyası bulunamadı; Ayarlar'dan yeniden seçebilirsiniz.";
    }
}

public static class GorunumRenkleri
{
    public static void Uygula(Control window, GorunumTercihleri a)
    {
        bool dark = a.Tema == "Koyu";
        if (a.Tema == "Sistem")
            dark = Convert.ToInt32(Microsoft.Win32.Registry.GetValue(@"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize", "AppsUseLightTheme", 1)) == 0;
        window.FontFamily = new FontFamily(a.YaziTipi);
        // Kaynak anahtarları yalnızca nötr yüzeylere uygulanır; uyarı/başarı renkleri korunur.
        foreach (string key in window.Resources.Keys.OfType<string>().Where(k => k.StartsWith("Gorunum_")).ToArray())
        {
            string original = key.Substring(8).Replace("HEX", "#");
            string value = original;
            if (original == "#2563EB") value = a.Vurgu;
            else if (a.Tema != "Varsayılan")
            {
                if (new[] { "White", "#FFFFFF", "#99FFFFFF", "#D9FFFFFF", "#F1F5F9", "#F8FAFC", "#99F4F8FF", "#D9F1F6FB", "#D9EEF4FB", "#E5E8F0F8", "#EEF4FF" }.Contains(original)) value = dark ? "#1E293B" : "#F8FAFC";
                else if (new[] { "#101C2B", "#0E1C2C", "#15263A" }.Contains(original)) value = dark ? "#0F172A" : "#E2E8F0";
                else if (new[] { "#E8F7F1", "#D3E5EF", "#DCE5F2", "#AAC9D3", "#A8C1CF" }.Contains(original)) value = dark ? "#E2E8F0" : "#334155";
                else if (new[] { "#1E3A5F", "#17263D", "#24364D", "#334155", "#475569", "#64748B" }.Contains(original)) value = dark ? "#CBD5E1" : original;
                else if (new[] { "#E3EAF3", "#E3E8EF", "#CBD5E1" }.Contains(original)) value = dark ? "#475569" : original;
            }
            if(a.Tema != "Koyu" && a.Tema != "Sistem"){var palet=Tema170.Sec(a.Tema); if(original is "#101C2B" or "#0E1C2C" or "#15263A") value=palet.Menu; else if(original is "#E8F7F1" or "#D3E5EF" or "#DCE5F2" or "#AAC9D3" or "#A8C1CF") value="#ECF4FF"; else if(original=="#2563EB" && a.Vurgu=="#2563EB")value=palet.Vurgu;else if(value=="#F8FAFC")value=palet.Yuzey;} window.Resources[key] = new SolidColorBrush((Color)ColorConverter.ConvertFromString(value));
        }
    }
}


