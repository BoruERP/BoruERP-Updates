using System.Collections;
using System.Data;
using System.Data.Common;
using System.Text.Json;
using Microsoft.Data.SqlClient;
using RawConnection=Microsoft.Data.SqlClient.SqlConnection;
using RawCommand=Microsoft.Data.SqlClient.SqlCommand;
using RawTransaction=Microsoft.Data.SqlClient.SqlTransaction;
namespace MiapaxERP.Desktop;

// Eski ekranların salt-okuma uyumluluk katmanı. HTTPS üzerinden SQL metni
// göndermez; yalnız sunucudaki sabit sorgu kimliği ve tipli değerleri yollar.
// Yazma işlemleri burada çalıştırılamaz; ilgili iş servisinden geçmelidir.
public sealed class ErpSqlConnection : IDisposable
{
    internal RawConnection? Yerel;
    internal bool Uzak=>HttpsOturumu.Uzak(ConnectionString);
    public string ConnectionString {get;}
    bool open;
    public ConnectionState State=>Yerel?.State??(open?ConnectionState.Open:ConnectionState.Closed);
    public string Database=>Yerel?.Database??"";
    public string DataSource=>Yerel?.DataSource??HttpsOturumu.Istemci?.Adres??"";
    public ErpSqlConnection(string connection){ConnectionString=connection;if(!Uzak)Yerel=new(connection);}
    ErpSqlConnection(RawConnection connection){Yerel=connection;ConnectionString=connection.ConnectionString;}
    public void Open(){if(Uzak){if(HttpsOturumu.Istemci?.Oturum is null)throw new UnauthorizedAccessException("Önce giriş yapın.");open=true;}else Yerel!.Open();}
    public async Task OpenAsync(CancellationToken ct=default){if(Uzak){ct.ThrowIfCancellationRequested();Open();}else await Yerel!.OpenAsync(ct);}
    public void Close(){if(Uzak)open=false;else Yerel!.Close();}
    public ErpSqlTransaction BeginTransaction(IsolationLevel level=IsolationLevel.ReadCommitted)=>Uzak?new(this,null):new(this,Yerel!.BeginTransaction(level));
    public ErpSqlCommand CreateCommand()=>new("",this);
    public void Dispose(){Yerel?.Dispose();open=false;}
    public static implicit operator ErpSqlConnection(RawConnection c)=>new(c);
    public static implicit operator RawConnection(ErpSqlConnection c)=>c.Yerel??throw new InvalidOperationException("Yan cihaz SQL bağlantısı açamaz.");
    public static void ClearAllPools()=>RawConnection.ClearAllPools();
}
public sealed class ErpSqlTransaction(ErpSqlConnection connection,RawTransaction? transaction) : IDisposable
{
    internal RawTransaction? Yerel=>transaction;
    public ErpSqlConnection Connection=>connection;
    public void Commit()=>transaction?.Commit();
    public void Rollback()=>transaction?.Rollback();
    public void Dispose()=>transaction?.Dispose();
    public static implicit operator RawTransaction?(ErpSqlTransaction? t)=>t?.Yerel;
    public static implicit operator ErpSqlTransaction?(RawTransaction? t)=>t is null?null:new((ErpSqlConnection)t.Connection!,t);
}
public sealed class ErpSqlCommand : IDisposable
{
    readonly RawCommand local=new();
    public string CommandText {get=>local.CommandText;set=>local.CommandText=value;}
    public int CommandTimeout {get=>local.CommandTimeout;set=>local.CommandTimeout=value;}
    public CommandType CommandType {get=>local.CommandType;set=>local.CommandType=value;}
    public SqlParameterCollection Parameters=>local.Parameters;
    public ErpSqlConnection? Connection {get;set;}
    public ErpSqlTransaction? Transaction {get;set;}
    public ErpSqlCommand(string sql,ErpSqlConnection? connection=null,ErpSqlTransaction? tx=null){CommandText=sql;Connection=connection;Transaction=tx;}
    RawCommand Local(){local.Connection=Connection?.Yerel;local.Transaction=Transaction?.Yerel;return local;}
    ErpSqlReader Remote()
    {
        var c=Connection??throw new InvalidOperationException("Bağlantı eksik.");if(c.State!=ConnectionState.Open)throw new InvalidOperationException("Bağlantı kapalı.");
        if(CommandType!=CommandType.Text)throw new InvalidOperationException("İşlem desteklenmiyor.");
        var values=Parameters.Cast<SqlParameter>().Select(p=>
        {
            object? value=p.Value is DBNull?null:p.Value;
            var type=value is null?"text":HttpsJson.Turler.SingleOrDefault(t=>t.Value==value.GetType()).Key??throw new ArgumentException("Alan türü desteklenmiyor.");
            return new ErpOkumaDegeri(p.ParameterName,p.SqlDbType,p.Size,p.Precision,p.Scale,type,JsonSerializer.SerializeToElement(value,HttpsJson.Ayarlar));
        }).ToArray();
        var result=HttpsOturumu.Cagir<ErpOkumaYaniti>(c.ConnectionString,"ErpOkumaServisi.Oku","",[new ErpOkumaIstegi(ErpOkumaServisi.Kimlik(CommandText),values)]);
        return new(new DataTableReader(result.Tablolar.Length==0?[new DataTable()]:result.Tablolar));
    }
    public ErpSqlReader ExecuteReader()=>Connection?.Uzak==true?Remote():new(Local().ExecuteReader());
    public ErpSqlReader ExecuteReader(CommandBehavior behavior)=>Connection?.Uzak==true?Remote():new(Local().ExecuteReader(behavior));
    public object? ExecuteScalar(){if(Connection?.Uzak!=true)return Local().ExecuteScalar();using var r=Remote();return r.Read()&&r.FieldCount>0?r.GetValue(0):null;}
    public int ExecuteNonQuery(){if(Connection?.Uzak==true)throw new InvalidOperationException("Bu yazma işlemi iş servisine taşınmalı; yan cihaz SQL çalıştıramaz.");return Local().ExecuteNonQuery();}
    public void Dispose()=>local.Dispose();
}
public sealed class ErpSqlDataAdapter(ErpSqlCommand command) : IDisposable
{
    public ErpSqlDataAdapter(string sql,ErpSqlConnection connection):this(new ErpSqlCommand(sql,connection)){}
    public int Fill(DataTable t){using var r=command.ExecuteReader();t.Load(r);return t.Rows.Count;}
    public void Dispose()=>command.Dispose();
}
public sealed class ErpSqlReader(DbDataReader reader) : DbDataReader
{
    public override object this[int ordinal]=>reader[ordinal];public override object this[string name]=>reader[name];
    public override int Depth=>reader.Depth;public override int FieldCount=>reader.FieldCount;public override bool HasRows=>reader.HasRows;public override bool IsClosed=>reader.IsClosed;public override int RecordsAffected=>reader.RecordsAffected;
    public override bool Read()=>reader.Read();public override bool NextResult()=>reader.NextResult();public override void Close()=>reader.Close();
    protected override void Dispose(bool disposing){if(disposing)reader.Dispose();base.Dispose(disposing);}
    public override DataTable? GetSchemaTable()=>reader.GetSchemaTable();public override IEnumerator GetEnumerator()=>((IEnumerable)reader).GetEnumerator();
    public override bool GetBoolean(int i)=>reader.GetBoolean(i);public override byte GetByte(int i)=>reader.GetByte(i);public override long GetBytes(int i,long o,byte[]? b,int bo,int l)=>reader.GetBytes(i,o,b,bo,l);
    public override char GetChar(int i)=>reader.GetChar(i);public override long GetChars(int i,long o,char[]? b,int bo,int l)=>reader.GetChars(i,o,b,bo,l);
    public override string GetDataTypeName(int i)=>reader.GetDataTypeName(i);public override DateTime GetDateTime(int i)=>reader.GetDateTime(i);public override decimal GetDecimal(int i)=>reader.GetDecimal(i);public override double GetDouble(int i)=>reader.GetDouble(i);public override Type GetFieldType(int i)=>reader.GetFieldType(i);public override float GetFloat(int i)=>reader.GetFloat(i);public override Guid GetGuid(int i)=>reader.GetGuid(i);public override short GetInt16(int i)=>reader.GetInt16(i);public override int GetInt32(int i)=>reader.GetInt32(i);public override long GetInt64(int i)=>reader.GetInt64(i);public override string GetName(int i)=>reader.GetName(i);public override int GetOrdinal(string n)=>reader.GetOrdinal(n);public override string GetString(int i)=>reader.GetString(i);public override object GetValue(int i)=>reader.GetValue(i);public override int GetValues(object[] v)=>reader.GetValues(v);public override bool IsDBNull(int i)=>reader.IsDBNull(i);public override T GetFieldValue<T>(int i)=>reader.GetFieldValue<T>(i);
}
