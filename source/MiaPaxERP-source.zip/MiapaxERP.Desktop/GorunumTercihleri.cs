using System.IO;
using System.Text;
using System.Text.Json;
using System.Security.Cryptography;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace MiapaxERP.Desktop;

public sealed class GorunumTercihleri
{
    public string FirmaBasligi { get; set; } = "MiapaxERP";
    public string FirmaMetni { get; set; } = "İŞLETMENİZE ÖZEL";
    public string FirmaAltMetni { get; set; } = "AKILCI YÖNETİM";
    public bool FirmaLogoGoster { get; set; } = true;
    public bool FirmaAdiGoster { get; set; } = true;
    public double FirmaLogoBoyutu { get; set; } = 65;
    public string Sektor { get; set; } = "BORU";
    public Dictionary<string,List<string>> SektorMedyalari { get; set; } = new();
    public string Tema { get; set; } = "Modern";
    public string Yerlesim { get; set; } = "Temaya göre";
    public string Yogunluk { get; set; } = "Temaya göre";
    public string AnaSayfaDuzeni { get; set; } = "Temaya göre";
    public double Kose { get; set; } = -1;
    public bool Golge { get; set; } = true;
    public int KisayolSutun { get; set; } = 0;
    public string Vurgu { get; set; } = "#2563EB";
    public string YaziTipi { get; set; } = "Segoe UI";
    public double Olcek { get; set; } = 1;
    public string MedyaModu { get; set; } = "Sektöre göre";
    public string Medya { get; set; } = "";
    public string Logo { get; set; } = "";
    public double Karartma { get; set; } = .13;
    public bool VideoOynat { get; set; } = true;
    public List<string> GizliKartlar { get; set; } = new();
    public static readonly (string Id, string Ad)[] Kartlar = {
        ("Haber", "Sektör haberleri"), ("Kisayol", "Modül kısayolları"),
        ("Kur", "Günlük döviz kurları"), ("Cari", "Borçlu cariler"),
        ("Stok", "Kritik stoklar"), ("Evrak", "Bugünkü çek / senet"),
        ("Uretim", "Aktif üretimler"), ("Odeme", "Yaklaşan ödemeler"),
        ("Piyasa", "Firma / piyasa fiyatları") };
    public GorunumTercihleri Kopya() => JsonSerializer.Deserialize<GorunumTercihleri>(JsonSerializer.Serialize(this))!;
    public void Dogrula()
    {
        FirmaBasligi = string.IsNullOrWhiteSpace(FirmaBasligi) ? "MiapaxERP" : FirmaBasligi.Trim();
        if (FirmaBasligi is "BoruERP" or "MiaSoft") FirmaBasligi = "MiapaxERP";
        if (FirmaBasligi.Length > 60 || FirmaBasligi.Any(char.IsControl)) throw new InvalidDataException("Firma başlığı tek satır ve en fazla 60 karakter olmalı.");
        if(new[]{FirmaMetni,FirmaAltMetni}.Any(v=>v is null||v.Length>100||v.Any(char.IsControl)))throw new InvalidDataException("Firma yazıları tek satır ve en fazla 100 karakter olmalı.");
        if(!FirmaLogoGoster&&!FirmaAdiGoster)throw new InvalidDataException("Firma adı veya logo görünür olmalı.");
        if(!double.IsFinite(FirmaLogoBoyutu)||FirmaLogoBoyutu<30||FirmaLogoBoyutu>120)throw new InvalidDataException("Logo boyutu 30–120 olmalı.");
        MiapaxERP.Lisans.Core.UrunKatalogu.SektorBul(Sektor);
        SektorMedyalari??=new();
        foreach(var pair in SektorMedyalari){MiapaxERP.Lisans.Core.UrunKatalogu.SektorBul(pair.Key);if(pair.Value is null||pair.Value.Count>12||pair.Value.Any(v=>string.IsNullOrWhiteSpace(v)||!new[]{".mp4",".wmv",".png",".jpg",".jpeg",".bmp"}.Contains(Path.GetExtension(v).ToLowerInvariant())))throw new InvalidDataException("Sektör başına en fazla 12 geçerli medya seçin.");}
        if (!Tema170.Adlar.Contains(Tema)) throw new InvalidDataException("Geçersiz tema.");
        if (!new[] { "Temaya göre", "Sol menü", "Üst menü", "Sağ menü" }.Contains(Yerlesim)) throw new InvalidDataException("Geçersiz yerleşim.");
        if (!new[] { "Temaya göre", "Kompakt", "Dengeli", "Ferah" }.Contains(Yogunluk)) throw new InvalidDataException("Geçersiz yoğunluk.");
        if (!new[] { "Temaya göre", "Takvim odaklı", "Modül odaklı", "Haber odaklı" }.Contains(AnaSayfaDuzeni)) throw new InvalidDataException("Geçersiz ana sayfa düzeni.");
        if (!double.IsFinite(Kose) || Kose < -1 || Kose > 28) throw new InvalidDataException("Köşe yuvarlaklığı 0–28 olmalı.");
        if (KisayolSutun != 0 && (KisayolSutun < 3 || KisayolSutun > 7)) throw new InvalidDataException("Kısayol sütunu 3–7 olmalı.");
        if (!System.Text.RegularExpressions.Regex.IsMatch(Vurgu ?? "", "^#[0-9a-fA-F]{6}$")) throw new InvalidDataException("Vurgu rengini #2563EB biçiminde yazın.");
        if (!double.IsFinite(Olcek) || Olcek < .85 || Olcek > 1.3) throw new InvalidDataException("Görünüm boyutu %85–130 arasında olmalı.");
        if (!double.IsFinite(Karartma) || Karartma < 0 || Karartma > .85) throw new InvalidDataException("Karartma değeri geçersiz.");
        if (!new[] { "Varsayılan", "Sektöre göre", "Düz renk", "Görsel", "Video" }.Contains(MedyaModu)) throw new InvalidDataException("Geçersiz arka plan türü.");
        if (string.IsNullOrWhiteSpace(YaziTipi)) YaziTipi = "Segoe UI";
        GizliKartlar ??= new();
        GizliKartlar = GizliKartlar.Where(id => Kartlar.Any(k => k.Id == id)).Distinct().ToList();
    }
}

public static class GorunumDeposu
{
    public static string Klasor(string baglanti, int id) => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "BoruERP", "Gorunum", Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(baglanti))).Substring(0, 16), id.ToString());
    public static GorunumTercihleri Oku(string klasor)
    {
        string yol = Path.Combine(klasor, "tercihler.json");
        if (!File.Exists(yol)) return new();
        try { var a = JsonSerializer.Deserialize<GorunumTercihleri>(File.ReadAllText(yol)) ?? new(); a.Dogrula(); return a; }
        catch (Exception ex) when (ex is IOException or JsonException or InvalidDataException or UnauthorizedAccessException)
        { System.Diagnostics.Trace.WriteLine("Görünüm ayarları okunamadı: " + ex.Message); return new(); }
    }
    public static void Kaydet(string klasor, GorunumTercihleri a)
    {
        a.Dogrula(); Directory.CreateDirectory(klasor);
        string hedef = Path.Combine(klasor, "tercihler.json"), gecici = hedef + ".tmp";
        File.WriteAllText(gecici, JsonSerializer.Serialize(a, new JsonSerializerOptions { WriteIndented = true }));
        File.Move(gecici, hedef, true);
    }
    public static bool EskiUygulamaLogosu(string yol)
    {
        using var stream = File.OpenRead(yol);
        string hash = Convert.ToHexString(SHA256.HashData(stream));
        return hash is "69F703F62C83305FBD063C045EA640267ECC854C09A3C8001DCB7930E59ED484" or "4316E1B71705B3F67935A8636C8A702F258C71E3C6453B3A04D94D445B3B7341";
    }
    public static BitmapImage Resim(string yol)
    {
        var b = new BitmapImage(); b.BeginInit(); b.CacheOption = BitmapCacheOption.OnLoad;
        b.DecodePixelWidth = 1600; b.UriSource = new Uri(yol, UriKind.Absolute); b.EndInit(); b.Freeze(); return b;
    }
    public static async Task<string> MedyaAl(string kaynak, string klasor, bool logo)
    {
        string ext = Path.GetExtension(kaynak).ToLowerInvariant();
        var izin = logo ? new[] { ".pdf", ".png", ".jpg", ".jpeg", ".bmp" } : new[] { ".png", ".jpg", ".jpeg", ".bmp", ".mp4", ".wmv" };
        if (!izin.Contains(ext)) throw new InvalidDataException("Desteklenmeyen dosya türü.");
        if (new FileInfo(kaynak).Length > (logo ? 25L : 500L) * 1024 * 1024) throw new InvalidDataException(logo ? "Logo en fazla 25 MB olabilir." : "Medya en fazla 500 MB olabilir.");
        Directory.CreateDirectory(klasor);
        string hedef = Path.Combine(klasor, Guid.NewGuid().ToString("N") + (ext == ".pdf" ? ".png" : ext));
        try
        {
            if (ext == ".pdf") await PdfLogo(kaynak, hedef);
            else await Task.Run(() => File.Copy(kaynak, hedef));
            if (ext != ".mp4" && ext != ".wmv") _ = Resim(hedef);
            return hedef;
        }
        catch { if (File.Exists(hedef)) File.Delete(hedef); throw; }
    }
    private static async Task PdfLogo(string kaynak, string hedef)
    {
        // Windows'un yerleşik PDF işleyicisi. Dosya yolları komut olarak yorumlanmaz.
        string B64(string s) => Convert.ToBase64String(Encoding.UTF8.GetBytes(s));
        string script = """
            $ErrorActionPreference='Stop'
            Add-Type -AssemblyName System.Runtime.WindowsRuntime
            [Windows.Storage.StorageFile,Windows.Storage,ContentType=WindowsRuntime] > $null
            [Windows.Data.Pdf.PdfDocument,Windows.Data.Pdf,ContentType=WindowsRuntime] > $null
            [Windows.Storage.Streams.InMemoryRandomAccessStream,Windows.Storage.Streams,ContentType=WindowsRuntime] > $null
            function AwaitResult($op,$type) {
              $m=[System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetGenericArguments().Count -eq 1 -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' } | Select-Object -First 1
              $t=$m.MakeGenericMethod($type).Invoke($null,@($op)); $t.GetAwaiter().GetResult()
            }
            function AwaitAction($op) {
              $m=[System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and -not $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction' } | Select-Object -First 1
              $t=$m.Invoke($null,@($op)); $t.GetAwaiter().GetResult()
            }
            """;
        script += $"\n$src=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('{B64(kaynak)}'))\n$dst=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('{B64(hedef)}'))\n";
        script += """
            $file=AwaitResult ([Windows.Storage.StorageFile]::GetFileFromPathAsync($src)) ([Windows.Storage.StorageFile])
            $pdf=AwaitResult ([Windows.Data.Pdf.PdfDocument]::LoadFromFileAsync($file)) ([Windows.Data.Pdf.PdfDocument])
            if($pdf.PageCount -lt 1){throw 'PDF boş.'}
            $page=$pdf.GetPage(0)
            $stream=New-Object Windows.Storage.Streams.InMemoryRandomAccessStream
            try {
              $options=New-Object Windows.Data.Pdf.PdfPageRenderOptions
              $options.DestinationWidth=1600
              AwaitAction ($page.RenderToStreamAsync($stream,$options))
              $reader=[System.IO.WindowsRuntimeStreamExtensions]::AsStreamForRead($stream)
              $out=[IO.File]::Create($dst)
              try {$reader.CopyTo($out)} finally {$out.Dispose();$reader.Dispose()}
            } finally {$page.Dispose();$stream.Dispose()}
            """;
        var info = new System.Diagnostics.ProcessStartInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "WindowsPowerShell", "v1.0", "powershell.exe"))
        { UseShellExecute = false, CreateNoWindow = true, RedirectStandardError = true, RedirectStandardOutput = true };
        foreach (string arg in new[] { "-NoProfile", "-NonInteractive", "-EncodedCommand", Convert.ToBase64String(Encoding.Unicode.GetBytes(script)) }) info.ArgumentList.Add(arg);
        using var p = System.Diagnostics.Process.Start(info) ?? throw new IOException("PDF dönüştürücü başlatılamadı.");
        var err = p.StandardError.ReadToEndAsync(); var stdout = p.StandardOutput.ReadToEndAsync();
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(45));
        try { await p.WaitForExitAsync(timeout.Token); }
        catch (OperationCanceledException) { p.Kill(true); throw new IOException("PDF dönüştürme zaman aşımına uğradı. PNG veya JPG deneyin."); }
        await stdout; string hata = await err;
        if (p.ExitCode != 0 || !File.Exists(hedef)) throw new IOException("PDF açılamadı. Şifresiz ve geçerli bir PDF seçin veya PNG/JPG kullanın. " + (hata.Contains("password", StringComparison.OrdinalIgnoreCase) ? "PDF şifreli." : ""));
    }
}
