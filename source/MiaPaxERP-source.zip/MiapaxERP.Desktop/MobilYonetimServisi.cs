using System.Data;
namespace MiapaxERP.Desktop;
public sealed class MobilYonetimServisi(string connection,int user)
{
    public void Kur(){if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"MobilYonetimServisi.Kur","",new object?[]{});return;}new MobilHesapServisi(connection).Kur(user);}
    public DataTable Liste(){if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"MobilYonetimServisi.Liste","",new object?[]{});}return new MobilHesapServisi(connection).Liste(user);}
    public Guid Kaydet(int hedefKullanici,string ad,string rol){if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<Guid>(connection,"MobilYonetimServisi.Kaydet","",new object?[]{hedefKullanici,ad,rol});}return new MobilHesapServisi(connection).Kaydet(user,hedefKullanici,ad,rol);}
    public string Esle(Guid id){if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<string>(connection,"MobilYonetimServisi.Esle","",new object?[]{id});}return new MobilHesapServisi(connection).Esle(user,id);}
    public void Iptal(Guid id){if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"MobilYonetimServisi.Iptal","",new object?[]{id});return;}new MobilHesapServisi(connection).Iptal(user,id);}
}
