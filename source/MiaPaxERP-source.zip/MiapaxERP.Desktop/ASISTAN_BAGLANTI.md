# MiapaxERP Asistanı bağlantısı

Programdaki Asistan → Bağlantı bölümünden kullanıcıya özel bağlantı ayarlanır. Sunucu kurulu değilken Yerleşik rehber seçili kalsın. Bu durumda 20 kullanım eğitimi ve mevcut ekran rehberi internet olmadan çalışır; genel sorular için dil modeli varmış gibi yanıt üretilmez.

## MiapaxERP aracı sunucusu

Tam POST adresi girilir; örnek: http://127.0.0.1:5189/api/yardim. Uzak adreslerde HTTPS gerekir. API anahtarları masaüstü uygulamasında veya URL'de tutulmaz; sağlayıcı bağlantısı aracı sunucuda yapılandırılır.

İstek JSON alanları:
- soru: kullanıcının son sorusu.
- modul: açık ekran; veri tabanı kayıtlarını içermez.
- messages: ilk system mesajında doğrulanmış program rehberi, ardından en fazla 12 sohbet mesajı ve son soru. Aracı sunucu sohbeti modele iletirken bu diziyi kullanmalıdır. Aynı soruyu ayrıca eklememelidir.
- rehber: eski sözleşmeler için aynı program rehberinin metni.

Yanıt: {"yanit":"Kullanıcıya gösterilecek metin"}

Eski yalnız soru/modul sözleşmesi geriye uyumludur; ancak messages/rehber kullanmayan eski sunucu yeni eğitim bağlamından ve geçmiş mesajlardan yararlanamaz. Model yanıtları düz metin gösterilir, kod veya SQL olarak çalıştırılmaz.

## Ollama

Ollama ayrıca kurulmuş ve bir sohbet modeli yüklenmiş olmalıdır. Bağlantı türü Ollama, tam adres örneği http://127.0.0.1:11434/api/chat ve model alanı kurulu modelin tam adı olmalıdır. Bu değişiklik model indirmez veya sunucu kurmaz. İstek messages, model ve stream:false kullanır; yanıt message.content alanından okunur. Resmî protokol: https://github.com/ollama/ollama/blob/main/docs/api.md

## Kontrol ve sınırlar

Bağlantıyı dene yalnız sentetik bir merhaba sorusu ve program rehberi gönderir; mevcut sohbeti göndermez. Başarılı testten sonra Kaydet kullanılmalıdır. Bağlantı değiştirilince sohbet temizlenir. Genel konulardaki yanıt kalitesi bağlanan modele bağlıdır; internet araması ve şirket verilerini otomatik okuma bu sürüme dahil değildir.

Sohbet yalnız bellekte tutulur; oturum kapanınca ve Yeni sohbet seçilince temizlenir. İstek Durdur ile iptal edilebilir; toplam bekleme sınırı 60 saniyedir. Sunucu hatası, geçersiz yanıt veya bağlantı kesintisinde yerleşik rehber kullanılabilir. Güncel vergi/mevzuat veya canlı şirket bakiyesi uydurulmamalıdır.
