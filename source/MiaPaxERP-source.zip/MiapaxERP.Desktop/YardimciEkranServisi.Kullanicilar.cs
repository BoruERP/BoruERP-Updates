using System.Data;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed partial class YardimciEkranServisi
{
    public int KullaniciKaydet(ErpKullaniciGirdisi input)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<int>(connection,"YardimciEkranServisi.KullaniciKaydet","",new object?[]{input});}

        Metin(input.KullaniciAdi,3,60,"Kullanıcı adı");Metin(input.AdSoyad,3,120,"Ad soyad");Metin(input.Eposta,0,254,"E-posta");
        if(!input.Id.HasValue&&(string.IsNullOrWhiteSpace(input.IlkSifre)||input.IlkSifre.Length is <12 or >128))throw new ArgumentException("İlk şifre 12–128 karakter olmalı.");
        using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yonetici(c,t);
        bool nextAdmin;
        using(var role=Q(c,t,"SELECT CASE WHEN RolAdi=N'Yönetici' THEN 1 ELSE 0 END FROM dbo.KullaniciRolleri WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Aktif=1",("@id",input.Rol)))
        {var result=role.ExecuteScalar()??throw new ArgumentException("Aktif rol seçin.");nextAdmin=Convert.ToInt32(result)==1;}
        int id;
        if(input.Id.HasValue)
        {
            id=input.Id.Value;if(id==user&&(!nextAdmin||!input.Aktif))throw new InvalidOperationException("Kendi yönetici rolünüzü kaldıramaz veya hesabınızı pasife alamazsınız.");
            if(!nextAdmin||!input.Aktif)
            {
                using var old=Q(c,t,"SELECT COUNT(*) FROM dbo.Kullanicilar k WITH(UPDLOCK,HOLDLOCK) JOIN dbo.KullaniciRolAtamalari a ON a.KullaniciId=k.Id JOIN dbo.KullaniciRolleri r ON r.Id=a.RolId WHERE k.Id=@id AND k.Aktif=1 AND r.Aktif=1 AND r.RolAdi=N'Yönetici'",("@id",id));
                if(Convert.ToInt32(old.ExecuteScalar())>0){using var count=Q(c,t,"SELECT COUNT(DISTINCT k.Id) FROM dbo.Kullanicilar k WITH(UPDLOCK,HOLDLOCK) JOIN dbo.KullaniciRolAtamalari a ON a.KullaniciId=k.Id JOIN dbo.KullaniciRolleri r ON r.Id=a.RolId WHERE k.Aktif=1 AND r.Aktif=1 AND r.RolAdi=N'Yönetici'");if(Convert.ToInt32(count.ExecuteScalar())<=1)throw new InvalidOperationException("Son aktif yönetici kaldırılamaz.");}
            }
            using var q=Q(c,t,"UPDATE dbo.Kullanicilar SET KullaniciAdi=@a,AdSoyad=@ad,Eposta=@e,Aktif=@aktif,GuncellemeTarihiUtc=SYSUTCDATETIME() WHERE Id=@id",("@a",input.KullaniciAdi.Trim()),("@ad",input.AdSoyad.Trim()),("@e",input.Eposta.Trim().Length==0?null:input.Eposta.Trim()),("@aktif",input.Aktif),("@id",id));if(q.ExecuteNonQuery()!=1)throw new InvalidOperationException("Kullanıcı bulunamadı.");
        }
        else
        {
            using var q=Q(c,t,"INSERT dbo.Kullanicilar(KullaniciAdi,AdSoyad,Eposta,SifreOzeti,Aktif,SifreDegistirmeli) OUTPUT INSERTED.Id VALUES(@a,@ad,@e,@h,@aktif,1)",("@a",input.KullaniciAdi.Trim()),("@ad",input.AdSoyad.Trim()),("@e",input.Eposta.Trim().Length==0?null:input.Eposta.Trim()),("@h",GirisPenceresi.SifreOzetiOlustur(input.IlkSifre)),("@aktif",input.Aktif));id=Convert.ToInt32(q.ExecuteScalar());
        }
        using(var remove=Q(c,t,"DELETE dbo.KullaniciRolAtamalari WHERE KullaniciId=@id",("@id",id)))remove.ExecuteNonQuery();
        using(var assign=Q(c,t,"INSERT dbo.KullaniciRolAtamalari(KullaniciId,RolId) VALUES(@id,@rol)",("@id",id),("@rol",input.Rol)))assign.ExecuteNonQuery();
        t.Commit();return id;
    }
    public void KullaniciSifreSifirla(int id,string password)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"YardimciEkranServisi.KullaniciSifreSifirla","",new object?[]{id,password});return;}

        if(string.IsNullOrWhiteSpace(password)||password.Length is <12 or >128)throw new ArgumentException("Şifre 12–128 karakter olmalı.");
        using var c=access.Ac();using var t=c.BeginTransaction();Yonetici(c,t);using var q=Q(c,t,"UPDATE dbo.Kullanicilar SET SifreOzeti=@h,SifreDegistirmeli=1,BasarisizGirisSayisi=0,KilitBitisUtc=NULL,GuncellemeTarihiUtc=SYSUTCDATETIME() WHERE Id=@id",("@h",GirisPenceresi.SifreOzetiOlustur(password)),("@id",id));if(q.ExecuteNonQuery()!=1)throw new InvalidOperationException("Kullanıcı bulunamadı.");t.Commit();
    }
    public void KullaniciYetkileri(int id,ErpYetkiKarari[] decisions)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"YardimciEkranServisi.KullaniciYetkileri","",new object?[]{id,decisions});return;}

        if(decisions is null||decisions.Length>2000||decisions.Select(d=>d.Id).Distinct().Count()!=decisions.Length)throw new ArgumentException("Yetki listesi geçersiz.");
        using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yonetici(c,t);
        using(var exists=Q(c,t,"SELECT COUNT(*) FROM dbo.Kullanicilar WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id",("@id",id)))if(Convert.ToInt32(exists.ExecuteScalar())!=1)throw new ArgumentException("Kullanıcı bulunamadı.");
        using(var clear=Q(c,t,"DELETE ky FROM dbo.KullaniciYetkileri ky JOIN dbo.Yetkiler y ON y.Id=ky.YetkiId WHERE ky.KullaniciId=@id AND y.YetkiKodu NOT IN(N'USERS.MANAGE',N'PERMISSIONS.MANAGE')",("@id",id)))clear.ExecuteNonQuery();
        foreach(var item in decisions)
        {
            if(item.Izin is null)continue;
            using var q=Q(c,t,"INSERT dbo.KullaniciYetkileri(KullaniciId,YetkiId,IzinVerildi,GuncelleyenKullaniciId) SELECT @id,y.Id,@izin,@u FROM dbo.Yetkiler y WHERE y.Id=@p AND y.Aktif=1 AND y.YetkiKodu NOT IN(N'USERS.MANAGE',N'PERMISSIONS.MANAGE')",("@id",id),("@izin",item.Izin),("@u",user),("@p",item.Id));if(q.ExecuteNonQuery()!=1)throw new ArgumentException("Korunan veya geçersiz yetki değiştirilemez.");
        }
        t.Commit();
    }
}
