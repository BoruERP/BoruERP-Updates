using System;
using System.Globalization;
using System.Linq;
using System.Printing;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using ZXing;
using ZXing.Common;

namespace MiapaxERP.Desktop;

public sealed class BarkodEtiketiPenceresi : Window
{
    private readonly TextBox urun = new() { Text = "Polietilen PE100" };
    private readonly TextBox firma = new() { Text = "Örnek Plastik A.Ş." };
    private readonly DatePicker tarih = new() { SelectedDate = DateTime.Today };
    private readonly TextBox lot = new() { Text = "HM-2026-000125" };
    private readonly TextBox kg = new() { Text = "25" };
    private readonly ComboBox boyut = new();
    private readonly ComboBox yazicilar = new();
    private readonly Border onizleme = new() { Background = Brushes.White, BorderBrush = Brushes.LightGray, BorderThickness = new Thickness(1), Padding = new Thickness(9) };

    public BarkodEtiketiPenceresi()
    {
        Title = "MiapaxERP | Barkod Etiketi Yazdır";
        Width = 760; Height = 760; MinWidth = 590; MinHeight = 620;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        Background = new SolidColorBrush(Color.FromRgb(242, 246, 252));

        var ana = new StackPanel { Margin = new Thickness(20) };
        var kaydir = new ScrollViewer { Content = ana, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        Content = kaydir;
        ana.Children.Add(new TextBlock { Text = "🏷 Hammadde Barkod Etiketi", FontSize = 23, FontWeight = FontWeights.Bold, Foreground = Brushes.DarkSlateBlue, Margin = new Thickness(0, 0, 0, 12) });
        Alan(ana, "Hammadde", urun);
        Alan(ana, "Tedarikçi firma", firma);
        Alan(ana, "Giriş tarihi", tarih);
        Alan(ana, "Lot / Barkod numarası", lot);
        Alan(ana, "Paket miktarı (KG)", kg);

        boyut.Items.Add("50 × 30 mm"); boyut.Items.Add("70 × 40 mm"); boyut.Items.Add("100 × 60 mm");
        boyut.SelectedIndex = 2;
        Alan(ana, "Etiket ölçüsü", boyut);
        Alan(ana, "Windows yazıcısı", yazicilar);
        var butonlar = new WrapPanel { Margin = new Thickness(0, 10, 0, 12) };
        ana.Children.Add(butonlar);
        Buton(butonlar, "↻ Yazıcıları Yenile", (_, _) => YazicilariYukle());
        Buton(butonlar, "👁 Önizleme", (_, _) => Onizle());
        Buton(butonlar, "🖨 Yazdır", (_, _) => Yazdir());
        ana.Children.Add(new TextBlock { Text = "Etiket önizlemesi (ekrandaki boyut temsilidir)", FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 4, 0, 8) });
        ana.Children.Add(onizleme);
        ana.Children.Add(new TextBlock { Text = "Not: Termal yazıcının kâğıt ölçüsünü Windows yazıcı sürücüsünde de seçin. Yazdırma stok miktarını değiştirmez.", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 12, 0, 0), Foreground = Brushes.DimGray });
        YazicilariYukle();
        Onizle();
    }

    private static void Alan(Panel panel, string baslik, Control kontrol)
    {
        panel.Children.Add(new TextBlock { Text = baslik, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 6, 0, 3) });
        kontrol.MinHeight = 31;
        panel.Children.Add(kontrol);
    }

    private static void Buton(Panel panel, string metin, RoutedEventHandler islem)
    {
        var b = new Button { Content = metin, Padding = new Thickness(13, 9, 13, 9), Margin = new Thickness(0, 0, 8, 0), Background = new SolidColorBrush(Color.FromRgb(37, 99, 235)), Foreground = Brushes.White, BorderThickness = new Thickness(0), Cursor = System.Windows.Input.Cursors.Hand };
        b.Click += islem;
        panel.Children.Add(b);
    }

    private void YazicilariYukle()
    {
        yazicilar.Items.Clear();
        try
        {
            using var sunucu = new LocalPrintServer();
            foreach (var y in sunucu.GetPrintQueues().OrderBy(q => q.Name))
                yazicilar.Items.Add(y.Name);
            var varsayilan = sunucu.DefaultPrintQueue?.Name;
            yazicilar.SelectedItem = varsayilan;
            if (yazicilar.SelectedIndex < 0 && yazicilar.Items.Count > 0) yazicilar.SelectedIndex = 0;
        }
        catch (Exception ex) { MessageBox.Show("Yazıcı listesi alınamadı: " + ex.Message); }
    }

    private (double genislik, double yukseklik) Olcu()
        => boyut.SelectedIndex switch { 0 => (50, 30), 1 => (70, 40), _ => (100, 60) };

    private FrameworkElement EtiketOlustur(double w, double h)
    {
        var kod = lot.Text.Trim();
        if (string.IsNullOrWhiteSpace(kod)) throw new InvalidOperationException("Lot / barkod numarası boş olamaz.");
        if (kod.Any(c => c < 32 || c > 126)) throw new InvalidOperationException("Code 128 barkod için lot numarasında yalnızca standart Latin harfleri, rakam ve işaretler kullanın.");
        if (!decimal.TryParse(kg.Text, NumberStyles.Number, CultureInfo.GetCultureInfo("tr-TR"), out var miktar) || miktar <= 0)
            throw new InvalidOperationException("Geçerli, sıfırdan büyük bir KG miktarı girin.");
        if (tarih.SelectedDate is null) throw new InvalidOperationException("Giriş tarihini seçin.");

        var piksel = new ZXing.BarcodeWriterPixelData
        {
            Format = BarcodeFormat.CODE_128,
            Options = new EncodingOptions { Width = 700, Height = 105, Margin = 4, PureBarcode = true }
        }.Write(kod);
        var bmp = BitmapSource.Create(piksel.Width, piksel.Height, 96, 96, PixelFormats.Bgra32, null, piksel.Pixels, piksel.Width * 4);
        bmp.Freeze();

        double katsayi = Math.Min(w / 378, h / 227);
        double f = Math.Max(0.55, katsayi);
        var icerik = new StackPanel { Margin = new Thickness(5) };
        icerik.Children.Add(Satir("MIAPAX ERP  |  HAMMADDE", 17 * f, true));
        icerik.Children.Add(Satir(urun.Text.Trim(), 14 * f, true));
        icerik.Children.Add(Satir("Firma: " + firma.Text.Trim(), 12 * f));
        icerik.Children.Add(Satir("Giriş: " + tarih.SelectedDate.Value.ToString("dd.MM.yyyy"), 12 * f));
        icerik.Children.Add(Satir("Lot: " + kod + "    •    " + miktar.ToString("0.###", CultureInfo.GetCultureInfo("tr-TR")) + " KG", 12 * f, true));
        icerik.Children.Add(new System.Windows.Controls.Image { Source = bmp, Stretch = Stretch.Fill, Height = Math.Max(28, h * 0.27), Margin = new Thickness(0, 6, 0, 0) });
        icerik.Children.Add(Satir(kod, 10 * f, false, TextAlignment.Center));
        return new Border { Width = w, Height = h, Background = Brushes.White, BorderBrush = Brushes.LightGray, BorderThickness = new Thickness(0.5), Child = icerik, ClipToBounds = true };
    }

    private static TextBlock Satir(string metin, double punto, bool kalin = false, TextAlignment hizalama = TextAlignment.Left)
        => new() { Text = metin, FontSize = punto, FontWeight = kalin ? FontWeights.Bold : FontWeights.Normal, Foreground = Brushes.Black, TextAlignment = hizalama, TextTrimming = TextTrimming.CharacterEllipsis, Margin = new Thickness(0, 1, 0, 1) };

    private void Onizle()
    {
        try
        {
            var (mmW, mmH) = Olcu();
            double olcek = 96 / 25.4;
            var etiket = EtiketOlustur(mmW * olcek, mmH * olcek);
            var alan = new Viewbox { Child = etiket, Stretch = Stretch.Uniform, MaxWidth = 570, MaxHeight = 270 };
            onizleme.Child = alan;
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Etiket kontrolü", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    private void Yazdir()
    {
        try
        {
            if (yazicilar.SelectedItem is not string ad) { MessageBox.Show("Önce bir yazıcı seçin."); return; }
            var (mmW, mmH) = Olcu();
            double katsayi = 96 / 25.4;
            var etiket = EtiketOlustur(mmW * katsayi, mmH * katsayi);
            var diyalog = new System.Windows.Controls.PrintDialog();
            using var sunucu = new LocalPrintServer();
            diyalog.PrintQueue = sunucu.GetPrintQueue(ad);
            if (diyalog.ShowDialog() != true) return;
            // Yazıcı sürücüsünün seçili kâğıt ölçüsü kullanılır.
            // Etiket sayfaya sığmıyorsa ölçeklenir; stok verisine dokunulmaz.
            double alanW = diyalog.PrintableAreaWidth;
            double alanH = diyalog.PrintableAreaHeight;
            if (alanW <= 0 || alanH <= 0) throw new InvalidOperationException("Yazıcının yazdırılabilir alanı okunamadı.");
            double oran = Math.Min(1, Math.Min(alanW / etiket.Width, alanH / etiket.Height));
            etiket.LayoutTransform = new ScaleTransform(oran, oran);
            etiket.Measure(new System.Windows.Size(alanW, alanH));
            etiket.Arrange(new Rect(0, 0, etiket.DesiredSize.Width, etiket.DesiredSize.Height));
            etiket.UpdateLayout();
            diyalog.PrintVisual(etiket, "MiapaxERP Hammadde Barkod Etiketi");
            MessageBox.Show("Etiket yazdırma işi yazıcıya gönderildi.", "MiapaxERP");
        }
        catch (Exception ex) { MessageBox.Show("Yazdırma hatası: " + ex.Message, "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Error); }
    }
}
