using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace MiapaxERP.Desktop;

public sealed record Tema170(string Zemin, string Yuzey, string Menu, string Vurgu, double Kose)
{
    public static GorunumTercihleri Mevcut { get; private set; } = new();
    public static string AnaSayfaDuzeni(GorunumTercihleri a) => a.AnaSayfaDuzeni != "Temaya göre" ? a.AnaSayfaDuzeni : a.Tema is "VIP" or "Eskitme" ? "Modül odaklı" : a.Tema is "Doğal" or "Kültürel" ? "Haber odaklı" : "Takvim odaklı";
    public static readonly string[] Adlar = ["VIP", "Modern", "Doğal", "Eskitme", "Kültürel", "Klasik", "Canlı", "Yenilikçi", "Varsayılan", "Açık", "Koyu", "Sistem"];
    public static string Yerlesim(GorunumTercihleri a) => a.Yerlesim != "Temaya göre" ? a.Yerlesim : a.Tema is "Modern" or "Yenilikçi" ? "Üst menü" : a.Tema == "Kültürel" ? "Sağ menü" : "Sol menü";
    public static string Yogunluk(GorunumTercihleri a) => a.Yogunluk != "Temaya göre" ? a.Yogunluk : a.Tema is "VIP" or "Doğal" ? "Ferah" : a.Tema is "Eskitme" or "Klasik" ? "Kompakt" : "Dengeli";
    public static Tema170 Sec(string ad) => ad switch
    {
        "VIP" => new("#F3F1EC","#FFFEFA","#1D252B","#8B652C",18),
        "Eskitme" => new("#E8DFCD","#F8F0DE","#44372E","#875D3B",2),
        "Kültürel" => new("#EAF2F1","#FFFCF5","#133E48","#A94935",7),
        "Doğal" => new("#EDF3EC","#FFFFFA","#244539","#237250",14),
        "Canlı" => new("#FFF4EE","#FFFCFA","#481F42","#B03F54",16),
        "Klasik" => new("#EFEEE9","#FFFEFA","#363C45","#475875",3),
        "Yenilikçi" => new("#F1EEFF","#FEFDFF","#2E2353","#6441BA",18),
        "Koyu" => new("#172333","#203044","#101A28","#366AC6",10),
        _ => new("#EDF3F8","#FFFFFF","#112C45","#0869A6",10)
    };
    public static Brush Firca(string value) => new SolidColorBrush((Color)ColorConverter.ConvertFromString(value));
    public static void Uygula(GorunumTercihleri tercih)
    {
        if(Application.Current is not {} app)return;
        Mevcut = tercih.Kopya();
        var renk = Sec(tercih.Tema);
        bool dark = tercih.Tema == "Koyu" || tercih.Tema == "Sistem" && Convert.ToInt32(Microsoft.Win32.Registry.GetValue(@"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize","AppsUseLightTheme",1))==0;
        if(dark) renk=Sec("Koyu");
#pragma warning disable WPF0001 // .NET 10 yerleşik Fluent teması
        app.ThemeMode = dark ? ThemeMode.Dark : ThemeMode.Light;
#pragma warning restore WPF0001
        var r=app.Resources;
        r["ErpZemin"]=Firca(renk.Zemin);
        r["ErpKart"]=Firca(renk.Yuzey);
        r["ErpMenu"]=Firca(renk.Menu);
        r["ErpVurgu"]=Firca(tercih.Vurgu=="#2563EB"?renk.Vurgu:tercih.Vurgu);
        r["ErpMetin"]=Firca(dark?"#F2F7FF":"#182E42");
        r["ErpCizgi"]=Firca(dark?"#435568":"#D4DEE6");
        r["ErpKose"]=new CornerRadius(tercih.Kose < 0 ? renk.Kose : tercih.Kose);
        r["ControlCornerRadius"]=new CornerRadius((tercih.Kose < 0 ? renk.Kose : tercih.Kose)/2);
        r["ErpFont"] = new FontFamily(tercih.YaziTipi);
        r["ErpBosluk"] = new Thickness(14, Yogunluk(tercih) == "Ferah" ? 12 : Yogunluk(tercih) == "Kompakt" ? 5 : 8,14,Yogunluk(tercih) == "Ferah" ? 12 : Yogunluk(tercih) == "Kompakt" ? 5 : 8);
        r["ErpSatir"] = Yogunluk(tercih) == "Ferah" ? 44d : Yogunluk(tercih) == "Kompakt" ? 28d : 36d;
        foreach (Window window in app.Windows) { TemaPencereServisi.Uygula(window); GorunumRenkleri.Uygula(window, tercih); }
    }
    public static Border Kart(UIElement child,string baslik)
    {
        var panel=new DockPanel();
        var text=new TextBlock{Text=baslik,FontSize=16,FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,0,0,12)};
        text.SetResourceReference(TextBlock.ForegroundProperty,"ErpMetin");
        DockPanel.SetDock(text,Dock.Top);panel.Children.Add(text);panel.Children.Add(child);
        var b=new Border{Child=panel,Padding=new Thickness(16),Margin=new Thickness(0,0,10,0),BorderThickness=new Thickness(1)};
        b.SetResourceReference(Border.BackgroundProperty,"ErpKart");
        b.SetResourceReference(Border.BorderBrushProperty,"ErpCizgi");
        b.SetResourceReference(Border.CornerRadiusProperty,"ErpKose");
        return b;
    }
    public static Border Baslik(string modul,string baslik)
    {
        var stack=new StackPanel();
        stack.Children.Add(new TextBlock{Text=modul,FontSize=12,Foreground=Brushes.White,Opacity=.83});
        stack.Children.Add(new TextBlock{Text=baslik,FontSize=23,FontWeight=FontWeights.SemiBold,Foreground=Brushes.White,Margin=new Thickness(0,3,0,0)});
        var b=new Border{Child=stack,Padding=new Thickness(20,12,20,13),Margin=new Thickness(0,0,0,14)};
        b.SetResourceReference(Border.BackgroundProperty,"ErpMenu");b.SetResourceReference(Border.CornerRadiusProperty,"ErpKose");
        return b;
    }
}
