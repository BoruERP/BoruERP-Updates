using System.Runtime.CompilerServices;
[assembly:InternalsVisibleTo("MiapaxERP.Tests.Muhasebe")]
[assembly:InternalsVisibleTo("MiapaxERP.Tests.Arayuz")]
