namespace MiapaxERP.Desktop.Muhasebe280;

public enum UcretEsasi { Brut, Net }
public enum SigortaTuru { Normal4A, EmekliSGDP }
public sealed record BordroGirdi(int Yil,int Ay,UcretEsasi Esas,decimal Ucret,int PrimGunu,
    SigortaTuru Sigorta,decimal OncekiMatrah,decimal OncekiIstisnaMatrahi,
    bool AsgariIstisna,decimal EkBrut=0,decimal VergiMatrahIndirimi=0,decimal Avans=0,
    decimal DigerNetKesinti=0,decimal IsverenIndirimPuani=0,string IndirimDayanagi="");
public sealed record BordroSonuc(decimal Brut,decimal Pek,decimal IsciSgk,decimal IsciIssizlik,
    decimal GelirMatrahi,decimal KumulatifMatrah,decimal HesaplananGelirVergisi,
    decimal GelirIstisnasi,decimal GelirVergisi,decimal DamgaIstisnasi,decimal DamgaVergisi,
    decimal Net,decimal Odenecek,decimal IsverenSgk,decimal IsverenIssizlik,decimal Tesvik,
    decimal IsverenMaliyeti,decimal IstisnaMatrahi,string ParametreSurumu);

/// <summary>Özel sektör 4/a ücret bordrosu. Her hesap dönem ve açılış matrahı ile saklanır.
/// Ek brüt tamamı prime/vergiye tabidir; yemek/yol istisnası veya kanuni teşvik uygunluğu varsayılmaz.</summary>
public static class BordroHesabi
{
 public const string Surum="TR-2026-UCRET-1";
 public const decimal AsgariBrut=33030m,PekTavan=297270m,DamgaOrani=0.00759m;
 public static decimal R(decimal n)=>decimal.Round(n,2,MidpointRounding.AwayFromZero);
 public static decimal Vergi(decimal matrah)
 {
  if(matrah<0)throw new ArgumentOutOfRangeException(nameof(matrah));
  decimal[] sinir={190000m,400000m,1500000m,5300000m,decimal.MaxValue};
  decimal[] oran={.15m,.20m,.27m,.35m,.40m};decimal once=0,vergi=0;
  for(int i=0;i<sinir.Length;i++){decimal kisim=Math.Min(matrah,sinir[i])-once;if(kisim>0)vergi+=kisim*oran[i];if(matrah<=sinir[i])break;once=sinir[i];}
  return R(vergi);
 }
 public static BordroSonuc Hesapla(BordroGirdi g)
 {
  if(g.Yil!=2026||g.Ay is <1 or >12)throw new ArgumentException("Bu hesaplama için doğrulanmış 2026 ücret parametreleri geçerlidir.");
  if(!Enum.IsDefined(g.Esas)||!Enum.IsDefined(g.Sigorta)||g.PrimGunu is <1 or >30||g.Ucret<=0||g.Ucret>100000000m||new[]{g.OncekiMatrah,g.OncekiIstisnaMatrahi,g.EkBrut,g.VergiMatrahIndirimi,g.Avans,g.DigerNetKesinti}.Any(x=>x<0))throw new ArgumentException("Ücret, gün, sigorta türü ve açılış matrahlarını kontrol edin.");
  if(g.Ay==1&&(g.OncekiMatrah!=0||g.OncekiIstisnaMatrahi!=0))throw new ArgumentException("Ocak bordrosunda yıllık açılış matrahı sıfır olmalıdır.");
  if(g.IsverenIndirimPuani is not(0 or 2 or 5)||g.Sigorta==SigortaTuru.EmekliSGDP&&g.IsverenIndirimPuani!=0||g.IsverenIndirimPuani>0&&string.IsNullOrWhiteSpace(g.IndirimDayanagi))throw new ArgumentException("Desteklenen genel prim indirimleri 0, 2 veya 5 puandır. Uygunluk dayanağı zorunludur; SGDP'ye normal prim indirimi uygulanamaz.");
  if(g.Esas==UcretEsasi.Brut)return Brut(g,g.Ucret+g.EkBrut);
  // Net ücret avans ve özel net kesintiler öncesidir; hedef nete ek brüt dahil değildir.
  var sade=g with{EkBrut=0,Avans=0,DigerNetKesinti=0};decimal lo=R(AsgariBrut*g.PrimGunu/30),hi=Math.Max(lo,g.Ucret*3);
  if(Brut(sade,lo).Net>g.Ucret+.01m)throw new ArgumentException("Net ücret prim gününe ait asgari brütün altında kalıyor.");
  while(Brut(sade,hi).Net<g.Ucret){hi*=2;if(hi>100000000m)throw new ArgumentException("Netten brüte hesap sınırı aşıldı.");}
  for(int i=0;i<64&&hi-lo>.001m;i++){decimal mid=(lo+hi)/2;if(Brut(sade,R(mid)).Net<g.Ucret)lo=mid;else hi=mid;}
  decimal aday=R(hi);var sonuc=Brut(sade,aday);var alt=Brut(sade,Math.Max(R(AsgariBrut*g.PrimGunu/30),aday-.01m));
  if(Math.Abs(alt.Net-g.Ucret)<Math.Abs(sonuc.Net-g.Ucret)){aday-=.01m;sonuc=alt;}
  if(Math.Abs(sonuc.Net-g.Ucret)>.01m)throw new ArgumentException("Net ücret kuruş hassasiyetinde çözülemedi.");
  return Brut(g,aday+g.EkBrut);
 }
 static BordroSonuc Brut(BordroGirdi g,decimal brut)
 {
  brut=R(brut);decimal taban=R(AsgariBrut*g.PrimGunu/30),tavan=R(PekTavan*g.PrimGunu/30);
  if(brut<taban)throw new ArgumentException("Brüt ücret prim gününün asgari ücretinden az olamaz.");
  decimal pek=Math.Min(brut,tavan),isci=R(pek*(g.Sigorta==SigortaTuru.Normal4A?.14m:.075m)),issiz=g.Sigorta==SigortaTuru.Normal4A?R(pek*.01m):0;
  if(g.VergiMatrahIndirimi>brut-isci-issiz)throw new ArgumentException("Matrah indirimi ücret matrahından büyük olamaz.");
  decimal matrah=R(brut-isci-issiz-g.VergiMatrahIndirimi),hesap=Vergi(g.OncekiMatrah+matrah)-Vergi(g.OncekiMatrah);
  decimal istMat=g.AsgariIstisna?R(AsgariBrut*.85m):0;
  decimal ist=g.AsgariIstisna?Math.Min(hesap,Vergi(g.OncekiIstisnaMatrahi+istMat)-Vergi(g.OncekiIstisnaMatrahi)):0;
  decimal damga=R(brut*DamgaOrani),damgaIst=g.AsgariIstisna?Math.Min(damga,R(AsgariBrut*DamgaOrani)):0;
  decimal gv=hesap-ist,dv=damga-damgaIst,net=brut-isci-issiz-gv-dv;
  if(g.Avans+g.DigerNetKesinti>net)throw new ArgumentException("Avans ve net kesintiler net ücreti aşamaz.");
  decimal isv=R(pek*(g.Sigorta==SigortaTuru.Normal4A?.2175m:.2475m)),isvIss=g.Sigorta==SigortaTuru.Normal4A?R(pek*.02m):0,tesvik=R(pek*g.IsverenIndirimPuani/100);
  return new(brut,pek,isci,issiz,matrah,g.OncekiMatrah+matrah,hesap,ist,gv,damgaIst,dv,net,net-g.Avans-g.DigerNetKesinti,isv,isvIss,tesvik,brut+isv+isvIss-tesvik,istMat,Surum);
 }
}
