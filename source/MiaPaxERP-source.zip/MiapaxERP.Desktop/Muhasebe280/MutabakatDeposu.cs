using System.Data;
using System.Security.Cryptography;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop.Muhasebe280;
public sealed class MutabakatDeposu
{
 readonly string cs;readonly int user;readonly Action<SqlConnection,SqlTransaction?,string> check;
 public MutabakatDeposu(string connection,int userId){cs=connection;user=userId;check=new ErpModulServisi(cs,user).Yetki;}
 internal MutabakatDeposu(string connection,int userId,Action<SqlConnection,SqlTransaction?,string> permission){cs=connection;user=userId;check=permission;}
 SqlConnection Ac(){var c=new SqlConnection(cs);c.Open();return c;}
 static SqlCommand Q(SqlConnection c,SqlTransaction? t,string sql,params(string,object?)[] p)=>ErpModulServisi.Komut(c,t,sql,p);
 public DataTable Ozet(DateTime start,DateTime end)
 {
if(HttpsOturumu.Uzak(cs)){return HttpsOturumu.Cagir<DataTable>(cs,"MutabakatDeposu.Ozet","",new object?[]{start,end});}

  if(end.Date<start.Date||end.Date>start.Date.AddYears(1))throw new ArgumentException("En fazla bir yıllık dönem seçin.");using var c=Ac();check(c,null,"FINANCE.RECONCILE.VIEW");using var q=Q(c,null,"""
  WITH Belgeler AS(
   SELECT b.CariId,b.BelgeNo,b.BelgeTipi,b.BelgeTarihi,b.AraToplam,b.KdvTutari,b.GenelToplam,N'Manuel' Kaynak
   FROM dbo.TicariBelgeler b WHERE b.Durum=N'Kaydedildi' AND NOT EXISTS(SELECT 1 FROM dbo.CariHareketleri r WHERE r.TersKayitId=b.CariHareketId)
   UNION ALL
   SELECT i.CariId,i.BelgeNo,i.BelgeTipi,i.BelgeTarihi,i.Matrah,i.Kdv,i.GenelToplam,N'E-Belge'
   FROM dbo.BERP270_EBelgeIslem i WHERE i.Ortam='Canli' AND i.Islem='Muhasebe' AND i.TersId IS NULL AND NOT EXISTS(SELECT 1 FROM dbo.TicariBelgeler b WHERE b.CariHareketId=i.CariHareketId)
  )SELECT c.CariKodu,c.Unvan,c.VergiNo,b.BelgeTipi,COUNT_BIG(*) BelgeAdedi,SUM(b.AraToplam) KdvHaricTry,SUM(b.KdvTutari) KdvTry,SUM(b.GenelToplam) KdvDahilTry,b.Kaynak
  FROM Belgeler b JOIN dbo.CariKartlari c ON c.Id=b.CariId WHERE b.BelgeTarihi>=@s AND b.BelgeTarihi<DATEADD(day,1,@e)
  GROUP BY c.CariKodu,c.Unvan,c.VergiNo,b.BelgeTipi,b.Kaynak ORDER BY c.Unvan,b.BelgeTipi,b.Kaynak
  """,("@s",start.Date),("@e",end.Date));using var r=q.ExecuteReader();var dt=new DataTable();dt.Load(r);return dt;
 }
 public DataTable Arsiv(){
if(HttpsOturumu.Uzak(cs)){return HttpsOturumu.Cagir<DataTable>(cs,"MutabakatDeposu.Arsiv","",new object?[]{});}
using var c=Ac();check(c,null,"FINANCE.RECONCILE.VIEW");using var q=Q(c,null,"SELECT Id,Yil,Ay,Tur,Aciklama,Ozet,Zaman FROM dbo.MPX280_BabsArsiv ORDER BY Yil DESC,Ay DESC,Tur,Id DESC");using var r=q.ExecuteReader();var dt=new DataTable();dt.Load(r);return dt;}
 public long Arsivle(int year,int month,string type,string reason,byte[] pdf)
 {
if(HttpsOturumu.Uzak(cs)){return HttpsOturumu.Cagir<long>(cs,"MutabakatDeposu.Arsivle","",new object?[]{year,month,type,reason,pdf});}

  if(year<2000||year>2024||month is <1 or >12||year==2024&&month>=9)throw new ArgumentException("BA/BS bildirim yükümlülüğü Eylül 2024'ten itibaren kaldırıldı. Yalnız önceki dönemler arşivlenebilir.");
  if(type is not("BA" or "BS")||string.IsNullOrWhiteSpace(reason)||reason.Length<5||reason.Length>400||pdf.Length is <8 or >5_000_000||!pdf.AsSpan(0,5).SequenceEqual("%PDF-"u8))throw new ArgumentException("BA/BS türü, açıklama ve en fazla 5 MB PDF gerekli.");
  string hash=Convert.ToHexString(SHA256.HashData(pdf));using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"FINANCE.RECONCILE.ARCHIVE");
  using(var q=Q(c,t,"SELECT Id FROM dbo.MPX280_BabsArsiv WITH(UPDLOCK,HOLDLOCK) WHERE Yil=@y AND Ay=@a AND Tur=@t AND Ozet=@h",("@y",year),("@a",month),("@t",type),("@h",hash))){if(q.ExecuteScalar() is{} id){t.Commit();return Convert.ToInt64(id);}}
  using var save=Q(c,t,"INSERT dbo.MPX280_BabsArsiv(Yil,Ay,Tur,Aciklama,Dosya,Ozet,Kullanici)OUTPUT INSERTED.Id VALUES(@y,@a,@t,@g,@f,@h,@u)",("@y",year),("@a",month),("@t",type),("@g",reason),("@f",pdf),("@h",hash),("@u",user));long result=Convert.ToInt64(save.ExecuteScalar());t.Commit();return result;
 }
 public byte[] Indir(long id)
 {
if(HttpsOturumu.Uzak(cs)){return HttpsOturumu.Cagir<byte[]>(cs,"MutabakatDeposu.Indir","",new object?[]{id});}

  using var c=Ac();check(c,null,"FINANCE.RECONCILE.DOWNLOAD");using var q=Q(c,null,"SELECT Dosya,Ozet FROM dbo.MPX280_BabsArsiv WHERE Id=@id",("@id",id));using var r=q.ExecuteReader();if(!r.Read())throw new ArgumentException("Arşiv kaydı bulunamadı.");var bytes=(byte[])r[0];if(Convert.ToHexString(SHA256.HashData(bytes))!=r.GetString(1))throw new ArgumentException("Arşiv dosyası özeti uyuşmuyor.");return bytes;
 }
}
