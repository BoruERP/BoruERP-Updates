using System.Data;
using System.Globalization;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
namespace MiapaxERP.Desktop.Muhasebe280;
public sealed class BordroPaneli:UserControl
{
 readonly BordroDeposu db;readonly DataGrid grid=new(){IsReadOnly=true,CanUserAddRows=false,AutoGenerateColumns=true,SelectionMode=DataGridSelectionMode.Single};
 readonly TextBlock status=new(){TextWrapping=TextWrapping.Wrap,Margin=new Thickness(8)};
 public BordroPaneli(string cs,int user):this(new BordroDeposu(cs,user)){}
 internal BordroPaneli(BordroDeposu store)
 {
  db=store;var root=new DockPanel{Margin=new Thickness(12)};Content=root;var bar=new WrapPanel();DockPanel.SetDock(bar,Dock.Top);root.Children.Add(bar);
  void B(string text,Action a)=>ErpModulPenceresi.B(bar,text,a);
  B("Bordro tablolarını kur / güncelle",()=>{db.Kur();Load();});B("Yenile",Load);B("Net / brüt bordro hazırla",Yeni);B("Tahakkuku onayla",()=>Islem("Onay"));B("Kasa / bankadan öde",()=>Islem("Ödeme"));B("Ücret ödemesini tersle",()=>Islem("Ödeme ters kaydı"));B("Ödenmemiş bordroyu iptal et",()=>Islem("İptal"));B("Bordro yazdır / PDF",Yazdir);
  DockPanel.SetDock(status,Dock.Bottom);root.Children.Add(status);root.Children.Add(grid);grid.AutoGeneratingColumn+=(_,e)=>{if(e.PropertyName is "Girdi" or "Sonuc" or "Surum" or "Id")e.Cancel=true;};
  status.Text="2026 özel sektör 4/a / SGDP. Net ücret avans öncesidir. Önceki kümülatif ve istisna matrahını bordro geçmişinizden girin. PDF için yazdırmada PDF yazıcısını seçin.";
 }
 void Load(){grid.ItemsSource=db.Liste().DefaultView;status.Text="Bordro listesi yenilendi.";}
 Window Pencere(string title,StackPanel panel)=>new(){Title="Miapax ERP · "+title,Owner=Window.GetWindow(this),Width=710,Height=760,WindowStartupLocation=WindowStartupLocation.CenterOwner,Content=new ScrollViewer{Content=panel}};
 static void Etiket(Panel p,string label)=>p.Children.Add(new TextBlock{Text=label,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,10,0,4)});
 static TextBox T(Panel p,string label,string value=""){Etiket(p,label);var b=new TextBox{Text=value,Padding=new Thickness(6)};p.Children.Add(b);return b;}
 static ComboBox C(Panel p,string label,DataTable dt){Etiket(p,label);var b=new ComboBox{ItemsSource=dt.DefaultView,DisplayMemberPath="Ad",SelectedValuePath="Id",Padding=new Thickness(6)};p.Children.Add(b);return b;}
 static decimal N(TextBox t){if(!decimal.TryParse(t.Text,NumberStyles.Number,CultureInfo.GetCultureInfo("tr-TR"),out var n))throw new ArgumentException("Sayısal alanı kontrol edin: "+t.Text);return n;}
 static int I(TextBox t){var n=N(t);if(n!=decimal.Truncate(n))throw new ArgumentException("Tam sayı girin.");return checked((int)n);}
 void Yeni()
 {
  var p=new StackPanel{Margin=new Thickness(20)};var w=Pencere("Ücret bordrosu hazırlama",p);
  var person=C(p,"Personel",db.Secimler(true));var cari=C(p,"Personelin ücret cari kartı",db.Secimler(false));
  var yil=T(p,"Yıl (doğrulanmış parametre: 2026)","2026");var ay=T(p,"Ay",DateTime.Today.Month.ToString());
  Etiket(p,"Ücret esası");var esas=new ComboBox{ItemsSource=Enum.GetValues<UcretEsasi>()};p.Children.Add(esas);
  var ucret=T(p,"Bu ayın ücret tutarı (net ise avans öncesi; brüt ise bu aya ait hak edilen ücret)");var gun=T(p,"SGK prim günü (1–30)","30");
  Etiket(p,"Sigorta statüsü");var sig=new ComboBox{ItemsSource=Enum.GetValues<SigortaTuru>()};p.Children.Add(sig);
  var once=T(p,"Önceki kümülatif gelir vergisi matrahı (Ocak: 0)");var onceIst=T(p,"Önceki kümülatif asgari istisna matrahı (Ocak: 0)");
  var ist=new CheckBox{Content="Asgari ücret istisna hakkını bu işveren için doğruladım",Margin=new Thickness(0,12,0,4)};p.Children.Add(ist);
  var ek=T(p,"Tamamı prime/vergiye tabi ek brüt ücret","0");var ind=T(p,"Belgeli gelir vergisi matrah indirimi","0");var avans=T(p,"Önceden ödenmiş / mahsup edilecek avans","0");var kes=T(p,"Diğer belgeli net kesintiler","0");
  var tes=T(p,"Doğrulanmış işveren prim indirimi (puan; teşviksiz: 0)","0");var day=T(p,"İndirim / kesinti dayanağı ve matrah geçmişi açıklaması");var onay=new CheckBox{Content="Gün, açılış matrahları, istisna ve personel cari eşlemesini kontrol ettim",Margin=new Thickness(0,12,0,4)};p.Children.Add(onay);
  var result=new TextBlock{TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,12,0,12)};p.Children.Add(result);var button=new Button{Content="Hesapla ve önizle",Padding=new Thickness(12)};p.Children.Add(button);var save=new Button{Content="Önizlediğim bordroyu taslak kaydet",Padding=new Thickness(12),IsEnabled=false};p.Children.Add(save);BordroGirdi? snapshot=null;Guid key=Guid.NewGuid();int pid=0,cid=0;string reason="";
  button.Click+=(_,_)=>{try{if(person.SelectedValue is null||cari.SelectedValue is null||esas.SelectedItem is null||sig.SelectedItem is null||onay.IsChecked!=true)throw new ArgumentException("Personel, cari, ücret esası ve sigorta seçimini tamamlayıp kontrolleri onaylayın.");snapshot=new(I(yil),I(ay),(UcretEsasi)esas.SelectedItem,N(ucret),I(gun),(SigortaTuru)sig.SelectedItem,N(once),N(onceIst),ist.IsChecked==true,N(ek),N(ind),N(avans),N(kes),N(tes),day.Text.Trim());var r=BordroHesabi.Hesapla(snapshot);pid=(int)person.SelectedValue;cid=(int)cari.SelectedValue;reason=day.Text.Trim();result.Text=$"Brüt: {r.Brut:N2} TRY\nSGK işçi: {r.IsciSgk:N2} / işsizlik: {r.IsciIssizlik:N2}\nGV matrahı: {r.GelirMatrahi:N2} / kümülatif: {r.KumulatifMatrah:N2}\nGelir vergisi: {r.GelirVergisi:N2} (istisna {r.GelirIstisnasi:N2})\nDamga: {r.DamgaVergisi:N2}\nNet: {r.Net:N2} / Ödenecek: {r.Odenecek:N2}\nİşveren maliyeti: {r.IsverenMaliyeti:N2} TRY\n{r.ParametreSurumu}\nKaydetme önizlenen değerleri kullanır. Değişiklik yaptıysanız yeniden hesaplayın.";save.IsEnabled=true;}catch(Exception e){save.IsEnabled=false;snapshot=null;result.Text=e.Message;}};
  save.Click+=(_,_)=>{try{if(snapshot is null)return;db.Hazirla(key,pid,cid,snapshot,reason);w.DialogResult=true;Load();}catch(Exception e){result.Text=e.Message;}};w.ShowDialog();
 }
 void Islem(string action)
 {
  if(grid.SelectedItem is not DataRowView row)throw new ArgumentException("Bordro seçin.");
  var p=new StackPanel{Margin=new Thickness(20)};var w=Pencere(action,p);Etiket(p,$"{row["AdSoyad"]} / {row["Yil"]}-{row["Ay"]} / ödenecek {row["Odenecek"]} TRY");ComboBox? hesap=action=="Ödeme"?C(p,"TRY kasa / banka hesabı",db.Hesaplar()):null;Etiket(p,"İşlem tarihi");var date=new DatePicker{SelectedDate=DateTime.Today};p.Children.Add(date);var input=JsonSerializer.Deserialize<BordroGirdi>((string)row["Girdi"])!;ComboBox? avans=action=="Onay"&&input.Avans>0?C(p,"Önceden ödenmiş avansın cari hareketi (tam tutar eşleşmeli)",db.Avanslar((long)row["Id"])):null;var why=T(p,"Kontrol / işlem açıklaması");var error=new TextBlock{TextWrapping=TextWrapping.Wrap};p.Children.Add(error);var ok=new Button{Content=action+" işlemini uygula",Padding=new Thickness(12),Margin=new Thickness(0,16,0,0)};p.Children.Add(ok);
  ok.Click+=(_,_)=>{try{long id=(long)row["Id"];byte[] ver=(byte[])row["Surum"];if(action=="Onay")db.Onayla(id,ver,why.Text,avans?.SelectedValue is{} a?Convert.ToInt64(a):null);else if(action=="İptal")db.Iptal(id,ver,(string)row["Durum"],why.Text,date.SelectedDate??throw new ArgumentException("Tarih seçin."));else if(action=="Ödeme ters kaydı")db.OdemeTersle(id,ver,date.SelectedDate??throw new ArgumentException("Tarih seçin."),why.Text);else db.Ode(id,ver,(int)(hesap?.SelectedValue??throw new ArgumentException("Hesap seçin.")),date.SelectedDate??throw new ArgumentException("Tarih seçin."),why.Text);w.DialogResult=true;Load();}catch(Exception e){error.Text=e.Message;}};w.ShowDialog();
 }
 void Yazdir()
 {
  if(grid.SelectedItem is not DataRowView old)throw new ArgumentException("Bordro seçin.");var dt=db.Liste();var row=dt.AsEnumerable().SingleOrDefault(r=>(long)r["Id"]==(long)old["Id"])??throw new ArgumentException("Bordro bulunamadı.");
  var s=JsonSerializer.Deserialize<BordroSonuc>((string)row["Sonuc"])!;var g=JsonSerializer.Deserialize<BordroGirdi>((string)row["Girdi"])!;
  var doc=new FlowDocument{FontFamily=new System.Windows.Media.FontFamily("Segoe UI"),FontSize=12,PagePadding=new Thickness(45),ColumnWidth=double.PositiveInfinity};
  void Line(string text)=>doc.Blocks.Add(new Paragraph(new Run(text)));
  Line("Miapax ERP · Ücret Hesap Pusulası");Line($"{row["Sicil"]} · {row["AdSoyad"]} / {g.Yil}-{g.Ay:00} / {row["Durum"]}");Line($"Prim günü {g.PrimGunu} / {g.Sigorta} / {g.Esas}");
  foreach(var item in new[]{("Brüt ücret",s.Brut),("Prime esas kazanç",s.Pek),("SGK işçi",s.IsciSgk),("İşsizlik işçi",s.IsciIssizlik),("Gelir vergisi matrahı",s.GelirMatrahi),("Kümülatif matrah",s.KumulatifMatrah),("Gelir vergisi istisnası",s.GelirIstisnasi),("Gelir vergisi",s.GelirVergisi),("Damga vergisi",s.DamgaVergisi),("Net ücret",s.Net),("Avans mahsubu",g.Avans),("Diğer kesintiler",g.DigerNetKesinti),("Ödenecek",s.Odenecek),("İşveren maliyeti",s.IsverenMaliyeti)})Line(item.Item1+": "+item.Item2.ToString("N2",CultureInfo.GetCultureInfo("tr-TR"))+" TRY");
  Line("Dayanak: "+row["Gerekce"]);Line(s.ParametreSurumu+" · Hazırlayan / kontrol eden / çalışan imzası: __________________");var print=new PrintDialog();if(print.ShowDialog()==true){doc.PageWidth=print.PrintableAreaWidth;doc.PageHeight=print.PrintableAreaHeight;print.PrintDocument(((IDocumentPaginatorSource)doc).DocumentPaginator,"Miapax ERP Bordro");}
 }
}
