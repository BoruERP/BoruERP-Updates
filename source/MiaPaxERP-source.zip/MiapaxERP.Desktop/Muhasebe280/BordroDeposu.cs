using System.Data;
using System.IO;
using System.Text.Json;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop.Muhasebe280;

public sealed class BordroDeposu
{
 readonly string cs;readonly int user;readonly Action<SqlConnection,SqlTransaction?,string> check;
 public BordroDeposu(string connection,int userId){cs=connection;user=userId;check=new ErpModulServisi(cs,user).Yetki;}
 internal BordroDeposu(string connection,int userId,Action<SqlConnection,SqlTransaction?,string> permission){cs=connection;user=userId;check=permission;}
 SqlConnection Ac(){var c=new SqlConnection(cs);c.Open();return c;}
 static SqlCommand Q(SqlConnection c,SqlTransaction? t,string sql,params(string,object?)[] p)=>ErpModulServisi.Komut(c,t,sql,p);
 static void Gerekce(string reason){if(string.IsNullOrWhiteSpace(reason)||reason.Trim().Length<5||reason.Length>400)throw new ArgumentException("5–400 karakter işlem açıklaması gerekli.");}
 public void Kur(){
if(HttpsOturumu.Uzak(cs)){HttpsOturumu.Cagir<object?>(cs,"BordroDeposu.Kur","",new object?[]{});return;}
using var c=Ac();check(c,null,"MODULES.INSTALL");using(var exists=Q(c,null,"SELECT OBJECT_ID('dbo.BERP_Personel','U')")){if(exists.ExecuteScalar() is DBNull){using var hr=Q(c,null,File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"Moduller160.sql")));hr.ExecuteNonQuery();}}using var q=Q(c,null,File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"Muhasebe280.sql")));q.ExecuteNonQuery();}
 public DataTable Liste(){
if(HttpsOturumu.Uzak(cs)){return HttpsOturumu.Cagir<DataTable>(cs,"BordroDeposu.Liste","",new object?[]{});}
using var c=Ac();check(c,null,"HR.PAYROLL.VIEW");using var q=Q(c,null,"SELECT TOP(500) b.Id,p.Sicil,p.AdSoyad,b.Yil,b.Ay,b.Brut,b.Net,b.Odenecek,b.Durum,b.Girdi,b.Sonuc,b.Surum,b.Gerekce FROM dbo.MPX280_Bordro b JOIN dbo.BERP_Personel p ON p.Id=b.PersonelId ORDER BY b.Yil DESC,b.Ay DESC,p.AdSoyad");using var r=q.ExecuteReader();var dt=new DataTable();dt.Load(r);return dt;}
 public DataTable Secimler(bool personel){
if(HttpsOturumu.Uzak(cs)){return HttpsOturumu.Cagir<DataTable>(cs,"BordroDeposu.Secimler","",new object?[]{personel});}
using var c=Ac();check(c,null,"HR.PAYROLL.VIEW");using var q=Q(c,null,personel?"SELECT Id,Sicil+N' / '+AdSoyad Ad FROM dbo.BERP_Personel ORDER BY AdSoyad":"SELECT Id,CariKodu+N' / '+Unvan Ad FROM dbo.CariKartlari WHERE Aktif=1 ORDER BY Unvan");using var r=q.ExecuteReader();var dt=new DataTable();dt.Load(r);return dt;}
 public DataTable Hesaplar(){
if(HttpsOturumu.Uzak(cs)){return HttpsOturumu.Cagir<DataTable>(cs,"BordroDeposu.Hesaplar","",new object?[]{});}
using var c=Ac();check(c,null,"HR.PAYROLL.PAY");check(c,null,"FINANCE.VIEW");using var q=Q(c,null,"SELECT Id,HesapAdi Ad FROM dbo.FinansHesaplari WHERE Aktif=1 AND ParaBirimi='TRY' ORDER BY HesapAdi");using var r=q.ExecuteReader();var dt=new DataTable();dt.Load(r);return dt;}
 public long Hazirla(Guid key,int person,int cari,BordroGirdi input,string reason)
 {
if(HttpsOturumu.Uzak(cs)){return HttpsOturumu.Cagir<long>(cs,"BordroDeposu.Hazirla","",new object?[]{key,person,cari,input,reason});}

  Gerekce(reason);var result=BordroHesabi.Hesapla(input);using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"HR.PAYROLL.EDIT");check(c,t,"HR.PAYROLL.VIEW");string g=JsonSerializer.Serialize(input),s=JsonSerializer.Serialize(result);
  using(var old=Q(c,t,"SELECT Id,PersonelId,CariId,Girdi,Gerekce FROM dbo.MPX280_Bordro WITH(UPDLOCK,HOLDLOCK) WHERE Anahtar=@k",("@k",key))){using var r=old.ExecuteReader();if(r.Read()){if(r.GetInt32(1)!=person||r.GetInt32(2)!=cari||r.GetString(3)!=g||r.GetString(4)!=reason)throw new ArgumentException("Aynı işlem anahtarı farklı bordro için kullanılamaz.");return r.GetInt64(0);}}
  var start=new DateTime(input.Yil,input.Ay,1);var end=start.AddMonths(1).AddDays(-1);
  using(var q=Q(c,t,"SELECT IseGiris,IstenCikis FROM dbo.BERP_Personel WITH(UPDLOCK,HOLDLOCK) WHERE Id=@p AND IseGiris<=@e AND (IstenCikis IS NULL OR IstenCikis>=@s)",("@p",person),("@s",start),("@e",end))){using var r=q.ExecuteReader();if(!r.Read())throw new ArgumentException("Personel çalışma dönemiyle bordro dönemi uyuşmuyor.");DateTime joined=r.GetDateTime(0),left=r.IsDBNull(1)?end:r.GetDateTime(1);int limit=joined<=start&&left>=end?30:Math.Min(30,((left<end?left:end)-(joined>start?joined:start)).Days+1);if(input.PrimGunu>limit)throw new ArgumentException("Prim günü işe giriş/çıkış tarihlerine göre mümkün olan gün sayısını aşıyor.");}
  using(var q=Q(c,t,"SELECT COUNT(*) FROM dbo.CariKartlari WITH(UPDLOCK,HOLDLOCK) WHERE Id=@c AND Aktif=1",("@c",cari)))if(Convert.ToInt32(q.ExecuteScalar())!=1)throw new ArgumentException("Aktif personel cari kartı seçin.");
  OncekiKontrol(c,t,person,input);
  using(var q=Q(c,t,"SELECT COUNT(*) FROM dbo.MPX280_Bordro WITH(UPDLOCK,HOLDLOCK) WHERE PersonelId=@p AND Yil=@y AND Ay=@a AND Durum<>N'İptal'",("@p",person),("@y",input.Yil),("@a",input.Ay)))if(Convert.ToInt32(q.ExecuteScalar())>0)throw new ArgumentException("Bu personel ve dönem için bordro zaten mevcut. Düzeltme gerekiyorsa önce mevcut kaydı inceleyin.");
  using var save=Q(c,t,"INSERT dbo.MPX280_Bordro(Anahtar,PersonelId,CariId,Yil,Ay,Girdi,Sonuc,Brut,Net,Odenecek,Gerekce,Olusturan) OUTPUT INSERTED.Id VALUES(@k,@p,@c,@y,@a,@g,@s,@b,@n,@o,@r,@u)",("@k",key),("@p",person),("@c",cari),("@y",input.Yil),("@a",input.Ay),("@g",g),("@s",s),("@b",result.Brut),("@n",result.Net),("@o",result.Odenecek),("@r",reason),("@u",user));long id=Convert.ToInt64(save.ExecuteScalar());Iz(c,t,id,"Hazırlandı",reason);t.Commit();return id;
 }
 static void OncekiKontrol(SqlConnection c,SqlTransaction t,int person,BordroGirdi input,bool onay=false)
 {
  using var q=Q(c,t,"SELECT TOP(1) Ay,Girdi,Sonuc,Durum FROM dbo.MPX280_Bordro WITH(UPDLOCK,HOLDLOCK) WHERE PersonelId=@p AND Yil=@y AND Durum<>N'İptal' AND Ay<>@a ORDER BY Ay DESC",("@p",person),("@y",input.Yil),("@a",input.Ay));using var r=q.ExecuteReader();if(!r.Read())return;
  if(onay&&r.GetString(3)=="Taslak")throw new ArgumentException("Önce önceki dönemin bordrosunu onaylayın.");
  int month=r.GetInt32(0);if(month>input.Ay)throw new ArgumentException("Daha ileri döneme ait bordro var; geçmiş bordro değişikliği önce zincir halinde ele alınmalı.");
  if(month!=input.Ay-1)throw new ArgumentException("Bordro dönemleri arasında boşluk var. Önce eksik geçmişi tamamlayın.");
  var prior=JsonSerializer.Deserialize<BordroGirdi>(r.GetString(1))!;var result=JsonSerializer.Deserialize<BordroSonuc>(r.GetString(2))!;
  if(input.OncekiMatrah!=result.KumulatifMatrah||input.OncekiIstisnaMatrahi!=prior.OncekiIstisnaMatrahi+result.IstisnaMatrahi)throw new ArgumentException("Açılış matrahları önceki bordroyla uyuşmuyor.");
 }
 void Iz(SqlConnection c,SqlTransaction t,long id,string action,string reason){using var q=Q(c,t,"INSERT dbo.MPX280_BordroOlay(BordroId,Islem,Gerekce,Kullanici)VALUES(@id,@a,@r,@u)",("@id",id),("@a",action),("@r",reason),("@u",user));q.ExecuteNonQuery();}
 (int Person,int Cari,BordroGirdi G,BordroSonuc S,long? Hareket) Oku(SqlConnection c,SqlTransaction t,long id,byte[] version,string status)
 {
  using var q=Q(c,t,"SELECT PersonelId,CariId,Girdi,Sonuc,CariHareketId FROM dbo.MPX280_Bordro WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Surum=@v AND Durum=@s",("@id",id),("@v",version),("@s",status));using var r=q.ExecuteReader();if(!r.Read())throw new ArgumentException("Bordro durumu değişti; listeyi yenileyin.");var g=JsonSerializer.Deserialize<BordroGirdi>(r.GetString(2))!;var s=JsonSerializer.Deserialize<BordroSonuc>(r.GetString(3))!;if(BordroHesabi.Hesapla(g)!=s)throw new ArgumentException("Bordro hesap özeti doğrulanamadı.");return(r.GetInt32(0),r.GetInt32(1),g,s,r.IsDBNull(4)?null:r.GetInt64(4));
 }
 public DataTable Avanslar(long bordro)
 {
if(HttpsOturumu.Uzak(cs)){return HttpsOturumu.Cagir<DataTable>(cs,"BordroDeposu.Avanslar","",new object?[]{bordro});}

  using var c=Ac();check(c,null,"HR.PAYROLL.APPROVE");check(c,null,"CUSTOMER.VIEW");using var q=Q(c,null,"SELECT h.Id,CONVERT(nvarchar(10),h.Tarih,104)+N' / '+CONVERT(nvarchar(40),h.Tutar)+N' TRY / '+h.Aciklama Ad FROM dbo.CariHareketleri h JOIN dbo.MPX280_Bordro b ON b.CariId=h.CariId WHERE b.Id=@id AND h.HareketTipi=N'Borç' AND h.TersKayitId IS NULL AND NOT EXISTS(SELECT 1 FROM dbo.CariHareketleri r WHERE r.TersKayitId=h.Id) AND NOT EXISTS(SELECT 1 FROM dbo.MPX280_Bordro x WHERE x.AvansCariHareketId=h.Id AND x.Durum<>N'İptal') ORDER BY h.Tarih DESC,h.Id DESC",("@id",bordro));using var r=q.ExecuteReader();var dt=new DataTable();dt.Load(r);return dt;
 }
 public void Onayla(long id,byte[] version,string reason,long? avansHareketi=null)
 {
if(HttpsOturumu.Uzak(cs)){HttpsOturumu.Cagir<object?>(cs,"BordroDeposu.Onayla","",new object?[]{id,version,reason,avansHareketi});return;}

  Gerekce(reason);using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"HR.PAYROLL.APPROVE");check(c,t,"CUSTOMER.EDIT");var d=Oku(c,t,id,version,"Taslak");OncekiKontrol(c,t,d.Person,d.G,true);
  DateTime accrual=new DateTime(d.G.Yil,d.G.Ay,1).AddMonths(1).AddDays(-1);
  if(d.G.Avans>0)
  {
   if(avansHareketi is null)throw new ArgumentException("Avansın daha önce ödenmiş cari borç hareketini seçin. Birden fazla veya kısmi avans için önce cari mahsup planını mali olarak düzenleyin.");
   using var advance=Q(c,t,"SELECT COUNT(*) FROM dbo.CariHareketleri h WITH(UPDLOCK,HOLDLOCK) WHERE h.Id=@id AND h.CariId=@c AND h.HareketTipi=N'Borç' AND h.Tutar=@m AND h.Tarih<=@d AND h.TersKayitId IS NULL AND NOT EXISTS(SELECT 1 FROM dbo.CariHareketleri r WHERE r.TersKayitId=h.Id) AND NOT EXISTS(SELECT 1 FROM dbo.MPX280_Bordro b WHERE b.AvansCariHareketId=h.Id AND b.Durum<>N'İptal')",("@id",avansHareketi),("@c",d.Cari),("@m",d.G.Avans),("@d",accrual));if(Convert.ToInt32(advance.ExecuteScalar())!=1)throw new ArgumentException("Avansın cari, tutar, tarih veya mahsup durumu bordroyla uyuşmuyor.");
  }
  else if(avansHareketi is not null)throw new ArgumentException("Bordroda avans mahsubu yok; avans hareketi seçmeyin.");
  using var q=Q(c,t,"INSERT dbo.CariHareketleri(CariId,Tarih,HareketTipi,Tutar,Aciklama,Kaynak,YapanKullaniciId) OUTPUT INSERTED.Id VALUES(@c,@d,N'Alacak',@m,@a,N'Miapax Bordro',@u)",("@c",d.Cari),("@d",accrual),("@m",d.S.Net-d.G.DigerNetKesinti),("@a",$"Bordro {d.G.Yil}/{d.G.Ay:00} / {id}"),("@u",user));long h=Convert.ToInt64(q.ExecuteScalar());using var update=Q(c,t,"UPDATE dbo.MPX280_Bordro SET Durum=N'Onaylandı',CariHareketId=@h,Onaylayan=@u,AvansCariHareketId=@av WHERE Id=@id",("@h",h),("@u",user),("@id",id),("@av",avansHareketi));update.ExecuteNonQuery();Iz(c,t,id,"Onaylandı",reason);t.Commit();
 }
 public void Ode(long id,byte[] version,int hesap,DateTime tarih,string reason)
 {
if(HttpsOturumu.Uzak(cs)){HttpsOturumu.Cagir<object?>(cs,"BordroDeposu.Ode","",new object?[]{id,version,hesap,tarih,reason});return;}

  Gerekce(reason);using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"HR.PAYROLL.PAY");check(c,t,"FINANCE.PAYMENT");check(c,t,"CUSTOMER.EDIT");var d=Oku(c,t,id,version,"Onaylandı");
  using(var av=Q(c,t,"SELECT COUNT(*) FROM dbo.MPX280_Bordro b JOIN dbo.CariHareketleri r ON r.TersKayitId=b.AvansCariHareketId WHERE b.Id=@id",("@id",id)))if(Convert.ToInt32(av.ExecuteScalar())>0)throw new ArgumentException("Bağlı avans sonradan terslenmiş; bordro mahsubunu düzeltmeden ödeme yapılamaz.");
  if(tarih.Date<new DateTime(d.G.Yil,d.G.Ay,1)||d.S.Odenecek<=0)throw new ArgumentException("Ödeme tarihi veya ödenecek tutar geçersiz.");
  using(var q=Q(c,t,"SELECT COUNT(*) FROM dbo.FinansHesaplari WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Aktif=1 AND ParaBirimi='TRY'",("@id",hesap)))if(Convert.ToInt32(q.ExecuteScalar())!=1)throw new ArgumentException("Aktif TRY kasa/banka hesabı seçin.");
  using var cari=Q(c,t,"INSERT dbo.CariHareketleri(CariId,Tarih,HareketTipi,Tutar,Aciklama,Kaynak,YapanKullaniciId)OUTPUT INSERTED.Id VALUES(@c,@d,N'Borç',@m,@a,N'Miapax Bordro Ödeme',@u)",("@c",d.Cari),("@d",tarih.Date),("@m",d.S.Odenecek),("@a",reason),("@u",user));long h=Convert.ToInt64(cari.ExecuteScalar());
  using var finans=Q(c,t,"INSERT dbo.FinansHareketleri(HesapId,CariId,CariHareketId,Tarih,HareketTipi,Tutar,Aciklama,YapanKullaniciId)OUTPUT INSERTED.Id VALUES(@h,@c,@ch,@d,N'Çıkış',@m,@a,@u)",("@h",hesap),("@c",d.Cari),("@ch",h),("@d",tarih.Date),("@m",d.S.Odenecek),("@a",reason),("@u",user));long f=Convert.ToInt64(finans.ExecuteScalar());
  using var update=Q(c,t,"UPDATE dbo.MPX280_Bordro SET Durum=N'Ödendi',FinansHareketId=@f WHERE Id=@id",("@f",f),("@id",id));update.ExecuteNonQuery();Iz(c,t,id,"Ödendi",reason);t.Commit();
 }
 public void OdemeTersle(long id,byte[] version,DateTime date,string reason)
 {
if(HttpsOturumu.Uzak(cs)){HttpsOturumu.Cagir<object?>(cs,"BordroDeposu.OdemeTersle","",new object?[]{id,version,date,reason});return;}

  Gerekce(reason);using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"HR.PAYROLL.REVERSE");check(c,t,"FINANCE.PAYMENT");check(c,t,"CUSTOMER.EDIT");var d=Oku(c,t,id,version,"Ödendi");long finance,cari;DateTime oldDate;
  using(var q=Q(c,t,"SELECT f.Id,f.CariHareketId,f.Tarih FROM dbo.MPX280_Bordro b WITH(UPDLOCK,HOLDLOCK) JOIN dbo.FinansHareketleri f WITH(UPDLOCK,HOLDLOCK) ON f.Id=b.FinansHareketId WHERE b.Id=@id AND f.Tutar=@m AND f.CariId=@c AND NOT EXISTS(SELECT 1 FROM dbo.FinansHareketleri r WHERE r.TersKayitId=f.Id)",("@id",id),("@m",d.S.Odenecek),("@c",d.Cari))){using var r=q.ExecuteReader();if(!r.Read())throw new ArgumentException("Bordro ödemesi bulunamadı veya daha önce terslenmiş.");finance=r.GetInt64(0);cari=r.GetInt64(1);oldDate=r.GetDateTime(2);}
  if(date.Date<oldDate.Date)throw new ArgumentException("Ters kayıt tarihi ödeme tarihinden önce olamaz.");
  using var ch=Q(c,t,"INSERT dbo.CariHareketleri(CariId,Tarih,HareketTipi,Tutar,Aciklama,Kaynak,YapanKullaniciId,TersKayitId) OUTPUT INSERTED.Id SELECT CariId,@d,N'Alacak',Tutar,@g,N'Miapax Bordro Ödeme Ters',@u,Id FROM dbo.CariHareketleri WITH(UPDLOCK,HOLDLOCK) WHERE Id=@h AND NOT EXISTS(SELECT 1 FROM dbo.CariHareketleri r WHERE r.TersKayitId=@h)",("@d",date.Date),("@g",reason),("@u",user),("@h",cari));object? value=ch.ExecuteScalar();if(value is null)throw new ArgumentException("Ödeme cari kaydı başka işlemde terslenmiş.");long rev=Convert.ToInt64(value);
  using var fh=Q(c,t,"INSERT dbo.FinansHareketleri(HesapId,CariId,CariHareketId,Tarih,HareketTipi,Tutar,Aciklama,YapanKullaniciId,TersKayitId) SELECT HesapId,CariId,@ch,@d,N'Giriş',Tutar,@g,@u,Id FROM dbo.FinansHareketleri WHERE Id=@h",("@ch",rev),("@d",date.Date),("@g",reason),("@u",user),("@h",finance));fh.ExecuteNonQuery();
  using var update=Q(c,t,"UPDATE dbo.MPX280_Bordro SET Durum=N'Onaylandı',FinansHareketId=NULL WHERE Id=@id",("@id",id));update.ExecuteNonQuery();Iz(c,t,id,"Ödeme terslendi / finans "+finance,reason);t.Commit();
 }
 public void Iptal(long id,byte[] version,string status,string reason,DateTime tarih)
 {
if(HttpsOturumu.Uzak(cs)){HttpsOturumu.Cagir<object?>(cs,"BordroDeposu.Iptal","",new object?[]{id,version,status,reason,tarih});return;}

  if(status is not("Taslak" or "Onaylandı"))throw new ArgumentException("Ödenmiş bordro bu işlemle iptal edilemez; ödeme ters kaydı gerekir.");Gerekce(reason);using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"HR.PAYROLL.CANCEL");var d=Oku(c,t,id,version,status);
  using(var q=Q(c,t,"SELECT COUNT(*) FROM dbo.MPX280_Bordro WITH(UPDLOCK,HOLDLOCK) WHERE PersonelId=@p AND Yil=@y AND Ay>@a AND Durum<>N'İptal'",("@p",d.Person),("@y",d.G.Yil),("@a",d.G.Ay)))if(Convert.ToInt32(q.ExecuteScalar())!=0)throw new ArgumentException("Sonraki bordrolar mevcut; önce en son dönemi ele alın.");
  if(status=="Onaylandı"&&tarih.Date<new DateTime(d.G.Yil,d.G.Ay,1).AddMonths(1).AddDays(-1))throw new ArgumentException("Tahakkuk ters kayıt tarihi tahakkuk tarihinden önce olamaz.");
  if(status=="Onaylandı"){check(c,t,"CUSTOMER.EDIT");using var q=Q(c,t,"INSERT dbo.CariHareketleri(CariId,Tarih,HareketTipi,Tutar,Aciklama,Kaynak,YapanKullaniciId,TersKayitId) SELECT CariId,@d,N'Borç',Tutar,@r,N'Miapax Bordro İptal',@u,Id FROM dbo.CariHareketleri WHERE Id=@h AND NOT EXISTS(SELECT 1 FROM dbo.CariHareketleri WHERE TersKayitId=@h)",("@d",tarih.Date),("@r",reason),("@u",user),("@h",d.Hareket));if(q.ExecuteNonQuery()!=1)throw new ArgumentException("Tahakkuk başka işlemde terslenmiş.");}
  using var update=Q(c,t,"UPDATE dbo.MPX280_Bordro SET Durum=N'İptal' WHERE Id=@id",("@id",id));update.ExecuteNonQuery();Iz(c,t,id,"İptal",reason);t.Commit();
 }
}
