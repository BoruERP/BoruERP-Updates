using System.Data;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using ClosedXML.Excel;
using Microsoft.Win32;
namespace MiapaxERP.Desktop.Muhasebe280;
public sealed class MutabakatPaneli:UserControl
{
 readonly MutabakatDeposu db;readonly DatePicker start=new(){SelectedDate=new DateTime(DateTime.Today.Year,DateTime.Today.Month,1)},end=new(){SelectedDate=DateTime.Today};
 readonly DataGrid grid=new(){AutoGenerateColumns=true,IsReadOnly=true,CanUserAddRows=false,SelectionMode=DataGridSelectionMode.Single};bool arsiv;
 public MutabakatPaneli(string cs,int user):this(new MutabakatDeposu(cs,user)){}
 internal MutabakatPaneli(MutabakatDeposu store)
 {
  db=store;var root=new DockPanel{Margin=new Thickness(12)};Content=root;var top=new StackPanel();DockPanel.SetDock(top,Dock.Top);root.Children.Add(top);top.Children.Add(new TextBlock{Text="Alış / satış mutabakatı · BA/BS tarihî arşivi",FontSize=22});top.Children.Add(new TextBlock{Text="BA/BS yükümlülüğü Eylül 2024'ten itibaren kaldırıldı. Güncel dönemler burada alış/satış mutabakatı olarak izlenir. İade belgeleri ayrı gösterilir; taslak, terslenmiş ve çift bağlantılı kayıtlar toplama alınmaz. Tutarlar TRY karşılığıdır. GİB'e bildirim gönderilmez.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,8,0,12)});var bar=new WrapPanel();top.Children.Add(bar);bar.Children.Add(start);bar.Children.Add(end);
  void B(string text,Action a)=>ErpModulPenceresi.B(bar,text,a);
  B("Mutabakatı getir",()=>{grid.ItemsSource=db.Ozet(start.SelectedDate??throw new ArgumentException("Başlangıç seçin."),end.SelectedDate??throw new ArgumentException("Bitiş seçin.")).DefaultView;arsiv=false;});B("Excel aktar",Export);B("Eski BA/BS arşivi",()=>{grid.ItemsSource=db.Arsiv().DefaultView;arsiv=true;});B("Geçmiş bildirim PDF ekle",Arsivle);B("Arşiv PDF indir",Indir);grid.AutoGeneratingColumn+=(_,e)=>{if(e.PropertyName=="Id")e.Cancel=true;};root.Children.Add(grid);
 }
 void Export()
 {
  if(grid.ItemsSource is not DataView v)throw new ArgumentException("Önce raporu getirin.");
  // Re-query enforces current permission and prevents exporting a cached privileged view.
  var data=arsiv?db.Arsiv():db.Ozet(start.SelectedDate!.Value,end.SelectedDate!.Value);var s=new SaveFileDialog{Filter="Excel çalışma kitabı|*.xlsx",FileName=arsiv?"Miapax-BA-BS-Arsiv.xlsx":"Miapax-Alis-Satis-Mutabakat.xlsx"};if(s.ShowDialog()!=true)return;using var book=new XLWorkbook();var sheet=book.AddWorksheet("Mutabakat");
  for(int c=0;c<data.Columns.Count;c++)sheet.Cell(1,c+1).SetValue(data.Columns[c].ColumnName);
  for(int r=0;r<data.Rows.Count;r++)for(int c=0;c<data.Columns.Count;c++){var val=data.Rows[r][c];var cell=sheet.Cell(r+2,c+1);if(val is decimal n)cell.SetValue(n);else if(val is long l)cell.SetValue(l);else if(val is int i)cell.SetValue(i);else cell.SetValue(Convert.ToString(val)??"");}
  sheet.Row(1).Style.Font.Bold=true;sheet.Columns().AdjustToContents(8,60);book.SaveAs(s.FileName);
 }
 void Arsivle()
 {
  var w=new Window{Title="Miapax ERP · Eski BA/BS bildirimi arşivle",Owner=Window.GetWindow(this),Width=600,Height=520,WindowStartupLocation=WindowStartupLocation.CenterOwner};var p=new StackPanel{Margin=new Thickness(20)};w.Content=p;
  TextBox T(string label){p.Children.Add(new TextBlock{Text=label,Margin=new Thickness(0,10,0,4)});var b=new TextBox{Padding=new Thickness(6)};p.Children.Add(b);return b;}var year=T("Yıl");var month=T("Ay (1–12)");p.Children.Add(new TextBlock{Text="Bildirim türü"});var type=new ComboBox{ItemsSource=new[]{"BA","BS"}};p.Children.Add(type);var why=T("Geçmiş bildirimin açıklaması / dayanağı");var error=new TextBlock{TextWrapping=TextWrapping.Wrap};p.Children.Add(error);var button=new Button{Content="PDF seç ve arşivle (Eylül 2024 öncesi)",Padding=new Thickness(12),Margin=new Thickness(0,20,0,0)};p.Children.Add(button);
  button.Click+=(_,_)=>{try{if(!int.TryParse(year.Text,out int y)||!int.TryParse(month.Text,out int m)||type.SelectedItem is not string t)throw new ArgumentException("Yıl, ay ve türü seçin.");var f=new OpenFileDialog{Filter="PDF dosyası|*.pdf"};if(f.ShowDialog()!=true)return;if(new FileInfo(f.FileName).Length>5_000_000)throw new ArgumentException("En fazla 5 MB PDF seçin.");db.Arsivle(y,m,t,why.Text,File.ReadAllBytes(f.FileName));w.DialogResult=true;grid.ItemsSource=db.Arsiv().DefaultView;arsiv=true;}catch(Exception e){error.Text=e.Message;}};w.ShowDialog();
 }
 void Indir(){if(!arsiv||grid.SelectedItem is not DataRowView r)throw new ArgumentException("Arşivden bir bildirim seçin.");byte[] pdf=db.Indir(Convert.ToInt64(r["Id"]));var f=new SaveFileDialog{Filter="PDF dosyası|*.pdf",FileName=$"Miapax-{r["Tur"]}-{r["Yil"]}-{r["Ay"]}.pdf"};if(f.ShowDialog()==true)File.WriteAllBytes(f.FileName,pdf);}
}
