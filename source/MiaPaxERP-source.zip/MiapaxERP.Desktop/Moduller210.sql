SET XACT_ABORT ON;
BEGIN TRANSACTION;
DECLARE @lock int;
EXEC @lock=sys.sp_getapplock @Resource=N'MiapaxERP.Moduller210',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=15000;
IF @lock<0 THROW 51000,N'Saha modülü kurulum kilidi alınamadı.',1;
IF OBJECT_ID(N'dbo.BERP210_SahaMusteri',N'U') IS NULL
BEGIN
 CREATE TABLE dbo.BERP210_SahaMusteri(Id uniqueidentifier PRIMARY KEY,IlId nvarchar(30) NOT NULL,IlceId nvarchar(40) NOT NULL,Koy nvarchar(160) NOT NULL,Ad nvarchar(160) NOT NULL,Telefon nvarchar(30) NOT NULL,Veri nvarchar(max) NOT NULL CHECK(ISJSON(Veri)=1),Olusturan int NOT NULL,Olusturma datetime2 NOT NULL DEFAULT SYSUTCDATETIME(),Guncelleme datetime2 NOT NULL DEFAULT SYSUTCDATETIME(),Surum rowversion);
 CREATE INDEX IX_BERP210_Konum ON dbo.BERP210_SahaMusteri(IlId,IlceId,Koy);
 CREATE TABLE dbo.BERP210_Gorusme(Id uniqueidentifier PRIMARY KEY,MusteriId uniqueidentifier NOT NULL REFERENCES dbo.BERP210_SahaMusteri(Id),Tarih datetime2 NOT NULL,Sonuc nvarchar(2000) NOT NULL,KullaniciId int NOT NULL,KayitZamani datetime2 NOT NULL DEFAULT SYSUTCDATETIME());
END;
INSERT dbo.Yetkiler(YetkiKodu,Modul,Islem,Aciklama,Aktif)
SELECT v.Kod,N'Saha pazarlama',v.Ad,v.Ad,1 FROM(VALUES('FIELD.VIEW',N'Saha müşterilerini görüntüle'),('FIELD.EDIT',N'Saha müşterisi ve görüşme kaydet'))v(Kod,Ad)
WHERE NOT EXISTS(SELECT 1 FROM dbo.Yetkiler WHERE YetkiKodu=v.Kod);
IF NOT EXISTS(SELECT 1 FROM dbo.BERP_Sema WHERE Surum=210)INSERT dbo.BERP_Sema(Surum)VALUES(210);
COMMIT;
