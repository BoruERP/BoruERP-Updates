SET XACT_ABORT ON;
BEGIN TRANSACTION;
DECLARE @lock int;EXEC @lock=sys.sp_getapplock @Resource=N'MiapaxERP.EBelge.271',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=15000;
IF @lock<0 THROW 51271,N'E-belge bağlantı kurulum kilidi alınamadı.',1;
IF COL_LENGTH('dbo.BERP270_EBelge','Taslak') IS NULL ALTER TABLE dbo.BERP270_EBelge ADD Taslak bit NOT NULL CONSTRAINT DF_EBelge_Taslak DEFAULT 1;
IF COL_LENGTH('dbo.BERP270_EBelge','TaslakGonder') IS NULL ALTER TABLE dbo.BERP270_EBelge ADD TaslakGonder bit NOT NULL CONSTRAINT DF_EBelge_TaslakGonder DEFAULT 0;
IF COL_LENGTH('dbo.BERP270_EBelge','SatisId') IS NULL ALTER TABLE dbo.BERP270_EBelge ADD SatisId bigint NULL;
DECLARE @ck sysname;SELECT @ck=name FROM sys.check_constraints WHERE parent_object_id=OBJECT_ID('dbo.BERP270_EBelge') AND definition LIKE '%Durum%';
IF @ck IS NOT NULL BEGIN DECLARE @ddl nvarchar(1000)=N'ALTER TABLE dbo.BERP270_EBelge DROP CONSTRAINT '+QUOTENAME(@ck);EXEC(@ddl);END;
ALTER TABLE dbo.BERP270_EBelge ADD CONSTRAINT CK_EBelge_Durum CHECK(Durum IN(N'Hazır',N'Gönderim başladı',N'Taslak kabul edildi',N'Gönderim kabul edildi',N'Belirsiz',N'Reddedildi',N'Sağlayıcıda bulundu'));
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name='UX_Ebelge_Satis' AND object_id=OBJECT_ID('dbo.BERP270_EBelge'))
EXEC(N'CREATE UNIQUE INDEX UX_Ebelge_Satis ON dbo.BERP270_EBelge(Ortam,Vkn,SatisId,AppType) WHERE SatisId IS NOT NULL');
IF OBJECT_ID('dbo.BERP270_EBelgeDosya','U') IS NULL
BEGIN
 CREATE TABLE dbo.BERP270_EBelgeDosya(Id bigint IDENTITY PRIMARY KEY,Ortam varchar(10) NOT NULL CHECK(Ortam IN('Test','Canli')),Vkn varchar(11) NOT NULL,Ettn uniqueidentifier NOT NULL,Kutu int NOT NULL CHECK(Kutu BETWEEN 1 AND 5),Xml nvarchar(max) NOT NULL,Ozet char(64) NOT NULL,Taslak bit NOT NULL,Durum int NOT NULL,ZarfDurum int NOT NULL,Iptal bit NOT NULL,Alindi datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET(),Surum rowversion,UNIQUE(Ortam,Vkn,Ettn,Kutu));
 CREATE TABLE dbo.BERP270_EBelgeIslem(Id bigint IDENTITY PRIMARY KEY,Ortam varchar(10) NOT NULL,Vkn varchar(11) NOT NULL,Ettn uniqueidentifier NOT NULL,Islem varchar(20) NOT NULL,CariId int NULL,CariHareketId bigint NULL,OncekiHareketId bigint NULL,Gerekce nvarchar(400) NOT NULL,Kullanici int NOT NULL,Zaman datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET(),TersId bigint NULL REFERENCES dbo.BERP270_EBelgeIslem(Id),UNIQUE(Ortam,Vkn,Ettn,Islem));
 CREATE TABLE dbo.BERP270_EBelgeStokBag(IslemId bigint NOT NULL REFERENCES dbo.BERP270_EBelgeIslem(Id),Satir nvarchar(100) NOT NULL,StokId int NOT NULL,HareketId bigint NOT NULL UNIQUE,PRIMARY KEY(IslemId,Satir));
 CREATE TABLE dbo.BERP270_EBelgeBirim(Yerel nvarchar(20) PRIMARY KEY,Ubl varchar(3) NOT NULL);
END;
IF OBJECT_ID('dbo.BERP270_EBelgeTaraf','U') IS NULL CREATE TABLE dbo.BERP270_EBelgeTaraf(Ortam varchar(10) NOT NULL,Vkn varchar(11) NOT NULL,Veri nvarchar(max) NOT NULL,Kullanici int NOT NULL,Surum rowversion,PRIMARY KEY(Ortam,Vkn));
IF OBJECT_ID('dbo.BERP270_EBelgeSatisBag','U') IS NULL CREATE TABLE dbo.BERP270_EBelgeSatisBag(Ortam varchar(10) NOT NULL,Vkn varchar(11) NOT NULL,SatisId bigint NOT NULL,Tur varchar(10) NOT NULL,EbelgeId bigint NOT NULL UNIQUE REFERENCES dbo.BERP270_EBelge(Id),PRIMARY KEY(Ortam,Vkn,SatisId,Tur));
IF COL_LENGTH('dbo.BERP270_EBelgeIslem','BelgeNo') IS NULL ALTER TABLE dbo.BERP270_EBelgeIslem ADD BelgeNo varchar(16) NULL,BelgeTipi nvarchar(40) NULL,BelgeTarihi date NULL,Matrah decimal(18,4) NULL,Kdv decimal(18,4) NULL,GenelToplam decimal(18,4) NULL;
INSERT dbo.Yetkiler(YetkiKodu,Modul,Islem,Aciklama,Aktif)
SELECT p.Kod,N'Muhasebe',p.Islem,p.Aciklama,1 FROM(VALUES
('FINANCE.EBELGE.SEND',N'Gönder',N'Onaylı belgeyi entegratöre gönderme'),
('FINANCE.EBELGE.POST',N'Muhasebeleştir',N'UBL ve cari hesap bağlantısı'),
('FINANCE.EBELGE.REVERSE',N'Ters kayıt',N'E-belge muhasebe ters kaydı'),
('FINANCE.EBELGE.STOCK',N'Sevkiyat',N'e-İrsaliye stok hareketi bağlantısı')
)p(Kod,Islem,Aciklama)WHERE NOT EXISTS(SELECT 1 FROM dbo.Yetkiler y WHERE y.YetkiKodu=p.Kod);
COMMIT;
