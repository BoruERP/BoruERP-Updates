using System.Data;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed partial class IsletmeServisi{
public void ExcelStokKaydet(ExcelVeYazdirmaPenceresi.StokSatiri s){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"IsletmeServisi.ExcelStokKaydet","",new object?[]{s});return;}

        Text(s.Kod,1,50,"Stok kodu");Text(s.Ad,1,200,"Stok adı");Text(s.Aciklama,0,500,"Açıklama");
        if(s.Birim is not("KG" or "Metre" or "Adet" or "Ton" or "Gram" or "Litre" or "M2" or "M3"))throw new ArgumentException("Birim geçersiz.");
        if(s.Minimum.HasValue&&(s.Minimum<0||decimal.Round(s.Minimum.Value,3)!=s.Minimum))throw new ArgumentException("Minimum miktarı kontrol edin.");
        if(s.Acilis.HasValue&&(s.Acilis<0||decimal.Round(s.Acilis.Value,3)!=s.Acilis))throw new ArgumentException("Açılış miktarını kontrol edin.");
        using var con=access.Ac();using var tx=con.BeginTransaction(IsolationLevel.Serializable);Yetki(con,tx,"STOCK.CREATE");
        using(var type=Q(con,tx,"SELECT COUNT(*) FROM dbo.StokTipleri t WITH(HOLDLOCK) WHERE t.Ad=@a AND t.Aktif=1 AND NOT EXISTS(SELECT 1 FROM dbo.StokOzellikTanimlari o WHERE o.StokTipId=t.Id AND o.Aktif=1 AND o.Zorunlu=1)",("@a",s.Tip)))if(Convert.ToInt32(type.ExecuteScalar())!=1)throw new ArgumentException("Aktif stok tipi bulunamadı veya zorunlu özel alanları var. Bu kartı stok ekranından tamamlayın.");
                        Yetki(con, tx,"STOCK.CREATE");
                        if (s.Acilis.GetValueOrDefault() > 0) Yetki(con, tx,"STOCK.OPENING");
                        using (var check = new SqlCommand(
                            "SELECT COUNT(*) FROM dbo.StokKartlari WITH (UPDLOCK, HOLDLOCK) WHERE StokKodu=@kod", con, tx))
                        {
                            check.Parameters.Add("@kod", SqlDbType.NVarChar, 50).Value = s.Kod;
                            if (Convert.ToInt32(check.ExecuteScalar()) != 0)
                                throw new InvalidOperationException("Stok kodu veritabanında zaten mevcut");
                        }
                        int id;
                        using (var cmd = new SqlCommand(@"
INSERT INTO dbo.StokKartlari
(StokKodu,StokAdi,StokTipi,Birim,Aciklama,Aktif,KayitTarihi,MinimumStokMiktari)
OUTPUT INSERTED.Id
VALUES(@kod,@ad,@tip,@birim,@aciklama,@aktif,SYSDATETIME(),@min)", con, tx))
                        {
                            cmd.Parameters.Add("@kod", SqlDbType.NVarChar, 50).Value = s.Kod;
                            cmd.Parameters.Add("@ad", SqlDbType.NVarChar, 200).Value = s.Ad;
                            cmd.Parameters.Add("@tip", SqlDbType.NVarChar, 30).Value = s.Tip;
                            cmd.Parameters.Add("@birim", SqlDbType.NVarChar, 20).Value = s.Birim;
                            cmd.Parameters.Add("@aktif", SqlDbType.Bit).Value = s.Aktif;
                            cmd.Parameters.Add("@aciklama", SqlDbType.NVarChar, 500).Value = s.Aciklama.Length == 0 ? DBNull.Value : s.Aciklama;
                            var minimum = cmd.Parameters.Add("@min", SqlDbType.Decimal);
                            minimum.Precision = 18;
                            minimum.Scale = 3;
                            minimum.Value = s.Minimum.HasValue ? s.Minimum.Value : DBNull.Value;
                            id = Convert.ToInt32(cmd.ExecuteScalar());
                        }
                        if (s.Acilis is decimal stokAcilisKaydi && stokAcilisKaydi > 0)
                        {
                            using (var bal = new SqlCommand(@"
INSERT INTO dbo.StokBakiyeleri(StokKartId,Birim,Miktar)
VALUES(@id,@birim,@miktar)", con, tx))
                            {
                                bal.Parameters.Add("@id", SqlDbType.Int).Value = id;
                                bal.Parameters.Add("@birim", SqlDbType.NVarChar, 20).Value = s.Birim;
                                var amt = bal.Parameters.Add("@miktar", SqlDbType.Decimal);
                                amt.Precision = 18; amt.Scale = 3; amt.Value = stokAcilisKaydi;
                                bal.ExecuteNonQuery();
                            }
                            using (var move = new SqlCommand(@"
INSERT INTO dbo.StokHareketleri(StokKartId,HareketTipi,Yon,Miktar,Birim,Aciklama)
VALUES(@id,N'ACILIS_GIRIS',N'G',@miktar,@birim,N'Excel toplu stok başlangıcı')", con, tx))
                            {
                                move.Parameters.Add("@id", SqlDbType.Int).Value = id;
                                move.Parameters.Add("@birim", SqlDbType.NVarChar, 20).Value = s.Birim;
                                var amt = move.Parameters.Add("@miktar", SqlDbType.Decimal);
                                amt.Precision = 18; amt.Scale = 3; amt.Value = stokAcilisKaydi;
                                move.ExecuteNonQuery();
                            }
                        }
if(s.Acilis.GetValueOrDefault()>0)StokPartile(con,tx,id,s.Acilis!.Value,"G",null,"Excel açılış partisi");tx.Commit();
}
}