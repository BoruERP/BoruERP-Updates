using System.Diagnostics;
using System.IO;
namespace MiapaxERP.Desktop;

internal static class GuncelleyiciBaslatma
{
    internal static bool Yazilabilir(string directory)
    {
        try
        {
            string probe = Path.Combine(Path.GetFullPath(directory), ".MiapaxERP-yetki-" + Guid.NewGuid().ToString("N") + ".tmp");
            using var stream = new FileStream(probe, FileMode.CreateNew, FileAccess.Write, FileShare.None, 1, FileOptions.DeleteOnClose);
            stream.WriteByte(0);
            return true;
        }
        catch (UnauthorizedAccessException) { return false; }
        catch (IOException) { return false; }
    }

    internal static ProcessStartInfo Olustur(string updater, string cache, string install, int pid, string manifest, bool rollback, bool writable)
    {
        var info = new ProcessStartInfo(updater)
        {
            WorkingDirectory = cache,
            UseShellExecute = !writable,
            CreateNoWindow = writable
        };
        if (!writable) info.Verb = "runas";
        info.ArgumentList.Add(rollback ? "rollback" : "apply");
        info.ArgumentList.Add(pid.ToString());
        info.ArgumentList.Add(install);
        info.ArgumentList.Add(manifest);
        return info;
    }
}
