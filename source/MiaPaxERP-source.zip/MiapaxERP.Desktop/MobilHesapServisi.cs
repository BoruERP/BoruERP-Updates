using System.Data;
using System.IO;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

public sealed record MobilKimlik(Guid Id,int Kullanici,string Ad,string Rol,string Ozet);
public sealed class MobilHesapServisi(string connection)
{
 public static void Yonetici(SqlConnection c,SqlTransaction? tx,int user){
  LisansOturumu.Gerekli("MOBIL");
  using var q=ErpModulServisi.Komut(c,tx,"SELECT COUNT(*) FROM dbo.Kullanicilar k JOIN dbo.KullaniciRolAtamalari a ON a.KullaniciId=k.Id JOIN dbo.KullaniciRolleri r ON r.Id=a.RolId WHERE k.Id=@u AND k.Aktif=1 AND r.Aktif=1 AND r.RolAdi=N'Yönetici'",("@u",user));
  if(Convert.ToInt32(q.ExecuteScalar())==0)throw new UnauthorizedAccessException("Yönetici oturumu gerekli.");
 }
 public void Kur(int admin){if(HttpsOturumu.Uzak(connection)){new MobilYonetimServisi(connection,admin).Kur();return;}using var c=new SqlConnection(connection);c.Open();Yonetici(c,null,admin);ModulKurulumu180.Hazirla(connection,admin);if(LisansOturumu.ModulVar("CRM"))new SahaServisi(connection,admin).Kur();using var q=new SqlCommand(File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"Moduller220.sql")),c);q.ExecuteNonQuery();}
 public DataTable Liste(int admin){if(HttpsOturumu.Uzak(connection)){return new MobilYonetimServisi(connection,admin).Liste();}using var c=new SqlConnection(connection);c.Open();Yonetici(c,null,admin);using var q=new SqlCommand("SELECT h.Id,h.KullaniciId,h.Ad,h.Rol,h.Aktif,(SELECT COUNT(*) FROM dbo.BERP220_Cihaz d WHERE d.HesapId=h.Id AND d.Iptal=0) AS Cihaz FROM dbo.BERP220_Hesap h ORDER BY h.Ad",c);using var r=q.ExecuteReader();var t=new DataTable();t.Load(r);return t;}
 public Guid Kaydet(int admin,int user,string name,string role){if(HttpsOturumu.Uzak(connection)){return new MobilYonetimServisi(connection,admin).Kaydet(user,name,role);}
  if(string.IsNullOrWhiteSpace(name)||name.Length>160||role is not("SAHA" or "PATRON"))throw new ArgumentException("Ad ve rol geçersiz.");
  using var c=new SqlConnection(connection);c.Open();using var tx=c.BeginTransaction(IsolationLevel.Serializable);Yonetici(c,tx,admin);
  using var active=ErpModulServisi.Komut(c,tx,"SELECT COUNT(*) FROM dbo.Kullanicilar WHERE Id=@u AND Aktif=1",("@u",user));if(Convert.ToInt32(active.ExecuteScalar())!=1)throw new ArgumentException("Etkin ERP kullanıcı numarası girin.");
  using var find=ErpModulServisi.Komut(c,tx,"SELECT Id FROM dbo.BERP220_Hesap WHERE KullaniciId=@u",("@u",user));var existing=find.ExecuteScalar();var id=existing is Guid g?g:Guid.NewGuid();
  using var q=ErpModulServisi.Komut(c,tx,existing is Guid?"UPDATE dbo.BERP220_Hesap SET Ad=@a,Rol=@r,Aktif=1 WHERE Id=@id":"INSERT dbo.BERP220_Hesap(Id,KullaniciId,Ad,Rol)VALUES(@id,@u,@a,@r)",("@id",id),("@u",user),("@a",name.Trim()),("@r",role));q.ExecuteNonQuery();tx.Commit();return id;
 }
 public string Esle(int admin,Guid id){if(HttpsOturumu.Uzak(connection)){return new MobilYonetimServisi(connection,admin).Esle(id);}using var c=new SqlConnection(connection);c.Open();using var tx=c.BeginTransaction();Yonetici(c,tx,admin);string code=MobilRaporSunucusu.YeniAnahtar();using var q=ErpModulServisi.Komut(c,tx,"DELETE dbo.BERP220_Esleme WHERE HesapId=@id OR Bitis<SYSUTCDATETIME(); INSERT dbo.BERP220_Esleme(Ozet,HesapId,Bitis) SELECT @h,Id,DATEADD(minute,15,SYSUTCDATETIME()) FROM dbo.BERP220_Hesap WHERE Id=@id AND Aktif=1",("@id",id),("@h",MobilRaporSunucusu.Ozet(code)));q.ExecuteNonQuery();tx.Commit();return code;}
 public void Iptal(int admin,Guid id){if(HttpsOturumu.Uzak(connection)){new MobilYonetimServisi(connection,admin).Iptal(id);return;}using var c=new SqlConnection(connection);c.Open();using var tx=c.BeginTransaction();Yonetici(c,tx,admin);using var q=ErpModulServisi.Komut(c,tx,"UPDATE dbo.BERP220_Hesap SET Aktif=0 WHERE Id=@id;UPDATE dbo.BERP220_Cihaz SET Iptal=1 WHERE HesapId=@id;DELETE dbo.BERP220_Esleme WHERE HesapId=@id",("@id",id));q.ExecuteNonQuery();tx.Commit();}
 public object Bagla(string code,string name){
  LisansOturumu.Gerekli("MOBIL");if(code?.Length!=64||string.IsNullOrWhiteSpace(name)||name.Length>100)throw new ArgumentException("Eşleme kodu veya cihaz adı geçersiz.");
  using var c=new SqlConnection(connection);c.Open();using var tx=c.BeginTransaction(IsolationLevel.Serializable);
  using var q=ErpModulServisi.Komut(c,tx,"SELECT h.Id,h.KullaniciId,h.Ad,h.Rol FROM dbo.BERP220_Esleme e WITH(UPDLOCK) JOIN dbo.BERP220_Hesap h ON h.Id=e.HesapId JOIN dbo.Kullanicilar k ON k.Id=h.KullaniciId WHERE e.Ozet=@h AND e.Bitis>SYSUTCDATETIME() AND h.Aktif=1 AND k.Aktif=1",("@h",MobilRaporSunucusu.Ozet(code)));
  Guid id;string ad,rol;using(var r=q.ExecuteReader()){if(!r.Read())throw new UnauthorizedAccessException("Eşleme kodu kullanılmış, süresi dolmuş veya hesap kapalı.");id=r.GetGuid(0);ad=r.GetString(2);rol=r.GetString(3);}
  string token=MobilRaporSunucusu.YeniAnahtar();using var write=ErpModulServisi.Komut(c,tx,"DELETE dbo.BERP220_Esleme WHERE Ozet=@h;INSERT dbo.BERP220_Cihaz(Ozet,HesapId,Ad)VALUES(@t,@id,@n)",("@h",MobilRaporSunucusu.Ozet(code)),("@t",MobilRaporSunucusu.Ozet(token)),("@id",id),("@n",name));write.ExecuteNonQuery();tx.Commit();return new{token,id,ad,rol};
 }
 public MobilKimlik Dogrula(string token){if(token.Length!=64)throw new UnauthorizedAccessException("Cihaz doğrulanamadı.");using var c=new SqlConnection(connection);c.Open();return Kontrol(c,null,MobilRaporSunucusu.Ozet(token));}
 public static MobilKimlik Kontrol(SqlConnection c,SqlTransaction? tx,string digest){
  LisansOturumu.Gerekli("MOBIL");using var q=ErpModulServisi.Komut(c,tx,"SELECT h.Id,h.KullaniciId,h.Ad,h.Rol FROM dbo.BERP220_Cihaz d JOIN dbo.BERP220_Hesap h ON h.Id=d.HesapId JOIN dbo.Kullanicilar k ON k.Id=h.KullaniciId WHERE d.Ozet=@h AND d.Iptal=0 AND h.Aktif=1 AND k.Aktif=1",("@h",digest));using var r=q.ExecuteReader();if(!r.Read())throw new UnauthorizedAccessException("Mobil hesap veya cihaz erişimi iptal edilmiş.");return new(r.GetGuid(0),r.GetInt32(1),r.GetString(2),r.GetString(3),digest);
 }
}
