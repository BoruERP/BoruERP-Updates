using System.Data;
using System.Globalization;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

public sealed record ErpUretimEmri(int? Id,string No,int Mamul,decimal Plan,string Birim,int? Recete,decimal? HedefKg,DateTime? Baslangic,DateTime? Bitis,string Aciklama);
public sealed record ErpEskiReceteKalemi(int Stok,decimal Oran);
public sealed record ErpEskiRecete(int? Id,string Kod,string Ad,int Mamul,ErpEskiReceteKalemi[] Kalemler);
public sealed partial class EskiUretimServisi(string connection,int user)
{
    readonly ErpModulServisi access=new(connection,user);
    static readonly CultureInfo uretimTr=CultureInfo.GetCultureInfo("tr-TR");
    static string uretimYazi(decimal n)=>n.ToString("0.###",uretimTr);
    static string? UretimBiriminiNormallestir(string? value)=>value?.Trim().ToLowerInvariant() switch {"kg"=>"kg","metre"=>"metre","adet"=>"adet",_=>null};
    static void Miktarlar(decimal uretilen,decimal fire)
    {if(uretilen<0||fire<0||uretilen>999999999999999.999m||fire>999999999999999.999m||decimal.Round(uretilen,3)!=uretilen||decimal.Round(fire,3)!=fire)throw new ArgumentException("Miktarlar negatif olamaz ve en fazla üç ondalıklı olmalı.");}
    static void EmirDogrula(ErpUretimEmri g)
    {
        if(g is null||g.Mamul<1||string.IsNullOrWhiteSpace(g.No)||g.No.Length>30||g.Aciklama is null||g.Aciklama.Length>500||g.Plan<=0||g.Plan>999999999999999.999m||decimal.Round(g.Plan,3)!=g.Plan||g.Birim is not("kg" or "metre" or "adet")||g.Birim=="adet"&&decimal.Truncate(g.Plan)!=g.Plan||g.Baslangic.HasValue&&g.Bitis.HasValue&&g.Bitis.Value.Date<g.Baslangic.Value.Date||g.Recete.HasValue&&!g.HedefKg.HasValue)throw new ArgumentException("Üretim emri bilgileri geçersiz.");
        if(g.HedefKg.HasValue&&(g.HedefKg<=0||g.HedefKg>999999999999999.999m||decimal.Round(g.HedefKg.Value,3)!=g.HedefKg))throw new ArgumentException("Hedef ağırlık geçersiz.");
        if(g.Birim=="kg"&&g.HedefKg!=g.Plan)throw new ArgumentException("KG emrinde hedef ağırlık planlanan miktarla aynı olmalı.");
    }
    static DataTable ReceteTablosu(ErpEskiRecete g)
    {
        if(g is null||string.IsNullOrWhiteSpace(g.Kod)||g.Kod.Length>30||string.IsNullOrWhiteSpace(g.Ad)||g.Ad.Length>150||g.Mamul<1||g.Kalemler is null||g.Kalemler.Length>500||g.Kalemler.Select(k=>k.Stok).Distinct().Count()!=g.Kalemler.Length||g.Kalemler.Any(k=>k.Stok<1||k.Stok==g.Mamul||k.Oran<=0||k.Oran>100||decimal.Round(k.Oran,4)!=k.Oran)||g.Kalemler.Sum(k=>k.Oran)>100)throw new ArgumentException("Reçete/hammadde bilgilerini kontrol edin.");
        var table=new DataTable();table.Columns.Add("HammaddeStokId",typeof(int));table.Columns.Add("Hammadde");table.Columns.Add("Yuzde",typeof(decimal));
        foreach(var k in g.Kalemler)table.Rows.Add(k.Stok,"Stok "+k.Stok,k.Oran);return table;
    }
}
