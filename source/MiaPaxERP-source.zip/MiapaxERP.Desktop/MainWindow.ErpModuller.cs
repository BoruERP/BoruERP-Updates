using System.Windows;
namespace MiapaxERP.Desktop;
public partial class MainWindow
{
 void TicaretMerkeziAc(object sender,RoutedEventArgs e)
 {
     if(aktifKullanici==null || DemoModu){MessageBox.Show("Bu modül için oturum açın.");return;}
     try{ModulKurulumu180.Hazirla(baglantiAdresi,aktifKullanici.KullaniciId);new TicaretMerkezi(baglantiAdresi,aktifKullanici.KullaniciId,(string)((Button)sender).Tag){Owner=this}.ShowDialog();}
     catch(Exception ex){MessageBox.Show(ex.Message,"MiapaxERP");}
 }
 void YeniModulAc(string type){if(DemoModu||aktifKullanici==null){MessageBox.Show("Bu modül için SQL Server kullanıcı oturumu açın.");return;}try{new ErpModulPenceresi(baglantiAdresi,aktifKullanici.KullaniciId,type){Owner=this}.ShowDialog();}catch(Exception e){MessageBox.Show("Modül açılamadı: "+e.Message,"MiapaxERP");}}
 void InsanKaynaklari_Click(object s,RoutedEventArgs e)=>YeniModulAc("personel");
 void SatinAlma_Click(object s,RoutedEventArgs e)=>YeniModulAc("satinalma");
 void HammaddeParti_Click(object s,RoutedEventArgs e)=>YeniModulAc("parti");
}
