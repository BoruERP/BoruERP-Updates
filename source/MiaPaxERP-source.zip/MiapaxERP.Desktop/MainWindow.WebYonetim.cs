using System.Windows;
namespace MiapaxERP.Desktop;
public partial class MainWindow
{
 void WebYonetimAc_Click(object sender,RoutedEventArgs e)
 {
  if(aktifKullanici is null||DemoModu){MessageBox.Show("Web Sitesi Yönetimi için kendi SQL/ERP hesabınızla giriş yapın.");return;}
  try{LisansOturumu.Gerekli("ETICARET");ModulKurulumu180.Hazirla(baglantiAdresi,aktifKullanici.KullaniciId);new WebYonetimi.WebYonetimPenceresi(baglantiAdresi,aktifKullanici.KullaniciId){Owner=this}.ShowDialog();}catch(Exception ex){MessageBox.Show(ex.Message,"Web Sitesi Yönetimi");}
 }
}
