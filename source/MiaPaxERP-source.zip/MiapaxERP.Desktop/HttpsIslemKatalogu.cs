using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Text.Json;
namespace MiapaxERP.Desktop;

public sealed record HttpsIslem(MethodInfo Metot, Func<string,int,string,object> Olustur);
public static partial class HttpsIslemKatalogu
{
    public static string[] Adlar=>islemler.Keys.Order().ToArray();
    public static object? Calistir(string connection,int user,HttpsCagri call)
    {
        // Kimlik ve bağlantı sunucudan gelir. İstemci bunları değiştiremez.
        if(!islemler.TryGetValue(call.Islem,out var op))throw new ArgumentException("İşlem desteklenmiyor. Uygulamayı güncelleyin.");
        if(call.Islem.StartsWith("TicaretDosyalari.",StringComparison.Ordinal))
        {if(call.Kapsam is not("SALES" or "PURCHASE" or "CRM" or "ECOM" or "TRADE"))throw new ArgumentException("Modül geçersiz.");}
        else if(call.Kapsam.Length!=0)throw new ArgumentException("Kapsam geçersiz.");
        var ps=op.Metot.GetParameters();if(call.Argumanlar.Length!=ps.Length)throw new ArgumentException("İşlem bilgileri eksik.");
        var args=ps.Select((p,i)=>call.Argumanlar[i].Deserialize(p.ParameterType,HttpsJson.Ayarlar)).ToArray();
        if(call.Islem.StartsWith("EbelgeDeposu.",StringComparison.Ordinal))for(int i=0;i<ps.Length;i++)if(ps[i].ParameterType==typeof(EBelge.HizliKimlik))
        {var identity=args[i] as EBelge.HizliKimlik??throw new ArgumentException("E-belge bağlantısı gerekli.");args[i]=new EBelge.EbelgeHttpsServisi(connection,user).GercekKimlik(identity.Ortam,identity.Vkn);}
        if(call.Islem=="LabServisi.RaporHtml"&&args.Length==3)args[2]="";
        try{return op.Metot.Invoke(op.Olustur(connection,user,call.Kapsam),args);}
        catch(TargetInvocationException e)when(e.InnerException!=null){ExceptionDispatchInfo.Capture(e.InnerException).Throw();throw;}
    }
}
