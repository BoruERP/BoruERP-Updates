using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using Point = System.Windows.Point;
using MouseEventArgs = System.Windows.Input.MouseEventArgs;
using Cursors = System.Windows.Input.Cursors;


namespace MiapaxERP.Desktop
{
    public partial class KrokiYonetimi : UserControl
    {
        private readonly ObservableCollection<BoruKalemi> kalemler = new();
        private Point? baslangic;
        private Line? onizleme;
        private bool boruCiziliyor;
        private double toplamUzunluk;

        private readonly string? krokiProfil;
        public KrokiYonetimi() : this(null) { }
        internal KrokiYonetimi(string? testProfil)
        {
            krokiProfil = testProfil;
            InitializeComponent();
            GelismisKrokiyiBagla();
            MalzemeTablosu.ItemsSource = kalemler;
            KrokiCanvas.ToolTip = "Taslak çizim: 1 piksel = 1 metre. Gerçek arazi ölçümü ve fiyat bağlantısı yoktur.";
            TxtGenelToplam.Text = "Fiyat tanımlanmadı";
            TxtGenelToplam.FontSize = 16;
        }

        private void BoruCiz_Click(object sender, RoutedEventArgs e)
        {
            CizimiBitir();
            boruCiziliyor = true;
            KrokiCanvas.Cursor = Cursors.Cross;
        }

        private void KrokiCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (!boruCiziliyor) return;
            Point nokta = e.GetPosition(KrokiCanvas);
            if (baslangic is Point onceki)
            {
                double uzunluk = (nokta - onceki).Length;
                if (uzunluk <= 0) return;
                var cizgi = YeniCizgi(onceki, nokta);
                KrokiCanvas.Children.Add(cizgi);
                toplamUzunluk += uzunluk;
                kalemler.Add(new BoruKalemi { Miktar = Math.Round(uzunluk, 2) });
                TxtToplamBoru.Text = $"{toplamUzunluk:N2} metre (taslak)";
            }
            baslangic = nokta;
            if (onizleme != null) KrokiCanvas.Children.Remove(onizleme);
            onizleme = YeniCizgi(nokta, nokta);
            onizleme.Opacity = 0.5;
            onizleme.StrokeDashArray = new DoubleCollection { 2, 2 };
            KrokiCanvas.Children.Add(onizleme);
            e.Handled = true;
        }

        private void KrokiCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (!boruCiziliyor || onizleme == null) return;
            Point nokta = e.GetPosition(KrokiCanvas);
            onizleme.X2 = nokta.X;
            onizleme.Y2 = nokta.Y;
        }

        private void KrokiCanvas_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            CizimiBitir();
            e.Handled = true;
        }

        private void CizimiBitir()
        {
            if (onizleme != null) KrokiCanvas.Children.Remove(onizleme);
            onizleme = null;
            baslangic = null;
            boruCiziliyor = false;
            KrokiCanvas.Cursor = Cursors.Arrow;
        }

        private static Line YeniCizgi(Point bas, Point son) => new()
        {
            X1 = bas.X, Y1 = bas.Y, X2 = son.X, Y2 = son.Y,
            Stroke = Brushes.DodgerBlue, StrokeThickness = 4,
            IsHitTestVisible = false
        };

        private sealed class BoruKalemi
        {
            public string Malzeme => "Boru (taslak)";
            public double Miktar { get; init; }
            public string Birim => "metre";
            public decimal? BirimFiyat => null;
            public decimal? Toplam => null;
        }
    }
}
