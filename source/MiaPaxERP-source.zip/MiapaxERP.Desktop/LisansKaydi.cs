using System;

namespace MiapaxERP.Desktop
{
    // Lisans sunucusundan alınan bilgileri temsil eden veri modeli.
    // Bu sınıf tek başına lisans doğrulaması veya güvenli saklama yapmaz.
    public class LisansKaydi
    {
        public string LisansAnahtari { get; set; } = string.Empty;
        public string FirmaKimligi { get; set; } = string.Empty;
        public string FirmaAdi { get; set; } = string.Empty;
        public string CihazKimligi { get; set; } = string.Empty;

        // Bu alanlar gerçek sunucu doğrulaması eklendiğinde doldurulacak.
        public DateTimeOffset? SonDogrulamaUtc { get; set; }
        public DateTimeOffset? LisansBitisUtc { get; set; }
        public string ImzaliLisansBelgesi { get; set; } = string.Empty;

        // Sunucunun bildirdiği durum. Yerel olarak değiştirilmesi
        // tek başına lisans yetkisi sağlamamalıdır.
        public string LisansDurumu { get; set; } = "Dogrulanmadi";
    }
}
