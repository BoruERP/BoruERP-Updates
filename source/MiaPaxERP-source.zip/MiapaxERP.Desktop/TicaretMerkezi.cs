using System.Data;
using System.Globalization;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using ClosedXML.Excel;

namespace MiapaxERP.Desktop;

public sealed partial class TicaretMerkezi : Window
{
    readonly TicaretDosyalari db;
    readonly Dictionary<string,TextBox> metin=new();
    readonly ComboBox tur=new(), para=new(), durum=new(), gecis=new();
    readonly ComboBox kanalFiltre=new();
    readonly DatePicker tarih=new(), vade=new();
    readonly TextBox ara=new(){Width=220,ToolTip="Referans, konu, firma veya sorumlu ara"};
    readonly TextBox not=new(){MaxLength=320,MinWidth=240};
    readonly DataGrid liste=Tablo(), hareketler=Tablo(), analiz=Tablo();
    readonly string analizSutunu;
    readonly TextBlock ozet=new(){FontSize=15,FontWeight=FontWeights.SemiBold,Margin=new Thickness(4,8,0,12)};
    readonly System.Windows.Controls.TabControl sekmeler=new();
    readonly DataTable kalemler=new();
    readonly DataGrid kalemGrid=new(){Height=150,AutoGenerateColumns=true,CanUserAddRows=true,CanUserDeleteRows=true};
    DataTable veri=new();
    DataRowView? secili=>liste.SelectedItem as DataRowView;
    long? duzenlenen;
    byte[]? surum;

    public TicaretMerkezi(string connection,int user,string kod)
    {
        db=new(connection,user,kod);
        analizSutunu=kod switch{"CRM"=>"Olasılık ağırlıklı tutar","ECOM"=>"Giderler sonrası tutar","SALES" or "PURCHASE"=>"Belge toplamı",_=>"Masraflar dahil tutar"};
        Title="MiapaxERP | "+db.Akis.Ad;
        Width=1160;Height=780;MinWidth=760;MinHeight=500;WindowStartupLocation=WindowStartupLocation.CenterOwner;
        var root=new DockPanel{Margin=new Thickness(18)};
        SetResourceReference(BackgroundProperty,"ErpZemin");Content=root;
        var bas=Tema170.Baslik("MIAPAX ERP   /   TİCARİ OPERASYONLAR",db.Akis.Ad);
        DockPanel.SetDock(bas,Dock.Top);root.Children.Add(bas);root.Children.Add(sekmeler);

        var listRoot=new DockPanel();
        var tools=new WrapPanel();
        tools.Children.Add(ara);
        durum.ItemsSource=new[]{"Tüm aşamalar"}.Concat(db.Akis.Adimlar).Append(db.Akis.Sonuc);durum.SelectedIndex=0;
        tools.Children.Add(durum);
        Dugme(tools,"Yeni kayıt",Yeni);
        Dugme(tools,"Seçileni düzenle",Duzenle);
        Dugme(tools,"Yenile",Yukle);
        Dugme(tools,"Excel’e aktar",Rapor);
        Dugme(tools,"Belge yazdır / PDF",BelgeYazdir);
        if(kod=="ECOM")
        {
            kanalFiltre.ItemsSource=new[]{"Tüm kanallar"}.Concat(PazaryeriKatalogu.Tum.Select(x=>x.Ad)).Append("Manuel / diğer").ToArray();
            kanalFiltre.SelectedIndex=0;kanalFiltre.MinWidth=150;kanalFiltre.ToolTip="Siparişleri pazaryerine göre ayır";
            kanalFiltre.SelectionChanged+=(_,_)=>Filtre();tools.Children.Add(kanalFiltre);
            Dugme(tools,"Mağaza bağlantıları",()=>new MagazaPenceresi(connection,user){Owner=this}.ShowDialog());
        }
        DockPanel.SetDock(tools,Dock.Top);listRoot.Children.Add(tools);
        DockPanel.SetDock(ozet,Dock.Top);listRoot.Children.Add(ozet);
        var actions=new WrapPanel{Margin=new Thickness(0,8,0,0)};
        actions.Children.Add(gecis);Dugme(actions,"Aşamayı değiştir",()=>{
            var row=Sec();var next=gecis.SelectedItem as string??throw new ArgumentException("Sonraki aşamayı seçin.");
            db.Ilerle((long)row["Id"],(byte[])row["Surum"],(string)row["Durum"],next);Yukle();
        });
        Dugme(actions,"İşlem geçmişi",Gecmis);
        DockPanel.SetDock(actions,Dock.Bottom);listRoot.Children.Add(actions);
        listRoot.Children.Add(liste);
        Tab("Kayıtlar",Tema170.Kart(listRoot,"Dosyalar ve iş akışı"));
        var form=new StackPanel{MaxWidth=850};
        tur.ItemsSource=db.Akis.Turler;para.ItemsSource=new[]{"TRY","USD","EUR","GBP"};
        var left=new StackPanel{Margin=new Thickness(0,0,18,0)};var right=new StackPanel();
        var cols=new System.Windows.Controls.Primitives.UniformGrid{Columns=2};cols.Children.Add(left);cols.Children.Add(right);form.Children.Add(cols);
        Alan(left,"Kayıt türü",tur);
        foreach(string ad in new[]{"Referans","Firma","Konu","Sorumlu"})Metin(left,ad);
        Alan(left,"Tarih",tarih);Alan(left,"Son tarih",vade);Metin(left,"Tutar");Alan(left,"Para birimi",para);
        foreach(string ad in db.Akis.Alanlar)Metin(right,ad);
        Metin(right,"Açıklama");
        kalemler.Columns.Add("Kod",typeof(string));kalemler.Columns.Add("Ürün",typeof(string));
        foreach(var a in new[]{"Miktar","Birim fiyat","İndirim %"})kalemler.Columns.Add(a,typeof(decimal)).DefaultValue=a=="Miktar"?1m:0m;
        kalemler.Columns.Add("Vergi %",typeof(decimal)).DefaultValue=0m;
        kalemler.Columns.Add("Birim",typeof(string)).DefaultValue="ADET";
        kalemGrid.ItemsSource=kalemler.DefaultView;
        form.Children.Add(new TextBlock{Text="Ürün ve hizmet kalemleri",FontSize=17,FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,14,0,4)});
        form.Children.Add(new TextBlock{Text="Kalem girildiğinde dosya tutarı miktar, birim fiyat ve indirimden hesaplanır.",TextWrapping=TextWrapping.Wrap});
        form.Children.Add(new TextBlock{Text="Vergi oranını belgenize göre girin. Bu kayıtlar stok/cari veya resmi e-fatura oluşturmaz; ilgili işlem belgesini ayrıca ilişkilendirin.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,8,0,8)});
        form.Children.Add(kalemGrid);Dugme(form,"Vergi dahil tutarı hesapla",()=>metin["Tutar"].Text=KalemOku().Sum(k=>k.Toplam()).ToString("0.00"));Dugme(form,"Kaydet",Kaydet);
        Tab("Kayıt kartı",Tema170.Kart(new ScrollViewer{Content=form,VerticalScrollBarVisibility=ScrollBarVisibility.Auto},"Dosya bilgileri"));
        var history=new DockPanel();var notes=new WrapPanel();notes.Children.Add(not);
        Dugme(notes,"İşlem notu ekle",()=>{db.NotEkle((long)Sec()["Id"],not.Text);not.Clear();Gecmis();});
        DockPanel.SetDock(notes,Dock.Top);history.Children.Add(notes);history.Children.Add(hareketler);
        Tab("Geçmiş",Tema170.Kart(history,"Tarihçe ve takip notları"));
        Tab("Aşama analizi",Tema170.Kart(analiz,analizSutunu+" · Aşama ve döviz kırılımı"));
        OdemeSekmesi();
        liste.AutoGeneratingColumn+=(_,e)=>{
            if(e.PropertyName is "Id" or "Surum" or "Detay")e.Cancel=true;
            e.Column.Header=e.PropertyName switch{"Baslik"=>"Konu","Referans"=>"Referans","Tur"=>"Tür","Vade"=>"Son tarih","Doviz"=>"Döviz","Aciklama"=>"Açıklama",_=>e.PropertyName};
            if(e.Column is DataGridTextColumn c && c.Binding is System.Windows.Data.Binding b && e.PropertyType==typeof(DateTime))b.StringFormat="dd.MM.yyyy";
        };
        liste.SelectionChanged+=(_,_)=>{gecis.ItemsSource=secili==null?Array.Empty<string>():db.Akis.Sonrakiler((string)secili["Durum"]);gecis.SelectedIndex=0;hareketler.ItemsSource=null;};
        ara.TextChanged+=(_,_)=>Filtre();durum.SelectionChanged+=(_,_)=>Filtre();
        Yeni();Yukle();sekmeler.SelectedIndex=0;
    }
    static DataGrid Tablo()=>new(){AutoGenerateColumns=true,IsReadOnly=true,CanUserAddRows=false,SelectionMode=DataGridSelectionMode.Single,HeadersVisibility=DataGridHeadersVisibility.Column,RowHeight=36,GridLinesVisibility=DataGridGridLinesVisibility.Horizontal};
    static void Dugme(Panel p,string ad,Action action)=>ErpModulPenceresi.B(p,ad,action);
    void Tab(string ad,UIElement child)=>sekmeler.Items.Add(new TabItem{Header=ad,Content=child});
    static void Alan(StackPanel p,string ad,Control input){p.Children.Add(new TextBlock{Text=ad,Margin=new Thickness(0,7,0,3)});input.MinHeight=32;p.Children.Add(input);}
    void Metin(StackPanel p,string ad){var t=new TextBox{MaxLength=ad=="Açıklama"?2000:ad=="Referans"?80:ad=="Sorumlu"?100:160};metin.Add(ad,t);Alan(p,ad,t);}
    DataRowView Sec()=>secili??throw new ArgumentException("Önce listeden bir kayıt seçin.");
    void Yeni()
    {
        duzenlenen=null;surum=null;kalemler.Clear();
        foreach(var t in metin.Values)t.Clear();
        metin["Tutar"].Text="0";tarih.SelectedDate=vade.SelectedDate=DateTime.Today;
        para.SelectedIndex=tur.SelectedIndex=0;sekmeler.SelectedIndex=1;
    }
    void Duzenle()
    {
        var r=Sec();duzenlenen=(long)r["Id"];surum=(byte[])r["Surum"];
        foreach(var (alan,kolon) in new[]{("Referans","Referans"),("Firma","Firma"),("Konu","Baslik"),("Sorumlu","Sorumlu"),("Tutar","Tutar"),("Açıklama","Aciklama")})metin[alan].Text=Convert.ToString(r[kolon]);
        var details=JsonSerializer.Deserialize<Dictionary<string,string>>((string)r["Detay"])??new();
        kalemler.Clear();if(details.TryGetValue("Kalemler",out var json))foreach(var k in JsonSerializer.Deserialize<TicaretKalem[]>(json)??[])kalemler.Rows.Add(k.Kod,k.Urun,k.Adet,k.Fiyat,k.Indirim,k.VergiOrani,k.Birim);
        foreach(string a in db.Akis.Alanlar)metin[a].Text=details.GetValueOrDefault(a,"");
        tur.SelectedItem=r["Tur"];para.SelectedItem=r["Doviz"];tarih.SelectedDate=(DateTime)r["Tarih"];vade.SelectedDate=(DateTime)r["Vade"];sekmeler.SelectedIndex=1;
    }
    TicaretKalem[] KalemOku()
    {
        if(!kalemGrid.CommitEdit(DataGridEditingUnit.Cell,true)||!kalemGrid.CommitEdit(DataGridEditingUnit.Row,true))
            throw new ArgumentException("Kalem girişini kontrol edin.");
        return kalemler.AsEnumerable().Select(r=>new TicaretKalem(Convert.ToString(r["Kod"])!,Convert.ToString(r["Ürün"])!,
            Convert.ToDecimal(r["Miktar"]),Convert.ToDecimal(r["Birim fiyat"]),Convert.ToDecimal(r["İndirim %"]),Convert.ToDecimal(r["Vergi %"]),Convert.ToString(r["Birim"])!)).ToArray();
    }
    void Kaydet()
    {
        if(!decimal.TryParse(metin["Tutar"].Text.Trim().Replace(',','.'),NumberStyles.AllowDecimalPoint,CultureInfo.InvariantCulture,out var tutar))throw new ArgumentException("Tutarı binlik ayırıcı kullanmadan girin.");
        string S(string a)=>metin[a].Text.Trim();
        var detay=db.Akis.Alanlar.ToDictionary(a=>a,S);var kalem=KalemOku();if(kalem.Length>0){tutar=kalem.Sum(k=>k.Toplam());detay["Kalemler"]=JsonSerializer.Serialize(kalem);}
        db.Kaydet(new(S("Referans"),(string)tur.SelectedItem,S("Firma"),S("Konu"),S("Sorumlu"),tarih.SelectedDate??throw new ArgumentException("Tarih gerekli."),vade.SelectedDate??throw new ArgumentException("Son tarih gerekli."),tutar,(string)para.SelectedItem,detay,S("Açıklama")),duzenlenen,surum);
        Yeni();Yukle();sekmeler.SelectedIndex=0;
    }
    void Yukle(){veri=db.Liste();Filtre();}
    void Filtre()
    {
        if(veri.Columns.Count==0)return;
        var rows=veri.AsEnumerable().Where(r=>(durum.SelectedIndex<=0 || (string)r["Durum"]==(string)durum.SelectedItem) && new[]{"Referans","Baslik","Firma","Sorumlu"}.Any(c=>((string)r[c]).Contains(ara.Text.Trim(),StringComparison.CurrentCultureIgnoreCase))).Where(KanalUygun).ToArray();
        liste.ItemsSource=(rows.Length==0?veri.Clone():rows.CopyToDataTable()).DefaultView;
        var rapor=new DataTable();rapor.Columns.Add("Aşama");rapor.Columns.Add("Döviz");rapor.Columns.Add("Dosya",typeof(int));rapor.Columns.Add("Toplam",typeof(decimal));rapor.Columns.Add(analizSutunu,typeof(decimal));
        foreach(var grup in rows.GroupBy(r=>(Asama:(string)r["Durum"],Doviz:(string)r["Doviz"])))
        {
            decimal hesap=grup.Sum(r=>db.AnalizTutari((decimal)r["Tutar"],JsonSerializer.Deserialize<Dictionary<string,string>>((string)r["Detay"])??new()));
            rapor.Rows.Add(grup.Key.Asama,grup.Key.Doviz,grup.Count(),grup.Sum(r=>(decimal)r["Tutar"]),hesap);
        }
        analiz.ItemsSource=rapor.DefaultView;
        var open=rows.Where(r=>(string)r["Durum"]!=db.Akis.Sonuc && (string)r["Durum"]!=db.Akis.Adimlar[^1]).ToArray();
        var tutar=open.GroupBy(r=>(string)r["Doviz"]).Select(g=>$"{g.Sum(r=>(decimal)r["Tutar"]):N2} {g.Key}");
        ozet.Text=$"{rows.Length} dosya     •     {open.Length} açık     •     {open.Count(r=>(DateTime)r["Vade"]<DateTime.Today)} geciken     •     Açık tutar  "+string.Join("   /   ",tutar);
    }
    bool KanalUygun(DataRow row)
    {
        if(kanalFiltre.SelectedIndex<=0)return true;
        var d=JsonSerializer.Deserialize<Dictionary<string,string>>((string)row["Detay"])??new();
        string value=d.GetValueOrDefault("Kanal / mağaza", "");
        string? provider=PazaryeriKatalogu.Tum.Select(x=>x.Ad).FirstOrDefault(x=>value.Equals(x,StringComparison.OrdinalIgnoreCase)||value.StartsWith(x+" / ",StringComparison.OrdinalIgnoreCase));
        return (string)kanalFiltre.SelectedItem==(provider??"Manuel / diğer");
    }
    void Gecmis(){hareketler.ItemsSource=db.Gecmis((long)Sec()["Id"]).DefaultView;sekmeler.SelectedIndex=2;}
    void Rapor()
    {
        var picker=new SaveFileDialog{Filter="Excel|*.xlsx",FileName=db.Akis.Ad+" raporu.xlsx"};
        if(picker.ShowDialog(this)!=true)return;
        var rapor=((DataView)liste.ItemsSource).ToTable();foreach(string col in new[]{"Id","Detay","Surum"})rapor.Columns.Remove(col);
        using var wb=new XLWorkbook();wb.Worksheets.Add(rapor,"Dosyalar");wb.Worksheets.Add(((DataView)analiz.ItemsSource).ToTable(),"Aşama analizi");wb.SaveAs(picker.FileName);
    }
}
