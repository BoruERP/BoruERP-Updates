using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace MiapaxERP.Desktop;

// Paylaşım paketleri yalnız adres taşır. SQL parolası, lisans ve cihaz erişim
// anahtarı burada bulunmaz; her çalışan kendi hesabıyla yetkilendirilir.
public sealed record KolayBaglantiProfili
{
    public string Rol { get; init; } = "Ana";
    public string SabitDisIp { get; init; } = "";
    public string MasaustuHttps { get; init; } = "";
    public string MobilHttps { get; init; } = "";
    static string Dosya => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MiapaxERP", "Baglanti", "kolay-baglanti.json");

    public static Uri Https(string input, bool gateway = false)
    {
        input = input.Trim();
        if (input.Length is < 1 or > 300 || input.Any(char.IsControl) || input.Contains('\\') ||
            !Uri.TryCreate(input, UriKind.Absolute, out var u) || u.Scheme != "https" ||
            u.AbsolutePath != "/" || u.UserInfo.Length != 0 || u.Query.Length != 0 || u.Fragment.Length != 0 ||
            u.HostNameType != UriHostNameType.Dns || u.IsLoopback || !u.IdnHost.Contains('.') ||
            !Regex.IsMatch(u.IdnHost, @"^(?=.{1,253}$)[a-zA-Z0-9](?:[a-zA-Z0-9.-]*[a-zA-Z0-9])$", RegexOptions.CultureInvariant) ||
            u.IdnHost.Split('.').Any(s => s.Length is < 1 or > 63 || s.StartsWith('-') || s.EndsWith('-')) ||
            u.Port is not (443 or 8443))
            throw new ArgumentException("Geçerli HTTPS alan adı girin. Örnek: https://erp.firmaniz.com (443 veya 8443).");
        return u;
    }
    public static string KisaAdres(Uri u) => "https://"+u.IdnHost+(u.IsDefaultPort?"":":"+u.Port);
    public static bool GenelIpv4(string input)
    {
        if (!IPAddress.TryParse(input, out var ip) || ip.AddressFamily != AddressFamily.InterNetwork || ip.ToString() != input) return false;
        var b = ip.GetAddressBytes();
        return !MobilYerelSunucu.OzelIp(input) && b[0] is not (0 or 127) && b[0] < 224 &&
            !(b[0] == 169 && b[1] == 254) && !(b[0] == 100 && b[1] >= 64 && b[1] <= 127) && !(b[0] == 198 && b[1] is 18 or 19) &&
            !(b[0]==192 && b[1]==0 && b[2] is 0 or 2) && !(b[0]==198 && b[1]==51 && b[2]==100) && !(b[0]==203 && b[1]==0 && b[2]==113);
    }
    public void Dogrula(bool tam = false)
    {
        if (Rol is not ("Ana" or "Yan" or "Mobil")) throw new ArgumentException("Ana sunucu, yan PC veya mobil seçin.");
        if (SabitDisIp.Length != 0 && !GenelIpv4(SabitDisIp)) throw new ArgumentException("Sabit dış IP genel bir IPv4 adresi olmalı. Yerel IP veya CGNAT adresi kullanmayın.");
        if (MasaustuHttps.Length > 0) _ = Https(MasaustuHttps, true);
        if (MobilHttps.Length > 0) _ = Https(MobilHttps);
        if (tam && Rol == "Yan" && MasaustuHttps.Length == 0) throw new ArgumentException("Sunucunun HTTPS adresini girin.");
        if (tam && Rol == "Mobil" && MobilHttps.Length == 0) throw new ArgumentException("Mobil HTTPS adresini girin.");
        if (tam && Rol == "Ana" && MasaustuHttps.Length == 0 && MobilHttps.Length == 0) throw new ArgumentException("En az bir HTTPS adresi girin.");
    }
    public string PaylasimKodu()
    {
        Dogrula();
        if (MasaustuHttps.Length == 0 && MobilHttps.Length == 0) throw new ArgumentException("Önce paylaşılacak sunucu adresini girin.");
        var safe = this with { Rol = "Yan", SabitDisIp = "", MasaustuHttps=MasaustuHttps.Length>0?KisaAdres(Https(MasaustuHttps,true)):"",MobilHttps=MobilHttps.Length>0?KisaAdres(Https(MobilHttps)):"" };
        return "MPX-CONNECT1:" + Convert.ToBase64String(JsonSerializer.SerializeToUtf8Bytes(safe)).TrimEnd('=').Replace('+','-').Replace('/','_');
    }
    public static KolayBaglantiProfili KoduOku(string text, string rol)
    {
        try
        {
            if (text.Length > 8192 || !text.StartsWith("MPX-CONNECT1:", StringComparison.Ordinal)) throw new ArgumentException();
            string b64 = text[13..].Replace('-','+').Replace('_','/');
            b64 = b64.PadRight((b64.Length + 3) / 4 * 4, '=');
            var p = JsonSerializer.Deserialize<KolayBaglantiProfili>(Convert.FromBase64String(b64)) ?? throw new ArgumentException();
            p = p with { Rol = rol, SabitDisIp = "" }; p.Dogrula(); return p;
        }
        catch (Exception e) when (e is FormatException or JsonException or ArgumentException) { throw new ArgumentException("Bağlantı kodu geçersiz. Ana sunucudaki bağlantı panelinden yeni kod alın."); }
    }
    public static KolayBaglantiProfili Oku()
    {
        if (!File.Exists(Dosya)) return new();
        var p = JsonSerializer.Deserialize<KolayBaglantiProfili>(File.ReadAllText(Dosya)) ?? throw new InvalidDataException("Bağlantı profili okunamadı."); p.Dogrula(); return p;
    }
    public void Kaydet()
    {
        Dogrula(true); Directory.CreateDirectory(Path.GetDirectoryName(Dosya)!);
        File.WriteAllText(Dosya + ".tmp", JsonSerializer.Serialize(this)); File.Move(Dosya + ".tmp", Dosya, true);
    }
}

public sealed record KolayKontrolSonucu(bool Basarili, string Mesaj);
public static class KolayBaglantiKontrolu
{
    public static async Task<KolayKontrolSonucu> Dns(string adres, string disIp, bool gateway, CancellationToken ct = default)
    {
        var u = KolayBaglantiProfili.Https(adres, gateway);
        if (disIp.Length > 0 && !KolayBaglantiProfili.GenelIpv4(disIp)) throw new ArgumentException("Sabit dış IP geçersiz.");
        try
        {
            var ips = await System.Net.Dns.GetHostAddressesAsync(u.IdnHost, ct).WaitAsync(TimeSpan.FromSeconds(10),ct);
            var v4 = ips.Where(i => i.AddressFamily == AddressFamily.InterNetwork).Select(i=>i.ToString()).ToArray();
            if (v4.Length == 0) return new(false, "Alan adının IPv4 kaydı bulunamadı. Alan adı panelindeki A kaydını kontrol edin.");
            if (disIp.Length > 0 && !v4.Contains(disIp)) return new(false, "Alan adı, girilen sabit dış IP'ye yönlenmiyor. A kaydını " + disIp + " olarak ayarlayın.");
            return new(true, "Alan adı çözümlendi" + (disIp.Length > 0 ? "; sabit dış IP ile eşleşti." : ".") + " Modem yönlendirmesi ayrıca kontrol edilir.");
        }
        catch (Exception e) when (e is SocketException or TimeoutException) { return new(false, "Alan adı bulunamadı veya DNS yanıt vermedi. A kaydı ve internet bağlantısını kontrol edin."); }
    }
    public static async Task<KolayKontrolSonucu> Https(string adres, bool gateway, CancellationToken ct = default)
    {
        var u = KolayBaglantiProfili.Https(adres,gateway);
        try
        {
            using var handler = new HttpClientHandler { AllowAutoRedirect=false, CheckCertificateRevocationList=true };
            using var client = new HttpClient(handler) { Timeout=TimeSpan.FromSeconds(12), MaxResponseContentBufferSize=4096 };
            using var response = await client.GetAsync(new Uri(u,gateway?"/api/desktop/v1/health":"/api/mobile/v2/health"),ct);
            if (!response.IsSuccessStatusCode) return new(false,"Sunucu yanıtı: HTTP " + (int)response.StatusCode + ". Sunucu ve HTTPS yönlendirmesini kontrol edin.");
            using var json = JsonDocument.Parse(await response.Content.ReadAsStringAsync(ct));
            if (!json.RootElement.TryGetProperty("service",out var s) || s.GetString()!=(gateway?"MiapaxERP.Server":"MiapaxERP.MobileServer") || !json.RootElement.TryGetProperty("api",out var api) || api.GetInt32()!=(gateway?1:2)) return new(false,"Adres açıldı fakat MiaPaxERP servisi doğrulanamadı. Yanlış web sitesi/port olabilir.");
            return new(true,"HTTPS ve MiaPaxERP servisi doğrulandı. Kullanıcı ve lisans erişimi, telefondaki eşleme sırasında doğrulanır.");
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested) { return new(false,"Sunucu zamanında yanıt vermedi. İnternet, modem yönlendirmesi ve çalışan servisi kontrol edin."); }
        catch (Exception e) when (e is HttpRequestException or AuthenticationException or SocketException or TimeoutException or IOException or JsonException or InvalidOperationException or FormatException)
        { return new(false,"Güvenli bağlantı doğrulanamadı. Alan adı, sertifika süresi ve port yönlendirmesini kontrol edin. Sertifika hatası atlanmadı."); }
    }
}
