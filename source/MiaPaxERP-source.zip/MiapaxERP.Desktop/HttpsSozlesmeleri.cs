using System.Data;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace MiapaxERP.Desktop;

public sealed record HttpsGiris(string Kullanici, string Parola);
public sealed record HttpsKullanici(int Id, string KullaniciAdi, string AdSoyad, string Roller);
public sealed record HttpsGirisYaniti(string Token, HttpsKullanici Kullanici, string[] Moduller, string Sektor, DateTimeOffset Bitis);
public sealed record HttpsCagri(string Islem, string Kapsam, JsonElement[] Argumanlar);
public static class HttpsJson
{
    public static readonly JsonSerializerOptions Ayarlar = Olustur();
    static JsonSerializerOptions Olustur()
    {
        var j = new JsonSerializerOptions(JsonSerializerDefaults.Web) { MaxDepth = 32, IncludeFields=true };
        j.Converters.Add(new TabloDonusturucu());j.Converters.Add(new SatirDonusturucu()); return j;
    }
    // Sadece sabit veri türleri kabul edilir; istemciden CLR tür adı yüklenmez.
    public static readonly IReadOnlyDictionary<string, Type> Turler = new Dictionary<string, Type>
    {
        ["text"]=typeof(string),["int"]=typeof(int),["long"]=typeof(long),["decimal"]=typeof(decimal),
        ["bool"]=typeof(bool),["date"]=typeof(DateTime),["offset"]=typeof(DateTimeOffset),["guid"]=typeof(Guid),
        ["bytes"]=typeof(byte[]),["short"]=typeof(short),["byte"]=typeof(byte),["double"]=typeof(double),["float"]=typeof(float)
    };
    sealed class SatirDonusturucu : JsonConverter<DataRow>
    {
        public override DataRow Read(ref Utf8JsonReader reader,Type type,JsonSerializerOptions options)
        {var table=JsonSerializer.Deserialize<DataTable>(ref reader,options)??throw new JsonException();if(table.Rows.Count!=1)throw new JsonException("Tek kayıt bekleniyor.");return table.Rows[0];}
        public override void Write(Utf8JsonWriter writer,DataRow row,JsonSerializerOptions options)
        {var table=row.Table.Clone();table.ImportRow(row);JsonSerializer.Serialize(writer,table,options);}
    }
    sealed class TabloDonusturucu : JsonConverter<DataTable>
    {
        public override DataTable Read(ref Utf8JsonReader reader, Type type, JsonSerializerOptions options)
        {
            using var doc=JsonDocument.ParseValue(ref reader);var root=doc.RootElement;var t=new DataTable();
            foreach(var c in root.GetProperty("columns").EnumerateArray())
            {
                if(t.Columns.Count>=256||!Turler.TryGetValue(c.GetProperty("type").GetString()!,out var ct))throw new JsonException("Tablo türü desteklenmiyor.");
                t.Columns.Add(c.GetProperty("name").GetString()!,ct);
            }
            foreach(var row in root.GetProperty("rows").EnumerateArray())
            {
                if(t.Rows.Count>=100000||row.GetArrayLength()!=t.Columns.Count)throw new JsonException();
                var values=row.EnumerateArray().Select((v,i)=>v.ValueKind==JsonValueKind.Null?DBNull.Value:v.Deserialize(t.Columns[i].DataType,options)??DBNull.Value).ToArray();
                t.Rows.Add(values);
            }
            return t;
        }
        public override void Write(Utf8JsonWriter w, DataTable t, JsonSerializerOptions options)
        {
            w.WriteStartObject();w.WriteStartArray("columns");
            foreach(DataColumn c in t.Columns)
            {
                var code=Turler.SingleOrDefault(p=>p.Value==c.DataType).Key??throw new JsonException("Tablo türü desteklenmiyor.");
                w.WriteStartObject();w.WriteString("name",c.ColumnName);w.WriteString("type",code);w.WriteEndObject();
            }
            w.WriteEndArray();w.WriteStartArray("rows");
            foreach(DataRow r in t.Rows){w.WriteStartArray();foreach(var v in r.ItemArray){if(v is null or DBNull)w.WriteNullValue();else JsonSerializer.Serialize(w,v,v.GetType(),options);}w.WriteEndArray();}
            w.WriteEndArray();w.WriteEndObject();
        }
    }
}
