
using System;
using System.Security.Cryptography;
using System.Text;

namespace MiapaxERP.Desktop
{
    public static class LisansImzaDogrulayici
    {
        // RSA-SHA256 / PSS dijital imza doğrulaması.
        // Özel anahtar yalnızca lisans sunucusunda tutulmalıdır.
        // Masaüstü uygulamasına sadece açık anahtar verilir.

        public static bool ImzayiDogrula(
            string lisansBelgesi,
            string imzaBase64,
            string acikAnahtarPem)
        {
            if (string.IsNullOrWhiteSpace(lisansBelgesi) ||
                string.IsNullOrWhiteSpace(imzaBase64) ||
                string.IsNullOrWhiteSpace(acikAnahtarPem))
            {
                return false;
            }

            try
            {
                byte[] belgeVerisi =
                    Encoding.UTF8.GetBytes(lisansBelgesi);

                byte[] imzaVerisi =
                    Convert.FromBase64String(imzaBase64);

                using RSA rsa = RSA.Create();

                rsa.ImportFromPem(acikAnahtarPem);

                return rsa.VerifyData(
                    belgeVerisi,
                    imzaVerisi,
                    HashAlgorithmName.SHA256,
                    RSASignaturePadding.Pss);
            }
            catch (Exception hata) when (
                hata is FormatException ||
                hata is CryptographicException ||
                hata is ArgumentException)
            {
                return false;
            }
        }
    }
}
