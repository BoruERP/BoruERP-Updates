using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shell;

namespace MiapaxERP.Desktop;

// Tüm mevcut çağrılar aynı WPF sonuçlarını kullanır; kapatmak asla onay sayılmaz.
public static class ModernMesaj
{
    public static MessageBoxResult Show(string message, string caption = "MiapaxERP", MessageBoxButton buttons = MessageBoxButton.OK,
        MessageBoxImage icon = MessageBoxImage.None, MessageBoxResult defaultResult = MessageBoxResult.None) =>
        Show(null, message, caption, buttons, icon, defaultResult);

    public static MessageBoxResult Show(Window? owner, string message, string caption = "MiapaxERP", MessageBoxButton buttons = MessageBoxButton.OK,
        MessageBoxImage icon = MessageBoxImage.None, MessageBoxResult defaultResult = MessageBoxResult.None)
    {
        caption = caption.Replace("BoruERP", "MiapaxERP");
        var dispatcher = Application.Current?.Dispatcher;
        if (dispatcher != null && !dispatcher.CheckAccess())
            return dispatcher.Invoke(() => Show(owner, message, caption, buttons, icon, defaultResult));
        owner ??= Application.Current?.Windows.OfType<Window>().LastOrDefault(w => w.IsActive && w.IsVisible);
        var dialog = new ModernMesajPenceresi(message, caption, buttons, icon, defaultResult);
        if (owner?.IsVisible == true) dialog.Owner = owner;
        dialog.ShowDialog();
        return dialog.Sonuc;
    }
}

public sealed class ModernMesajPenceresi : Window
{
    public MessageBoxResult Sonuc { get; private set; }
    public ModernMesajPenceresi(string message, string caption, MessageBoxButton buttons, MessageBoxImage icon, MessageBoxResult defaultResult)
    {
        Title = caption; Width = 540; SizeToContent = SizeToContent.Height;
        MaxHeight = Math.Max(300, SystemParameters.WorkArea.Height - 60);
        MaxWidth = Math.Max(300, SystemParameters.WorkArea.Width - 40);
        WindowStartupLocation = WindowStartupLocation.CenterOwner; ResizeMode = ResizeMode.NoResize;
        ShowInTaskbar = false; WindowStyle = WindowStyle.None;
        WindowChrome.SetWindowChrome(this, new WindowChrome { CaptionHeight = 0, CornerRadius = new CornerRadius(16), GlassFrameThickness = new Thickness(0), ResizeBorderThickness = new Thickness(0) });
        SetResourceReference(BackgroundProperty, "ErpKart"); SetResourceReference(ForegroundProperty, "ErpMetin");
        SetResourceReference(FontFamilyProperty, "ErpFont");
        var options = buttons switch {
            MessageBoxButton.YesNo => new[] { MessageBoxResult.No, MessageBoxResult.Yes },
            MessageBoxButton.YesNoCancel => new[] { MessageBoxResult.Cancel, MessageBoxResult.No, MessageBoxResult.Yes },
            MessageBoxButton.OKCancel => new[] { MessageBoxResult.Cancel, MessageBoxResult.OK },
            _ => new[] { MessageBoxResult.OK }
        };
        Sonuc = options.Contains(MessageBoxResult.Cancel) ? MessageBoxResult.Cancel : options.Contains(MessageBoxResult.No) ? MessageBoxResult.No : MessageBoxResult.OK;
        var preferred = options.Contains(defaultResult) ? defaultResult : Sonuc;
        var root = new DockPanel { LastChildFill = true, Margin = new Thickness(28) }; Content = root;
        var heading = new DockPanel { Margin = new Thickness(0, 0, 0, 22) };
        heading.MouseLeftButtonDown += (_, e) => { if (e.ButtonState == MouseButtonState.Pressed) DragMove(); };
        var close = new Button { Content = "✕", Width = 36, Height = 32, ToolTip = "Kapat", Padding = new Thickness(0) };
        close.Click += (_, _) => Close(); DockPanel.SetDock(close, Dock.Right); heading.Children.Add(close);
        var brand = new TextBlock { Text = "MIAPAX ERP  /  " + (icon == MessageBoxImage.Error ? "İŞLEM HATASI" : icon == MessageBoxImage.Warning ? "DİKKAT" : buttons == MessageBoxButton.OK ? "BİLGİ" : "ONAY"), FontSize = 11, FontWeight = FontWeights.SemiBold, VerticalAlignment = VerticalAlignment.Center };
        brand.SetResourceReference(TextBlock.ForegroundProperty, "ErpVurgu"); heading.Children.Add(brand);
        DockPanel.SetDock(heading, Dock.Top); root.Children.Add(heading);
        var actions = new WrapPanel { HorizontalAlignment = System.Windows.HorizontalAlignment.Right, Margin = new Thickness(0, 24, 0, 0) };
        foreach (var result in options)
        {
            var b = new Button { Content = result switch { MessageBoxResult.Yes => "Evet", MessageBoxResult.No => "Hayır", MessageBoxResult.Cancel => "Vazgeç", _ => "Tamam" }, MinWidth = 100, Padding = new Thickness(18, 10, 18, 10), Margin = new Thickness(8, 0, 0, 0), IsDefault = result == preferred };
            if (result is MessageBoxResult.OK or MessageBoxResult.Yes) { b.SetResourceReference(BackgroundProperty, "ErpVurgu"); b.Foreground = Brushes.White; }
            b.Click += (_, _) => { Sonuc = result; Close(); }; actions.Children.Add(b);
            if (result == preferred) Loaded += (_, _) => b.Focus();
        }
        DockPanel.SetDock(actions, Dock.Bottom); root.Children.Add(actions);
        var body = new StackPanel();
        body.Children.Add(new TextBlock { Text = caption, FontSize = 24, FontWeight = FontWeights.SemiBold, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0,0,0,14) });
        body.Children.Add(new TextBlock { Text = message, FontSize = 15, LineHeight = 24, TextWrapping = TextWrapping.Wrap });
        root.Children.Add(new ScrollViewer { Content = body, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, MaxHeight = Math.Max(160, SystemParameters.WorkArea.Height - 260) });
        PreviewKeyDown += (_, e) => { if (e.Key == Key.Escape) { Close(); e.Handled = true; } };
    }
}

