using System.Data;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

public sealed record ErpOkumaDegeri(string Ad,SqlDbType Tip,int Boyut,byte Duyarlik,byte Olcek,string Tur,JsonElement Deger);
public sealed record ErpOkumaIstegi(string Sorgu,ErpOkumaDegeri[] Degerler);
public sealed record ErpOkumaYaniti(DataTable[] Tablolar);
public sealed record ErpOkumaTanimi(string Sql,string[] Yetkiler,string Kaynak);
public sealed partial class ErpOkumaServisi(string connection,int user)
{
    public static string Kimlik(string sql)=>Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(sql.Replace("\r\n","\n").Trim())));
    public static string[] Sorgular=>sorgular.Keys.Order().ToArray();
    internal static bool KimlikParametresi(string sql,string parameter)
    {
        string name=System.Text.RegularExpressions.Regex.Escape(parameter);
        bool owner=System.Text.RegularExpressions.Regex.IsMatch(sql,@"\b(?:Alici|Sahip)?KullaniciId\s*=\s*"+name+@"\b|"+name+@"\s*=\s*(?:[A-Za-z_]\w*\.)?(?:Alici|Sahip)?KullaniciId\b",System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        bool ownRoleCheck=sql.Contains("Kullanicilar",StringComparison.OrdinalIgnoreCase)&&sql.Contains("KullaniciRolAtamalari",StringComparison.OrdinalIgnoreCase)&&System.Text.RegularExpressions.Regex.IsMatch(sql,@"\bk\.Id\s*=\s*"+name+@"\b",System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        return owner||ownRoleCheck;
    }
    public ErpOkumaYaniti Oku(ErpOkumaIstegi input)
    {
        if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<ErpOkumaYaniti>(connection,"ErpOkumaServisi.Oku","",[input]);
        if(!sorgular.TryGetValue(input.Sorgu,out var definition))throw new ArgumentException("Bu okuma işlemi sunucuda tanımlı değil.");
        if(input.Degerler is null||input.Degerler.Length>512)throw new ArgumentException();
        var access=new ErpModulServisi(connection,user);using var c=access.Ac();
        foreach(string permission in definition.Yetkiler)access.Yetki(c,null,permission);
        using var q=new SqlCommand(definition.Sql,c){CommandTimeout=60};
        foreach(var v in input.Degerler)
        {
            if(v.Ad is null||!System.Text.RegularExpressions.Regex.IsMatch(v.Ad,"^@[A-Za-z_][A-Za-z0-9_]{0,79}$")||!Enum.IsDefined(v.Tip)||v.Tip is SqlDbType.Structured or SqlDbType.Udt||v.Boyut < -1||v.Boyut>16*1024*1024||v.Duyarlik>38||v.Olcek>38)throw new ArgumentException("Alan türü geçersiz.");
            if(q.Parameters.Contains(v.Ad))throw new ArgumentException("Alan tekrarlanmış.");
            object value=DBNull.Value;
            if(v.Deger.ValueKind!=JsonValueKind.Null)
            {if(!HttpsJson.Turler.TryGetValue(v.Tur,out var type))throw new ArgumentException("Alan türü desteklenmiyor.");value=v.Deger.Deserialize(type,HttpsJson.Ayarlar)??DBNull.Value;}
            var p=q.Parameters.Add(v.Ad,v.Tip);if(v.Boyut!=0)p.Size=v.Boyut;p.Precision=v.Duyarlik;p.Scale=v.Olcek;p.Value=value;
        }
        // Kimlik ve takvim kapsamı istemciden kabul edilmez.
        bool own=definition.Sql.Contains("vw_KullaniciEtkinYetkileri",StringComparison.OrdinalIgnoreCase)||definition.Sql.Contains("dbo.IsTakvimi",StringComparison.OrdinalIgnoreCase)||definition.Sql.Contains("dbo.Bildirimler",StringComparison.OrdinalIgnoreCase)||definition.Sql.Contains("KullaniciRolAtamalari",StringComparison.OrdinalIgnoreCase)||definition.Sql.Contains("KullaniciGorunumAyarlari",StringComparison.OrdinalIgnoreCase);
        if(own)
        {
            bool admin=false;try{access.Yetki(c,null,"USERS.MANAGE");admin=true;}catch(UnauthorizedAccessException){}
            foreach(SqlParameter p in q.Parameters)
            {
                if(p.ParameterName.Equals("@Tum",StringComparison.OrdinalIgnoreCase))
                {bool all=false;try{access.Yetki(c,null,"CALENDAR.ALL");all=true;}catch(UnauthorizedAccessException){}p.Value=all;}
                if(!admin&&KimlikParametresi(definition.Sql,p.ParameterName))p.Value=user;
            }
        }
        using var reader=q.ExecuteReader();var tables=new List<DataTable>();
        while(!reader.IsClosed)
        {
            var table=new DataTable();table.Load(reader);
            foreach(DataColumn column in table.Columns.Cast<DataColumn>().ToArray())
                if(System.Text.RegularExpressions.Regex.IsMatch(column.ColumnName,@"(?i)sifre|parola|password|secret|apikey|token"))table.Columns.Remove(column);
            if(table.Rows.Count>100000)throw new InvalidOperationException("Liste çok büyük. Filtre uygulayın.");
            tables.Add(table);if(tables.Count>16)throw new InvalidOperationException("Çok fazla sonuç.");
        }
        return new(tables.ToArray());
    }
}
