using System;
using System.Threading.Tasks;
using System.Windows;

namespace MiapaxERP.Desktop
{
    public partial class GirisPenceresi
    {
        private async Task OtomatikGirisDeneAsync()
        {
            BtnGiris.IsEnabled = false;
            try
            {
                var oturum = await Task.Run(() => BeniHatirlaServisi.Dogrula(baglantiAdresi));
                if (pencereKapandi || oturum == null) return;
                Oturum = oturum;
                DialogResult = true;
            }
            catch (Exception ex)
            {
                if (!pencereKapandi)
                    TxtGirisDurum.Text = "Hatırlanan oturum açılamadı; şifrenizle giriş yapabilirsiniz. " + ex.Message;
            }
            finally { if (!pencereKapandi) BtnGiris.IsEnabled = true; }
        }

        private async Task HatirlananOturumuKaydetAsync(GirisKontrolSonucu sonuc)
        {
            try { await Task.Run(() => BeniHatirlaServisi.Kaydet(baglantiAdresi, sonuc.Id)); }
            catch (Exception ex)
            {
                MessageBox.Show("Giriş başarılı fakat Beni Hatırla kaydedilemedi: " + ex.Message,
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}
