using System.Net;
using System.Net.Sockets;
using System.Text.RegularExpressions;
namespace MiapaxERP.Desktop;

public static class UzakCalismaGuvenligi
{
    public static bool OzelIpv4(string host)
    {
        var p=host.Split('.');if(p.Length!=4)return false;var b=new byte[4];
        for(int i=0;i<4;i++)if(!Regex.IsMatch(p[i],"^(0|[1-9][0-9]{0,2})$")||!byte.TryParse(p[i],out b[i]))return false;
        return b[0]==10||b[0]==172&&b[1]>=16&&b[1]<=31||b[0]==192&&b[1]==168;
    }
    public static (string Ip,int Port) VpnSqlHedefi(string value)
    {
        var s=value.Trim();if(s.StartsWith("tcp:",StringComparison.OrdinalIgnoreCase))s=s[4..];
        var parts=s.Split(',');if(parts.Length!=2||!OzelIpv4(parts[0])||!Regex.IsMatch(parts[1],"^[0-9]{1,5}$")||!int.TryParse(parts[1],out int port)||port<1||port>65535)
            throw new ArgumentException("VPN bağlantısında fabrikanın özel IPv4 adresini ve sabit SQL TCP portunu girin. Örnek: 10.80.0.1,1433. Genel internet IP'si veya SQL instance keşfi kullanılmaz.");
        return(parts[0],port);
    }
    public static string SertifikaAdi(string value)
    {
        if(value.Length==0)return "";
        if(value.Length>253||Uri.CheckHostName(value)!=UriHostNameType.Dns||value.Split('.').Any(p=>p.Length==0||p.Length>63||!Regex.IsMatch(p,"^[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?$")))throw new ArgumentException("Sertifikadaki SQL sunucu adını girin; joker karakter, adres yolu veya kullanıcı bilgisi kullanmayın.");
        return value;
    }
    public static async Task<string> TcpDene(string ip,int port,CancellationToken token=default)
    {
        if(!OzelIpv4(ip)||port<1||port>65535)throw new ArgumentException("Özel ağ hedefi geçersiz.");
        using var timeout=CancellationTokenSource.CreateLinkedTokenSource(token);timeout.CancelAfter(TimeSpan.FromSeconds(5));
        using var tcp=new TcpClient(AddressFamily.InterNetwork);try{await tcp.ConnectAsync(ip,port,timeout.Token);return "TCP erişimi var. Bu sonuç SQL kimliğini, TLS sertifikasını veya ERP yetkilerini doğrulamaz; ayrıca SQL bağlantı testini çalıştırın.";}
        catch(OperationCanceledException)when(!token.IsCancellationRequested){return "Hedefe ulaşılamadı (zaman aşımı). VPN, fabrika ağı ve güvenlik duvarını kontrol edin.";}
        catch(SocketException){return "Hedef bağlantıyı kabul etmedi veya erişilemiyor. VPN ve ilgili servisi kontrol edin.";}
    }
}
