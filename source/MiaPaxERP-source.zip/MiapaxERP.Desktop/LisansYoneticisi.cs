using System;

namespace MiapaxERP.Desktop
{
    public enum LisansDurumu
    {
        Etkin,
        DogrulamaGerekli,
        SuresiDolmus,
        AskiyaAlinmis
    }

    public sealed class LisansSonucu
    {
        public LisansDurumu Durum { get; }
        public string Mesaj { get; }
        public TimeSpan KalanCevrimdisiSure { get; }
        public bool IslemYapilabilir => Durum == LisansDurumu.Etkin;

        public LisansSonucu(
            LisansDurumu durum,
            string mesaj,
            TimeSpan kalanCevrimdisiSure)
        {
            Durum = durum;
            Mesaj = mesaj;
            KalanCevrimdisiSure = kalanCevrimdisiSure;
        }
    }

    public static class LisansYoneticisi
    {
        public static readonly TimeSpan CevrimdisiKullanimSuresi =
            TimeSpan.FromDays(7);

        // Hazirlik asamasi: Bu metot sadece verilen bilgileri degerlendirir.
        // LisansKaydi icindeki degerler henuz sunucudan dogrulanmamistir.
        // Bu sonucu gercek lisans yetkilendirmesi icin kullanmayin.
        public static LisansSonucu KaydiDegerlendir(
            LisansKaydi? kayit,
            DateTimeOffset simdiUtc)
        {
            if (kayit == null)
            {
                return new LisansSonucu(
                    LisansDurumu.DogrulamaGerekli,
                    "Lisans kaydi bulunamadi. Sunucu dogrulamasi gerekli.",
                    TimeSpan.Zero);
            }

            if (string.IsNullOrWhiteSpace(kayit.ImzaliLisansBelgesi))
            {
                return new LisansSonucu(
                    LisansDurumu.DogrulamaGerekli,
                    "Imzali lisans belgesi bulunamadi. Sunucu dogrulamasi gerekli.",
                    TimeSpan.Zero);
            }

            // Imzanin varligi imzanin gecerli oldugu anlamina gelmez.
            // Gercek imza dogrulamasi eklenene kadar lisans etkin sayilmaz.
            return new LisansSonucu(
                LisansDurumu.DogrulamaGerekli,
                "Lisans belgesi henuz kriptografik olarak dogrulanmadi.",
                TimeSpan.Zero);
        }

        // Sadece sure hesaplamasini denemek icin kullanilan mevcut metot.
        // Parametrelerin gercekligi bu metotta kontrol edilmez.
        public static LisansSonucu DurumuHesapla(
            DateTime? sonBasariliDogrulamaUtc,
            DateTime simdiUtc,
            bool lisansAskida = false,
            DateTime? lisansBitisUtc = null)
        {
            if (lisansAskida)
            {
                return new LisansSonucu(
                    LisansDurumu.AskiyaAlinmis,
                    "Lisans askiya alinmis. Yoneticiyle iletisime gecin.",
                    TimeSpan.Zero);
            }

            if (lisansBitisUtc.HasValue && simdiUtc >= lisansBitisUtc.Value)
            {
                return new LisansSonucu(
                    LisansDurumu.SuresiDolmus,
                    "Lisans suresi dolmus. Yeniden etkinlestirme gerekli.",
                    TimeSpan.Zero);
            }

            if (!sonBasariliDogrulamaUtc.HasValue ||
                sonBasariliDogrulamaUtc.Value > simdiUtc)
            {
                return new LisansSonucu(
                    LisansDurumu.DogrulamaGerekli,
                    "Internet uzerinden lisans dogrulamasi gerekli.",
                    TimeSpan.Zero);
            }

            TimeSpan gecenSure = simdiUtc - sonBasariliDogrulamaUtc.Value;
            TimeSpan kalanSure = CevrimdisiKullanimSuresi - gecenSure;

            if (kalanSure <= TimeSpan.Zero)
            {
                return new LisansSonucu(
                    LisansDurumu.DogrulamaGerekli,
                    "7 gunluk cevrimdisi sure doldu. Lisansi dogrulayin.",
                    TimeSpan.Zero);
            }

            return new LisansSonucu(
                LisansDurumu.Etkin,
                "Sure hesabina gore cevrimdisi kullanim devam edebilir. " +
                "Bu sonuc tek basina lisans dogrulamasi degildir.",
                kalanSure);
        }
    }
}
