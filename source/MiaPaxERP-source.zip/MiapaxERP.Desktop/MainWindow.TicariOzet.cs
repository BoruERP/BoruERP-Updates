using SqlConnection = MiapaxERP.Desktop.ErpSqlConnection;
using SqlCommand = MiapaxERP.Desktop.ErpSqlCommand;
using SqlTransaction = MiapaxERP.Desktop.ErpSqlTransaction;
using SqlDataReader = MiapaxERP.Desktop.ErpSqlReader;
using SqlDataAdapter = MiapaxERP.Desktop.ErpSqlDataAdapter;
using System;
using System.Data;
using System.Threading.Tasks;
using System.Windows;
using Microsoft.Data.SqlClient;

namespace MiapaxERP.Desktop
{
    public partial class MainWindow
    {
        private bool ticariOzetYukleniyor;

        private void TicariPencereAc(int bolum, string yetki)
        {
            if (DemoModu)
            {
                MessageBox.Show("Ticari modüller şu an SQL Server modunda çalışır.", "MiapaxERP");
                return;
            }
            if (aktifKullanici == null ||
                !(StokYetkisiVar(yetki) || (bolum == 1 && StokYetkisiVar("CHECKNOTE.VIEW"))))
            {
                MessageBox.Show("Bu bölüm için yetkiniz bulunmuyor: " + yetki,
                    "MiapaxERP | Yetki", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            MuhasebeBolumAc(bolum switch { 0 => "cari", 1 => "kasa", 2 => "rapor", _ => "ayar" });
        }

        private sealed class TicariOzetVerileri
        {
            public DataTable Cariler { get; set; } = new DataTable();
            public DataTable Bugun { get; set; } = new DataTable();
            public DataTable Yaklasan { get; set; } = new DataTable();
            public DataTable Piyasa { get; set; } = new DataTable();
            public string PiyasaDurum { get; set; } = "";
            public string CariDurum { get; set; } = "";
            public string EvrakDurum { get; set; } = "";
            public string OdemeDurum { get; set; } = "";
        }

        private async Task AnaSayfaTicariYukleAsync()
        {
            if (ticariOzetYukleniyor || AnaSayfaIcerik.Visibility != Visibility.Visible) return;
            int? user = aktifKullanici?.KullaniciId;
            AnaBorcluCarilerTablosu.ItemsSource = null;
            AnaBugunEvrakTablosu.ItemsSource = null;
            AnaYaklasanOdemeTablosu.ItemsSource = null;
            AnaPiyasaFiyatTablosu.ItemsSource = null;
            if (!user.HasValue || DemoModu)
            {
                TxtAnaCariDurum.Text = "Veriler için oturum açın.";
                TxtAnaEvrakDurum.Text = "Veriler için oturum açın.";
                TxtAnaOdemeDurum.Text = "Veriler için oturum açın.";
                TxtAnaPiyasaDurum.Text = "Veriler için oturum açın.";
                return;
            }
            ticariOzetYukleniyor = true;
            try
            {
                var summary = await Task.Run(() =>
                {
                    var result = new TicariOzetVerileri();
                    using var con = new SqlConnection(baglantiAdresi);
                    con.Open();
                    using (var exists = new SqlCommand(@"SELECT CASE WHEN OBJECT_ID(N'dbo.CariKartlari',N'U') IS NOT NULL
AND OBJECT_ID(N'dbo.CariHareketleri',N'U') IS NOT NULL AND OBJECT_ID(N'dbo.CekSenetler',N'U') IS NOT NULL
AND OBJECT_ID(N'dbo.PlanliOdemeler',N'U') IS NOT NULL THEN 1 ELSE 0 END;", con))
                    {
                        if (Convert.ToInt32(exists.ExecuteScalar()) != 1)
                        {
                            result.CariDurum = result.EvrakDurum = result.OdemeDurum = "Ticari modül SQL kurulumu bekleniyor.";
                            return result;
                        }
                    }
                    bool cariPermission = StokSqlYetkisiVar(con, null, user.Value, "CUSTOMER.VIEW");
                    bool checkPermission = StokSqlYetkisiVar(con, null, user.Value, "CHECKNOTE.VIEW");
                    bool financePermission = StokSqlYetkisiVar(con, null, user.Value, "FINANCE.VIEW");
                    if (cariPermission)
                    {
                        using var cmd = new SqlCommand(@"SELECT TOP (5) c.Unvan,
CAST(SUM(CASE h.HareketTipi WHEN N'Borç' THEN h.Tutar ELSE -h.Tutar END) AS decimal(18,2)) AS BakiyeTRY
FROM dbo.CariKartlari c JOIN dbo.CariHareketleri h ON h.CariId=c.Id
WHERE c.Aktif=1 GROUP BY c.Id,c.Unvan
HAVING SUM(CASE h.HareketTipi WHEN N'Borç' THEN h.Tutar ELSE -h.Tutar END)>0
ORDER BY BakiyeTRY DESC;", con);
                        using var reader = cmd.ExecuteReader(); result.Cariler.Load(reader);
                        result.CariDurum = result.Cariler.Rows.Count == 0 ? "Borçlu cari bulunamadı." : "Bakiyesi pozitif en yüksek cariler.";
                    }
                    else result.CariDurum = "Cari görüntüleme yetkiniz yok.";
                    if (checkPermission)
                    {
                        using (var cmd = new SqlCommand(@"SELECT TOP(5) e.EvrakNo,e.Yon,
CONVERT(nvarchar(30),e.Tutar)+N' '+e.ParaBirimi AS TutarMetin,
ISNULL(c.Unvan,N'-') AS Unvan FROM dbo.CekSenetler e
LEFT JOIN dbo.CariKartlari c ON c.Id=e.CariId
WHERE e.VadeTarihi=CONVERT(date,GETDATE()) AND e.Durum=N'Bekliyor'
ORDER BY e.Id DESC;", con))
                        using (var reader = cmd.ExecuteReader()) result.Bugun.Load(reader);
                        result.EvrakDurum = result.Bugun.Rows.Count == 0 ? "Bugün vadesi gelen bekleyen evrak yok." : "Bugünkü bekleyen çek/senetler.";
                    }
                    else result.EvrakDurum = "Çek/senet görüntüleme yetkiniz yok.";
                    if (checkPermission || financePermission)
                    {
                        using var cmd = new SqlCommand(@"SELECT TOP(5) t.VadeTarihi,t.Unvan,t.TutarMetin FROM (
SELECT p.VadeTarihi,p.Baslik AS Unvan,CONVERT(nvarchar(30),p.Tutar)+N' '+p.ParaBirimi AS TutarMetin
FROM dbo.PlanliOdemeler p
WHERE @fin=1 AND p.Durum=N'Bekliyor' AND p.VadeTarihi BETWEEN CONVERT(date,GETDATE()) AND DATEADD(day,7,CONVERT(date,GETDATE()))
UNION ALL
SELECT e.VadeTarihi,ISNULL(c.Unvan,N'Verilen Çek/Senet') AS Unvan,
CONVERT(nvarchar(30),e.Tutar)+N' '+e.ParaBirimi AS TutarMetin
FROM dbo.CekSenetler e LEFT JOIN dbo.CariKartlari c ON c.Id=e.CariId
WHERE @cek=1 AND e.Yon=N'Verilen' AND e.Durum=N'Bekliyor'
AND e.VadeTarihi BETWEEN CONVERT(date,GETDATE()) AND DATEADD(day,7,CONVERT(date,GETDATE()))
) t ORDER BY t.VadeTarihi,t.Unvan;", con);
                        cmd.Parameters.Add("@fin", SqlDbType.Bit).Value = financePermission;
                        cmd.Parameters.Add("@cek", SqlDbType.Bit).Value = checkPermission;
                        using var reader = cmd.ExecuteReader(); result.Yaklasan.Load(reader);
                        result.OdemeDurum = result.Yaklasan.Rows.Count == 0 ? "Önümüzdeki 7 günde bekleyen ödeme yok." : "7 gün içinde bekleyen planlı ve evrak ödemeleri.";
                    }
                    else result.OdemeDurum = "Finans/çek-senet görüntüleme yetkiniz yok.";
                    // Piyasa fiyatları SQL'den değil, doğrudan kamuya açık web sayfalarından alınır.
                    bool piyasaYetkisi = (LisansOturumu.Gecerli?.Sector??gorunum.Sektor)=="BORU" && (StokSqlYetkisiVar(con, null, user.Value, "MARKET.VIEW") ||
                                         StokSqlYetkisiVar(con, null, user.Value, "STOCK.VIEW"));
                    result.PiyasaDurum = piyasaYetkisi ? "İnternet kaynakları kontrol ediliyor..." :
                        "Piyasa fiyatlarını görüntüleme yetkiniz yok.";
                    return result;
                });
                if (summary.PiyasaDurum == "İnternet kaynakları kontrol ediliyor...")
                {
                    try
                    {
                        var internet = await PiyasaInternetServisi.GetirAsync();
                        summary.Piyasa = internet.Tablo;
                        summary.PiyasaDurum = internet.Durum;
                    }
                    catch (Exception webEx)
                    {
                        summary.PiyasaDurum = "İnternet fiyatları alınamadı: " + webEx.Message;
                    }
                }
                if (aktifKullanici?.KullaniciId != user) return;
                AnaBorcluCarilerTablosu.ItemsSource = summary.Cariler.DefaultView;
                AnaBugunEvrakTablosu.ItemsSource = summary.Bugun.DefaultView;
                AnaYaklasanOdemeTablosu.ItemsSource = summary.Yaklasan.DefaultView;
                AnaPiyasaFiyatTablosu.ItemsSource = summary.Piyasa.DefaultView;
                TxtAnaPiyasaDurum.Text = summary.PiyasaDurum;
                TxtAnaCariDurum.Text = summary.CariDurum;
                TxtAnaEvrakDurum.Text = summary.EvrakDurum;
                TxtAnaOdemeDurum.Text = summary.OdemeDurum;
            }
            catch (Exception ex)
            {
                TxtAnaCariDurum.Text = "Cari özeti alınamadı: " + ex.Message;
                TxtAnaEvrakDurum.Text = "Çek/senet özeti alınamadı.";
                TxtAnaOdemeDurum.Text = "Ödeme özeti alınamadı.";
                TxtAnaPiyasaDurum.Text = "Piyasa özeti alınamadı.";
            }
            finally { ticariOzetYukleniyor = false; }
        }
        private async void PiyasaFiyatYenile_Click(object sender, RoutedEventArgs e)
        {
            if (aktifKullanici == null ||
                !(StokYetkisiVar("MARKET.VIEW") || StokYetkisiVar("STOCK.VIEW")))
            {
                TxtAnaPiyasaDurum.Text = "Piyasa görüntüleme yetkiniz yok.";
                return;
            }
            TxtAnaPiyasaDurum.Text = "İnternet kaynakları yeniden kontrol ediliyor...";
            try
            {
                var sonuc = await PiyasaInternetServisi.GetirAsync(true);
                AnaPiyasaFiyatTablosu.ItemsSource = sonuc.Tablo.DefaultView;
                TxtAnaPiyasaDurum.Text = sonuc.Durum;
            }
            catch (Exception ex) { TxtAnaPiyasaDurum.Text = "Fiyat yenileme başarısız: " + ex.Message; }
        }
    }
}
