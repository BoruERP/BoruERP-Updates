SET XACT_ABORT ON;
BEGIN TRANSACTION;
DECLARE @lock310 int;
EXEC @lock310=sys.sp_getapplock @Resource=N'MiapaxERP.Isletme.310',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=15000;
IF @lock310<0 THROW 51310,N'İşletme modülleri kurulum kilidi alınamadı.',1;
IF OBJECT_ID('dbo.StokKartlari','U') IS NULL OR OBJECT_ID('dbo.CariKartlari','U') IS NULL OR OBJECT_ID('dbo.FinansHesaplari','U') IS NULL THROW 51310,N'Ana stok, cari ve finans tabloları hazırlanmalı.',1;
IF OBJECT_ID('dbo.MPX310_Kayit','U') IS NULL
BEGIN
 CREATE TABLE dbo.MPX310_Kayit(Id bigint IDENTITY PRIMARY KEY,Anahtar uniqueidentifier NOT NULL UNIQUE,Tur varchar(40) NOT NULL,ParentId bigint NULL REFERENCES dbo.MPX310_Kayit(Id),Veri nvarchar(max) NOT NULL CHECK(ISJSON(Veri)=1),Ozet char(64) NOT NULL,Durum nvarchar(40) NOT NULL,Olusturan int NOT NULL,Olusturma datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET(),Guncelleyen int NOT NULL,Guncelleme datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET(),Surum rowversion);
 CREATE INDEX IX_MPX310_Kayit_Tur ON dbo.MPX310_Kayit(Tur,ParentId,Durum,Id);
 CREATE TABLE dbo.MPX310_Olay(Id bigint IDENTITY PRIMARY KEY,KayitId bigint NULL REFERENCES dbo.MPX310_Kayit(Id),Tur nvarchar(60) NOT NULL,Aciklama nvarchar(2000) NOT NULL,Kullanici int NOT NULL,Zaman datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET());
 CREATE TABLE dbo.MPX310_Ek(Id bigint IDENTITY PRIMARY KEY,Anahtar uniqueidentifier NOT NULL UNIQUE,KayitId bigint NOT NULL REFERENCES dbo.MPX310_Kayit(Id),Ad nvarchar(180) NOT NULL,Tur varchar(80) NOT NULL,Veri varbinary(max) NOT NULL,Sha256 char(64) NOT NULL,Ekleyen int NOT NULL,Zaman datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET(),CHECK(DATALENGTH(Veri) BETWEEN 1 AND 41943040));
END;
IF OBJECT_ID('dbo.MPX310_Depo','U') IS NULL
BEGIN
 CREATE TABLE dbo.MPX310_Depo(Id int IDENTITY PRIMARY KEY,Kod nvarchar(30) NOT NULL UNIQUE,Ad nvarchar(120) NOT NULL,Aktif bit NOT NULL DEFAULT 1);
 CREATE TABLE dbo.MPX310_Raf(Id int IDENTITY PRIMARY KEY,DepoId int NOT NULL REFERENCES dbo.MPX310_Depo(Id),Kod nvarchar(40) NOT NULL,Ad nvarchar(120) NOT NULL,Aktif bit NOT NULL DEFAULT 1,UNIQUE(DepoId,Kod));
 CREATE TABLE dbo.MPX310_Lot(Id bigint IDENTITY PRIMARY KEY,StokId int NOT NULL REFERENCES dbo.StokKartlari(Id),Kod nvarchar(80) NOT NULL,Kaynak varchar(40) NOT NULL,KaynakId bigint NULL,Kalite nvarchar(30) NOT NULL DEFAULT N'Serbest',BirimMaliyet decimal(28,8) NULL CHECK(BirimMaliyet>=0),Olusturma datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET(),Surum rowversion,UNIQUE(StokId,Kod));
 CREATE TABLE dbo.MPX310_LotBakiye(LotId bigint NOT NULL REFERENCES dbo.MPX310_Lot(Id),RafId int NOT NULL REFERENCES dbo.MPX310_Raf(Id),Miktar decimal(18,3) NOT NULL CHECK(Miktar>=0),Surum rowversion,PRIMARY KEY(LotId,RafId));
 CREATE TABLE dbo.MPX310_LotHareket(Id bigint IDENTITY PRIMARY KEY,LotId bigint NOT NULL REFERENCES dbo.MPX310_Lot(Id),RafId int NOT NULL REFERENCES dbo.MPX310_Raf(Id),Miktar decimal(18,3) NOT NULL CHECK(Miktar<>0),Tur nvarchar(40) NOT NULL,Kaynak varchar(40) NOT NULL,KaynakId bigint NULL,Aciklama nvarchar(400) NOT NULL,Kullanici int NOT NULL,Zaman datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET());
 CREATE TABLE dbo.MPX310_Rezervasyon(Id bigint IDENTITY PRIMARY KEY,Anahtar uniqueidentifier NOT NULL UNIQUE,KayitId bigint NULL REFERENCES dbo.MPX310_Kayit(Id),LotId bigint NOT NULL REFERENCES dbo.MPX310_Lot(Id),RafId int NOT NULL REFERENCES dbo.MPX310_Raf(Id),Miktar decimal(18,3) NOT NULL CHECK(Miktar>0),Durum nvarchar(30) NOT NULL DEFAULT N'Bekliyor',Kullanici int NOT NULL,Zaman datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET(),Surum rowversion);
 CREATE INDEX IX_MPX310_Rez_Lot ON dbo.MPX310_Rezervasyon(LotId,RafId,Durum);
 CREATE TABLE dbo.MPX310_LotBag(Id bigint IDENTITY PRIMARY KEY,KaynakLot bigint NOT NULL REFERENCES dbo.MPX310_Lot(Id),UrunLot bigint NOT NULL REFERENCES dbo.MPX310_Lot(Id),Miktar decimal(18,3) NOT NULL CHECK(Miktar>0),UretimEmriId int NULL,KayitId bigint NULL REFERENCES dbo.MPX310_Kayit(Id),CHECK(KaynakLot<UrunLot),UNIQUE(KaynakLot,UrunLot,UretimEmriId));
END;
IF OBJECT_ID('dbo.MPX310_Gizli','U') IS NULL CREATE TABLE dbo.MPX310_Gizli(Kullanici int NOT NULL,Saglayici varchar(30) NOT NULL,Ortam varchar(10) NOT NULL,Vkn varchar(11) NOT NULL,Sifreli varbinary(max) NOT NULL,Guncelleme datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET(),PRIMARY KEY(Kullanici,Saglayici,Ortam));
IF NOT EXISTS(SELECT 1 FROM dbo.MPX310_Depo WHERE Kod=N'MERKEZ') INSERT dbo.MPX310_Depo(Kod,Ad) VALUES(N'MERKEZ',N'Merkez depo');
IF NOT EXISTS(SELECT 1 FROM dbo.MPX310_Raf r JOIN dbo.MPX310_Depo d ON d.Id=r.DepoId WHERE d.Kod=N'MERKEZ' AND r.Kod=N'GENEL') INSERT dbo.MPX310_Raf(DepoId,Kod,Ad) SELECT Id,N'GENEL',N'Genel raf' FROM dbo.MPX310_Depo WHERE Kod=N'MERKEZ';
IF OBJECT_ID('dbo.MPX310_Hesap','U') IS NULL
BEGIN
 CREATE TABLE dbo.MPX310_Hesap(Kod nvarchar(30) PRIMARY KEY,Ad nvarchar(160) NOT NULL,Aktif bit NOT NULL DEFAULT 1);
 CREATE TABLE dbo.MPX310_Donem(Yil int NOT NULL,Ay int NOT NULL CHECK(Ay BETWEEN 1 AND 12),Kapali bit NOT NULL DEFAULT 0,Kapatan int NULL,Kapanis datetimeoffset NULL,Gerekce nvarchar(400) NULL,PRIMARY KEY(Yil,Ay));
 CREATE TABLE dbo.MPX310_Sira(Yil int PRIMARY KEY,Son int NOT NULL);
 CREATE TABLE dbo.MPX310_Fis(Id bigint IDENTITY PRIMARY KEY,Anahtar uniqueidentifier NOT NULL UNIQUE,Yil int NOT NULL,Sira int NOT NULL,Tarih date NOT NULL,Kaynak varchar(40) NOT NULL,KaynakId bigint NULL,Aciklama nvarchar(400) NOT NULL,Durum nvarchar(20) NOT NULL DEFAULT N'Taslak',TersFisId bigint NULL REFERENCES dbo.MPX310_Fis(Id),Kullanici int NOT NULL,Zaman datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET(),UNIQUE(Yil,Sira));
 CREATE TABLE dbo.MPX310_FisKalem(FisId bigint NOT NULL REFERENCES dbo.MPX310_Fis(Id),Sira int NOT NULL,Hesap nvarchar(30) NOT NULL REFERENCES dbo.MPX310_Hesap(Kod),Borc decimal(28,8) NOT NULL CHECK(Borc>=0),Alacak decimal(28,8) NOT NULL CHECK(Alacak>=0),CariId int NULL REFERENCES dbo.CariKartlari(Id),Doviz varchar(3) NOT NULL DEFAULT 'TRY',DovizTutar decimal(28,8) NOT NULL DEFAULT 0,Kur decimal(28,8) NOT NULL DEFAULT 1 CHECK(Kur>0),Aciklama nvarchar(400) NOT NULL,PRIMARY KEY(FisId,Sira),CHECK((Borc>0 AND Alacak=0) OR (Alacak>0 AND Borc=0)));
 CREATE UNIQUE INDEX UX_MPX310_Fis_Ters ON dbo.MPX310_Fis(TersFisId) WHERE TersFisId IS NOT NULL;
 CREATE INDEX IX_MPX310_Fis_Tarih ON dbo.MPX310_Fis(Tarih,Durum);
END;
INSERT dbo.MPX310_Hesap(Kod,Ad) SELECT x.Kod,x.Ad FROM(VALUES
 (N'100',N'Kasa'),(N'102',N'Bankalar'),(N'120',N'Alıcılar'),(N'150',N'İlk madde ve malzeme'),(N'152',N'Mamuller'),(N'153',N'Ticari mallar'),(N'191',N'İndirilecek KDV'),(N'197',N'Sayım ve tesellüm noksanları'),(N'320',N'Satıcılar'),(N'391',N'Hesaplanan KDV'),(N'397',N'Sayım ve tesellüm fazlaları'),(N'500',N'Sermaye'),(N'600',N'Yurt içi satışlar'),(N'620',N'Satılan mamuller maliyeti'),(N'621',N'Satılan ticari mallar maliyeti'),(N'646',N'Kambiyo kârları'),(N'656',N'Kambiyo zararları'),(N'730',N'Genel üretim giderleri'),(N'770',N'Genel yönetim giderleri'))x(Kod,Ad) WHERE NOT EXISTS(SELECT 1 FROM dbo.MPX310_Hesap h WHERE h.Kod=x.Kod);
IF OBJECT_ID('dbo.MPX310_Satis','U') IS NULL
BEGIN
 CREATE TABLE dbo.MPX310_Satis(BelgeId bigint PRIMARY KEY REFERENCES dbo.BoruERP_YeniBelgeler(Id),CariHareketId bigint NOT NULL UNIQUE REFERENCES dbo.CariHareketleri(Id),FisId bigint NOT NULL UNIQUE REFERENCES dbo.MPX310_Fis(Id),Doviz varchar(3) NOT NULL,Kur decimal(28,8) NOT NULL CHECK(Kur>0),Toplam decimal(18,2) NOT NULL CHECK(Toplam>0),Kapanan decimal(18,2) NOT NULL DEFAULT 0 CHECK(Kapanan>=0),Surum rowversion);
 CREATE TABLE dbo.MPX310_Tahsilat(Id bigint IDENTITY PRIMARY KEY,Anahtar uniqueidentifier NOT NULL UNIQUE,BelgeId bigint NOT NULL REFERENCES dbo.MPX310_Satis(BelgeId),Tarih date NOT NULL,Tutar decimal(18,2) NOT NULL CHECK(Tutar>0),Kur decimal(28,8) NOT NULL CHECK(Kur>0),DefterTutar decimal(18,2) NOT NULL,KurFarki decimal(18,2) NOT NULL,FinansHareketId bigint NOT NULL UNIQUE REFERENCES dbo.FinansHareketleri(Id),CariHareketId bigint NOT NULL UNIQUE REFERENCES dbo.CariHareketleri(Id),FisId bigint NOT NULL UNIQUE REFERENCES dbo.MPX310_Fis(Id),Kullanici int NOT NULL);
 CREATE TABLE dbo.MPX310_SatisLot(Id bigint IDENTITY PRIMARY KEY,BelgeId bigint NOT NULL REFERENCES dbo.MPX310_Satis(BelgeId),KalemId bigint NOT NULL REFERENCES dbo.BoruERP_YeniBelgeKalemleri(Id),LotId bigint NOT NULL REFERENCES dbo.MPX310_Lot(Id),RafId int NOT NULL REFERENCES dbo.MPX310_Raf(Id),Miktar decimal(18,3) NOT NULL CHECK(Miktar>0),SevkEdilen decimal(18,3) NOT NULL DEFAULT 0 CHECK(SevkEdilen>=0),Maliyet decimal(28,8) NULL);
END;
INSERT dbo.Yetkiler(YetkiKodu,Modul,Islem,Aciklama,Aktif)
SELECT x.Kod,x.Modul,x.Islem,x.Aciklama,1 FROM(VALUES
 ('SHIPMENT.VIEW',N'Sevkiyat',N'Görüntüle',N'Sevkiyat ve kantar kayıtları'),('SHIPMENT.EDIT',N'Sevkiyat',N'Düzenle',N'Sevkiyat hazırlama'),('SHIPMENT.DISPATCH',N'Sevkiyat',N'Sevk et',N'Ürün çıkışı ve sevkiyat durumları'),
 ('PRESSURE.VIEW',N'Basınç testi',N'Görüntüle',N'Boru basınç testleri ve medya'),('PRESSURE.EDIT',N'Basınç testi',N'Deney kaydet',N'Deney koşulları ve ölçümler'),('PRESSURE.APPROVE',N'Basınç testi',N'Teknik onay',N'Ayrı kullanıcıyla basınç testi incelemesi'),('PRESSURE.EXPORT',N'Basınç testi',N'Dışa aktar',N'Boru test PDF ve medya dışa aktarımı'),
 ('WAREHOUSE.VIEW',N'Depo',N'Görüntüle',N'Depo raf parti ve kullanılabilir miktarlar'),('WAREHOUSE.CONFIG',N'Depo',N'Tanımla',N'Depo raf tanımları ve devir'),('WAREHOUSE.TRANSFER',N'Depo',N'Transfer',N'Raflar arasında atomik transfer'),('WAREHOUSE.RESERVE',N'Depo',N'Rezerve et',N'Sipariş veya üretim için malzeme ayırma'),('WAREHOUSE.COUNT',N'Depo',N'Sayım',N'Fiilî sayım ve farkları stokla eşleme'),
 ('ACCOUNTING.VIEW',N'Genel muhasebe',N'Görüntüle',N'Fiş yevmiye mizan ve hesap planı'),('ACCOUNTING.POST',N'Genel muhasebe',N'Fiş kaydet',N'Dengeli ve izlenebilir muhasebe kayıtları'),('ACCOUNTING.CLOSE',N'Genel muhasebe',N'Dönem kapat',N'Kapalı dönem kayıt koruması'),
 ('PRODUCTION.PLAN',N'Üretim',N'Malzeme planla',N'Çok seviyeli reçeteden MRP'),('PRODUCTION.CAPACITY',N'Üretim',N'Kapasite planla',N'Makine süre ve çakışma kontrolü'),('PRODUCTION.COST',N'Üretim',N'Maliyet hesapla',N'Fiilî malzeme süre ve gider maliyeti'),
 ('PURCHASE.MATCH',N'Satın alma',N'Eşleştir',N'Sipariş mal kabul fatura miktar ve fiyat eşleştirmesi'))x(Kod,Modul,Islem,Aciklama)
WHERE NOT EXISTS(SELECT 1 FROM dbo.Yetkiler y WHERE y.YetkiKodu=x.Kod);
EXEC(N'CREATE OR ALTER TRIGGER dbo.MPX310_FisKalem_Koru ON dbo.MPX310_FisKalem AFTER INSERT,UPDATE,DELETE AS
BEGIN SET NOCOUNT ON;
 IF EXISTS(SELECT 1 FROM (SELECT FisId FROM inserted UNION SELECT FisId FROM deleted) x JOIN dbo.MPX310_Fis f ON f.Id=x.FisId WHERE f.Durum=N''Kesin'') THROW 51310,N''Kesin fiş kalemleri değiştirilemez; ters fiş kullanın.'',1;
END');
EXEC(N'CREATE OR ALTER TRIGGER dbo.MPX310_Fis_Koru ON dbo.MPX310_Fis AFTER INSERT,UPDATE,DELETE AS
BEGIN SET NOCOUNT ON;
 IF EXISTS(SELECT 1 FROM deleted WHERE Durum=N''Kesin'') THROW 51310,N''Kesin muhasebe fişi değiştirilemez veya silinemez.'',1;
 IF EXISTS(SELECT 1 FROM inserted f JOIN dbo.MPX310_Donem d ON d.Yil=f.Yil AND d.Ay=MONTH(f.Tarih) WHERE d.Kapali=1) THROW 51310,N''Kapalı döneme fiş kaydedilemez.'',1;
 IF EXISTS(SELECT 1 FROM inserted f WHERE f.Durum=N''Kesin'' AND (NOT EXISTS(SELECT 1 FROM dbo.MPX310_FisKalem k WHERE k.FisId=f.Id) OR (SELECT SUM(Borc-Alacak) FROM dbo.MPX310_FisKalem k WHERE k.FisId=f.Id)<>0)) THROW 51310,N''Kesin fiş dengeli ve kalemli olmalı.'',1;
END');
DROP TRIGGER IF EXISTS dbo.MPX310_CariTers_Koru;
DROP TRIGGER IF EXISTS dbo.MPX310_FinansTers_Koru;
COMMIT;

