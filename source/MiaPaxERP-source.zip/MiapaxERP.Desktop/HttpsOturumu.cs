using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
namespace MiapaxERP.Desktop;

public sealed class HttpsIstemci : IDisposable
{
    readonly HttpClient http;
    public HttpsGirisYaniti? Oturum {get;private set;}
    public string Adres {get;}
    public HttpsIstemci(string address) : this(address,new HttpClientHandler{AllowAutoRedirect=false,CheckCertificateRevocationList=true,UseCookies=false}) { }
    internal HttpsIstemci(string address,HttpMessageHandler handler)
    {
        var uri=KolayBaglantiProfili.Https(address);Adres=KolayBaglantiProfili.KisaAdres(uri);
        http=new HttpClient(handler)
        {BaseAddress=uri,Timeout=TimeSpan.FromSeconds(120),MaxResponseContentBufferSize=64*1024*1024};
    }
    public async Task Giris(string name,string password,CancellationToken ct=default)
    {
        using var r=await http.PostAsJsonAsync(HttpsApi.Kok+"/login",new HttpsGiris(name,password),HttpsJson.Ayarlar,ct).ConfigureAwait(false);
        await Kontrol(r,ct).ConfigureAwait(false);
        var s=await r.Content.ReadFromJsonAsync<HttpsGirisYaniti>(HttpsJson.Ayarlar,ct).ConfigureAwait(false)??throw new InvalidOperationException("Sunucu giriş yanıtı eksik.");
        if(s.Token.Length!=64||!s.Token.All(Uri.IsHexDigit)||s.Bitis<=DateTimeOffset.UtcNow||s.Kullanici.Id<=0)throw new InvalidOperationException("Sunucu giriş yanıtı geçersiz.");
        Oturum=s;http.DefaultRequestHeaders.Authorization=new AuthenticationHeaderValue("Bearer",s.Token);
    }
    internal async Task<T> Cagir<T>(string operation,string scope,object?[] args,CancellationToken ct=default)
    {
        if(Oturum is null||Oturum.Bitis<=DateTimeOffset.UtcNow)throw new UnauthorizedAccessException("Oturum bitti. Tekrar giriş yapın.");
        var call=new HttpsCagri(operation,scope,args.Select(a=>JsonSerializer.SerializeToElement(a,HttpsJson.Ayarlar)).ToArray());
        try
        {
            using var r=await http.PostAsJsonAsync(HttpsApi.Kok+"/rpc",call,HttpsJson.Ayarlar,ct).ConfigureAwait(false);
            await Kontrol(r,ct).ConfigureAwait(false);
            return (await r.Content.ReadFromJsonAsync<T>(HttpsJson.Ayarlar,ct).ConfigureAwait(false))!;
        }
        catch(Exception e)when(e is HttpRequestException or TaskCanceledException)
        {throw new InvalidOperationException("Sunucuya ulaşılamadı veya yanıt süresi doldu. İşlem otomatik tekrarlanmadı. Kaydetme yaptıysanız listeyi yenileyip sonucunu kontrol edin.",e);}
    }
    static async Task Kontrol(HttpResponseMessage r,CancellationToken ct)
    {
        if(r.IsSuccessStatusCode)return;
        string message="Sunucu işlemi tamamlayamadı ("+(int)r.StatusCode+").";
        try{using var json=JsonDocument.Parse(await r.Content.ReadAsStringAsync(ct).ConfigureAwait(false));if(json.RootElement.TryGetProperty("mesaj",out var m))message=m.GetString()??message;}catch(JsonException){}
        if(r.StatusCode is HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden)throw new UnauthorizedAccessException(message);
        throw new InvalidOperationException(message);
    }
    public async Task Cikis()
    {
        using var stop=new CancellationTokenSource(TimeSpan.FromSeconds(5));
        try{using var r=await http.PostAsync(HttpsApi.Kok+"/logout",null,stop.Token).ConfigureAwait(false);}catch(HttpRequestException){}catch(TaskCanceledException){}
        finally{Oturum=null;http.DefaultRequestHeaders.Authorization=null;}
    }
    public async Task SifreDegistir(HttpsSifreDegisimi input,CancellationToken ct=default){using var r=await http.PostAsJsonAsync(HttpsApi.Kok+"/password",input,HttpsJson.Ayarlar,ct).ConfigureAwait(false);await Kontrol(r,ct).ConfigureAwait(false);}
    public async Task SifreKurtar(HttpsSifreKurtarma input,CancellationToken ct=default){using var r=await http.PostAsJsonAsync(HttpsApi.Kok+"/recover",input,HttpsJson.Ayarlar,ct).ConfigureAwait(false);await Kontrol(r,ct).ConfigureAwait(false);}
    internal async Task<GirisPenceresi.KurtarmaKodPaketi?> KurtarmaKodlari(CancellationToken ct=default){using var r=await http.PostAsync(HttpsApi.Kok+"/recovery/codes",null,ct).ConfigureAwait(false);await Kontrol(r,ct).ConfigureAwait(false);return await r.Content.ReadFromJsonAsync<GirisPenceresi.KurtarmaKodPaketi>(HttpsJson.Ayarlar,ct).ConfigureAwait(false);}
    internal async Task KurtarmaOnayla(Guid group,CancellationToken ct=default){using var r=await http.PostAsJsonAsync(HttpsApi.Kok+"/recovery/confirm",new HttpsKodOnayi(group),HttpsJson.Ayarlar,ct).ConfigureAwait(false);await Kontrol(r,ct).ConfigureAwait(false);}
    public void Dispose(){Oturum=null;http.Dispose();}
}
public static class HttpsOturumu
{
    public static HttpsIstemci? Istemci {get;private set;}
    public static bool Uzak(string connection)=>connection.StartsWith("miapax-https:",StringComparison.Ordinal);
    public static string Baglanti=>"miapax-https:"+(Istemci?.Adres??throw new UnauthorizedAccessException("Önce giriş yapın."));
    public static void Baslat(HttpsIstemci client)=>Istemci=client;
    public static void Temizle(){Istemci?.Dispose();Istemci=null;}
    public static T Cagir<T>(string connection,string operation,string scope,object?[] args)
    {
        var c=Istemci??throw new UnauthorizedAccessException("Önce giriş yapın.");
        if(connection!=Baglanti)throw new UnauthorizedAccessException("Sunucu değişti. Tekrar giriş yapın.");
        return c.Cagir<T>(operation,scope,args).GetAwaiter().GetResult();
    }
}
