using System.Data;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed partial class IsletmeServisi
{
    static decimal Round(decimal v)=>decimal.Round(v,2,MidpointRounding.AwayFromZero);
    static void Currency(string currency,decimal rate){if(currency is not("TRY" or "USD" or "EUR" or "GBP")||rate<=0||rate>1000000||decimal.Round(rate,8)!=rate||currency=="TRY"&&rate!=1)throw new ArgumentException("Para birimi / kur geçersiz. TRY kuru 1 olmalı.");}
    static void PurchaseLine(SiparisKalemi k){Quantity(k.Miktar);Money(k.Fiyat);if(k.Fiyat<=0||k.Stok<=0||k.Raf<=0||k.Kdv<0||k.Kdv>100||decimal.Round(k.Kdv,2)!=k.Kdv)throw new ArgumentException("Sipariş kaleminin ürün, raf, fiyat veya KDV bilgileri geçersiz.");Text(k.Parti,0,80,"Parti");}
    public long SiparisKaydet(SatinAlmaGirdisi g)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"IsletmeServisi.SiparisKaydet","",new object?[]{g});}

        Text(g.No,1,80,"Sipariş no");Text(g.Aciklama,0,400,"Açıklama");Currency(g.Para,g.Kur);if(g.Tarih.Year<2000||g.Tarih.Year>2100||g.Termin<g.Tarih||g.Kalemler is null||g.Kalemler.Length<1||g.Kalemler.Length>200)throw new ArgumentException("Sipariş tarihlerini ve kalemlerini kontrol edin.");foreach(var k in g.Kalemler)PurchaseLine(k);
        using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"PURCHASE.EDIT");
        using(var customer=Q(c,t,"SELECT COUNT(*) FROM dbo.CariKartlari WITH(HOLDLOCK) WHERE Id=@i AND Aktif=1",("@i",g.Cari)))if(Convert.ToInt32(customer.ExecuteScalar())!=1)throw new ArgumentException("Aktif tedarikçi seçin.");
        foreach(var k in g.Kalemler){using var q=Q(c,t,"SELECT COUNT(*) FROM dbo.StokKartlari s CROSS JOIN dbo.MPX310_Raf r JOIN dbo.MPX310_Depo d ON d.Id=r.DepoId WHERE s.Id=@s AND s.Aktif=1 AND r.Id=@r AND r.Aktif=1 AND d.Aktif=1",("@s",k.Stok),("@r",k.Raf));if(Convert.ToInt32(q.ExecuteScalar())!=1)throw new ArgumentException("Aktif stok ve raf seçin.");}
        long id;if(g.Id.HasValue){var row=Read(c,t,g.Id.Value,"SatinAlma",true);Version(row,g.Surum);using var children=Q(c,t,"SELECT COUNT(*) FROM dbo.MPX310_Kayit WHERE ParentId=@i",("@i",g.Id));if(Convert.ToInt32(children.ExecuteScalar())!=0)throw new InvalidOperationException("Mal kabul veya fatura kaydı olan sipariş değiştirilemez.");Update(c,t,g.Id.Value,"SatinAlma",g.Surum!,g);id=g.Id.Value;}else id=Create(c,t,"SatinAlma",g.Anahtar,g);t.Commit();return id;
    }
    List<T> Children<T>(SqlConnection c,SqlTransaction t,long parent,string kind)=>Table(Q(c,t,"SELECT Veri FROM dbo.MPX310_Kayit WITH(UPDLOCK,HOLDLOCK) WHERE ParentId=@p AND Tur=@t AND Durum=N'Tamamlandı'",("@p",parent),("@t",kind))).AsEnumerable().Select(r=>Veri<T>((string)r[0])).ToList();
    public long MalKabul(MalKabulGirdisi g)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"IsletmeServisi.MalKabul","",new object?[]{g});}

        Text(g.Aciklama,1,400,"Açıklama");if(g.Kalemler is null||g.Kalemler.Length<1||g.Kalemler.Length>200||g.Kalemler.Select(k=>k.Satir).Distinct().Count()!=g.Kalemler.Length)throw new ArgumentException("Mal kabul kalemleri boş veya tekrarlı.");
        using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"PURCHASE.MATCH");Yetki(c,t,"STOCK.RECEIVE");var row=Read(c,t,g.Siparis,"SatinAlma",true);var order=Veri<SatinAlmaGirdisi>((string)row["Veri"]);if((string)row["Durum"]!="Taslak")throw new InvalidOperationException("Sipariş kapalı.");if(g.Tarih.Date<order.Tarih.Date||g.Tarih.Date>DateTime.Today)throw new ArgumentException("Mal kabul tarihi siparişten önce veya gelecekte olamaz.");
        var receipts=Children<MalKabulGirdisi>(c,t,g.Siparis,"MalKabul");using(var prior=Q(c,t,"SELECT Id FROM dbo.MPX310_Kayit WHERE Anahtar=@k",("@k",g.Anahtar)))if(prior.ExecuteScalar() is not null)throw new InvalidOperationException("Mal kabul zaten kaydedildi.");long id=Create(c,t,"MalKabul",g.Anahtar,g,"Tamamlandı",g.Siparis);
        foreach(var k in g.Kalemler.OrderBy(k=>k.Satir))
        {
            Quantity(k.Miktar);Text(k.Parti,1,80,"Tedarikçi partisi");if(k.Satir<0||k.Satir>=order.Kalemler.Length)throw new ArgumentException("Sipariş kalemi bulunamadı.");var line=order.Kalemler[k.Satir];decimal received=receipts.SelectMany(r=>r.Kalemler).Where(r=>r.Satir==k.Satir).Sum(r=>r.Miktar);if(received+k.Miktar>line.Miktar)throw new InvalidOperationException("Mal kabul miktarı siparişin kalan miktarını aşıyor.");
            long lot;using(var insert=Q(c,t,"INSERT dbo.MPX310_Lot(StokId,Kod,Kaynak,KaynakId,Kalite,BirimMaliyet) OUTPUT INSERTED.Id VALUES(@s,@p,'MalKabul',@i,@q,@m)",("@s",line.Stok),("@p",k.Parti),("@i",id),("@q",k.KaliteKontrol?"Bloke":"Serbest"),("@m",line.Fiyat*order.Kur)))lot=Convert.ToInt64(insert.ExecuteScalar());LocationChange(c,t,lot,line.Raf,k.Miktar,"Mal kabul","MalKabul",id,order.No);AggregateChange(c,t,line.Stok,k.Miktar,"MAL_KABUL",order.No+" · "+k.Parti);
        }t.Commit();return id;
    }
    public long AlisFaturasi(AlisFaturaGirdisi g)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"IsletmeServisi.AlisFaturasi","",new object?[]{g});}

        Text(g.No,1,80,"Fatura no");Text(g.Aciklama,1,400,"Açıklama");if(g.Kalemler is null||g.Kalemler.Length<1||g.Kalemler.Length>200||g.Kalemler.Select(k=>k.Satir).Distinct().Count()!=g.Kalemler.Length)throw new ArgumentException("Fatura kalemleri boş veya tekrarlı.");
        using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"PURCHASE.MATCH");Yetki(c,t,"FINANCE.PAYMENT");var order=Veri<SatinAlmaGirdisi>((string)Read(c,t,g.Siparis,"SatinAlma",true)["Veri"]);if(g.Tarih.Date<order.Tarih.Date||g.Tarih.Date>DateTime.Today)throw new ArgumentException("Fatura tarihini kontrol edin.");
        var receipts=Children<MalKabulGirdisi>(c,t,g.Siparis,"MalKabul");var invoices=Children<AlisFaturaGirdisi>(c,t,g.Siparis,"AlisFatura");if(invoices.Any(i=>i.No==g.No))throw new InvalidOperationException("Fatura bu siparişte zaten kayıtlı.");using(var duplicate=Q(c,t,"SELECT COUNT(*) FROM dbo.MPX310_Kayit WHERE Tur='AlisFatura' AND JSON_VALUE(Veri,'$.no')=@n AND ParentId IN(SELECT Id FROM dbo.MPX310_Kayit WHERE Tur='SatinAlma' AND TRY_CONVERT(int,JSON_VALUE(Veri,'$.cari'))=@c)",("@n",g.No),("@c",order.Cari)))if(Convert.ToInt32(duplicate.ExecuteScalar())>0)throw new InvalidOperationException("Tedarikçiye ait fatura numarası zaten kayıtlı.");
        decimal subtotal=0,vat=0;foreach(var k in g.Kalemler){Quantity(k.Miktar);Money(k.Fiyat);if(k.Satir<0||k.Satir>=order.Kalemler.Length)throw new ArgumentException("Sipariş kalemi bulunamadı.");var line=order.Kalemler[k.Satir];decimal received=receipts.SelectMany(r=>r.Kalemler).Where(r=>r.Satir==k.Satir).Sum(r=>r.Miktar),invoiced=invoices.SelectMany(r=>r.Kalemler).Where(r=>r.Satir==k.Satir).Sum(r=>r.Miktar);if(k.Miktar+invoiced>received||k.Fiyat!=line.Fiyat||k.Kdv!=line.Kdv)throw new InvalidOperationException("Üçlü eşleştirme başarısız: miktar kabul edileni aşıyor veya fiyat/KDV siparişle uyuşmuyor.");decimal net=Round(k.Miktar*k.Fiyat*order.Kur);subtotal+=net;vat+=Round(net*k.Kdv/100);}
        long id=Create(c,t,"AlisFatura",g.Anahtar,g,"Tamamlandı",g.Siparis);var lines=new List<MuhasebeKalemi>{new("150",subtotal,0,null,g.No),new("320",0,subtotal+vat,order.Cari,g.No)};if(vat>0)lines.Add(new("191",vat,0,null,g.No));Journal(c,t,new(g.Anahtar,g.Tarih,g.No,lines.ToArray()),"AlisFatura",id);
        using(var movement=Q(c,t,"INSERT dbo.CariHareketleri(CariId,Tarih,HareketTipi,Tutar,Aciklama,Kaynak,YapanKullaniciId) VALUES(@c,@d,N'Alacak',@v,@a,N'MPX310 Alış',@u)",("@c",order.Cari),("@d",g.Tarih.Date),("@v",subtotal+vat),("@a",g.No+" · "+order.Para+" / kur "+order.Kur),("@u",user)))movement.ExecuteNonQuery();t.Commit();return id;
    }
    public DataTable SiparisEslesme(long id)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"IsletmeServisi.SiparisEslesme","",new object?[]{id});}

        using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"PURCHASE.VIEW");var order=Veri<SatinAlmaGirdisi>((string)Read(c,t,id,"SatinAlma")["Veri"]);var receipts=Children<MalKabulGirdisi>(c,t,id,"MalKabul");var invoices=Children<AlisFaturaGirdisi>(c,t,id,"AlisFatura");var table=new DataTable();table.Columns.Add("Satir",typeof(int));table.Columns.Add("Stok",typeof(int));foreach(string name in new[]{"Siparis","Kabul","Fatura","BekleyenKabul","BekleyenFatura","Fiyat","Kdv"})table.Columns.Add(name,typeof(decimal));for(int i=0;i<order.Kalemler.Length;i++){var k=order.Kalemler[i];decimal received=receipts.SelectMany(x=>x.Kalemler).Where(x=>x.Satir==i).Sum(x=>x.Miktar),invoiced=invoices.SelectMany(x=>x.Kalemler).Where(x=>x.Satir==i).Sum(x=>x.Miktar);table.Rows.Add(i,k.Stok,k.Miktar,received,invoiced,k.Miktar-received,received-invoiced,k.Fiyat,k.Kdv);}t.Commit();return table;
    }
}
