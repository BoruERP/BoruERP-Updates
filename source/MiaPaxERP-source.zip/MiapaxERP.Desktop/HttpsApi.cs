using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Data.SqlClient;
using System.Text.Json;
namespace MiapaxERP.Desktop;

public static class HttpsApi
{
    public const string Kok="/api/desktop/v1";
    public static void Kur(WebApplication app,string connection,IHttpsHesapDeposu? testDepo=null,Func<bool>? lisans=null)
    {
        var sessions=new HttpsOturumDeposu(testDepo??new HttpsSqlHesapDeposu(connection));
        var secretGate=new SemaphoreSlim(1,1);
        bool Lisans()=>lisans?.Invoke()??(!LisansOturumu.Zorunlu||LisansOturumu.Gecerli!=null);
        string Token(HttpContext c){var a=c.Request.Headers.Authorization.ToString();return a.StartsWith("Bearer ",StringComparison.Ordinal)?a[7..]:"";}
        app.Use(async(c,next)=>
        {
            if(!c.Request.Path.StartsWithSegments(Kok)){await next(c);return;}
            c.Response.Headers.CacheControl="no-store, private";c.Response.Headers["X-Content-Type-Options"]="nosniff";
            try
            {
                if(c.Request.Path!=Kok+"/health"&&!Lisans()){c.Response.StatusCode=403;await c.Response.WriteAsJsonAsync(new{mesaj="Ana sunucunun lisansı doğrulanmalı."});return;}
                await next(c);
            }
            catch(HttpsYogunException){c.Response.StatusCode=429;c.Response.Headers.RetryAfter="5";}
            catch(UnauthorizedAccessException){c.Response.StatusCode=401;await c.Response.WriteAsJsonAsync(new{mesaj="Hesap/oturum geçersiz veya bu işlem için yetkiniz yok. Tekrar giriş yapın."});}
            catch(Exception e)when(e is ArgumentException or JsonException or KeyNotFoundException or NullReferenceException){c.Response.StatusCode=400;await c.Response.WriteAsJsonAsync(new{mesaj="İşlem bilgileri geçersiz. Formu kontrol edin."});}
            catch(InvalidOperationException e){c.Response.StatusCode=409;await c.Response.WriteAsJsonAsync(new{mesaj=e.Message});}
            catch(EBelge.EbelgeHatasi e){c.Response.StatusCode=409;await c.Response.WriteAsJsonAsync(new{mesaj=e.Message});}
            catch(WebYonetimi.WebApiHatasi e){c.Response.StatusCode=409;await c.Response.WriteAsJsonAsync(new{mesaj=e.Message});}
            catch(SqlException e)when(e.Number is 2601 or 2627){c.Response.StatusCode=409;await c.Response.WriteAsJsonAsync(new{mesaj="Kayıt zaten var. Listeyi yenileyin."});}
            catch(SqlException){c.Response.StatusCode=503;await c.Response.WriteAsJsonAsync(new{mesaj="Ana sunucu veritabanına erişemedi. İşlemin sonucunu listeyi yenileyerek kontrol edin."});}
        });
        app.MapGet(Kok+"/health",()=>Results.Json(new{service="MiapaxERP.Server",api=1,transport="https",desktop=true,mobile=true}));
        app.MapPost(Kok+"/login",async(HttpContext c)=>
        {
            var input=await c.Request.ReadFromJsonAsync<HttpsGiris>(HttpsJson.Ayarlar,c.RequestAborted)??throw new ArgumentException();
            var s=await sessions.Giris(input,c.RequestAborted);
            var modules=LisansOturumu.Gecerli?.Modules?.ToArray()??[];
            return Results.Json(new HttpsGirisYaniti(s.Token,s.Kullanici,modules,LisansOturumu.SektorKodu,s.Bitis),HttpsJson.Ayarlar);
        });
        app.MapPost(Kok+"/logout",(HttpContext c)=>{sessions.Cikis(Token(c));return Results.NoContent();});
        app.MapPost(Kok+"/password",async(HttpContext c)=>
        {
            if(!await secretGate.WaitAsync(0,c.RequestAborted))throw new HttpsYogunException();try{var input=await c.Request.ReadFromJsonAsync<HttpsSifreDegisimi>(HttpsJson.Ayarlar,c.RequestAborted)??throw new ArgumentException();new HttpsSifreServisi(connection).Degistir(input);return Results.NoContent();}finally{secretGate.Release();}
        });
        app.MapPost(Kok+"/recover",async(HttpContext c)=>
        {
            if(!await secretGate.WaitAsync(0,c.RequestAborted))throw new HttpsYogunException();try{var input=await c.Request.ReadFromJsonAsync<HttpsSifreKurtarma>(HttpsJson.Ayarlar,c.RequestAborted)??throw new ArgumentException();new HttpsSifreServisi(connection).Kurtar(input);return Results.NoContent();}finally{secretGate.Release();}
        });
        app.MapPost(Kok+"/recovery/codes",(HttpContext c)=>{var account=sessions.Dogrula(Token(c));return Results.Json(GirisPenceresi.GiristeKurtarmaKodlariniHazirla(account.Id,connection),HttpsJson.Ayarlar);});
        app.MapPost(Kok+"/recovery/confirm",async(HttpContext c)=>{var account=sessions.Dogrula(Token(c));var input=await c.Request.ReadFromJsonAsync<HttpsKodOnayi>(HttpsJson.Ayarlar,c.RequestAborted)??throw new ArgumentException();if(!GirisPenceresi.KurtarmaKodlariniTeslimOnayla(account.Id,input.Grup,connection))throw new InvalidOperationException("Kurtarma kodu grubu değişti. Tekrar giriş yapın.");return Results.NoContent();});
        app.MapGet(Kok+"/profile",(HttpContext c)=>{var user=sessions.Dogrula(Token(c));return Results.Json(new{user,modules=LisansOturumu.Gecerli?.Modules,sector=LisansOturumu.SektorKodu},HttpsJson.Ayarlar);});
        app.MapPost(Kok+"/rpc",async(HttpContext c)=>
        {
            var user=sessions.Dogrula(Token(c));
            var call=await c.Request.ReadFromJsonAsync<HttpsCagri>(HttpsJson.Ayarlar,c.RequestAborted)??throw new ArgumentException();
            if(call.Islem is null||call.Kapsam is null||call.Argumanlar is null)throw new ArgumentException();
            // Aynı servis yerelde de çalışır; her işlev kendi lisansını, yetkisini,
            // sürüm bilgisini ve SQL işlemini ana sunucuda denetler.
            var result=HttpsIslemKatalogu.Calistir(connection,user.Id,call);
            return Results.Json(result,HttpsJson.Ayarlar);
        });
    }
}
