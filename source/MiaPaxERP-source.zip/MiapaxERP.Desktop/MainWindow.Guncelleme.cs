using System;
using System.Threading.Tasks;
using System.Windows.Threading;

namespace MiapaxERP.Desktop;

public partial class MainWindow
{
    private DispatcherTimer? _guncellemeZamanlayicisi;
    private bool _guncellemeKapatildi;

    private void OtomatikGuncellemeyiBagla()
    {
        Loaded += (_, _) =>
        {
            _guncellemeZamanlayicisi = new DispatcherTimer { Interval = MiapaxERPGuncelleme.KontrolAraligi };
            _guncellemeZamanlayicisi.Tick += (_, _) => _ = MiapaxERPGuncelleme.KontrolEtAsync();
            _guncellemeZamanlayicisi.Start();
            // Açılışı bloklamamak için gecikmeli kontrol.
            _ = BaslangictaGuncellemeKontrolEtAsync();
        };
        Closed += (_, _) =>
        {
            _guncellemeKapatildi = true;
            _guncellemeZamanlayicisi?.Stop();
            MiapaxERPGuncelleme.UygulamaKapanirken();
        };
    }

    private async Task BaslangictaGuncellemeKontrolEtAsync()
    {
        await Task.Delay(TimeSpan.FromSeconds(12));
        if (_guncellemeKapatildi) return;
        await MiapaxERPGuncelleme.KontrolEtAsync();
    }
}
