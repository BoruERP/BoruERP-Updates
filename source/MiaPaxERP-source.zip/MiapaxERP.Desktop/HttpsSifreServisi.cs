using System.Data;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed record HttpsSifreDegisimi(string Kullanici,string Eski,string Yeni);
public sealed record HttpsSifreKurtarma(string Kullanici,string Kod,string Yeni);
public sealed record HttpsKodOnayi(Guid Grup);
public sealed class HttpsSifreServisi(string connection)
{
    static void Parola(string value){if(value is null||value.Length<12||value.Length>128)throw new ArgumentException("Yeni şifre 12–128 karakter olmalı.");}
    internal void Degistir(HttpsSifreDegisimi input)
    {
        Parola(input.Yeni);if(input.Eski==input.Yeni)throw new ArgumentException("Yeni şifre öncekiyle aynı olamaz.");var identity=new HttpsSqlHesapDeposu(connection).Dogrula(new(input.Kullanici,input.Eski),true);using var c=new SqlConnection(connection);c.Open();using var t=c.BeginTransaction(IsolationLevel.Serializable);
        using(var q=new SqlCommand("SELECT SifreOzeti FROM dbo.Kullanicilar WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Aktif=1",c,t))
        {q.Parameters.AddWithValue("@id",identity.Kullanici.Id);if(q.ExecuteScalar() is not string hash||HttpsSqlHesapDeposu.Damga(hash)!=identity.GuvenlikDamgasi)throw new UnauthorizedAccessException("Hesap bilgileri değişti.");}
        using(var q=new SqlCommand("UPDATE dbo.Kullanicilar SET SifreOzeti=@h,SifreDegistirmeli=0,BasarisizGirisSayisi=0,KilitBitisUtc=NULL WHERE Id=@id;UPDATE dbo.KullaniciKurtarmaKodlari SET GecersizUtc=SYSUTCDATETIME() WHERE KullaniciId=@id AND GecersizUtc IS NULL;DELETE dbo.KurtarmaKoduTeslimDurumu WHERE KullaniciId=@id;",c,t))
        {q.Parameters.AddWithValue("@id",identity.Kullanici.Id);q.Parameters.Add("@h",SqlDbType.NVarChar,512).Value=GirisPenceresi.SifreOzetiOlustur(input.Yeni);q.ExecuteNonQuery();}t.Commit();
    }
    internal void Kurtar(HttpsSifreKurtarma input){Parola(input.Yeni);if(input.Kullanici is null||input.Kullanici.Length is <1 or >60||input.Kod is null||input.Kod.Length>80)throw new ArgumentException("Kurtarma alanlarını kontrol edin.");if(!GirisPenceresi.KurtarmaKoduIleSifreSifirla(connection,input.Kullanici,input.Kod,input.Yeni))throw new UnauthorizedAccessException("Kullanıcı veya kurtarma kodu doğrulanamadı.");}
}
