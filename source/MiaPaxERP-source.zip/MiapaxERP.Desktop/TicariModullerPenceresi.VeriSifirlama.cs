using SqlConnection = MiapaxERP.Desktop.ErpSqlConnection;
using SqlCommand = MiapaxERP.Desktop.ErpSqlCommand;
using SqlTransaction = MiapaxERP.Desktop.ErpSqlTransaction;
using SqlDataReader = MiapaxERP.Desktop.ErpSqlReader;
using SqlDataAdapter = MiapaxERP.Desktop.ErpSqlDataAdapter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using Microsoft.Data.SqlClient;

namespace MiapaxERP.Desktop
{
    public partial class TicariModullerPaneli
    {
        private void VeriSifirla_Click(object sender, RoutedEventArgs e)
        {
            if (!ChkResetStok.IsChecked.GetValueOrDefault() && !ChkResetTicari.IsChecked.GetValueOrDefault())
            { MessageBox.Show("En az bir modül seçin."); return; }
            if (!ChkResetYedek.IsChecked.GetValueOrDefault() || TxtResetOnay.Text.Trim() != "VERILERI SIL")
            { MessageBox.Show("Yedek onayını işaretleyin ve VERILERI SIL yazın."); return; }
            try
            {
                if(HttpsOturumu.Uzak(baglantiAdresi))
                {
                    var service=new YardimciEkranServisi(baglantiAdresi,kullaniciId);string database=service.VeritabaniAdi();
                    if(TxtResetVeritabani.Text.Trim()!=database)throw new ArgumentException("Bağlı veritabanının adını aynen yazın: "+database);
                    if(MessageBox.Show("DİKKAT: '"+database+"' veritabanındaki seçili kayıtlar kalıcı silinecek. Yedekten geri dönebileceğinizden emin misiniz?","Son onay",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;
                    int count=service.VeriSifirla(ChkResetStok.IsChecked==true,ChkResetTicari.IsChecked==true,database,TxtResetOnay.Text.Trim(),ChkResetYedek.IsChecked==true);
                    MessageBox.Show("İşlem tamamlandı. Tablo sayısı: "+count);TxtResetOnay.Clear();TxtResetVeritabani.Clear();ChkResetYedek.IsChecked=false;return;
                }
                using var con = Baglan();
                var db = con.Database;
                // Canlı veritabanında da kullanılabilir; adı ve silme onayı açıkça istenir.
                if (!string.Equals(TxtResetVeritabani.Text.Trim(), db, StringComparison.Ordinal))
                { MessageBox.Show("Bağlı veritabanının adını aynen yazmalısınız: " + db); return; }
                using (var admin = new SqlCommand(@"SELECT COUNT(*) FROM dbo.KullaniciRolAtamalari a
 JOIN dbo.KullaniciRolleri r ON r.Id=a.RolId
 WHERE a.KullaniciId=@uid AND r.RolAdi=N'Yönetici'", con))
                {
                    admin.Parameters.AddWithValue("@uid", kullaniciId);
                    if (Convert.ToInt32(admin.ExecuteScalar()) == 0)
                    { MessageBox.Show("Yalnızca Yönetici rolü bu işlemi yapabilir."); return; }
                }
                if (MessageBox.Show("DİKKAT: '" + db + "' veritabanındaki seçili kayıtlar KALICI olarak silinecek! SQL yedeğinizi geri yükleyebileceğinizden emin misiniz?",
                    "Son onay", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
                // Yalnızca operasyonel kayıt tabloları. Kullanıcılar, roller, ayarlar ve stok tipleri korunur.
                var stock = new[] { "UretimEmriReceteAnlikKalemleri", "UretimPaketlemeKayitlari",
                    "UretimGunlukKayitlari", "StokHareketleri", "UretimStokIslemleri",
                    "UretimEmirleri", "UretimReceteKalemleri", "UretimReceteleri",
                    "UrunGorselleri", "StokOzellikDegerleri", "StokKategoriSecimleri",
                    "StokBakiyeleri", "StokKartlari", "StokKategorileri", "StokOzellikTanimlari",
                    "StokAlimKayitlari", "StokFiyatlari", "StokAileleri", "PiyasaFiyatlari" };
                var commerce = new[] { "CekSenetDurumGecmisi", "CekSenetler", "PlanliOdemeler",
                    "BoruERP_YeniBelgeKalemleri", "BoruERP_YeniBelgeler", "BoruERP_YeniMasraflar",
                    "BoruERP_GelenEFaturalar", "TicariBelgeler", "FinansHareketleri",
                    "CariHareketleri", "FinansHesaplari", "CariKartlari" };
                var chosen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                if (ChkResetStok.IsChecked == true) foreach (var s in stock) chosen.Add(s);
                if (ChkResetTicari.IsChecked == true) foreach (var s in commerce) chosen.Add(s);
                using var tran = con.BeginTransaction();
                try
                {
                    // Yalnızca mevcut tabloları kullan; seçili olmayan tablodan FK varsa silmeyi reddet.
                    var present = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    using (var cmd = new SqlCommand("SELECT name FROM sys.tables WHERE schema_id=SCHEMA_ID('dbo')", con, tran))
                    using (var rd = cmd.ExecuteReader()) while (rd.Read()) present.Add(rd.GetString(0));
                    chosen.IntersectWith(present);
                    var edges = new List<(string child,string parent)>();
                    using (var cmd = new SqlCommand(@"SELECT OBJECT_NAME(parent_object_id), OBJECT_NAME(referenced_object_id)
 FROM sys.foreign_keys WHERE is_disabled=0", con, tran))
                    using (var rd = cmd.ExecuteReader()) while (rd.Read())
                        edges.Add((rd.GetString(0), rd.GetString(1)));
                    foreach (var relation in edges)
                        if (chosen.Contains(relation.parent) && !chosen.Contains(relation.child))
                            throw new InvalidOperationException("Seçilmeyen '" + relation.child + "' tablosu, silinecek '" + relation.parent + "' tablosuna bağlı. İlgili modülleri birlikte seçin.");
                    // Bağımlı (child) tablolar önce silinir. Döngüsel FK varsa işlem güvenli biçimde iptal edilir.
                    var pending = new HashSet<string>(chosen, StringComparer.OrdinalIgnoreCase);
                    var ordered = new List<string>();
                    while (pending.Count > 0)
                    {
                        string? next = pending.FirstOrDefault(name => !edges.Any(relation =>
                            relation.parent.Equals(name, StringComparison.OrdinalIgnoreCase) &&
                            pending.Contains(relation.child) && !relation.child.Equals(name, StringComparison.OrdinalIgnoreCase)));
                        if (next == null) throw new InvalidOperationException("Döngüsel veya kendi kendine bağlı tablo ilişkisi var; sıfırlama iptal edildi.");
                        ordered.Add(next); pending.Remove(next);
                    }
                    foreach (var name in ordered)
                    {
                        // Tablo adları yalnızca yukarıdaki sabit listeden gelir.
                        using var cmd = new SqlCommand("DELETE FROM dbo.[" + name + "]", con, tran);
                        cmd.CommandTimeout = 120;
                        cmd.ExecuteNonQuery();
                    }
                    tran.Commit();
                    MessageBox.Show("Seçilen veriler temizlendi. İşlenen tablo sayısı: " + ordered.Count);
                    TxtResetOnay.Clear(); TxtResetVeritabani.Clear(); ChkResetYedek.IsChecked = false;
                }
                catch { tran.Rollback(); throw; }
            }
            catch (Exception ex) { MessageBox.Show("Sıfırlama yapılmadı / işlem geri alındı: " + ex.Message); }
        }
    }
}
