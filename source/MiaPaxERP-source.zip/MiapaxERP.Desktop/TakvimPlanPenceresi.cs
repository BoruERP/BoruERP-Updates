using System;
using System.Windows;
using System.Windows.Controls;
namespace MiapaxERP.Desktop {
public sealed class TakvimPlanPenceresi : Window {
 private readonly TextBox baslik=new(){Margin=new Thickness(0,4,0,10)};
 private readonly TextBox aciklama=new(){Margin=new Thickness(0,4,0,10),Height=60,TextWrapping=TextWrapping.Wrap,AcceptsReturn=true};
 private readonly ComboBox tur=new(){Margin=new Thickness(0,4,0,10)};
 private readonly DatePicker tarih=new(){Margin=new Thickness(0,4,0,10)};
 private readonly ComboBox saat=new(){ItemsSource=Enumerable.Range(0,24).Select(n=>n.ToString("00")),Width=80,Margin=new Thickness(0,4,8,10)};
 private readonly ComboBox dakika=new(){ItemsSource=Enumerable.Range(0,60).Select(n=>n.ToString("00")),Width=80,Margin=new Thickness(0,4,8,10)};
 public string PlanBaslik=>baslik.Text.Trim();public string PlanAciklama=>aciklama.Text.Trim();public string PlanTur=>tur.SelectedItem?.ToString()??"Diğer";
 public static DateTime OnerilenSaat(DateTime gun,DateTime now) => gun.Date==now.Date ? new DateTime(now.Ticks-now.Ticks%TimeSpan.TicksPerMinute).AddMinutes(15-now.Minute%15) : gun.Date.AddHours(9);
 public DateTime PlanTarihi {get=>tarih.SelectedDate.GetValueOrDefault(DateTime.Today).Date.AddHours(saat.SelectedIndex).AddMinutes(dakika.SelectedIndex);set{tarih.SelectedDate=value.Date;saat.SelectedIndex=value.Hour;dakika.SelectedIndex=value.Minute;}}
 public TakvimPlanPenceresi(){Title="MiapaxERP | Yeni İş Planı";Width=480;Height=560;WindowStartupLocation=WindowStartupLocation.CenterOwner;ResizeMode=ResizeMode.CanResize;
 var root=new StackPanel{Margin=new Thickness(20)};Content=new ScrollViewer {Content=root,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};
 void Alan(string ad,Control kontrol){root.Children.Add(new TextBlock{Text=ad,FontWeight=FontWeights.SemiBold});root.Children.Add(kontrol);}
 Alan("İşlem başlığı",baslik);Alan("Açıklama",aciklama);foreach(var s in new[]{"Ödeme","Hammadde transferi","Sevkiyat","Üretim","Tahsilat","Çek / Senet","Toplantı","Diğer"})tur.Items.Add(s);tur.SelectedIndex=0;
 Alan("İşlem türü",tur);Alan("Tarih",tarih);
 root.Children.Add(new TextBlock{Text="Saat / dakika"});var times=new StackPanel{Orientation=System.Windows.Controls.Orientation.Horizontal};times.Children.Add(saat);times.Children.Add(dakika);root.Children.Add(times);
 var quick=new WrapPanel();root.Children.Add(quick);
 foreach(var item in new[]{("Otomatik saat",0),("30 dk sonra",30),("1 saat sonra",60)}){var b=new Button{Content=item.Item1,Margin=new Thickness(0,0,6,8)};b.Click+=(_,_)=>PlanTarihi=item.Item2==0?OnerilenSaat(tarih.SelectedDate??DateTime.Today,DateTime.Now):DateTime.Now.AddMinutes(item.Item2);quick.Children.Add(b);}
 root.Children.Add(new TextBlock{Text="Otomatik: bugün bir sonraki 15 dakika; diğer günler 09:00. İstersen saat ve dakikayı değiştir.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,0,0,10)});
 PlanTarihi=OnerilenSaat(DateTime.Today,DateTime.Now);
 var kaydet=new Button{Content="Planı Kaydet",Height=36,Margin=new Thickness(0,6,0,0)};kaydet.Click+=(_,_)=>{if(PlanBaslik.Length<3||PlanBaslik.Length>180||saat.SelectedIndex<0||dakika.SelectedIndex<0||tarih.SelectedDate==null){MessageBox.Show("Başlık, tarih ve saat bilgilerini kontrol edin.");return;}DialogResult=true;};root.Children.Add(kaydet);
 }
}
}
