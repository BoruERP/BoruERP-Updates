using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using TabControl = System.Windows.Controls.TabControl;
using Cursors = System.Windows.Input.Cursors;

namespace MiapaxERP.Desktop;

public sealed record MuhasebeBolum(string Kod,string Baslik,string Yetki,string Aciklama);

/// <summary>Oturuma özel tek çalışma alanı. Kontroller gezinmede yeniden oluşturulmaz.</summary>
public sealed class MuhasebePaneli : UserControl
{
    public static readonly IReadOnlyList<MuhasebeBolum> Bolumler = new[] {
        new MuhasebeBolum("kasa","Kasa / Banka","FINANCE.VIEW","Hesap bakiyeleri, tahsilatlar ve ödemeler"),
        new MuhasebeBolum("gelir","Gelir / Gider","FINANCE.VIEW","Hesap planı, maliyet merkezleri ve gelir/gider özeti"),
        new MuhasebeBolum("cari","Cari hesaplar","CUSTOMER.VIEW","Müşteri ve tedarikçi kartları, borç ve alacak hareketleri"),
        new MuhasebeBolum("plan","Planlı ödemeler","FINANCE.VIEW","Vade takvimi ve ödeme takibi"),
        new MuhasebeBolum("cek","Çek / Senet","CHECKNOTE.VIEW","Alınan ve verilen evraklar, vadeler ve durumlar"),
        new MuhasebeBolum("belge","Alış / Satış belgeleri","FINANCE.VIEW","Cari hesaba bağlı ticari belgeler"),
        new MuhasebeBolum("teklif","Teklifler","CUSTOMER.VIEW","Ürün kalemleriyle teklif hazırlama ve takip"),
        new MuhasebeBolum("satis","Satışlar","CUSTOMER.VIEW","Satış belgeleri ve ödeme bilgileri"),
        new MuhasebeBolum("fatura","Gelen faturalar","FINANCE.VIEW","Tedarikçi faturalarını manuel kayıt ve takip"),
        new MuhasebeBolum("ebelge","E-Belge merkezi","FINANCE.VIEW","Hızlı Bilişim test bağlantısı, belge kutuları ve kalıcı UBL taslak takibi"),
        new MuhasebeBolum("bordro","Maaş bordroları","HR.PAYROLL.VIEW","Net / brüt ücret, kesintiler, tahakkuk ve kasa/banka ödemeleri"),
        new MuhasebeBolum("mutabakat","Mutabakat / BA-BS arşivi","FINANCE.RECONCILE.VIEW","Alış/satış karşılaştırması ve Eylül 2024 öncesi bildirimlerin arşivi"),
        new MuhasebeBolum("rapor","Raporlar","REPORT.VIEW","Cari, kasa/banka, stok ve üretim raporları")
    };
    private readonly string baglanti;
    private readonly int kullanici;
    private readonly string ad;
    private readonly Func<string,bool> yetki;
    private readonly Grid icerik = new();
    private readonly WrapPanel gezinme = new();
    private readonly Dictionary<string,Button> dugmeler = new();
    private readonly TextBlock baslik = new() { FontSize=21,FontWeight=FontWeights.SemiBold };
    private readonly TextBlock aciklama = new() { TextWrapping=TextWrapping.Wrap, Margin=new Thickness(0,5,0,8) };
    private readonly TextBlock durum = new() { Visibility=Visibility.Collapsed, TextWrapping=TextWrapping.Wrap,Margin=new Thickness(12,5,12,5) };
    private TicariModullerPaneli? temel;
    private TicariIslemlerPaneli? ticari;
    private GelirGiderPaneli? gelir;
    private EBelge.EbelgePaneli? ebelge;
    private Muhasebe280.BordroPaneli? bordro;
    private Muhasebe280.MutabakatPaneli? mutabakat;
    private GorunumTercihleri tema = new();
    public string? AktifBolum { get; private set; }
    public bool IslemSuruyor => gelir?.IslemSuruyor == true || ebelge?.IslemSuruyor == true;

    public MuhasebePaneli(string connectionString,int userId,string userName,Func<string,bool> yetkiKontrol)
    {
        baglanti=connectionString;kullanici=userId;ad=userName;yetki=yetkiKontrol;
        var root=new DockPanel();Content=root;
        var header=new StackPanel { Margin=new Thickness(14,10,14,8) };
        DockPanel.SetDock(header,Dock.Top);root.Children.Add(header);
        header.Children.Add(baslik);header.Children.Add(aciklama);header.Children.Add(gezinme);
        var hazirla=new Button{Content="Yeni muhasebe modüllerini hazırla",Padding=new Thickness(12,8,12,8),Margin=new Thickness(0,0,6,6)};
        hazirla.Click+=(_,_)=>{try{new EBelge.EbelgeDeposu(baglanti,kullanici).Kur();new Muhasebe280.BordroDeposu(baglanti,kullanici).Kur();durum.Visibility=Visibility.Visible;durum.Text="Muhasebe modülleri hazırlandı. Yeni yetkileri kullanıcı rollerinden tanımlayabilirsiniz.";}catch(Exception ex){durum.Visibility=Visibility.Visible;durum.Text="Hazırlama tamamlanamadı: "+ex.Message;}};
        gezinme.Children.Add(hazirla);
        DockPanel.SetDock(durum,Dock.Bottom);root.Children.Add(durum);root.Children.Add(icerik);
        foreach(var b in Bolumler)
        {
            var button=new Button { Content=b.Baslik,ToolTip=b.Aciklama,Padding=new Thickness(12,8,12,8),Margin=new Thickness(0,0,6,6),BorderThickness=new Thickness(0),Cursor=Cursors.Hand };
            button.Click+=(_,_)=>Ac(b.Kod);gezinme.Children.Add(button);dugmeler.Add(b.Kod,button);
        }
        TemayiUygula(GorunumDeposu.Oku(GorunumDeposu.Klasor(baglanti,kullanici)));
    }
    public bool Ac(string? kod)
    {
        if(IslemSuruyor){durum.Visibility=Visibility.Visible;durum.Text="İşlem sürüyor. Tamamlandığında bölüm değiştirebilirsiniz.";return false;}
        try
        {
            kod ??= AktifBolum is not null and not "ayar" ? AktifBolum : Bolumler.FirstOrDefault(b=>yetki(b.Yetki))?.Kod;
            var bolum=kod=="ayar" ? new MuhasebeBolum("ayar","Ayarlar","SETTINGS.VIEW","Kullanıcıya özel görünüm ve sistem ayarları") : Bolumler.FirstOrDefault(b=>b.Kod==kod);
            if(bolum==null || !yetki(bolum.Yetki)) { durum.Visibility=Visibility.Visible;durum.Text="Bu bölüme erişim yetkiniz bulunmuyor.";return false; }
            UserControl hedef;
            switch(bolum.Kod)
            {
                case "mutabakat":
                    if(mutabakat==null){mutabakat=new Muhasebe280.MutabakatPaneli(baglanti,kullanici);Ekle(mutabakat);}hedef=mutabakat;break;
                case "bordro":
                    if(bordro==null){bordro=new Muhasebe280.BordroPaneli(baglanti,kullanici);Ekle(bordro);}hedef=bordro;break;
                case "ebelge":
                    if(ebelge==null){ebelge=new EBelge.EbelgePaneli(baglanti,kullanici);Ekle(ebelge);}hedef=ebelge;break;
                case "gelir":
                    if(gelir==null){gelir=new GelirGiderPaneli(baglanti,kullanici);Ekle(gelir);}
                    hedef=gelir;
                    if(gelir.IsLoaded) _=gelir.YenileAsync();
                    break;
                case "teklif":case "satis":case "fatura":
                    if(ticari==null){ticari=new TicariIslemlerPaneli(baglanti,kullanici);ticari.BolumIstendi+=Istendi;Ekle(ticari);}
                    hedef=ticari;ticari.BolumAc(bolum.Kod);break;
                default:
                    int tab=bolum.Kod switch{"cari"=>0,"rapor"=>2,"ayar"=>3,_=>1};
                    int alt=bolum.Kod switch{"belge"=>1,"plan"=>2,"cek"=>3,_=>0};
                    if(temel==null){temel=new TicariModullerPaneli(baglanti,kullanici,ad,tab);temel.BolumIstendi+=Istendi;Ekle(temel);}
                    hedef=temel;temel.BolumAc(tab,alt);break;
            }
            foreach(UIElement child in icerik.Children)child.Visibility=ReferenceEquals(child,hedef)?Visibility.Visible:Visibility.Collapsed;
            AktifBolum=bolum.Kod;baslik.Text=bolum.Baslik;aciklama.Text=bolum.Aciklama;
            gezinme.Visibility=kod=="ayar"?Visibility.Collapsed:Visibility.Visible;
            durum.Text="";durum.Visibility=Visibility.Collapsed;
            SecimiBoya();return true;
        }
        catch(Exception ex){durum.Visibility=Visibility.Visible;durum.Text="Bölüm açılamadı: "+ex.Message;return false;}
    }
    public string? RehberBolumu => AktifBolum=="gelir" && gelir?.FindName("GelirGiderSekmeleri") is TabControl tabs ? tabs.SelectedIndex switch {2=>"merkez",3=>"eski",_=>"gelir"} : AktifBolum;
    public FrameworkElement? RehberHedefi(string name) {
        if(AktifBolum=="gelir")return gelir?.FindName(name) as FrameworkElement;
        if(AktifBolum is "teklif" or "satis" or "fatura")return ticari?.FindName(name) as FrameworkElement;
        return temel?.FindName(name) as FrameworkElement;
    }
    public void RehberGelirSekmesi(int index) {
        if(gelir?.FindName("GelirGiderSekmeleri") is TabControl tabs)tabs.SelectedIndex=index;
    }
    private void Istendi(string kod)=>Ac(kod);
    private void Ekle(UserControl kontrol)
    {
        kontrol.Visibility=Visibility.Collapsed;icerik.Children.Add(kontrol);
        GorunumRenkleri.Uygula(kontrol,tema);
    }
    public void TemayiUygula(GorunumTercihleri a)
    {
        tema=a;
        bool dark=a.Tema=="Koyu" || (a.Tema=="Sistem" && Convert.ToInt32(Microsoft.Win32.Registry.GetValue(@"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize","AppsUseLightTheme",1))==0);
        Background=new SolidColorBrush((Color)ColorConverter.ConvertFromString(dark?"#0F172A":"#F1F5F9"));
        Foreground=dark?Brushes.White:Brushes.Black;FontFamily=new FontFamily(a.YaziTipi);
        foreach(Control c in icerik.Children)GorunumRenkleri.Uygula(c,a);
        SecimiBoya();
    }
    private void SecimiBoya()
    {
        foreach(var (kod,b) in dugmeler)
        {
            bool selected=kod==AktifBolum;
            b.Background=selected?(Brush)new BrushConverter().ConvertFromString(tema.Vurgu)!:Brushes.White;
            b.Foreground=selected?Brushes.White:Brushes.Black;
            b.FontWeight=selected?FontWeights.SemiBold:FontWeights.Normal;
            System.Windows.Automation.AutomationProperties.SetItemStatus(b,selected?"Seçili":"");
        }
    }
}

internal static class MuhasebeGorunum
{
    internal static void SekmeBasliklariniGizle(TabControl tabs)
    {
        var presenter=new FrameworkElementFactory(typeof(ContentPresenter));
        presenter.Name="PART_SelectedContentHost";
        presenter.SetBinding(ContentPresenter.ContentProperty,new System.Windows.Data.Binding("SelectedContent"){RelativeSource=RelativeSource.TemplatedParent});
        var template=new ControlTemplate(typeof(TabControl)){VisualTree=presenter};
        tabs.Template=template;tabs.BorderThickness=new Thickness(0);tabs.Margin=new Thickness(0);
        tabs.PreviewKeyDown+=(_,e)=>{if(e.Key==Key.Tab && (Keyboard.Modifiers&ModifierKeys.Control)!=0)e.Handled=true;};
    }
}

public partial class TicariModullerPaneli
{
    public event Action<string>? BolumIstendi;
    public void BolumAc(int bolum,int finansAlt)
    {
        istenenBolum=bolum;
        bool degisti=Sekmeler.SelectedIndex!=bolum;
        FinansSekmeleri.SelectedIndex=finansAlt;Sekmeler.SelectedIndex=bolum;
        if(panelHazir && !degisti)Calistir(()=>BolumuYukle(bolum));
    }
}
public partial class TicariIslemlerPaneli
{
    public event Action<string>? BolumIstendi;
    public void BolumAc(string bolum)
    {
        int index=bolum=="teklif"?0:bolum=="satis"?1:2;
        IslemSekmeleri.SelectedIndex=index;
        if(index==2)NakitAltSekmeler.SelectedIndex=2;
        if(!ekranHazir)return;
        try {if(index==0)TeklifleriListele();else if(index==1)SatislariListele();else EfaturalariListele();}
        catch(Exception ex){TxtDurum.Text="Yükleme uyarısı: "+ex.Message;}
    }
}
