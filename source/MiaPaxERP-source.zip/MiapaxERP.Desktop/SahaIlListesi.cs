using System.Data;
namespace MiapaxERP.Desktop;

public sealed record SahaGorusulenKisi(Guid Id,string Ad,string Telefon,string IlceId,string Koy,DateTime SonGorusme,string Sonuc);
public sealed record SahaIlSayfasi(SahaGorusulenKisi[] Rows,bool HasMore,int NextOffset);
public sealed partial class SahaServisi
{
 public SahaIlSayfasi IlGorusmeleri(string il,string? ilce=null,string? search=null,int offset=0){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<SahaIlSayfasi>(connection,"SahaServisi.IlGorusmeleri","",new object?[]{il,ilce,search,offset});}

  LisansOturumu.Gerekli("CRM");ilce??="";search=(search??"").Trim();
  if(string.IsNullOrWhiteSpace(il)||il.Length>30||ilce.Length>40||search.Length>160||offset<0||offset>int.MaxValue-101)throw new ArgumentException("İl, ilçe, arama veya sayfa bilgisi geçersiz.");
  using var c=access.Ac();Yetki(c,null,"FIELD.VIEW");
  using var q=ErpModulServisi.Komut(c,null,"""
   WITH contacts AS(
    SELECT m.Id,m.Ad,m.Telefon,m.IlceId,m.Koy,g.Tarih,LEFT(g.Sonuc,160) AS Sonuc,
     ROW_NUMBER() OVER(PARTITION BY m.Id ORDER BY g.Tarih DESC,g.KayitZamani DESC,g.Id DESC) AS rn
    FROM dbo.BERP210_SahaMusteri m JOIN dbo.BERP210_Gorusme g ON g.MusteriId=m.Id
    WHERE m.IlId=@il AND (@district=N'' OR m.IlceId=@district)
     AND (@own=0 OR m.Olusturan=@user)
     AND (@search=N'' OR CHARINDEX(@search,m.Ad)>0 OR CHARINDEX(@search,m.Telefon)>0)
   )
   SELECT Id,Ad,Telefon,IlceId,Koy,Tarih,Sonuc FROM contacts WHERE rn=1
   ORDER BY Tarih DESC,Ad,Id
   OFFSET @offset ROWS FETCH NEXT 101 ROWS ONLY
   """,("@il",il),("@district",ilce),("@own",Own),("@user",user),("@search",search),("@offset",offset));
  using var reader=q.ExecuteReader();var rows=new List<SahaGorusulenKisi>();
  while(reader.Read())rows.Add(new(reader.GetGuid(0),reader.GetString(1),reader.GetString(2),reader.GetString(3),reader.GetString(4),DateTime.SpecifyKind(reader.GetDateTime(5),DateTimeKind.Utc),reader.GetString(6)));
  bool more=rows.Count>100;if(more)rows.RemoveAt(100);return new(rows.ToArray(),more,offset+rows.Count);
 }
}
