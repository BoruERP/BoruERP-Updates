using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Data.Sqlite;

namespace MiapaxERP.Desktop
{
    public static class DemoVeritabani
    {
        // Demo verileri uygulamanın yanında saklanır.
        public static readonly string DosyaYolu =
            Path.Combine(
                AppContext.BaseDirectory,
                "MiapaxERP-Demo.db");

        public static string BaglantiAdresi =>
            new SqliteConnectionStringBuilder
            {
                DataSource = DosyaYolu
            }.ToString();

        public static void Hazirla()
        {
            using (SqliteConnection baglanti =
                new SqliteConnection(BaglantiAdresi))
            {
                baglanti.Open();

                string tabloSorgusu = @"
                    CREATE TABLE IF NOT EXISTS StokKartlari
                    (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        StokKodu TEXT NOT NULL UNIQUE,
                        StokAdi TEXT NOT NULL,
                        StokTipi TEXT NOT NULL,
                        Birim TEXT NOT NULL,
                        Aciklama TEXT,
                        Aktif INTEGER NOT NULL DEFAULT 1,
                        KayitTarihi TEXT NOT NULL
                            DEFAULT CURRENT_TIMESTAMP
                    );";

                using (SqliteCommand komut =
                    new SqliteCommand(tabloSorgusu, baglanti))
                {
                    komut.ExecuteNonQuery();
                }

                // Var olan stokları koruyarak yalnızca eksik alanları ekle.
                StokOzellikAlanlariniHazirla(baglanti);

                DemoStokEkle(
                    baglanti,
                    "HM-001",
                    "Polietilen PE100",
                    "Hammadde",
                    "KG",
                    "Boru üretiminde kullanılan hammadde");

                DemoStokEkle(
                    baglanti,
                    "HM-002",
                    "Siyah Masterbatch",
                    "Hammadde",
                    "KG",
                    "Boru üretiminde kullanılan renklendirici");
            }
        }

        private static void StokOzellikAlanlariniHazirla(SqliteConnection baglanti)
        {
            HashSet<string> mevcutAlanlar =
                new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            using (SqliteCommand komut = baglanti.CreateCommand())
            {
                komut.CommandText = "PRAGMA table_info(StokKartlari);";

                using (SqliteDataReader okuyucu = komut.ExecuteReader())
                {
                    while (okuyucu.Read())
                    {
                        mevcutAlanlar.Add(okuyucu.GetString(1));
                    }
                }
            }

            // SQLite'da sayısal ölçüler REAL, açıklama türündeki alanlar TEXT.
            // NULL kabul ettikleri için eski stok kayıtları değişmeden kalır.
            (string Ad, string Tur)[] yeniAlanlar =
            {
                ("CapMm", "REAL"),
                ("BasincSinifi", "TEXT"),
                ("UzunlukMetre", "REAL"),
                ("Renk", "TEXT"),
                ("EtKalinligiMm", "REAL"),
                ("HammaddeTuru", "TEXT"),
                ("AgirlikKg", "REAL")
            };

            using (SqliteTransaction islem = baglanti.BeginTransaction())
            {
                foreach ((string ad, string tur) in yeniAlanlar)
                {
                    if (mevcutAlanlar.Contains(ad))
                        continue;

                    using (SqliteCommand komut = baglanti.CreateCommand())
                    {
                        komut.Transaction = islem;
                        komut.CommandText =
                            $"ALTER TABLE StokKartlari ADD COLUMN \"{ad}\" {tur} NULL;";
                        komut.ExecuteNonQuery();
                    }
                }

                islem.Commit();
            }
        }

        private static void DemoStokEkle(
            SqliteConnection baglanti,
            string stokKodu,
            string stokAdi,
            string stokTipi,
            string birim,
            string aciklama)
        {
            string sorgu = @"
                INSERT INTO StokKartlari
                (StokKodu, StokAdi, StokTipi, Birim, Aciklama)
                SELECT
                @StokKodu, @StokAdi, @StokTipi, @Birim, @Aciklama
                WHERE NOT EXISTS
                (
                    SELECT 1
                    FROM StokKartlari
                    WHERE StokKodu = @StokKodu
                );";

            using (SqliteCommand komut =
                new SqliteCommand(sorgu, baglanti))
            {
                komut.Parameters.AddWithValue("@StokKodu", stokKodu);
                komut.Parameters.AddWithValue("@StokAdi", stokAdi);
                komut.Parameters.AddWithValue("@StokTipi", stokTipi);
                komut.Parameters.AddWithValue("@Birim", birim);
                komut.Parameters.AddWithValue("@Aciklama", aciklama);

                komut.ExecuteNonQuery();
            }
        }
    }
}
