using System.Data;
using System.IO;
using System.Text.Json;
using MiapaxERP.Lisans.Core;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

public sealed record ReceteBileseni(int StokId,decimal Miktar);
public sealed record StokTuketimi(int StokId,string Birim,decimal Miktar);
public sealed class SektorUretimServisi(string connection,int user)
{
    readonly ErpModulServisi access=new(connection,user);
    internal static SqlCommand Q(SqlConnection c,SqlTransaction? tx,string sql,params(string,object?)[] p)=>ErpModulServisi.Komut(c,tx,sql,p);
    public void Kur()
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"SektorUretimServisi.Kur","",new object?[]{});return;}

        LisansOturumu.Gerekli("STOK");ModulKurulumu180.Hazirla(connection,user);using var c=access.Ac();
        using(var q=Q(c,null,"SELECT COUNT(*) FROM dbo.BERP_Sema WHERE Surum=200"))if(Convert.ToInt32(q.ExecuteScalar())==1)return;
        access.Yetki(c,null,"MODULES.INSTALL");using var cmd=Q(c,null,File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"Moduller200.sql")));cmd.ExecuteNonQuery();
    }
    public DataTable Oku(string kind)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"SektorUretimServisi.Oku","",new object?[]{kind});}

        LisansOturumu.Gerekli("URETIM");using var c=access.Ac();access.Yetki(c,null,"PRODUCTION.VIEW");
        string sql=kind switch{
            "stok"=>"SELECT Id,StokKodu,StokAdi,Birim,StokKodu+N' · '+StokAdi+N' ('+Birim+N')' AS Secim FROM dbo.StokKartlari WHERE Aktif=1 ORDER BY StokAdi",
            "recete"=>"SELECT r.Id,r.Kod,r.Ad,r.Sektor,r.MamulId,s.StokAdi,r.CiktiBirimi,r.FireYuzde,r.Surum FROM dbo.BERP200_Recete r JOIN dbo.StokKartlari s ON s.Id=r.MamulId WHERE r.Aktif=1 ORDER BY r.Id DESC",
            "uretim"=>"SELECT TOP(300) u.Id,u.Tarih,u.Belge,r.Ad,u.Miktar,r.CiktiBirimi FROM dbo.BERP200_Uretim u JOIN dbo.BERP200_Recete r ON r.Id=u.ReceteId ORDER BY u.Id DESC",
            _=>throw new ArgumentException("Liste bulunamadı.")};
        using var q=Q(c,null,sql);using var r=q.ExecuteReader();var t=new DataTable();t.Load(r);return t;
    }
    internal static string Birim(SqlConnection c,SqlTransaction tx,int id)
    {
        using var q=Q(c,tx,"SELECT Birim FROM dbo.StokKartlari WITH(UPDLOCK,HOLDLOCK) WHERE Id=@s AND Aktif=1",("@s",id));
        return q.ExecuteScalar() as string??throw new ArgumentException("Aktif stok kartı bulunamadı.");
    }
    public long ReceteKaydet(string kod,string ad,int output,decimal fire,string sector,ReceteBileseni[] items)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"SektorUretimServisi.ReceteKaydet","",new object?[]{kod,ad,output,fire,sector,items});}

        LisansOturumu.Gerekli("URETIM");UrunKatalogu.SektorBul(sector);
        if(LisansOturumu.Zorunlu&&sector!=LisansOturumu.SektorKodu)throw new UnauthorizedAccessException("Lisans sektöründen farklı reçete oluşturulamaz.");
        if(string.IsNullOrWhiteSpace(kod)||kod.Length>50||string.IsNullOrWhiteSpace(ad)||ad.Length>160||fire<0||fire>100||decimal.Round(fire,3)!=fire||items.Length is 0 or >200||items.Any(x=>x.StokId==output||x.Miktar<=0||x.Miktar>1000000000||decimal.Round(x.Miktar,6)!=x.Miktar)||items.Select(x=>x.StokId).Distinct().Count()!=items.Length)throw new ArgumentException("Reçete kodu, ad, açık miktarlar ve %0–100 fire ek tüketim oranını kontrol edin.");
        using var c=access.Ac();using var tx=c.BeginTransaction(IsolationLevel.Serializable);access.Yetki(c,tx,"PRODUCTION.RECIPE");
        var unit=Birim(c,tx,output);using var q=Q(c,tx,"INSERT dbo.BERP200_Recete(Kod,Ad,Sektor,MamulId,CiktiBirimi,FireYuzde) OUTPUT INSERTED.Id VALUES(@k,@a,@s,@o,@b,@f)",("@k",kod.Trim()),("@a",ad.Trim()),("@s",sector),("@o",output),("@b",unit),("@f",fire));long id=Convert.ToInt64(q.ExecuteScalar());
        foreach(var item in items.OrderBy(x=>x.StokId))
        {string inputUnit=Birim(c,tx,item.StokId);using var row=Q(c,tx,"INSERT dbo.BERP200_ReceteKalem(ReceteId,StokId,Birim,BirimCiktiIcinMiktar)VALUES(@r,@s,@b,@m)",("@r",id),("@s",item.StokId),("@b",inputUnit),("@m",item.Miktar));var p=row.Parameters["@m"];p.Scale=6;row.ExecuteNonQuery();}
        tx.Commit();return id;
    }
    public static decimal TuketimHesapla(decimal perUnit,decimal output,decimal extraWaste)
    {
        if(perUnit<=0||output<=0||extraWaste<0||extraWaste>100)throw new ArgumentException("Pozitif reçete ve üretim miktarı ile açık fire oranı gerekli.");
        return decimal.Ceiling(checked(perUnit*output*(1+extraWaste/100))*1000)/1000;
    }
    internal static List<StokTuketimi> Hesapla(SqlConnection c,SqlTransaction tx,long recipe,decimal amount,int expectedOutput=0)
    {
        decimal waste;int product;string outputUnit;
        using(var q=Q(c,tx,"SELECT MamulId,CiktiBirimi,FireYuzde FROM dbo.BERP200_Recete WITH(HOLDLOCK) WHERE Id=@r AND Aktif=1",("@r",recipe)))
        {using var rd=q.ExecuteReader();if(!rd.Read())throw new ArgumentException("Aktif reçete bulunamadı.");product=rd.GetInt32(0);outputUnit=rd.GetString(1);waste=rd.GetDecimal(2);}
        if(expectedOutput!=0&&product!=expectedOutput)throw new ArgumentException("Menü ve reçete mamulü uyuşmuyor.");
        if(Birim(c,tx,product)!=outputUnit)throw new ArgumentException("Mamul stok birimi reçeteden sonra değişmiş.");
        var result=new List<StokTuketimi>();
        using(var q=Q(c,tx,"SELECT StokId,Birim,BirimCiktiIcinMiktar FROM dbo.BERP200_ReceteKalem WITH(HOLDLOCK) WHERE ReceteId=@r ORDER BY StokId",("@r",recipe)))
        {using var rd=q.ExecuteReader();while(rd.Read())result.Add(new(rd.GetInt32(0),rd.GetString(1),TuketimHesapla(rd.GetDecimal(2),amount,waste)));}
        if(result.Count==0)throw new ArgumentException("Reçete kalemleri boş.");return result;
    }
    internal static void Hareket(SqlConnection c,SqlTransaction tx,StokTuketimi item,bool inbound,string note)
    {
        if(Birim(c,tx,item.StokId)!=item.Birim)throw new ArgumentException("Stok birimi reçeteyle uyuşmuyor; otomatik dönüşüm yapılmadı.");
        using var q=Q(c,tx,inbound?"IF EXISTS(SELECT 1 FROM dbo.StokBakiyeleri WITH(UPDLOCK,HOLDLOCK) WHERE StokKartId=@s AND Birim<>@b) THROW 51000,N'Bakiye birimi uyuşmuyor.',1; UPDATE dbo.StokBakiyeleri WITH(UPDLOCK,HOLDLOCK) SET Miktar=Miktar+@m,SonGuncelleme=SYSDATETIME() WHERE StokKartId=@s; IF @@ROWCOUNT=0 INSERT dbo.StokBakiyeleri(StokKartId,Birim,Miktar) VALUES(@s,@b,@m);":"UPDATE dbo.StokBakiyeleri WITH(UPDLOCK,HOLDLOCK) SET Miktar=Miktar-@m,SonGuncelleme=SYSDATETIME() WHERE StokKartId=@s AND Birim=@b AND Miktar>=@m; IF @@ROWCOUNT<>1 THROW 51000,N'Stok yetersiz veya bakiye birimi farklı.',1;",("@s",item.StokId),("@b",item.Birim),("@m",item.Miktar));q.ExecuteNonQuery();
        using var move=Q(c,tx,"INSERT dbo.StokHareketleri(StokKartId,HareketTipi,Yon,Miktar,Birim,Aciklama)VALUES(@s,@t,@y,@m,@b,@n)",("@s",item.StokId),("@t",inbound?"SEKTOR_GIRIS":"SEKTOR_TUKETIM"),("@y",inbound?"G":"C"),("@m",item.Miktar),("@b",item.Birim),("@n",note));move.ExecuteNonQuery();
    }
    public long Uret(Guid key,long recipe,decimal amount,string document)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"SektorUretimServisi.Uret","",new object?[]{key,recipe,amount,document});}

        LisansOturumu.Gerekli("URETIM");if(key==Guid.Empty||amount<=0||amount>1000000000||decimal.Round(amount,3)!=amount||string.IsNullOrWhiteSpace(document)||document.Length>80)throw new ArgumentException("Üretim miktarı en fazla 3 ondalıklı, belge no dolu olmalı.");
        var digest=LisansKripto.Ozet(JsonSerializer.Serialize(new{recipe,amount,document}));
        using var c=access.Ac();using var tx=c.BeginTransaction(IsolationLevel.Serializable);access.Yetki(c,tx,"PRODUCTION.COMPLETE");
        using(var old=Q(c,tx,"SELECT Id,IstekOzeti FROM dbo.BERP200_Uretim WITH(UPDLOCK,HOLDLOCK) WHERE Anahtar=@k",("@k",key)))
        {using var rd=old.ExecuteReader();if(rd.Read()){long id=rd.GetInt64(0);if(rd.GetString(1)!=digest)throw new ArgumentException("İşlem anahtarı farklı üretimde kullanılmış.");rd.Close();tx.Commit();return id;}}
        var items=Hesapla(c,tx,recipe,amount);
        int output;string unit;using(var q=Q(c,tx,"SELECT MamulId,CiktiBirimi FROM dbo.BERP200_Recete WHERE Id=@r",("@r",recipe))){using var rd=q.ExecuteReader();rd.Read();output=rd.GetInt32(0);unit=rd.GetString(1);}
        foreach(var item in items.OrderBy(x=>x.StokId))Hareket(c,tx,item,false,"Sektör üretimi: "+document);
        Hareket(c,tx,new(output,unit,amount),true,"Sektör üretimi: "+document);
        using var insert=Q(c,tx,"INSERT dbo.BERP200_Uretim(Anahtar,IstekOzeti,ReceteId,Miktar,Belge,KullaniciId,Detay) OUTPUT INSERTED.Id VALUES(@k,@h,@r,@m,@b,@u,@d)",("@k",key),("@h",digest),("@r",recipe),("@m",amount),("@b",document.Trim()),("@u",user),("@d",JsonSerializer.Serialize(items)));long result=Convert.ToInt64(insert.ExecuteScalar());tx.Commit();return result;
    }
}
