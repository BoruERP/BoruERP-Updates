using System.Windows;
namespace MiapaxERP.Desktop;
public partial class MainWindow
{
    void UzakOturumuKabul(HttpsIstemci client)
    {
        var session=client.Oturum??throw new UnauthorizedAccessException("Önce sunucuya giriş yapın.");
        aktifKullanici=new(){KullaniciId=session.Kullanici.Id,KullaniciAdi=session.Kullanici.KullaniciAdi,AdSoyad=session.Kullanici.AdSoyad,Roller=session.Kullanici.Roller};
        try
        {
            TakvimOturumunuTemizle();GorunumYukle();gorunum.Sektor=session.Sektor;GorunumuUygula(gorunum.Kopya());LisansMenuUygula();
            KayitBeklemeKatmani.Visibility=string.Equals(aktifKullanici.Roller.Trim(),"Kısıtlı Kullanıcı",StringComparison.OrdinalIgnoreCase)?Visibility.Visible:Visibility.Collapsed;
            BtnBildirimler.Visibility=aktifKullanici.Roller.Split(',').Any(x=>x.Trim()=="Yönetici")?Visibility.Visible:Visibility.Collapsed;
            ProfilBilgisiniYenile();StokYetkiGorunumuYenile();IsEnabled=true;agBagli=true;AgDurumunuEkranaYansit();bildirimZamanlayici.Start();_ = BildirimleriYenileAsync(false);YardimOturumAcildi();_ = AnaSayfaVerileriniYukleAsync();_ = AnaSayfaTicariYukleAsync();Dispatcher.BeginInvoke(new Action(()=>{TakvimYenile();TakvimAcilisUyarisi();}));
        }
        catch(Exception e){MessageBox.Show(this,"Sunucu oturumu açıldı; ekran verileri yüklenemedi: "+e.Message,"MiaPaxERP");IsEnabled=true;}
    }
}
