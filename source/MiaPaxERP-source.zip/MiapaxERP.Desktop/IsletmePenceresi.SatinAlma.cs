using System.Data;
namespace MiapaxERP.Desktop;
public sealed partial class IsletmePenceresi
{
    void ConfigurePurchase()
    {
        Action("Yeni sipariş",async()=>
        {
            var f=new IsletmeForm(this,"Satın alma siparişi");f.Text("no","Sipariş no","SIP-"+DateTime.Now.ToString("yyyyMMdd-HHmmss"),80);f.Select("cari","Tedarikçi",await Task.Run(()=>db.Secimler("cari")));f.Date("date","Sipariş tarihi");f.Date("due","Termin");f.Choice("currency","Para birimi",new[]{"TRY","USD","EUR","GBP"});f.Number("rate","Belge kuru (TRY karşılığı)",1);f.Text("note","Açıklama");var table=f.Lines("lines","Sipariş kalemleri",("Ürün",typeof(int)),("Raf",typeof(int)),("Miktar",typeof(decimal)),("Fiyat",typeof(decimal)),("KDV",typeof(decimal)));f.LineChoice("lines","Ürün",await Task.Run(()=>db.Secimler("stok")));f.LineChoice("lines","Raf",await Task.Run(()=>db.Secimler("raf")));if(f.ShowDialog()!=true)return;
            var g=new SatinAlmaGirdisi(Guid.NewGuid(),null,null,f.S("no"),f.I("cari"),f.D("date"),f.D("due"),f.S("currency"),f.N("rate"),table.AsEnumerable().Select(r=>new SiparisKalemi((int)r["Ürün"],(int)r["Raf"],(decimal)r["Miktar"],(decimal)r["Fiyat"],(decimal)r["KDV"],"")).ToArray(),f.S("note"));await Task.Run(()=>db.SiparisKaydet(g));await Saved();
        });
        Action("Miktar / fiyat eşleştirmesi",async()=>{long id=Id();ShowTable("Sipariş · mal kabul · fatura",await Task.Run(()=>db.SiparisEslesme(id)));});
        Action("Mal kabul",async()=>
        {
            long id=Id();var match=await Task.Run(()=>db.SiparisEslesme(id));var f=new IsletmeForm(this,"Mal kabul");f.Date("date","Kabul tarihi");f.Text("note","İrsaliye / açıklama");var lines=f.Lines("lines","Kabul edilecek satırlar · miktarı sıfır olanlar işlenmez",("Satır",typeof(int)),("Miktar",typeof(decimal)),("Parti",typeof(string)),("KaliteKontrol",typeof(bool)));foreach(DataRow r in match.Rows)if((decimal)r["BekleyenKabul"]>0)lines.Rows.Add(r["Satir"],r["BekleyenKabul"],"",true);f.Note("Parti kodu her stok için benzersiz olmalı. Kalite kontrolü gereken parti bloke olarak alınır.");if(f.ShowDialog()!=true)return;var g=new MalKabulGirdisi(Guid.NewGuid(),id,f.D("date"),lines.AsEnumerable().Where(r=>!r.IsNull("Miktar")&&(decimal)r["Miktar"]>0).Select(r=>new MalKabulKalemi((int)r["Satır"],(decimal)r["Miktar"],Convert.ToString(r["Parti"])??"",r.IsNull("KaliteKontrol")||Convert.ToBoolean(r["KaliteKontrol"]))).ToArray(),f.S("note"));await Task.Run(()=>db.MalKabul(g));await Saved();
        });
        Action("Alış faturası eşleştir",async()=>
        {
            long id=Id();var match=await Task.Run(()=>db.SiparisEslesme(id));var f=new IsletmeForm(this,"Alış faturası");f.Text("no","Tedarikçi fatura numarası",max:80);f.Date("date","Fatura tarihi");f.Text("note","Açıklama");var lines=f.Lines("lines","Kabul edilmiş, faturalanmamış miktarlar",("Satır",typeof(int)),("Miktar",typeof(decimal)),("Fiyat",typeof(decimal)),("KDV",typeof(decimal)));foreach(DataRow r in match.Rows)if((decimal)r["BekleyenFatura"]>0)lines.Rows.Add(r["Satir"],r["BekleyenFatura"],r["Fiyat"],r["Kdv"]);if(f.ShowDialog()!=true)return;var g=new AlisFaturaGirdisi(Guid.NewGuid(),id,f.S("no"),f.D("date"),lines.AsEnumerable().Where(r=>!r.IsNull("Miktar")&&(decimal)r["Miktar"]>0).Select(r=>new AlisFaturaKalemi((int)r["Satır"],(decimal)r["Miktar"],(decimal)r["Fiyat"],(decimal)r["KDV"])).ToArray(),f.S("note"));await Task.Run(()=>db.AlisFaturasi(g));await Saved();
        });
    }
}
