using System;
using System.Data;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Data.SqlClient;

namespace MiapaxERP.Desktop
{
    internal static class BeniHatirlaServisi
    {
        private static readonly string Dosya = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "BoruERP", "hatirlanan-oturum.dat");
        private static readonly byte[] EkVeri = Encoding.UTF8.GetBytes("BoruERP.RememberMe.v1");

        internal static void Kaydet(string baglantiAdresi, int kullaniciId)
        {
            byte[] belirtec = RandomNumberGenerator.GetBytes(32);
            byte[] ozet = SHA256.HashData(belirtec);
            using var con = new SqlConnection(baglantiAdresi);
            con.Open();
            using var cmd = new SqlCommand(@"
DECLARE @SifreOzeti nvarchar(512);
SELECT @SifreOzeti=SifreOzeti FROM dbo.Kullanicilar
 WHERE Id=@Id AND Aktif=1 AND SifreDegistirmeli=0;
IF @SifreOzeti IS NULL THROW 51110, N'Oturum hatırlanamadı: hesap geçersiz.', 1;
DELETE dbo.HatirlananOturumlar WHERE KullaniciId=@Id AND BitisUtc<SYSUTCDATETIME();
INSERT dbo.HatirlananOturumlar(KullaniciId,BelirtecOzeti,SifreDurumuOzeti,BitisUtc)
 VALUES(@Id,@Belirtec,HASHBYTES('SHA2_256',CONVERT(varbinary(max),@SifreOzeti)),DATEADD(DAY,30,SYSUTCDATETIME()));", con);
            cmd.Parameters.Add("@Id",SqlDbType.Int).Value=kullaniciId;
            cmd.Parameters.Add("@Belirtec",SqlDbType.VarBinary,32).Value=ozet;
            cmd.ExecuteNonQuery();
            // Şifre değil, rastgele bir oturum belirteci Windows kullanıcı hesabına bağlı şifrelenir.
            byte[] kayit = new byte[36];
            BitConverter.GetBytes(kullaniciId).CopyTo(kayit,0);
            Buffer.BlockCopy(belirtec,0,kayit,4,32);
            byte[] sifreli = ProtectedData.Protect(kayit,EkVeri,DataProtectionScope.CurrentUser);
            Directory.CreateDirectory(Path.GetDirectoryName(Dosya)!);
            File.WriteAllBytes(Dosya,sifreli);
        }

        internal static KullaniciOturumu? Dogrula(string baglantiAdresi)
        {
            if (!File.Exists(Dosya)) return null;
            byte[] kayit;
            try { kayit=ProtectedData.Unprotect(File.ReadAllBytes(Dosya),EkVeri,DataProtectionScope.CurrentUser); }
            catch (CryptographicException) { YerelKaydiSil(); return null; }
            if (kayit.Length!=36) { YerelKaydiSil(); return null; }
            int id=BitConverter.ToInt32(kayit,0);
            byte[] belirtec=new byte[32];
            Buffer.BlockCopy(kayit,4,belirtec,0,32);
            using var con=new SqlConnection(baglantiAdresi);
            con.Open();
            using var cmd=new SqlCommand(@"
SELECT k.KullaniciAdi,k.AdSoyad FROM dbo.HatirlananOturumlar h
JOIN dbo.Kullanicilar k ON k.Id=h.KullaniciId
WHERE h.KullaniciId=@Id AND h.BelirtecOzeti=@Ozet AND h.BitisUtc>SYSUTCDATETIME()
 AND k.Aktif=1 AND k.SifreDegistirmeli=0
 AND (k.KilitBitisUtc IS NULL OR k.KilitBitisUtc<=SYSUTCDATETIME())
 AND h.SifreDurumuOzeti=HASHBYTES('SHA2_256',CONVERT(varbinary(max),k.SifreOzeti));",con);
            cmd.Parameters.Add("@Id",SqlDbType.Int).Value=id;
            cmd.Parameters.Add("@Ozet",SqlDbType.VarBinary,32).Value=SHA256.HashData(belirtec);
            string kullaniciAdi, adSoyad;
            using(var rd=cmd.ExecuteReader())
            {
                if(!rd.Read()) { YerelKaydiSil(); return null; }
                kullaniciAdi=rd.GetString(0);
                adSoyad=rd.GetString(1);
            }
            using var rolCmd=new SqlCommand(@"SELECT r.RolAdi FROM dbo.KullaniciRolAtamalari a
 JOIN dbo.KullaniciRolleri r ON r.Id=a.RolId
 WHERE a.KullaniciId=@Id AND r.Aktif=1 ORDER BY r.RolAdi;",con);
            rolCmd.Parameters.Add("@Id",SqlDbType.Int).Value=id;
            var roller=new System.Collections.Generic.List<string>();
            using(var rd=rolCmd.ExecuteReader()) while(rd.Read()) roller.Add(rd.GetString(0));
            return new KullaniciOturumu { KullaniciId=id,KullaniciAdi=kullaniciAdi,AdSoyad=adSoyad,
                Roller=roller.Count==0?"Rol atanmadı":string.Join(", ",roller) };
        }

        internal static void OturumuIptalEt(string baglantiAdresi)
        {
            if(!File.Exists(Dosya)) return;
            byte[] kayit;
            try { kayit=ProtectedData.Unprotect(File.ReadAllBytes(Dosya),EkVeri,DataProtectionScope.CurrentUser); }
            catch (CryptographicException) { YerelKaydiSil(); return; }
            if(kayit.Length!=36) { YerelKaydiSil(); return; }
            using var con=new SqlConnection(baglantiAdresi);
            con.Open();
            using var cmd=new SqlCommand("DELETE dbo.HatirlananOturumlar WHERE KullaniciId=@Id AND BelirtecOzeti=@Ozet",con);
            cmd.Parameters.Add("@Id",SqlDbType.Int).Value=BitConverter.ToInt32(kayit,0);
            byte[] belirtec=new byte[32]; Buffer.BlockCopy(kayit,4,belirtec,0,32);
            cmd.Parameters.Add("@Ozet",SqlDbType.VarBinary,32).Value=SHA256.HashData(belirtec);
            cmd.ExecuteNonQuery();
            YerelKaydiSil();
        }
        private static void YerelKaydiSil() { try { File.Delete(Dosya); } catch (IOException) { } }
    }
}
