using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
namespace MiapaxERP.Desktop;
public sealed record ParselBaglantisi(string Adres,string SifreliAnahtar);
public static class ParselServisi
{
 static string Dosya=>Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"BoruERP","parsel-servisi.json");
 public static Uri AdresDogrula(string adres){if(!Uri.TryCreate(adres,UriKind.Absolute,out var uri)||uri.Scheme!="https"||!string.IsNullOrEmpty(uri.UserInfo)||!string.IsNullOrEmpty(uri.Fragment)||!string.IsNullOrEmpty(uri.Query))throw new ArgumentException("Yetkili sağlayıcınızın sorgu parametresi içermeyen HTTPS servis adresini girin.");return uri;}
 public static ParselBaglantisi Oku()=>File.Exists(Dosya)?JsonSerializer.Deserialize<ParselBaglantisi>(File.ReadAllText(Dosya))!:new("","");
 public static void Ayarlar(Window? owner){
  var old=Oku();var w=new Window{Title="İzinli parsel servisi bağlantısı",Owner=owner,Width=650,Height=430,WindowStartupLocation=WindowStartupLocation.CenterOwner};var p=new StackPanel{Margin=new Thickness(24)};w.Content=p;
  p.Children.Add(new TextBlock{Text="TKGM veya yetkili sağlayıcınızdan aldığınız erişime uygun servis bağlantısını tanımlayın. Servis bağlı değilken otomatik ada/parsel sorgusu çalışmaz. WGS84 GeoJSON sınır aktarımı kullanılabilir.",TextWrapping=TextWrapping.Wrap});
  p.Children.Add(new TextBlock{Text="HTTPS sorgu adresi",Margin=new Thickness(0,20,0,4)});var address=new TextBox{Text=old.Adres,MinHeight=34};p.Children.Add(address);
  p.Children.Add(new TextBlock{Text="Bearer erişim anahtarı (değiştirmeyecekseniz boş bırakın)",Margin=new Thickness(0,16,0,4)});var key=new PasswordBox{MinHeight=34};p.Children.Add(key);var clear=new System.Windows.Controls.CheckBox{Content="Kayıtlı erişim anahtarını temizle",Margin=new Thickness(0,12,0,8)};p.Children.Add(clear);
  var status=new TextBlock{TextWrapping=TextWrapping.Wrap};p.Children.Add(status);var save=new System.Windows.Controls.Button{Content="Bağlantıyı kaydet",Margin=new Thickness(0,16,0,0),Padding=new Thickness(12)};p.Children.Add(save);
  save.Click+=(_,_)=>{try{AdresDogrula(address.Text.Trim());string secret=clear.IsChecked==true?"":old.SifreliAnahtar;if(key.Password.Length>0)secret=Convert.ToBase64String(ProtectedData.Protect(Encoding.UTF8.GetBytes(key.Password),null,DataProtectionScope.CurrentUser));Directory.CreateDirectory(Path.GetDirectoryName(Dosya)!);File.WriteAllText(Dosya,JsonSerializer.Serialize(new ParselBaglantisi(address.Text.Trim(),secret)));w.DialogResult=true;}catch(Exception ex){status.Text=ex.Message;}};w.ShowDialog();
 }
 public static async Task<JsonElement> Sorgula(JsonElement fields){
  LisansOturumu.Gerekli("KROKI");var setting=Oku();if(string.IsNullOrWhiteSpace(setting.Adres))throw new InvalidOperationException("İzinli parsel servisi henüz bağlı değil. Servis ayarlarını tanımlayın veya KML / GeoJSON sınırı aktarın.");
  var request=new Dictionary<string,string>();foreach(var key in new[]{"il","ilce","mahalle","ada","parsel"}){var value=fields.GetProperty(key).GetString()?.Trim();if(string.IsNullOrWhiteSpace(value)||value.Length>80||value.Any(char.IsControl))throw new ArgumentException("İl, ilçe, mahalle/köy, ada ve parsel alanlarını doldurun.");request[key]=value;}
  using var http=new HttpClient(new HttpClientHandler{AllowAutoRedirect=false}){Timeout=TimeSpan.FromSeconds(25),MaxResponseContentBufferSize=1000000};
  if(!string.IsNullOrWhiteSpace(setting.SifreliAnahtar)){var bytes=ProtectedData.Unprotect(Convert.FromBase64String(setting.SifreliAnahtar),null,DataProtectionScope.CurrentUser);try{http.DefaultRequestHeaders.Authorization=new AuthenticationHeaderValue("Bearer",Encoding.UTF8.GetString(bytes));}finally{CryptographicOperations.ZeroMemory(bytes);}}
  using var response=await http.PostAsJsonAsync(AdresDogrula(setting.Adres),request);if(!response.IsSuccessStatusCode)throw new InvalidOperationException("Parsel sağlayıcısı sorguyu tamamlayamadı (HTTP "+(int)response.StatusCode+"). Bağlantı ve yetkiyi kontrol edin.");
  using var doc=JsonDocument.Parse(await response.Content.ReadAsStringAsync());return doc.RootElement.Clone();
 }
}
