using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;

namespace MiapaxERP.Desktop;
public partial class MainWindow
{
    private void StokGorselleriniBagla()
    {
        foreach(var grid in new[]{StokTablosu,StokHareketGecmisiTablosu,StokBakiyeRaporTablosu})
        {
            grid.Columns.Insert(0,new DataGridTemplateColumn{Header="Görsel",Width=70,CellTemplate=GorselSablonu(false)});
            grid.RowHeight=58;
        }
        CmbHareketStok.DisplayMemberPath="";CmbHareketStok.ItemTemplate=GorselSablonu(true);CmbHareketStok.Height=58;
    }
    private static DataTemplate GorselSablonu(bool isim)
    {
        var row=new FrameworkElementFactory(typeof(StackPanel));row.SetValue(StackPanel.OrientationProperty,System.Windows.Controls.Orientation.Horizontal);
        var box=new FrameworkElementFactory(typeof(Grid));box.SetValue(FrameworkElement.WidthProperty,54d);box.SetValue(FrameworkElement.HeightProperty,48d);
        var empty=new FrameworkElementFactory(typeof(TextBlock));empty.SetValue(TextBlock.TextProperty,"▧");empty.SetValue(TextBlock.FontSizeProperty,28d);empty.SetValue(TextBlock.ForegroundProperty,Brushes.SlateGray);empty.SetValue(FrameworkElement.HorizontalAlignmentProperty,System.Windows.HorizontalAlignment.Center);box.AppendChild(empty);
        var image=new FrameworkElementFactory(typeof(System.Windows.Controls.Image));image.SetBinding(System.Windows.Controls.Image.SourceProperty,new System.Windows.Data.Binding("KapakGorseli"));image.SetValue(System.Windows.Controls.Image.StretchProperty,Stretch.Uniform);box.AppendChild(image);row.AppendChild(box);
        if(isim){var text=new FrameworkElementFactory(typeof(TextBlock));text.SetBinding(TextBlock.TextProperty,new System.Windows.Data.Binding("SecimMetni"));text.SetValue(FrameworkElement.VerticalAlignmentProperty,VerticalAlignment.Center);text.SetValue(FrameworkElement.MarginProperty,new Thickness(8,0,0,0));row.AppendChild(text);}
        return new DataTemplate{VisualTree=row};
    }
    private async void StokFotograflariniYukle(DataTable table,string idColumn)
    {
        if(!table.Columns.Contains("KapakGorseli"))table.Columns.Add("KapakGorseli",typeof(System.Windows.Media.Imaging.BitmapImage));
        if(DemoModu || !table.Columns.Contains(idColumn))return;
        int generation=(table.ExtendedProperties["GorselNesli"] as int? ?? 0)+1;table.ExtendedProperties["GorselNesli"]=generation;
        int? user=aktifKullanici?.KullaniciId;
        var ids=table.Rows.Cast<DataRow>().Select(r=>Convert.ToInt32(r[idColumn])).ToArray();
        if(ids.Length==0)return;
        try{
            var images=await Task.Run(()=>StokGorselServisi.Kapaklar(baglantiAdresi,ids));
            if(aktifKullanici?.KullaniciId!=user || !Equals(table.ExtendedProperties["GorselNesli"],generation))return;
            foreach(DataRow row in table.Rows)row["KapakGorseli"]=images.TryGetValue(Convert.ToInt32(row[idColumn]),out var image)?image:DBNull.Value;
        }catch(Exception ex){System.Diagnostics.Trace.WriteLine("Stok fotoğrafları: "+ex.Message);StokTablosu.ToolTip="Fotoğraflar yüklenemedi: "+ex.Message;}
    }
}

