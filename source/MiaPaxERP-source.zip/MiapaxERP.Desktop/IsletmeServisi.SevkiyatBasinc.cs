using System.Data;
using System.IO;
using System.Security.Cryptography;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed partial class IsletmeServisi
{
    internal static void SevkiyatDogrula(SevkiyatGirdisi g)
    {
        Text(g.No,1,80,"Sevkiyat no");Text(g.Nereden,1,200,"Nereden");Text(g.Nereye,1,200,"Nereye");Text(g.Tasima,1,60,"Taşıma şekli");Text(g.Plaka,0,30,"Plaka");Text(g.Sofor,0,120,"Şoför");Text(g.Telefon,0,40,"Telefon");Text(g.Aciklama,0,400,"Açıklama");
        if(g.Cari<=0||g.Tarih.Year<2000||g.Tarih.Year>2100||g.BosKg<0||g.DoluKg<g.BosKg||g.DoluKg>99999999||decimal.Round(g.DoluKg,3)!=g.DoluKg||decimal.Round(g.BosKg,3)!=g.BosKg)throw new ArgumentException("Müşteri, tarih ve kantar ağırlıklarını kontrol edin. Dolu ağırlık boş ağırlıktan küçük olamaz.");
        if(g.Tasima=="Karayolu"&&(string.IsNullOrWhiteSpace(g.Plaka)||string.IsNullOrWhiteSpace(g.Sofor)))throw new ArgumentException("Karayolu sevkiyatında plaka ve şoför gerekli.");
        if(g.Kalemler is null||g.Kalemler.Length<1||g.Kalemler.Length>200)throw new ArgumentException("1–200 sevkiyat kalemi girin.");foreach(var k in g.Kalemler){Quantity(k.Miktar);if(k.Stok<=0||k.Raf<=0)throw new ArgumentException("Ürün ve raf seçin.");}
    }
    public long SevkiyatKaydet(SevkiyatGirdisi g)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"IsletmeServisi.SevkiyatKaydet","",new object?[]{g});}

        SevkiyatDogrula(g);using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"SHIPMENT.EDIT");
        using(var customer=Q(c,t,"SELECT COUNT(*) FROM dbo.CariKartlari WITH(HOLDLOCK) WHERE Id=@id AND Aktif=1",("@id",g.Cari)))if(Convert.ToInt32(customer.ExecuteScalar())!=1)throw new ArgumentException("Aktif müşteri seçin.");
        foreach(var k in g.Kalemler){using var stock=Q(c,t,"SELECT COUNT(*) FROM dbo.StokKartlari WITH(HOLDLOCK) WHERE Id=@id AND Aktif=1",("@id",k.Stok));if(Convert.ToInt32(stock.ExecuteScalar())!=1)throw new ArgumentException("Aktif ürün seçin.");}
        if(g.Satis.HasValue){using var sale=Q(c,t,"SELECT COUNT(*) FROM dbo.MPX310_Satis s JOIN dbo.BoruERP_YeniBelgeler d ON d.Id=s.BelgeId WHERE s.BelgeId=@id AND d.CariId=@c AND d.Durum<>N'İptal'",("@id",g.Satis),("@c",g.Cari));if(Convert.ToInt32(sale.ExecuteScalar())!=1)throw new ArgumentException("Müşteriye ait işlenmiş satış bulunamadı.");}
        long id;if(g.Id.HasValue){var r=Read(c,t,g.Id.Value,"Sevkiyat",true);Version(r,g.Surum);Update(c,t,g.Id.Value,"Sevkiyat",g.Surum!,g);id=g.Id.Value;}else id=Create(c,t,"Sevkiyat",g.Anahtar,g);t.Commit();return id;
    }
    public void SevkEt(long id,byte[] surum)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"IsletmeServisi.SevkEt","",new object?[]{id,surum});return;}

        using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"SHIPMENT.DISPATCH");var row=Read(c,t,id,"Sevkiyat",true);Version(row,surum);if((string)row["Durum"]!="Taslak")throw new InvalidOperationException("Sevkiyat zaten işlendi.");var g=Veri<SevkiyatGirdisi>((string)row["Veri"]);SevkiyatDogrula(g);
        // Linked sales have already issued stock. Only advance their undelivered allocations.
        foreach(var k in g.Kalemler.OrderBy(k=>k.Stok).ThenBy(k=>k.Lot))
        {
            if(g.Satis.HasValue)
            {
                var allocations=Table(Q(c,t,"SELECT x.Id,x.Miktar-x.SevkEdilen Kalan FROM dbo.MPX310_SatisLot x WITH(UPDLOCK,HOLDLOCK) JOIN dbo.MPX310_Lot l ON l.Id=x.LotId JOIN dbo.BoruERP_YeniBelgeler d ON d.Id=x.BelgeId WHERE x.BelgeId=@s AND d.CariId=@c AND d.Durum<>N'İptal' AND l.StokId=@stok AND x.RafId=@r AND (@lot IS NULL OR x.LotId=@lot) ORDER BY x.Id",("@s",g.Satis),("@c",g.Cari),("@stok",k.Stok),("@r",k.Raf),("@lot",k.Lot)));
                decimal left=k.Miktar;foreach(DataRow a in allocations.Rows){decimal qty=Math.Min(left,(decimal)a["Kalan"]);if(qty<=0)continue;using var q=Q(c,t,"UPDATE dbo.MPX310_SatisLot SET SevkEdilen=SevkEdilen+@m WHERE Id=@id",("@m",qty),("@id",a["Id"]));q.ExecuteNonQuery();left-=qty;if(left==0)break;}if(left>0)throw new InvalidOperationException("Sevk miktarı satışın teslim edilmemiş parti miktarını aşıyor.");
            }
            else Issue(c,t,k.Stok,k.Miktar,k.Lot,k.Raf,"SEVKIYAT",id,g.No);
        }
        State(c,t,id,"Taslak","Sevk edildi",g.Plaka+" · "+g.Sofor);t.Commit();
    }
    public void SevkiyatTeslim(long id,byte[] surum,string teslimAlan,string dayanak)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"IsletmeServisi.SevkiyatTeslim","",new object?[]{id,surum,teslimAlan,dayanak});return;}

        Text(teslimAlan,2,120,"Teslim alan");Text(dayanak,3,400,"Teslim dayanağı");using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"SHIPMENT.DISPATCH");var row=Read(c,t,id,"Sevkiyat",true);Version(row,surum);State(c,t,id,"Sevk edildi","Teslim edildi",teslimAlan+" · "+dayanak);t.Commit();
    }
    internal static void BasincDogrula(BasincTestGirdisi g)
    {
        Text(g.No,1,80,"Test no");Text(g.Yontem,1,160,"Yöntem");Text(g.Standart,1,120,"Standart / şartname");Text(g.Aciklama,0,2000,"Açıklama");
        if(g.Stok<=0||g.Lot<=0||g.Cihaz<=0||g.Bitis<g.Baslangic||g.Bitis>DateTimeOffset.UtcNow.AddMinutes(5)||g.Baslangic.Year<2000||g.GerekliSaat<=0||g.GerekliSaat>10000||g.HedefBar<=0||g.HedefBar>100000||g.IlkBar<0||g.SonBar<0||g.IlkBar>100000||g.SonBar>100000||g.Sicaklik< -100||g.Sicaklik>500)throw new ArgumentException("Test süresi, basınç, sıcaklık, parti ve cihaz bilgilerini kontrol edin.");
    }
    public long BasincKaydet(BasincTestGirdisi g)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"IsletmeServisi.BasincKaydet","",new object?[]{g});}

        BasincDogrula(g);using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"PRESSURE.EDIT");
        using(var lot=Q(c,t,"SELECT COUNT(*) FROM dbo.MPX310_Lot WITH(UPDLOCK,HOLDLOCK) WHERE Id=@l AND StokId=@s",("@l",g.Lot),("@s",g.Stok)))if(Convert.ToInt32(lot.ExecuteScalar())!=1)throw new ArgumentException("Parti bu ürüne ait değil.");
        using(var device=Q(c,t,"SELECT COUNT(*) FROM dbo.BERP260_LabCihaz WITH(HOLDLOCK) WHERE Id=@id AND Kalibrasyon<=@a AND Gecerlilik>=@b",("@id",g.Cihaz),("@a",g.Baslangic.Date),("@b",g.Bitis.Date)))if(Convert.ToInt32(device.ExecuteScalar())!=1)throw new ArgumentException("Cihazın kalibrasyonu test tarih aralığında geçerli değil.");
        long id;if(g.Id.HasValue){var row=Read(c,t,g.Id.Value,"BasincTest",true);Version(row,g.Surum);if(Veri<BasincTestGirdisi>((string)row["Veri"]).Lot!=g.Lot)throw new ArgumentException("Kaydedilmiş testin partisi değiştirilemez.");Update(c,t,g.Id.Value,"BasincTest",g.Surum!,g);id=g.Id.Value;}else id=Create(c,t,"BasincTest",g.Anahtar,g);
        using(var block=Q(c,t,"UPDATE dbo.MPX310_Lot SET Kalite=N'Bloke' WHERE Id=@l",("@l",g.Lot)))block.ExecuteNonQuery();t.Commit();return id;
    }
    public void BasincIncele(long id,byte[] surum,bool onay,string gerekce)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"IsletmeServisi.BasincIncele","",new object?[]{id,surum,onay,gerekce});return;}

        Text(gerekce,5,400,"Teknik inceleme gerekçesi");using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"PRESSURE.APPROVE");var row=Read(c,t,id,"BasincTest",true);Version(row,surum);if((string)row["Durum"]!="Taslak")throw new InvalidOperationException("Test daha önce sonuçlandırılmış.");if((int)row["Olusturan"]==user||(int)row["Guncelleyen"]==user)throw new InvalidOperationException("Teknik onayı testi kaydeden kişiden farklı bir kullanıcı yapmalı.");var g=Veri<BasincTestGirdisi>((string)row["Veri"]);BasincDogrula(g);
        if(onay&&(g.Sizinti||g.IlkBar<g.HedefBar||g.SonBar<g.HedefBar||(decimal)(g.Bitis-g.Baslangic).TotalHours<g.GerekliSaat))throw new InvalidOperationException("Girilen süre/basınç/sızıntı ölçütleri sağlanmıyor. Sonuç onaylanamaz.");
        State(c,t,id,"Taslak",onay?"Onaylandı":"Reddedildi",gerekce);
        // A passed test alone does not override other quality holds or another pending/failed test.
        using(var release=Q(c,t,"UPDATE dbo.MPX310_Lot SET Kalite=@q WHERE Id=@l",("@q",onay?"İnceleme":"Reddedildi"),("@l",g.Lot)))release.ExecuteNonQuery();t.Commit();
    }
    public void PartiSerbestBirak(long lot,string gerekce)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"IsletmeServisi.PartiSerbestBirak","",new object?[]{lot,gerekce});return;}

        Text(gerekce,5,400,"Serbest bırakma gerekçesi");using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"LAB.RELEASE");
        using(var q=Q(c,t,"SELECT COUNT(*) FROM dbo.MPX310_Kayit WITH(UPDLOCK,HOLDLOCK) WHERE Tur='BasincTest' AND TRY_CONVERT(bigint,JSON_VALUE(Veri,'$.lot'))=@l AND Durum<>N'Onaylandı'",("@l",lot)))if(Convert.ToInt32(q.ExecuteScalar())>0)throw new InvalidOperationException("Partinin bekleyen veya reddedilen basınç testi var.");
        using(var q=Q(c,t,"SELECT COUNT(*) FROM dbo.BERP260_LabBloke b JOIN dbo.MPX310_Lot l ON l.StokId=b.StokId WHERE l.Id=@l AND b.Aktif=1",("@l",lot)))if(Convert.ToInt32(q.ExecuteScalar())>0)throw new InvalidOperationException("Laboratuvar stok blokesi var.");
        using(var q=Q(c,t,"UPDATE dbo.MPX310_Lot SET Kalite=N'Serbest' WHERE Id=@l AND Kalite=N'İnceleme'",("@l",lot)))if(q.ExecuteNonQuery()!=1)throw new InvalidOperationException("Teknik incelemesi tamamlanmış parti bulunamadı.");Event(c,t,null,"Parti serbest",lot+" · "+gerekce);t.Commit();
    }
    internal static string MedyaDogrula(IsletmeDosyasi g)
    {
        Text(g.Ad,1,180,"Dosya adı");if(Path.GetFileName(g.Ad)!=g.Ad||g.Ad.Contains('/')||g.Ad.Contains('\\')||g.Veri is null||g.Veri.Length<12||g.Veri.Length>40*1024*1024)throw new ArgumentException("Dosya adı veya boyutu geçersiz. En fazla 40 MB yükleyin.");
        var b=g.Veri.AsSpan();string ext=Path.GetExtension(g.Ad).ToLowerInvariant();string type=ext switch{
            ".png" when b.StartsWith(new byte[]{137,80,78,71,13,10,26,10})=>"image/png",
            ".jpg" or ".jpeg" when b[0]==255&&b[1]==216&&b[2]==255=>"image/jpeg",
            ".mp4" when b.Slice(4,4).SequenceEqual("ftyp"u8)=>"video/mp4",
            ".webm" when b.StartsWith(new byte[]{26,69,223,163})=>"video/webm",
            _=>throw new ArgumentException("Yalnız PNG, JPEG, MP4 veya WebM yüklenebilir. Dosya içeriği uzantıyla uyuşmalı.")};
        if(type!=g.Tur)throw new ArgumentException("Dosya türü uyuşmuyor.");return type;
    }
    public long BasincMedyaEkle(Guid key,long id,byte[] surum,IsletmeDosyasi g)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"IsletmeServisi.BasincMedyaEkle","",new object?[]{key,id,surum,g});}

        string type=MedyaDogrula(g);if(key==Guid.Empty)throw new ArgumentException("İşlem kimliği gerekli.");using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"PRESSURE.EDIT");var row=Read(c,t,id,"BasincTest",true);Version(row,surum);if((string)row["Durum"]!="Taslak")throw new InvalidOperationException("Sonuçlandırılmış teste medya eklenemez.");string hash=Convert.ToHexString(SHA256.HashData(g.Veri));
        using(var prior=Q(c,t,"SELECT Id,KayitId,Sha256,Ad FROM dbo.MPX310_Ek WITH(UPDLOCK,HOLDLOCK) WHERE Anahtar=@k",("@k",key)))using(var r=prior.ExecuteReader()){if(r.Read()){if(r.GetInt64(1)!=id||r.GetString(2)!=hash||r.GetString(3)!=g.Ad)throw new ArgumentException("İşlem kimliği farklı dosyada kullanılmış.");long previous=r.GetInt64(0);r.Close();t.Commit();return previous;}}
        using(var quota=Q(c,t,"SELECT COUNT(*),COALESCE(SUM(CONVERT(bigint,DATALENGTH(Veri))),0) FROM dbo.MPX310_Ek WITH(UPDLOCK,HOLDLOCK) WHERE KayitId=@id",("@id",id)))using(var r=quota.ExecuteReader()){r.Read();if(r.GetInt32(0)>=20||r.GetInt64(1)+g.Veri.Length>200*1024*1024)throw new ArgumentException("Test başına 20 dosya / 200 MB sınırı aşılıyor.");}
        using var q=Q(c,t,"INSERT dbo.MPX310_Ek(Anahtar,KayitId,Ad,Tur,Veri,Sha256,Ekleyen) OUTPUT INSERTED.Id VALUES(@k,@id,@a,@t,@v,@h,@u)",("@k",key),("@id",id),("@a",g.Ad),("@t",type),("@v",g.Veri),("@h",hash),("@u",user));long media=Convert.ToInt64(q.ExecuteScalar());Event(c,t,id,"Medya eklendi",g.Ad+" · "+hash);t.Commit();return media;
    }
    public DataTable BasincMedyaListesi(long id){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"IsletmeServisi.BasincMedyaListesi","",new object?[]{id});}
using var c=access.Ac();Yetki(c,null,"PRESSURE.VIEW");Read(c,null,id,"BasincTest");return Table(Q(c,null,"SELECT Id,Ad,Tur,DATALENGTH(Veri) Boyut,Sha256,Zaman,Ekleyen FROM dbo.MPX310_Ek WHERE KayitId=@id ORDER BY Id",("@id",id)));}
    public IsletmeDosyasi BasincMedyaOku(long id)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<IsletmeDosyasi>(connection,"IsletmeServisi.BasincMedyaOku","",new object?[]{id});}

        using var c=access.Ac();Yetki(c,null,"PRESSURE.EXPORT");using var q=Q(c,null,"SELECT e.Ad,e.Tur,e.Veri FROM dbo.MPX310_Ek e JOIN dbo.MPX310_Kayit k ON k.Id=e.KayitId WHERE e.Id=@id AND k.Tur='BasincTest'",("@id",id));using var r=q.ExecuteReader();if(!r.Read())throw new ArgumentException("Dosya bulunamadı.");return new(r.GetString(0),r.GetString(1),(byte[])r[2]);
    }
}
