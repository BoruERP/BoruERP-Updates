using SqlConnection = MiapaxERP.Desktop.ErpSqlConnection;
using SqlCommand = MiapaxERP.Desktop.ErpSqlCommand;
using SqlTransaction = MiapaxERP.Desktop.ErpSqlTransaction;
using SqlDataReader = MiapaxERP.Desktop.ErpSqlReader;
using SqlDataAdapter = MiapaxERP.Desktop.ErpSqlDataAdapter;
using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.Data;
using System.Security.Cryptography;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;

namespace MiapaxERP.Desktop
{
    /// <summary>
    /// İlk yönetici kurulumu ve yönetici doğrulaması bulunan kullanıcı/yetki yönetim ekranı.
    /// NOT: Diğer MiapaxERP modüllerinin işlem bazlı yetki kontrolleri sonraki aşamadadır.
    /// </summary>
    public partial class KullaniciYonetimiPenceresi : Window
    {
        private readonly string baglantiAdresi;
        private int? oturumYoneticiId;
        private int? seciliKullaniciId;
        private readonly List<YetkiSatiri> yetkiSatirlari = new List<YetkiSatiri>();

        private sealed class YetkiSatiri
        {
            public int Id { get; set; }
            public string Modul { get; set; } = "";
            public string Islem { get; set; } = "";
            public string Secim { get; set; } = "Devral";
            public IReadOnlyList<string> Secenekler { get; } =
                new[] { "Devral", "İzin ver", "Engelle" };
        }

        public KullaniciYonetimiPenceresi(string sqlBaglantiAdresi)
        {
            baglantiAdresi = sqlBaglantiAdresi;
            InitializeComponent();
            Loaded += PencereYuklendi;
        }

        private void PencereYuklendi(object sender, RoutedEventArgs e)
        {
            try
            {
                if(HttpsOturumu.Uzak(baglantiAdresi)){
                    new YardimciEkranServisi(baglantiAdresi,HttpsOturumu.Istemci!.Oturum!.Kullanici.Id).YoneticiKontrol();
                    oturumYoneticiId=HttpsOturumu.Istemci.Oturum.Kullanici.Id;
                    IlkKurulumPaneli.Visibility=GirisPaneli.Visibility=Visibility.Collapsed;YonetimPaneli.Visibility=Visibility.Visible;
                    RolleriYukle();KullanicilariYukle();return;
                }
                using var baglanti = new SqlConnection(baglantiAdresi);
                baglanti.Open();
                using var komut = new SqlCommand("SELECT COUNT_BIG(*) FROM dbo.Kullanicilar;", baglanti);
                bool ilkKurulum = Convert.ToInt64(komut.ExecuteScalar()) == 0;
                IlkKurulumPaneli.Visibility = ilkKurulum ? Visibility.Visible : Visibility.Collapsed;
                GirisPaneli.Visibility = ilkKurulum ? Visibility.Collapsed : Visibility.Visible;
                YonetimPaneli.Visibility = Visibility.Collapsed;
            }
            catch (Exception hata)
            {
                MessageBox.Show("Kullanıcı tabloları kontrol edilemedi:\n\n" + hata.Message,
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Error);
                Close();
            }
        }

        // ASP.NET Core Identity PasswordHasher V3 biçimiyle uyumlu PBKDF2-SHA512:
        // 0x01 | PRF (HMACSHA512=2) | iterasyon | salt boyutu | 16 byte salt | 32 byte alt anahtar.
        // Güvenli rastgele tuz ve sabit zamanlı karşılaştırma kullanılır.
        private static string SifreOzetiOlustur(string sifre)
        {
            const int iterasyon = 310000;
            byte[] tuz = RandomNumberGenerator.GetBytes(16);
            byte[] anahtar = Rfc2898DeriveBytes.Pbkdf2(sifre, tuz, iterasyon,
                HashAlgorithmName.SHA512, 32);
            byte[] veri = new byte[13 + tuz.Length + anahtar.Length];
            veri[0] = 0x01;
            BinaryPrimitives.WriteUInt32BigEndian(veri.AsSpan(1, 4), 2);
            BinaryPrimitives.WriteUInt32BigEndian(veri.AsSpan(5, 4), iterasyon);
            BinaryPrimitives.WriteUInt32BigEndian(veri.AsSpan(9, 4), (uint)tuz.Length);
            tuz.CopyTo(veri, 13);
            anahtar.CopyTo(veri, 13 + tuz.Length);
            return Convert.ToBase64String(veri);
        }

        private static bool SifreDogrula(string sifre, string ozet)
        {
            try
            {
                byte[] veri = Convert.FromBase64String(ozet);
                if (veri.Length != 61 || veri[0] != 0x01) return false;
                uint prf = BinaryPrimitives.ReadUInt32BigEndian(veri.AsSpan(1, 4));
                uint iterasyon = BinaryPrimitives.ReadUInt32BigEndian(veri.AsSpan(5, 4));
                uint tuzBoyutu = BinaryPrimitives.ReadUInt32BigEndian(veri.AsSpan(9, 4));
                if (prf != 2 || iterasyon < 10000 || iterasyon > 1000000 || tuzBoyutu != 16)
                    return false;
                byte[] tuz = veri.AsSpan(13, 16).ToArray();
                byte[] beklenen = veri.AsSpan(29, 32).ToArray();
                byte[] hesaplanan = Rfc2898DeriveBytes.Pbkdf2(sifre, tuz, (int)iterasyon,
                    HashAlgorithmName.SHA512, 32);
                return CryptographicOperations.FixedTimeEquals(beklenen, hesaplanan);
            }
            catch (FormatException) { return false; }
            catch (CryptographicException) { return false; }
        }

        private static bool SifreGecerliMi(string sifre) =>
            sifre.Length >= 12 && sifre.Length <= 128;

        private static bool YoneticiMi(SqlConnection baglanti, SqlTransaction? islem, int id)
        {
            const string sorgu = @"
SELECT CASE WHEN EXISTS (
    SELECT 1 FROM dbo.Kullanicilar k
    INNER JOIN dbo.KullaniciRolAtamalari a ON a.KullaniciId = k.Id
    INNER JOIN dbo.KullaniciRolleri r ON r.Id = a.RolId
    WHERE k.Id = @Id AND k.Aktif = 1 AND r.RolAdi = N'Yönetici' AND r.Aktif = 1
) THEN 1 ELSE 0 END;";
            using var komut = new SqlCommand(sorgu, baglanti, islem);
            komut.Parameters.Add("@Id", SqlDbType.Int).Value = id;
            return Convert.ToInt32(komut.ExecuteScalar()) == 1;
        }

        private bool AdminYetkisiniKontrolEt(SqlConnection baglanti, SqlTransaction? islem = null)
        {
            if (oturumYoneticiId.HasValue && YoneticiMi(baglanti, islem, oturumYoneticiId.Value))
                return true;
            MessageBox.Show("Yönetici oturumu artık geçerli değil. Pencereyi kapatıp yeniden giriş yapın.",
                "Erişim Engellendi", MessageBoxButton.OK, MessageBoxImage.Warning);
            return false;
        }

        private void IlkYoneticiOlustur_Click(object sender, RoutedEventArgs e)
        {
            string kullanici = TxtIlkKullaniciAdi.Text.Trim();
            string adSoyad = TxtIlkAdSoyad.Text.Trim();
            string sifre = PwdIlkSifre.Password;
            if (kullanici.Length < 3 || adSoyad.Length < 3 || !SifreGecerliMi(sifre))
            {
                TxtIlkDurum.Text = "Kullanıcı adı ve ad soyad en az 3; şifre en az 12 karakter olmalı.";
                return;
            }
            if (sifre != PwdIlkTekrar.Password)
            {
                TxtIlkDurum.Text = "Şifreler aynı değil.";
                return;
            }
            try
            {
                string ozet = SifreOzetiOlustur(sifre);
                using var baglanti = new SqlConnection(baglantiAdresi);
                baglanti.Open();
                using var islem = baglanti.BeginTransaction(IsolationLevel.Serializable);

                // Eşzamanlı iki istemcinin ilk yönetici oluşturmasını engeller.
                using (var kilit = new SqlCommand(
                    "SELECT COUNT_BIG(*) FROM dbo.Kullanicilar WITH (TABLOCKX, HOLDLOCK);",
                    baglanti, islem))
                {
                    if (Convert.ToInt64(kilit.ExecuteScalar()) != 0)
                        throw new InvalidOperationException("İlk yönetici zaten oluşturulmuş.");
                }

                int rolId;
                using (var rolKomut = new SqlCommand(
                    "SELECT Id FROM dbo.KullaniciRolleri WHERE RolAdi=N'Yönetici' AND Aktif=1;",
                    baglanti, islem))
                {
                    object? sonuc = rolKomut.ExecuteScalar();
                    if (sonuc == null || sonuc == DBNull.Value)
                        throw new InvalidOperationException("Yönetici rolü bulunamadı.");
                    rolId = Convert.ToInt32(sonuc);
                }
                int yeniId;
                using (var komut = new SqlCommand(@"
INSERT INTO dbo.Kullanicilar (KullaniciAdi, AdSoyad, SifreOzeti, Aktif)
VALUES (@KullaniciAdi,@AdSoyad,@SifreOzeti,1);
SELECT CAST(SCOPE_IDENTITY() AS INT);", baglanti, islem))
                {
                    komut.Parameters.Add("@KullaniciAdi", SqlDbType.NVarChar, 60).Value = kullanici;
                    komut.Parameters.Add("@AdSoyad", SqlDbType.NVarChar, 120).Value = adSoyad;
                    komut.Parameters.Add("@SifreOzeti", SqlDbType.NVarChar, 512).Value = ozet;
                    yeniId = Convert.ToInt32(komut.ExecuteScalar());
                }
                using (var komut = new SqlCommand(@"
INSERT INTO dbo.KullaniciRolAtamalari (KullaniciId,RolId) VALUES (@KullaniciId,@RolId);",
                    baglanti, islem))
                {
                    komut.Parameters.Add("@KullaniciId", SqlDbType.Int).Value = yeniId;
                    komut.Parameters.Add("@RolId", SqlDbType.Int).Value = rolId;
                    komut.ExecuteNonQuery();
                }
                islem.Commit();
                PwdIlkSifre.Clear();
                PwdIlkTekrar.Clear();
                TxtGirisKullanici.Text = kullanici;
                TxtIlkDurum.Text = "";
                IlkKurulumPaneli.Visibility = Visibility.Collapsed;
                GirisPaneli.Visibility = Visibility.Visible;
                MessageBox.Show("İlk yönetici oluşturuldu. Şimdi hesabınızla giriş yapın.",
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (SqlException hata) when (hata.Number == 2601 || hata.Number == 2627)
            {
                TxtIlkDurum.Text = "Bu kullanıcı adı zaten kayıtlı.";
            }
            catch (Exception hata)
            {
                TxtIlkDurum.Text = "Yönetici oluşturulamadı: " + hata.Message;
            }
        }

        private void YoneticiGiris_Click(object sender, RoutedEventArgs e)
        {
            string kullanici = TxtGirisKullanici.Text.Trim();
            string sifre = PwdGiris.Password;
            TxtGirisDurum.Text = "";
            try
            {
                int kullaniciId;
                bool aktif;
                int hataliGiris;
                DateTime? kilitBitis;
                string ozet;
                using var baglanti = new SqlConnection(baglantiAdresi);
                baglanti.Open();
                using (var komut = new SqlCommand(@"
SELECT TOP(1) Id, SifreOzeti, Aktif, BasarisizGirisSayisi, KilitBitisUtc
FROM dbo.Kullanicilar WHERE KullaniciAdi=@KullaniciAdi;", baglanti))
                {
                    komut.Parameters.Add("@KullaniciAdi", SqlDbType.NVarChar, 60).Value = kullanici;
                    using var okuyucu = komut.ExecuteReader();
                    if (!okuyucu.Read())
                    {
                        TxtGirisDurum.Text = "Giriş bilgileri hatalı veya hesabınız yetkisiz.";
                        return;
                    }
                    kullaniciId = okuyucu.GetInt32(0);
                    ozet = okuyucu.GetString(1);
                    aktif = okuyucu.GetBoolean(2);
                    hataliGiris = okuyucu.GetInt32(3);
                    kilitBitis = okuyucu.IsDBNull(4) ? null : okuyucu.GetDateTime(4);
                }
                if (!aktif || (kilitBitis.HasValue && kilitBitis.Value > DateTime.UtcNow))
                {
                    TxtGirisDurum.Text = "Giriş yapılamadı. Hesap pasif veya geçici olarak kilitli.";
                    return;
                }
                if (!SifreDogrula(sifre, ozet))
                {
                    using var hataliKomut = new SqlCommand(@"
UPDATE dbo.Kullanicilar
SET BasarisizGirisSayisi = CASE WHEN KilitBitisUtc IS NOT NULL
           AND KilitBitisUtc <= SYSUTCDATETIME() THEN 1 ELSE BasarisizGirisSayisi + 1 END,
    KilitBitisUtc = CASE WHEN (KilitBitisUtc IS NOT NULL AND KilitBitisUtc <= SYSUTCDATETIME())
          THEN NULL WHEN BasarisizGirisSayisi >= 4
          THEN DATEADD(MINUTE,15,SYSUTCDATETIME()) ELSE KilitBitisUtc END
WHERE Id=@Id;", baglanti);
                    hataliKomut.Parameters.Add("@Id", SqlDbType.Int).Value = kullaniciId;
                    hataliKomut.ExecuteNonQuery();
                    TxtGirisDurum.Text = "Giriş bilgileri hatalı veya hesabınız yetkisiz.";
                    return;
                }
                if (!YoneticiMi(baglanti, null, kullaniciId))
                {
                    TxtGirisDurum.Text = "Bu bölümü yalnızca Yönetici rolü açabilir.";
                    return;
                }
                using (var komut = new SqlCommand(@"
UPDATE dbo.Kullanicilar SET BasarisizGirisSayisi=0, KilitBitisUtc=NULL,
SonGirisUtc=SYSUTCDATETIME() WHERE Id=@Id;", baglanti))
                {
                    komut.Parameters.Add("@Id", SqlDbType.Int).Value = kullaniciId;
                    komut.ExecuteNonQuery();
                }
                PwdGiris.Clear();
                oturumYoneticiId = kullaniciId;
                TxtYoneticiAdi.Text = "Yetkili yönetici: " + kullanici;
                GirisPaneli.Visibility = Visibility.Collapsed;
                YonetimPaneli.Visibility = Visibility.Visible;
                RolleriYukle();
                KullanicilariYukle();
                YeniKullaniciFormu();
            }
            catch (Exception hata)
            {
                TxtGirisDurum.Text = "Giriş tamamlanamadı: " + hata.Message;
            }
        }

        private void RolleriYukle()
        {
            using var baglanti = new SqlConnection(baglantiAdresi);
            baglanti.Open();
            if (!AdminYetkisiniKontrolEt(baglanti)) return;
            using var komut = new SqlCommand(
                "SELECT Id, RolAdi FROM dbo.KullaniciRolleri WHERE Aktif=1 ORDER BY RolAdi;", baglanti);
            using var okuyucu = komut.ExecuteReader();
            var tablo = new DataTable();
            tablo.Load(okuyucu);
            CmbYRol.ItemsSource = tablo.DefaultView;
        }

        private void KullanicilariYukle()
        {
            using var baglanti = new SqlConnection(baglantiAdresi);
            baglanti.Open();
            if (!AdminYetkisiniKontrolEt(baglanti)) return;
            using var komut = new SqlCommand(@"
SELECT k.Id, k.KullaniciAdi, k.AdSoyad, k.Eposta, k.Aktif,
       ISNULL((SELECT TOP 1 r.RolAdi FROM dbo.KullaniciRolAtamalari a
               JOIN dbo.KullaniciRolleri r ON r.Id=a.RolId
               WHERE a.KullaniciId=k.Id ORDER BY r.Id),N'Rol atanmadı') AS RolAdi,
       (SELECT TOP 1 a.RolId FROM dbo.KullaniciRolAtamalari a
        WHERE a.KullaniciId=k.Id ORDER BY a.RolId) AS RolId
FROM dbo.Kullanicilar k ORDER BY k.Id;", baglanti);
            using var okuyucu = komut.ExecuteReader();
            var tablo = new DataTable();
            tablo.Load(okuyucu);
            KullanicilarGrid.ItemsSource = tablo.DefaultView;
        }

        private void KullanicilariYenile_Click(object sender, RoutedEventArgs e)
        {
            try { KullanicilariYukle(); }
            catch (Exception hata) { HataGoster("Kullanıcılar yenilenemedi", hata); }
        }

        private void YeniKullanici_Click(object sender, RoutedEventArgs e) => YeniKullaniciFormu();

        private void YeniKullaniciFormu()
        {
            KullanicilarGrid.SelectedItem = null;
            seciliKullaniciId = null;
            TxtFormBasligi.Text = "Yeni Kullanıcı Oluştur";
            TxtYKullaniciAdi.Clear();
            TxtYAdSoyad.Clear();
            TxtYEposta.Clear();
            PwdYeniSifre.Clear();
            ChkYAktif.IsChecked = true;
            // İlk rol olarak yönetici seçilmesini önler; yönetici ataması bilinçli yapılmalıdır.
            CmbYRol.SelectedIndex = -1;
            YetkilerGrid.ItemsSource = null;
            BtnYetkileriKaydet.IsEnabled = false;
        }

        private void KullaniciSecildi(object sender, SelectionChangedEventArgs e)
        {
            if (KullanicilarGrid.SelectedItem is not DataRowView satir) return;
            try
            {
                seciliKullaniciId = Convert.ToInt32(satir["Id"]);
                TxtFormBasligi.Text = "Kullanıcıyı Düzenle: " + Convert.ToString(satir["KullaniciAdi"]);
                TxtYKullaniciAdi.Text = Convert.ToString(satir["KullaniciAdi"]);
                TxtYAdSoyad.Text = Convert.ToString(satir["AdSoyad"]);
                TxtYEposta.Text = satir["Eposta"] == DBNull.Value ? "" : Convert.ToString(satir["Eposta"]);
                ChkYAktif.IsChecked = Convert.ToBoolean(satir["Aktif"]);
                CmbYRol.SelectedValue = satir["RolId"] == DBNull.Value ? null : satir["RolId"];
                PwdYeniSifre.Clear();
                YetkileriYukle(seciliKullaniciId.Value);
                BtnYetkileriKaydet.IsEnabled = true;
            }
            catch (Exception hata) { HataGoster("Kullanıcı yüklenemedi", hata); }
        }

        private void YetkileriYukle(int kullaniciId)
        {
            using var baglanti = new SqlConnection(baglantiAdresi);
            baglanti.Open();
            if (!AdminYetkisiniKontrolEt(baglanti)) return;
            using var komut = new SqlCommand(@"
SELECT y.Id, y.Modul, y.Islem, ky.IzinVerildi
FROM dbo.Yetkiler y
LEFT JOIN dbo.KullaniciYetkileri ky
  ON ky.YetkiId=y.Id AND ky.KullaniciId=@KullaniciId
WHERE y.Aktif=1 AND y.YetkiKodu NOT IN (N'USERS.MANAGE',N'PERMISSIONS.MANAGE')
ORDER BY y.Modul,y.Id;", baglanti);
            komut.Parameters.Add("@KullaniciId", SqlDbType.Int).Value = kullaniciId;
            using var okuyucu = komut.ExecuteReader();
            yetkiSatirlari.Clear();
            while (okuyucu.Read())
            {
                yetkiSatirlari.Add(new YetkiSatiri
                {
                    Id = okuyucu.GetInt32(0),
                    Modul = okuyucu.GetString(1),
                    Islem = okuyucu.GetString(2),
                    Secim = okuyucu.IsDBNull(3) ? "Devral" :
                        okuyucu.GetBoolean(3) ? "İzin ver" : "Engelle"
                });
            }
            YetkilerGrid.ItemsSource = null;
            YetkilerGrid.ItemsSource = yetkiSatirlari;
        }

        private void KullaniciKaydet_Click(object sender, RoutedEventArgs e)
        {
            string kullaniciAdi = TxtYKullaniciAdi.Text.Trim();
            string adSoyad = TxtYAdSoyad.Text.Trim();
            string eposta = TxtYEposta.Text.Trim();
            string sifre = PwdYeniSifre.Password;
            if (kullaniciAdi.Length < 3 || adSoyad.Length < 3 || CmbYRol.SelectedValue is not int rolId)
            {
                MessageBox.Show("Kullanıcı adı/ad soyad en az 3 karakter olmalı ve rol seçilmelidir.", "MiapaxERP");
                return;
            }
            if (!seciliKullaniciId.HasValue && !SifreGecerliMi(sifre))
            {
                MessageBox.Show("Yeni kullanıcı şifresi en az 12 karakter olmalıdır.", "MiapaxERP");
                return;
            }
            int? oncekiId = seciliKullaniciId;
            bool yeniAktif = ChkYAktif.IsChecked == true;
            try
            {
                if(HttpsOturumu.Uzak(baglantiAdresi)){
                    int id=new YardimciEkranServisi(baglantiAdresi,oturumYoneticiId!.Value).KullaniciKaydet(new(seciliKullaniciId,kullaniciAdi,adSoyad,eposta,rolId,yeniAktif,sifre));
                    PwdYeniSifre.Clear();KullanicilariYukle();KullaniciyiTekrarSec(id);MessageBox.Show("Kullanıcı ve rol bilgileri kaydedildi.","MiaPaxERP");return;
                }
                using var baglanti = new SqlConnection(baglantiAdresi);
                baglanti.Open();
                using var islem = baglanti.BeginTransaction(IsolationLevel.Serializable);
                if (!AdminYetkisiniKontrolEt(baglanti, islem)) return;
                bool yeniAdmin;
                using (var komut = new SqlCommand(
                    "SELECT CASE WHEN RolAdi=N'Yönetici' AND Aktif=1 THEN 1 ELSE 0 END " +
                    "FROM dbo.KullaniciRolleri WHERE Id=@Id;", baglanti, islem))
                {
                    komut.Parameters.Add("@Id", SqlDbType.Int).Value = rolId;
                    object? sonuc = komut.ExecuteScalar();
                    if (sonuc == null) throw new InvalidOperationException("Seçilen rol geçersiz.");
                    yeniAdmin = Convert.ToInt32(sonuc) == 1;
                }
                if (oncekiId.HasValue)
                {
                    if (oncekiId == oturumYoneticiId && (!yeniAktif || !yeniAdmin))
                        throw new InvalidOperationException("Kendi yönetici rolünüzü kaldıramaz veya hesabınızı pasife alamazsınız.");
                    bool eskiAdmin = YoneticiMi(baglanti, islem, oncekiId.Value);
                    if (eskiAdmin && (!yeniAdmin || !yeniAktif))
                    {
                        using var sayKomut = new SqlCommand(@"
SELECT COUNT(DISTINCT k.Id) FROM dbo.Kullanicilar k WITH (UPDLOCK, HOLDLOCK)
JOIN dbo.KullaniciRolAtamalari a ON a.KullaniciId=k.Id
JOIN dbo.KullaniciRolleri r ON r.Id=a.RolId
WHERE k.Aktif=1 AND r.Aktif=1 AND r.RolAdi=N'Yönetici';", baglanti, islem);
                        if (Convert.ToInt32(sayKomut.ExecuteScalar()) <= 1)
                            throw new InvalidOperationException("Son aktif yönetici pasife alınamaz veya rolü kaldırılamaz.");
                    }
                    using var komut = new SqlCommand(@"
UPDATE dbo.Kullanicilar SET KullaniciAdi=@KullaniciAdi, AdSoyad=@AdSoyad,
 Eposta=@Eposta, Aktif=@Aktif, GuncellemeTarihiUtc=SYSUTCDATETIME()
WHERE Id=@Id;", baglanti, islem);
                    komut.Parameters.Add("@Id", SqlDbType.Int).Value = oncekiId.Value;
                    komut.Parameters.Add("@KullaniciAdi", SqlDbType.NVarChar, 60).Value = kullaniciAdi;
                    komut.Parameters.Add("@AdSoyad", SqlDbType.NVarChar, 120).Value = adSoyad;
                    komut.Parameters.Add("@Eposta", SqlDbType.NVarChar, 254).Value =
                        eposta.Length == 0 ? DBNull.Value : eposta;
                    komut.Parameters.Add("@Aktif", SqlDbType.Bit).Value = yeniAktif;
                    if (komut.ExecuteNonQuery() != 1)
                        throw new InvalidOperationException("Kullanıcı bulunamadı.");
                }
                else
                {
                    using var komut = new SqlCommand(@"
INSERT INTO dbo.Kullanicilar
(KullaniciAdi,AdSoyad,Eposta,SifreOzeti,Aktif,SifreDegistirmeli)
VALUES (@KullaniciAdi,@AdSoyad,@Eposta,@SifreOzeti,@Aktif,1);
SELECT CAST(SCOPE_IDENTITY() AS INT);", baglanti, islem);
                    komut.Parameters.Add("@KullaniciAdi", SqlDbType.NVarChar, 60).Value = kullaniciAdi;
                    komut.Parameters.Add("@AdSoyad", SqlDbType.NVarChar, 120).Value = adSoyad;
                    komut.Parameters.Add("@Eposta", SqlDbType.NVarChar, 254).Value =
                        eposta.Length == 0 ? DBNull.Value : eposta;
                    komut.Parameters.Add("@SifreOzeti", SqlDbType.NVarChar, 512).Value = SifreOzetiOlustur(sifre);
                    komut.Parameters.Add("@Aktif", SqlDbType.Bit).Value = yeniAktif;
                    oncekiId = Convert.ToInt32(komut.ExecuteScalar());
                }

                using (var temizle = new SqlCommand(
                    "DELETE FROM dbo.KullaniciRolAtamalari WHERE KullaniciId=@Id;", baglanti, islem))
                {
                    temizle.Parameters.Add("@Id", SqlDbType.Int).Value = oncekiId.Value;
                    temizle.ExecuteNonQuery();
                }
                using (var ata = new SqlCommand(
                    "INSERT INTO dbo.KullaniciRolAtamalari (KullaniciId,RolId) VALUES (@Id,@Rol);",
                    baglanti, islem))
                {
                    ata.Parameters.Add("@Id", SqlDbType.Int).Value = oncekiId.Value;
                    ata.Parameters.Add("@Rol", SqlDbType.Int).Value = rolId;
                    ata.ExecuteNonQuery();
                }
                islem.Commit();
                PwdYeniSifre.Clear();
                KullanicilariYukle();
                KullaniciyiTekrarSec(oncekiId.Value);
                MessageBox.Show("Kullanıcı ve rol bilgileri kaydedildi.", "MiapaxERP",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (SqlException hata) when (hata.Number == 2601 || hata.Number == 2627)
            {
                MessageBox.Show("Bu kullanıcı adı zaten kullanılıyor.", "MiapaxERP");
            }
            catch (Exception hata) { HataGoster("Kullanıcı kaydedilemedi", hata); }
        }

        private void KullaniciyiTekrarSec(int id)
        {
            if (KullanicilarGrid.ItemsSource is not DataView gorunum) return;
            foreach (DataRowView satir in gorunum)
            {
                if (Convert.ToInt32(satir["Id"]) != id) continue;
                KullanicilarGrid.SelectedItem = satir;
                break;
            }
        }

        private void SifreSifirla_Click(object sender, RoutedEventArgs e)
        {
            if (!seciliKullaniciId.HasValue)
            {
                MessageBox.Show("Önce kullanıcı seçin.", "MiapaxERP");
                return;
            }
            string sifre = PwdYeniSifre.Password;
            if (!SifreGecerliMi(sifre))
            {
                MessageBox.Show("Yeni şifre en az 12 karakter olmalı.", "MiapaxERP");
                return;
            }
            if (MessageBox.Show("Seçili kullanıcının şifresini sıfırlamak istiyor musunuz?",
                "Şifre Sıfırlama", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
                return;
            try
            {
                if(HttpsOturumu.Uzak(baglantiAdresi)){
                    new YardimciEkranServisi(baglantiAdresi,oturumYoneticiId!.Value).KullaniciSifreSifirla(seciliKullaniciId.Value,sifre);
                    PwdYeniSifre.Clear();MessageBox.Show("Şifre sıfırlandı. Kullanıcı girişte kendi şifresini belirlemeli.","MiaPaxERP");return;
                }
                using var baglanti = new SqlConnection(baglantiAdresi);
                baglanti.Open();
                using var islem = baglanti.BeginTransaction();
                if (!AdminYetkisiniKontrolEt(baglanti, islem)) return;
                using var komut = new SqlCommand(@"
UPDATE dbo.Kullanicilar SET SifreOzeti=@Ozet, SifreDegistirmeli=1,
 BasarisizGirisSayisi=0, KilitBitisUtc=NULL, GuncellemeTarihiUtc=SYSUTCDATETIME()
WHERE Id=@Id;", baglanti, islem);
                komut.Parameters.Add("@Ozet", SqlDbType.NVarChar, 512).Value = SifreOzetiOlustur(sifre);
                komut.Parameters.Add("@Id", SqlDbType.Int).Value = seciliKullaniciId.Value;
                if (komut.ExecuteNonQuery() != 1)
                    throw new InvalidOperationException("Kullanıcı bulunamadı.");
                islem.Commit();
                PwdYeniSifre.Clear();
                MessageBox.Show("Şifre sıfırlandı. İlk girişte şifre değiştirme zorunluluğunu giriş ekranında etkinleştireceğiz.",
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception hata) { HataGoster("Şifre sıfırlanamadı", hata); }
        }

        private void YetkileriKaydet_Click(object sender, RoutedEventArgs e)
        {
            if (!seciliKullaniciId.HasValue)
            {
                MessageBox.Show("Önce kayıtlı kullanıcı seçin.", "MiapaxERP");
                return;
            }
            // ComboBox yazdığı değeri kontrol kaybolmadan modele işlesin.
            YetkilerGrid.CommitEdit(DataGridEditingUnit.Cell, true);
            YetkilerGrid.CommitEdit(DataGridEditingUnit.Row, true);
            int id = seciliKullaniciId.Value;
            try
            {
                if(HttpsOturumu.Uzak(baglantiAdresi)){
                    var kararlar=yetkiSatirlari.Select(y=>new ErpYetkiKarari(y.Id,y.Secim=="Devral"?(bool?)null:y.Secim=="İzin ver"?true:y.Secim=="Engelle"?false:throw new ArgumentException("Yetki kararı geçersiz."))).ToArray();
                    new YardimciEkranServisi(baglantiAdresi,oturumYoneticiId!.Value).KullaniciYetkileri(id,kararlar);MessageBox.Show("Kullanıcı yetkileri sunucuda güncellendi.","MiaPaxERP");return;
                }
                using var baglanti = new SqlConnection(baglantiAdresi);
                baglanti.Open();
                using var islem = baglanti.BeginTransaction(IsolationLevel.Serializable);
                if (!AdminYetkisiniKontrolEt(baglanti, islem)) return;
                using (var sil = new SqlCommand(@"
DELETE ky FROM dbo.KullaniciYetkileri ky
JOIN dbo.Yetkiler y ON y.Id=ky.YetkiId
WHERE ky.KullaniciId=@Id
 AND y.YetkiKodu NOT IN (N'USERS.MANAGE',N'PERMISSIONS.MANAGE');", baglanti, islem))
                {
                    sil.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                    sil.ExecuteNonQuery();
                }
                foreach (YetkiSatiri yetki in yetkiSatirlari)
                {
                    if (yetki.Secim == "Devral") continue;
                    if (yetki.Secim != "İzin ver" && yetki.Secim != "Engelle")
                        throw new InvalidOperationException("Tanımsız yetki kararı.");
                    using var ekle = new SqlCommand(@"
INSERT INTO dbo.KullaniciYetkileri
(KullaniciId,YetkiId,IzinVerildi,GuncelleyenKullaniciId)
VALUES (@Id,@Yetki,@Izin,@Admin);", baglanti, islem);
                    ekle.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                    ekle.Parameters.Add("@Yetki", SqlDbType.Int).Value = yetki.Id;
                    ekle.Parameters.Add("@Izin", SqlDbType.Bit).Value = yetki.Secim == "İzin ver";
                    ekle.Parameters.Add("@Admin", SqlDbType.Int).Value = oturumYoneticiId!.Value;
                    ekle.ExecuteNonQuery();
                }
                islem.Commit();
                MessageBox.Show("Seçili kullanıcının yetkileri kaydedildi. Diğer modüllerde fiili engelleme sonraki aşamada etkinleşecek.",
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception hata) { HataGoster("Yetkiler kaydedilemedi", hata); }
        }

        private static void HataGoster(string baslik, Exception hata)
        {
            MessageBox.Show(baslik + ":\n\n" + hata.Message, "MiapaxERP",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}
