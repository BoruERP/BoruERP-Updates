using SqlConnection = MiapaxERP.Desktop.ErpSqlConnection;
using SqlCommand = MiapaxERP.Desktop.ErpSqlCommand;
using SqlTransaction = MiapaxERP.Desktop.ErpSqlTransaction;
using SqlDataReader = MiapaxERP.Desktop.ErpSqlReader;
using SqlDataAdapter = MiapaxERP.Desktop.ErpSqlDataAdapter;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop {
public partial class MainWindow {
 private readonly DispatcherTimer takvimZamanlayici = new() { Interval=TimeSpan.FromSeconds(30) };
 private readonly HashSet<string> takvimBildirilen = new();
 private bool takvimBasladi;
 private bool takvimKontrolSuruyor;
 private bool takvimAcilisBekliyor;
 private int? takvimOturumu;
 private int takvimOturumNesli;
 private Window? takvimUyariPenceresi;
 private sealed class TakvimKaydi { public int Id {get;set;} public DateTime Tarih {get;set;} public string Baslik {get;set;}=""; public string Tur {get;set;}=""; public string Durum {get;set;}=""; }
 private void TakvimBaslat() { if(takvimBasladi)return; takvimBasladi=true; IsTakvimiTakvim.SelectedDate=DateTime.Today; takvimZamanlayici.Tick+=(_,_)=>TakvimSaatKontrol(); takvimZamanlayici.Start(); TakvimYenile(); }
 private bool TakvimYetki(SqlConnection db,string kod,SqlTransaction? tx=null) => aktifKullanici!=null && StokSqlYetkisiVar(db,tx,aktifKullanici.KullaniciId,kod);
 private bool TakvimYetki(string kod) { if(aktifKullanici==null || DemoModu)return false; try {using var db=new SqlConnection(baglantiAdresi);db.Open();return TakvimYetki(db,kod);}catch{return false;} }
 private bool TakvimIzin(string kod) {if(TakvimYetki(kod))return true;MessageBox.Show("Yetkiniz yok: "+kod,"MiapaxERP",MessageBoxButton.OK,MessageBoxImage.Warning);return false;}
 private void TakvimYenile_Click(object sender,RoutedEventArgs e)=>TakvimYenile();
 private void TakvimTarihDegisti(object sender,SelectionChangedEventArgs e)=>TakvimYenile();
 private List<TakvimKaydi> TakvimOku(DateTime ilk,DateTime son,bool sadeceBekleyen, int? kullanici = null) {
  var liste=new List<TakvimKaydi>(); int? user = kullanici ?? aktifKullanici?.KullaniciId; if(user==null)return liste;
  using var db=new SqlConnection(baglantiAdresi);db.Open();if(!StokSqlYetkisiVar(db,null,user.Value,"CALENDAR.VIEW"))throw new UnauthorizedAccessException("İş takvimini görüntüleme yetkiniz bulunmuyor.");
  bool tum=StokSqlYetkisiVar(db,null,user.Value,"CALENDAR.ALL");
  using var cmd=new SqlCommand(@"SELECT Id,PlanTarihi,Baslik,Tur,Durum FROM dbo.IsTakvimi WHERE PlanTarihi>=@Ilk AND PlanTarihi<@Son AND (@Bek=0 OR Durum=N'Bekliyor') AND (@Tum=1 OR OlusturanKullaniciId=@K OR AtananKullaniciId=@K) ORDER BY PlanTarihi",db);
  cmd.Parameters.Add("@Ilk",SqlDbType.DateTime2).Value=ilk;cmd.Parameters.Add("@Son",SqlDbType.DateTime2).Value=son;
  cmd.Parameters.Add("@Bek",SqlDbType.Bit).Value=sadeceBekleyen;cmd.Parameters.Add("@Tum",SqlDbType.Bit).Value=tum;cmd.Parameters.Add("@K",SqlDbType.Int).Value=user.Value;
  using var rd=cmd.ExecuteReader();while(rd.Read())liste.Add(new TakvimKaydi{Id=rd.GetInt32(0),Tarih=rd.GetDateTime(1),Baslik=rd.GetString(2),Tur=rd.GetString(3),Durum=rd.GetString(4)});return liste;
 }
 private void TakvimYenile() {
  bool gor=TakvimYetki("CALENDAR.VIEW");
  BrdIsTakvimi.Visibility=aktifKullanici!=null ? Visibility.Visible : Visibility.Collapsed;
  IsTakvimiTakvim.IsEnabled=gor;
  IsTakvimiListe.IsEnabled=gor;
  BtnTakvimYeni.Visibility=gor ? Visibility.Visible : Visibility.Collapsed;
  BtnTakvimTamamla.Visibility=gor ? Visibility.Visible : Visibility.Collapsed;
  BtnTakvimIptal.Visibility=gor ? Visibility.Visible : Visibility.Collapsed;
  if(!gor){
   IsTakvimiListe.ItemsSource=null;
   TxtTakvimDurum.Text=aktifKullanici==null ? "Takvim için önce oturum açın." :
     "İş takvimi görüntüleme yetkisi (CALENDAR.VIEW) bulunmuyor veya SQL bağlantısı kurulamadı. Yönetici yetkileri ve takvim tablosunu kontrol edin.";
   BrdTakvimAcilUyari.Visibility=Visibility.Collapsed;
   return;
  }
  BtnTakvimYeni.IsEnabled=TakvimYetki("CALENDAR.CREATE");BtnTakvimTamamla.IsEnabled=TakvimYetki("CALENDAR.COMPLETE");BtnTakvimIptal.IsEnabled=TakvimYetki("CALENDAR.CANCEL");
  try {DateTime gun=IsTakvimiTakvim.SelectedDate??DateTime.Today;var liste=TakvimOku(gun.Date,gun.Date.AddDays(1),false);IsTakvimiListe.ItemsSource=liste;TxtTakvimDurum.Text=$"{gun:dd.MM.yyyy} • {liste.Count} plan";}
  catch(Exception ex){TxtTakvimDurum.Text="Takvim hatası: "+ex.Message;IsTakvimiListe.ItemsSource=null;}
 }
 private void TakvimYeni_Click(object sender,RoutedEventArgs e) {
  if(!TakvimIzin("CALENDAR.CREATE"))return;
  var p=new TakvimPlanPenceresi {Owner=this,PlanTarihi=TakvimPlanPenceresi.OnerilenSaat(IsTakvimiTakvim.SelectedDate??DateTime.Today,DateTime.Now)};if(p.ShowDialog()!=true)return;
  try {if(HttpsOturumu.Uzak(baglantiAdresi)){new YardimciEkranServisi(baglantiAdresi,aktifKullanici!.KullaniciId).TakvimEkle(p.PlanBaslik,p.PlanAciklama,p.PlanTur,p.PlanTarihi);}
else{using var db=new SqlConnection(baglantiAdresi);db.Open();using var tx=db.BeginTransaction();if(!TakvimYetki(db,"CALENDAR.CREATE",tx))throw new UnauthorizedAccessException();
   using var cmd=new SqlCommand(@"INSERT INTO dbo.IsTakvimi(Baslik,Aciklama,Tur,PlanTarihi,OlusturanKullaniciId,AtananKullaniciId,Durum) VALUES(@B,@A,@T,@P,@K,@K,N'Bekliyor')",db,tx);
   cmd.Parameters.Add("@B",SqlDbType.NVarChar,180).Value=p.PlanBaslik;cmd.Parameters.Add("@A",SqlDbType.NVarChar,1000).Value=p.PlanAciklama;cmd.Parameters.Add("@T",SqlDbType.NVarChar,60).Value=p.PlanTur;
   cmd.Parameters.Add("@P",SqlDbType.DateTime2).Value=p.PlanTarihi;cmd.Parameters.Add("@K",SqlDbType.Int).Value=aktifKullanici!.KullaniciId;cmd.ExecuteNonQuery();tx.Commit();
}
   IsTakvimiTakvim.SelectedDate=p.PlanTarihi.Date;TakvimYenile();TakvimSaatKontrol();}
  catch(Exception ex){MessageBox.Show("Plan kaydedilemedi: "+ex.Message);}
 }
 private void TakvimTamamla_Click(object sender,RoutedEventArgs e)=>TakvimDurum("Tamamlandı","CALENDAR.COMPLETE");
 private void TakvimIptal_Click(object sender,RoutedEventArgs e)=>TakvimDurum("İptal","CALENDAR.CANCEL");
 private void TakvimDurum(string durum,string yetki) {
  if(!TakvimIzin(yetki)||IsTakvimiListe.SelectedItem is not TakvimKaydi secili)return;
  if(MessageBox.Show($"{secili.Baslik} → {durum}?","Onay",MessageBoxButton.YesNo)!=MessageBoxResult.Yes)return;
  try {if(HttpsOturumu.Uzak(baglantiAdresi)){new YardimciEkranServisi(baglantiAdresi,aktifKullanici!.KullaniciId).TakvimDurum(secili.Id,durum);}
else{using var db=new SqlConnection(baglantiAdresi);db.Open();using var tx=db.BeginTransaction();if(!TakvimYetki(db,yetki,tx))throw new UnauthorizedAccessException();bool tum=TakvimYetki(db,"CALENDAR.ALL",tx);
   using var cmd=new SqlCommand(@"UPDATE dbo.IsTakvimi SET Durum=@D,DegistirenKullaniciId=@K,DegistirmeTarihi=SYSUTCDATETIME() WHERE Id=@Id AND Durum=N'Bekliyor' AND (@Tum=1 OR OlusturanKullaniciId=@K OR AtananKullaniciId=@K)",db,tx);
   cmd.Parameters.Add("@D",SqlDbType.NVarChar,30).Value=durum;cmd.Parameters.Add("@K",SqlDbType.Int).Value=aktifKullanici!.KullaniciId;cmd.Parameters.Add("@Id",SqlDbType.Int).Value=secili.Id;cmd.Parameters.Add("@Tum",SqlDbType.Bit).Value=tum;
   if(cmd.ExecuteNonQuery()!=1)throw new InvalidOperationException("Plan bulunamadı veya işlenmiş.");tx.Commit();}
TakvimYenile();TakvimSaatKontrol();}
  catch(Exception ex){MessageBox.Show("İşlem yapılamadı: "+ex.Message);}
 }
 private void TakvimOturumunuTemizle() {
  takvimOturumNesli++;
  takvimBildirilen.Clear(); takvimOturumu=null; takvimAcilisBekliyor=false;
  takvimUyariPenceresi?.Close(); takvimUyariPenceresi=null;
  BrdTakvimAcilUyari.Visibility=Visibility.Collapsed;
  TxtTakvimAcilUyari.Text=""; IsTakvimiListe.ItemsSource=null;
  BtnTakvimBildirim.Content="Takvim"; BrdIsTakvimi.Visibility=Visibility.Collapsed;
  TxtTakvimDurum.Text="Takvim için oturum açın.";
 }
 private void TakvimAcilisUyarisi() { takvimAcilisBekliyor=true; _=TakvimKontrolAsync(false); }
 private void TakvimSaatKontrol() => _=TakvimKontrolAsync(false);
 private async void TakvimBildirimleri_Click(object sender,RoutedEventArgs e) => await TakvimKontrolAsync(true);
 private async System.Threading.Tasks.Task TakvimKontrolAsync(bool elle) {
  if(aktifKullanici==null || DemoModu || takvimKontrolSuruyor)return;
  int user=aktifKullanici.KullaniciId; int nesil=takvimOturumNesli;
  if(takvimOturumu!=user){takvimBildirilen.Clear();takvimOturumu=user;takvimAcilisBekliyor=true;}
  takvimKontrolSuruyor=true;
  try {
   var now=DateTime.Now;
   var kayitlar=await System.Threading.Tasks.Task.Run(()=>TakvimOku(DateTime.MinValue,now.Date.AddDays(2),true,user));
   if(aktifKullanici?.KullaniciId!=user || takvimOturumNesli!=nesil || !IsLoaded)return;
   var plans=kayitlar.Select(k=>new TakvimHatirlatma(k.Id,k.Tarih,k.Baslik,k.Durum)).Where(k=>k.OzetteGoster(now)).ToList();
   bool acilis=takvimAcilisBekliyor; takvimAcilisBekliyor=false;
   string summary=plans.Count==0?"Bugün, yarın veya geçmiş tarihlerde bekleyen planınız yok.":
    $"{plans.Count} bekleyen plan\n\n"+string.Join("\n",plans.Take(20).Select(k=>k.Satir(now)))+(plans.Count>20?"\n\nDiğer planları iş takviminde görebilirsiniz.":"");
   TxtTakvimAcilUyari.Text=summary;BrdTakvimAcilUyari.Visibility=plans.Count>0?Visibility.Visible:Visibility.Collapsed;
   BtnTakvimBildirim.Content=$"Takvim ({plans.Count})";
   var due=plans.Where(k=>k.ZamaniGeldi(now) && !takvimBildirilen.Contains(k.Anahtar)).ToList();
   if(elle || acilis && plans.Count>0) {
    foreach(var k in due)takvimBildirilen.Add(k.Anahtar);
    MessageBox.Show(this,summary,"İş takvimi • Hatırlatmalar",MessageBoxButton.OK,MessageBoxImage.Information);
   } else if(due.Count>0 && takvimUyariPenceresi==null) {
    var dialog=new ModernMesajPenceresi(string.Join("\n",due.Take(8).Select(k=>k.Satir(now))),"Planın zamanı geldi",MessageBoxButton.OK,MessageBoxImage.Information,MessageBoxResult.OK) { Owner=this };
    takvimUyariPenceresi=dialog;
    var timer=new DispatcherTimer { Interval=TimeSpan.FromSeconds(25) };
    timer.Tick+=(_,_)=>dialog.Close(); dialog.Closed+=(_,_)=>{timer.Stop();takvimUyariPenceresi=null;};
    dialog.Show();timer.Start();
    foreach(var k in due)takvimBildirilen.Add(k.Anahtar);
   }
  } catch(Exception ex) {
   if(aktifKullanici?.KullaniciId!=user || takvimOturumNesli!=nesil)return;
   TxtTakvimDurum.Text="Hatırlatmalar alınamadı; bağlantı düzelince yeniden denenecek: "+ex.Message;
   if(ex is UnauthorizedAccessException){BrdTakvimAcilUyari.Visibility=Visibility.Collapsed;BtnTakvimBildirim.Content="Takvim";}
   if(elle)MessageBox.Show(this,ex.Message,"Hatırlatmalar alınamadı",MessageBoxButton.OK,MessageBoxImage.Warning);
  }
  finally {takvimKontrolSuruyor=false;}
 }
}
}
