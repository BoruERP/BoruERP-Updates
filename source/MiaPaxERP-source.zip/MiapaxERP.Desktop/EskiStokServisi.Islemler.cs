using System.Data;
using System.Globalization;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed partial class EskiStokServisi {
public void Acilis(int stokId,decimal miktar,string aciklama){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiStokServisi.Acilis","",new object?[]{stokId,miktar,aciklama});return;}
if(stokId<1)throw new ArgumentException("Stok seçin.");Miktar(miktar);Metin(aciklama,0,500);using (SqlConnection baglanti = new SqlConnection(connection))
                {
                    baglanti.Open();
                    using (SqlTransaction islem = baglanti.BeginTransaction(IsolationLevel.Serializable))
                    {
                        try
                        {
                            StokSqlYetkisiZorunlu(baglanti, islem, "STOCK.OPENING");
                            string stokBirim;
                            using (SqlCommand komut = new SqlCommand(
                                "SELECT Birim FROM dbo.StokKartlari WITH (UPDLOCK, HOLDLOCK) " +
                                "WHERE Id=@Id AND Aktif=1;", baglanti, islem))
                            {
                                komut.Parameters.Add("@Id", SqlDbType.Int).Value = stokId;
                                stokBirim = Convert.ToString(komut.ExecuteScalar()) ?? "";
                            }
                            if (string.IsNullOrWhiteSpace(stokBirim))
                                throw new InvalidOperationException("Aktif stok kartı ve birim bulunamadı.");

                            using (SqlCommand komut = new SqlCommand(
                                "SELECT CASE WHEN EXISTS(SELECT 1 FROM dbo.StokBakiyeleri " +
                                "WITH (UPDLOCK, HOLDLOCK) WHERE StokKartId=@Id) " +
                                "OR EXISTS(SELECT 1 FROM dbo.StokHareketleri WITH (UPDLOCK, HOLDLOCK) " +
                                "WHERE StokKartId=@Id) THEN 1 ELSE 0 END;", baglanti, islem))
                            {
                                komut.Parameters.Add("@Id", SqlDbType.Int).Value = stokId;
                                if (Convert.ToInt32(komut.ExecuteScalar()) != 0)
                                    throw new InvalidOperationException(
                                        "Bu stok kartında bakiye veya stok hareketi zaten var. İkinci açılış kaydı engellendi.");
                            }

                            using (SqlCommand komut = new SqlCommand(
                                "INSERT INTO dbo.StokBakiyeleri (StokKartId, Birim, Miktar) " +
                                "VALUES (@Id, @Birim, @Miktar);", baglanti, islem))
                            {
                                komut.Parameters.Add("@Id", SqlDbType.Int).Value = stokId;
                                komut.Parameters.Add("@Birim", SqlDbType.NVarChar, 20).Value = stokBirim;
                                var miktarParam = komut.Parameters.Add("@Miktar", SqlDbType.Decimal);
                                miktarParam.Precision = 18;
                                miktarParam.Scale = 3;
                                miktarParam.Value = miktar;
                                komut.ExecuteNonQuery();
                            }
                            using (SqlCommand komut = new SqlCommand(
                                "INSERT INTO dbo.StokHareketleri " +
                                "(StokKartId, HareketTipi, Yon, Miktar, Birim, Aciklama) " +
                                "VALUES (@Id, N'ACILIS_GIRIS', N'G', @Miktar, @Birim, @Aciklama);",
                                baglanti, islem))
                            {
                                komut.Parameters.Add("@Id", SqlDbType.Int).Value = stokId;
                                komut.Parameters.Add("@Birim", SqlDbType.NVarChar, 20).Value = stokBirim;
                                var miktarParam = komut.Parameters.Add("@Miktar", SqlDbType.Decimal);
                                miktarParam.Precision = 18;
                                miktarParam.Scale = 3;
                                miktarParam.Value = miktar;
                                komut.Parameters.Add("@Aciklama", SqlDbType.NVarChar, 500).Value =
                                    string.IsNullOrWhiteSpace(aciklama) ? DBNull.Value :
                                    aciklama.Trim();
                                komut.ExecuteNonQuery();
                            }
                            new IsletmeServisi(connection,user).StokPartile(baglanti,islem,stokId,miktar,"G",null,aciklama);
islem.Commit();
                        }
                        catch
                        {
                            islem.Rollback();
                            throw;
                        }
                    }
                }}
public decimal Hareket(ErpStokHareketi g){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<decimal>(connection,"EskiStokServisi.Hareket","",new object?[]{g});}

Miktar(g.Miktar);Metin(g.Aciklama,0,500);if(g.Stok<1||g.Yon is not("G" or "C")||g.SatinAlma&&(g.Yon!="G"||!g.Tedarikci.HasValue||!g.AlimTarihi.HasValue||g.Fiyat<0||g.Fiyat>99999999999999.9999m||decimal.Round(g.Fiyat,4)!=g.Fiyat||g.Para is not("TRY" or "USD" or "EUR" or "GBP")))throw new ArgumentException("Hareket/alış bilgileri geçersiz.");
int stokId=g.Stok;string yon=g.Yon;decimal miktar=g.Miktar;string aciklama=g.Aciklama;bool satinAlma=g.SatinAlma;int? tedarikciId=g.Tedarikci;DateTime? alimTarihi=g.AlimTarihi;decimal alisFiyati=g.Fiyat;string paraBirimi=g.Para;string hareketYetkisi=yon=="G"?"STOCK.RECEIVE":"STOCK.ISSUE";decimal sonBakiye;
using (SqlConnection baglanti = new SqlConnection(connection))
                {
                    baglanti.Open();
                    using (SqlTransaction islem = baglanti.BeginTransaction(IsolationLevel.Serializable))
                    {
                        try
                        {
                            StokSqlYetkisiZorunlu(baglanti,islem,hareketYetkisi);
if(satinAlma){access.Yetki(baglanti,islem,"CUSTOMER.VIEW");using var supplier=ErpModulServisi.Komut(baglanti,islem,"SELECT COUNT(*) FROM dbo.CariKartlari WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Aktif=1",("@id",tedarikciId));if(Convert.ToInt32(supplier.ExecuteScalar())!=1)throw new ArgumentException("Aktif tedarikçi seçin.");}
                            string birim;
                            using (SqlCommand komut = new SqlCommand(
                                "SELECT Birim FROM dbo.StokKartlari WITH (UPDLOCK, HOLDLOCK) " +
                                "WHERE Id=@Id AND Aktif=1;", baglanti, islem))
                            {
                                komut.Parameters.Add("@Id", SqlDbType.Int).Value = stokId;
                                birim = Convert.ToString(komut.ExecuteScalar()) ?? "";
                            }
                            if (string.IsNullOrWhiteSpace(birim))
                                throw new InvalidOperationException("Aktif stok kartı veya birimi bulunamadı.");

                            decimal mevcutBakiye = 0;
                            string? bakiyeBirimi = null;
                            bool bakiyeVar;
                            using (SqlCommand komut = new SqlCommand(
                                "SELECT Miktar, Birim FROM dbo.StokBakiyeleri WITH (UPDLOCK, HOLDLOCK) " +
                                "WHERE StokKartId=@Id;", baglanti, islem))
                            {
                                komut.Parameters.Add("@Id", SqlDbType.Int).Value = stokId;
                                using (SqlDataReader okuyucu = komut.ExecuteReader())
                                {
                                    bakiyeVar = okuyucu.Read();
                                    if (bakiyeVar)
                                    {
                                        mevcutBakiye = okuyucu.GetDecimal(0);
                                        bakiyeBirimi = okuyucu.GetString(1);
                                    }
                                }
                            }
                            if (bakiyeVar && !string.Equals(bakiyeBirimi, birim,
                                StringComparison.OrdinalIgnoreCase))
                                throw new InvalidOperationException("Stok kartı ile bakiye birimi farklı. İşlem durduruldu.");
                            if (!bakiyeVar && yon == "C")
                                throw new InvalidOperationException("Çıkış için stok bakiyesi yok. Önce giriş kaydetmelisiniz.");
                            if (yon == "C" && mevcutBakiye < miktar)
                                throw new InvalidOperationException("Yetersiz stok. Güncel miktar: " +
                                    mevcutBakiye.ToString("0.###", CultureInfo.GetCultureInfo("tr-TR")) + " " + birim);
                            sonBakiye = yon == "G" ? mevcutBakiye + miktar : mevcutBakiye - miktar;

                            if (!bakiyeVar)
                            {
                                using (SqlCommand komut = new SqlCommand(
                                    "INSERT INTO dbo.StokBakiyeleri (StokKartId,Birim,Miktar) " +
                                    "VALUES(@Id,@Birim,@Miktar);", baglanti, islem))
                                {
                                    komut.Parameters.Add("@Id", SqlDbType.Int).Value = stokId;
                                    komut.Parameters.Add("@Birim", SqlDbType.NVarChar, 20).Value = birim;
                                    HareketOndalikParametre(komut, "@Miktar", sonBakiye);
                                    komut.ExecuteNonQuery();
                                }
                            }
                            else
                            {
                                using (SqlCommand komut = new SqlCommand(
                                    "UPDATE dbo.StokBakiyeleri SET Miktar=@Miktar, " +
                                    "SonGuncelleme=SYSDATETIME() WHERE StokKartId=@Id;", baglanti, islem))
                                {
                                    komut.Parameters.Add("@Id", SqlDbType.Int).Value = stokId;
                                    HareketOndalikParametre(komut, "@Miktar", sonBakiye);
                                    if (komut.ExecuteNonQuery() != 1)
                                        throw new InvalidOperationException("Stok bakiyesi güncellenemedi.");
                                }
                            }

                            using (SqlCommand komut = new SqlCommand(
                                "INSERT INTO dbo.StokHareketleri " +
                                "(StokKartId, HareketTipi, Yon, Miktar, Birim, Aciklama) " +
                                "OUTPUT INSERTED.Id VALUES (@Id, @Tip, @Yon, @Miktar, @Birim, @Aciklama);", baglanti, islem))
                            {
                                komut.Parameters.Add("@Id", SqlDbType.Int).Value = stokId;
                                komut.Parameters.Add("@Tip", SqlDbType.NVarChar, 40).Value =
                                    yon == "G" ? "MANUEL_GIRIS" : "MANUEL_CIKIS";
                                komut.Parameters.Add("@Yon", SqlDbType.NChar, 1).Value = yon;
                                komut.Parameters.Add("@Birim", SqlDbType.NVarChar, 20).Value = birim;
                                HareketOndalikParametre(komut, "@Miktar", miktar);
                                komut.Parameters.Add("@Aciklama", SqlDbType.NVarChar, 500).Value =
                                    string.IsNullOrEmpty(aciklama) ? DBNull.Value : aciklama;
                                long hareketId = Convert.ToInt64(komut.ExecuteScalar());
                                if (hareketId <= 0)
                                    throw new InvalidOperationException("Stok hareket kaydı oluşturulamadı.");
                                if (satinAlma)
                                {
                                    using var alimKomut = new SqlCommand(
                                        "INSERT INTO dbo.StokAlimKayitlari " +
                                        "(StokKartId, StokHareketId, CariKartId, AlimTarihi, Miktar, BirimFiyat, ParaBirimi, Aciklama) " +
                                        "VALUES (@Stok, @Hareket, @Cari, @Tarih, @Miktar, @Fiyat, @Doviz, @Aciklama);",
                                        baglanti, islem);
                                    alimKomut.Parameters.Add("@Stok", SqlDbType.Int).Value = stokId;
                                    alimKomut.Parameters.Add("@Hareket", SqlDbType.BigInt).Value = hareketId;
                                    alimKomut.Parameters.Add("@Cari", SqlDbType.Int).Value = tedarikciId!.Value;
                                    alimKomut.Parameters.Add("@Tarih", SqlDbType.Date).Value = alimTarihi!.Value.Date;
                                    HareketOndalikParametre(alimKomut, "@Miktar", miktar);
                                    var fiyatParam = alimKomut.Parameters.Add("@Fiyat", SqlDbType.Decimal);
                                    fiyatParam.Precision = 18;
                                    fiyatParam.Scale = 4;
                                    fiyatParam.Value = alisFiyati;
                                    alimKomut.Parameters.Add("@Doviz", SqlDbType.Char, 3).Value = paraBirimi;
                                    alimKomut.Parameters.Add("@Aciklama", SqlDbType.NVarChar, 500).Value =
                                        string.IsNullOrEmpty(aciklama) ? DBNull.Value : aciklama;
                                    if (alimKomut.ExecuteNonQuery() != 1)
                                        throw new InvalidOperationException("Alış detayları kaydedilemedi.");
                                }
                            }
                            new IsletmeServisi(connection,user).StokPartile(baglanti,islem,stokId,miktar,yon,satinAlma&&paraBirimi=="TRY"?alisFiyati:null,aciklama);
islem.Commit();
                        }
                        catch
                        {
                            islem.Rollback();
                            throw;
                        }
                    }
                }return sonBakiye;}
public void Minimum(int stokId,decimal? minimum){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiStokServisi.Minimum","",new object?[]{stokId,minimum});return;}
if(stokId<1)throw new ArgumentException("Stok seçin.");if(minimum.HasValue)Miktar(minimum.Value);using (SqlConnection baglanti = new SqlConnection(connection))
                {
                    baglanti.Open();
                    StokSqlYetkisiZorunlu(baglanti, null, "STOCK.MINIMUM");
                    using (SqlCommand komut = new SqlCommand(
                        "UPDATE dbo.StokKartlari SET MinimumStokMiktari=@Minimum " +
                        "WHERE Id=@Id AND Aktif=1;", baglanti))
                    {
                        komut.Parameters.Add("@Id", SqlDbType.Int).Value = stokId;
                        SqlParameter param = komut.Parameters.Add("@Minimum", SqlDbType.Decimal);
                        param.Precision = 18;
                        param.Scale = 3;
                        param.Value = minimum.HasValue ? minimum.Value : DBNull.Value;
                        if (komut.ExecuteNonQuery() != 1)
                            throw new InvalidOperationException("Aktif stok kartı bulunamadı.");
                    }
                }}
public int Durum(int stokId,bool aktifYap){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<int>(connection,"EskiStokServisi.Durum","",new object?[]{stokId,aktifYap});}
if(stokId<1)throw new ArgumentException("Stok seçin.");int sonuc;using (SqlConnection baglanti = new SqlConnection(connection))
                    {
                        baglanti.Open();
                        StokSqlYetkisiZorunlu(baglanti, null, "STOCK.STATUS");
                        using (SqlCommand komut = baglanti.CreateCommand())
                        {
                            komut.CommandText =
                                "UPDATE dbo.StokKartlari SET Aktif = @Aktif " +
                                "WHERE Id = @Id AND Aktif <> @Aktif";
                            komut.Parameters.Add("@Aktif", SqlDbType.Bit).Value = aktifYap;
                            komut.Parameters.Add("@Id", SqlDbType.Int).Value = stokId;
                            sonuc = komut.ExecuteNonQuery();
                        }
                    }return sonuc;}
public void Kaydet(ErpStokGirdisi g){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiStokServisi.Kaydet","",new object?[]{g});return;}
Dogrula(g);string stokYazmaYetkisi=g.Id.HasValue?"STOCK.EDIT":"STOCK.CREATE";using (SqlConnection baglanti =
                        new SqlConnection(connection))
                    {
                        baglanti.Open();
                        using SqlTransaction stokTx = baglanti.BeginTransaction(IsolationLevel.Serializable);
                        StokSqlYetkisiZorunlu(baglanti, stokTx, stokYazmaYetkisi);
string tipAd;
using(var tipQuery=ErpModulServisi.Komut(baglanti,stokTx,"SELECT Ad FROM dbo.StokTipleri WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Aktif=1",("@id",g.Tip)))tipAd=Convert.ToString(tipQuery.ExecuteScalar())??"";
if(tipAd.Length==0)throw new ArgumentException("Aktif stok tipi seçin.");


                        using (SqlCommand komut =
                            baglanti.CreateCommand())
                        {
                            komut.Transaction = stokTx;
                            if (g.Id.HasValue)
                            {
                                komut.CommandText =
                                    "UPDATE dbo.StokKartlari SET " +
                                    "StokKodu=@StokKodu, " +
                                    "StokAdi=@StokAdi, " +
                                    "StokTipi=@StokTipi, " +
                                    "Birim=@Birim, " +
                                    "Aciklama=@Aciklama, " +
                                    "CapMm=@CapMm, BasincSinifi=@BasincSinifi, " +
                                    "UzunlukMetre=@UzunlukMetre, Renk=@Renk, " +
                                    "EtKalinligiMm=@EtKalinligiMm, " +
                                    "HammaddeTuru=@HammaddeTuru, AgirlikKg=@AgirlikKg " +
                                    "WHERE Id=@Id AND (Birim=@Birim OR (" +
                                    "NOT EXISTS (SELECT 1 FROM dbo.StokBakiyeleri WHERE StokKartId=@Id) AND " +
                                    "NOT EXISTS (SELECT 1 FROM dbo.StokHareketleri WHERE StokKartId=@Id)))";

                                komut.Parameters.Add(
                                    "@Id", SqlDbType.Int).Value =
                                    g.Id.Value;
                            }
                            else
                            {
                                komut.CommandText =
                                    "INSERT INTO dbo.StokKartlari " +
                                    "(StokKodu, StokAdi, StokTipi, " +
                                    "Birim, Aciklama, CapMm, BasincSinifi, " +
                                    "UzunlukMetre, Renk, EtKalinligiMm, " +
                                    "HammaddeTuru, AgirlikKg) OUTPUT INSERTED.Id VALUES " +
                                    "(@StokKodu, @StokAdi, @StokTipi, " +
                                    "@Birim, @Aciklama, @CapMm, @BasincSinifi, " +
                                    "@UzunlukMetre, @Renk, @EtKalinligiMm, " +
                                    "@HammaddeTuru, @AgirlikKg)";
                            }

                            komut.Parameters.Add(
                                "@StokKodu",
                                SqlDbType.NVarChar, 50).Value =
                                g.Kod;

                            komut.Parameters.Add(
                                "@StokAdi",
                                SqlDbType.NVarChar, 200).Value =
                                g.Ad;

                            komut.Parameters.Add(
                                "@StokTipi",
                                SqlDbType.NVarChar, 30).Value =
                                tipAd;

                            komut.Parameters.Add(
                                "@Birim",
                                SqlDbType.NVarChar, 20).Value =
                                g.Birim;

                            komut.Parameters.Add(
                                "@Aciklama",
                                SqlDbType.NVarChar, 500).Value =
                                string.IsNullOrWhiteSpace(
                                    g.Aciklama)
                                    ? DBNull.Value
                                    : g.Aciklama.Trim();

                            SqlOndalikEkle(komut, "@CapMm", g.Cap);
                            komut.Parameters.Add("@BasincSinifi", SqlDbType.NVarChar, 30).Value =
                                BosIseNull(g.Basinc);
                            SqlOndalikEkle(komut, "@UzunlukMetre", g.Uzunluk);
                            komut.Parameters.Add("@Renk", SqlDbType.NVarChar, 50).Value =
                                BosIseNull(g.Renk);
                            SqlOndalikEkle(komut, "@EtKalinligiMm", g.Kalinlik);
                            komut.Parameters.Add("@HammaddeTuru", SqlDbType.NVarChar, 100).Value =
                                BosIseNull(g.Hammadde);
                            SqlOndalikEkle(komut, "@AgirlikKg", g.Agirlik);

                            int sonuc;
                            int yeniStokId = 0;
                            if (g.Id.HasValue)
                                sonuc = komut.ExecuteNonQuery();
                            else
                            {
                                yeniStokId = Convert.ToInt32(komut.ExecuteScalar());
                                sonuc = 1;
                            }

                            if(sonuc==0)throw new InvalidOperationException("Stok kartı bulunamadı veya hareket geçmişi olan kartın birimi değiştirilemez.");
                            DinamikKaydet(baglanti,stokTx,g.Id??yeniStokId,g);
                            stokTx.Commit();
                        }
                    }}
}