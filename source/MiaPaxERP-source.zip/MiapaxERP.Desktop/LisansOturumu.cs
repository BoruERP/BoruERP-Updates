using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Text.Json;
using Microsoft.Data.SqlClient;
using Microsoft.Win32;
using MiapaxERP.Lisans.Core;

namespace MiapaxERP.Desktop;

public sealed record LisansOnbellek(string Anahtar,ImzaliLisans? Belge,DateTimeOffset SonGorulenUtc);
public static class LisansOturumu
{
    public const string VarsayilanSunucu="https://boruerp-lisans-yonetimi.ali-can-0001.chatgpt.site";
    public static string Sunucu=>PortalBaglantisi.LisansSunucusu;
#if CUSTOMER_BUILD
    public static bool Zorunlu=>true;
#else
    public static bool Zorunlu=>false;
#endif
    static readonly object sync=new();
    static readonly SemaphoreSlim yenile=new(1);
    static LisansOnbellek? cached;
    static DateTimeOffset saatCipasi=DateTimeOffset.UtcNow;
    static readonly System.Diagnostics.Stopwatch gecen=System.Diagnostics.Stopwatch.StartNew();
    static string file="",device="",database="";
    public static string SonMesaj {get;private set;}="Lisans etkinleştirilmedi.";
    public static string CihazKimligi=>device;
    public static string VeritabaniKimligi=>database;
    public static LisansIcerigi? Gecerli
    {
        get{lock(sync){try{if(cached?.Belge is null)return null;var now=DateTimeOffset.UtcNow;if(now<cached.SonGorulenUtc.AddMinutes(-5)||now<(saatCipasi+gecen.Elapsed).AddMinutes(-5))return null;return LisansKripto.Dogrula(cached.Belge,LisansAcikAnahtari.Pem,device,database,now);}catch{return null;}}}
    }
    public static string SektorKodu=>HttpsOturumu.Istemci?.Oturum?.Sektor??Gecerli?.Sector??"GENEL";
    public static bool ModulVar(string module)=>HttpsOturumu.Istemci?.Oturum is { } remote ? remote.Bitis>DateTimeOffset.UtcNow&&remote.Moduller.Contains(module) : !Zorunlu||Gecerli?.Modules.Contains(module)==true;
    public static void Gerekli(string module){if(!ModulVar(module))throw new UnauthorizedAccessException("Bu modül lisansınızda açık değil veya lisans doğrulaması gerekiyor: "+module);}
    public static void YetkiGerekli(string permission)
    {
        if(HttpsOturumu.Istemci?.Oturum is not null){var remoteModule=UrunKatalogu.YetkiModulu(permission);if(remoteModule is not null)Gerekli(remoteModule);return;}
        if(!Zorunlu)return;if(Gecerli is null)throw new UnauthorizedAccessException("Geçerli lisans doğrulaması gerekiyor.");
        var module=UrunKatalogu.YetkiModulu(permission);if(module is not null)Gerekli(module);
    }
    public static void Hazirla(string connection)
    {
        var b=new SqlConnectionStringBuilder(connection);
        string fingerprint=b.DataSource.Trim().ToUpperInvariant()+"|"+b.InitialCatalog.Trim().ToUpperInvariant();
        string machine=Convert.ToString(Registry.GetValue(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Cryptography","MachineGuid",null))??throw new InvalidOperationException("Cihaz kimliği okunamadı.");
        lock(sync)
        {
            device=LisansKripto.Ozet(machine);database=LisansKripto.Ozet(fingerprint);
            file=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"BoruERP","Lisans",database,"lisans-v2.dpapi");cached=null;saatCipasi=DateTimeOffset.UtcNow;gecen.Restart();
            if(File.Exists(file))try{cached=JsonSerializer.Deserialize<LisansOnbellek>(ProtectedData.Unprotect(File.ReadAllBytes(file),null,DataProtectionScope.CurrentUser),LisansKripto.Json);}catch{SonMesaj="Kayıtlı lisans açılamadı. Yeniden etkinleştirin.";}
        }
    }
    static void Kaydet()
    {
        if(cached is null||string.IsNullOrEmpty(file))return;
        Directory.CreateDirectory(Path.GetDirectoryName(file)!);
        var bytes=ProtectedData.Protect(JsonSerializer.SerializeToUtf8Bytes(cached,LisansKripto.Json),null,DataProtectionScope.CurrentUser);
        File.WriteAllBytes(file+".tmp",bytes);File.Move(file+".tmp",file,true);
    }
    public static void SaatIziniGuncelle()
    {
        lock(sync){if(cached is not null){var seen=saatCipasi+gecen.Elapsed;if(DateTimeOffset.UtcNow>seen)seen=DateTimeOffset.UtcNow;if(cached.SonGorulenUtc>seen)seen=cached.SonGorulenUtc;cached=cached with{SonGorulenUtc=seen};Kaydet();}}
    }
    public static async Task<bool> YenileAsync(string? newKey=null,CancellationToken cancellation=default)
    {
        await yenile.WaitAsync(cancellation);
        try
        {
            string key;lock(sync){
                // An expired or invalid offline receipt requires explicit re-entry,
                // even when the network is available again on this startup.
                if(string.IsNullOrWhiteSpace(newKey)&&Gecerli is null){
                    cached=new("",null,DateTimeOffset.UtcNow);Kaydet();
                    SonMesaj="Lisansı internet üzerinden etkinleştirmek için anahtarınızı yeniden girin. Çevrimdışı izin en fazla 7 gündür.";
                    return false;
                }
                key=newKey?.Trim()??cached?.Anahtar??"";
            }
            if(key.Length!=64){SonMesaj="Panelde oluşturulan 64 karakterlik lisans anahtarını girin.";return false;}
            using var http=new HttpClient(new HttpClientHandler{AllowAutoRedirect=false}){Timeout=TimeSpan.FromSeconds(20),MaxResponseContentBufferSize=64*1024};
            using var response=await http.PostAsJsonAsync(Sunucu+"/api/activate",new{licenseKey=key,deviceId=device,databaseId=database,deviceName=Environment.MachineName},cancellation);
            if(response.StatusCode is HttpStatusCode.Forbidden or HttpStatusCode.Unauthorized)
            {
                lock(sync){cached=new(key,null,DateTimeOffset.UtcNow);Kaydet();}
                SonMesaj="Lisans etkin değil, süresi dolmuş veya cihaz sınırı dolu. Lisans yöneticinizle görüşün.";return false;
            }
            response.EnsureSuccessStatusCode();
            var envelope=await response.Content.ReadFromJsonAsync<ImzaliLisans>(LisansKripto.Json,cancellation)??throw new InvalidDataException("Sunucu yanıtı boş.");
            var validated=LisansKripto.Dogrula(envelope,LisansAcikAnahtari.Pem,device,database,DateTimeOffset.UtcNow);
            lock(sync){cached=new(key,envelope,DateTimeOffset.UtcNow);Kaydet();}
            SonMesaj=$"{validated.Company} • {UrunKatalogu.SektorBul(validated.Sector).Ad} • Sonraki doğrulama: {validated.ValidUntil.ToLocalTime():g}";return true;
        }
        catch(Exception ex)when(ex is HttpRequestException or TaskCanceledException)
        {SonMesaj=Gecerli is null?"Lisans sunucusuna ulaşılamadı. İnternet bağlantısını kontrol edin.":"Sunucuya ulaşılamadı; mevcut imzalı izin süresi içinde çevrimdışı kullanım devam ediyor.";SaatIziniGuncelle();return Gecerli is not null;}
        catch(Exception ex)when(ex is CryptographicException or InvalidDataException or JsonException)
        {lock(sync){if(cached is not null){cached=cached with{Belge=null};Kaydet();}}SonMesaj="Lisans imzası veya içeriği doğrulanamadı. İşlem kapatıldı.";return false;}
        finally{yenile.Release();}
    }
}

