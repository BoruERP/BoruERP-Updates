using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
namespace MiapaxERP.Desktop;
public partial class MainWindow
{
    private readonly List<AsistanMesaji> asistanGecmisi=new();
    private readonly AsistanIstemcisi asistanIstemcisi=new();
    private CancellationTokenSource? asistanIptal;
    private int asistanOturum;
    private AsistanAyari asistanAyari=new();
    private AsistanDersi? asistanKonusu;
    private int asistanDersAdimi;
    private bool asistanBoyutBaglandi;
    private string AsistanAyarYolu => Path.Combine(GorunumDeposu.Klasor(baglantiAdresi,aktifKullanici?.KullaniciId??0),"asistan.json");
    private void AsistanHazirla() {
        if(!asistanBoyutBaglandi && AnaSayfaYardimKatmani.Parent is FrameworkElement area){
            asistanBoyutBaglandi=true;
            area.SizeChanged+=(_,_)=>{if(area.ActualHeight>0)AnaYardimPenceresi.Height=Math.Clamp(area.ActualHeight-90,280,520);};
        }
        AsistanDersSecimi.ItemsSource=AsistanBilgisi.Dersler;AsistanDersSecimi.DisplayMemberPath="Baslik";AsistanDersSecimi.SelectedIndex=0;
        asistanAyari=AsistanAyari.Oku(AsistanAyarYolu);AsistanAyarlariniGoster();
    }
    private void AsistanAyarlariniGoster() {
        AsistanBaglantiTuru.SelectedIndex=asistanAyari.Tur switch {"MiapaxERP sunucusu"=>1,"Ollama"=>2,_=>0};
        AsistanAdres.Text=asistanAyari.Adres;AsistanModel.Text=asistanAyari.Model;
        AsistanDurum.Text=asistanAyari.Tur=="Yerleşik rehber"?"Yerleşik rehber • Genel sohbet için sunucu bağla":"Bağlantı ayarlı • Henüz doğrulanmadı";
    }
    private void AsistanOturumTemizle() {
        asistanOturum++;asistanIptal?.Cancel();asistanIptal=null;yardimSoruIsleniyor=false;
        asistanGecmisi.Clear();asistanKonusu=null;asistanDersAdimi=0;
        YardimSoruMetni.Clear();YardimGonderButonu.IsEnabled=true;AsistanDurdur.IsEnabled=false;
        AsistanBaglantiPaneli.Visibility=Visibility.Collapsed;
    }
    private void AsistanYeniSohbet_Click(object sender,RoutedEventArgs e) {
        AsistanOturumTemizle();YardimRehberiniBitir(false);YardimMesajListesi.Children.Clear();YardimBaslat();AsistanAyarlariniGoster();
    }
    private void AsistanDurdur_Click(object sender,RoutedEventArgs e) => asistanIptal?.Cancel();
    private void AsistanBaglanti_Click(object sender,RoutedEventArgs e) {
        AsistanBaglantiPaneli.Visibility=AsistanBaglantiPaneli.Visibility==Visibility.Visible?Visibility.Collapsed:Visibility.Visible;
    }
    private AsistanAyari AsistanFormAyari() => new(){Tur=AsistanBaglantiTuru.SelectedIndex switch {1=>"MiapaxERP sunucusu",2=>"Ollama",_=>"Yerleşik rehber"},Adres=AsistanAdres.Text.Trim(),Model=AsistanModel.Text.Trim()};
    private void AsistanAyarKaydet_Click(object sender,RoutedEventArgs e) {
        try {
            var ayar=AsistanFormAyari();if(ayar.Tur!="Yerleşik rehber")AsistanIstemcisi.AdresiDogrula(ayar);
            ayar.Kaydet(AsistanAyarYolu);asistanAyari=ayar;AsistanOturumTemizle();YardimMesajListesi.Children.Clear();YardimBaslat();AsistanAyarlariniGoster();
            YardimMesajEkle(false,"Bağlantı tercihi kaydedildi. Yeni sohbet başlatıldı; önceki mesajlar yeni sunucuya gönderilmez.");
        } catch(Exception ex) when(ex is ArgumentException or IOException or UnauthorizedAccessException){AsistanAyarBilgi.Text="Kaydedilemedi: "+ex.Message;}
    }
    private async void AsistanBaglantiTest_Click(object sender,RoutedEventArgs e) {
        if(yardimSoruIsleniyor)return;
        var ayar=AsistanFormAyari();
        if(ayar.Tur=="Yerleşik rehber"){AsistanAyarBilgi.Text="Yerleşik rehber internet bağlantısı gerektirmez.";return;}
        try {AsistanIstemcisi.AdresiDogrula(ayar);}catch(ArgumentException ex){AsistanAyarBilgi.Text=ex.Message;return;}
        int oturum=asistanOturum;using var cts=new CancellationTokenSource(TimeSpan.FromSeconds(60));asistanIptal=cts;AsistanMesgul(true);AsistanAyarBilgi.Text="Bağlantı deneniyor…";
        try {var r=await asistanIstemcisi.SorAsync(ayar,"Kısa bir merhaba yanıtı ver.","Bağlantı testi",Array.Empty<AsistanMesaji>(),cts.Token);if(oturum==asistanOturum)AsistanAyarBilgi.Text=r.Metin!=null?"Bağlantı başarılı. Tercihini kaydetmeyi unutma.":r.Durum;}
        catch(OperationCanceledException){if(oturum==asistanOturum)AsistanAyarBilgi.Text="Bağlantı testi durduruldu veya zaman aşımına uğradı.";}
        finally {if(oturum==asistanOturum){asistanIptal=null;AsistanMesgul(false);}}
    }
    private void AsistanMesgul(bool busy) {yardimSoruIsleniyor=busy;YardimGonderButonu.IsEnabled=!busy;AsistanDurdur.IsEnabled=busy;}
    private string AsistanEkrani() => MuhasebeIcerik.Visibility==Visibility.Visible ? "Muhasebe / "+(muhasebePaneli?.AktifBolum??"") : SayfaBasligi.Text;
    private AsistanDersi? AsistanEkranDersi() {
        if(MuhasebeIcerik.Visibility==Visibility.Visible)return AsistanBilgisi.Dersler.FirstOrDefault(d=>d.Kod==muhasebePaneli?.RehberBolumu);
        return AsistanBilgisi.Bul(SayfaBasligi.Text);
    }
    private void AsistanEkraniAnlat_Click(object sender,RoutedEventArgs e) {
        if(yardimSoruIsleniyor)return;
        var d=AsistanEkranDersi()??AsistanBilgisi.Dersler[0];AsistanDersiSec(d);YardimMesajEkle(false,AsistanBilgisi.Anlat(d));
    }
    private void AsistanDersiSec(AsistanDersi d){asistanKonusu=d;asistanDersAdimi=0;AsistanDersSecimi.SelectedItem=d;}
    private void AsistanEgitim_Click(object sender,RoutedEventArgs e) {
        if(yardimSoruIsleniyor)return;
        if(AsistanDersSecimi.SelectedItem is not AsistanDersi d)return;AsistanDersiSec(d);AsistanAdimAnlat();
    }
    private void AsistanAdimAnlat() {
        if(asistanKonusu==null){YardimMesajEkle(false,"Üstteki listeden bir eğitim seçip Başlat'a basabilirsin.");return;}
        YardimMesajEkle(false,$"{asistanKonusu.Baslik} • Adım {asistanDersAdimi+1}/{asistanKonusu.Adimlar.Length}\n{asistanKonusu.Yol}\n\n{asistanKonusu.Adimlar[asistanDersAdimi]}\n\n"+(asistanDersAdimi==asistanKonusu.Adimlar.Length-1?"Eğitim tamamlandı. Kontrol: "+asistanKonusu.Kontrol:"Hazır olunca 'devam' yaz; 'örnek ver' veya 'geri' de diyebilirsin."));
    }
    private void AsistanEkrandaGoster_Click(object sender,RoutedEventArgs e) {
        if(yardimSoruIsleniyor)return;
        if(AsistanDersSecimi.SelectedItem is AsistanDersi d){AsistanDersiSec(d);YardimRehberBaslat(d.Kod);}
    }
    private async Task AsistanSorAsync(string soru) {
        string normal=AsistanBilgisi.Normalize(soru);
        if(normal is "devam" or "sonraki" or "geri"){
            if(yardimTurAdimlari.Count > 0){
                if(normal=="geri")YardimGeri_Click(this,new());
                else YardimIleri_Click(this,new());
                return;
            }
            if(asistanKonusu!=null)asistanDersAdimi=Math.Clamp(asistanDersAdimi+(normal=="geri"?-1:1),0,asistanKonusu.Adimlar.Length-1);
            AsistanAdimAnlat();return;
        }
        if(normal is "bu ekrani anlat" or "bu ekran" or "neredeyim"){AsistanEkraniAnlat_Click(this,new());return;}
        if(normal is "ornek" or "ornek ver" or "bir ornek ver"){
            YardimMesajEkle(false,asistanKonusu==null?"Hangi konu için örnek istersin? Üstteki eğitim listesinden seçebilirsin.":"Eğitim örneği: "+asistanKonusu.Ornek+"\n\n"+asistanKonusu.Kontrol);return;
        }
        if(normal is "anlamadim" or "tekrar anlat" or "daha detayli anlat" or "ozetle"){
            YardimMesajEkle(false,asistanKonusu==null?"Hangi konuda yardım istersin? Üstten bir eğitim seçebilirsin.":normal=="ozetle"?asistanKonusu.Baslik+"\n"+asistanKonusu.Yol+"\n"+asistanKonusu.Kontrol:AsistanBilgisi.Anlat(asistanKonusu));return;
        }
        var ders=AsistanBilgisi.Bul(soru);
        if(ders!=null && (normal.Contains("egit")||normal.Contains("ogret")||normal.Contains("adim adim"))){AsistanDersiSec(ders);AsistanAdimAnlat();return;}
        int oturum=asistanOturum;using var cts=new CancellationTokenSource(TimeSpan.FromSeconds(60));asistanIptal=cts;AsistanMesgul(true);
        AsistanDurum.Text=asistanAyari.Tur=="Yerleşik rehber"?"Yerleşik rehber":"Yanıt hazırlanıyor…";
        try {
            var result=await asistanIstemcisi.SorAsync(asistanAyari,soru,AsistanEkrani(),asistanGecmisi.Take(Math.Max(0,asistanGecmisi.Count-1)).ToArray(),cts.Token);
            if(oturum!=asistanOturum)return;
            AsistanDurum.Text=result.Durum;
            if(ders!=null)AsistanDersiSec(ders);
            string answer=result.Metin??(ders!=null?AsistanBilgisi.Anlat(ders):"Bu soruya yerleşik rehberle güvenilir bir yanıt veremiyorum. Genel konularda sohbet için Bağlantı bölümünden yapay zekâ sunucusunu bağlayabilirsin.\n\nProgram kullanımı için üstten eğitim seçebilir veya 'bu ekranı anlat' yazabilirsin. Bir sorun yaşıyorsan ekran adını ve hata mesajını paylaş.");
            YardimMesajEkle(false,answer);
        }catch(OperationCanceledException){if(oturum==asistanOturum){AsistanDurum.Text="İstek durduruldu veya zaman aşımına uğradı.";YardimMesajEkle(false,"Yanıt isteği durduruldu. Sorunu yeniden gönderebilirsin.");}}
        finally {if(oturum==asistanOturum){asistanIptal=null;AsistanMesgul(false);}}
    }
    private void AsistanGecmiseEkle(bool kullanici,string text) {
        asistanGecmisi.Add(new(kullanici?"user":"assistant",text));while(asistanGecmisi.Count>12)asistanGecmisi.RemoveAt(0);
        while(YardimMesajListesi.Children.Count>80)YardimMesajListesi.Children.RemoveAt(0);
    }
    private FrameworkElement? AsistanHedefBul(string name) => FindName(name) as FrameworkElement ?? muhasebePaneli?.RehberHedefi(name);
    private bool AsistanMuhasebeTuru(string tur) {
        string route=tur is "merkez" or "eski"?"gelir":tur;
        if(!MuhasebePaneli.Bolumler.Any(b=>b.Kod==route) && route!="ayar")return false;
        var d=AsistanBilgisi.Dersler.First(x=>x.Kod==tur);
        string[] targets=tur switch {
            "gelir"=>new[]{"Tur","Hesap","Aciklama","Odendi","GelirGiderSekmeleri"},
            "merkez"=>new[]{"Merkezler","MerkezKod","MerkezAd"},
            "eski"=>new[]{"Eskiler","EskiHesap","EskiMerkez"},
            "cari"=>new[]{"TxtCariKod","TxtCariUnvan","CmbCariHareketCari","GridCariler"},
            "kasa"=>new[]{"CmbFinHareketHesap","CmbFinHareketTur","TxtFinHareketTutar","GridFinHareketler"},
            "teklif"=>new[]{"TxtTeklifNo","CmbTeklifFiyatTipi","CmbTeklifUrun","TxtTeklifToplam"},
            "plan"=>new[]{"TxtPlanliBaslik","CmbPlanliCari","GridPlanliOdemeler"},
            "cek"=>new[]{"TxtEvrakNo","DpEvrakVade","GridEvraklar"},
            "belge"=>new[]{"TxtBelgeNo","TxtBelgeAraToplam","GridBelgeler"},
            "rapor"=>new[]{"CmbRaporTur","GridRapor","GridRapor"},
            _=>Enumerable.Repeat("MuhasebeIcerik",d.Adimlar.Length).ToArray()
        };
        for(int i=0;i<d.Adimlar.Length;i++)yardimTurAdimlari.Add(new("muhasebe:"+tur,targets[Math.Min(i,targets.Length-1)],$"{i+1}. {d.Baslik}",d.Adimlar[i]));return true;
    }
}
