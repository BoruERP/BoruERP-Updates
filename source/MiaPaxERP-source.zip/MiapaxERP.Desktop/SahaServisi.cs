using System.Data;
using System.IO;
using System.Text.Json;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

public sealed record SahaMusterisi(Guid Id,string IlId,string IlceId,string Koy,string Ad,string Telefon,decimal? Alan,string AlanBirimi,string Urunler,decimal? Debi,string DebiBirimi,decimal? Basinc,string Sulama,string SuKaynagi,string Aciklama);
public sealed partial class SahaServisi(string connection,int user,MobilKimlik? mobile=null)
{
 public static readonly JsonSerializerOptions Json=new(JsonSerializerDefaults.Web);
 readonly ErpModulServisi access=new(connection,user);
 bool Own => mobile?.Rol=="SAHA";
 void Yetki(SqlConnection c,SqlTransaction? tx,string permission){
  if(mobile is null){access.Yetki(c,tx,permission);return;}
  var fresh=MobilHesapServisi.Kontrol(c,tx,mobile.Ozet);
  if(fresh.Id!=mobile.Id||fresh.Kullanici!=user||fresh.Rol!=mobile.Rol)throw new UnauthorizedAccessException("Mobil yetkileri değişti; yeniden bağlanın.");
 }
 public void Kur(){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"SahaServisi.Kur","",new object?[]{});return;}
LisansOturumu.Gerekli("CRM");ModulKurulumu180.Hazirla(connection,user);using var c=access.Ac();using(var q=ErpModulServisi.Komut(c,null,"SELECT COUNT(*) FROM dbo.BERP_Sema WHERE Surum=210"))if(Convert.ToInt32(q.ExecuteScalar())==1)return;access.Yetki(c,null,"MODULES.INSTALL");using var cmd=ErpModulServisi.Komut(c,null,File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"Moduller210.sql")));cmd.ExecuteNonQuery();}
 public static void Dogrula(SahaMusterisi m){
  if(m.Id==Guid.Empty)throw new ArgumentException("Müşteri kimliği gerekli.");
  foreach(var (value,max) in new[]{(m.IlId,30),(m.IlceId,40),(m.Koy,160),(m.Ad,160),(m.Telefon,30)})if(string.IsNullOrWhiteSpace(value)||value.Length>max||value.Any(char.IsControl))throw new ArgumentException("Konum, müşteri adı ve cep telefonu gerekli; alan uzunluklarını kontrol edin.");
  if(m.Telefon.Count(char.IsDigit)<10||m.Telefon.Any(c=>!char.IsDigit(c)&&!"+ ()-".Contains(c)))throw new ArgumentException("Geçerli cep telefonu girin.");
  if(m.Alan is <=0 or >1000000000||m.Debi is <0 or >1000000000||m.Basinc is <0 or >1000)throw new ArgumentException("Alan pozitif, debi ve basınç negatif olmayan değerler olmalı. Bilinmiyorsa boş bırakın.");
  if(m.AlanBirimi is not("m²" or "dekar" or "hektar")||m.DebiBirimi is not("m³/saat" or "litre/saniye"))throw new ArgumentException("Ölçü birimini seçin.");
  foreach(var (value,max) in new[]{(m.Urunler,1000),(m.Sulama,100),(m.SuKaynagi,100),(m.Aciklama,4000)})if(value is null||value.Length>max)throw new ArgumentException("Açıklama alanı çok uzun.");
 }
 public object[] Liste(string il,string ilce,string koy){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<object[]>(connection,"SahaServisi.Liste","",new object?[]{il,ilce,koy});}
LisansOturumu.Gerekli("CRM");using var c=access.Ac();Yetki(c,null,"FIELD.VIEW");using var q=ErpModulServisi.Komut(c,null,"SELECT TOP(500) Id,Ad,Telefon,Surum FROM dbo.BERP210_SahaMusteri WHERE IlId=@i AND IlceId=@d AND Koy=@k AND (@own=0 OR Olusturan=@user) ORDER BY Ad,Id",("@i",il),("@d",ilce),("@k",koy),("@own",Own),("@user",user));using var r=q.ExecuteReader();var rows=new List<object>();while(r.Read())rows.Add(new{id=r.GetGuid(0),ad=r.GetString(1),telefon=r.GetString(2),version=Convert.ToBase64String((byte[])r[3])});return rows.ToArray();}
 public object Oku(Guid id){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<object>(connection,"SahaServisi.Oku","",new object?[]{id});}
LisansOturumu.Gerekli("CRM");using var c=access.Ac();Yetki(c,null,"FIELD.VIEW");SahaMusterisi data;string version;
  using(var q=ErpModulServisi.Komut(c,null,"SELECT Veri,Surum FROM dbo.BERP210_SahaMusteri WHERE Id=@id AND (@own=0 OR Olusturan=@user)",("@id",id),("@own",Own),("@user",user))){using var r=q.ExecuteReader();if(!r.Read())throw new ArgumentException("Müşteri bulunamadı.");data=JsonSerializer.Deserialize<SahaMusterisi>(r.GetString(0),Json)!;version=Convert.ToBase64String((byte[])r[1]);}
  using var cmd=ErpModulServisi.Komut(c,null,"SELECT TOP(100) Tarih,Sonuc,KullaniciId FROM dbo.BERP210_Gorusme WHERE MusteriId=@id ORDER BY Tarih DESC,KayitZamani DESC",("@id",id));using var rd=cmd.ExecuteReader();var visits=new List<object>();while(rd.Read())visits.Add(new{tarih=DateTime.SpecifyKind(rd.GetDateTime(0),DateTimeKind.Utc),sonuc=rd.GetString(1),kullanici=rd.GetInt32(2)});return new{data,version,visits};
 }
 public string Kaydet(SahaMusterisi m,string? version,Guid visitId,DateTimeOffset visitDate,string visit,Guid? operation=null){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<string>(connection,"SahaServisi.Kaydet","",new object?[]{m,version,visitId,visitDate,visit,operation});}

  LisansOturumu.Gerekli("CRM");Dogrula(m);if(visit is null||visit.Length>2000||(!string.IsNullOrWhiteSpace(visit)&&(visitId==Guid.Empty||visitDate>DateTimeOffset.UtcNow.AddMinutes(5))))throw new ArgumentException("Görüşme tarihi ve sonucu geçersiz.");
  using var c=access.Ac();using var tx=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,tx,"FIELD.EDIT");
  string? digest=null;
  if(mobile is not null){
   if(operation is null||operation==Guid.Empty)throw new ArgumentException("İşlem kimliği gerekli.");
   digest=MobilRaporSunucusu.Ozet(JsonSerializer.Serialize(new{m,version,visitId,visitDate,visit},Json));
   using var prior=ErpModulServisi.Komut(c,tx,"SELECT Ozet,Surum FROM dbo.BERP220_Islem WITH(UPDLOCK,HOLDLOCK) WHERE HesapId=@a AND Id=@id",("@a",mobile.Id),("@id",operation));
   using var rr=prior.ExecuteReader();if(rr.Read()){if(rr.GetString(0)!=digest)throw new InvalidOperationException("İşlem kimliği farklı kayıtla tekrar kullanılamaz.");string result=rr.GetString(1);rr.Close();tx.Commit();return result;}
  }
  string data=JsonSerializer.Serialize(m,Json);byte[]? v=string.IsNullOrEmpty(version)?null:Convert.FromBase64String(version);
  using var q=ErpModulServisi.Komut(c,tx,v is null?"INSERT dbo.BERP210_SahaMusteri(Id,IlId,IlceId,Koy,Ad,Telefon,Veri,Olusturan) VALUES(@id,@i,@d,@k,@a,@p,@data,@u)":"UPDATE dbo.BERP210_SahaMusteri SET IlId=@i,IlceId=@d,Koy=@k,Ad=@a,Telefon=@p,Veri=@data,Guncelleme=SYSUTCDATETIME() WHERE Id=@id AND Surum=@v AND (@own=0 OR Olusturan=@u)",("@id",m.Id),("@i",m.IlId),("@d",m.IlceId),("@k",m.Koy),("@a",m.Ad),("@p",m.Telefon),("@data",data),("@u",user),("@v",v),("@own",Own));if(q.ExecuteNonQuery()!=1)throw new InvalidOperationException("Müşteri başka kullanıcı tarafından değiştirildi. Yenileyin.");
  if(!string.IsNullOrWhiteSpace(visit)){using var add=ErpModulServisi.Komut(c,tx,"INSERT dbo.BERP210_Gorusme(Id,MusteriId,Tarih,Sonuc,KullaniciId) VALUES(@id,@m,@d,@s,@u)",("@id",visitId),("@m",m.Id),("@d",visitDate.UtcDateTime),("@s",visit.Trim()),("@u",user));add.ExecuteNonQuery();}
  using var read=ErpModulServisi.Komut(c,tx,"SELECT Surum FROM dbo.BERP210_SahaMusteri WHERE Id=@id",("@id",m.Id));string newVersion=Convert.ToBase64String((byte[])read.ExecuteScalar()!);
  if(mobile is not null){using var done=ErpModulServisi.Komut(c,tx,"INSERT dbo.BERP220_Islem(HesapId,Id,Ozet,Surum)VALUES(@a,@id,@h,@v)",("@a",mobile.Id),("@id",operation),("@h",digest),("@v",newVersion));done.ExecuteNonQuery();}
  tx.Commit();return newVersion;
 }
}
