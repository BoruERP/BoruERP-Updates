using System.Windows;
namespace MiapaxERP.Desktop;
public partial class TicariModullerPaneli
{
    private void GelirGiderAc_Click(object sender, RoutedEventArgs e) => BolumIstendi?.Invoke("gelir");
}
public partial class TicariIslemlerPaneli
{
    private void GelirGiderAc_Click(object sender, RoutedEventArgs e) => BolumIstendi?.Invoke("gelir");
}
public partial class TicariYeniIslemlerPenceresi
{
    private void GelirGiderAc_Click(object sender, RoutedEventArgs e)
    {
        if (Owner is MainWindow ana) { Close(); ana.MuhasebeBolumAc("gelir"); }
    }
}
