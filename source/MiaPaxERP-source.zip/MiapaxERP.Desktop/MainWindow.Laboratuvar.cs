using System.Windows;
namespace MiapaxERP.Desktop;
public partial class MainWindow
{
 void LaboratuvarAc_Click(object sender,RoutedEventArgs e)
 {
  if(aktifKullanici is null||DemoModu){MessageBox.Show("Laboratuvar için kendi SQL/ERP hesabınızla giriş yapın.");return;}
  try{LisansOturumu.Gerekli("LABORATUVAR");new Laboratuvar.LabPenceresi(baglantiAdresi,aktifKullanici.KullaniciId,gorunum.FirmaBasligi,gorunum.FirmaLogoGoster?gorunum.Logo:""){Owner=this}.ShowDialog();}catch(Exception ex){MessageBox.Show(ex.Message,"Laboratuvar ve Kalite");}
 }
}
