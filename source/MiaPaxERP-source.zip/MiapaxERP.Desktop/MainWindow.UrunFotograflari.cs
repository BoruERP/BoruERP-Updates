using System;
using System.Data;
using System.Windows;

namespace MiapaxERP.Desktop
{
    // Mevcut MainWindow.xaml.cs dosyasına dokunmadan yeni buton olayını ekler.
    public partial class MainWindow
    {
        private void UrunFotograflari_Click(object sender, RoutedEventArgs e)
        {
            if (!StokYetkisiGerekli("STOCK.VIEW")) return;
            if (DemoModu)
            {
                MessageBox.Show("Ürün fotoğrafları şu anda SQL Server modunda kullanılabilir.",
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (StokTablosu.SelectedItem is not DataRowView satir)
            {
                MessageBox.Show("Önce stok listesinden bir ürün seçin.",
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            try
            {
                int stokId = Convert.ToInt32(satir["Id"]);
                string stokAdi = Convert.ToString(satir["StokAdi"]) ?? "";
                new UrunGorselleriPenceresi(baglantiAdresi, stokId, stokAdi, aktifKullanici!.KullaniciId)
                {
                    Owner = this
                }.ShowDialog();
                StoklariListele();
                if(StokTablosu.ItemsSource is DataView view) StokTablosu.SelectedItem=view.Cast<DataRowView>().FirstOrDefault(r=>Convert.ToInt32(r["Id"])==stokId);
                if(CmbHareketStok.ItemsSource is DataView hareket) StokFotograflariniYukle(hareket.Table!,"Id");
                if(StokHareketGecmisiTablosu.ItemsSource is DataView gecmis) StokFotograflariniYukle(gecmis.Table!,"StokKartId");
                if(StokBakiyeRaporTablosu.ItemsSource is DataView bakiye) StokFotograflariniYukle(bakiye.Table!,"StokKartId");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ürün fotoğrafları açılamadı:\n\n" + ex.Message,
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}

