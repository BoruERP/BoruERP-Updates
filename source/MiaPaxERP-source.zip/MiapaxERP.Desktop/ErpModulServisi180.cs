using System.Data;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed partial class ErpModulServisi
{
    public static string IKBirim(string tur)=>tur switch{"Yıllık İzin" or "Ücretsiz İzin" or "Rapor"=>"Gün","Puantaj" or "Fazla Mesai"=>"Saat","Avans" or "Masraf"=>"TRY","Eğitim"=>"Saat","Sertifika" or "Zimmet" or "Performans" or "İşe Alım" or "İşten Ayrılış"=>"Adet",_=>throw new ArgumentException("İK işlem türü geçersiz.")};
    public static void IKDogrula(string tur,DateTime start,DateTime end,decimal amount)
    {
        string unit=IKBirim(tur);decimal days=(decimal)(end.Date-start.Date).TotalDays+1;
        if(days<=0||amount<=0||decimal.Round(amount,3)!=amount)throw new ArgumentException("İK işlemi için geçerli tarih aralığı ve pozitif miktar girin.");
        if(unit=="Gün"&&amount>days || unit=="Saat"&&amount>days*24 || unit=="Adet"&&amount!=decimal.Truncate(amount))throw new ArgumentException("Miktar seçili tarih aralığına veya birime uymuyor.");
    }
    static void IKPersonelDogrula(SqlConnection c,SqlTransaction tx,int person,DateTime start,DateTime end)
    {
        using var q=Komut(c,tx,"SELECT COUNT(*) FROM dbo.BERP_Personel WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND IseGiris<=@s AND (IstenCikis IS NULL OR IstenCikis>=@e)",("@id",person),("@s",start.Date),("@e",end.Date));
        if(Convert.ToInt32(q.ExecuteScalar())!=1)throw new ArgumentException("Personel bulunamadı veya tarihler çalışma dönemi dışında.");
    }
    public DataTable IKRapor(DateTime start,DateTime end)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"ErpModulServisi.IKRapor","",new object?[]{start,end});}

        if(end<start)throw new ArgumentException("Rapor tarihlerini kontrol edin.");using var c=Ac();Yetki(c,null,"HR.VIEW");
        using var q=Komut(c,null,"SELECT p.Sicil,p.AdSoyad,p.Departman,i.Tur,i.Durum,SUM(i.Miktar) Miktar,COUNT(*) Kayit FROM dbo.BERP_IKIslem i JOIN dbo.BERP_Personel p ON p.Id=i.PersonelId WHERE i.Baslangic>=@s AND i.Baslangic<=@e GROUP BY p.Sicil,p.AdSoyad,p.Departman,i.Tur,i.Durum ORDER BY p.AdSoyad,i.Tur",("@s",start.Date),("@e",end.Date));using var rd=q.ExecuteReader();var dt=new DataTable();dt.Load(rd);dt.Columns.Add("Birim");foreach(DataRow row in dt.Rows)row["Birim"]=IKBirim((string)row["Tur"]);return dt;
    }
    public void IzinOnayla(int id,byte[] version,string next)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"ErpModulServisi.IzinOnayla","",new object?[]{id,version,next});return;}

        if(next is not ("Onaylandı" or "Reddedildi"))throw new ArgumentException("Geçersiz onay işlemi.");
        using var c=Ac();using var tx=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,tx,"HR.APPROVE");
        int person;string tur;DateTime start,end;
        using(var q=Komut(c,tx,"SELECT PersonelId,Tur,Baslangic,Bitis FROM dbo.BERP_IKIslem WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Surum=@v AND Durum=N'Taslak'",("@id",id),("@v",version)))
        {using var rd=q.ExecuteReader();if(!rd.Read())throw new ArgumentException("Kayıt değişti veya onay beklemiyor.");person=rd.GetInt32(0);tur=rd.GetString(1);start=rd.GetDateTime(2);end=rd.GetDateTime(3);}
        if(next=="Onaylandı")
        {
            IKPersonelDogrula(c,tx,person,start,end);
            if(IKBirim(tur)=="Gün")
            {using var q=Komut(c,tx,"SELECT COUNT(*) FROM dbo.BERP_IKIslem WITH(UPDLOCK,HOLDLOCK) WHERE PersonelId=@p AND Id<>@id AND Durum=N'Onaylandı' AND Tur IN(N'Yıllık İzin',N'Ücretsiz İzin',N'Rapor') AND Baslangic<=@e AND Bitis>=@s",("@p",person),("@id",id),("@e",end),("@s",start));if(Convert.ToInt32(q.ExecuteScalar())>0)throw new ArgumentException("Bu tarihlerde onaylı izin/rapor var.");}
        }
        using(var q=Komut(c,tx,"UPDATE dbo.BERP_IKIslem SET Durum=@n,Onaylayan=@u WHERE Id=@id AND Surum=@v",("@n",next),("@u",user),("@id",id),("@v",version)))if(q.ExecuteNonQuery()!=1)throw new ArgumentException("Kayıt değişti.");
        Iz(c,tx,"İK",id,"Taslak → "+next);tx.Commit();
    }
}
