﻿USE [MiapaxERP];
GO
IF COL_LENGTH('dbo.FirmaBilgileri','KisaAd') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [KisaAd] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','FirmaTuru') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [FirmaTuru] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','MersisNo') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [MersisNo] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','TicaretSicilNo') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [TicaretSicilNo] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','TicaretSicilMudurlugu') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [TicaretSicilMudurlugu] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','NaceKodu') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [NaceKodu] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','KurulusTarihi') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [KurulusTarihi] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','Telefon2') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [Telefon2] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','Eposta') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [Eposta] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','WebSitesi') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [WebSitesi] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','KepAdresi') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [KepAdresi] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','Etebligat') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [Etebligat] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','Il') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [Il] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','Ilce') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [Ilce] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','PostaKodu') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [PostaKodu] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','Ulke') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [Ulke] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','YetkiliAdSoyad') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [YetkiliAdSoyad] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','YetkiliUnvan') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [YetkiliUnvan] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','YetkiliTelefon') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [YetkiliTelefon] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','Iban') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [Iban] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','BankaAdi') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [BankaAdi] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','SubeAdi') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [SubeAdi] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','HesapNo') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [HesapNo] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','OdaKayitNo') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [OdaKayitNo] NVARCHAR(500) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','FaaliyetKonusu') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [FaaliyetKonusu] NVARCHAR(1000) NULL;
IF COL_LENGTH('dbo.FirmaBilgileri','Aciklama') IS NULL ALTER TABLE dbo.FirmaBilgileri ADD [Aciklama] NVARCHAR(1000) NULL;
IF OBJECT_ID(N'dbo.FirmaBelgeleri',N'U') IS NULL
BEGIN
 CREATE TABLE dbo.FirmaBelgeleri (
 Id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
 BelgeTuru NVARCHAR(100) NOT NULL,
 DosyaAdi NVARCHAR(255) NOT NULL,
 PdfIcerik VARBINARY(MAX) NOT NULL,
 EklenmeTarihi DATETIME2 NOT NULL CONSTRAINT DF_FirmaBelgeleri_Eklenme DEFAULT SYSDATETIME(),
 EkleyenKullaniciId INT NULL
 );
END;
GO
