using System.Data;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed partial class IsletmeServisi
{
    internal static void FisDogrula(MuhasebeFisi g)
    {
        if(g.Anahtar==Guid.Empty||g.Tarih.Year<2000||g.Tarih.Year>2100)throw new ArgumentException("Fiş tarihi veya işlem kimliği geçersiz.");
        Text(g.Aciklama,1,400,"Açıklama");
        if(g.Kalemler is null||g.Kalemler.Length<2||g.Kalemler.Length>500)throw new ArgumentException("Fişte 2–500 kalem olmalı.");
        foreach(var k in g.Kalemler){Text(k.Hesap,1,30,"Hesap");Text(k.Aciklama,0,400,"Kalem açıklaması");Money(k.Borc);Money(k.Alacak);if((k.Borc>0)==(k.Alacak>0))throw new ArgumentException("Her kalemde yalnız borç veya alacak girin.");}
        if(g.Kalemler.Sum(k=>k.Borc)!=g.Kalemler.Sum(k=>k.Alacak))throw new ArgumentException("Borç ve alacak toplamları eşit olmalı.");
    }
    long Journal(SqlConnection c,SqlTransaction t,MuhasebeFisi g,string source,long? sourceId,long? reversed=null)
    {
        FisDogrula(g);
        using(var prior=Q(c,t,"SELECT Id FROM dbo.MPX310_Fis WITH(UPDLOCK,HOLDLOCK) WHERE Anahtar=@k",("@k",g.Anahtar)))
        {var old=prior.ExecuteScalar();if(old is not null)throw new InvalidOperationException("Bu fiş işlem kimliği daha önce kullanılmış. Listeyi yenileyin.");}
        using(var period=Q(c,t,"SELECT Kapali FROM dbo.MPX310_Donem WITH(UPDLOCK,HOLDLOCK) WHERE Yil=@y AND Ay=@m",("@y",g.Tarih.Year),("@m",g.Tarih.Month)))if(Convert.ToBoolean(period.ExecuteScalar()??false))throw new InvalidOperationException("Muhasebe dönemi kapalı.");
        foreach(var k in g.Kalemler)
        {
            using var account=Q(c,t,"SELECT COUNT(*) FROM dbo.MPX310_Hesap WITH(HOLDLOCK) WHERE Kod=@k AND Aktif=1",("@k",k.Hesap));if(Convert.ToInt32(account.ExecuteScalar())!=1)throw new ArgumentException("Aktif muhasebe hesabı bulunamadı: "+k.Hesap);
            if(k.Cari.HasValue){using var customer=Q(c,t,"SELECT COUNT(*) FROM dbo.CariKartlari WITH(HOLDLOCK) WHERE Id=@i AND Aktif=1",("@i",k.Cari));if(Convert.ToInt32(customer.ExecuteScalar())!=1)throw new ArgumentException("Aktif cari bulunamadı.");}
        }
        using(var seq=Q(c,t,"IF NOT EXISTS(SELECT 1 FROM dbo.MPX310_Sira WITH(UPDLOCK,HOLDLOCK) WHERE Yil=@y) INSERT dbo.MPX310_Sira VALUES(@y,0);UPDATE dbo.MPX310_Sira SET Son=Son+1 WHERE Yil=@y;",("@y",g.Tarih.Year)))seq.ExecuteNonQuery();
        long id;using(var insert=Q(c,t,"DECLARE @created TABLE(Id bigint);INSERT dbo.MPX310_Fis(Anahtar,Yil,Sira,Tarih,Kaynak,KaynakId,Aciklama,TersFisId,Kullanici) OUTPUT INSERTED.Id INTO @created SELECT @k,@y,Son,@d,@src,@sid,@a,@rev,@u FROM dbo.MPX310_Sira WHERE Yil=@y;SELECT Id FROM @created;",("@k",g.Anahtar),("@y",g.Tarih.Year),("@d",g.Tarih.Date),("@src",source),("@sid",sourceId),("@a",g.Aciklama),("@rev",reversed),("@u",user)))id=Convert.ToInt64(insert.ExecuteScalar());
        int n=0;foreach(var k in g.Kalemler){using var insert=Q(c,t,"INSERT dbo.MPX310_FisKalem(FisId,Sira,Hesap,Borc,Alacak,CariId,Aciklama) VALUES(@id,@n,@h,@b,@a,@c,@text)",("@id",id),("@n",++n),("@h",k.Hesap),("@b",k.Borc),("@a",k.Alacak),("@c",k.Cari),("@text",k.Aciklama));insert.ExecuteNonQuery();}
        using(var post=Q(c,t,"UPDATE dbo.MPX310_Fis SET Durum=N'Kesin' WHERE Id=@id AND (SELECT SUM(Borc-Alacak) FROM dbo.MPX310_FisKalem WHERE FisId=@id)=0",("@id",id)))if(post.ExecuteNonQuery()!=1)throw new InvalidOperationException("Fiş dengesi doğrulanamadı.");
        Event(c,t,null,"Muhasebe fişi",id+" · "+g.Aciklama);return id;
    }
    public long FisKaydet(MuhasebeFisi g){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"IsletmeServisi.FisKaydet","",new object?[]{g});}
FisDogrula(g);using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"ACCOUNTING.POST");long id=Journal(c,t,g,"Manuel",null);t.Commit();return id;}
    public long FisTersle(Guid key,long id,DateTime tarih,string gerekce)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"IsletmeServisi.FisTersle","",new object?[]{key,id,tarih,gerekce});}

        Text(gerekce,5,400,"Ters kayıt gerekçesi");using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"ACCOUNTING.POST");
        using(var q=Q(c,t,"SELECT COUNT(*) FROM dbo.MPX310_Fis WITH(UPDLOCK,HOLDLOCK) WHERE Id=@i AND Kaynak='Manuel' AND Durum=N'Kesin' AND TersFisId IS NULL AND NOT EXISTS(SELECT 1 FROM dbo.MPX310_Fis WHERE TersFisId=@i)",("@i",id)))if(Convert.ToInt32(q.ExecuteScalar())!=1)throw new InvalidOperationException("Yalnız terslenmemiş manuel kesin fiş terslenebilir. İşlem fişini kaynak belgeden iptal edin.");
        var rows=Table(Q(c,t,"SELECT * FROM dbo.MPX310_FisKalem WHERE FisId=@i ORDER BY Sira",("@i",id)));
        var lines=rows.AsEnumerable().Select(r=>new MuhasebeKalemi((string)r["Hesap"],(decimal)r["Alacak"],(decimal)r["Borc"],r.IsNull("CariId")?null:(int)r["CariId"],gerekce)).ToArray();
        long result=Journal(c,t,new(key,tarih,gerekce,lines),"Ters",id,id);t.Commit();return result;
    }
    public DataTable Mizan(DateTime ilk,DateTime son)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"IsletmeServisi.Mizan","",new object?[]{ilk,son});}

        if(son<ilk)throw new ArgumentException("Tarih aralığını kontrol edin.");using var c=access.Ac();Yetki(c,null,"ACCOUNTING.VIEW");
        return Table(Q(c,null,"SELECT h.Kod,h.Ad,COALESCE(SUM(k.Borc),0) Borc,COALESCE(SUM(k.Alacak),0) Alacak,COALESCE(SUM(k.Borc-k.Alacak),0) Bakiye FROM dbo.MPX310_Hesap h LEFT JOIN (SELECT k.* FROM dbo.MPX310_FisKalem k JOIN dbo.MPX310_Fis f ON f.Id=k.FisId WHERE f.Durum=N'Kesin' AND f.Tarih BETWEEN @a AND @b) k ON k.Hesap=h.Kod GROUP BY h.Kod,h.Ad ORDER BY h.Kod",("@a",ilk.Date),("@b",son.Date)));
    }
    public DataTable Yevmiye(DateTime ilk,DateTime son)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"IsletmeServisi.Yevmiye","",new object?[]{ilk,son});}

        if(son<ilk)throw new ArgumentException("Tarih aralığını kontrol edin.");using var c=access.Ac();Yetki(c,null,"ACCOUNTING.VIEW");return Table(Q(c,null,"SELECT f.Id,f.Yil,f.Sira YevmiyeNo,f.Tarih,f.Kaynak,f.KaynakId,f.Aciklama,k.Sira Kalem,k.Hesap,h.Ad,k.Borc,k.Alacak,k.CariId,f.TersFisId FROM dbo.MPX310_Fis f JOIN dbo.MPX310_FisKalem k ON k.FisId=f.Id JOIN dbo.MPX310_Hesap h ON h.Kod=k.Hesap WHERE f.Durum=N'Kesin' AND f.Tarih BETWEEN @a AND @b ORDER BY f.Yil,f.Sira,k.Sira",("@a",ilk.Date),("@b",son.Date)));
    }
    public void DonemDurumu(int yil,int ay,bool kapali,string gerekce)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"IsletmeServisi.DonemDurumu","",new object?[]{yil,ay,kapali,gerekce});return;}

        if(yil<2000||yil>2100||ay<1||ay>12)throw new ArgumentException("Dönem geçersiz.");Text(gerekce,5,400,"Dönem gerekçesi");using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"ACCOUNTING.CLOSE");
        using(var check=Q(c,t,"SELECT COUNT(*) FROM dbo.MPX310_Fis f WITH(UPDLOCK,HOLDLOCK) WHERE Yil=@y AND MONTH(Tarih)=@m AND (Durum<>N'Kesin' OR NOT EXISTS(SELECT 1 FROM dbo.MPX310_FisKalem WHERE FisId=f.Id) OR (SELECT SUM(Borc-Alacak) FROM dbo.MPX310_FisKalem WHERE FisId=f.Id)<>0)",("@y",yil),("@m",ay)))if(kapali&&Convert.ToInt32(check.ExecuteScalar())!=0)throw new InvalidOperationException("Dönemde taslak veya dengesiz fiş bulunuyor.");
        using(var q=Q(c,t,"IF NOT EXISTS(SELECT 1 FROM dbo.MPX310_Donem WITH(UPDLOCK,HOLDLOCK) WHERE Yil=@y AND Ay=@m) INSERT dbo.MPX310_Donem(Yil,Ay) VALUES(@y,@m);UPDATE dbo.MPX310_Donem SET Kapali=@s,Kapatan=@u,Kapanis=SYSDATETIMEOFFSET(),Gerekce=@a WHERE Yil=@y AND Ay=@m",("@y",yil),("@m",ay),("@s",kapali),("@u",user),("@a",gerekce)))q.ExecuteNonQuery();Event(c,t,null,kapali?"Dönem kapandı":"Dönem açıldı",$"{yil}/{ay}: {gerekce}");t.Commit();
    }
}

