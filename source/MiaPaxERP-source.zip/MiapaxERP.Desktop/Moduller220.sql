SET XACT_ABORT ON;
BEGIN TRANSACTION;
DECLARE @lock int;
EXEC @lock=sys.sp_getapplock @Resource=N'MiapaxERP.Moduller220',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=15000;
IF @lock<0 THROW 51000,N'Mobil kurulum kilidi alınamadı.',1;
IF OBJECT_ID(N'dbo.BERP220_Hesap',N'U') IS NULL
BEGIN
 CREATE TABLE dbo.BERP220_Hesap(Id uniqueidentifier PRIMARY KEY,KullaniciId int NOT NULL UNIQUE REFERENCES dbo.Kullanicilar(Id),Ad nvarchar(160) NOT NULL,Rol varchar(10) NOT NULL CHECK(Rol IN('SAHA','PATRON')),Aktif bit NOT NULL DEFAULT 1);
 CREATE TABLE dbo.BERP220_Esleme(Ozet char(64) PRIMARY KEY,HesapId uniqueidentifier NOT NULL REFERENCES dbo.BERP220_Hesap(Id),Bitis datetime2 NOT NULL);
 CREATE TABLE dbo.BERP220_Cihaz(Ozet char(64) PRIMARY KEY,HesapId uniqueidentifier NOT NULL REFERENCES dbo.BERP220_Hesap(Id),Ad nvarchar(100) NOT NULL,Olusturma datetime2 NOT NULL DEFAULT SYSUTCDATETIME(),SonGorulme datetime2 NOT NULL DEFAULT SYSUTCDATETIME(),Iptal bit NOT NULL DEFAULT 0);
 CREATE TABLE dbo.BERP220_Islem(HesapId uniqueidentifier NOT NULL,Id uniqueidentifier NOT NULL,Ozet char(64) NOT NULL,Surum varchar(20) NOT NULL,PRIMARY KEY(HesapId,Id));
END;
IF NOT EXISTS(SELECT 1 FROM dbo.BERP_Sema WHERE Surum=220)INSERT dbo.BERP_Sema(Surum)VALUES(220);
COMMIT;
