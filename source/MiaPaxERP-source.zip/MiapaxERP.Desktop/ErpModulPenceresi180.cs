using System.Data;
using System.Windows;
using System.Windows.Controls;
using ClosedXML.Excel;
namespace MiapaxERP.Desktop;
public sealed partial class ErpModulPenceresi
{
    void ListeAraclari(Panel tools)
    {
        var search=new TextBox{Width=180,ToolTip="Personel, departman, sicil veya kayıt ara",Margin=new Thickness(4)};tools.Children.Add(search);
        search.TextChanged+=(_,_)=>{if(grid.ItemsSource is DataView dv){string value=search.Text.Replace("'","''").Replace("[","[[]").Replace("%","[%]").Replace("*","[*]");dv.RowFilter=value.Length==0?"":string.Join(" OR ",dv.Table!.Columns.Cast<DataColumn>().Where(c=>c.DataType==typeof(string)).Select(c=>$"CONVERT([{c.ColumnName}], 'System.String') LIKE '%{value}%'"));}};
        B(tools,"Excel’e aktar",()=>{if(grid.ItemsSource is not DataView dv)throw new ArgumentException("Liste boş.");Excel(dv.ToTable(),"Kayıtlar");});
        if(type is "personel" or "ik")B(tools,"Dönem / Departman raporu",()=>{
            var win=new Window{Title="İnsan kaynakları dönem raporu",Width=1000,Height=700,Owner=this};var root=new DockPanel{Margin=new Thickness(16)};var bar=new WrapPanel();var start=new DatePicker{SelectedDate=new DateTime(DateTime.Today.Year,1,1)};var end=new DatePicker{SelectedDate=DateTime.Today};var rows=new DataGrid{IsReadOnly=true,AutoGenerateColumns=true,CanUserAddRows=false};bar.Children.Add(start);bar.Children.Add(end);
            B(bar,"Raporu getir",()=>rows.ItemsSource=db.IKRapor(start.SelectedDate??throw new ArgumentException("Başlangıç seçin."),end.SelectedDate??throw new ArgumentException("Bitiş seçin.")).DefaultView);
            B(bar,"Excel’e aktar",()=>{if(rows.ItemsSource is DataView dv)Excel(dv.ToTable(),"İK dönem özeti");});DockPanel.SetDock(bar,Dock.Top);root.Children.Add(bar);
            var info=new TextBlock{Text="Başlangıcı seçilen döneme düşen işlemler; personel, departman, tür ve onay durumuna göre özetlenir. Gün, saat, adet ve TRY ayrı gösterilir. Yasal izin hakkı veya bordro hesabı değildir.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(4,10,4,10)};DockPanel.SetDock(info,Dock.Top);root.Children.Add(info);root.Children.Add(rows);win.Content=root;win.ShowDialog();
        });
        Loaded+=(_,_)=>{if(type=="ik"&&fields["İşlem Türü"] is ComboBox combo){var label=new TextBlock{Margin=new Thickness(0,10,0,10),TextWrapping=TextWrapping.Wrap};form.Children.Add(label);void Unit()=>label.Text="Miktar birimi: "+ErpModulServisi.IKBirim((string)combo.SelectedItem)+". İzinlerde iş günü miktarını çalışma takviminize göre girin.";combo.SelectionChanged+=(_,_)=>Unit();Unit();}};
    }
    void Excel(DataTable data,string sheet)
    {
        foreach(string c in new[]{"Surum","Anahtar"})if(data.Columns.Contains(c))data.Columns.Remove(c);
        var dlg=new SaveFileDialog{Filter="Excel|*.xlsx",FileName=sheet+".xlsx"};if(dlg.ShowDialog(this)!=true)return;using var book=new XLWorkbook();book.Worksheets.Add(data,sheet);book.SaveAs(dlg.FileName);
    }
}
