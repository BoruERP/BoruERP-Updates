using System.IO;
namespace MiapaxERP.Desktop;
public static class ModulKurulumu180
{
    public static void Hazirla(string connection, int user)
    {
        var db=new ErpModulServisi(connection,user);using var c=db.Ac();
        using(var q=ErpModulServisi.Komut(c,null,"IF OBJECT_ID('dbo.BERP_Sema') IS NULL SELECT 0 ELSE SELECT COUNT(*) FROM dbo.BERP_Sema WHERE Surum=181"))
            if(Convert.ToInt32(q.ExecuteScalar())==1)return;
        db.Yetki(c,null,"MODULES.INSTALL");
        foreach(var file in new[]{"Moduller160.sql","Ticaret170.sql","Moduller180.sql","Moduller181.sql"})
        {using var q=ErpModulServisi.Komut(c,null,File.ReadAllText(Path.Combine(AppContext.BaseDirectory,file)));q.ExecuteNonQuery();}
    }
}
