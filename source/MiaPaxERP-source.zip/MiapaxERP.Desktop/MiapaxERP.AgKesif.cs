using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace MiapaxERP.Desktop
{
    /// <summary>
    /// LAN icinde yalnızca sunucu ADRESINI duyurur; lisans, SQL ve MiapaxERP sifrelerini paylasmaz.
    /// Kesif sonrasinda gercek SQL yetki ve veritabani kontrolu ZORUNLUDUR.
    /// Ana PC uzerinde MiapaxERP calisirken cevap verir (Windows servisi degildir).
    /// </summary>
    internal static class MiapaxERPAnaMakineDuyurusu
    {
        internal const int KesifPortu = 38765; // UDP, yalnizca yerel ag
        private const string IstekOnEk = "BORUERP-SUNUCU-BUL-v1|";
        private const string CevapOnEk = "BORUERP-SUNUCU-v1|";
        private static readonly object kilit = new object();
        private static CancellationTokenSource? iptal;
        private static UdpClient? dinleyici;

        private sealed class Duyuru
        {
            public string Nonce { get; set; } = "";
            public string Bilgisayar { get; set; } = "";
            public string SqlHedef { get; set; } = "";
            public string Veritabani { get; set; } = "";
        }

        public static void Baslat()
        {
            var ayarlar = MiapaxERPBaglantiAyarlari.Oku();
            if (ayarlar.Rol != "Ana") return;
            lock (kilit)
            {
                if (dinleyici != null) return;
                UdpClient soket;
                try
                {
                    soket = new UdpClient(new IPEndPoint(IPAddress.Any, KesifPortu));
                }
                catch (SocketException) { return; } // Port kullaniliyorsa uygulama calismaya devam eder.
                var cts = new CancellationTokenSource();
                dinleyici = soket;
                iptal = cts;
                _ = DinleAsync(soket, cts.Token);
            }
        }

        public static void Durdur()
        {
            lock (kilit)
            {
                iptal?.Cancel();
                dinleyici?.Dispose();
                dinleyici = null;
                iptal?.Dispose();
                iptal = null;
            }
        }

        private static async Task DinleAsync(UdpClient soket, CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                try
                {
                    var mesaj = await soket.ReceiveAsync(token);
                    // Buyuk paketler / beklenmeyen protokoller yok sayilir.
                    if (mesaj.Buffer.Length > 120 || mesaj.RemoteEndPoint.Address.AddressFamily != AddressFamily.InterNetwork)
                        continue;
                    string istek = Encoding.UTF8.GetString(mesaj.Buffer);
                    if (!istek.StartsWith(IstekOnEk, StringComparison.Ordinal)) continue;
                    string nonce = istek.Substring(IstekOnEk.Length);
                    if (nonce.Length != 32 || nonce.Any(c => !Uri.IsHexDigit(c))) continue;
                    var ayarlar = MiapaxERPBaglantiAyarlari.Oku();
                    if (ayarlar.Rol != "Ana") continue;
                    var veri = new Duyuru
                    {
                        Nonce = nonce,
                        Bilgisayar = Environment.MachineName,
                        SqlHedef = ayarlar.Sunucu,
                        Veritabani = ayarlar.Veritabani
                    };
                    byte[] cevap = Encoding.UTF8.GetBytes(CevapOnEk + JsonSerializer.Serialize(veri));
                    await soket.SendAsync(cevap, mesaj.RemoteEndPoint, token);
                }
                catch (OperationCanceledException) { break; }
                catch (ObjectDisposedException) { break; }
                catch (SocketException) { if (!token.IsCancellationRequested) await Task.Delay(250); }
                catch (Exception) { /* Kesif yuzunden ana ERP kapanmamali. */ }
            }
        }

        internal sealed class KesifAdayi
        {
            public string Bilgisayar { get; set; } = "";
            public string Sunucu { get; set; } = "";
            public string Veritabani { get; set; } = "";
        }

        private static string IpSqlHedefineCevir(IPAddress kaynakIp, string sunucuAyari)
        {
            string ip = kaynakIp.ToString();
            string hedef = sunucuAyari.Trim();
            // SQL instance/port adini korurken loopback veya yerel PC adini ag IP'sine cevirir.
            int virgul = hedef.IndexOf(',');
            int tersEgik = hedef.IndexOf('\\');
            int sinir = virgul >= 0 && tersEgik >= 0 ? Math.Min(virgul, tersEgik)
                : Math.Max(virgul, tersEgik);
            string ek = sinir >= 0 ? hedef.Substring(sinir) : "";
            return ip + ek;
        }

        private static IEnumerable<IPAddress> BroadcastAdresleri()
        {
            yield return IPAddress.Broadcast;
            foreach (var nic in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (nic.OperationalStatus != OperationalStatus.Up ||
                    nic.NetworkInterfaceType == NetworkInterfaceType.Loopback) continue;
                foreach (var ua in nic.GetIPProperties().UnicastAddresses)
                {
                    if (ua.Address.AddressFamily != AddressFamily.InterNetwork || ua.IPv4Mask == null) continue;
                    var ip = ua.Address.GetAddressBytes();
                    var mask = ua.IPv4Mask.GetAddressBytes();
                    var adr = new byte[4];
                    for (int i = 0; i < 4; i++) adr[i] = (byte)(ip[i] | ~mask[i]);
                    yield return new IPAddress(adr);
                }
            }
        }

        public static async Task<IReadOnlyList<KesifAdayi>> AnaBilgisayarlariBulAsync(CancellationToken token)
        {
            using var arama = CancellationTokenSource.CreateLinkedTokenSource(token);
            arama.CancelAfter(TimeSpan.FromSeconds(3));
            using var soket = new UdpClient(AddressFamily.InterNetwork) { EnableBroadcast = true };
            soket.Client.Bind(new IPEndPoint(IPAddress.Any, 0));
            string nonce = Guid.NewGuid().ToString("N");
            byte[] soru = Encoding.UTF8.GetBytes(IstekOnEk + nonce);
            foreach (IPAddress adres in BroadcastAdresleri().Distinct())
            {
                try { await soket.SendAsync(soru, new IPEndPoint(adres, KesifPortu), arama.Token); }
                catch (SocketException) { } // Bazi sanal/kapali adaptorlerde beklenen durum.
            }
            var adaylar = new Dictionary<string, KesifAdayi>(StringComparer.OrdinalIgnoreCase);
            while (!arama.IsCancellationRequested)
            {
                try
                {
                    UdpReceiveResult paket = await soket.ReceiveAsync(arama.Token);
                    if (paket.Buffer.Length > 1024 ||
                        paket.RemoteEndPoint.Address.AddressFamily != AddressFamily.InterNetwork) continue;
                    string cevap = Encoding.UTF8.GetString(paket.Buffer);
                    if (!cevap.StartsWith(CevapOnEk, StringComparison.Ordinal)) continue;
                    Duyuru? bilgi = JsonSerializer.Deserialize<Duyuru>(cevap.Substring(CevapOnEk.Length));
                    if (bilgi == null || bilgi.Nonce != nonce || string.IsNullOrWhiteSpace(bilgi.Veritabani)
                        || bilgi.Veritabani.Length > 128 || string.IsNullOrWhiteSpace(bilgi.SqlHedef)
                        || bilgi.SqlHedef.Length > 128) continue;
                    string adres = IpSqlHedefineCevir(paket.RemoteEndPoint.Address, bilgi.SqlHedef);
                    if (!adaylar.ContainsKey(adres))
                        adaylar.Add(adres, new KesifAdayi
                        {
                            Bilgisayar = bilgi.Bilgisayar,
                            Sunucu = adres,
                            Veritabani = bilgi.Veritabani
                        });
                }
                catch (OperationCanceledException) { break; }
                catch (SocketException) { break; }
                catch (JsonException) { } // Yabanci/bozuk LAN paketlerini yok say.
            }
            return adaylar.Values.ToArray();
        }

        public static async Task<(bool Basarili, string Hata)> SqlDogrulaAsync(KesifAdayi aday)
        {
            try
            {
                return await Task.Run(() =>
                {
                    var ayar = new MiapaxERPBaglantiAyarlari
                    {
                        Rol = "Yan", Sunucu = aday.Sunucu, Veritabani = aday.Veritabani
                    };
                    using var baglanti = new SqlConnection(ayar.BaglantiDizesi());
                    baglanti.Open();
                    using var komut = new SqlCommand(@"SELECT CASE WHEN DB_NAME() = @db
                        AND OBJECT_ID(N'dbo.StokKartlari',N'U') IS NOT NULL
                        AND OBJECT_ID(N'dbo.Kullanicilar',N'U') IS NOT NULL
                        THEN 1 ELSE 0 END", baglanti) { CommandTimeout = 3 };
                    komut.Parameters.Add("@db", System.Data.SqlDbType.NVarChar, 128).Value = aday.Veritabani;
                    return Convert.ToInt32(komut.ExecuteScalar()) == 1
                        ? (true, "")
                        : (false, "SQL acildi ancak beklenen MiapaxERP tablolari gorulmedi.");
                });
            }
            catch (SqlException ex) { return (false, ex.Message); }
            catch (InvalidOperationException ex) { return (false, ex.Message); }
            catch (ArgumentException ex) { return (false, ex.Message); }
        }
    }
}
