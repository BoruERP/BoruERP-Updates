using SqlConnection = MiapaxERP.Desktop.ErpSqlConnection;
using SqlCommand = MiapaxERP.Desktop.ErpSqlCommand;
using SqlTransaction = MiapaxERP.Desktop.ErpSqlTransaction;
using SqlDataReader = MiapaxERP.Desktop.ErpSqlReader;
using SqlDataAdapter = MiapaxERP.Desktop.ErpSqlDataAdapter;
using System;
using System.Data;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;

namespace MiapaxERP.Desktop
{
    public partial class StokTipiYonetimiPenceresi : Window
    {
        private readonly string _baglanti;
        private readonly int _kullaniciId;
        private sealed record Secim(int Id, string Ad);

        public StokTipiYonetimiPenceresi(string baglanti, int kullaniciId)
        {
            _baglanti = baglanti;
            _kullaniciId = kullaniciId;
            InitializeComponent();
            Loaded += (_, _) =>
            {
                try { TipleriYukle(); }
                catch (Exception ex) { MesajHata(ex); Close(); }
            };
        }

        private SqlConnection Baglan()
        {
            var con = new SqlConnection(_baglanti);
            con.Open();
            return con;
        }

        private static int SecilenId(ComboBox cmb) => (cmb.SelectedItem as Secim)?.Id ?? 0;

        private void YoneticiYetkisi(SqlConnection con)
        {
            using var cmd = new SqlCommand(@"
SELECT CASE WHEN EXISTS (
 SELECT 1 FROM dbo.Kullanicilar u
 JOIN dbo.KullaniciRolAtamalari ra ON ra.KullaniciId=u.Id
 JOIN dbo.KullaniciRolleri r ON r.Id=ra.RolId
 WHERE u.Id=@Kullanici AND u.Aktif=1 AND r.Aktif=1 AND r.RolAdi=N'Yönetici'
) AND EXISTS (
 SELECT 1 FROM dbo.vw_KullaniciEtkinYetkileri
 WHERE KullaniciId=@Kullanici AND YetkiKodu=N'STOCK.EDIT' AND Yetkili=1
) THEN 1 ELSE 0 END", con);
            cmd.Parameters.Add("@Kullanici", SqlDbType.Int).Value = _kullaniciId;
            if (Convert.ToInt32(cmd.ExecuteScalar()) != 1)
                throw new UnauthorizedAccessException("Stok tipi ve özellik tanımlamak için Yönetici rolü ve STOCK.EDIT yetkisi gerekli.");
        }

        private static void MesajHata(Exception ex) => MessageBox.Show(ex.Message,
            "MiapaxERP | Stok Tipi Yönetimi", MessageBoxButton.OK, MessageBoxImage.Warning);

        private void TipleriYukle(int tercihId = 0)
        {
            using var con = Baglan();
            YoneticiYetkisi(con);
            int eskiId = tercihId > 0 ? tercihId : SecilenId(CmbYonetimTipi);
            var items = new System.Collections.Generic.List<Secim>();
            using (var cmd = new SqlCommand("SELECT Id,Ad FROM dbo.StokTipleri WHERE Aktif=1 AND Ad NOT IN (N'Mamul', N'Yarı Mamul') ORDER BY Id", con))
            using (var rd = cmd.ExecuteReader())
                while (rd.Read()) items.Add(new Secim(rd.GetInt32(0), rd.GetString(1)));
            CmbYonetimTipi.ItemsSource = items;
            CmbYonetimTipi.DisplayMemberPath = "Ad";
            CmbYonetimTipi.SelectedValuePath = "Id";
            CmbYonetimTipi.SelectedItem = items.FirstOrDefault(t => t.Id == eskiId) ?? items.FirstOrDefault();
            KategorileriYukle();
        }

        private void KategorileriYukle()
        {
            int tipId = SecilenId(CmbYonetimTipi);
            var ana = new System.Collections.Generic.List<Secim> { new(0, "(Ana kategori oluştur)") };
            var ozellik = new System.Collections.Generic.List<Secim> { new(0, "(Stok tipinin tamamında)") };
            if (tipId > 0)
            {
                using var con = Baglan();
                using var cmd = new SqlCommand(@"SELECT Id, Ad, UstKategoriId
FROM dbo.StokKategorileri WHERE StokTipId=@Tip AND Aktif=1
ORDER BY CASE WHEN UstKategoriId IS NULL THEN 0 ELSE 1 END, Ad", con);
                cmd.Parameters.Add("@Tip", SqlDbType.Int).Value = tipId;
                using var rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    int id = rd.GetInt32(0);
                    string ad = rd.GetString(1);
                    bool altKategori = !rd.IsDBNull(2);
                    if (!altKategori) ana.Add(new Secim(id, ad));
                    ozellik.Add(new Secim(id, (altKategori ? "↳ " : "") + ad));
                }
            }
            CmbUstKategori.ItemsSource = ana;
            CmbUstKategori.DisplayMemberPath = "Ad";
            CmbUstKategori.SelectedIndex = 0;
            CmbOzellikKategori.ItemsSource = ozellik;
            CmbOzellikKategori.DisplayMemberPath = "Ad";
            CmbOzellikKategori.SelectedIndex = 0;
        }

        private void TipSecimiDegisti(object sender, SelectionChangedEventArgs e)
        {
            if (!IsLoaded) return;
            try { KategorileriYukle(); }
            catch (Exception ex) { MesajHata(ex); }
        }

        private void TipEkle_Click(object sender, RoutedEventArgs e)
        {
            string ad = TxtYeniTip.Text.Trim();
            if (ad.Length == 0 || ad.Length > 30) { MessageBox.Show("Stok tipi adı 1-30 karakter olmalı."); return; }
            if (string.Equals(ad, "Mamul", StringComparison.CurrentCultureIgnoreCase) ||
                string.Equals(ad, "Yarı Mamul", StringComparison.CurrentCultureIgnoreCase))
            {
                MessageBox.Show("Mamul ve Yarı Mamul stok tipleri yeni kayıtlar için kullanımdan kaldırıldı.");
                return;
            }
            try
            {
int id;
if(HttpsOturumu.Uzak(_baglanti)){id=new YardimciEkranServisi(_baglanti,_kullaniciId).TipEkle(ad);}
else{                using var con = Baglan();
                YoneticiYetkisi(con);
                using var cmd = new SqlCommand(@"
IF EXISTS (SELECT 1 FROM dbo.StokTipleri WHERE Ad=@Ad)
 THROW 51031, N'Bu stok tipi zaten tanımlı.', 1;
INSERT dbo.StokTipleri(Ad,Aktif) OUTPUT INSERTED.Id VALUES(@Ad,1);", con);
                cmd.Parameters.Add("@Ad", SqlDbType.NVarChar, 30).Value = ad;
                id = Convert.ToInt32(cmd.ExecuteScalar());
}
                TipleriYukle(id);
                TxtYeniTip.Clear();
                TxtBilgi.Text = "Yeni stok tipi eklendi: " + ad;
            }
            catch (Exception ex) { MesajHata(ex); }
        }

        private void KategoriEkle_Click(object sender, RoutedEventArgs e)
        {
            string ad = TxtYeniKategori.Text.Trim();
            int tipId = SecilenId(CmbYonetimTipi);
            int ustId = SecilenId(CmbUstKategori);
            if (tipId == 0 || ad.Length == 0 || ad.Length > 80)
            { MessageBox.Show("Stok tipi ve geçerli kategori adı seçin."); return; }
            try
            {
if(HttpsOturumu.Uzak(_baglanti)){new YardimciEkranServisi(_baglanti,_kullaniciId).KategoriEkle(tipId,ustId>0?ustId:null,ad,ChkBoruOzelligi.IsChecked==true);}
else{                using var con = Baglan();
                YoneticiYetkisi(con);
                using var cmd = new SqlCommand(@"
IF @UstId IS NOT NULL AND NOT EXISTS (
 SELECT 1 FROM dbo.StokKategorileri WHERE Id=@UstId AND StokTipId=@TipId
 AND UstKategoriId IS NULL AND Aktif=1)
 THROW 51032, N'Üst kategori geçersiz.', 1;
IF EXISTS (SELECT 1 FROM dbo.StokKategorileri
 WHERE StokTipId=@TipId AND Ad=@Ad
 AND ((@UstId IS NULL AND UstKategoriId IS NULL) OR UstKategoriId=@UstId))
 THROW 51033, N'Bu kategori adı bu seviyede zaten tanımlı.', 1;
INSERT dbo.StokKategorileri(StokTipId,UstKategoriId,Ad,BoruOzellikleri,Aktif)
 VALUES (@TipId,@UstId,@Ad,@Boru,1);", con);
                cmd.Parameters.Add("@TipId", SqlDbType.Int).Value = tipId;
                cmd.Parameters.Add("@UstId", SqlDbType.Int).Value = ustId > 0 ? (object)ustId : DBNull.Value;
                cmd.Parameters.Add("@Ad", SqlDbType.NVarChar, 80).Value = ad;
                cmd.Parameters.Add("@Boru", SqlDbType.Bit).Value = ChkBoruOzelligi.IsChecked == true;
                cmd.ExecuteNonQuery();
}
                KategorileriYukle();
                TxtYeniKategori.Clear();
                TxtBilgi.Text = "Kategori eklendi: " + ad;
            }
            catch (Exception ex) { MesajHata(ex); }
        }

        private void AlanTuruDegisti(object sender, SelectionChangedEventArgs e)
        {
            if (PanelSecenekler == null) return;
            PanelSecenekler.Visibility = (CmbAlanTuru.SelectedItem as ComboBoxItem)?.Content?.ToString() == "Seçim"
                ? Visibility.Visible : Visibility.Collapsed;
        }

        private void OzellikEkle_Click(object sender, RoutedEventArgs e)
        {
            int tipId = SecilenId(CmbYonetimTipi);
            int kategoriId = SecilenId(CmbOzellikKategori);
            string ad = TxtAlanAdi.Text.Trim();
            string tur = (CmbAlanTuru.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Metin";
            string secenekler = TxtAlanSecenekleri.Text.Trim();
            if (tipId == 0 || ad.Length == 0 || ad.Length > 100)
            { MessageBox.Show("Stok tipi ve alan adı seçin."); return; }
            if (!new[] { "Metin", "Sayı", "Tarih", "Seçim" }.Contains(tur))
            { MessageBox.Show("Alan türü geçersiz."); return; }
            if (tur == "Seçim" && (secenekler.Length == 0 || secenekler.Split('|', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).Length < 2))
            { MessageBox.Show("Seçim türünde en az iki seçenek girin. Örn. Kırmızı|Mavi"); return; }
            try
            {
if(HttpsOturumu.Uzak(_baglanti)){new YardimciEkranServisi(_baglanti,_kullaniciId).OzellikEkle(tipId,kategoriId>0?kategoriId:null,ad,tur,secenekler,ChkZorunluAlan.IsChecked==true);}
else{                using var con = Baglan();
                YoneticiYetkisi(con);
                using var cmd = new SqlCommand(@"
IF @Kategori IS NOT NULL AND NOT EXISTS (
 SELECT 1 FROM dbo.StokKategorileri
 WHERE Id=@Kategori AND StokTipId=@Tip AND Aktif=1)
 THROW 51034, N'Alan için seçilen kategori geçersiz.', 1;
IF EXISTS (SELECT 1 FROM dbo.StokOzellikTanimlari
 WHERE StokTipId=@Tip AND AlanAdi=@Ad
 AND ((@Kategori IS NULL AND KategoriId IS NULL) OR KategoriId=@Kategori))
 THROW 51035, N'Bu özellik alanı zaten tanımlanmış.', 1;
INSERT dbo.StokOzellikTanimlari(StokTipId,KategoriId,AlanAdi,AlanTuru,Secenekler,Zorunlu,Aktif)
 VALUES (@Tip,@Kategori,@Ad,@Tur,@Secenekler,@Zorunlu,1);", con);
                cmd.Parameters.Add("@Tip", SqlDbType.Int).Value = tipId;
                cmd.Parameters.Add("@Kategori", SqlDbType.Int).Value = kategoriId > 0 ? (object)kategoriId : DBNull.Value;
                cmd.Parameters.Add("@Ad", SqlDbType.NVarChar, 100).Value = ad;
                cmd.Parameters.Add("@Tur", SqlDbType.NVarChar, 10).Value = tur;
                cmd.Parameters.Add("@Secenekler", SqlDbType.NVarChar, 500).Value = tur == "Seçim" ? (object)secenekler : DBNull.Value;
                cmd.Parameters.Add("@Zorunlu", SqlDbType.Bit).Value = ChkZorunluAlan.IsChecked == true;
                cmd.ExecuteNonQuery();
}
                TxtAlanAdi.Clear();
                TxtAlanSecenekleri.Clear();
                TxtBilgi.Text = "Özellik alanı eklendi: " + ad + ". Stok kartını açtığınızda görünecek.";
            }
            catch (Exception ex) { MesajHata(ex); }
        }

        private void Kapat_Click(object sender, RoutedEventArgs e) => Close();
    }
}
