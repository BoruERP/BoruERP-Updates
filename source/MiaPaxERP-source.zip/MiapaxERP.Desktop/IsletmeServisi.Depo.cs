using System.Data;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed partial class IsletmeServisi
{
    internal void StokPartile(SqlConnection c,SqlTransaction t,int stock,decimal qty,string direction,decimal? cost,string note)
    {
        if(direction=="C"){Issue(c,t,stock,qty,null,null,"STOK",0,note,false);return;}
        long lot;using(var insert=Q(c,t,"INSERT dbo.MPX310_Lot(StokId,Kod,Kaynak,BirimMaliyet) OUTPUT INSERTED.Id VALUES(@s,@p,'StokGiris',@m)",("@s",stock),("@p","GIRIS-"+Guid.NewGuid().ToString("N")),("@m",cost)))lot=Convert.ToInt64(insert.ExecuteScalar());int shelf;using(var q=Q(c,t,"SELECT r.Id FROM dbo.MPX310_Raf r JOIN dbo.MPX310_Depo d ON d.Id=r.DepoId WHERE d.Kod=N'MERKEZ' AND r.Kod=N'GENEL' AND r.Aktif=1 AND d.Aktif=1"))shelf=Convert.ToInt32(q.ExecuteScalar());LocationChange(c,t,lot,shelf,qty,"Stok girişi","STOK",null,note);
    }
    decimal Available(SqlConnection c,SqlTransaction t,long lot,int shelf)
    {
        using var q=Q(c,t,"SELECT b.Miktar-COALESCE((SELECT SUM(r.Miktar) FROM dbo.MPX310_Rezervasyon r WITH(UPDLOCK,HOLDLOCK) WHERE r.LotId=b.LotId AND r.RafId=b.RafId AND r.Durum=N'Bekliyor'),0) FROM dbo.MPX310_LotBakiye b WITH(UPDLOCK,HOLDLOCK) JOIN dbo.MPX310_Lot l WITH(UPDLOCK,HOLDLOCK) ON l.Id=b.LotId WHERE b.LotId=@l AND b.RafId=@r AND l.Kalite=N'Serbest'",("@l",lot),("@r",shelf));var v=q.ExecuteScalar();return v is null or DBNull?0:Convert.ToDecimal(v);
    }
    void LocationChange(SqlConnection c,SqlTransaction t,long lot,int shelf,decimal delta,string kind,string source,long? sourceId,string note)
    {
        if(note.Length>400)note=note[..400];
        using(var active=Q(c,t,"SELECT COUNT(*) FROM dbo.MPX310_Raf r WITH(HOLDLOCK) JOIN dbo.MPX310_Depo d ON d.Id=r.DepoId WHERE r.Id=@r AND r.Aktif=1 AND d.Aktif=1",("@r",shelf)))if(Convert.ToInt32(active.ExecuteScalar())!=1)throw new ArgumentException("Aktif depo ve raf seçin.");
        using(var q=Q(c,t,"IF NOT EXISTS(SELECT 1 FROM dbo.MPX310_LotBakiye WITH(UPDLOCK,HOLDLOCK) WHERE LotId=@l AND RafId=@r) INSERT dbo.MPX310_LotBakiye(LotId,RafId,Miktar) VALUES(@l,@r,0);UPDATE dbo.MPX310_LotBakiye SET Miktar=Miktar+@d WHERE LotId=@l AND RafId=@r AND Miktar+@d>=0;IF @@ROWCOUNT<>1 THROW 51310,N'Parti raf bakiyesi yetersiz.',1;INSERT dbo.MPX310_LotHareket(LotId,RafId,Miktar,Tur,Kaynak,KaynakId,Aciklama,Kullanici) VALUES(@l,@r,@d,@t,@src,@id,@a,@u)",("@l",lot),("@r",shelf),("@d",delta),("@t",kind),("@src",source),("@id",sourceId),("@a",note),("@u",user)))q.ExecuteNonQuery();
    }
    void AggregateChange(SqlConnection c,SqlTransaction t,int stock,decimal delta,string kind,string note)
    {
        string unit;using(var q=Q(c,t,"SELECT Birim FROM dbo.StokKartlari WITH(UPDLOCK,HOLDLOCK) WHERE Id=@s AND Aktif=1",("@s",stock)))unit=Convert.ToString(q.ExecuteScalar())??"";if(unit.Length==0)throw new ArgumentException("Aktif stok bulunamadı.");
        using var cmd=Q(c,t,"IF NOT EXISTS(SELECT 1 FROM dbo.StokBakiyeleri WITH(UPDLOCK,HOLDLOCK) WHERE StokKartId=@s) INSERT dbo.StokBakiyeleri(StokKartId,Birim,Miktar) VALUES(@s,@b,0);UPDATE dbo.StokBakiyeleri SET Miktar=Miktar+@d WHERE StokKartId=@s AND Birim=@b AND Miktar+@d>=0;IF @@ROWCOUNT<>1 THROW 51310,N'Ana stok bakiyesi yetersiz veya birim uyuşmuyor.',1;INSERT dbo.StokHareketleri(StokKartId,HareketTipi,Yon,Miktar,Birim,Aciklama) VALUES(@s,@t,@y,ABS(@d),@b,@a)",("@s",stock),("@b",unit),("@d",delta),("@t",kind),("@y",delta>0?"G":"C"),("@a",note));cmd.ExecuteNonQuery();
    }
    List<LotTuketimi> Issue(SqlConnection c,SqlTransaction t,int stock,decimal qty,long? lot,int? shelf,string source,long id,string note,bool aggregate=true)
    {
        Quantity(qty);var candidates=Table(Q(c,t,"SELECT b.LotId,b.RafId,l.BirimMaliyet FROM dbo.MPX310_LotBakiye b WITH(UPDLOCK,HOLDLOCK) JOIN dbo.MPX310_Lot l WITH(UPDLOCK,HOLDLOCK) ON l.Id=b.LotId JOIN dbo.MPX310_Raf r ON r.Id=b.RafId JOIN dbo.MPX310_Depo d ON d.Id=r.DepoId WHERE l.StokId=@s AND l.Kalite=N'Serbest' AND r.Aktif=1 AND d.Aktif=1 AND b.Miktar>0 AND (@l IS NULL OR l.Id=@l) AND (@r IS NULL OR b.RafId=@r) ORDER BY l.Olusturma,l.Id,b.RafId",("@s",stock),("@l",lot),("@r",shelf)));
        var result=new List<LotTuketimi>();decimal left=qty;foreach(DataRow r in candidates.Rows){long l=(long)r["LotId"];int raf=(int)r["RafId"];decimal take=Math.Min(left,Available(c,t,l,raf));if(take<=0)continue;LocationChange(c,t,l,raf,-take,"Çıkış",source,id,note);result.Add(new(l,raf,take,r.IsNull("BirimMaliyet")?null:(decimal)r["BirimMaliyet"]));left-=take;if(left==0)break;}
        if(left!=0)throw new InvalidOperationException("Serbest, rezerve edilmemiş parti miktarı yetersiz. Eski stoklar için kontrollü parti devri yapın.");if(aggregate)AggregateChange(c,t,stock,-qty,source,note);return result;
    }
    public DataTable DepoBakiyeleri()
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"IsletmeServisi.DepoBakiyeleri","",new object?[]{});}

        using var c=access.Ac();Yetki(c,null,"WAREHOUSE.VIEW");return Table(Q(c,null,"SELECT l.Id LotId,l.Kod Parti,s.Id StokId,s.StokKodu,s.StokAdi,s.Birim,d.Ad Depo,r.Id RafId,r.Kod Raf,l.Kalite,b.Miktar,COALESCE(x.Miktar,0) Rezerve,b.Miktar-COALESCE(x.Miktar,0) Kullanilabilir,l.BirimMaliyet,b.Surum FROM dbo.MPX310_LotBakiye b JOIN dbo.MPX310_Lot l ON l.Id=b.LotId JOIN dbo.StokKartlari s ON s.Id=l.StokId JOIN dbo.MPX310_Raf r ON r.Id=b.RafId JOIN dbo.MPX310_Depo d ON d.Id=r.DepoId OUTER APPLY(SELECT SUM(Miktar) Miktar FROM dbo.MPX310_Rezervasyon WHERE LotId=b.LotId AND RafId=b.RafId AND Durum=N'Bekliyor') x ORDER BY s.StokAdi,l.Id,r.Id"));
    }
    public void DepoKaydet(DepoGirdisi g)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"IsletmeServisi.DepoKaydet","",new object?[]{g});return;}

        Text(g.Kod,1,30,"Depo kodu");Text(g.Ad,1,120,"Depo adı");Text(g.RafKodu,1,40,"Raf kodu");Text(g.RafAdi,1,120,"Raf adı");using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"WAREHOUSE.CONFIG");
        using var q=Q(c,t,"IF NOT EXISTS(SELECT 1 FROM dbo.MPX310_Depo WITH(UPDLOCK,HOLDLOCK) WHERE Kod=@k) INSERT dbo.MPX310_Depo(Kod,Ad) VALUES(@k,@a);DECLARE @d int=(SELECT Id FROM dbo.MPX310_Depo WHERE Kod=@k);IF EXISTS(SELECT 1 FROM dbo.MPX310_Raf WITH(UPDLOCK,HOLDLOCK) WHERE DepoId=@d AND Kod=@r) THROW 51310,N'Raf zaten tanımlı.',1;INSERT dbo.MPX310_Raf(DepoId,Kod,Ad) VALUES(@d,@r,@ra)",("@k",g.Kod),("@a",g.Ad),("@r",g.RafKodu),("@ra",g.RafAdi));q.ExecuteNonQuery();Event(c,t,null,"Depo / raf",g.Kod+" / "+g.RafKodu);t.Commit();
    }
    public long PartiDevret(Guid key,int stok,int raf,string parti,decimal miktar,decimal? maliyet,string gerekce)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"IsletmeServisi.PartiDevret","",new object?[]{key,stok,raf,parti,miktar,maliyet,gerekce});}

        Quantity(miktar);Text(parti,1,80,"Parti");Text(gerekce,5,400,"Devir gerekçesi");if(maliyet<0)throw new ArgumentException("Maliyet negatif olamaz.");using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"WAREHOUSE.CONFIG");
        using(var prior=Q(c,t,"SELECT Id FROM dbo.MPX310_Kayit WITH(UPDLOCK,HOLDLOCK) WHERE Anahtar=@k",("@k",key)))if(prior.ExecuteScalar() is not null)throw new InvalidOperationException("Devir işlemi daha önce kaydedildi.");
        using(var balance=Q(c,t,"SELECT COALESCE((SELECT SUM(Miktar) FROM dbo.StokBakiyeleri WITH(UPDLOCK,HOLDLOCK) WHERE StokKartId=@s),0)-COALESCE((SELECT SUM(b.Miktar) FROM dbo.MPX310_LotBakiye b WITH(UPDLOCK,HOLDLOCK) JOIN dbo.MPX310_Lot l ON l.Id=b.LotId WHERE l.StokId=@s),0)",("@s",stok)))if(Convert.ToDecimal(balance.ExecuteScalar())<miktar)throw new InvalidOperationException("Devredilecek miktar, partiye ayrılmamış ana stok miktarını aşıyor.");
        long record=Create(c,t,"PartiDevir",key,new{stok,raf,parti,miktar,maliyet,gerekce},"Tamamlandı");long lot;using(var insert=Q(c,t,"INSERT dbo.MPX310_Lot(StokId,Kod,Kaynak,KaynakId,BirimMaliyet) OUTPUT INSERTED.Id VALUES(@s,@p,'Devir',@id,@m)",("@s",stok),("@p",parti),("@id",record),("@m",maliyet)))lot=Convert.ToInt64(insert.ExecuteScalar());LocationChange(c,t,lot,raf,miktar,"Devir","PartiDevir",record,"Geçmiş kaynak bilinmiyor: "+gerekce);t.Commit();return lot;
    }
    public void Transfer(TransferGirdisi g)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"IsletmeServisi.Transfer","",new object?[]{g});return;}

        Quantity(g.Miktar);Text(g.Aciklama,1,400,"Açıklama");if(g.KaynakRaf==g.HedefRaf)throw new ArgumentException("Kaynak ve hedef raf farklı olmalı.");using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"WAREHOUSE.TRANSFER");
        using(var prior=Q(c,t,"SELECT Id FROM dbo.MPX310_Kayit WITH(UPDLOCK,HOLDLOCK) WHERE Anahtar=@k",("@k",g.Anahtar)))if(prior.ExecuteScalar() is not null)throw new InvalidOperationException("Transfer zaten kaydedildi.");
        if(Available(c,t,g.Lot,g.KaynakRaf)<g.Miktar)throw new InvalidOperationException("Kullanılabilir miktar yetersiz.");long id=Create(c,t,"Transfer",g.Anahtar,g,"Tamamlandı");LocationChange(c,t,g.Lot,g.KaynakRaf,-g.Miktar,"Transfer çıkış","Transfer",id,g.Aciklama);LocationChange(c,t,g.Lot,g.HedefRaf,g.Miktar,"Transfer giriş","Transfer",id,g.Aciklama);t.Commit();
    }
    public long Rezerve(RezervasyonGirdisi g)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"IsletmeServisi.Rezerve","",new object?[]{g});}

        Quantity(g.Miktar);Text(g.Aciklama,1,400,"Açıklama");if(g.Anahtar==Guid.Empty)throw new ArgumentException("İşlem kimliği gerekli.");using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"WAREHOUSE.RESERVE");
        if(g.Kayit.HasValue){using var parent=Q(c,t,"SELECT COUNT(*) FROM dbo.MPX310_Kayit WHERE Id=@id AND Tur IN('Sevkiyat','Kapasite') AND Durum=N'Taslak'",("@id",g.Kayit));if(Convert.ToInt32(parent.ExecuteScalar())!=1)throw new ArgumentException("Açık sevkiyat veya üretim planı bulunamadı.");}
        using(var prior=Q(c,t,"SELECT Id FROM dbo.MPX310_Rezervasyon WITH(UPDLOCK,HOLDLOCK) WHERE Anahtar=@k",("@k",g.Anahtar)))if(prior.ExecuteScalar() is not null)throw new InvalidOperationException("Rezervasyon zaten kaydedildi.");
        if(Available(c,t,g.Lot,g.Raf)<g.Miktar)throw new InvalidOperationException("Serbest miktar yetersiz.");using var q=Q(c,t,"INSERT dbo.MPX310_Rezervasyon(Anahtar,KayitId,LotId,RafId,Miktar,Kullanici) OUTPUT INSERTED.Id VALUES(@k,@id,@l,@r,@m,@u)",("@k",g.Anahtar),("@id",g.Kayit),("@l",g.Lot),("@r",g.Raf),("@m",g.Miktar),("@u",user));long id=Convert.ToInt64(q.ExecuteScalar());Event(c,t,g.Kayit,"Rezervasyon",id+" · "+g.Aciklama);t.Commit();return id;
    }
    public void RezervasyonBirak(long id,string gerekce)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"IsletmeServisi.RezervasyonBirak","",new object?[]{id,gerekce});return;}

        Text(gerekce,3,400,"Gerekçe");using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"WAREHOUSE.RESERVE");using var q=Q(c,t,"UPDATE dbo.MPX310_Rezervasyon SET Durum=N'İptal' WHERE Id=@i AND Durum=N'Bekliyor'",("@i",id));if(q.ExecuteNonQuery()!=1)throw new InvalidOperationException("Bekleyen rezervasyon bulunamadı.");Event(c,t,null,"Rezervasyon bırakıldı",id+" · "+gerekce);t.Commit();
    }
    public void Sayim(SayimGirdisi g)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"IsletmeServisi.Sayim","",new object?[]{g});return;}

        Text(g.No,1,80,"Sayım no");Text(g.Gerekce,5,400,"Fark gerekçesi");if(g.Kalemler is null||g.Kalemler.Length==0||g.Kalemler.Length>500||g.Kalemler.Select(k=>(k.Lot,k.Raf)).Distinct().Count()!=g.Kalemler.Length)throw new ArgumentException("Sayım kalemleri boş veya tekrarlı.");
        using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"WAREHOUSE.COUNT");using(var prior=Q(c,t,"SELECT Id FROM dbo.MPX310_Kayit WITH(UPDLOCK,HOLDLOCK) WHERE Anahtar=@k",("@k",g.Anahtar)))if(prior.ExecuteScalar() is not null)throw new InvalidOperationException("Sayım zaten işlendi.");long id=Create(c,t,"Sayim",g.Anahtar,g,"Tamamlandı");
        var journalLines=new List<MuhasebeKalemi>();
        foreach(var k in g.Kalemler.OrderBy(k=>k.Lot).ThenBy(k=>k.Raf))
        {
            if(k.Sayilan<0||decimal.Round(k.Sayilan,3)!=k.Sayilan)throw new ArgumentException("Sayım miktarı negatif olamaz, en fazla üç ondalıklı olmalı.");
            var rows=Table(Q(c,t,"SELECT b.Miktar,b.Surum,l.StokId,l.BirimMaliyet,s.StokTipi FROM dbo.MPX310_LotBakiye b WITH(UPDLOCK,HOLDLOCK) JOIN dbo.MPX310_Lot l ON l.Id=b.LotId JOIN dbo.StokKartlari s ON s.Id=l.StokId WHERE b.LotId=@l AND b.RafId=@r",("@l",k.Lot),("@r",k.Raf)));if(rows.Rows.Count!=1)throw new ArgumentException("Sayım raf bakiyesi bulunamadı.");var r=rows.Rows[0];Version(r,k.Surum);decimal old=(decimal)r["Miktar"],delta=k.Sayilan-old;
            using(var reserved=Q(c,t,"SELECT COALESCE(SUM(Miktar),0) FROM dbo.MPX310_Rezervasyon WITH(UPDLOCK,HOLDLOCK) WHERE LotId=@l AND RafId=@r AND Durum=N'Bekliyor'",("@l",k.Lot),("@r",k.Raf)))if(k.Sayilan<Convert.ToDecimal(reserved.ExecuteScalar()))throw new InvalidOperationException("Sayım rezervasyonun altında. Önce rezervasyonları çözün.");
            if(delta!=0){Yetki(c,t,"ACCOUNTING.POST");if(r.IsNull("BirimMaliyet"))throw new InvalidOperationException("Sayım farkını değerlemek için önce parti maliyetini tamamlayın.");decimal amount=Round(Math.Abs(delta)*(decimal)r["BirimMaliyet"]);string type=(string)r["StokTipi"],inventory=type=="Hammadde"?"150":type is "Başlık" or "Mandallı" or "Kangal"?"152":"153";if(amount>0){journalLines.Add(new(delta>0?inventory:"197",amount,0,null,g.Gerekce));journalLines.Add(new(delta>0?"397":inventory,0,amount,null,g.Gerekce));}LocationChange(c,t,k.Lot,k.Raf,delta,"Sayım","Sayim",id,g.Gerekce);AggregateChange(c,t,(int)r["StokId"],delta,"SAYIM",g.No+" · "+g.Gerekce);}
        }
        if(journalLines.Count>0){var grouped=journalLines.GroupBy(k=>(k.Hesap,Borc:k.Borc>0)).Select(x=>new MuhasebeKalemi(x.Key.Hesap,x.Sum(k=>k.Borc),x.Sum(k=>k.Alacak),null,g.Gerekce)).ToArray();Journal(c,t,new(g.Anahtar,g.Tarih,g.No+" · sayım farkı",grouped),"Sayim",id);}t.Commit();
    }
    public DataTable PartiIzle(long lot)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"IsletmeServisi.PartiIzle","",new object?[]{lot});}

        using var c=access.Ac();Yetki(c,null,"WAREHOUSE.VIEW");return Table(Q(c,null,"WITH zincir AS(SELECT @l Id,0 Seviye UNION ALL SELECT b.UrunLot,z.Seviye+1 FROM zincir z JOIN dbo.MPX310_LotBag b ON b.KaynakLot=z.Id WHERE z.Seviye<50) SELECT DISTINCT z.Seviye,l.Id,l.Kod Parti,s.StokKodu,s.StokAdi,l.Kaynak,l.KaynakId,l.Kalite,b.BelgeId,c.Unvan Musteri FROM zincir z JOIN dbo.MPX310_Lot l ON l.Id=z.Id JOIN dbo.StokKartlari s ON s.Id=l.StokId LEFT JOIN dbo.MPX310_SatisLot b ON b.LotId=l.Id LEFT JOIN dbo.BoruERP_YeniBelgeler d ON d.Id=b.BelgeId LEFT JOIN dbo.CariKartlari c ON c.Id=d.CariId ORDER BY z.Seviye,l.Id OPTION(MAXRECURSION 100)",("@l",lot)));
    }
    public void PartiMaliyeti(long lot,byte[] surum,decimal maliyet,string gerekce)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"IsletmeServisi.PartiMaliyeti","",new object?[]{lot,surum,maliyet,gerekce});return;}

        Money(maliyet);Text(gerekce,5,400,"Maliyet dayanağı");using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"WAREHOUSE.CONFIG");Yetki(c,t,"ACCOUNTING.POST");
        var rows=Table(Q(c,t,"SELECT Surum,BirimMaliyet,Kaynak FROM dbo.MPX310_Lot WITH(UPDLOCK,HOLDLOCK) WHERE Id=@l",("@l",lot)));if(rows.Rows.Count!=1)throw new ArgumentException("Parti bulunamadı.");Version(rows.Rows[0],surum);if(!rows.Rows[0].IsNull("BirimMaliyet")||((string)rows.Rows[0]["Kaynak"]) is not("Devir" or "StokGiris"))throw new InvalidOperationException("Yalnız maliyeti boş devir veya stok giriş partisine maliyet atanabilir.");
        using(var used=Q(c,t,"SELECT COUNT(*) FROM dbo.MPX310_LotHareket WITH(UPDLOCK,HOLDLOCK) WHERE LotId=@l AND Miktar<0",("@l",lot)))if(Convert.ToInt32(used.ExecuteScalar())>0)throw new InvalidOperationException("Partide çıkış var; kaynak maliyeti artık değiştirilemez.");using(var q=Q(c,t,"UPDATE dbo.MPX310_Lot SET BirimMaliyet=@m WHERE Id=@l",("@m",maliyet),("@l",lot)))q.ExecuteNonQuery();Event(c,t,null,"Parti maliyet atandı",lot+" · "+maliyet+" TRY · "+gerekce);t.Commit();
    }
    public DataTable PartiKimligi(long lot){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"IsletmeServisi.PartiKimligi","",new object?[]{lot});}
using var c=access.Ac();Yetki(c,null,"WAREHOUSE.VIEW");return Table(Q(c,null,"SELECT Id,Kod,BirimMaliyet,Surum FROM dbo.MPX310_Lot WHERE Id=@l",("@l",lot)));}
    public DataTable Rezervasyonlar(){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"IsletmeServisi.Rezervasyonlar","",new object?[]{});}
using var c=access.Ac();Yetki(c,null,"WAREHOUSE.RESERVE");return Table(Q(c,null,"SELECT r.Id,CONVERT(nvarchar(20),r.Id)+N' · '+s.StokAdi+N' / '+l.Kod+N' · '+CONVERT(nvarchar(30),r.Miktar)+N' '+s.Birim AS Ad,r.KayitId,r.Miktar,r.Zaman FROM dbo.MPX310_Rezervasyon r JOIN dbo.MPX310_Lot l ON l.Id=r.LotId JOIN dbo.StokKartlari s ON s.Id=l.StokId WHERE r.Durum=N'Bekliyor' ORDER BY r.Id DESC"));}
}
