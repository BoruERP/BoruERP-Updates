using SqlConnection = MiapaxERP.Desktop.ErpSqlConnection;
using SqlCommand = MiapaxERP.Desktop.ErpSqlCommand;
using SqlTransaction = MiapaxERP.Desktop.ErpSqlTransaction;
using SqlDataReader = MiapaxERP.Desktop.ErpSqlReader;
using SqlDataAdapter = MiapaxERP.Desktop.ErpSqlDataAdapter;
using System;
using System.Collections.Generic;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;

namespace MiapaxERP.Desktop
{
    // Stok yetkileri tek bir yerde kontrol edilir. SQL sorguları oturumdaki kullanıcı ID'sine bağlıdır.
    public partial class MainWindow
    {
        // Önbellek SADECE butonların görüntüsü içindir. Her yazma işlemi SQL'den yeniden doğrulanır.
        private readonly HashSet<string> stokArayuzYetkileri =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        private static bool StokSqlYetkisiVar(SqlConnection baglanti,
            SqlTransaction? islem, int kullaniciId, string yetkiKodu)
        {
            try { LisansOturumu.YetkiGerekli(yetkiKodu); } catch(UnauthorizedAccessException) { return false; }
            const string sql = @"
SELECT CASE WHEN EXISTS (
    SELECT 1 FROM dbo.vw_KullaniciEtkinYetkileri
    WHERE KullaniciId = @KullaniciId AND YetkiKodu = @YetkiKodu AND Yetkili = 1
) THEN 1 ELSE 0 END;";
            using var komut = new SqlCommand(sql, baglanti, islem);
            komut.Parameters.Add("@KullaniciId", SqlDbType.Int).Value = kullaniciId;
            komut.Parameters.Add("@YetkiKodu", SqlDbType.NVarChar, 80).Value = yetkiKodu;
            return Convert.ToInt32(komut.ExecuteScalar()) == 1;
        }

        // Yazma yapan mevcut SQL bağlantısından kontrol edilir (hareketlerde aynı transaction içinde).
        private void StokSqlYetkisiZorunlu(SqlConnection baglanti,
            SqlTransaction? islem, string yetkiKodu)
        {
            if (DemoModu) return; // Demo SQLite erişimi ayrı, test ortamıdır.
            int? kullaniciId = aktifKullanici?.KullaniciId;
            if (!kullaniciId.HasValue ||
                !StokSqlYetkisiVar(baglanti, islem, kullaniciId.Value, "STOCK.VIEW") ||
                !StokSqlYetkisiVar(baglanti, islem, kullaniciId.Value, yetkiKodu))
                throw new UnauthorizedAccessException(
                    "Bu işlem için yetkiniz yok: " + yetkiKodu +
                    ". Yönetici izinlerinizi kontrol etmelidir.");
        }

        // Ekran açma / veri okuma için taze SQL yetkisi. Hata halinde kapalı (fail-closed).
        private bool StokYetkisiVar(string yetkiKodu)
        {
            if (DemoModu) return true;
            if (aktifKullanici == null) return false;
            try
            {
                using var baglanti = new SqlConnection(baglantiAdresi);
                baglanti.Open();
                return StokSqlYetkisiVar(baglanti, null, aktifKullanici.KullaniciId, yetkiKodu);
            }
            catch
            {
                // Bağlantı yoksa / sorgu çalışmıyorsa izin VAR sayılmaz.
                return false;
            }
        }

        private bool StokYetkisiGerekli(string yetkiKodu)
        {
            if (StokYetkisiVar(yetkiKodu)) return true;
            MessageBox.Show(
                "Bu bölüm veya işlem için yetkiniz bulunmuyor: " + yetkiKodu +
                "\n\nGerekirse yöneticinizden izin isteyin.",
                "MiapaxERP | Yetki Gerekli", MessageBoxButton.OK, MessageBoxImage.Warning);
            return false;
        }

        private bool StokHareketPaneliYetkisiGerekli()
        {
            if (StokYetkisiVar("STOCK.HISTORY") || StokYetkisiVar("STOCK.RECEIVE") ||
                StokYetkisiVar("STOCK.ISSUE") || StokYetkisiVar("STOCK.MINIMUM")) return true;
            MessageBox.Show("Bu stok hareketleri bölümünü kullanmak için yetkiniz bulunmuyor. " +
                "Yönetici erişim izinlerinizi kontrol etmelidir.",
                "MiapaxERP | Yetki Gerekli", MessageBoxButton.OK, MessageBoxImage.Warning);
            return false;
        }

        private bool StokArayuzYetkisiVar(string kod) =>
            DemoModu || stokArayuzYetkileri.Contains(kod);

        private bool StokHareketTipineUIYetkiVar()
        {
            if (CmbHareketTur.SelectedItem is not ComboBoxItem secim) return false;
            string? yon = secim.Tag?.ToString();
            return yon == "G" ? StokArayuzYetkisiVar("STOCK.RECEIVE") :
                   yon == "C" && StokArayuzYetkisiVar("STOCK.ISSUE");
        }

        private void StokHareketButonunuYenile()
        {
            if (BtnHareketKaydet != null)
                BtnHareketKaydet.IsEnabled = CmbHareketStok.SelectedValue is int &&
                    TxtHareketMevcutBakiye?.Text.StartsWith("Mevcut:", StringComparison.Ordinal) == true &&
                    StokHareketTipineUIYetkiVar();
        }

        private void StokYetkiGorunumuYenile()
        {
            stokArayuzYetkileri.Clear();
            if (!DemoModu && aktifKullanici != null)
            {
                try
                {
                    using var baglanti = new SqlConnection(baglantiAdresi);
                    baglanti.Open();
                    using var komut = new SqlCommand(@"
SELECT YetkiKodu FROM dbo.vw_KullaniciEtkinYetkileri
WHERE KullaniciId = @Id AND Yetkili = 1 AND YetkiKodu LIKE N'STOCK.%';", baglanti);
                    komut.Parameters.Add("@Id", SqlDbType.Int).Value = aktifKullanici.KullaniciId;
                    using var okuyucu = komut.ExecuteReader();
                    while (okuyucu.Read()) stokArayuzYetkileri.Add(okuyucu.GetString(0));
                }
                catch
                {
                    // İzin sorgusu bozulduysa tüm stok eylemlerini varsayılan olarak kapat.
                    stokArayuzYetkileri.Clear();
                }
            }

            bool gor = StokArayuzYetkisiVar("STOCK.VIEW");
            bool hareket = StokArayuzYetkisiVar("STOCK.RECEIVE") ||
                           StokArayuzYetkisiVar("STOCK.ISSUE") ||
                           StokArayuzYetkisiVar("STOCK.HISTORY") ||
                           StokArayuzYetkisiVar("STOCK.MINIMUM");

            BtnMenuStok.IsEnabled = gor;
            BtnMenuStokHareket.IsEnabled = gor && hareket;
            BtnYeniStokEkle.IsEnabled = gor && StokArayuzYetkisiVar("STOCK.CREATE");
            BtnStokDuzenle.IsEnabled = gor && StokArayuzYetkisiVar("STOCK.EDIT");
            BtnStokKaydet.IsEnabled = gor && StokArayuzYetkisiVar(
                duzenlenenStokId.HasValue ? "STOCK.EDIT" : "STOCK.CREATE");
            BtnPasifeAl.IsEnabled = gor && StokArayuzYetkisiVar("STOCK.STATUS");
            BtnAktiflestir.IsEnabled = gor && StokArayuzYetkisiVar("STOCK.STATUS");
            BtnStokAcilisAc.IsEnabled = gor && StokArayuzYetkisiVar("STOCK.OPENING");
            if (!StokArayuzYetkisiVar("STOCK.OPENING")) BtnStokAcilisKaydet.IsEnabled = false;
            BtnStokMinimumKaydet.IsEnabled = gor && StokArayuzYetkisiVar("STOCK.MINIMUM");
            TxtHareketMinimum.IsReadOnly = !StokArayuzYetkisiVar("STOCK.MINIMUM");
            StokHareketGecmisiTablosu.Visibility = StokArayuzYetkisiVar("STOCK.HISTORY")
                ? Visibility.Visible : Visibility.Collapsed;
            StokAcilisHareketTablosu.Visibility = StokArayuzYetkisiVar("STOCK.HISTORY")
                ? Visibility.Visible : Visibility.Collapsed;
            StokHareketButonunuYenile();
        }
    }
}
