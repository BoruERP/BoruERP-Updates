using System.Buffers.Binary;
using System.Data;
using System.IO;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

public sealed record ErpGorselDosyasi(string Ad,byte[] Veri);
public sealed record ErpGorselKapak(int StokId,byte[] Veri);
public sealed record ErpKullaniciGirdisi(int? Id,string KullaniciAdi,string AdSoyad,string Eposta,int Rol,bool Aktif,string IlkSifre);
public sealed record ErpYetkiKarari(int Id,bool? Izin);
public sealed partial class YardimciEkranServisi(string connection,int user)
{
    readonly ErpModulServisi access=new(connection,user);
    static SqlCommand Q(SqlConnection c,SqlTransaction? t,string sql,params(string,object?)[] ps)=>ErpModulServisi.Komut(c,t,sql,ps);
    static void Metin(string? value,int min,int max,string label){if(value is null||value.Trim().Length<min||value.Length>max)throw new ArgumentException(label+" alanını kontrol edin.");}
    void Yetki(SqlConnection c,SqlTransaction? t,string permission)=>access.Yetki(c,t,permission);
    void Yonetici(SqlConnection c,SqlTransaction? t)
    {
        LisansOturumu.YetkiGerekli("USERS.MANAGE");
        using var q=Q(c,t,"SELECT COUNT(*) FROM dbo.Kullanicilar k JOIN dbo.KullaniciRolAtamalari a ON a.KullaniciId=k.Id JOIN dbo.KullaniciRolleri r ON r.Id=a.RolId WHERE k.Id=@u AND k.Aktif=1 AND r.Aktif=1 AND r.RolAdi=N'Yönetici'",("@u",user));
        if(Convert.ToInt32(q.ExecuteScalar())==0)throw new UnauthorizedAccessException("Yönetici hesabı gerekli.");
    }
    public void YoneticiKontrol(){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"YardimciEkranServisi.YoneticiKontrol","",new object?[]{});return;}
using var c=access.Ac();Yonetici(c,null);}
    public void FiyatKaydet(int stok,decimal? alis,decimal? bayi,decimal? perakende,string para)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"YardimciEkranServisi.FiyatKaydet","",new object?[]{stok,alis,bayi,perakende,para});return;}

        foreach(var n in new[]{alis,bayi,perakende})if(n<0||n>99999999999999m||n.HasValue&&decimal.Round(n.Value,4)!=n.Value)throw new ArgumentException("Fiyat geçersiz.");
        if(para is not("TRY" or "USD" or "EUR" or "GBP"))throw new ArgumentException("Para birimi geçersiz.");
        using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"STOCK.VIEW");Yetki(c,t,"STOCK.EDIT");
        using var exists=Q(c,t,"SELECT COUNT(*) FROM dbo.StokKartlari WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id",("@id",stok));if(Convert.ToInt32(exists.ExecuteScalar())!=1)throw new ArgumentException("Stok bulunamadı.");
        using var q=Q(c,t,"UPDATE dbo.StokFiyatlari WITH(UPDLOCK,HOLDLOCK) SET AlisMaliyeti=@a,BayiSatisFiyati=@b,PerakendeSatisFiyati=@p,ParaBirimi=@pb,GuncellemeUtc=SYSUTCDATETIME() WHERE StokKartId=@id;IF @@ROWCOUNT=0 INSERT dbo.StokFiyatlari(StokKartId,AlisMaliyeti,BayiSatisFiyati,PerakendeSatisFiyati,ParaBirimi) VALUES(@id,@a,@b,@p,@pb)",("@id",stok),("@a",alis),("@b",bayi),("@p",perakende),("@pb",para));q.ExecuteNonQuery();t.Commit();
    }
    static void Png(byte[] data)
    {
        if(data is null||data.Length<24||data.Length>5*1024*1024||!data.AsSpan(0,8).SequenceEqual(new byte[]{137,80,78,71,13,10,26,10}))throw new ArgumentException("Geçerli, en fazla 5 MB PNG gerekli.");
        int w=BinaryPrimitives.ReadInt32BigEndian(data.AsSpan(16,4)),h=BinaryPrimitives.ReadInt32BigEndian(data.AsSpan(20,4));
        if(w<1||h<1||w>12000||h>12000||(long)w*h>12_000_000)throw new ArgumentException("Görselin boyutlarını küçültün.");
    }
    public void GorselEkle(int stok,ErpGorselDosyasi[] files)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"YardimciEkranServisi.GorselEkle","",new object?[]{stok,files});return;}

        if(files is null||files.Length is <1 or >50||files.Sum(f=>(long)f.Veri.Length)>40*1024*1024)throw new ArgumentException("Bir kerede en fazla 40 MB fotoğraf ekleyin.");
        foreach(var f in files){Metin(f.Ad,1,255,"Dosya adı");if(Path.GetFileName(f.Ad)!=f.Ad)throw new ArgumentException("Dosya adı geçersiz.");Png(f.Veri);}
        using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"STOCK.VIEW");Yetki(c,t,"STOCK.EDIT");
        using(var check=Q(c,t,"SELECT COUNT(*) FROM dbo.StokKartlari WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id",("@id",stok)))if(Convert.ToInt32(check.ExecuteScalar())!=1)throw new ArgumentException("Stok bulunamadı.");
        foreach(var f in files){using var q=Q(c,t,"INSERT dbo.UrunGorselleri(StokKartId,DosyaAdi,IcerikTuru,GorselVerisi,KapakMi,SiraNo) VALUES(@s,@ad,N'image/png',@v,CASE WHEN NOT EXISTS(SELECT 1 FROM dbo.UrunGorselleri WITH(UPDLOCK,HOLDLOCK) WHERE StokKartId=@s AND KapakMi=1) THEN 1 ELSE 0 END,ISNULL((SELECT MAX(SiraNo)+1 FROM dbo.UrunGorselleri WHERE StokKartId=@s),0))",("@s",stok),("@ad",f.Ad),("@v",f.Veri));q.ExecuteNonQuery();}t.Commit();
    }
    public void GorselKapak(int stok,int id)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"YardimciEkranServisi.GorselKapak","",new object?[]{stok,id});return;}

        using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"STOCK.VIEW");Yetki(c,t,"STOCK.EDIT");
        using var check=Q(c,t,"SELECT COUNT(*) FROM dbo.UrunGorselleri WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND StokKartId=@s",("@id",id),("@s",stok));if(Convert.ToInt32(check.ExecuteScalar())!=1)throw new ArgumentException("Görsel bulunamadı.");
        using var q=Q(c,t,"UPDATE dbo.UrunGorselleri SET KapakMi=CASE WHEN Id=@id THEN 1 ELSE 0 END WHERE StokKartId=@s",("@id",id),("@s",stok));q.ExecuteNonQuery();t.Commit();
    }
    public void GorselSil(int stok,int id)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"YardimciEkranServisi.GorselSil","",new object?[]{stok,id});return;}

        using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"STOCK.VIEW");Yetki(c,t,"STOCK.EDIT");
        using var q=Q(c,t,"DELETE dbo.UrunGorselleri WHERE Id=@id AND StokKartId=@s;IF NOT EXISTS(SELECT 1 FROM dbo.UrunGorselleri WHERE StokKartId=@s AND KapakMi=1) UPDATE dbo.UrunGorselleri SET KapakMi=1 WHERE Id=(SELECT TOP(1) Id FROM dbo.UrunGorselleri WHERE StokKartId=@s ORDER BY SiraNo,Id)",("@id",id),("@s",stok));q.ExecuteNonQuery();t.Commit();
    }
    public ErpGorselKapak[] Kapaklar(int[] ids)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<ErpGorselKapak[]>(connection,"YardimciEkranServisi.Kapaklar","",new object?[]{ids});}

        if(ids is null||ids.Length>150)throw new ArgumentException("Görsel listesi çok büyük.");
        using var c=access.Ac();Yetki(c,null,"STOCK.VIEW");var result=new List<ErpGorselKapak>();
        foreach(int id in ids.Distinct())
        {
            using var q=Q(c,null,"SELECT TOP(1) GorselVerisi FROM dbo.UrunGorselleri WHERE StokKartId=@id ORDER BY KapakMi DESC,SiraNo,Id",("@id",id));
            if(q.ExecuteScalar() is not byte[] bytes)continue;
            using var stream=new MemoryStream(bytes);var image=new System.Windows.Media.Imaging.BitmapImage();image.BeginInit();image.CacheOption=System.Windows.Media.Imaging.BitmapCacheOption.OnLoad;image.DecodePixelWidth=128;image.DecodePixelHeight=128;image.StreamSource=stream;image.EndInit();image.Freeze();
            var encoder=new System.Windows.Media.Imaging.PngBitmapEncoder();encoder.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(image));using var buffer=new MemoryStream();encoder.Save(buffer);result.Add(new(id,buffer.ToArray()));
        }
        return result.ToArray();
    }
    public void FirmaHazirla(){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"YardimciEkranServisi.FirmaHazirla","",new object?[]{});return;}
using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"USERS.MANAGE");using var q=Q(c,t,FirmaSemasi);q.ExecuteNonQuery();t.Commit();}
    public void FirmaKaydet(Dictionary<string,string> fields)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"YardimciEkranServisi.FirmaKaydet","",new object?[]{fields});return;}

        if(fields is null||fields.Count!=FirmaAlanlari.Length||fields.Keys.Any(k=>!FirmaAlanlari.Contains(k)))throw new ArgumentException("Firma alanları geçersiz.");
        Metin(fields["FirmaAdi"],2,200,"Firma adı");
        using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"USERS.MANAGE");
        using var q=Q(c,t,"UPDATE dbo.FirmaBilgileri SET "+string.Join(',',FirmaAlanlari.Select(k=>"["+k+"]=@"+k))+",GuncellemeTarihi=SYSDATETIME() WHERE Id=1;IF @@ROWCOUNT=0 INSERT dbo.FirmaBilgileri(Id,"+string.Join(',',FirmaAlanlari.Select(k=>"["+k+"]"))+") VALUES(1,"+string.Join(',',FirmaAlanlari.Select(k=>"@"+k))+")");
        foreach(string key in FirmaAlanlari){int max=key switch{"FirmaAdi"=>200,"VergiDairesi"=>100,"VergiNo"=>20,"Telefon"=>40,"Adres"=>400,"Aciklama" or "FaaliyetKonusu"=>1000,_=>500};Metin(fields[key],0,max,key);q.Parameters.Add("@"+key,SqlDbType.NVarChar,max).Value=fields[key].Trim();}q.ExecuteNonQuery();t.Commit();
    }
    public void FirmaBelgeEkle(string tur,string ad,byte[] pdf)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"YardimciEkranServisi.FirmaBelgeEkle","",new object?[]{tur,ad,pdf});return;}

        Metin(tur,1,100,"Belge türü");Metin(ad,1,255,"Dosya adı");if(Path.GetFileName(ad)!=ad||pdf is null||pdf.Length<5||pdf.Length>20*1024*1024||!pdf.AsSpan(0,5).SequenceEqual("%PDF-"u8))throw new ArgumentException("Geçerli ve en fazla 20 MB PDF gerekli.");
        using var c=access.Ac();using var t=c.BeginTransaction();Yetki(c,t,"USERS.MANAGE");using var q=Q(c,t,"INSERT dbo.FirmaBelgeleri(BelgeTuru,DosyaAdi,PdfIcerik,EkleyenKullaniciId) VALUES(@t,@a,@p,@u)",("@t",tur),("@a",ad),("@p",pdf),("@u",user));q.ExecuteNonQuery();t.Commit();
    }
    public void FirmaBelgeSil(int id){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"YardimciEkranServisi.FirmaBelgeSil","",new object?[]{id});return;}
using var c=access.Ac();using var t=c.BeginTransaction();Yetki(c,t,"USERS.MANAGE");using var q=Q(c,t,"DELETE dbo.FirmaBelgeleri WHERE Id=@id",("@id",id));q.ExecuteNonQuery();t.Commit();}
    public int TipEkle(string ad)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<int>(connection,"YardimciEkranServisi.TipEkle","",new object?[]{ad});}

        Metin(ad,1,30,"Stok tipi");using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yonetici(c,t);Yetki(c,t,"STOCK.EDIT");using var q=Q(c,t,TipSql,("@Ad",ad));int id=Convert.ToInt32(q.ExecuteScalar());t.Commit();return id;
    }
    public void KategoriEkle(int tip,int? ust,string ad,bool boru)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"YardimciEkranServisi.KategoriEkle","",new object?[]{tip,ust,ad,boru});return;}

        Metin(ad,1,80,"Kategori");if(tip<=0)throw new ArgumentException("Stok tipi gerekli.");using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yonetici(c,t);Yetki(c,t,"STOCK.EDIT");using var q=Q(c,t,KategoriSql,("@TipId",tip),("@UstId",ust),("@Ad",ad),("@Boru",boru));q.ExecuteNonQuery();t.Commit();
    }
    public void OzellikEkle(int tip,int? kategori,string ad,string tur,string secenek,bool zorunlu)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"YardimciEkranServisi.OzellikEkle","",new object?[]{tip,kategori,ad,tur,secenek,zorunlu});return;}

        Metin(ad,1,100,"Özellik");Metin(secenek,0,500,"Seçenekler");if(tip<=0||tur is not("Metin" or "Sayı" or "Tarih" or "Seçim")||tur=="Seçim"&&secenek.Split('|',StringSplitOptions.TrimEntries|StringSplitOptions.RemoveEmptyEntries).Length<2)throw new ArgumentException("Özellik bilgileri geçersiz.");
        using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yonetici(c,t);Yetki(c,t,"STOCK.EDIT");using var q=Q(c,t,OzellikSql,("@Tip",tip),("@Kategori",kategori),("@Ad",ad),("@Tur",tur),("@Secenekler",tur=="Seçim"?secenek:null),("@Zorunlu",zorunlu));q.ExecuteNonQuery();t.Commit();
    }
    public void TakvimEkle(string baslik,string aciklama,string tur,DateTime tarih)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"YardimciEkranServisi.TakvimEkle","",new object?[]{baslik,aciklama,tur,tarih});return;}

        Metin(baslik,3,180,"Başlık");Metin(aciklama,0,1000,"Açıklama");Metin(tur,1,60,"Tür");using var c=access.Ac();using var t=c.BeginTransaction();Yetki(c,t,"CALENDAR.CREATE");
        using var q=Q(c,t,"INSERT dbo.IsTakvimi(Baslik,Aciklama,Tur,PlanTarihi,OlusturanKullaniciId,AtananKullaniciId,Durum) VALUES(@b,@a,@tur,@d,@u,@u,N'Bekliyor')",("@b",baslik),("@a",aciklama),("@tur",tur),("@d",tarih),("@u",user));q.ExecuteNonQuery();t.Commit();
    }
    public void TakvimDurum(int id,string durum)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"YardimciEkranServisi.TakvimDurum","",new object?[]{id,durum});return;}

        string permission=durum switch{"Tamamlandı"=>"CALENDAR.COMPLETE","İptal"=>"CALENDAR.CANCEL",_=>throw new ArgumentException("Durum geçersiz.")};
        using var c=access.Ac();using var t=c.BeginTransaction();Yetki(c,t,permission);bool all=false;try{Yetki(c,t,"CALENDAR.ALL");all=true;}catch(UnauthorizedAccessException){}
        using var q=Q(c,t,"UPDATE dbo.IsTakvimi SET Durum=@d,DegistirenKullaniciId=@u,DegistirmeTarihi=SYSUTCDATETIME() WHERE Id=@id AND Durum=N'Bekliyor' AND (@all=1 OR OlusturanKullaniciId=@u OR AtananKullaniciId=@u)",("@d",durum),("@u",user),("@id",id),("@all",all));if(q.ExecuteNonQuery()!=1)throw new InvalidOperationException("Plan bulunamadı veya işlenmiş.");t.Commit();
    }
    public void BildirimOkundu(int[] ids)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"YardimciEkranServisi.BildirimOkundu","",new object?[]{ids});return;}

        if(ids is null||ids.Length>500)throw new ArgumentException();using var c=access.Ac();using var t=c.BeginTransaction();
        foreach(int id in ids.Distinct()){using var q=Q(c,t,"UPDATE dbo.Bildirimler SET OkunduUtc=SYSUTCDATETIME() WHERE Id=@id AND AliciKullaniciId=@u AND OkunduUtc IS NULL",("@id",id),("@u",user));q.ExecuteNonQuery();}t.Commit();
    }
}
