using System.IO;
namespace MiapaxERP.Guncelleme;

public static class GuncellemeKanalAyari
{
 public const string DosyaAdi="MiapaxERP.guncelleme.json";
 public const string EskiDosyaAdi="BoruERP.guncelleme.json";
 public const string OncekiMarkaDosyasi="MiaSoft.guncelleme.json";
 public static string DosyaYolu(string klasor)
 {
  string yeni=Path.Combine(klasor,DosyaAdi);
  return new[]{DosyaAdi,OncekiMarkaDosyasi,EskiDosyaAdi}.Select(x=>Path.Combine(klasor,x)).FirstOrDefault(File.Exists)??yeni;
 }
 public static bool KorunanDosya(string ad)=>new[]{DosyaAdi,OncekiMarkaDosyasi,EskiDosyaAdi}.Contains(ad,StringComparer.OrdinalIgnoreCase);
}
