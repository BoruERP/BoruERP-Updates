using System.Data;
using System.Text.Json;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

public sealed class RestoranServisi(string connection,int user)
{
    readonly ErpModulServisi access=new(connection,user);
    public void Kur()
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"RestoranServisi.Kur","",new object?[]{});return;}

        LisansOturumu.Gerekli("RESTORAN");new SektorUretimServisi(connection,user).Kur();using var c=access.Ac();
        using(var q=Q(c,null,"SELECT COUNT(*) FROM dbo.BERP_Sema WHERE Surum=201"))if(Convert.ToInt32(q.ExecuteScalar())==1)return;
        access.Yetki(c,null,"MODULES.INSTALL");using var cmd=Q(c,null,System.IO.File.ReadAllText(System.IO.Path.Combine(AppContext.BaseDirectory,"Moduller201.sql")));cmd.ExecuteNonQuery();
    }
    static SqlCommand Q(SqlConnection c,SqlTransaction? tx,string sql,params(string,object?)[] p)=>SektorUretimServisi.Q(c,tx,sql,p);
    void Yetki(SqlConnection c,SqlTransaction? tx,string permission){LisansOturumu.Gerekli("RESTORAN");access.Yetki(c,tx,permission);}
    public DataTable Oku(string kind,long id=0)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"RestoranServisi.Oku","",new object?[]{kind,id});}

        using var c=access.Ac();Yetki(c,null,"RESTAURANT.VIEW");
        string sql=kind switch{
            "masa"=>"SELECT Id,Ad FROM dbo.BERP200_Masa WHERE Aktif=1 ORDER BY Ad",
            "menu"=>"SELECT m.Id,m.Ad,m.MamulId,m.ReceteId,m.BirimFiyat,m.Surum,s.Birim FROM dbo.BERP200_Menu m JOIN dbo.StokKartlari s ON s.Id=m.MamulId WHERE m.Aktif=1 ORDER BY m.Ad",
            "hesap"=>"SELECT Id,HesapAdi,ParaBirimi FROM dbo.FinansHesaplari WHERE Aktif=1 AND ParaBirimi=N'TRY' ORDER BY HesapAdi",
            "adisyon"=>"SELECT TOP(300) a.Id,m.Ad AS Masa,a.Durum,a.Acilis,a.Kapanis,COALESCE(k.Toplam,0) AS Toplam,COALESCE(o.Odenen,0) AS Odenen,CASE WHEN a.Durum=N'İptal' THEN 0 ELSE COALESCE(k.Toplam,0)-COALESCE(o.Odenen,0) END AS Kalan,a.Surum FROM dbo.BERP200_Adisyon a JOIN dbo.BERP200_Masa m ON m.Id=a.MasaId OUTER APPLY(SELECT SUM(ROUND(Miktar*BirimFiyat,2)) AS Toplam FROM dbo.BERP200_AdisyonKalem WHERE AdisyonId=a.Id AND Iptal=0)k OUTER APPLY(SELECT SUM(Tutar) AS Odenen FROM dbo.BERP200_Odeme WHERE AdisyonId=a.Id AND IadeFinansId IS NULL)o ORDER BY a.Id DESC",
            "kalem"=>"SELECT Id,Ad,Miktar,BirimFiyat,ROUND(Miktar*BirimFiyat,2) AS Toplam,MutfakDurumu,Iptal FROM dbo.BERP200_AdisyonKalem WHERE AdisyonId=@id ORDER BY Id",
            "mutfak"=>"SELECT k.Id,a.Id AS Adisyon,m.Ad AS Masa,k.Ad,k.Miktar,k.MutfakDurumu,a.Acilis FROM dbo.BERP200_AdisyonKalem k JOIN dbo.BERP200_Adisyon a ON a.Id=k.AdisyonId JOIN dbo.BERP200_Masa m ON m.Id=a.MasaId WHERE a.Kapanis IS NULL AND k.Iptal=0 AND k.MutfakDurumu IN(N'Hazırlanıyor',N'Hazır') ORDER BY k.Id",
            "odeme"=>"SELECT o.Id,o.Tarih,o.Tutar,o.Yontem,o.Belge,h.HesapAdi,o.IadeFinansId FROM dbo.BERP200_Odeme o JOIN dbo.FinansHesaplari h ON h.Id=o.HesapId WHERE o.AdisyonId=@id ORDER BY o.Id",
            _=>throw new ArgumentException("Liste bulunamadı.")};
        using var q=Q(c,null,sql,("@id",id));using var rd=q.ExecuteReader();var t=new DataTable();t.Load(rd);return t;
    }
    public void MasaKaydet(string ad)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"RestoranServisi.MasaKaydet","",new object?[]{ad});return;}

        if(string.IsNullOrWhiteSpace(ad)||ad.Length>50)throw new ArgumentException("Masa adı gerekli (en fazla 50 karakter).");
        using var c=access.Ac();Yetki(c,null,"RESTAURANT.EDIT");using var q=Q(c,null,"INSERT dbo.BERP200_Masa(Ad)VALUES(@a)",("@a",ad.Trim()));q.ExecuteNonQuery();
    }
    public void MenuKaydet(string ad,int product,long? recipe,decimal price,int? editId=null,byte[]? version=null)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"RestoranServisi.MenuKaydet","",new object?[]{ad,product,recipe,price,editId,version});return;}

        if(string.IsNullOrWhiteSpace(ad)||ad.Length>160||price<=0||decimal.Round(price,2)!=price)throw new ArgumentException("Menü adı ve pozitif, iki ondalıklı KDV dahil birim fiyat gerekli.");
        using var c=access.Ac();using var tx=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,tx,"RESTAURANT.EDIT");SektorUretimServisi.Birim(c,tx,product);
        if(recipe.HasValue)SektorUretimServisi.Hesapla(c,tx,recipe.Value,1,product);
        using var q=Q(c,tx,editId.HasValue?"UPDATE dbo.BERP200_Menu SET Ad=@a,MamulId=@p,ReceteId=@r,BirimFiyat=@f WHERE Id=@id AND Surum=@v":"INSERT dbo.BERP200_Menu(Ad,MamulId,ReceteId,BirimFiyat)VALUES(@a,@p,@r,@f)",("@a",ad.Trim()),("@p",product),("@r",recipe),("@f",price),("@id",editId),("@v",version));if(q.ExecuteNonQuery()!=1)throw new InvalidOperationException("Menü kartı değişmiş. Yenileyin.");tx.Commit();
    }
    static string Acik(SqlConnection c,SqlTransaction tx,long bill,byte[]? version=null)
    {
        using var q=Q(c,tx,"SELECT Durum,Surum FROM dbo.BERP200_Adisyon WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Kapanis IS NULL",("@id",bill));using var r=q.ExecuteReader();if(!r.Read())throw new ArgumentException("Açık adisyon bulunamadı.");
        if(version is not null&&!((byte[])r[1]).SequenceEqual(version))throw new InvalidOperationException("Adisyon değişmiş. Listeyi yenileyin.");return r.GetString(0);
    }
    public long Ac(Guid key,int table)
    {
        if(HttpsOturumu.Uzak(connection))return HttpsOturumu.Cagir<long>(connection,"RestoranServisi.Ac","",new object?[]{key,table});
        if(key==Guid.Empty)throw new ArgumentException("İşlem anahtarı gerekli.");
        using var c=access.Ac();using var tx=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,tx,"RESTAURANT.EDIT");
        using(var old=Q(c,tx,"SELECT Id,MasaId FROM dbo.BERP200_Adisyon WITH(UPDLOCK,HOLDLOCK) WHERE Anahtar=@k",("@k",key))){using var r=old.ExecuteReader();if(r.Read()){long id=r.GetInt64(0);if(r.GetInt32(1)!=table)throw new ArgumentException("İşlem anahtarı farklı masada kullanılmış.");r.Close();tx.Commit();return id;}}
        using(var q=Q(c,tx,"SELECT COUNT(*) FROM dbo.BERP200_Masa WITH(HOLDLOCK) WHERE Id=@t AND Aktif=1",("@t",table)))if(Convert.ToInt32(q.ExecuteScalar())!=1)throw new ArgumentException("Aktif masa seçin.");
        using var insert=Q(c,tx,"INSERT dbo.BERP200_Adisyon(Anahtar,MasaId,KullaniciId)OUTPUT INSERTED.Id VALUES(@k,@t,@u)",("@k",key),("@t",table),("@u",user));long result=Convert.ToInt64(insert.ExecuteScalar());tx.Commit();return result;
    }
    public long KalemEkle(Guid key,long bill,byte[] version,int menu,decimal qty)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"RestoranServisi.KalemEkle","",new object?[]{key,bill,version,menu,qty});}

        if(key==Guid.Empty||qty<=0||qty>1000000||decimal.Round(qty,3)!=qty)throw new ArgumentException("Pozitif ve en fazla 3 ondalıklı miktar girin.");
        using var c=access.Ac();using var tx=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,tx,"RESTAURANT.EDIT");
        using(var old=Q(c,tx,"SELECT Id,AdisyonId,MenuId,Miktar FROM dbo.BERP200_AdisyonKalem WITH(UPDLOCK,HOLDLOCK) WHERE Anahtar=@k",("@k",key))){using var r=old.ExecuteReader();if(r.Read()){long id=r.GetInt64(0);if(r.GetInt64(1)!=bill||r.GetInt32(2)!=menu||r.GetDecimal(3)!=qty)throw new ArgumentException("İşlem anahtarı farklı siparişte kullanılmış.");r.Close();tx.Commit();return id;}}
        Acik(c,tx,bill,version);
        using(var pay=Q(c,tx,"SELECT COUNT(*) FROM dbo.BERP200_Odeme WHERE AdisyonId=@id AND IadeFinansId IS NULL",("@id",bill)))if(Convert.ToInt32(pay.ExecuteScalar())>0)throw new ArgumentException("Ödeme başlayan adisyona kalem eklenemez.");
        string name;int product;long? recipe;decimal price;
        using(var q=Q(c,tx,"SELECT Ad,MamulId,ReceteId,BirimFiyat FROM dbo.BERP200_Menu WITH(HOLDLOCK) WHERE Id=@id AND Aktif=1",("@id",menu))){using var r=q.ExecuteReader();if(!r.Read())throw new ArgumentException("Aktif menü seçin.");name=r.GetString(0);product=r.GetInt32(1);recipe=r.IsDBNull(2)?null:r.GetInt64(2);price=r.GetDecimal(3);}
        var items=recipe.HasValue?SektorUretimServisi.Hesapla(c,tx,recipe.Value,qty,product):new List<StokTuketimi>{new(product,SektorUretimServisi.Birim(c,tx,product),qty)};
        using var insert=Q(c,tx,"INSERT dbo.BERP200_AdisyonKalem(Anahtar,AdisyonId,MenuId,Ad,MamulId,ReceteId,Miktar,BirimFiyat,Tuketim)OUTPUT INSERTED.Id VALUES(@k,@a,@m,@n,@p,@r,@q,@f,@d)",("@k",key),("@a",bill),("@m",menu),("@n",name),("@p",product),("@r",recipe),("@q",qty),("@f",price),("@d",JsonSerializer.Serialize(items)));long result=Convert.ToInt64(insert.ExecuteScalar());
        using var touch=Q(c,tx,"UPDATE dbo.BERP200_Adisyon SET Durum=N'Açık' WHERE Id=@id",("@id",bill));touch.ExecuteNonQuery();tx.Commit();return result;
    }
    public void KalemIptal(long bill,byte[] version,long item)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"RestoranServisi.KalemIptal","",new object?[]{bill,version,item});return;}

        using var c=access.Ac();using var tx=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,tx,"RESTAURANT.EDIT");Acik(c,tx,bill,version);
        using(var paid=Q(c,tx,"SELECT COUNT(*) FROM dbo.BERP200_Odeme WHERE AdisyonId=@id AND IadeFinansId IS NULL",("@id",bill)))if(Convert.ToInt32(paid.ExecuteScalar())>0)throw new ArgumentException("Ödeme başlayan adisyon değiştirilemez.");
        using var q=Q(c,tx,"UPDATE dbo.BERP200_AdisyonKalem SET Iptal=1 WHERE Id=@k AND AdisyonId=@a AND Iptal=0 AND MutfakDurumu=N'Yeni'",("@k",item),("@a",bill));if(q.ExecuteNonQuery()!=1)throw new ArgumentException("Yalnız mutfağa gönderilmemiş yeni kalem iptal edilebilir.");
        using var touch=Q(c,tx,"UPDATE dbo.BERP200_Adisyon SET Durum=Durum WHERE Id=@id",("@id",bill));touch.ExecuteNonQuery();tx.Commit();
    }
    public void Mutfak(long bill,byte[] version,bool ready)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"RestoranServisi.Mutfak","",new object?[]{bill,version,ready});return;}

        using var c=access.Ac();using var tx=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,tx,"RESTAURANT.KITCHEN");Acik(c,tx,bill,version);
        using var q=Q(c,tx,"UPDATE dbo.BERP200_AdisyonKalem SET MutfakDurumu=@y WHERE AdisyonId=@id AND Iptal=0 AND MutfakDurumu=@e",("@y",ready?"Hazır":"Hazırlanıyor"),("@e",ready?"Hazırlanıyor":"Yeni"),("@id",bill));if(q.ExecuteNonQuery()==0)throw new ArgumentException("Bu aşamaya geçirilecek mutfak kalemi yok.");
        using var touch=Q(c,tx,"UPDATE dbo.BERP200_Adisyon SET Durum=@d WHERE Id=@id",("@d",ready?"Hazır":"Mutfakta"),("@id",bill));touch.ExecuteNonQuery();tx.Commit();
    }
    static decimal Toplam(SqlConnection c,SqlTransaction tx,long bill,string kind)
    {
        using var q=Q(c,tx,kind=="kalem"?"SELECT COALESCE(SUM(ROUND(Miktar*BirimFiyat,2)),0) FROM dbo.BERP200_AdisyonKalem WHERE AdisyonId=@id AND Iptal=0":"SELECT COALESCE(SUM(Tutar),0) FROM dbo.BERP200_Odeme WHERE AdisyonId=@id AND IadeFinansId IS NULL",("@id",bill));return Convert.ToDecimal(q.ExecuteScalar());
    }
    static long Finans(SqlConnection c,SqlTransaction tx,int user,int account,decimal amount,string type,string note,long? reverse=null)
    {
        using(var q=Q(c,tx,"SELECT COUNT(*) FROM dbo.FinansHesaplari WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Aktif=1 AND ParaBirimi=N'TRY'",("@id",account)))if(Convert.ToInt32(q.ExecuteScalar())!=1)throw new ArgumentException("Aktif TRY kasa/banka hesabı seçin.");
        using var ins=Q(c,tx,"INSERT dbo.FinansHareketleri(HesapId,Tarih,HareketTipi,Tutar,Aciklama,YapanKullaniciId,TersKayitId)OUTPUT INSERTED.Id VALUES(@h,CONVERT(date,GETDATE()),@t,@a,@n,@u,@r)",("@h",account),("@t",type),("@a",amount),("@n",note),("@u",user),("@r",reverse));return Convert.ToInt64(ins.ExecuteScalar());
    }
    public long Odeme(Guid key,long bill,byte[] version,int account,decimal amount,string method,string document)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"RestoranServisi.Odeme","",new object?[]{key,bill,version,account,amount,method,document});}

        if(key==Guid.Empty||amount<=0||decimal.Round(amount,2)!=amount||method is not("Nakit" or "Kart" or "Havale")||string.IsNullOrWhiteSpace(document)||document.Length>80)throw new ArgumentException("Pozitif tutar, yöntem ve ödeme belge numarası gerekli.");
        using var c=access.Ac();using var tx=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,tx,"RESTAURANT.PAYMENT");access.Yetki(c,tx,"FINANCE.PAYMENT");
        using(var old=Q(c,tx,"SELECT Id,AdisyonId,HesapId,Tutar,Yontem,Belge FROM dbo.BERP200_Odeme WITH(UPDLOCK,HOLDLOCK) WHERE Anahtar=@k",("@k",key))){using var r=old.ExecuteReader();if(r.Read()){long id=r.GetInt64(0);if(r.GetInt64(1)!=bill||r.GetInt32(2)!=account||r.GetDecimal(3)!=amount||r.GetString(4)!=method||r.GetString(5)!=document.Trim())throw new ArgumentException("İşlem anahtarı farklı ödemede kullanılmış.");r.Close();tx.Commit();return id;}}
        Acik(c,tx,bill,version);decimal total=Toplam(c,tx,bill,"kalem"),paid=Toplam(c,tx,bill,"odeme");if(total<=0||amount>total-paid)throw new ArgumentException("Ödeme kalan tutarı aşamaz; boş adisyona ödeme alınamaz.");
        bool close=paid+amount==total;
        if(close)
        {
            var lines=new List<StokTuketimi>();using(var q=Q(c,tx,"SELECT Tuketim FROM dbo.BERP200_AdisyonKalem WHERE AdisyonId=@id AND Iptal=0",("@id",bill))){using var r=q.ExecuteReader();while(r.Read())lines.AddRange(JsonSerializer.Deserialize<StokTuketimi[]>(r.GetString(0))??[]);}
            foreach(var group in lines.GroupBy(x=>x.StokId).OrderBy(x=>x.Key))
            {if(group.Select(x=>x.Birim).Distinct().Count()!=1)throw new ArgumentException("Tüketim birimleri uyuşmuyor.");var item=new StokTuketimi(group.Key,group.First().Birim,group.Sum(x=>x.Miktar));SektorUretimServisi.Hareket(c,tx,item,false,"Adisyon tüketimi: "+bill);using var save=Q(c,tx,"INSERT dbo.BERP200_Tuketim(AdisyonId,StokId,Birim,Miktar)VALUES(@a,@s,@b,@m)",("@a",bill),("@s",item.StokId),("@b",item.Birim),("@m",item.Miktar));save.ExecuteNonQuery();}
        }
        long finance=Finans(c,tx,user,account,amount,"Giriş","Adisyon "+bill+" / "+document.Trim());
        using var pay=Q(c,tx,"INSERT dbo.BERP200_Odeme(Anahtar,AdisyonId,HesapId,Tutar,Yontem,Belge,FinansHareketId,KullaniciId)OUTPUT INSERTED.Id VALUES(@k,@a,@h,@t,@y,@b,@f,@u)",("@k",key),("@a",bill),("@h",account),("@t",amount),("@y",method),("@b",document.Trim()),("@f",finance),("@u",user));long result=Convert.ToInt64(pay.ExecuteScalar());
        using var touch=Q(c,tx,close?"UPDATE dbo.BERP200_Adisyon SET Durum=N'Ödendi',Kapanis=SYSUTCDATETIME() WHERE Id=@id":"UPDATE dbo.BERP200_Adisyon SET Durum=Durum WHERE Id=@id",("@id",bill));touch.ExecuteNonQuery();tx.Commit();return result;
    }
    public void IptalVeyaIade(long bill,byte[] version,string reason)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"RestoranServisi.IptalVeyaIade","",new object?[]{bill,version,reason});return;}

        if(string.IsNullOrWhiteSpace(reason)||reason.Length>200)throw new ArgumentException("İptal/iade nedeni gerekli (1–200 karakter).");
        using var c=access.Ac();using var tx=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,tx,"RESTAURANT.REFUND");access.Yetki(c,tx,"FINANCE.PAYMENT");
        string state;using(var q=Q(c,tx,"SELECT Durum,Surum FROM dbo.BERP200_Adisyon WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id",("@id",bill))){using var r=q.ExecuteReader();if(!r.Read())throw new ArgumentException("Adisyon bulunamadı.");state=r.GetString(0);if(!((byte[])r[1]).SequenceEqual(version))throw new InvalidOperationException("Adisyon değişmiş. Yenileyin.");}
        if(state=="İptal"){tx.Commit();return;}
        var payments=new List<(long Id,int Account,decimal Amount,long Finance)>();
        using(var q=Q(c,tx,"SELECT Id,HesapId,Tutar,FinansHareketId FROM dbo.BERP200_Odeme WITH(UPDLOCK,HOLDLOCK) WHERE AdisyonId=@id AND IadeFinansId IS NULL",("@id",bill))){using var r=q.ExecuteReader();while(r.Read())payments.Add((r.GetInt64(0),r.GetInt32(1),r.GetDecimal(2),r.GetInt64(3)));}
        foreach(var p in payments)
        {
            using(var check=Q(c,tx,"SELECT COUNT(*) FROM dbo.FinansHareketleri WITH(UPDLOCK,HOLDLOCK) WHERE TersKayitId=@id",("@id",p.Finance)))if(Convert.ToInt32(check.ExecuteScalar())>0)throw new InvalidOperationException("Ödeme finans ekranından zaten terslenmiş. Muhasebe kontrolü gerekli.");
            long reverse=Finans(c,tx,user,p.Account,p.Amount,"Çıkış","Adisyon iadesi "+bill+" / "+reason,p.Finance);
            using var update=Q(c,tx,"UPDATE dbo.BERP200_Odeme SET IadeFinansId=@r WHERE Id=@id",("@r",reverse),("@id",p.Id));update.ExecuteNonQuery();
        }
        // A prepared meal cannot turn back into raw ingredients. Money refunds do not restore stock.
        using var cancel=Q(c,tx,"UPDATE dbo.BERP200_Adisyon SET Durum=N'İptal',Kapanis=COALESCE(Kapanis,SYSUTCDATETIME()) WHERE Id=@id",("@id",bill));cancel.ExecuteNonQuery();tx.Commit();
    }
}
