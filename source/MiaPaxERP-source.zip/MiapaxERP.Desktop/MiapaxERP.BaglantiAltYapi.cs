using System;
using System.Data;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Data.SqlClient;

namespace MiapaxERP.Desktop
{
    public sealed class MiapaxERPBaglantiAyarlari
    {
        public string Rol { get; set; } = "Ana";
        public string Sunucu { get; set; } = "localhost";
        public string Veritabani { get; set; } = "BoruERP";
        public string KimlikDogrulama { get; set; } = "Windows";
        public string SqlKullanici { get; set; } = "";
        public string SifreliSqlParola { get; set; } = "";
        public bool UzakVpn { get; set; }
        public bool SertifikaDogrula { get; set; }
        public string SertifikaSunucuAdi { get; set; } = "";
        public int BaglantiZamanAsimi { get; set; } = 3;

        private static string Dosya => System.IO.Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "BoruERP", "ag-baglantisi.json");

        public void ParolayiAyarla(string parola)
        {
            if (string.IsNullOrWhiteSpace(parola))
                throw new ArgumentException("SQL parolası boş olamaz.");
            byte[] ham = System.Text.Encoding.UTF8.GetBytes(parola);
            try
            {
                byte[] sifreli = System.Security.Cryptography.ProtectedData.Protect(
                    ham, null, System.Security.Cryptography.DataProtectionScope.CurrentUser);
                SifreliSqlParola = Convert.ToBase64String(sifreli);
            }
            finally { System.Security.Cryptography.CryptographicOperations.ZeroMemory(ham); }
        }

        public string ParolayiCoz()
        {
            if (string.IsNullOrEmpty(SifreliSqlParola)) return "";
            byte[] sifreli = Convert.FromBase64String(SifreliSqlParola);
            byte[] ham = System.Security.Cryptography.ProtectedData.Unprotect(
                sifreli, null, System.Security.Cryptography.DataProtectionScope.CurrentUser);
            try { return System.Text.Encoding.UTF8.GetString(ham); }
            finally { System.Security.Cryptography.CryptographicOperations.ZeroMemory(ham); }
        }

        public static MiapaxERPBaglantiAyarlari Oku()
        {
            try
            {
                if (!System.IO.File.Exists(Dosya)) return new MiapaxERPBaglantiAyarlari();
                return System.Text.Json.JsonSerializer.Deserialize<MiapaxERPBaglantiAyarlari>(
                    System.IO.File.ReadAllText(Dosya)) ?? new MiapaxERPBaglantiAyarlari();
            }
            catch (System.Text.Json.JsonException) { return new MiapaxERPBaglantiAyarlari(); }
            catch (System.IO.IOException) { return new MiapaxERPBaglantiAyarlari(); }
        }

        public void Kaydet()
        {
            Sunucu = Sunucu.Trim();
            Veritabani = Veritabani.Trim();
            SqlKullanici = SqlKullanici.Trim();
            if (Sunucu.Length == 0 || Sunucu.Length > 128 ||
                Veritabani.Length == 0 || Veritabani.Length > 128 ||
                (Rol != "Ana" && Rol != "Yan") ||
                (KimlikDogrulama != "Windows" && KimlikDogrulama != "Sql"))
                throw new ArgumentException("Sunucu, veritabanı, rol ve kimlik doğrulama bilgilerini kontrol edin.");
            _ = BaglantiDizesi();
            System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(Dosya)!);
            string gecici = Dosya + ".tmp";
            System.IO.File.WriteAllText(gecici,
                System.Text.Json.JsonSerializer.Serialize(this,
                    new System.Text.Json.JsonSerializerOptions { WriteIndented = true }),
                System.Text.Encoding.UTF8);
            System.IO.File.Move(gecici, Dosya, true);
        }

        public string BaglantiDizesi()
        {
            if(BaglantiZamanAsimi<3||BaglantiZamanAsimi>120)throw new ArgumentException("Bağlantı zaman aşımı 3–120 saniye olmalı.");
            string source=Sunucu;
            if(UzakVpn){var endpoint=UzakCalismaGuvenligi.VpnSqlHedefi(Sunucu);source=$"tcp:{endpoint.Ip},{endpoint.Port}";}
            string certificate=UzakCalismaGuvenligi.SertifikaAdi(SertifikaSunucuAdi);
            var olusturucu = new Microsoft.Data.SqlClient.SqlConnectionStringBuilder
            {
                DataSource = source,
                InitialCatalog = Veritabani,
                Encrypt = Microsoft.Data.SqlClient.SqlConnectionEncryptOption.Mandatory,
                TrustServerCertificate = !UzakVpn&&!SertifikaDogrula,
                ConnectTimeout = UzakVpn?Math.Max(15,BaglantiZamanAsimi):BaglantiZamanAsimi,
                ApplicationName = "MiapaxERP Desktop"
            };
            if(certificate.Length>0)olusturucu.HostNameInCertificate=certificate;
            if (KimlikDogrulama == "Sql")
            {
                if (string.IsNullOrWhiteSpace(SqlKullanici) || string.IsNullOrEmpty(SifreliSqlParola))
                    throw new ArgumentException("SQL kullanıcı adı ve parola zorunludur.");
                olusturucu.IntegratedSecurity = false;
                olusturucu.UserID = SqlKullanici;
                olusturucu.Password = ParolayiCoz();
            }
            else if (KimlikDogrulama == "Windows")
            {
                olusturucu.IntegratedSecurity = true;
            }
            else throw new ArgumentException("Bilinmeyen kimlik doğrulama yöntemi.");
            return olusturucu.ConnectionString;
        }

        public static string BaglantiAdresi() => HttpsOturumu.Istemci is not null ? HttpsOturumu.Baglanti : Oku().BaglantiDizesi();
    }

    // Windows DPAPI: Aynı Windows kullanıcısına özgü şifrelenmiş salt-okunur tablolar.
    // Kullanıcıya özel SQL yetkisi online doğrulanmadan asla yeni tablo indirilemez.
    internal static class MiapaxERPYerelKopya
    {
        [StructLayout(LayoutKind.Sequential)]
        private struct VeriBlogu
        {
            public int Boyut;
            public IntPtr Adres;
        }

        [DllImport("crypt32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool CryptProtectData(ref VeriBlogu giris, string? aciklama,
            IntPtr entropi, IntPtr ayrilmis, IntPtr istem, int bayraklar, out VeriBlogu cikis);

        [DllImport("crypt32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool CryptUnprotectData(ref VeriBlogu giris, IntPtr aciklama,
            IntPtr entropi, IntPtr ayrilmis, IntPtr istem, int bayraklar, out VeriBlogu cikis);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr LocalFree(IntPtr bellek);

        private static byte[] Koru(byte[] kaynak, bool sifrele)
        {
            IntPtr giris = Marshal.AllocHGlobal(kaynak.Length);
            try
            {
                Marshal.Copy(kaynak, 0, giris, kaynak.Length);
                var kaynakBlogu = new VeriBlogu { Adres = giris, Boyut = kaynak.Length };
                VeriBlogu sonuc;
                bool basarili = sifrele
                    ? CryptProtectData(ref kaynakBlogu, "MiapaxERP offline snapshot", IntPtr.Zero,
                        IntPtr.Zero, IntPtr.Zero, 0x01, out sonuc)
                    : CryptUnprotectData(ref kaynakBlogu, IntPtr.Zero, IntPtr.Zero,
                        IntPtr.Zero, IntPtr.Zero, 0x01, out sonuc);
                if (!basarili) throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
                try
                {
                    var bytes = new byte[sonuc.Boyut];
                    Marshal.Copy(sonuc.Adres, bytes, 0, sonuc.Boyut);
                    return bytes;
                }
                finally { if (sonuc.Adres != IntPtr.Zero) LocalFree(sonuc.Adres); }
            }
            finally { Marshal.FreeHGlobal(giris); }
        }

        private static string YoluBul(string baglanti, int kullaniciId, string kategori)
        {
            if (kategori != "Stok" && kategori != "Uretim" && kategori != "Recete" &&
                kategori != "Cari" && kategori != "Odeme" && kategori != "CekSenet")
                throw new ArgumentException("Bilinmeyen yerel veri türü.");
            byte[] kimlik = SHA256.HashData(Encoding.UTF8.GetBytes(baglanti + "|" + kullaniciId));
            string klasor = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "BoruERP", "Offline", Convert.ToHexString(kimlik));
            return Path.Combine(klasor, kategori + ".dpapi");
        }

        public static void Kaydet(string baglanti, int kullaniciId, string kategori, DataTable veri)
        {
            var ds = new DataSet("BoruERP");
            var kopya = veri.Copy();
            kopya.TableName = "Kayitlar";
            ds.Tables.Add(kopya);
            using var akis = new MemoryStream();
            ds.WriteXml(akis, XmlWriteMode.WriteSchema);
            string icerik = DateTime.UtcNow.ToString("O") + "\n" + Convert.ToBase64String(akis.ToArray());
            byte[] sifreli = Koru(Encoding.UTF8.GetBytes(icerik), true);
            string yol = YoluBul(baglanti, kullaniciId, kategori);
            Directory.CreateDirectory(Path.GetDirectoryName(yol)!);
            string gecici = yol + ".tmp";
            File.WriteAllBytes(gecici, sifreli);
            File.Move(gecici, yol, true);
        }

        public static void Sil(string baglanti, int kullaniciId, string kategori)
        {
            try
            {
                string yol = YoluBul(baglanti, kullaniciId, kategori);
                if (File.Exists(yol)) File.Delete(yol);
            }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }

        public static (DateTime Alinma, DataTable Veri)? Oku(string baglanti, int kullaniciId,
            string kategori)
        {
            try
            {
                string yol = YoluBul(baglanti, kullaniciId, kategori);
                if (!File.Exists(yol)) return null;
                string icerik = Encoding.UTF8.GetString(Koru(File.ReadAllBytes(yol), false));
                int bol = icerik.IndexOf('\n');
                if (bol < 0 || !DateTime.TryParse(icerik[..bol], null,
                    System.Globalization.DateTimeStyles.RoundtripKind, out DateTime zaman)) return null;
                // Çevrimdışı izinler sonsuza kadar geçerli sayılmaz.
                if (zaman > DateTime.UtcNow.AddMinutes(5) ||
                    zaman < DateTime.UtcNow.AddDays(-7)) return null;
                using var akis = new MemoryStream(Convert.FromBase64String(icerik[(bol + 1)..]));
                var ds = new DataSet();
                ds.ReadXml(akis, XmlReadMode.ReadSchema);
                return ds.Tables.Count == 0 ? null : (zaman.ToLocalTime(), ds.Tables[0]);
            }
            catch (Exception) { return null; } // Bozuk kopya oturumu veya uygulamayı durdurmaz.
        }
    }
}
