using System;
using System.Windows;

namespace MiapaxERP.Desktop
{
    public partial class MainWindow
    {
        private void VeriAraclari_Click(object sender, RoutedEventArgs e)
        {
            if (DemoModu)
            {
                MessageBox.Show("Excel toplu işlemleri şu an SQL Server modunda destekleniyor.", "MiapaxERP");
                return;
            }
            if (aktifKullanici == null)
            {
                MessageBox.Show("Önce hesabınızla giriş yapın.", "MiapaxERP");
                return;
            }
            var pencere = new ExcelVeYazdirmaPenceresi(baglantiAdresi, aktifKullanici.KullaniciId)
            {
                Owner = this
            };
            pencere.ShowDialog();
            // Değişen stok kayıtlarını oturumun yetkileriyle yeniden oku.
            if (StokYetkisiVar("STOCK.VIEW")) StokEkraniniAc();
        }
    }
}
