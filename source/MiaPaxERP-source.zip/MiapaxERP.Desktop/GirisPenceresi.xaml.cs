using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.Data;
using System.Security.Cryptography;
using System.Threading.Tasks;
using System.Windows;
using Microsoft.Data.SqlClient;

namespace MiapaxERP.Desktop
{
    /// <summary>
    /// Oturumu doğrular ve kullanıcının profil bilgilerini sağlar.
    /// Modül bazlı işlem yetkileri sonraki adımdadır.
    /// </summary>
    public sealed class KullaniciOturumu
    {
        public int KullaniciId { get; init; }
        public string KullaniciAdi { get; init; } = "";
        public string AdSoyad { get; init; } = "";
        public string Roller { get; init; } = "Rol atanmadı";
    }

    public partial class GirisPenceresi : Window
    {
        private readonly string baglantiAdresi;
        private GirisKontrolSonucu? sifreDegistirecekKullanici;
        private bool pencereKapandi;

        protected override void OnClosed(EventArgs e)
        {
            pencereKapandi = true;
            base.OnClosed(e);
        }
        public KullaniciOturumu? Oturum { get; private set; }

        private sealed class GirisKontrolSonucu
        {
            public bool Basarili { get; init; }
            public string Mesaj { get; init; } = "";
            public int Id { get; init; }
            public string KullaniciAdi { get; init; } = "";
            public string AdSoyad { get; init; } = "";
            public string Roller { get; init; } = "";
            public string EskiSifreOzeti { get; init; } = "";
            public bool SifreDegistirmeli { get; init; }
        }

        public GirisPenceresi(string sqlBaglantiAdresi)
        {
            baglantiAdresi = sqlBaglantiAdresi;
            InitializeComponent();
            Loaded += (_, _) => TxtKullaniciAdi.Focus();
            BtnGiris.IsEnabled = false;
            BtnKayitAc.IsEnabled = false;
            Loaded += IlkYoneticiDurumunuKontrolEt;
        }

        private void AgBaglantiAyarlari_Click(object sender, RoutedEventArgs e)
        {
            new BaglantiAyarlariPenceresi { Owner = this }.ShowDialog();
            TxtGirisDurum.Text = "Bağlantı ayarlarını değiştirdiyseniz MiapaxERP’u kapatıp yeniden açın.";
        }

        internal static bool SifreDogrula(string sifre, string ozet)
        {
            try
            {
                // Kullanıcı Yönetimi Adım 3 ile AYNI Identity V3 PBKDF2-SHA512 biçimi.
                byte[] veri = Convert.FromBase64String(ozet);
                if (veri.Length != 61 || veri[0] != 0x01) return false;
                uint prf = BinaryPrimitives.ReadUInt32BigEndian(veri.AsSpan(1, 4));
                uint iterasyon = BinaryPrimitives.ReadUInt32BigEndian(veri.AsSpan(5, 4));
                uint tuzBoyutu = BinaryPrimitives.ReadUInt32BigEndian(veri.AsSpan(9, 4));
                if (prf != 2 || iterasyon < 10000 || iterasyon > 1000000 || tuzBoyutu != 16) return false;
                byte[] tuz = veri.AsSpan(13, 16).ToArray();
                byte[] beklenen = veri.AsSpan(29, 32).ToArray();
                byte[] hesaplanan = Rfc2898DeriveBytes.Pbkdf2(sifre, tuz, (int)iterasyon,
                    HashAlgorithmName.SHA512, 32);
                return CryptographicOperations.FixedTimeEquals(beklenen, hesaplanan);
            }
            catch (FormatException) { return false; }
            catch (CryptographicException) { return false; }
        }

        internal static string SifreOzetiOlustur(string sifre)
        {
            const int iterasyon = 310000;
            byte[] tuz = RandomNumberGenerator.GetBytes(16);
            byte[] anahtar = Rfc2898DeriveBytes.Pbkdf2(sifre, tuz, iterasyon,
                HashAlgorithmName.SHA512, 32);
            byte[] veri = new byte[13 + tuz.Length + anahtar.Length];
            veri[0] = 0x01;
            BinaryPrimitives.WriteUInt32BigEndian(veri.AsSpan(1, 4), 2);
            BinaryPrimitives.WriteUInt32BigEndian(veri.AsSpan(5, 4), iterasyon);
            BinaryPrimitives.WriteUInt32BigEndian(veri.AsSpan(9, 4), (uint)tuz.Length);
            tuz.CopyTo(veri, 13);
            anahtar.CopyTo(veri, 13 + tuz.Length);
            return Convert.ToBase64String(veri);
        }

        private static string RolleriOku(SqlConnection baglanti, int id)
        {
            var roller = new List<string>();
            using var komut = new SqlCommand(@"
SELECT r.RolAdi
FROM dbo.KullaniciRolAtamalari a
JOIN dbo.KullaniciRolleri r ON r.Id=a.RolId
WHERE a.KullaniciId=@Id AND r.Aktif=1 ORDER BY r.RolAdi;", baglanti);
            komut.Parameters.Add("@Id", SqlDbType.Int).Value = id;
            using var okuyucu = komut.ExecuteReader();
            while (okuyucu.Read()) roller.Add(okuyucu.GetString(0));
            return roller.Count == 0 ? "Rol atanmadı" : string.Join(", ", roller);
        }

        private GirisKontrolSonucu GirisiDogrula(string kullaniciAdi, string sifre)
        {
            const string genelHata = "Kullanıcı adı veya şifre hatalı ya da hesabınız kullanılamıyor.";
            using var baglanti = new SqlConnection(baglantiAdresi);
            baglanti.Open();
            int id;
            string kayitliAd;
            string adSoyad;
            string sifreOzeti;
            bool aktif;
            bool sifreDegistirmeli;
            DateTime? kilitBitis;
            using (var komut = new SqlCommand(@"
SELECT TOP(1) Id, KullaniciAdi, AdSoyad, SifreOzeti, Aktif, SifreDegistirmeli, KilitBitisUtc
FROM dbo.Kullanicilar WHERE KullaniciAdi=@Adi;", baglanti))
            {
                komut.Parameters.Add("@Adi", SqlDbType.NVarChar, 60).Value = kullaniciAdi;
                using var okuyucu = komut.ExecuteReader();
                if (!okuyucu.Read()) return new GirisKontrolSonucu { Mesaj = genelHata };
                id = okuyucu.GetInt32(0);
                kayitliAd = okuyucu.GetString(1);
                adSoyad = okuyucu.GetString(2);
                sifreOzeti = okuyucu.GetString(3);
                aktif = okuyucu.GetBoolean(4);
                sifreDegistirmeli = okuyucu.GetBoolean(5);
                kilitBitis = okuyucu.IsDBNull(6) ? null : okuyucu.GetDateTime(6);
            }
            if (!aktif || (kilitBitis.HasValue && kilitBitis.Value > DateTime.UtcNow))
                return new GirisKontrolSonucu { Mesaj = genelHata };

            if (!SifreDogrula(sifre, sifreOzeti))
            {
                // Beş başarısız denemede 15 dakika kilitle; eski kilit bittiyse sayaç sıfırdan başlar.
                using var hatali = new SqlCommand(@"
UPDATE dbo.Kullanicilar
SET BasarisizGirisSayisi = CASE WHEN KilitBitisUtc IS NOT NULL
       AND KilitBitisUtc <= SYSUTCDATETIME() THEN 1 ELSE BasarisizGirisSayisi + 1 END,
    KilitBitisUtc = CASE WHEN
       (CASE WHEN KilitBitisUtc IS NOT NULL AND KilitBitisUtc <= SYSUTCDATETIME()
          THEN 1 ELSE BasarisizGirisSayisi + 1 END) >= 5
       THEN DATEADD(MINUTE, 15, SYSUTCDATETIME()) ELSE NULL END
WHERE Id=@Id AND Aktif=1;", baglanti);
                hatali.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                hatali.ExecuteNonQuery();
                return new GirisKontrolSonucu { Mesaj = genelHata };
            }

            string roller = RolleriOku(baglanti, id);
            if (!sifreDegistirmeli)
            {
                using var komut = new SqlCommand(@"
UPDATE dbo.Kullanicilar SET BasarisizGirisSayisi=0, KilitBitisUtc=NULL,
SonGirisUtc=SYSUTCDATETIME()
WHERE Id=@Id AND Aktif=1 AND SifreDegistirmeli=0 AND SifreOzeti=@Ozet
  AND (KilitBitisUtc IS NULL OR KilitBitisUtc <= SYSUTCDATETIME());", baglanti);
                komut.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                komut.Parameters.Add("@Ozet", SqlDbType.NVarChar, 512).Value = sifreOzeti;
                if (komut.ExecuteNonQuery() != 1)
                    return new GirisKontrolSonucu { Mesaj = "Hesap bilgileri değişti. Lütfen yeniden deneyin." };
            }
            return new GirisKontrolSonucu
            {
                Basarili = true,
                Id = id,
                KullaniciAdi = kayitliAd,
                AdSoyad = adSoyad,
                Roller = roller,
                EskiSifreOzeti = sifreOzeti,
                SifreDegistirmeli = sifreDegistirmeli
            };
        }

        private async void Giris_Click(object sender, RoutedEventArgs e)
        {
            string kullaniciAdi = TxtKullaniciAdi.Text.Trim();
            string sifre = PwdSifre.Password;
            if (kullaniciAdi.Length == 0 || sifre.Length == 0)
            {
                TxtGirisDurum.Text = "Kullanıcı adı ve şifre girin.";
                return;
            }
            BtnGiris.IsEnabled = false;
            TxtGirisDurum.Text = "Hesap kontrol ediliyor...";
            try
            {
                GirisKontrolSonucu sonuc = await Task.Run(() => GirisiDogrula(kullaniciAdi, sifre));
                if (pencereKapandi) return;
                if (!sonuc.Basarili)
                {
                    TxtGirisDurum.Text = sonuc.Mesaj;
                    return;
                }
                if (sonuc.SifreDegistirmeli)
                {
                    sifreDegistirecekKullanici = sonuc;
                    GirisPaneli.Visibility = Visibility.Collapsed;
                    SifreDegistirPaneli.Visibility = Visibility.Visible;
                    PwdYeniSifre.Focus();
                    return;
                }
                // İlk girişte / kurtarma kodları henüz teslim edilmemişse zorunlu kod ekranı.
                KurtarmaKodPaketi? kodPaketi = await Task.Run(() =>
                    GiristeKurtarmaKodlariniHazirla(sonuc.Id,baglantiAdresi));
                if (pencereKapandi) return;
                if (kodPaketi != null && !KurtarmaKodlariniGosterVeOnayla(sonuc.Id, kodPaketi))
                {
                    TxtGirisDurum.Text = "Kodlar onaylanmadı. Tekrar giriş yaptığınızda yeni kodlar üretilecek.";
                    return;
                }
                if (ChkBeniHatirla.IsChecked == true)
                    await HatirlananOturumuKaydetAsync(sonuc);
                OturumuTamamla(sonuc);
            }
            catch (Exception hata)
            {
                if (!pencereKapandi) TxtGirisDurum.Text = "Giriş kontrolü yapılamadı: " + hata.Message;
            }
            finally
            {
                sifre = "";
                if (!pencereKapandi)
                {
                    PwdSifre.Clear();
                    BtnGiris.IsEnabled = true;
                }
            }
        }

        // Şifre değişimi ve kurtarma kodu oluşturma tek SQL işlemi içinde tamamlanır.
        private KurtarmaKodPaketi? IlkSifreyiDegistir(GirisKontrolSonucu kullanici, string yeniSifre)
        {
            string yeniOzet = SifreOzetiOlustur(yeniSifre);
            using var baglanti = new SqlConnection(baglantiAdresi);
            baglanti.Open();
            using var islem = baglanti.BeginTransaction(IsolationLevel.Serializable);
            try
            {
                using var komut = new SqlCommand(@"
UPDATE dbo.Kullanicilar
SET SifreOzeti=@YeniOzet, SifreDegistirmeli=0,
    BasarisizGirisSayisi=0, KilitBitisUtc=NULL,
    SonGirisUtc=SYSUTCDATETIME(), GuncellemeTarihiUtc=SYSUTCDATETIME()
WHERE Id=@Id AND Aktif=1 AND SifreOzeti=@EskiOzet AND SifreDegistirmeli=1
  AND (KilitBitisUtc IS NULL OR KilitBitisUtc <= SYSUTCDATETIME());", baglanti, islem);
                komut.Parameters.Add("@Id", SqlDbType.Int).Value = kullanici.Id;
                komut.Parameters.Add("@EskiOzet", SqlDbType.NVarChar, 512).Value = kullanici.EskiSifreOzeti;
                komut.Parameters.Add("@YeniOzet", SqlDbType.NVarChar, 512).Value = yeniOzet;
                if (komut.ExecuteNonQuery() != 1)
                {
                    islem.Rollback();
                    return null;
                }
                KurtarmaKodPaketi paket = KurtarmaKodlariniUret(baglanti, islem, kullanici.Id);
                islem.Commit();
                return paket;
            }
            catch
            {
                try { islem.Rollback(); } catch { /* İşlem sunucu tarafında kapanmış olabilir. */ }
                throw;
            }
        }

        private async void SifreDegistir_Click(object sender, RoutedEventArgs e)
        {
            if (sifreDegistirecekKullanici == null) return;
            string yeni = PwdYeniSifre.Password;
            string tekrar = PwdYeniTekrar.Password;
            if (yeni.Length < 12 || yeni.Length > 128)
            {
                TxtSifreDegistirDurum.Text = "Şifre 12-128 karakter arasında olmalı.";
                return;
            }
            if (yeni != tekrar)
            {
                TxtSifreDegistirDurum.Text = "Yeni şifreler aynı değil.";
                return;
            }
            if (SifreDogrula(yeni, sifreDegistirecekKullanici.EskiSifreOzeti))
            {
                TxtSifreDegistirDurum.Text = "Yeni şifre eski şifreden farklı olmalı.";
                return;
            }
            BtnSifreDegistir.IsEnabled = false;
            TxtSifreDegistirDurum.Text = "Şifre güvenli şekilde güncelleniyor...";
            try
            {
                GirisKontrolSonucu kullanici = sifreDegistirecekKullanici;
                KurtarmaKodPaketi? paket = await Task.Run(() => IlkSifreyiDegistir(kullanici, yeni));
                if (pencereKapandi) return;
                if (paket == null)
                {
                    TxtSifreDegistirDurum.Text = "Hesap bilgileri değişti. Giriş ekranından tekrar deneyin.";
                    return;
                }
                // Şifre ekranını kapatıp ayrı ÖNEMLİ penceresinde kodları göster.
                if (!KurtarmaKodlariniGosterVeOnayla(kullanici.Id, paket))
                {
                    sifreDegistirecekKullanici = null;
                    SifreDegistirPaneli.Visibility = Visibility.Collapsed;
                    GirisPaneli.Visibility = Visibility.Visible;
                    TxtGirisDurum.Text = "Şifreniz değişti. Kurtarma kodlarını onaylamak için yeni şifrenizle tekrar girin.";
                    return;
                }
                OturumuTamamla(kullanici);
            }
            catch (Exception hata)
            {
                if (!pencereKapandi) TxtSifreDegistirDurum.Text = "Şifre değiştirilemedi: " + hata.Message;
            }
            finally
            {
                yeni = "";
                tekrar = "";
                if (!pencereKapandi)
                {
                    PwdYeniSifre.Clear();
                    PwdYeniTekrar.Clear();
                    BtnSifreDegistir.IsEnabled = true;
                }
            }
        }


        // Bu hesap SADECE tamamen boş ve daha önce kurulumu tamamlanmamış DB'de açılır.
        // Gerçek müşteri kurulumu için kurulum paketinde daha güvenli parolalı ilk-kurulum önerilir.
        private async void IlkYoneticiDurumunuKontrolEt(object sender, RoutedEventArgs e)
        {
            BtnGiris.IsEnabled = false;
            BtnKayitAc.IsEnabled = false;
            BtnIlkYonetici.Visibility = Visibility.Collapsed;
            TxtGirisDurum.Text = "İlk kurulum kontrol ediliyor...";
            try
            {
                bool olusturuldu = await Task.Run(IlkAdminHesabiniGerekirseOlustur);
                if (pencereKapandi) return;
                TxtGirisDurum.Text = olusturuldu
                    ? "İlk kurulum hazır. Kullanıcı: Admin • Geçici şifre: 1234. Girişte şifre değişikliği zorunludur."
                    : "";
                BtnGiris.IsEnabled = true;
                BtnKayitAc.IsEnabled = true;
                await OtomatikGirisDeneAsync();
            }
            catch (Exception hata)
            {
                if (pencereKapandi) return;
                TxtGirisDurum.Text = "İlk kurulum kontrolü başarısız: " + hata.Message +
                    "  Önce SQL kurtarma altyapısı dosyasını uygulayın. Giriş güvenlik nedeniyle kapalı.";
                BtnGiris.IsEnabled = false;
                BtnKayitAc.IsEnabled = false;
            }
        }

        // Mevcut XAML olay bağlantısı korunur; ilk yönetici artık otomatik hazırlanır.
        private void IlkYonetici_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("İlk yönetici hesabı boş kurulumda otomatik açılır.\n" +
                            "Giriş: Admin / 1234. İlk girişte şifrenizi değiştirmelisiniz.",
                "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void KayitAc_Click(object sender, RoutedEventArgs e)
        {
            GirisPaneli.Visibility = Visibility.Collapsed;
            SifreDegistirPaneli.Visibility = Visibility.Collapsed;
            KayitPaneli.Visibility = Visibility.Visible;
            TxtKayitAd.Focus();
        }

        private void KayitGeri_Click(object sender, RoutedEventArgs e)
        {
            KayitPaneli.Visibility = Visibility.Collapsed;
            GirisPaneli.Visibility = Visibility.Visible;
            PwdKayit.Clear();
            PwdKayitTekrar.Clear();
            TxtKayitTc.Clear();
            TxtKullaniciAdi.Focus();
        }

        private static bool TcKimlikGecerliMi(string tc)
        {
            if (tc.Length != 11 || tc[0] == '0') return false;
            foreach (char karakter in tc)
                if (karakter < '0' || karakter > '9') return false;
            int[] hane = new int[11];
            for (int i = 0; i < 11; i++) hane[i] = tc[i] - '0';
            int tek = hane[0] + hane[2] + hane[4] + hane[6] + hane[8];
            int cift = hane[1] + hane[3] + hane[5] + hane[7];
            if (((tek * 7 - cift) % 10 + 10) % 10 != hane[9]) return false;
            int toplam = 0;
            for (int i = 0; i < 10; i++) toplam += hane[i];
            return toplam % 10 == hane[10];
        }

        private static void YeniKullaniciKaydet(string baglantiDizesi, string ad, string soyad,
            string tc, string kullanici, string sifre)
        {
            // TC numarası sadece doğrulama için kullanılır; SQL'e gönderilmez veya diske yazılmaz.
            if (!TcKimlikGecerliMi(tc)) throw new InvalidOperationException("TC kimlik numarası geçersiz.");
            string ozet = SifreOzetiOlustur(sifre);
            using var baglanti = new SqlConnection(baglantiDizesi);
            baglanti.Open();
            using var islem = baglanti.BeginTransaction(IsolationLevel.Serializable);
            try
            {
                int rolId;
                using (var komut = new SqlCommand(
                    "SELECT Id FROM dbo.KullaniciRolleri WITH (HOLDLOCK) WHERE RolAdi=N'Kısıtlı Kullanıcı' AND Aktif=1;",
                    baglanti, islem))
                {
                    object? bulunan = komut.ExecuteScalar();
                    if (bulunan == null || bulunan == DBNull.Value)
                        throw new InvalidOperationException("Kısıtlı Kullanıcı rolü yok. Önce SQL güncellemesini uygulayın.");
                    rolId = Convert.ToInt32(bulunan);
                }
                // İlk kullanıcı asla kendi kendine Yönetici olamaz.
                using (var komut = new SqlCommand(@"
SELECT COUNT_BIG(*) FROM dbo.Kullanicilar k WITH (UPDLOCK,HOLDLOCK)
JOIN dbo.KullaniciRolAtamalari a ON a.KullaniciId=k.Id
JOIN dbo.KullaniciRolleri r ON r.Id=a.RolId
WHERE k.Aktif=1 AND r.Aktif=1 AND r.RolAdi=N'Yönetici';", baglanti, islem))
                {
                    if (Convert.ToInt64(komut.ExecuteScalar()) == 0)
                        throw new InvalidOperationException("Önce aktif yönetici hesabını oluşturun.");
                }
                int yeniId;
                using (var komut = new SqlCommand(@"
INSERT INTO dbo.Kullanicilar (KullaniciAdi,AdSoyad,SifreOzeti,Aktif,SifreDegistirmeli)
VALUES(@KullaniciAdi,@AdSoyad,@Ozet,1,0);
SELECT CAST(SCOPE_IDENTITY() AS INT);", baglanti, islem))
                {
                    komut.Parameters.Add("@KullaniciAdi", SqlDbType.NVarChar, 60).Value = kullanici;
                    komut.Parameters.Add("@AdSoyad", SqlDbType.NVarChar, 120).Value = ad + " " + soyad;
                    komut.Parameters.Add("@Ozet", SqlDbType.NVarChar, 512).Value = ozet;
                    yeniId = Convert.ToInt32(komut.ExecuteScalar());
                }
                using (var komut = new SqlCommand(
                    "INSERT INTO dbo.KullaniciRolAtamalari (KullaniciId,RolId) VALUES(@Id,@Rol);", baglanti, islem))
                {
                    komut.Parameters.Add("@Id", SqlDbType.Int).Value = yeniId;
                    komut.Parameters.Add("@Rol", SqlDbType.Int).Value = rolId;
                    komut.ExecuteNonQuery();
                }
                using (var komut = new SqlCommand(@"
INSERT INTO dbo.Bildirimler (AliciKullaniciId,Tur,Baslik,Mesaj,IlgiliKullaniciId)
SELECT DISTINCT k.Id,N'YENI_KULLANICI',N'Yeni kullanıcı başvurusu',
       @Mesaj,@YeniKullaniciId
FROM dbo.Kullanicilar k
INNER JOIN dbo.KullaniciRolAtamalari a ON a.KullaniciId=k.Id
INNER JOIN dbo.KullaniciRolleri r ON r.Id=a.RolId
WHERE k.Aktif=1 AND r.Aktif=1 AND r.RolAdi=N'Yönetici';", baglanti, islem))
                {
                    komut.Parameters.Add("@Mesaj", SqlDbType.NVarChar, 500).Value =
                        ad + " " + soyad + " (" + kullanici + ") kayıt oldu, rol onayı bekliyor.";
                    komut.Parameters.Add("@YeniKullaniciId", SqlDbType.Int).Value = yeniId;
                    komut.ExecuteNonQuery();
                }
                islem.Commit();
            }
            catch
            {
                islem.Rollback();
                throw;
            }
        }

        private async void KayitKaydet_Click(object sender, RoutedEventArgs e)
        {
            string ad = TxtKayitAd.Text.Trim();
            string soyad = TxtKayitSoyad.Text.Trim();
            string tc = TxtKayitTc.Text.Trim();
            string kullanici = TxtKayitKullanici.Text.Trim();
            string sifre = PwdKayit.Password;
            if (ad.Length < 2 || soyad.Length < 2 || kullanici.Length < 3 || kullanici.Length > 60)
            {
                TxtKayitDurum.Text = "Ad ve soyad en az 2, kullanıcı adı en az 3 karakter olmalı.";
                return;
            }
            if (!TcKimlikGecerliMi(tc))
            {
                TxtKayitDurum.Text = "Geçerli, 11 haneli TC kimlik numarası girin.";
                return;
            }
            if (sifre.Length < 12 || sifre.Length > 128 || sifre != PwdKayitTekrar.Password)
            {
                TxtKayitDurum.Text = "Şifreler aynı ve en az 12 karakter olmalı.";
                return;
            }
            BtnKayitKaydet.IsEnabled = false;
            TxtKayitDurum.Text = "Kayıt oluşturuluyor...";
            try
            {
                await Task.Run(() => YeniKullaniciKaydet(baglantiAdresi, ad, soyad, tc, kullanici, sifre));
                if (pencereKapandi) return;
                TxtKullaniciAdi.Text = kullanici;
                TxtGirisDurum.Text = "Kayıt tamamlandı. Giriş yapabilirsiniz; yönetici rol atayıncaya kadar yetkileriniz sınırlıdır.";
                KayitGeri_Click(sender, e);
            }
            catch (SqlException hata) when (hata.Number == 2601 || hata.Number == 2627)
            {
                if (!pencereKapandi) TxtKayitDurum.Text = "Bu kullanıcı adı zaten kullanımda.";
            }
            catch (Exception hata)
            {
                if (!pencereKapandi) TxtKayitDurum.Text = "Kayıt yapılamadı: " + hata.Message;
            }
            finally
            {
                sifre = "";
                tc = "";
                if (!pencereKapandi)
                {
                    BtnKayitKaydet.IsEnabled = true;
                    PwdKayit.Clear();
                    PwdKayitTekrar.Clear();
                    TxtKayitTc.Clear();
                }
            }
        }

        private void OturumuTamamla(GirisKontrolSonucu sonuc)
        {
            Oturum = new KullaniciOturumu
            {
                KullaniciId = sonuc.Id,
                KullaniciAdi = sonuc.KullaniciAdi,
                AdSoyad = sonuc.AdSoyad,
                Roller = sonuc.Roller
            };
            DialogResult = true;
        }

    }
}
