SET XACT_ABORT ON;
BEGIN TRANSACTION;
DECLARE @lock181 int;
EXEC @lock181=sys.sp_getapplock @Resource=N'MiapaxERP.Moduller180',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=15000;
IF @lock181<0 THROW 51000,N'Kurulum kilidi alınamadı.',1;
IF NOT EXISTS(SELECT 1 FROM dbo.BERP_Sema WHERE Surum=181)
BEGIN
    DECLARE @constraint181 sysname,@ddl181 nvarchar(max);
    DECLARE module_checks181 CURSOR LOCAL FAST_FORWARD FOR
        SELECT name FROM sys.check_constraints
        WHERE parent_object_id=OBJECT_ID(N'dbo.BERP_TicaretDosya') AND CHARINDEX(N'Modul',definition)>0;
    OPEN module_checks181;FETCH NEXT FROM module_checks181 INTO @constraint181;
    WHILE @@FETCH_STATUS=0
    BEGIN
        SET @ddl181=N'ALTER TABLE dbo.BERP_TicaretDosya DROP CONSTRAINT '+QUOTENAME(@constraint181);
        EXEC sys.sp_executesql @ddl181;
        FETCH NEXT FROM module_checks181 INTO @constraint181;
    END;
    CLOSE module_checks181;DEALLOCATE module_checks181;
    ALTER TABLE dbo.BERP_TicaretDosya WITH CHECK ADD CONSTRAINT CK_BERP_Modul181
        CHECK(Modul IN ('CRM','ECOM','TRADE','SALES','PURCHASE'));
    INSERT dbo.BERP_Sema(Surum) VALUES(181);
END;
COMMIT;
