using System.Data;
using System.Text.Json;
using Microsoft.Data.SqlClient;

namespace MiapaxERP.Desktop;

public record IsAkisi(string Ad,string[] Turler,string[] Adimlar,string[] Alanlar,string Sonuc)
{
    public static IsAkisi Getir(string kod) => kod switch
    {
        "SALES" => new("Satış operasyonları",["Satış teklifi","Müşteri siparişi","Hizmet satışı"],["Taslak","Teklif gönderildi","Onaylandı","Hazırlanıyor","Sevk edildi","Faturalandı","Kapandı"],["Müşteri kodu","Vergi no","Yetkili kişi","Telefon","E-posta","Teslimat adresi","Ödeme koşulu","Teklif geçerlilik tarihi","Depo","İrsaliye no","Fatura numarası","Kargo firması","Takip numarası"],"İptal edildi"),
        "PURCHASE" => new("Satın alma operasyonları",["Satın alma talebi","Tedarikçi teklifi","Satın alma siparişi"],["Talep","Teklif toplama","Onaylandı","Sipariş verildi","Mal kabul","Faturalandı","Kapandı"],["Tedarikçi kodu","Vergi no","Yetkili kişi","Telefon","E-posta","Teslimat adresi","Ödeme koşulu","İhtiyaç tarihi","Depo","Mal kabul belgesi","Fatura numarası","Alternatif tedarikçi","Alternatif teklif tutarı","Seçim gerekçesi"],"İptal edildi"),
        "CRM" => new("CRM",["Satış fırsatı","Müşteri adayı","Yenileme"],["Aday","Görüşme","Teklif","Müzakere","Kazanıldı"],["Yetkili kişi","E-posta","Telefon","Kaynak / kampanya","Sektör","Ürün / hizmet","Sonraki görüşme konusu","Kazanma olasılığı (%)"],"Kaybedildi"),
        "ECOM" => new("E-ticaret",["Mağaza siparişi","Pazaryeri siparişi","B2B sipariş"],["Yeni sipariş","Ödeme onaylandı","Hazırlanıyor","Kargoda","Teslim edildi","Tamamlandı"],["Kanal / mağaza","Ürünler ve adetleri","Ödeme yöntemi","Teslimat adresi","Kargo firması","Takip numarası","Fatura numarası","Komisyon","Kargo gideri","Ürün maliyeti"],"İade edildi"),
        "TRADE" => new("Dış ticaret",["İhracat","İthalat","Transit ticaret"],["Hazırlık","Belgeler hazır","Sevkiyat","Gümrük","Teslim edildi","Kapandı"],["Menşe ülkesi","Varış ülkesi","Mal tanımı / miktar","GTİP","Teslim şekli","Taşıma türü","Nakliyeci","Konteyner / konşimento","Beyanname no","Proforma / fatura","Navlun","Sigorta","Gümrük masrafı"],"İptal edildi"),
        _ => throw new ArgumentException("Modül bulunamadı.")
    };
    public string[] Sonrakiler(string durum)
    {
        int i=Array.IndexOf(Adimlar,durum);
        if(i<0)return [];
        if(i==Adimlar.Length-1)return Ad=="E-ticaret"?[Sonuc]:[];
        return [Adimlar[i+1],Sonuc];
    }
}

public record TicaretGirdi(string Referans,string Tur,string Firma,string Baslik,string Sorumlu,
    DateTime Tarih,DateTime Vade,decimal Tutar,string Doviz,Dictionary<string,string> Detay,string Aciklama);

public sealed partial class TicaretDosyalari(string connection,int user,string modul)
{
    readonly ErpModulServisi access=new(connection,user);
    public IsAkisi Akis {get;}=IsAkisi.Getir(modul);
    public DataTable Liste(){if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"TicaretDosyalari.Liste",modul,new object?[]{});}return Oku("SELECT Id,Referans,Tur,Firma,Baslik,Sorumlu,Tarih,Vade,Tutar,Doviz,Durum,Aciklama,Detay,Surum FROM dbo.BERP_TicaretDosya WHERE Modul=@m ORDER BY Id DESC");}
    public DataTable Gecmis(long id){if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"TicaretDosyalari.Gecmis",modul,new object?[]{id});}return Oku("SELECT o.Zaman,o.KullaniciId,o.Olay FROM dbo.BERP_TicaretOlay o JOIN dbo.BERP_TicaretDosya d ON d.Id=o.DosyaId WHERE d.Modul=@m AND d.Id=@id ORDER BY o.Id DESC",id);}
    DataTable Oku(string sql,long id=0)
    {
        using var c=access.Ac();
        access.Yetki(c,null,modul+".VIEW");
        using var q=ErpModulServisi.Komut(c,null,sql,("@m",modul),("@id",id));
        using var r=q.ExecuteReader();
        var t=new DataTable();t.Load(r);return t;
    }
    void Olay(SqlConnection c,SqlTransaction tx,long id,string mesaj)
    {
        using var q=ErpModulServisi.Komut(c,tx,"INSERT dbo.BERP_TicaretOlay(DosyaId,KullaniciId,Olay) VALUES(@id,@u,@a)",("@id",id),("@u",user),("@a",mesaj));q.ExecuteNonQuery();
    }
    public decimal AnalizTutari(decimal tutar,Dictionary<string,string> detay)
    {
        decimal Deger(string ad)
        {
            if(!detay.TryGetValue(ad,out var metin)||string.IsNullOrWhiteSpace(metin))return 0;
            if(!decimal.TryParse(metin.Trim().Replace(',','.'),System.Globalization.NumberStyles.AllowDecimalPoint,
                System.Globalization.CultureInfo.InvariantCulture,out decimal n)||n<0)
                throw new ArgumentException(ad+" için sıfır veya pozitif sayı girin.");
            return n;
        }
        if(modul=="CRM")
        {
            decimal oran=Deger("Kazanma olasılığı (%)");
            if(oran>100)throw new ArgumentException("Olasılık %100'ü aşamaz.");
            return decimal.Round(tutar*oran/100,2);
        }
        if(modul=="ECOM")return tutar-Deger("Komisyon")-Deger("Kargo gideri")-Deger("Ürün maliyeti");
        if(modul is "SALES" or "PURCHASE")return tutar;
        return tutar+Deger("Navlun")+Deger("Sigorta")+Deger("Gümrük masrafı");
    }
    public long Kaydet(TicaretGirdi g,long? id=null,byte[]? surum=null)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"TicaretDosyalari.Kaydet",modul,new object?[]{g,id,surum});}

        Dogrula(g);
        _=AnalizTutari(g.Tutar,g.Detay);
        if(new[]{g.Referans,g.Firma,g.Baslik}.Any(string.IsNullOrWhiteSpace) || g.Vade.Date<g.Tarih.Date || g.Tutar<0 || decimal.Round(g.Tutar,2)!=g.Tutar || g.Doviz is not ("TRY" or "USD" or "EUR" or "GBP") || !Akis.Turler.Contains(g.Tur))
            throw new ArgumentException("Referans, firma ve konu gereklidir. Tarih, para birimi ve tutarı kontrol edin.");
        using var c=access.Ac();using var tx=c.BeginTransaction();
        access.Yetki(c,tx,modul+".EDIT");
        if(!id.HasValue&&modul=="ECOM"&&g.Detay.ContainsKey("Kaynak kimliği"))
        {
            // Her iki site aktarım ekranı aynı işlem kilidi altında kaynak kimliğini denetler.
            using var dupe=ErpModulServisi.Komut(c,tx,"SELECT Detay FROM dbo.BERP_TicaretDosya WITH(UPDLOCK,HOLDLOCK) WHERE Modul=@m",("@m",modul));
            using var rows=dupe.ExecuteReader();while(rows.Read())
            {
                Dictionary<string,string>? detail;try{detail=JsonSerializer.Deserialize<Dictionary<string,string>>(rows.GetString(0));}catch(JsonException){throw new InvalidOperationException("Mevcut sipariş kaynak bilgisi okunamadı; aktarım durduruldu.");}
                if(detail is not null&&WebYonetimi.WebSiparisBelgesi.AyniKaynak(g.Detay,detail))throw new InvalidOperationException("Bu site siparişi daha önce ERP'ye aktarılmış. Mevcut e-ticaret dosyasını açın.");
            }
        }
        if(id.HasValue)
        {
            using var state=ErpModulServisi.Komut(c,tx,"SELECT Durum FROM dbo.BERP_TicaretDosya WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Modul=@m",("@id",id.Value),("@m",modul));
            string current=Convert.ToString(state.ExecuteScalar())??"";
            if(current==Akis.Sonuc || current==Akis.Adimlar[^1])throw new InvalidOperationException("Kapalı dosya değiştirilemez. Yeni referansla düzeltme dosyası açın.");
            if(g.Tutar<NetOdeme(c,tx,id.Value))throw new ArgumentException("Tutar kaydedilmiş net ödemeden düşük olamaz.");
        }
        var sql=id.HasValue ? """
        UPDATE dbo.BERP_TicaretDosya SET Referans=@r,Tur=@tur,Firma=@f,Baslik=@b,Sorumlu=@s,Tarih=@t,Vade=@v,Tutar=@tut,Doviz=@d,Detay=@det,Aciklama=@a
        OUTPUT INSERTED.Id WHERE Id=@id AND Modul=@m AND Surum=@ver
        """ : """
        INSERT dbo.BERP_TicaretDosya(Modul,Referans,Tur,Firma,Baslik,Sorumlu,Tarih,Vade,Tutar,Doviz,Detay,Aciklama,Durum)
        OUTPUT INSERTED.Id VALUES(@m,@r,@tur,@f,@b,@s,@t,@v,@tut,@d,@det,@a,@dur)
        """;
        using var q=ErpModulServisi.Komut(c,tx,sql,("@m",modul),("@r",g.Referans.Trim()),("@tur",g.Tur),("@f",g.Firma.Trim()),("@b",g.Baslik.Trim()),("@s",g.Sorumlu),("@t",g.Tarih),("@v",g.Vade),("@tut",g.Tutar),("@d",g.Doviz),("@det",JsonSerializer.Serialize(g.Detay)),("@a",g.Aciklama),("@dur",Akis.Adimlar[0]));
        if(id.HasValue){q.Parameters.AddWithValue("@id",id.Value);q.Parameters.Add("@ver",SqlDbType.Binary,8).Value=surum??throw new ArgumentException("Kayıt sürümü gerekli.");}
        var key=q.ExecuteScalar()??throw new InvalidOperationException("Kayıt değişmiş. Listeyi yenileyin.");
        long result=Convert.ToInt64(key);Olay(c,tx,result,id.HasValue?"Bilgiler güncellendi":"Dosya açıldı");tx.Commit();return result;
    }
    public void Ilerle(long id,byte[] surum,string eski,string yeni)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"TicaretDosyalari.Ilerle",modul,new object?[]{id,surum,eski,yeni});return;}

        if(!Akis.Sonrakiler(eski).Contains(yeni))throw new ArgumentException("Bu aşamaya geçilemez.");
        using var c=access.Ac();using var tx=c.BeginTransaction();access.Yetki(c,tx,modul+".EDIT");
        if(modul is "SALES" or "PURCHASE")access.Yetki(c,tx,modul+".APPROVE");
        using(var read=ErpModulServisi.Komut(c,tx,"SELECT Detay,Tutar FROM dbo.BERP_TicaretDosya WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Modul=@m",("@id",id),("@m",modul)))
        {
            using var rd=read.ExecuteReader();if(!rd.Read())throw new ArgumentException("Dosya bulunamadı.");
            var details=JsonSerializer.Deserialize<Dictionary<string,string>>(rd.GetString(0))??new();decimal amount=rd.GetDecimal(1);rd.Close();
            GecisDogrula(modul,yeni,details);
            decimal net=NetOdeme(c,tx,id);
            if((yeni=="Kapandı" || yeni=="Tamamlandı") && modul!="CRM" && net!=amount)throw new ArgumentException("Kapatmak için ödeme bakiyesi sıfır olmalı.");
            if(yeni==Akis.Sonuc && net!=0)throw new ArgumentException("İptal / iade öncesinde kayıtlı ödemeleri iade edin.");
        }
        using var q=ErpModulServisi.Komut(c,tx,"UPDATE dbo.BERP_TicaretDosya SET Durum=@y WHERE Id=@id AND Modul=@m AND Surum=@v AND Durum=@e",("@y",yeni),("@id",id),("@m",modul),("@v",surum),("@e",eski));
        if(q.ExecuteNonQuery()!=1)throw new InvalidOperationException("Kayıt değişmiş. Listeyi yenileyin.");
        Olay(c,tx,id,eski+" → "+yeni);tx.Commit();
    }
    public void NotEkle(long id,string not)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"TicaretDosyalari.NotEkle",modul,new object?[]{id,not});return;}

        if(string.IsNullOrWhiteSpace(not)||not.Length>320)throw new ArgumentException("1–320 karakter işlem notu girin.");
        using var c=access.Ac();using var tx=c.BeginTransaction();access.Yetki(c,tx,modul+".EDIT");
        using var q=ErpModulServisi.Komut(c,tx,"SELECT Id FROM dbo.BERP_TicaretDosya WHERE Modul=@m AND Id=@id",("@m",modul),("@id",id));
        if(q.ExecuteScalar()==null)throw new ArgumentException("Dosya bulunamadı.");
        Olay(c,tx,id,not.Trim());tx.Commit();
    }
}
