using System.Runtime.CompilerServices;
[assembly:InternalsVisibleTo("MiapaxERP.Tests.UzakCalisma")]
[assembly:InternalsVisibleTo("MiapaxERP.Tests.HTTPS.Integration")]
