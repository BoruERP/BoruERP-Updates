-- Yalnız eksik görsel tablosunu ekler; mevcut ürün ve fotoğrafları değiştirmez.
SET XACT_ABORT ON;
BEGIN TRANSACTION;
IF OBJECT_ID(N'dbo.UrunGorselleri',N'U') IS NULL
BEGIN
 CREATE TABLE dbo.UrunGorselleri(
 Id int IDENTITY PRIMARY KEY, StokKartId int NOT NULL,
 DosyaAdi nvarchar(255) NOT NULL, IcerikTuru nvarchar(40) NOT NULL,
 GorselVerisi varbinary(max) NOT NULL, KapakMi bit NOT NULL DEFAULT 0,
 SiraNo int NOT NULL DEFAULT 0,
 CONSTRAINT FK_UrunGorselleri_Stok FOREIGN KEY(StokKartId) REFERENCES dbo.StokKartlari(Id));
 CREATE INDEX IX_UrunGorselleri_Stok ON dbo.UrunGorselleri(StokKartId,KapakMi,SiraNo);
END;
COMMIT;
