using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Controls.Primitives;

namespace MiapaxERP.Desktop;

public sealed class GorunumPenceresi : Window
{
    private GorunumTercihleri taslak;
    private readonly string klasor;
    private readonly Action yetkiDogrula;
    private readonly Action<GorunumTercihleri> uygula;
    private readonly ComboBox tema = new(), font = new(), medya = new();
    private readonly ComboBox yerlesim = new(), yogunluk = new(), sutun = new();
    private readonly ComboBox anaDuzen = new();
    private readonly Slider kose = new() { Minimum = -1, Maximum = 28, TickFrequency = 1, IsSnapToTickEnabled = true };
    private readonly CheckBox golge = new() { Content = "Kartlarda yumuşak gölge" };
    private readonly Border mimariOnizleme = new() { Height = 180, Margin = new Thickness(0,12,0,12) };
    private readonly TextBox renk = new();
    private readonly TextBox firmaBasligi = new() { MaxLength = 60 };
    private readonly TextBox firmaMetni=new(){MaxLength=100},firmaAltMetni=new(){MaxLength=100};
    private readonly CheckBox logoGoster=new(){Content="Logoyu göster"},adGoster=new(){Content="Firma adını göster"};
    private readonly Slider logoBoyut=new(){Minimum=30,Maximum=120,TickFrequency=5,IsSnapToTickEnabled=true};
    private readonly ComboBox sektor=new();
    private readonly System.Windows.Controls.ListBox sektorMedya=new(){Height=110};
    private readonly Slider boyut = new() { Minimum = 85, Maximum = 130, TickFrequency = 5, IsSnapToTickEnabled = true };
    private readonly Slider karartma = new() { Minimum = 0, Maximum = 85, TickFrequency = 5, IsSnapToTickEnabled = true };
    private readonly CheckBox oynat = new() { Content = "Arka plan videosunu oynat (sessiz)" };
    private readonly Dictionary<string, CheckBox> kartlar = new();
    private readonly TextBlock dosyaBilgi = new() { TextWrapping = TextWrapping.Wrap }, logoBilgi = new() { TextWrapping = TextWrapping.Wrap };
    private readonly TextBlock ornek = new() { Text = "MiapaxERP • Görünüm önizlemesi", Margin = new Thickness(12) };
    private readonly Border onizleme = new() { CornerRadius = new CornerRadius(8), Margin = new Thickness(0,12,0,12) };
    private readonly System.Windows.Controls.Image logoOnizleme = new() { Height = 70, Stretch = Stretch.Uniform, HorizontalAlignment = System.Windows.HorizontalAlignment.Left };
    private readonly List<string> yeniDosyalar = new();
    private bool kaydedildi, mesgul;
    private readonly StackPanel form = new() { Margin = new Thickness(24), MaxWidth = 850 };

    public GorunumPenceresi(string klasor, GorunumTercihleri mevcut, Action yetkiDogrula, Action<GorunumTercihleri> uygula)
    {
        this.klasor = klasor; taslak = mevcut.Kopya(); this.yetkiDogrula = yetkiDogrula; this.uygula = uygula;
        Title = "Tema ve Ana Sayfa Özelleştirme"; Width = 960; Height = 760; MinWidth = 620; MinHeight = 480;
        WindowStartupLocation = WindowStartupLocation.CenterOwner; SetResourceReference(BackgroundProperty,"ErpZemin"); SetResourceReference(ForegroundProperty,"ErpMetin");
        var root = new DockPanel(); root.SetResourceReference(Panel.BackgroundProperty,"ErpZemin"); Content = root;
        var alt = new WrapPanel { Margin = new Thickness(20), HorizontalAlignment = System.Windows.HorizontalAlignment.Right };
        DockPanel.SetDock(alt, Dock.Bottom); root.Children.Add(alt);
        Buton(alt, "Varsayılanlara dön", (_, _) => { taslak = new(); Doldur(); });
        Buton(alt, "Vazgeç", (_, _) => Close());
        Buton(alt, "Kaydet ve uygula", (_, _) => Kaydet());
        root.Children.Add(new ScrollViewer { Content = form, VerticalScrollBarVisibility = ScrollBarVisibility.Auto });
        Baslik("Görünümünü kendin düzenle");
        Aciklama("Ayarlar bu bilgisayardaki hesabınıza özeldir. Kartları gizlemek kayıtları silmez; erişim yetkileri aynen geçerlidir.");
        Baslik("Tasarım koleksiyonları");
        Aciklama("VIP: geniş kartlar ve altın detaylar. Modern: üst menü. Doğal: ferah ve yumuşak. Eskitme: kâğıt tonları ve sıkı düzen. Kültürel: sağ menü ve çini tonları. Her koleksiyonun düzenini aşağıdan değiştirebilirsiniz.");
        tema.ItemsSource = Tema170.Adlar; Alan("Tema", tema);
        yerlesim.ItemsSource = new[] { "Temaya göre", "Sol menü", "Üst menü", "Sağ menü" }; Alan("Menünün konumu", yerlesim);
        yogunluk.ItemsSource = new[] { "Temaya göre", "Kompakt", "Dengeli", "Ferah" }; Alan("Kart, düğme ve tablo yoğunluğu", yogunluk);
        anaDuzen.ItemsSource = new[] { "Temaya göre", "Takvim odaklı", "Modül odaklı", "Haber odaklı" }; Alan("Ana sayfa bölüm sırası", anaDuzen);
        sutun.ItemsSource = new[] { "Temaya göre", "3", "4", "5", "6", "7" }; Alan("Ana sayfa kısayolları — sütun sayısı", sutun);
        Alan("Köşe yuvarlaklığı (−1: koleksiyonun varsayılanı)", kose); form.Children.Add(golge);
        form.Children.Add(mimariOnizleme);
        Aciklama("Önizleme yerleşimi gösterir. Kaydet ve uygula ile açık ekranlar güncellenir; seçimleriniz yeniden açılışta korunur.");
        Baslik("Renkler ve yazılar");
        renk.MaxLength = 7; Alan("Vurgu rengi (#RRGGBB)", renk);
        var palet = new WrapPanel(); form.Children.Add(palet);
        foreach (string c in new[] { "#2563EB", "#0D9488", "#7C3AED", "#EA580C", "#B91C1C" })
        { var b = Buton(palet, c, (_, _) => renk.Text = c); b.Background = (Brush)new BrushConverter().ConvertFromString(c)!; b.Foreground = Brushes.White; }
        font.ItemsSource = Fonts.SystemFontFamilies.Select(f => f.Source).OrderBy(s => s).ToArray(); Alan("Yazı tipi", font);
        Alan("Yazı ve arayüz boyutu (%85–130)", boyut);
        onizleme.Child = ornek; form.Children.Add(onizleme);
        Aciklama("Boyut ayarı yazıları, düğmeleri ve tabloları birlikte büyütür. Ana ekran ve ticari modüllere uygulanır.");
        Baslik("Firmanın logosu");
        Alan("Ana sayfada görünen firma adı", firmaBasligi);
        Alan("Firma yazısı / slogan",firmaMetni);Alan("İkinci açıklama satırı",firmaAltMetni);
        form.Children.Add(logoGoster);form.Children.Add(adGoster);Alan("Logo boyutu",logoBoyut);
        Aciklama("Bu başlık yalnızca uygulama içindeki marka alanında görünür. Masaüstü kısayolu, uygulama adı ve simgesi MiapaxERP olarak kalır.");
        Aciklama("PNG, JPG, BMP veya PDF yükleyin. PDF'nin ilk sayfası logo olarak kullanılır (en fazla 25 MB).");
        form.Children.Add(logoOnizleme); form.Children.Add(logoBilgi);
        var lp = new WrapPanel(); form.Children.Add(lp);
        Buton(lp, "Logo seç…", async (_, _) => await DosyaSec(true));
        Buton(lp, "Varsayılan logoyu kullan", (_, _) => { taslak.Logo = ""; DosyaBilgileriniYenile(); });
        Baslik("Ana sayfa arka planı");
        sektor.ItemsSource=MiapaxERP.Lisans.Core.UrunKatalogu.Sektorler;sektor.DisplayMemberPath="Ad";sektor.SelectedValuePath="Kod";
        sektor.IsEnabled=!LisansOturumu.Zorunlu;Alan("Firmanın sektör profili (müşteri dağıtımında lisans belirler)",sektor);
        form.Children.Add(sektorMedya);var playlist=new WrapPanel();form.Children.Add(playlist);
        Buton(playlist,"Sektöre video / görsel ekle…",async(_,_)=>await SektorMedyaEkle());
        Buton(playlist,"Listeden kaldır",(_,_)=>{if(sektorMedya.SelectedItem is string f){taslak.SektorMedyalari.GetValueOrDefault((string?)sektor.SelectedValue??taslak.Sektor)?.Remove(f);SektorListeYenile();}});
        Aciklama("Her sektörün dönen medya listesi ayrıdır. En fazla 12 dosya seçilir. Dosya seçilmediyse diğer sektörün videosu gösterilmez. Videoların kullanım hakkı firmanızda olmalıdır.");
        sektor.SelectionChanged+=(_,_)=>SektorListeYenile();
        medya.ItemsSource = new[] { "Sektöre göre", "Varsayılan", "Düz renk", "Görsel", "Video" }; Alan("Arka plan türü", medya);
        Aciklama("Görsel: PNG/JPG/BMP. Video: MP4/WMV, en fazla 500 MB. Seçilen dosya uygulamanın kişisel medya klasörüne kopyalanır.");
        form.Children.Add(dosyaBilgi); Buton(form, "Görsel veya video seç…", async (_, _) => await DosyaSec(false));
        form.Children.Add(oynat); Alan("Okunabilirlik için arka planı karart (%0–85)", karartma);
        Baslik("Ana sayfadaki kartlar ve tablolar");
        Aciklama("İşaretini kaldırdığınız kart gizlenir. Yeniden işaretleyerek ana sayfaya ekleyebilirsiniz.");
        foreach (var k in GorunumTercihleri.Kartlar)
        { var cb = new CheckBox { Content = k.Ad, Margin = new Thickness(0,6,0,6) }; kartlar.Add(k.Id, cb); form.Children.Add(cb); }
        Doldur();
        tema.SelectionChanged += (_, _) => Onizle(); font.SelectionChanged += (_, _) => Onizle();
        yerlesim.SelectionChanged += (_, _) => Onizle(); yogunluk.SelectionChanged += (_, _) => Onizle(); sutun.SelectionChanged += (_, _) => Onizle();
        kose.ValueChanged += (_, _) => Onizle();
        renk.TextChanged += (_, _) => Onizle(); boyut.ValueChanged += (_, _) => Onizle();
        Closing += (_, e) => { if (mesgul) e.Cancel = true; };
        Closed += (_, _) =>
        {
            foreach (string f in yeniDosyalar.Where(f => !kaydedildi || (f != taslak.Logo && f != taslak.Medya && !taslak.SektorMedyalari.Values.Any(l=>l.Contains(f)))))
                try { File.Delete(f); } catch (IOException) { } catch (UnauthorizedAccessException) { }
        };
    }
    private void Baslik(string t) => form.Children.Add(new TextBlock { Text = t, FontSize = 21, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0,18,0,10) });
    private void Aciklama(string t) => form.Children.Add(new TextBlock { Text = t, TextWrapping = TextWrapping.Wrap, Foreground = Brushes.SlateGray, Margin = new Thickness(0,0,0,10) });
    private void Alan(string t, FrameworkElement e)
    { form.Children.Add(new TextBlock { Text = t, Margin = new Thickness(0,8,0,5) }); e.MinHeight = 28; form.Children.Add(e); }
    private static Button Buton(Panel p, string t, RoutedEventHandler h)
    { var b = new Button { Content = t, Padding = new Thickness(12,8,12,8), Margin = new Thickness(0,6,8,6) }; b.Click += h; p.Children.Add(b); return b; }
    private void Doldur()
    {
        firmaBasligi.Text = taslak.FirmaBasligi;
        firmaMetni.Text=taslak.FirmaMetni;firmaAltMetni.Text=taslak.FirmaAltMetni;logoGoster.IsChecked=taslak.FirmaLogoGoster;adGoster.IsChecked=taslak.FirmaAdiGoster;logoBoyut.Value=taslak.FirmaLogoBoyutu;
        sektor.SelectedValue=LisansOturumu.Gecerli?.Sector??taslak.Sektor;SektorListeYenile();
        tema.SelectedItem = taslak.Tema; renk.Text = taslak.Vurgu; font.SelectedItem = taslak.YaziTipi;
        yerlesim.SelectedItem = taslak.Yerlesim; yogunluk.SelectedItem = taslak.Yogunluk;
        anaDuzen.SelectedItem = taslak.AnaSayfaDuzeni;
        sutun.SelectedItem = taslak.KisayolSutun == 0 ? "Temaya göre" : taslak.KisayolSutun.ToString();
        kose.Value = taslak.Kose; golge.IsChecked = taslak.Golge;
        if (font.SelectedIndex < 0) font.SelectedItem = "Segoe UI";
        boyut.Value = taslak.Olcek * 100; medya.SelectedItem = taslak.MedyaModu;
        karartma.Value = taslak.Karartma * 100; oynat.IsChecked = taslak.VideoOynat;
        foreach (var k in kartlar) k.Value.IsChecked = !taslak.GizliKartlar.Contains(k.Key);
        DosyaBilgileriniYenile(); Onizle();
    }
    private void DosyaBilgileriniYenile()
    {
        dosyaBilgi.Text = string.IsNullOrEmpty(taslak.Medya) ? "Özel medya seçilmedi." : "Seçili medya: " + Path.GetFileName(taslak.Medya);
        logoBilgi.Text = string.IsNullOrEmpty(taslak.Logo) ? "MiapaxERP logosu kullanılıyor." : "Özel firma logosu seçildi.";
        try { logoOnizleme.Source = File.Exists(taslak.Logo) ? GorunumDeposu.Resim(taslak.Logo) : null; }
        catch { logoOnizleme.Source = null; logoBilgi.Text = "Logo dosyası okunamıyor; yeniden seçin."; }
    }
    private void Onizle()
    {
        bool koyu = tema.SelectedItem?.ToString() == "Koyu";
        var stil=Tema170.Sec(tema.SelectedItem?.ToString() ?? "Modern"); onizleme.Background=Tema170.Firca(stil.Zemin); onizleme.CornerRadius=new CornerRadius(stil.Kose);
        ornek.Foreground = koyu ? Brushes.White : Brushes.Black;
        ornek.FontSize = 16 * boyut.Value / 100;
        ornek.Text = $"{tema.SelectedItem} • Görünüm boyutu %{boyut.Value:0}";
        ornek.FontFamily = new FontFamily(font.SelectedItem?.ToString() ?? "Segoe UI");
        try { onizleme.BorderBrush = (Brush)new BrushConverter().ConvertFromString(renk.Text)!; onizleme.BorderThickness = new Thickness(3); } catch { }
        var a = taslak.Kopya(); a.Tema = tema.SelectedItem?.ToString() ?? "Modern"; a.Yerlesim = yerlesim.SelectedItem?.ToString() ?? "Temaya göre";
        var grid = new Grid { Background = Tema170.Firca(stil.Zemin) }; mimariOnizleme.Child = grid;
        bool top = Tema170.Yerlesim(a) == "Üst menü", right = Tema170.Yerlesim(a) == "Sağ menü";
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = top || right ? new GridLength(1, GridUnitType.Star) : new GridLength(100) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = top ? new GridLength(0) : right ? new GridLength(100) : new GridLength(1,GridUnitType.Star) });
        grid.RowDefinitions.Add(new RowDefinition { Height = top ? new GridLength(40) : new GridLength(1,GridUnitType.Star) });
        grid.RowDefinitions.Add(new RowDefinition { Height = top ? new GridLength(1,GridUnitType.Star) : new GridLength(0) });
        var nav = new Border { Background = Tema170.Firca(stil.Menu), Child = new TextBlock { Text = "MIAPAX ERP\nMenüler", Foreground = Brushes.White, Margin = new Thickness(10), FontSize = 11 } };
        Grid.SetColumn(nav,right ? 1 : 0); grid.Children.Add(nav);
        var cards = new System.Windows.Controls.Primitives.UniformGrid { Columns = int.TryParse(sutun.SelectedItem?.ToString(), out int cols) ? cols : a.Tema == "VIP" ? 4 : a.Tema == "Kültürel" ? 3 : 5, Margin = new Thickness(8) };
        for (int i=0;i<8;i++) cards.Children.Add(new Border { Background=Tema170.Firca(stil.Yuzey), CornerRadius=new CornerRadius(kose.Value < 0 ? stil.Kose : kose.Value), Margin=new Thickness(4), BorderBrush=Tema170.Firca(stil.Vurgu), BorderThickness=new Thickness(0,2,0,0), Child=new TextBlock { Text=i==0?"Takvim":"Modül", Foreground=Tema170.Firca(koyu ? "#F2F7FF":"#182E42"), Margin=new Thickness(6), FontSize=10 } });
        Grid.SetColumn(cards,top || right ? 0 : 1); Grid.SetRow(cards,top ? 1 : 0); grid.Children.Add(cards);
    }
    void SektorListeYenile()
    {
        string code=(string?)sektor.SelectedValue??taslak.Sektor;
        sektorMedya.ItemsSource=null;sektorMedya.ItemsSource=taslak.SektorMedyalari.GetValueOrDefault(code,new());
    }
    async Task SektorMedyaEkle()
    {
        var picker=new OpenFileDialog{Filter="Video ve görseller|*.mp4;*.wmv;*.png;*.jpg;*.jpeg;*.bmp",Multiselect=true,CheckFileExists=true};
        if(picker.ShowDialog(this)!=true)return;string code=(string?)sektor.SelectedValue??taslak.Sektor;
        if(!taslak.SektorMedyalari.TryGetValue(code,out var files))taslak.SektorMedyalari[code]=files=new();
        if(files.Count+picker.FileNames.Length>12){MessageBox.Show("Sektör başına en fazla 12 dosya ekleyin.");return;}
        mesgul=true;IsEnabled=false;
        try{foreach(string source in picker.FileNames){string file=await GorunumDeposu.MedyaAl(source,klasor,false);yeniDosyalar.Add(file);files.Add(file);}medya.SelectedItem="Sektöre göre";SektorListeYenile();}
        catch(Exception ex){MessageBox.Show(ex.Message,"Medya eklenemedi");}
        finally{mesgul=false;IsEnabled=true;}
    }
    private async Task DosyaSec(bool logo)
    {
        var d = new OpenFileDialog { Filter = logo ? "Logo|*.pdf;*.png;*.jpg;*.jpeg;*.bmp" : "Görsel ve video|*.png;*.jpg;*.jpeg;*.bmp;*.mp4;*.wmv", CheckFileExists = true };
        if (d.ShowDialog(this) != true) return;
        mesgul = true; IsEnabled = false;
        try
        {
            string f = await GorunumDeposu.MedyaAl(d.FileName, klasor, logo); yeniDosyalar.Add(f);
            if (logo) taslak.Logo = f;
            else { taslak.Medya = f; medya.SelectedItem = new[] { ".mp4", ".wmv" }.Contains(Path.GetExtension(f)) ? "Video" : "Görsel"; }
            DosyaBilgileriniYenile();
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Dosya yüklenemedi", MessageBoxButton.OK, MessageBoxImage.Warning); }
        finally { mesgul = false; IsEnabled = true; }
    }
    private void Kaydet()
    {
        try
        {
            taslak.FirmaBasligi = firmaBasligi.Text;
            taslak.FirmaMetni=firmaMetni.Text.Trim();taslak.FirmaAltMetni=firmaAltMetni.Text.Trim();taslak.FirmaLogoGoster=logoGoster.IsChecked==true;taslak.FirmaAdiGoster=adGoster.IsChecked==true;taslak.FirmaLogoBoyutu=logoBoyut.Value;
            taslak.Sektor=LisansOturumu.Gecerli?.Sector??(string?)sektor.SelectedValue??taslak.Sektor;
            taslak.Tema = tema.SelectedItem?.ToString() ?? "Varsayılan"; taslak.Vurgu = renk.Text.Trim();
            taslak.Yerlesim = yerlesim.SelectedItem?.ToString() ?? "Temaya göre"; taslak.Yogunluk = yogunluk.SelectedItem?.ToString() ?? "Temaya göre";
            taslak.AnaSayfaDuzeni = anaDuzen.SelectedItem?.ToString() ?? "Temaya göre";
            taslak.Kose = kose.Value; taslak.Golge = golge.IsChecked == true; taslak.KisayolSutun = int.TryParse(sutun.SelectedItem?.ToString(), out int col) ? col : 0;
            taslak.YaziTipi = font.SelectedItem?.ToString() ?? "Segoe UI"; taslak.Olcek = boyut.Value / 100;
            taslak.MedyaModu = medya.SelectedItem?.ToString() ?? "Varsayılan"; taslak.VideoOynat = oynat.IsChecked == true;
            taslak.Karartma = karartma.Value / 100; taslak.GizliKartlar = kartlar.Where(k => k.Value.IsChecked != true).Select(k => k.Key).ToList();
            taslak.Dogrula();
            if (taslak.MedyaModu is "Video" or "Görsel")
            {
                if (!File.Exists(taslak.Medya)) throw new InvalidDataException("Önce bir arka plan dosyası seçin.");
                bool video = new[] { ".mp4", ".wmv" }.Contains(Path.GetExtension(taslak.Medya));
                if (video != (taslak.MedyaModu == "Video")) throw new InvalidDataException("Seçtiğiniz dosya arka plan türüyle uyuşmuyor.");
            }
            yetkiDogrula(); GorunumDeposu.Kaydet(klasor, taslak); kaydedildi = true; uygula(taslak.Kopya()); DialogResult = true;
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Ayarlar kaydedilemedi", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }
}


