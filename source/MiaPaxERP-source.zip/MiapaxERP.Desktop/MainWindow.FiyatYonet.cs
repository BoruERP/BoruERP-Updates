using System;
using System.Data;
using System.Windows;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop
{
    public partial class MainWindow
    {
        private void StokFiyatYonet_Click(object sender, RoutedEventArgs e)
        {
            if (!StokYetkisiGerekli("STOCK.EDIT")) return;
            if (DemoModu) { MessageBox.Show("Bu özellik SQL Server modunda kullanılabilir."); return; }
            if (StokTablosu.SelectedItem is not DataRowView row)
            { MessageBox.Show("Önce listeden stok seçin."); return; }
            try
            {
                var pencere = new StokFiyatPenceresi(baglantiAdresi,
                    Convert.ToInt32(row["Id"]), Convert.ToString(row["StokKodu"]) ?? "");
                pencere.Owner = this;
                pencere.ShowDialog();
            }
            catch (Exception ex) { MessageBox.Show("Fiyat yönetimi açılamadı: " + ex.Message); }
        }
    }
}
