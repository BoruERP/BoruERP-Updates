using System;
using System.Windows;
using System.Windows.Controls;

namespace MiapaxERP.Desktop
{
    public partial class CevrimdisiVerilerPenceresi : Window
    {
        private readonly string baglanti;
        private readonly int kullaniciId;

        public CevrimdisiVerilerPenceresi(string sunucuBaglantisi, int kullanici)
        {
            baglanti = sunucuBaglantisi;
            kullaniciId = kullanici;
            InitializeComponent();
            CmbKategori.SelectedIndex = 0;
        }

        private void KategoriDegisti(object sender, SelectionChangedEventArgs e)
        {
            if (GridYerel == null || TxtKopyaZamani == null) return;
            string kategori = (CmbKategori.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "Stok";
            var kopya = MiapaxERPYerelKopya.Oku(baglanti, kullaniciId, kategori);
            GridYerel.ItemsSource = kopya?.Veri.DefaultView;
            TxtKopyaZamani.Text = kopya == null
                ? "Bu kullanıcı için son 7 günde yetkili ve geçerli yerel kopya bulunmuyor. Önce sunucuya bağlıyken oturum açıp verilerin alınmasını bekleyin."
                : "⚠ Son eşitlenen kopya: " + kopya.Value.Alinma.ToString("dd.MM.yyyy HH:mm:ss") +
                  "   — bağlantı yoksa bu kayıtlar güncel değildir. İşlem yapamazsınız.";
        }
    }
}
