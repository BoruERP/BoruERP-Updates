using System.Collections.Concurrent;
using System.Data;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Data.SqlClient;

namespace MiapaxERP.Desktop;

public sealed record HttpsDogrulanmisHesap(HttpsKullanici Kullanici,string GuvenlikDamgasi);
public interface IHttpsHesapDeposu
{
    HttpsDogrulanmisHesap Giris(HttpsGiris giris);
    bool Gecerli(int id,string damga);
}
public sealed class HttpsSqlHesapDeposu(string connection) : IHttpsHesapDeposu
{
    static readonly string bosHash=GirisPenceresi.SifreOzetiOlustur("Miapax-hesap-yok-"+Guid.NewGuid());
    internal static string Damga(string hash)=>Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(hash)));
    public HttpsDogrulanmisHesap Giris(HttpsGiris input)=>Dogrula(input,false);
    internal HttpsDogrulanmisHesap Dogrula(HttpsGiris input,bool degisimIzin)
    {
        const string hata="Kullanıcı adı veya şifre hatalı ya da hesabınız kullanılamıyor.";
        if(string.IsNullOrWhiteSpace(input.Kullanici)||input.Kullanici.Length>60||string.IsNullOrEmpty(input.Parola)||input.Parola.Length>512)throw new UnauthorizedAccessException(hata);
        using var c=new SqlConnection(connection);c.Open();using var tx=c.BeginTransaction(IsolationLevel.Serializable);
        int id=0;string name="",full="",hash=bosHash;bool active=false,change=false;DateTime? until=null;
        using(var q=new SqlCommand("SELECT Id,KullaniciAdi,AdSoyad,SifreOzeti,Aktif,SifreDegistirmeli,KilitBitisUtc FROM dbo.Kullanicilar WITH(UPDLOCK,HOLDLOCK) WHERE KullaniciAdi=@a",c,tx))
        {
            q.Parameters.Add("@a",SqlDbType.NVarChar,60).Value=input.Kullanici.Trim();using var r=q.ExecuteReader();
            if(r.Read()){id=r.GetInt32(0);name=r.GetString(1);full=r.GetString(2);hash=r.GetString(3);active=r.GetBoolean(4);change=r.GetBoolean(5);until=r.IsDBNull(6)?null:r.GetDateTime(6);}
        }
        bool correct=GirisPenceresi.SifreDogrula(input.Parola,hash);
        if(!active||(until.HasValue&&until.Value>DateTime.UtcNow)){tx.Commit();throw new UnauthorizedAccessException(hata);}
        if(!correct)
        {
            using var q=new SqlCommand("UPDATE dbo.Kullanicilar SET BasarisizGirisSayisi=CASE WHEN KilitBitisUtc<=SYSUTCDATETIME() THEN 1 ELSE BasarisizGirisSayisi+1 END,KilitBitisUtc=CASE WHEN (CASE WHEN KilitBitisUtc<=SYSUTCDATETIME() THEN 1 ELSE BasarisizGirisSayisi+1 END)>=5 THEN DATEADD(minute,15,SYSUTCDATETIME()) ELSE NULL END WHERE Id=@id",c,tx);
            q.Parameters.AddWithValue("@id",id);q.ExecuteNonQuery();tx.Commit();throw new UnauthorizedAccessException(hata);
        }
        if(change&&!degisimIzin){tx.Commit();throw new InvalidOperationException("İlk giriş için şifrenizi yenilemelisiniz. Şifre değiştir / İlk giriş düğmesini kullanın.");}
        var roles=new List<string>();using(var q=new SqlCommand("SELECT r.RolAdi FROM dbo.KullaniciRolAtamalari a JOIN dbo.KullaniciRolleri r ON r.Id=a.RolId WHERE a.KullaniciId=@u AND r.Aktif=1 ORDER BY r.RolAdi",c,tx))
        {q.Parameters.AddWithValue("@u",id);using var r=q.ExecuteReader();while(r.Read())roles.Add(r.GetString(0));}
        using(var q=new SqlCommand("UPDATE dbo.Kullanicilar SET BasarisizGirisSayisi=0,KilitBitisUtc=NULL,SonGirisUtc=SYSUTCDATETIME() WHERE Id=@u",c,tx)){q.Parameters.AddWithValue("@u",id);q.ExecuteNonQuery();}
        tx.Commit();return new(new(id,name,full,string.Join(", ",roles)),Damga(hash));
    }
    public bool Gecerli(int id,string stamp)
    {
        using var c=new SqlConnection(connection);c.Open();using var q=new SqlCommand("SELECT SifreOzeti FROM dbo.Kullanicilar WHERE Id=@u AND Aktif=1 AND SifreDegistirmeli=0 AND (KilitBitisUtc IS NULL OR KilitBitisUtc<=SYSUTCDATETIME())",c);
        q.Parameters.AddWithValue("@u",id);return q.ExecuteScalar() is string hash&&CryptographicOperations.FixedTimeEquals(Encoding.ASCII.GetBytes(Damga(hash)),Encoding.ASCII.GetBytes(stamp));
    }
}
public sealed class HttpsOturumDeposu(IHttpsHesapDeposu hesap,TimeProvider? clock=null)
{
    sealed class Session(HttpsDogrulanmisHesap account,DateTimeOffset now)
    {
        public HttpsDogrulanmisHesap Hesap=account;public DateTimeOffset Baslangic=now,Son=now;public readonly object Gate=new();
    }
    readonly TimeProvider saat=clock??TimeProvider.System;
    readonly ConcurrentDictionary<string,Session> sessions=new(StringComparer.Ordinal);
    readonly SemaphoreSlim login=new(1);
    static string Key(string token)=>Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(token)));
    public async Task<(string Token,HttpsKullanici Kullanici,DateTimeOffset Bitis)> Giris(HttpsGiris input,CancellationToken ct)
    {
        if(!await login.WaitAsync(0,ct))throw new HttpsYogunException();
        try
        {
            var now=saat.GetUtcNow();foreach(var item in sessions)if(now-item.Value.Baslangic>=TimeSpan.FromHours(8)||now-item.Value.Son>=TimeSpan.FromMinutes(15))sessions.TryRemove(item.Key,out _);
            if(sessions.Count>=256)throw new HttpsYogunException();
            var user=hesap.Giris(input);string token=Convert.ToHexString(RandomNumberGenerator.GetBytes(32));
            sessions[Key(token)]=new(user,now);return(token,user.Kullanici,now.AddHours(8));
        }
        finally{login.Release();}
    }
    public HttpsKullanici Dogrula(string token)
    {
        if(token.Length!=64||!token.All(Uri.IsHexDigit)||!sessions.TryGetValue(Key(token),out var s))throw new UnauthorizedAccessException();
        lock(s.Gate)
        {
            var now=saat.GetUtcNow();if(now-s.Baslangic>=TimeSpan.FromHours(8)||now-s.Son>=TimeSpan.FromMinutes(15)||!hesap.Gecerli(s.Hesap.Kullanici.Id,s.Hesap.GuvenlikDamgasi))
            {sessions.TryRemove(Key(token),out _);throw new UnauthorizedAccessException();}
            s.Son=now;return s.Hesap.Kullanici;
        }
    }
    public void Cikis(string token){if(token.Length==64)sessions.TryRemove(Key(token),out _);}
}
public sealed class HttpsYogunException : Exception;
