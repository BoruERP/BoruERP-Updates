import {fromGeo,area,simple,bounds} from './field-plan-core.mjs?v=2.8.1';
export function boundaryFromCoordinates(coordinates){
 let points=coordinates.map(c=>({lng:Number(c[0]),lat:Number(c[1])}));
 if(points.length>1&&points[0].lng===points.at(-1).lng&&points[0].lat===points.at(-1).lat)points.pop();
 if(points.length<3||points.length>120||points.some(p=>!Number.isFinite(p.lat)||!Number.isFinite(p.lng)||Math.abs(p.lat)>85||Math.abs(p.lng)>180))throw Error('3–120 köşeli WGS84 enlem/boylam sınırı gerekli. ED50/ITRF metre koordinatlarını önce WGS84’e dönüştürün.');
 const field=fromGeo(points),b=bounds(field.boundary);
 if(!simple(field.boundary)||area(field.boundary)<1||b.maxX-b.minX>5000||b.maxY-b.minY>5000)throw Error('Sınır kesişiyor, çok küçük veya 5 km’den büyük.');
 return field;
}
export function fromGeoJson(raw){
 if(raw.crs && !JSON.stringify(raw.crs).match(/4326|CRS84/i))throw Error('Yalnız WGS84 / EPSG:4326 koordinatları destekleniyor.');
 let shape=raw;
 if(shape.type==='FeatureCollection'){if(shape.features.length!==1)throw Error('Tek bir parsel içeren dosya seçin.');shape=shape.features[0];}
 if(shape.type==='Feature')shape=shape.geometry;
 if(shape?.type!=='Polygon'||shape.coordinates.length!==1)throw Error('Tek dış sınırlı Polygon gerekli; delikli veya çok parçalı parsel desteklenmiyor.');
 return boundaryFromCoordinates(shape.coordinates[0]);
}
export function fromKml(text){
 const doc=new DOMParser().parseFromString(text,'application/xml');
 if(doc.querySelector('parsererror'))throw Error('KML okunamadı.');
 const polygons=[...doc.getElementsByTagNameNS('*','Polygon')];
 if(polygons.length!==1||polygons[0].getElementsByTagNameNS('*','innerBoundaryIs').length)throw Error('Tek ve deliksiz bir parsel KML dosyası gerekli.');
 const node=polygons[0].getElementsByTagNameNS('*','coordinates')[0];
 if(!node)throw Error('KML sınır koordinatları yok.');
 return boundaryFromCoordinates(node.textContent.trim().split(/\s+/).map(s=>s.split(',')));
}
