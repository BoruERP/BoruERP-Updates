import {cleanHydraulics,hydraulicEstimate} from "./hydraulics.mjs?v=2.8.1";
import {PARTS,uid,area,bounds,length,simple,rectangle} from './field-plan-core.mjs?v=2.8.1';
export const numberText=n=>n.toLocaleString('tr-TR',{maximumFractionDigits:1});
export function billOfMaterials(plan){
 const groups=new Map();
 for(const item of plan.items){const line=PARTS[item.kind].line,key=item.kind+(line?`-${item.diameter||63}`:'');
 if(!groups.has(key))groups.set(key,{label:PARTS[item.kind].label+(line?` · Ø${item.diameter||63} mm`:''),unit:line?'m':'adet',quantity:0});
 groups.get(key).quantity+=line?length(item.a,item.b):1;}
 return [...groups.values()].map(g=>({...g,order:g.unit==='m'?Math.ceil(g.quantity*1.05):g.quantity}));
}
function cuts(poly,y,vertical=false){const p=vertical?poly.map(a=>({x:a.y,y:a.x})):poly,x=[];
 for(let i=0;i<p.length;i++){const a=p[i],b=p[(i+1)%p.length];if((a.y<=y&&b.y>y)||(b.y<=y&&a.y>y))x.push(a.x+(y-a.y)*(b.x-a.x)/(b.y-a.y));}
 x.sort((a,b)=>a-b);const result=[];for(let i=0;i+1<x.length;i+=2)if(x[i+1]-x[i]>2)result.push([x[i]+1,x[i+1]-1]);return result;
}
export function automaticPlan(old,settings,dimensions){
 const gap=Number(settings.rowGap),heads=Number(settings.headGap),mode=settings.method;
 if(!['sprinkler','drip'].includes(mode)||!Number.isFinite(gap)||gap<.3||gap>50||!Number.isFinite(heads)||heads<1||heads>50)throw Error('Hat aralığı 0,3–50 m, başlık aralığı 1–50 m olmalı.');
 const poly=settings.areaMode==='dimensions'?rectangle(dimensions.width,dimensions.height):old.boundary;
 if(settings.areaMode==='dimensions'&&(!Number.isFinite(dimensions.width)||!Number.isFinite(dimensions.height)||dimensions.width<2||dimensions.height<2||dimensions.width>2000||dimensions.height>2000))throw Error('En ve boy 2–2.000 metre arasında olmalı.');
 if(!simple(poly)||area(poly)<1)throw Error('Önce geçerli bir tarla sınırı oluşturun.');
 const b=bounds(poly),x=settings.side==='right'?b.maxX-1:b.minX+1,items=[],mains=cuts(poly,x,true);let independent=0;
 const line=(a,b,kind='pipe',diameter=Number(settings.mainDiameter))=>{if(length(a,b)>.05)items.push({id:uid(),kind,a,b,diameter});};
 const point=(kind,p)=>items.push({id:uid(),kind,p,diameter:Number(settings.mainDiameter),range:Math.max(1,Math.min(100,heads*.65))});
 for(const [a,z] of mains){line({x,y:a},{x,y:z});point('source',{x,y:z});point('valve',{x,y:z-.1});}
 const rows=Math.max(1,Math.ceil((b.maxY-b.minY-2)/gap));
 if(rows>240)throw Error('Bu aralık 500 parçalık çizim sınırını aşar. Tarlayı sulama bölümlerine ayırıp her bölümü ayrı planlayın. Aralıklarınız değiştirilmedi.');
 for(let row=0;row<rows;row++){const y=b.minY+1+(row+.5)*(b.maxY-b.minY-2)/rows;
 for(const [left,right] of cuts(poly,y)){line({x:left,y},{x:right,y},mode==='drip'?'drip':'pipe',Number(settings.lateralDiameter));
 const connected=x>=left-1e-6&&x<=right+1e-6&&mains.some(([a,z])=>y>=a&&y<=z);
 if(connected){point('tee',{x,y});point('valve',{x,y});}else{const inlet={x:settings.side==='right'?right:left,y};point('source',inlet);point('valve',inlet);independent++;}
 if(mode==='sprinkler'){const count=Math.max(1,Math.ceil((right-left)/heads));if(items.length+count>500)throw Error('Bu seçim 500 parçalık sınırı aşar. Tarlayı bölümlere ayırın veya aralığı değiştirin. Mevcut çiziminiz korundu.');for(let n=0;n<count;n++)point('sprinkler',{x:left+(n+.5)*(right-left)/count,y});}
 }}
 if(items.length>500)throw Error('Çizim sınırı aşıldı. Daha küçük bir sulama bölümü planlayın.');
 if(!items.some(i=>PARTS[i.kind].line))throw Error('Bu dar alanda yerleşim oluşmadı. Tarla sınırını veya ölçüleri kontrol edin.');
 const result = {...old,name:settings.project.trim()||'Tarlam',boundary:poly,items,geo:settings.areaMode==='dimensions'?null:old.geo,settings:{...settings,independent}};
 if(settings.hydraulics)hydraulicEstimate(result,settings.hydraulics,true);
 return result;
}

