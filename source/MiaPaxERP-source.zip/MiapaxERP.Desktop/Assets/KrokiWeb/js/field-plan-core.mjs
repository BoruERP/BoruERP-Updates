import {cleanHydraulics} from "./hydraulics.mjs?v=2.8.1";
export function cleanSettings(s){
 if(!s||!['drip','sprinkler'].includes(s.method))return null;
 const n=(x,min,max,fallback)=>Number.isFinite(Number(x))&&Number(x)>=min&&Number(x)<=max?Number(x):fallback;
 return {hydraulics:s.hydraulics?cleanHydraulics(s.hydraulics):null,project:String(s.project||'').slice(0,80),crop:String(s.crop||'').slice(0,60),water:String(s.water||'').slice(0,60),method:s.method,side:s.side==='right'?'right':'left',areaMode:s.areaMode==='boundary'?'boundary':'dimensions',rowGap:n(s.rowGap,.3,50,12),headGap:n(s.headGap,1,50,12),mainDiameter:n(s.mainDiameter,10,1000,63),lateralDiameter:n(s.lateralDiameter,10,1000,50),independent:n(s.independent,0,500,0)};
}
export const PARTS={pipe:{label:'Boru hattı',line:true,color:'#1474a8'},drip:{label:'Damla hattı',line:true,color:'#233d31'},sprinkler:{label:'Yağmurlama başlığı',color:'#16a7c2'},tee:{label:'T bağlantı',color:'#476c82'},valve:{label:'Vana',color:'#e7852c'},source:{label:'Su kaynağı',color:'#145da0'}};
export const uid=()=>crypto.randomUUID();
export const bounds=points=>({minX:Math.min(...points.map(p=>p.x)),maxX:Math.max(...points.map(p=>p.x)),minY:Math.min(...points.map(p=>p.y)),maxY:Math.max(...points.map(p=>p.y))});
export function area(p){return Math.abs(p.reduce((s,a,i)=>{const b=p[(i+1)%p.length];return s+a.x*b.y-b.x*a.y},0)/2)}
export const length=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
export const perimeter=p=>p.reduce((s,a,i)=>s+length(a,p[(i+1)%p.length]),0);
export function inside(p,poly){let yes=false;for(let i=0,j=poly.length-1;i<poly.length;j=i++){const a=poly[i],b=poly[j];if((a.y>p.y)!==(b.y>p.y)&&p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x)yes=!yes}return yes}
export function simple(poly){
 if(!Array.isArray(poly)||poly.length<3)return false;
 const eps=1e-8,cross=(a,b,c)=>(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
 const on=(a,b,p)=>Math.abs(cross(a,b,p))<eps&&p.x>=Math.min(a.x,b.x)-eps&&p.x<=Math.max(a.x,b.x)+eps&&p.y>=Math.min(a.y,b.y)-eps&&p.y<=Math.max(a.y,b.y)+eps;
 for(let i=0;i<poly.length;i++){
 const a=poly[i],b=poly[(i+1)%poly.length],next=poly[(i+2)%poly.length];
 if(length(a,b)<eps||Math.abs(cross(a,b,next))<eps&&((a.x-b.x)*(next.x-b.x)+(a.y-b.y)*(next.y-b.y))>eps)return false;
 for(let j=i+1;j<poly.length;j++){
 if(j===i+1||i===0&&j===poly.length-1)continue;
 const c=poly[j],d=poly[(j+1)%poly.length],abC=cross(a,b,c),abD=cross(a,b,d),cdA=cross(c,d,a),cdB=cross(c,d,b);
 if(abC*abD<0&&cdA*cdB<0||on(a,b,c)||on(a,b,d)||on(c,d,a)||on(c,d,b))return false;
 }}return true;
}
export const rectangle=(w,h)=>[{x:0,y:0},{x:w,y:0},{x:w,y:h},{x:0,y:h}];
export const initial=()=>({version:1,name:'Yeni tarla',boundary:rectangle(80,50),items:[],geo:null});
export function validate(raw){
 if(!raw||typeof raw!=='object'||raw.version!==1||!Array.isArray(raw.boundary)||raw.boundary.length<3||raw.boundary.length>120||!Array.isArray(raw.items)||raw.items.length>500)throw Error('Bu dosya geçerli bir MiapaxERP planı değil.');
 const point=p=>{if(!p||!Number.isFinite(p.x)||!Number.isFinite(p.y)||Math.abs(p.x)>100000||Math.abs(p.y)>100000)throw Error('Planda geçersiz bir konum var.');return {x:p.x,y:p.y}};
 const boundary=raw.boundary.map(point);if(area(boundary)<1||!simple(boundary))throw Error('Tarla sınırı en az 1 m² olmalı ve kendi üzerine kesişmemeli.');
 const items=raw.items.map(x=>{if(!x||!Object.hasOwn(PARTS,x.kind))throw Error('Bilinmeyen parça.');const item={id:uid(),kind:x.kind,diameter:x.diameter==null?63:Number(x.diameter),range:x.range==null?8:Number(x.range)};if(!Number.isFinite(item.range)||!Number.isFinite(item.diameter)||item.range<1||item.range>100||item.diameter<10||item.diameter>1000)throw Error('Parça ölçüsü geçersiz.');return PARTS[x.kind].line?{...item,a:point(x.a),b:point(x.b)}:{...item,p:point(x.p)}});
 return {version:1,parcel:Object.fromEntries(['il','ilce','mahalle','ada','parsel'].map(k=>[k,String(raw.parcel?.[k]||'').slice(0,80)])),name:String(raw.name||'Tarlam').slice(0,80),boundary,items,settings:cleanSettings(raw.settings),geo:raw.geo&&Number.isFinite(raw.geo.lat)&&Number.isFinite(raw.geo.lng)&&Math.abs(raw.geo.lat)<=90&&Math.abs(raw.geo.lng)<=180?{lat:raw.geo.lat,lng:raw.geo.lng,scaleLat:Number.isFinite(raw.geo.scaleLat)?raw.geo.scaleLat:raw.geo.lat}:null};
}
function intervals(poly,value,vertical=false){const list=[],p=vertical?poly.map(p=>({x:p.y,y:p.x})):poly;for(let i=0;i<p.length;i++){const a=p[i],b=p[(i+1)%p.length];if((a.y<=value&&b.y>value)||(b.y<=value&&a.y>value))list.push(a.x+(value-a.y)*(b.x-a.x)/(b.y-a.y))}list.sort((a,b)=>a-b);return list.reduce((r,x,i)=>{if(i%2===0&&list[i+1]-x>2)r.push([x+1,list[i+1]-1]);return r},[])}
export function autoLayout(poly,{spacing=12,mode='sprinkler',side='left'}={}){
 const b=bounds(poly),w=b.maxX-b.minX,h=b.maxY-b.minY;spacing=Math.max(3,Math.min(50,spacing));
 const adjusted=Math.max(spacing,Math.sqrt(area(poly)/130)),items=[],mainX=b.minX+w*(side==='right'?.85:.15);
 const pipe=(a,b,kind='pipe')=>items.push({id:uid(),kind,a,b,diameter:63});
 const point=(kind,p)=>items.push({id:uid(),kind,p,range:Math.max(3,adjusted*.65)});
 for(const span of intervals(poly,mainX,true)){pipe({x:mainX,y:span[0]},{x:mainX,y:span[1]});point('source',{x:mainX,y:span[1]})}
 for(let y=b.minY+adjusted/2;y<b.maxY-1;y+=adjusted){for(const [left,right] of intervals(poly,y)){pipe({x:left,y},{x:right,y},mode==='drip'?'drip':'pipe');if(mainX>=left&&mainX<=right)point('tee',{x:mainX,y});if(mode!=='drip')for(let x=left+adjusted/2;x<right;x+=adjusted)if(inside({x,y},poly))point('sprinkler',{x,y})}}
 return {items:items.slice(0,500),spacing:adjusted};
}
export function totals(plan){const counts={};let meters=0;for(const i of plan.items){counts[i.kind]=(counts[i.kind]||0)+1;if(PARTS[i.kind].line)meters+=length(i.a,i.b)}return {area:area(plan.boundary),perimeter:perimeter(plan.boundary),meters,counts}}
export function fromGeo(points){const lat=points.reduce((s,p)=>s+p.lat,0)/points.length,lng=Math.min(...points.map(p=>p.lng)),north=Math.max(...points.map(p=>p.lat));return {boundary:points.map(p=>({x:(p.lng-lng)*111320*Math.cos(lat*Math.PI/180),y:(north-p.lat)*111320})),geo:{lat:north,lng,scaleLat:lat}}}





