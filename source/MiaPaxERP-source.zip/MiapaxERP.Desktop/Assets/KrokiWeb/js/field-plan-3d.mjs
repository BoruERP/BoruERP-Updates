import {zoneColors} from "./hydraulics.mjs?v=2.8.1";
import * as THREE from '/lib/three/three.module.js';
import {OrbitControls} from '/lib/three/OrbitControls.js';
import {bounds,inside,PARTS,area} from './field-plan-core.mjs?v=2.8.1';
export function createViewer(host,callbacks){
 const scene=new THREE.Scene();scene.background=new THREE.Color('#d9edf5');
 const camera=new THREE.PerspectiveCamera(48,1,.05,10000);
 const renderer=new THREE.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));renderer.outputColorSpace=THREE.SRGBColorSpace;host.append(renderer.domElement);
 const caption=document.createElement('div');caption.setAttribute('role','status');caption.style.cssText='position:absolute;right:10px;top:55px;left:10px;background:#fffffff0;color:#17495e;padding:8px 12px;border-radius:8px;font:12px Arial,sans-serif;pointer-events:none;z-index:2';host.append(caption);
 const controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.maxPolarAngle=Math.PI/2-.012;controls.minDistance=1.3;controls.maxDistance=4000;
 scene.add(new THREE.HemisphereLight('#f4fbff','#6e7650',2.5));const sun=new THREE.DirectionalLight('#fff5d6',2.5);sun.position.set(-60,120,80);scene.add(sun);
 const ground=new THREE.Group(),parts=new THREE.Group();scene.add(ground,parts);
 const mat=color=>new THREE.MeshStandardMaterial({color,roughness:.8});const zoneMats=zoneColors.map(mat);
 const mats={pipe:mat('#183441'),drip:mat('#253a28'),sprinkler:mat('#008caf'),tee:mat('#4e6170'),valve:mat('#ef8c32'),source:mat('#1a80bc'),selected:mat('#4cd8ba'),field:mat('#9eae68'),outer:mat('#b8c5aa')};
 const raycaster=new THREE.Raycaster(),pointer=new THREE.Vector2(),plane=new THREE.Plane(new THREE.Vector3(0,1,0),0);let plan=null,selected=null,dragging=false,down=null;
 function clear(group){for(const obj of [...group.children]){obj.traverse(x=>{if(x.geometry)x.geometry.dispose();if(x.material?.userData?.owned)x.material.dispose()});group.remove(obj)}}
 function mesh(geometry,material,parent){const m=new THREE.Mesh(geometry,material);parent.add(m);return m}
 function segment(a,b,r,parent,material){const v1=new THREE.Vector3(a.x,.16,a.y),v2=new THREE.Vector3(b.x,.16,b.y),d=v2.clone().sub(v1);if(d.length()<.001)return;const m=mesh(new THREE.CylinderGeometry(r,r,d.length(),10),material,parent);m.position.copy(v1).add(v2).multiplyScalar(.5);m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),d.normalize())}
 function update(next,id){plan=next;selected=id;clear(ground);clear(parts);const b=bounds(plan.boundary),w=b.maxX-b.minX,h=b.maxY-b.minY,size=Math.max(w,h,10),cx=(b.minX+b.maxX)/2,cy=(b.minY+b.maxY)/2;
  const outer=mesh(new THREE.PlaneGeometry(size*8,size*8),mats.outer,ground);outer.rotation.x=-Math.PI/2;outer.position.set(cx,-.08,cy);
  const shape=new THREE.Shape();plan.boundary.forEach((p,i)=>i?shape.lineTo(p.x,-p.y):shape.moveTo(p.x,-p.y));shape.closePath();const field=mesh(new THREE.ShapeGeometry(shape),mats.field,ground);field.rotation.x=-Math.PI/2;
  const rowPoints=[],stepX=Math.max(2,w/60),stepY=Math.max(2,h/65);for(let y=b.minY+stepY;y<b.maxY;y+=stepY)for(let x=b.minX;x<b.maxX-stepX;x+=stepX)if(inside({x,y},plan.boundary)&&inside({x:x+stepX,y},plan.boundary))rowPoints.push(x,.025,y,x+stepX,.025,y);
  const rowMat=new THREE.LineBasicMaterial({color:'#657546',transparent:true,opacity:.55});rowMat.userData.owned=true;const lines=new THREE.LineSegments(new THREE.BufferGeometry().setAttribute('position',new THREE.Float32BufferAttribute(rowPoints,3)),rowMat);ground.add(lines);
  const borderPts=plan.boundary.concat(plan.boundary[0]).map(p=>new THREE.Vector3(p.x,.08,p.y));const borderMat=new THREE.LineBasicMaterial({color:'#47713f'});borderMat.userData.owned=true;ground.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(borderPts),borderMat));
  const pipes=plan.items.filter(i=>PARTS[i.kind].line),meters=pipes.reduce((sum,i)=>sum+Math.hypot(i.a.x-i.b.x,i.a.y-i.b.y),0),heads=plan.items.filter(i=>i.kind==='sprinkler').length;
 caption.textContent=(plan.name||'Tarlam')+' · '+w.toLocaleString('tr-TR')+' × '+h.toLocaleString('tr-TR')+' m · '+area(plan.boundary).toLocaleString('tr-TR')+' m² · '+(plan.settings?.method==='drip'?'Damlama':heads?'Yağmurlama':'Düzenlenmiş plan')+' · '+pipes.length+' hat · '+heads+' başlık · '+meters.toLocaleString('tr-TR',{maximumFractionDigits:1})+' m boru';
  for(const item of plan.items){const group=new THREE.Group();group.userData.itemId=item.id;parts.add(group);const material=item.id===selected?mats.selected:item.zone?zoneMats[(item.zone-1)%zoneMats.length]:mats[item.kind];
   if(PARTS[item.kind].line){segment(item.a,item.b,Math.max(.04,(item.diameter||63)*.004),group,material);for(const p of [item.a,item.b]){const end=mesh(new THREE.SphereGeometry(.17,10,8),material,group);end.position.set(p.x,.16,p.y)}}
   else{const p=item.p;
    if(item.kind==='sprinkler'){const pole=mesh(new THREE.CylinderGeometry(.11,.13,1.5,10),material,group);pole.position.set(p.x,.75,p.y);const head=mesh(new THREE.BoxGeometry(.9,.18,.2),material,group);head.position.set(p.x,1.55,p.y);const coverMat=new THREE.MeshBasicMaterial({color:'#22b5d1',transparent:true,opacity:.11,depthWrite:false,side:THREE.DoubleSide});coverMat.userData.owned=true;const circle=mesh(new THREE.CircleGeometry(item.range||8,40),coverMat,group);circle.rotation.x=-Math.PI/2;circle.position.set(p.x,.04,p.y);circle.raycast=()=>{}}
    else if(item.kind==='source'){const tank=mesh(new THREE.CylinderGeometry(1,1,1.6,16),material,group);tank.position.set(p.x,.8,p.y);const cap=mesh(new THREE.CylinderGeometry(.85,.85,.05,16),mats.sprinkler,group);cap.position.set(p.x,1.63,p.y)}
    else if(item.kind==='valve'){const stem=mesh(new THREE.CylinderGeometry(.18,.18,.65,10),material,group);stem.position.set(p.x,.4,p.y);const wheel=mesh(new THREE.TorusGeometry(.4,.08,8,18),material,group);wheel.rotation.x=Math.PI/2;wheel.position.set(p.x,.78,p.y)}
    else{segment({x:p.x-.6,y:p.y},{x:p.x+.6,y:p.y},.19,group,material);segment({x:p.x,y:p.y},{x:p.x,y:p.y+.6},.19,group,material)}
   }
   group.traverse(m=>m.userData.itemId=item.id);
  }
 }
 function fit(mode='above'){if(!plan)return;const b=bounds(plan.boundary),w=b.maxX-b.minX,h=b.maxY-b.minY,s=Math.max(w,h,10),cx=(b.minX+b.maxX)/2,cy=(b.minY+b.maxY)/2;controls.target.set(cx,.3,cy);if(mode==='ground'){camera.position.set(cx,1.7,b.maxY+Math.max(4,s*.06));controls.target.set(cx,.5,cy)}else camera.position.set(cx+s*.6,s*.78,cy+s*.72);controls.update();renderer.render(scene,camera)}
 function hit(event){const r=renderer.domElement.getBoundingClientRect();pointer.set((event.clientX-r.left)/r.width*2-1,-(event.clientY-r.top)/r.height*2+1);raycaster.setFromCamera(pointer,camera);const point=raycaster.ray.intersectPlane(plane,new THREE.Vector3());const object=raycaster.intersectObjects(parts.children,true).find(x=>x.object.userData.itemId);return {p:point?{x:point.x,y:point.z}:null,id:object?.object.userData.itemId||null}}
 renderer.domElement.addEventListener('pointerdown',event=>{const h=hit(event);down={x:event.clientX,y:event.clientY};if(callbacks.down(h.p,h.id,event)){dragging=true;controls.enabled=false;renderer.domElement.setPointerCapture(event.pointerId)}});
 renderer.domElement.addEventListener('pointermove',event=>{if(dragging){const h=hit(event);if(h.p)callbacks.move(h.p,event)}});
 renderer.domElement.addEventListener('pointerup',event=>{if(dragging){const h=hit(event);callbacks.up(h.p,event);dragging=false;controls.enabled=callbacks.canOrbit();if(renderer.domElement.hasPointerCapture(event.pointerId))renderer.domElement.releasePointerCapture(event.pointerId)}else if(down&&Math.hypot(event.clientX-down.x,event.clientY-down.y)<5){const h=hit(event);callbacks.click(h.p,h.id,event)}down=null});
 const resize=()=>{const w=host.clientWidth,h=host.clientHeight;if(w&&h){renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix()}};new ResizeObserver(resize).observe(host);resize();
 function frame(){requestAnimationFrame(frame);if(host.getClientRects().length&&!document.hidden){controls.update();renderer.render(scene,camera)}}frame();
 return {update,fit,resize,setOrbit:enabled=>controls.enabled=enabled,image:()=>renderer.domElement.toDataURL('image/png')};
}



