import {hydraulicForm,hydraulicReport} from "./desktop.mjs?v=2.8.1";
import {hydraulicEstimate} from "./hydraulics.mjs?v=2.8.1";
import {area,bounds,PARTS} from './field-plan-core.mjs?v=2.8.1';
import {automaticPlan,billOfMaterials,numberText as fmt} from './field-plan-estimate.mjs?v=2.8.1';
const $=id=>document.getElementById(id),escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const methodName=s=>s?.method==='drip'?'Damlama':s?.method==='sprinkler'?'Yağmurlama':'Elle düzenlenmiş plan';
const table=rows=>`<table><thead><tr><th>Malzeme</th><th>Çizimde</th><th>Önerilen miktar*</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${escape(r.label)}</td><td>${fmt(r.quantity)} ${r.unit}</td><td>${fmt(r.order)} ${r.unit}</td></tr>`).join('')}</tbody></table>`;
export function installWorkflow({getPlan,getView=()=>$('fp3DStage').hidden?'sketch':'3d',svg,reportImage,status,setView,apply}){
 document.body.append($('fpPrintReport'));
 let lastSettings=null,dirty=false;
 const planNotice=document.createElement('p');planNotice.style.cssText='font-size:12px;color:#476875';planNotice.textContent='Çizimi ölçüler, sulama türü, hat/başlık aralığı ve çap belirler. Ürün ve su kaynağı teklif notuna eklenir.'; $('fpAutoForm').append(planNotice);
 const form=$('fpAutoForm'),message=$('fpAutoMessage');
 svg.closest('.fp-workspace').style.scrollMarginTop='90px';
 const stagebar=svg.closest('.fp-workspace').querySelector('.fp-stagebar');
 const localViews=document.createElement('div');localViews.style.cssText='display:flex;gap:6px;flex-wrap:wrap';
 const sketchButton=document.createElement('button'),threeButton=document.createElement('button');
 for(const b of [sketchButton,threeButton])b.type='button';
 sketchButton.textContent='Krokiyi göster';threeButton.textContent='3D Görünüm';
 localViews.append(sketchButton,threeButton);stagebar.prepend(localViews);
 async function open3D(){if(dirty&&!generate('3d'))return;await setView('3d');requestAnimationFrame(()=>{svg.closest('.fp-workspace').scrollIntoView({behavior:'smooth',block:'start'});});}
 sketchButton.onclick=()=>showSketch();threeButton.onclick=()=>open3D().catch(()=>status('3D açılamadı. Krokiyi kullanabilir veya sayfayı yenileyebilirsiniz.'));
 const auto3D=document.createElement('button');auto3D.type='button';auto3D.textContent='Çizimi 3D aç';auto3D.style.marginLeft='8px';form.querySelector('button[type=submit]').after(auto3D);auto3D.onclick=threeButton.onclick;
 const showSketch=()=>{setView('sketch');requestAnimationFrame(()=>{svg.setAttribute('preserveAspectRatio','xMidYMid meet');svg.closest('.fp-workspace').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'start'});svg.focus({preventScroll:true});});};
 // The old rectangle action erased the calculated pipes. Both actions now use the same plan.
 $('fpRectangle').textContent='Otomatik planı krokide göster';
 $('fpRectangle').onclick=()=>generate('sketch');
 document.querySelector('.fp-left h2').textContent='Kroki ve çizim';
 function areaMode(){const locked=$('fpAreaMode').value==='boundary';$('fpWidth').readOnly=$('fpHeight').readOnly=locked;}
 $('fpAreaMode').addEventListener('change',areaMode);areaMode();
 form.addEventListener('input',()=>{dirty=true;message.textContent='Bilgiler değişti. Hesapla veya Çizimi 3D aç ile yeni plana uygula.';});
 form.addEventListener('change',()=>{dirty=true;message.textContent='Bilgiler değişti. Hesapla veya Çizimi 3D aç ile yeni plana uygula.';});
 form.addEventListener('invalid',()=>{message.textContent='Geçersiz alanı düzeltin; ekrandaki önceki plan henüz güncellenmedi.';},true);
 function settings(){return {hydraulics:hydraulicForm(),project:$('fpProject').value,crop:$('fpCrop').value,water:$('fpWater').value,method:$('fpMethod').value,side:$('fpMainSide').value,areaMode:$('fpAreaMode').value,rowGap:Number($('fpRowGap').value),headGap:$('fpMethod').value==='drip'?12:Number($('fpHeadGap').value),mainDiameter:Number($('fpMainDiameter').value),lateralDiameter:Number($('fpLateralDiameter').value)};}
 function hydrate(s){if(!s||s===lastSettings)return;lastSettings=s;for(const [key,id] of Object.entries({project:'fpProject',crop:'fpCrop',water:'fpWater',method:'fpMethod',side:'fpMainSide',areaMode:'fpAreaMode',rowGap:'fpRowGap',headGap:'fpHeadGap',mainDiameter:'fpMainDiameter',lateralDiameter:'fpLateralDiameter'}))if(s[key]!=null)$(id).value=s[key];$('fpHeadGapLabel').hidden=$('fpHeadGap').disabled=s.method==='drip';areaMode();}
 $('fpMethod').onchange=()=>{const drip=$('fpMethod').value==='drip';$('fpRowGap').value=drip?'1':'12';$('fpLateralDiameter').value=drip?'16':'50';$('fpHeadGapLabel').hidden=$('fpHeadGap').disabled=drip;$('fpRowLabel').textContent=drip?'Damla sıraları arası (m)':'Hatlar arası (m)';};
 function generate(target=getView()){
 if(!form.reportValidity())return false;
 try{const next=automaticPlan(getPlan(),settings(),{width:Number($('fpWidth').value),height:Number($('fpHeight').value)});
 dirty=false;apply(next);setView(target==='3d'?'3d':'sketch');if(target!=='3d')showSketch();else requestAnimationFrame(()=>svg.closest('.fp-workspace').scrollIntoView({behavior:'smooth',block:'start'}));
 $('fpToolLabel').textContent=methodName(next.settings)+' · Güncel plan';
 const dimensions=bounds(next.boundary);message.textContent=fmt(dimensions.maxX-dimensions.minX)+' × '+fmt(dimensions.maxY-dimensions.minY)+' m '+methodName(next.settings)+' planı güncellendi. '+next.items.length+' çizim öğesi.'+(next.settings.independent?' '+next.settings.independent+' hat ayrı su girişi gerektirir.':'');status(message.textContent);return true;
 }catch(e){message.textContent=e.message+' Önceki plan değiştirilmedi.';status(message.textContent);return false;}
 }
 form.onsubmit=e=>{e.preventDefault();generate();};

 function update(){const plan=getPlan();hydrate(plan.settings);const rows=billOfMaterials(plan);$('fpBill').innerHTML=rows.length?table(rows):'<p class="fp-empty">Otomatik çizim oluştur veya krokiye parça ekle; malzeme listesi burada oluşacak.</p>';threeButton.disabled=auto3D.disabled=!rows.length;$('fpQuote').disabled=!rows.length;$('fpPrint').disabled=!rows.length;}
 function summary(plan){const s=plan.settings,b=bounds(plan.boundary);return [`MiapaxERP sulama planı: ${plan.name}`,`Alan: ${fmt(area(plan.boundary))} m²; sınır: ${fmt(b.maxX-b.minX)} × ${fmt(b.maxY-b.minY)} m`,`${methodName(s)}; ürün: ${s?.crop||'Belirtilmedi'}; su: ${s?.water||'Belirtilmedi'}`,s?`Hat aralığı: ${fmt(s.rowGap)} m; başlık aralığı: ${s.method==='drip'?'uygulanmaz':fmt(s.headGap)+' m'}`:'Elle düzenlenmiş yerleşim',...billOfMaterials(plan).map(r=>`${r.label}: ${fmt(r.quantity)} ${r.unit}; talep: ${fmt(r.order)} ${r.unit}`),'Boru miktarına %5 pay eklenmiştir. Fiyatsız ön taleptir; hidrolik hesap ve saha doğrulaması gerekir.',s?.independent?`${s.independent} hat bağımsız su girişi gerektirir.`:''].filter(Boolean).join('\n');}
 $('fpQuote').onclick=()=>{if(dirty&&!generate())return;const plan=getPlan();try{sessionStorage.setItem('miaplast-plan-quote',JSON.stringify({summary:summary(plan).slice(0,1700),group:plan.settings?.method==='drip'?'Kangal Borular':'Yağmurlama Boruları',quantity:Math.max(1,Math.ceil(billOfMaterials(plan).filter(r=>r.unit==='m').reduce((n,r)=>n+r.order,0)))}));location.assign('/Home/TeklifOlustur?plan=1');}catch{status('Teklif aktarımı için tarayıcı depolama izni gerekiyor. PDF çıktısı alıp iletişim bölümünden bize ulaşabilirsiniz.');}};
 async function print(pdf=false){if(dirty&&!generate())return;const plan=getPlan(),s=plan.settings;const copy=svg.cloneNode(true);copy.removeAttribute('tabindex');copy.removeAttribute('id');copy.querySelectorAll('[data-id]').forEach(e=>e.removeAttribute('data-id'));const logo=window.MiapaxERPLogo||new URL('./miapaxerp-wordmark.png',document.baseURI).href;let image=null;try{image=reportImage();}catch{}
 $('fpPrintReport').innerHTML=`<header><img src="${logo}" alt="Miapax ERP" data-brand-logo/><div><h1>Sulama planı ve malzeme ön talebi</h1><p>${escape(plan.name)} · ${new Date().toLocaleDateString('tr-TR')}</p></div></header><p>${escape(methodName(s))} · ${fmt(area(plan.boundary))} m² · Ürün: ${escape(s?.crop||'Belirtilmedi')} · Su: ${escape(s?.water||'Belirtilmedi')}</p>${plan.parcel?`<p>Parsel: ${Object.values(plan.parcel).filter(Boolean).map(escape).join(" / ")}</p>`:""}<h2>Ölçülü kroki</h2><div class="fp-print-sketch">${new XMLSerializer().serializeToString(copy)}</div><p class="fp-print-legend">S1, S2… ve renkler: sulama sektörleri · Kesikli: damla hattı · +: yağmurlama · T: bağlantı · V: vana · S: su girişi. Ölçüler metre cinsindedir.</p>${image?`<h2>3D görünüm</h2><img class="fp-print-3d" src="${image}" alt="Sulama planının 3D görünümü"/>`:''}<h2>Fiyatsız malzeme listesi</h2>${table(billOfMaterials(plan))}<p>* Boru sipariş miktarında %5 pay ve yukarı yuvarlama vardır. Çizimi değiştirdikçe metraj yeniden hesaplanır.</p>${s?.independent?`<p>${s.independent} hat bağımsız su girişi gerektirir. Kaynaklar krokide gösterilmiştir.</p>`:''}${s?.hydraulics?hydraulicReport(hydraulicEstimate(plan,s.hydraulics)):""}<footer>Bu belge fiyat teklifi veya mühendislik projesi değildir. Basınç, debi, arazi eğimi, bağlantı çeşitleri ve sulama uygunluğu teknik ekibimizce doğrulanmalıdır.<br/>MiapaxERP • Sulama Tasarım Atölyesi</footer>`;
 await Promise.all([...$('fpPrintReport').querySelectorAll('img')].map(async i=>{try{await i.decode();}catch(e){if(i.hasAttribute('data-brand-logo')){i.src=new URL('./miapaxerp-wordmark.png',document.baseURI).href;await i.decode();}}}));document.body.classList.add('fp-printing');if(pdf==='prepare')return;if(pdf&&window.chrome?.webview)window.chrome.webview.postMessage({action:'pdf'});else window.print();}
 $('fpPrint').onclick=()=>{status('Açılan yazdırma ekranında “PDF olarak kaydet” veya yazıcınızı seçin.');print().catch(()=>status('Çıktı hazırlanamadı. Lütfen tekrar deneyin.'));};
 $("fpQuote").textContent='PDF dosyasını kaydet';$("fpQuote").onclick=()=>print(true).catch(e=>status(e.message));window.prepareMiapaxReport=()=>print("prepare");
 window.addEventListener('afterprint',()=>document.body.classList.remove('fp-printing'));
 window.addEventListener('beforeprint',()=>{if($('fpPrintReport').children.length)document.body.classList.add('fp-printing');});
 update();return {update};
}




