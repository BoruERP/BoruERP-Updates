import {length,area,bounds,PARTS,inside} from './field-plan-core.mjs?v=2.8.1';
export const hydraulicDefaults={flow:12,pressure:4,emitterFlow:600,emitterPressure:3,emitterGap:.3,elevation:0,depth:20,efficiency:85,c:140,autoDiameter:true};
export const zoneColors=['#176fbe','#b25317','#6749ad','#08775e','#af3071','#696014'];
export function cleanHydraulics(raw={}){
 const h={...hydraulicDefaults,...raw};
 for(const [key,min,max] of [['flow',.01,5000],['pressure',.1,30],['emitterFlow',.1,50000],['emitterPressure',.1,20],['emitterGap',.05,20],['elevation',0,500],['depth',.1,300],['efficiency',10,100],['c',80,160]]){
  h[key]=Number(h[key]);if(!Number.isFinite(h[key])||h[key]<min||h[key]>max)throw Error(`Geçersiz hidrolik değer: ${key} (${min}–${max}).`);
 }
 h.autoDiameter=h.autoDiameter===true;return h;
}
export const velocity=(flow,d)=>4*(flow/3600)/(Math.PI*(d/1000)**2);
// SI Hazen–Williams: metre, m³/s, metre iç çap. Tam debi boyunca konservatif kayıp.
export const headLoss=(meters,flow,diameter,c=140)=>flow<=0?0:10.67*meters*(flow/3600)**1.852/(c**1.852*(diameter/1000)**4.87);
export function diameter(flow){return [16,20,25,32,40,50,63,75,90,110,125,160,200,250,315,400].find(d=>velocity(flow,d)<=1.5)||400;}
export function hydraulicEstimate(plan,raw,resize=false){
 const h=cleanHydraulics(raw), warnings=[],method=plan.settings?.method||'sprinkler';
 const lines=plan.items.filter(i=>PARTS[i.kind]?.line),heads=plan.items.filter(i=>i.kind==='sprinkler');
 const laterals=lines.filter(i=>i.kind==='drip'||Math.abs(i.a.y-i.b.y)<.01&&Math.abs(i.a.x-i.b.x)>.01);
 const mains=lines.filter(i=>!laterals.includes(i));
 if(!laterals.length)return {warnings:['Hesap için otomatik yerleşim oluşturun.'],zones:[],flow:0};
 const rows=laterals.map(line=>({line,emitters:method==='drip'?Math.ceil(length(line.a,line.b)/h.emitterGap):heads.filter(p=>Math.abs(p.p.y-line.a.y)<.05&&p.p.x>=Math.min(line.a.x,line.b.x)-.05&&p.p.x<=Math.max(line.a.x,line.b.x)+.05).length}));
 const zones=[];
 for(const row of rows){row.flow=row.emitters*h.emitterFlow/1000;let zone=zones.find(z=>z.flow+row.flow<=h.flow+1e-8);if(!zone){zone={number:zones.length+1,flow:0,rows:[]};zones.push(zone);}zone.rows.push(row);zone.flow+=row.flow;row.line.zone=zone.number;}
 for(const i of plan.items.filter(i=>!laterals.includes(i)))delete i.zone;
 for(const row of rows)for(const item of plan.items.filter(i=>i.p))if(Math.abs(item.p.y-row.line.a.y)<.05&&item.p.x>=Math.min(row.line.a.x,row.line.b.x)-.05&&item.p.x<=Math.max(row.line.a.x,row.line.b.x)+.05)item.zone=row.line.zone;
 const maxFlow=Math.max(...zones.map(z=>z.flow)),worstFlow=Math.max(...rows.map(r=>r.flow));
 if(rows.some(r=>r.flow>h.flow))warnings.push('Tek bir hat kaynak debisini aşıyor. Hattı fiziksel olarak bölün; yalnız vana sırası değiştirmek yeterli değil.');
 if(plan.settings?.independent)warnings.push(`${plan.settings.independent} hat ana hatta bağlı değil; ek bağlantı/su girişi tasarlanmalı.`);
 if(!mains.length)warnings.push('Ana besleme hattı yok; bağlantılar doğrulanmalı.');
 if(plan.items.some(i=>i.p&&!inside(i.p,plan.boundary)))warnings.push('Tarla sınırı dışında parçalar var. Düzenlemeyi kontrol edin.');
 const proposedMain=diameter(maxFlow),proposedLateral=diameter(worstFlow);
 if(resize&&h.autoDiameter){for(const i of mains)i.diameter=proposedMain;for(const r of rows)r.line.diameter=method==='drip'?Number(plan.settings.lateralDiameter):proposedLateral;
  plan.settings.mainDiameter=proposedMain;if(method!=='drip')plan.settings.lateralDiameter=proposedLateral;
 }
 const mainDiameter=mains.length?Math.min(...mains.map(i=>i.diameter||63)):proposedMain,lateralDiameter=Math.min(...laterals.map(i=>i.diameter||16));
 const mainLength=mains.reduce((n,i)=>n+length(i.a,i.b),0);
 const mainLoss=mains.reduce((n,i)=>n+headLoss(length(i.a,i.b),maxFlow,i.diameter||63,h.c),0);
 const lateralLoss=Math.max(...rows.map(r=>headLoss(length(r.line.a,r.line.b),r.flow,r.line.diameter||16,h.c)));
 const required=h.emitterPressure+((mainLoss+lateralLoss)*1.2+h.elevation)/10.197;
 if(required>h.pressure)warnings.push(`Kaynak basıncı yetersiz: yaklaşık ${required.toFixed(2)} bar gerekli, ${h.pressure.toFixed(2)} bar girildi.`);
 if(mains.some(i=>velocity(maxFlow,i.diameter||63)>1.5)||rows.some(r=>velocity(r.flow,r.line.diameter||16)>1.5))warnings.push('En az bir boruda hedef 1,5 m/s hız aşılıyor; iç çapı büyütün.');
 const water=area(plan.boundary)*h.depth/1000/(h.efficiency/100);
 // Eşit başlık/damlatıcı başına su; sektör debisiyle süre hesabı.
 const emitterCount=rows.reduce((n,r)=>n+r.emitters,0),perEmitter=emitterCount?water/emitterCount:0;
 if(method==='sprinkler'&&emitterCount!==heads.length)warnings.push('Elle taşınmış veya örtüşen hat/başlık var. Bazı başlıklar hat debisine eşlenemedi; bağlantıları düzeltmeden bu hesabı kullanmayın.');
 for(const zone of zones)zone.hours=zone.flow?zone.rows.reduce((n,r)=>n+r.emitters,0)*perEmitter/zone.flow:0;
 if(!emitterCount)warnings.push('Başlık bulunamadı. Elle taşınan başlıkları besleme hatlarına hizalayın.');
 return {zones:zones.map(z=>({number:z.number,flow:z.flow,rows:z.rows.length,hours:z.hours})),warnings,flow:maxFlow,totalFlow:rows.reduce((n,r)=>n+r.flow,0),emitterCount,mainDiameter,lateralDiameter,proposedMain,proposedLateral,mainLength,mainLoss,lateralLoss,requiredPressure:required,water,hours:zones.reduce((n,z)=>n+z.hours,0),assumptions:'Metre cinsinden düz plan; girilen kot farkı, boru iç çapı, C katsayısı ve %20 yerel kayıp payı kullanıldı. Yağmurlama örtüşmesi, rüzgâr, toprak ve pompa eğrisi doğrulanmadı.'};
}
