using System.Data;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed partial class IsletmeServisi
{
    long CariEntry(SqlConnection c,SqlTransaction t,int customer,DateTime date,string direction,decimal amount,string note,string source)
    {
        using var q=Q(c,t,"INSERT dbo.CariHareketleri(CariId,Tarih,HareketTipi,Tutar,Aciklama,Kaynak,YapanKullaniciId) OUTPUT INSERTED.Id VALUES(@c,@d,@t,@v,@a,@s,@u)",("@c",customer),("@d",date.Date),("@t",direction),("@v",amount),("@a",note),("@s",source),("@u",user));return Convert.ToInt64(q.ExecuteScalar());
    }
    public long SatisKaydet(SatisGirdisi g)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"IsletmeServisi.SatisKaydet","",new object?[]{g});}

        Text(g.No,1,80,"Belge no");Text(g.Aciklama,0,400,"Açıklama");Currency(g.Para,g.Kur);Money(g.Indirim);Money(g.Tahsilat);if(g.Anahtar==Guid.Empty||g.Tarih.Year<2000||g.Tarih.Year>2100||g.Teklif&&(g.Gecerlilik is null||g.Gecerlilik.Value.Date<g.Tarih.Date)||g.Kalemler is null||g.Kalemler.Length<1||g.Kalemler.Length>200||g.Teklif&&g.Tahsilat!=0)throw new ArgumentException("Belge bilgileri geçersiz.");
        using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);Yetki(c,t,"CUSTOMER.EDIT");Yetki(c,t,"STOCK.VIEW");if(!g.Teklif){Yetki(c,t,"STOCK.ISSUE");Yetki(c,t,"ACCOUNTING.POST");}
        using(var previous=Q(c,t,"SELECT Id FROM dbo.MPX310_Kayit WITH(UPDLOCK,HOLDLOCK) WHERE Anahtar=@k",("@k",g.Anahtar)))if(previous.ExecuteScalar() is not null)throw new InvalidOperationException("Belge daha önce kaydedildi. Listeyi yenileyin.");
        using(var duplicate=Q(c,t,"SELECT COUNT(*) FROM dbo.BoruERP_YeniBelgeler WITH(UPDLOCK,HOLDLOCK) WHERE BelgeNo=@n AND BelgeTuru=@t",("@n",g.No),("@t",g.Teklif?"T":"S")))if(Convert.ToInt32(duplicate.ExecuteScalar())>0)throw new ArgumentException("Belge numarası zaten var.");
        using(var customer=Q(c,t,"SELECT COUNT(*) FROM dbo.CariKartlari WITH(HOLDLOCK) WHERE Id=@i AND Aktif=1",("@i",g.Cari)))if(Convert.ToInt32(customer.ExecuteScalar())!=1)throw new ArgumentException("Aktif müşteri seçin.");
        if(g.KaynakTeklif.HasValue){using var offer=Q(c,t,"SELECT COUNT(*) FROM dbo.BoruERP_YeniBelgeler WITH(UPDLOCK,HOLDLOCK) WHERE Id=@i AND CariId=@c AND BelgeTuru='T' AND NOT EXISTS(SELECT 1 FROM dbo.BoruERP_YeniBelgeler WHERE KaynakTeklifId=@i AND BelgeTuru='S')",("@i",g.KaynakTeklif),("@c",g.Cari));if(g.Teklif||g.Para!="TRY"||Convert.ToInt32(offer.ExecuteScalar())!=1)throw new ArgumentException("Kaynak teklif geçersiz veya daha önce satışa çevrilmiş.");}
        decimal net=0,vat=0;var details=new List<(SatisKalemi K,string Name,string Unit,decimal Net,decimal Vat,string Inventory,string Expense)>();
        foreach(var k in g.Kalemler){Quantity(k.Miktar);Money(k.Fiyat);if(k.Fiyat<=0||k.Kdv<0||k.Kdv>100||decimal.Round(k.Kdv,2)!=k.Kdv)throw new ArgumentException("Fiyat ve KDV geçersiz.");var stock=Table(Q(c,t,"SELECT StokAdi,Birim,StokTipi FROM dbo.StokKartlari WITH(HOLDLOCK) WHERE Id=@s AND Aktif=1",("@s",k.Stok)));if(stock.Rows.Count!=1)throw new ArgumentException("Aktif ürün bulunamadı.");decimal n=Round(k.Miktar*k.Fiyat),v=Round(n*k.Kdv/100);net+=n;vat+=v;string kind=Convert.ToString(stock.Rows[0][2])??"";string inventory=kind=="Hammadde"?"150":kind is "Başlık" or "Mandallı" or "Kangal"?"152":"153";details.Add((k,(string)stock.Rows[0][0],(string)stock.Rows[0][1],n,v,inventory,inventory=="152"?"620":"621"));}
        // Gross discount retains the legacy totals convention; tax-base discounts require repriced lines.
        decimal total=net+vat-g.Indirim;if(total<=0||total>999999999999m||g.Tahsilat>total)throw new ArgumentException("Belge toplamı / tahsilat geçersiz.");
        decimal effectiveVat=vat;
        if(!g.Teklif&&g.Indirim>0){var taxRows=details.Select((d,i)=>new EBelge.UblSatir(i.ToString(System.Globalization.CultureInfo.InvariantCulture),d.K.Stok.ToString(),d.Name,d.K.Miktar,d.Unit,d.K.Fiyat,d.K.Kdv)).ToArray();var discount=EBelge.UblMaliHesap.EskiBrutIndirim(taxRows,g.Indirim);effectiveVat=discount.YeniKdv;}
        long record=Create(c,t,g.Teklif?"Teklif":"Satis",g.Anahtar,g,"Tamamlandı");long id;
        using(var q=Q(c,t,"INSERT dbo.BoruERP_YeniBelgeler(BelgeTuru,BelgeNo,CariId,Tarih,GecerlilikTarihi,OdemeDurumu,AraToplam,KdvToplam,Indirim,GenelToplam,Aciklama,KaynakTeklifId,YapanKullaniciId) OUTPUT INSERTED.Id VALUES(@tur,@n,@c,@d,@g,N'Ödenmedi',@net,@v,@i,@t,@a,@src,@u)",("@tur",g.Teklif?"T":"S"),("@n",g.No),("@c",g.Cari),("@d",g.Tarih.Date),("@g",g.Gecerlilik?.Date),("@net",net),("@v",vat),("@i",g.Indirim),("@t",total),("@a",g.Aciklama),("@src",g.KaynakTeklif),("@u",user)))id=Convert.ToInt64(q.ExecuteScalar());
        using(var schema=Q(c,t,"SELECT COL_LENGTH('dbo.BoruERP_YeniBelgeler','ParaBirimi')")){if(schema.ExecuteScalar() is DBNull){if(g.Para!="TRY")throw new InvalidOperationException("Önce mali tablo güncellemesini uygulayın.");}else{using var q=Q(c,t,"UPDATE dbo.BoruERP_YeniBelgeler SET ParaBirimi=@p WHERE Id=@i",("@p",g.Para),("@i",id));q.ExecuteNonQuery();}}
        if(!g.Teklif)
        {
            decimal book=Round(total*g.Kur),bookNet=book-Round(effectiveVat*g.Kur);long movement=CariEntry(c,t,g.Cari,g.Tarih,"Borç",book,g.No+" · "+g.Para+" / kur "+g.Kur,"MPX310 Satış");var entries=new List<MuhasebeKalemi>{new("120",book,0,g.Cari,g.No),new("600",0,bookNet,null,g.No)};if(book-bookNet>0)entries.Add(new("391",0,book-bookNet,null,g.No));long journal=Journal(c,t,new(g.Anahtar,g.Tarih,g.No,entries.ToArray()),"Satis",id);
            using var q=Q(c,t,"INSERT dbo.MPX310_Satis(BelgeId,CariHareketId,FisId,Doviz,Kur,Toplam) VALUES(@i,@m,@f,@p,@k,@v)",("@i",id),("@m",movement),("@f",journal),("@p",g.Para),("@k",g.Kur),("@v",total));q.ExecuteNonQuery();
        }
        var costs=new Dictionary<(string Inventory,string Expense),decimal>();bool missingCost=false;
        foreach(var d in details)
        {
            long line;using(var q=Q(c,t,"INSERT dbo.BoruERP_YeniBelgeKalemleri(BelgeId,StokKartId,UrunAciklama,Birim,Miktar,BirimFiyat,KdvOrani,SatirAraToplam,KdvTutari,SatirGenelToplam) OUTPUT INSERTED.Id VALUES(@id,@s,@n,@b,@m,@f,@k,@net,@v,@t)",("@id",id),("@s",d.K.Stok),("@n",d.Name),("@b",d.Unit),("@m",d.K.Miktar),("@f",d.K.Fiyat),("@k",d.K.Kdv),("@net",d.Net),("@v",d.Vat),("@t",d.Net+d.Vat)))line=Convert.ToInt64(q.ExecuteScalar());
            if(g.Teklif)continue;foreach(var allocation in Issue(c,t,d.K.Stok,d.K.Miktar,null,null,"SATIS",id,g.No)){using var q=Q(c,t,"INSERT dbo.MPX310_SatisLot(BelgeId,KalemId,LotId,RafId,Miktar,Maliyet) VALUES(@i,@k,@l,@r,@m,@c)",("@i",id),("@k",line),("@l",allocation.Lot),("@r",allocation.Raf),("@m",allocation.Miktar),("@c",allocation.BirimMaliyet));q.ExecuteNonQuery();if(allocation.BirimMaliyet is null)missingCost=true;else{var costKey=(d.Inventory,d.Expense);costs[costKey]=costs.GetValueOrDefault(costKey)+allocation.Miktar*allocation.BirimMaliyet.Value;}}
        }
        if(!g.Teklif){if(missingCost)throw new InvalidOperationException("Parti maliyeti eksik. Satış maliyetini doğru kaydetmek için önce parti maliyetlerini tamamlayın.");foreach(var cost in costs){decimal amount=Round(cost.Value);if(amount>0)Journal(c,t,new(Guid.NewGuid(),g.Tarih,g.No+" · satış maliyeti",new[]{new MuhasebeKalemi(cost.Key.Expense,amount,0,null,g.No),new MuhasebeKalemi(cost.Key.Inventory,0,amount,null,g.No)}),"SatisMaliyet",id);}if(g.Tahsilat>0){if(g.TahsilatHesabi is null)throw new ArgumentException("Tahsilat hesabını seçin.");Collect(c,t,new(Guid.NewGuid(),id,g.TahsilatHesabi.Value,g.Tarih,g.Tahsilat,g.TahsilatKuru,g.No));}}
        Event(c,t,record,"Belge oluştu",g.No+" · "+id);t.Commit();return id;
    }
    long Collect(SqlConnection c,SqlTransaction t,TahsilatGirdisi g)
    {
        Yetki(c,t,"FINANCE.PAYMENT");Money(g.Miktar);Text(g.Dayanak,1,400,"Tahsilat dayanağı");if(g.Miktar<=0||g.Anahtar==Guid.Empty)throw new ArgumentException("Tahsilat miktarı / kimliği geçersiz.");
        using(var duplicate=Q(c,t,"SELECT Id FROM dbo.MPX310_Tahsilat WITH(UPDLOCK,HOLDLOCK) WHERE Anahtar=@k",("@k",g.Anahtar)))if(duplicate.ExecuteScalar() is not null)throw new InvalidOperationException("Tahsilat zaten kaydedildi.");
        var sales=Table(Q(c,t,"SELECT s.*,d.CariId,d.Tarih,d.Durum,h.Tutar DefterToplam,COALESCE((SELECT SUM(DefterTutar) FROM dbo.MPX310_Tahsilat WHERE BelgeId=s.BelgeId),0) DefterKapanan FROM dbo.MPX310_Satis s WITH(UPDLOCK,HOLDLOCK) JOIN dbo.BoruERP_YeniBelgeler d ON d.Id=s.BelgeId JOIN dbo.CariHareketleri h ON h.Id=s.CariHareketId WHERE s.BelgeId=@i",("@i",g.Belge)));if(sales.Rows.Count!=1)throw new ArgumentException("Muhasebeleştirilmiş satış bulunamadı.");var sale=sales.Rows[0];if((string)sale["Durum"]=="İptal"||g.Miktar>(decimal)sale["Toplam"]-(decimal)sale["Kapanan"]||g.Tarih.Date<((DateTime)sale["Tarih"]).Date)throw new ArgumentException("Tahsilat bakiyeyi aşıyor veya tarih/durum uygun değil.");string currency=(string)sale["Doviz"];Currency(currency,g.Kur);
        var accounts=Table(Q(c,t,"SELECT ParaBirimi,HesapTipi FROM dbo.FinansHesaplari WITH(UPDLOCK,HOLDLOCK) WHERE Id=@i AND Aktif=1",("@i",g.Hesap)));if(accounts.Rows.Count!=1||(string)accounts.Rows[0]["ParaBirimi"]!=currency)throw new ArgumentException("Tahsilat hesabı satışla aynı para biriminde olmalı.");
        decimal paid=Round(g.Miktar*g.Kur),book=g.Miktar==(decimal)sale["Toplam"]-(decimal)sale["Kapanan"]?(decimal)sale["DefterToplam"]-(decimal)sale["DefterKapanan"]:Round(g.Miktar*(decimal)sale["Kur"]),fx=paid-book;int customer=(int)sale["CariId"];long movement=CariEntry(c,t,customer,g.Tarih,"Alacak",book,g.Dayanak,"MPX310 Tahsilat");
        long finance;using(var q=Q(c,t,"INSERT dbo.FinansHareketleri(HesapId,CariId,CariHareketId,Tarih,HareketTipi,Tutar,Aciklama,YapanKullaniciId) OUTPUT INSERTED.Id VALUES(@h,@c,@m,@d,N'Giriş',@v,@a,@u)",("@h",g.Hesap),("@c",customer),("@m",movement),("@d",g.Tarih.Date),("@v",g.Miktar),("@a",g.Dayanak),("@u",user)))finance=Convert.ToInt64(q.ExecuteScalar());
        string account=Convert.ToString(accounts.Rows[0]["HesapTipi"])=="Kasa"?"100":"102";var entries=new List<MuhasebeKalemi>{new(account,paid,0,null,g.Dayanak),new("120",0,book,customer,g.Dayanak)};if(fx>0)entries.Add(new("646",0,fx,null,g.Dayanak));if(fx<0)entries.Add(new("656",-fx,0,null,g.Dayanak));long journal=Journal(c,t,new(g.Anahtar,g.Tarih,g.Dayanak,entries.ToArray()),"Tahsilat",g.Belge);
        using(var q=Q(c,t,"INSERT dbo.MPX310_Tahsilat(Anahtar,BelgeId,Tarih,Tutar,Kur,DefterTutar,KurFarki,FinansHareketId,CariHareketId,FisId,Kullanici) OUTPUT INSERTED.Id VALUES(@k,@i,@d,@v,@r,@b,@fx,@f,@c,@j,@u)",("@k",g.Anahtar),("@i",g.Belge),("@d",g.Tarih.Date),("@v",g.Miktar),("@r",g.Kur),("@b",book),("@fx",fx),("@f",finance),("@c",movement),("@j",journal),("@u",user)))
        {long id=Convert.ToInt64(q.ExecuteScalar());using var update=Q(c,t,"UPDATE dbo.MPX310_Satis SET Kapanan=Kapanan+@v WHERE BelgeId=@i;UPDATE d SET OdemeDurumu=CASE WHEN s.Kapanan=s.Toplam THEN N'Ödendi' ELSE N'Kısmi' END FROM dbo.BoruERP_YeniBelgeler d JOIN dbo.MPX310_Satis s ON s.BelgeId=d.Id WHERE d.Id=@i",("@v",g.Miktar),("@i",g.Belge));update.ExecuteNonQuery();return id;}
    }
    public long Tahsilat(TahsilatGirdisi g){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"IsletmeServisi.Tahsilat","",new object?[]{g});}
using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);long id=Collect(c,t,g);t.Commit();return id;}
}

