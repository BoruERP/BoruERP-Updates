using System;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace MiapaxERP.Desktop
{
    internal static class PiyasaInternetServisi
    {
        internal sealed class FiyatKaynagi
        {
            public string Firma { get; set; } = "";
            public string Adres { get; set; } = "";
            public string Urun { get; set; } = "";
            public string KaynakTuru { get; set; } = "";
            public string Birim { get; set; } = "";
            public string FiyatDeseni { get; set; } = "";
            public string Kultur { get; set; } = "tr-TR";
        }
        private static readonly HttpClient Http = new HttpClient(new HttpClientHandler
        { AutomaticDecompression = DecompressionMethods.All }) { Timeout = TimeSpan.FromSeconds(15) };
        private static readonly SemaphoreSlim TekIstek = new SemaphoreSlim(1, 1);
        private static DataTable? onbellek;
        private static DateTime sonKontrolUtc;
        private static string sonDurum = "";
        private static readonly CultureInfo Tr = CultureInfo.GetCultureInfo("tr-TR");
        private static string AyarDosyasi => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "MiapaxERP", "piyasa-kaynaklari.json");
        private static List<FiyatKaynagi> KaynaklariOku()
        {
            if (!File.Exists(AyarDosyasi))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(AyarDosyasi)!);
                var ilk = new List<FiyatKaynagi>
                {
                    new FiyatKaynagi { Firma = "Ertunç Plastik",
                        Adres = "https://www.ertuncplastik.com.tr/urunler/kangal-borular/beyaz-pe-boru/",
                        Urun = "Beyaz PE Boru (başlangıç fiyatı)", KaynakTuru = "Üretici liste fiyatı",
                        Birim = "TL/metre (başlangıç)",
                        FiyatDeseni = @"(\d{1,5},\d{1,2})\s*TL\s*/\s*metreden\s+başlayan" },
                    new FiyatKaynagi { Firma = "Dalaz Tarım",
                        Adres = "https://dalaztarimsondajcilik.com/urunler?s=11",
                        Urun = "63/10 Kangal Boru 100 metre", KaynakTuru = "Mağaza satış fiyatı",
                        Birim = "TL/100 m kangal",
                        FiyatDeseni = @"63/10\s+Kangal\s+Boru\s+100\s+metre.{0,600}?(\d{1,3}(?:,\d{3})*\.\d{2})\s*₺",
                        Kultur = "en-US" }
                };
                File.WriteAllText(AyarDosyasi, JsonSerializer.Serialize(ilk,
                    new JsonSerializerOptions { WriteIndented = true }));
                return ilk;
            }
            return JsonSerializer.Deserialize<List<FiyatKaynagi>>(File.ReadAllText(AyarDosyasi)) ?? new();
        }
        internal static async Task<(DataTable Tablo, string Durum)> GetirAsync(bool zorla = false)
        {
            await TekIstek.WaitAsync();
            try
            {
                if (!zorla && onbellek != null && DateTime.UtcNow - sonKontrolUtc < TimeSpan.FromHours(24))
                    return (onbellek.Copy(), sonDurum);
                var tablo = new DataTable();
                tablo.Columns.Add("FirmaAdi", typeof(string));
                tablo.Columns.Add("UrunAciklamasi", typeof(string));
                tablo.Columns.Add("FiyatMetni", typeof(string));
                tablo.Columns.Add("KaynakTuru", typeof(string));
                tablo.Columns.Add("FiyatTarihi", typeof(DateTime));
                List<FiyatKaynagi> kaynaklar;
                try { kaynaklar = KaynaklariOku(); }
                catch (Exception ex) { return (tablo, "Kaynak ayarları okunamadı: " + ex.Message); }
                int dogrulanan = 0, erisilen = 0;
                foreach (var k in kaynaklar)
                {
                    if (string.IsNullOrWhiteSpace(k.Firma) || string.IsNullOrWhiteSpace(k.Urun) ||
                        string.IsNullOrWhiteSpace(k.FiyatDeseni) ||
                        !Uri.TryCreate(k.Adres, UriKind.Absolute, out var uri) ||
                        uri.Scheme != Uri.UriSchemeHttps) continue;
                    try
                    {
                        using var yanit = await Http.GetAsync(uri);
                        yanit.EnsureSuccessStatusCode();
                        erisilen++;
                        string html = await yanit.Content.ReadAsStringAsync();
                        string duz = WebUtility.HtmlDecode(Regex.Replace(html, "<[^>]+>", " "));
                        duz = Regex.Replace(duz, @"\s+", " ");
                        var eslesme = Regex.Match(duz, k.FiyatDeseni, RegexOptions.IgnoreCase,
                            TimeSpan.FromMilliseconds(500));
                        if (!eslesme.Success || eslesme.Groups.Count < 2) continue;
                        if (!decimal.TryParse(eslesme.Groups[1].Value, NumberStyles.Number,
                            CultureInfo.GetCultureInfo(k.Kultur), out decimal fiyat) || fiyat <= 0) continue;
                        // Tarih sayfadaki fiyatın yayın tarihi değil, kontrol zamanıdır.
                        tablo.Rows.Add(k.Firma, k.Urun, fiyat.ToString("N2", Tr) + " " + k.Birim,
                            k.KaynakTuru + " | " + k.Adres + " | Yayın tarihi belirtilmemiş", DateTime.Now);
                        dogrulanan++;
                    }
                    catch (HttpRequestException) { }
                    catch (TaskCanceledException) { }
                    catch (RegexMatchTimeoutException) { }
                    catch (CultureNotFoundException) { }
                    catch (ArgumentException) { }
                }
                string durum = $"{dogrulanan}/{kaynaklar.Count} kaynaktan fiyat doğrulandı; " +
                    $"{erisilen} sayfaya erişildi. Kontrol: {DateTime.Now:dd.MM.yyyy HH:mm}. " +
                    "Tarih kontrol zamanıdır; fiyatın yayımlandığı gün değildir. " +
                    "Kaynak eklemek için %LocalAppData%\\MiapaxERP\\piyasa-kaynaklari.json dosyasını düzenleyin.";
                onbellek = tablo.Copy(); sonKontrolUtc = DateTime.UtcNow; sonDurum = durum;
                return (tablo, durum);
            }
            finally { TekIstek.Release(); }
        }
    }
}
