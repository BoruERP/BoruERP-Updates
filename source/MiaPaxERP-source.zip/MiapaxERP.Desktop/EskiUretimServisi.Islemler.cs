using System.Data;
using System.Globalization;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed partial class EskiUretimServisi {
private static void UretimDecimalParametreEkle(SqlCommand komut, string ad,
            decimal deger, byte precision = 18, byte scale = 3)
        {
            SqlParameter p = komut.Parameters.Add(ad, SqlDbType.Decimal);
            p.Precision = precision;
            p.Scale = scale;
            p.Value = deger;
        }
private static decimal UretimPaketlenmisToplam(SqlConnection baglanti,
            SqlTransaction? islem, int emirId)
        {
            using var k = new SqlCommand(
                "SELECT ISNULL(SUM(ToplamAdet),CONVERT(bigint,0)) " +
                "FROM dbo.UretimPaketlemeKayitlari WITH (UPDLOCK,HOLDLOCK) " +
                "WHERE UretimEmriId=@Emir;", baglanti, islem);
            k.Parameters.Add("@Emir", SqlDbType.Int).Value = emirId;
            return Convert.ToDecimal(k.ExecuteScalar());
        }
private void UretimGunlukFarkKaydet(SqlConnection baglanti, SqlTransaction islem,
            int emirId, decimal uretilenFark, decimal fireFark)
        {
            if (uretilenFark == 0m && fireFark == 0m) return;
            using var k = new SqlCommand(
                "INSERT INTO dbo.UretimGunlukKayitlari " +
                "(UretimEmriId,UretilenFark,FireFark,KaydedenKullaniciId) " +
                "VALUES(@Id,@U,@F,@K);", baglanti, islem);
            k.Parameters.Add("@Id", SqlDbType.Int).Value = emirId;
            UretimDecimalParametreEkle(k, "@U", uretilenFark);
            UretimDecimalParametreEkle(k, "@F", fireFark);
            k.Parameters.Add("@K", SqlDbType.Int).Value = user;
            k.ExecuteNonQuery();
        }
public void Baslat(int emirId){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiUretimServisi.Baslat","",new object?[]{emirId});return;}
if(emirId<1)throw new ArgumentException("Emir seçin.");using SqlConnection baglanti = new SqlConnection(connection);
                baglanti.Open();
                using SqlTransaction islem = baglanti.BeginTransaction(IsolationLevel.Serializable);
access.Yetki(baglanti,islem,"PRODUCTION.COMPLETE");
                try
                {
                    int mamulId, receteId;
                    decimal planlanan, hedefKg;
                    string birim;
                    using (SqlCommand emirKomutu = new SqlCommand(
                        "SELECT MamulStokId, ReceteId, MiktarBirimi, PlanlananMiktar, HedefAgirlikKg " +
                        "FROM dbo.UretimEmirleri WITH (UPDLOCK, HOLDLOCK) " +
                        "WHERE Id=@Emir AND Durum=N'Planlandı' AND UretilenMiktar=0 AND FireMiktari=0;",
                        baglanti, islem))
                    {
                        emirKomutu.Parameters.Add("@Emir", SqlDbType.Int).Value = emirId;
                        using SqlDataReader r = emirKomutu.ExecuteReader();
                        if (!r.Read()) throw new InvalidOperationException("Emir artık başlatılabilecek durumda değil.");
                        mamulId = r.GetInt32(0);
                        if (r.IsDBNull(1)) throw new InvalidOperationException("Önce üretim emrine reçete seçin.");
                        receteId = r.GetInt32(1);
                        birim = r.IsDBNull(2) ? "" : r.GetString(2);
                        planlanan = r.GetDecimal(3);
                        if (r.IsDBNull(4)) throw new InvalidOperationException("Hedef toplam ağırlık (kg) boş. Emri önce düzenleyin.");
                        hedefKg = r.GetDecimal(4);
                    }
                    if (UretimBiriminiNormallestir(birim) == null || planlanan <= 0m || hedefKg <= 0m)
                        throw new InvalidOperationException("Üretim birimi veya hedef ağırlık geçersiz.");
                    if (birim == "kg" && hedefKg != planlanan)
                        throw new InvalidOperationException("KG emrinde hedef ağırlık planlanan miktara eşit olmalıdır.");
                    using (SqlCommand kontrol = new SqlCommand(
                        "SELECT COUNT_BIG(*) FROM dbo.UretimEmriReceteAnlikKalemleri " +
                        "WHERE UretimEmriId=@Emir;", baglanti, islem))
                    {
                        kontrol.Parameters.Add("@Emir", SqlDbType.Int).Value = emirId;
                        if (Convert.ToInt64(kontrol.ExecuteScalar()) != 0)
                            throw new InvalidOperationException("Bu emre daha önce reçete sabitlenmiş; ikinci kez başlatılamaz.");
                    }
                    using (SqlCommand kontrol = new SqlCommand(
                        "SELECT COUNT_BIG(*) FROM dbo.UretimReceteleri WITH (UPDLOCK, HOLDLOCK) " +
                        "WHERE Id=@Recete AND MamulStokId=@Mamul AND Aktif=1;", baglanti, islem))
                    {
                        kontrol.Parameters.Add("@Recete", SqlDbType.Int).Value = receteId;
                        kontrol.Parameters.Add("@Mamul", SqlDbType.Int).Value = mamulId;
                        if (Convert.ToInt64(kontrol.ExecuteScalar()) != 1)
                            throw new InvalidOperationException("Reçete artık aktif değil veya bu mamule ait değil.");
                    }
                    var kalemler = new List<(int StokId, decimal Oran)>();
                    decimal toplamOran = 0m;
                    using (SqlCommand komut = new SqlCommand(
                        "SELECT k.HammaddeStokId, k.YuzdeOrani, s.Birim, s.Aktif " +
                        "FROM dbo.UretimReceteKalemleri k WITH (HOLDLOCK) " +
                        "JOIN dbo.StokKartlari s WITH (HOLDLOCK) ON s.Id=k.HammaddeStokId " +
                        "WHERE k.ReceteId=@Recete ORDER BY k.Id;", baglanti, islem))
                    {
                        komut.Parameters.Add("@Recete", SqlDbType.Int).Value = receteId;
                        using SqlDataReader r = komut.ExecuteReader();
                        while (r.Read())
                        {
                            int stokId = r.GetInt32(0);
                            decimal oran = r.GetDecimal(1);
                            string hammaddeBirimi = r.GetString(2);
                            if (stokId == mamulId || UretimBiriminiNormallestir(hammaddeBirimi) != "kg" || !r.GetBoolean(3))
                                throw new InvalidOperationException("Reçetedeki hammaddeler aktif ve KG birimli stok kartlarından seçilmelidir.");
                            kalemler.Add((stokId, oran));
                            toplamOran += oran;
                        }
                    }
                    if (kalemler.Count == 0 || toplamOran != 100m)
                        throw new InvalidOperationException("Reçete boş veya toplam hammadde oranı %100 değil.");
                    foreach (var kalem in kalemler)
                    {
                        using SqlCommand k = new SqlCommand(
                            "INSERT INTO dbo.UretimEmriReceteAnlikKalemleri " +
                            "(UretimEmriId,HammaddeStokId,YuzdeOrani) VALUES (@Emir,@Stok,@Oran);", baglanti, islem);
                        k.Parameters.Add("@Emir", SqlDbType.Int).Value = emirId;
                        k.Parameters.Add("@Stok", SqlDbType.Int).Value = kalem.StokId;
                        UretimDecimalParametreEkle(k, "@Oran", kalem.Oran, 9, 4);
                        k.ExecuteNonQuery();
                    }
                    using (SqlCommand k = new SqlCommand(
                        "UPDATE dbo.UretimEmirleri SET Durum=N'Üretimde' " +
                        "WHERE Id=@Emir AND Durum=N'Planlandı' AND UretilenMiktar=0 AND FireMiktari=0;", baglanti, islem))
                    {
                        k.Parameters.Add("@Emir", SqlDbType.Int).Value = emirId;
                        if (k.ExecuteNonQuery() != 1)
                            throw new InvalidOperationException("Üretim emri değişti; başlatma işlemi iptal edildi.");
                    }
                    islem.Commit();
                }
                catch
                {
                    islem.Rollback();
                    throw;
                }}
public void MiktarKaydet(int emirId,decimal uretilen,decimal fire){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiUretimServisi.MiktarKaydet","",new object?[]{emirId,uretilen,fire});return;}
if(emirId<1)throw new ArgumentException("Emir seçin.");Miktarlar(uretilen,fire);using var baglanti = new SqlConnection(connection);
                baglanti.Open();
                using var islem = baglanti.BeginTransaction(IsolationLevel.Serializable);
access.Yetki(baglanti,islem,"PRODUCTION.COMPLETE");
                try
                {
                    decimal eskiUretilen, eskiFire;
                    string birim;
                    using (var oku = new SqlCommand(
                        "SELECT UretilenMiktar, FireMiktari, MiktarBirimi FROM dbo.UretimEmirleri " +
                        "WITH (UPDLOCK, HOLDLOCK) WHERE Id=@Id AND Durum=N'Üretimde';", baglanti, islem))
                    {
                        oku.Parameters.Add("@Id", SqlDbType.Int).Value = emirId;
                        using var r = oku.ExecuteReader();
                        if (!r.Read()) throw new InvalidOperationException("Emir artık Üretimde değil.");
                        eskiUretilen = r.GetDecimal(0);
                        eskiFire = r.GetDecimal(1);
                        birim = r.IsDBNull(2) ? "" : r.GetString(2);
                    }
                    if (UretimBiriminiNormallestir(birim) == "adet" &&
                        (decimal.Truncate(uretilen) != uretilen || decimal.Truncate(fire) != fire))
                        throw new InvalidOperationException("Adet üretiminde sağlam ürün ve fire tam sayı olmalıdır.");
                    decimal paketlenen = UretimPaketlenmisToplam(baglanti, islem, emirId);
                    if (uretilen < paketlenen)
                        throw new InvalidOperationException("Sağlam ürün " + uretimYazi(paketlenen) +
                            " adet paketlenmiş miktardan az olamaz. Önce paketleri kontrol edin.");

                    using (var kaydet = new SqlCommand(
                        "UPDATE dbo.UretimEmirleri SET UretilenMiktar=@U, FireMiktari=@F " +
                        "WHERE Id=@Id AND Durum=N'Üretimde';", baglanti, islem))
                    {
                        kaydet.Parameters.Add("@Id", SqlDbType.Int).Value = emirId;
                        UretimDecimalParametreEkle(kaydet, "@U", uretilen);
                        UretimDecimalParametreEkle(kaydet, "@F", fire);
                        if (kaydet.ExecuteNonQuery() != 1)
                            throw new InvalidOperationException("Üretim miktarları güncellenemedi.");
                    }
                    UretimGunlukFarkKaydet(baglanti, islem, emirId,
                        uretilen - eskiUretilen, fire - eskiFire);

                    islem.Commit();
                }
                catch { islem.Rollback(); throw; }}
public decimal Tamamla(int emirId,decimal uretilen,decimal fire){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<decimal>(connection,"EskiUretimServisi.Tamamla","",new object?[]{emirId,uretilen,fire});}
if(emirId<1||uretilen+fire<=0)throw new ArgumentException("Geçerli emir ve miktar gerekli.");Miktarlar(uretilen,fire);decimal hesaplananTuketimKg=0;using SqlConnection baglanti = new SqlConnection(connection);
                baglanti.Open();
                using SqlTransaction islem = baglanti.BeginTransaction(IsolationLevel.Serializable);
access.Yetki(baglanti,islem,"PRODUCTION.COMPLETE");
                try
                {
                    int mamulId, receteId;
                    decimal planlanan, hedefKg;
                    decimal eskiUretilen, eskiFire;
                    string birim;
                    using (SqlCommand k = new SqlCommand(
                        "SELECT MamulStokId, ReceteId, MiktarBirimi, PlanlananMiktar, HedefAgirlikKg, UretilenMiktar, FireMiktari " +
                        "FROM dbo.UretimEmirleri WITH (UPDLOCK, HOLDLOCK) " +
                        "WHERE Id=@Emir AND Durum=N'Üretimde';", baglanti, islem))
                    {
                        k.Parameters.Add("@Emir", SqlDbType.Int).Value = emirId;
                        using SqlDataReader r = k.ExecuteReader();
                        if (!r.Read()) throw new InvalidOperationException("Emir artık Üretimde değil. Listeyi yenileyin.");
                        mamulId = r.GetInt32(0);
                        if (r.IsDBNull(1)) throw new InvalidOperationException("Bu emir reçetesiz; otomatik stok işlenemez.");
                        receteId = r.GetInt32(1);
                        birim = r.IsDBNull(2) ? "" : r.GetString(2);
                        planlanan = r.GetDecimal(3);
                        if (r.IsDBNull(4)) throw new InvalidOperationException("Hedef kilogram tanımlanmamış.");
                        hedefKg = r.GetDecimal(4);
                        eskiUretilen = r.GetDecimal(5);
                        eskiFire = r.GetDecimal(6);
                    }
                    decimal paketlenmis = UretimPaketlenmisToplam(baglanti, islem, emirId);
                    if (uretilen < paketlenmis)
                        throw new InvalidOperationException("Tamamlanacak sağlam ürün paketlenmiş " +
                            uretimYazi(paketlenmis) + " adetten az olamaz.");
                    string? standartBirim = UretimBiriminiNormallestir(birim);
                    if (standartBirim == null || planlanan <= 0m || hedefKg <= 0m)
                        throw new InvalidOperationException("Emirde geçerli birim veya hedef kilogram bilgisi bulunamadı.");
                    if (standartBirim == "adet" && (decimal.Truncate(uretilen) != uretilen || decimal.Truncate(fire) != fire))
                        throw new InvalidOperationException("Adet birimindeki sağlam ürün ve fire miktarları tam sayı olmalıdır.");
                    if (standartBirim == "kg" && planlanan != hedefKg)
                        throw new InvalidOperationException("KG üretim emrinde hedef ağırlık planlanan miktarla eşleşmiyor.");
                    decimal toplamGerceklesen = uretilen + fire;
                    hesaplananTuketimKg = decimal.Round(
                        hedefKg * toplamGerceklesen / planlanan, 3, MidpointRounding.AwayFromZero);
                    if (hesaplananTuketimKg <= 0m || hesaplananTuketimKg > 999999999999999.999m)
                        throw new InvalidOperationException("Hesaplanan tüketim miktarı KG olarak kaydedilemeyecek kadar küçük veya büyük.");

                    // Üretim stok işleminde emir başına tek kayıt veritabanı UNIQUE ile de korunur.
                    using (SqlCommand k = new SqlCommand(
                        "SELECT COUNT_BIG(*) FROM dbo.UretimStokIslemleri WITH (UPDLOCK, HOLDLOCK) " +
                        "WHERE UretimEmriId=@Emir;", baglanti, islem))
                    {
                        k.Parameters.Add("@Emir", SqlDbType.Int).Value = emirId;
                        if (Convert.ToInt64(k.ExecuteScalar()) != 0)
                            throw new InvalidOperationException("Bu üretim emri daha önce stoklara işlendi; ikinci işlem engellendi.");
                    }

                    string mamulBirim;
                    using (SqlCommand k = new SqlCommand(
                        "SELECT Birim FROM dbo.StokKartlari WITH (UPDLOCK,HOLDLOCK) " +
                        "WHERE Id=@Mamul AND Aktif=1 AND StokTipi IN (N'Başlık',N'Mandallı',N'Kangal');", baglanti, islem))
                    {
                        k.Parameters.Add("@Mamul", SqlDbType.Int).Value = mamulId;
                        mamulBirim = Convert.ToString(k.ExecuteScalar()) ?? "";
                    }
                    if (UretimBiriminiNormallestir(mamulBirim) != standartBirim)
                        throw new InvalidOperationException("Mamul stok kartının birimi üretim emrinin birimiyle aynı olmalıdır. " +
                            "Örneğin stok kartı Metre ise emir de metre olmalıdır. Otomatik dönüşüm yapılmaz.");

                    // SQL'de saklanan sabit reçete; değiştirilen güncel reçeteye BAKILMAZ.
                    var oranlar = new List<(int StokId, decimal Oran, string Birim, decimal Gram, decimal Kesir)>();
                    decimal toplamOran = 0m;
                    decimal toplamTamGram = 0m;
                    using (SqlCommand k = new SqlCommand(
                        "SELECT a.HammaddeStokId, a.YuzdeOrani, s.Birim, s.StokTipi, s.Aktif " +
                        "FROM dbo.UretimEmriReceteAnlikKalemleri a WITH (HOLDLOCK) " +
                        "JOIN dbo.StokKartlari s WITH (UPDLOCK,HOLDLOCK) ON s.Id=a.HammaddeStokId " +
                        "WHERE a.UretimEmriId=@Emir ORDER BY a.HammaddeStokId;", baglanti, islem))
                    {
                        k.Parameters.Add("@Emir", SqlDbType.Int).Value = emirId;
                        using SqlDataReader r = k.ExecuteReader();
                        while (r.Read())
                        {
                            int stokId = r.GetInt32(0);
                            decimal oran = r.GetDecimal(1);
                            string hBirim = r.GetString(2);
                            string stokTipi = r.GetString(3);
                            bool aktif = r.GetBoolean(4);
                            if (!aktif || stokId == mamulId || stokTipi != "Hammadde" || UretimBiriminiNormallestir(hBirim) != "kg")
                                throw new InvalidOperationException("Reçetedeki hammaddeler aktif Hammadde ve KG birimli olmalıdır.");
                            decimal hamGram = hesaplananTuketimKg * 1000m * oran / 100m;
                            decimal tamGram = decimal.Truncate(hamGram);
                            oranlar.Add((stokId, oran, hBirim, tamGram, hamGram - tamGram));
                            toplamOran += oran;
                            toplamTamGram += tamGram;
                        }
                    }
                    if (oranlar.Count == 0 || toplamOran != 100m)
                        throw new InvalidOperationException("Üretim başlangıcında sabitlenmiş geçerli (%100) reçete bulunamadı. " +
                            "Eski Üretimde emirleri otomatik işleme uygun değildir; yeni test emri oluşturun.");

                    // 0.001 KG (1 gram) seviyesinde toplam korunur; yuvarlama farkı en büyük kalanlara dağıtılır.
                    int kalanGram = decimal.ToInt32(hesaplananTuketimKg * 1000m - toplamTamGram);
                    if (kalanGram < 0 || kalanGram > oranlar.Count)
                        throw new InvalidOperationException("Reçete kilogram yuvarlaması doğrulanamadı.");
                    for (int i = 0; i < kalanGram; i++)
                    {
                        int enBuyuk = -1;
                        decimal enBuyukKesir = -1m;
                        for (int j = 0; j < oranlar.Count; j++)
                        {
                            if (oranlar[j].Kesir > enBuyukKesir)
                            {
                                enBuyuk = j;
                                enBuyukKesir = oranlar[j].Kesir;
                            }
                        }
                        var g = oranlar[enBuyuk];
                        oranlar[enBuyuk] = (g.StokId, g.Oran, g.Birim, g.Gram + 1m, -1m);
                    }

                    // Şartlar sağlanırsa öncelikle stok işlem başlığını yarat; herhangi bir hata tüm işlemi geri alır.
                    long stokIslemId;
                    using (SqlCommand k = new SqlCommand(
                        "INSERT INTO dbo.UretimStokIslemleri " +
                        "(UretimEmriId,ReceteId,MamulMiktari,FireMiktari,MamulBirimi,GerceklesenTuketimKg) " +
                        "OUTPUT INSERTED.Id VALUES (@Emir,@Recete,@Mamul,@Fire,@Birim,@Tuketim);", baglanti, islem))
                    {
                        k.Parameters.Add("@Emir", SqlDbType.Int).Value = emirId;
                        k.Parameters.Add("@Recete", SqlDbType.Int).Value = receteId;
                        UretimDecimalParametreEkle(k, "@Mamul", uretilen);
                        UretimDecimalParametreEkle(k, "@Fire", fire);
                        k.Parameters.Add("@Birim", SqlDbType.NVarChar, 20).Value = mamulBirim;
                        UretimDecimalParametreEkle(k, "@Tuketim", hesaplananTuketimKg);
                        stokIslemId = Convert.ToInt64(k.ExecuteScalar());
                    }

                    foreach (var kalem in oranlar)
                    {
                        decimal miktarKg = kalem.Gram / 1000m;
                        if (miktarKg == 0m) continue; // SQL stok hareketinde pozitif miktar şartı var.
                        using (SqlCommand k = new SqlCommand(
                            "UPDATE dbo.StokBakiyeleri WITH (UPDLOCK) SET Miktar=Miktar-@Miktar, " +
                            "SonGuncelleme=SYSDATETIME() " +
                            "WHERE StokKartId=@Stok AND Birim=@Birim AND Miktar>=@Miktar;", baglanti, islem))
                        {
                            k.Parameters.Add("@Stok", SqlDbType.Int).Value = kalem.StokId;
                            k.Parameters.Add("@Birim", SqlDbType.NVarChar, 20).Value = kalem.Birim;
                            UretimDecimalParametreEkle(k, "@Miktar", miktarKg);
                            if (k.ExecuteNonQuery() != 1)
                                throw new InvalidOperationException("Hammadde stok bakiyesi bulunamadı veya yetersiz. " +
                                    "Stok kartı ID: " + kalem.StokId + "; gereken: " + miktarKg.ToString("0.###", CultureInfo.GetCultureInfo("tr-TR")) + " KG. " +
                                    "Açılış stoku veya sonraki giriş işlemlerini kontrol edin.");
                        }
                        using (SqlCommand k = new SqlCommand(
                            "INSERT INTO dbo.StokHareketleri " +
                            "(StokKartId,UretimStokIslemId,HareketTipi,Yon,Miktar,Birim,ReceteOrani,Aciklama) " +
                            "VALUES (@Stok,@Islem,N'URETIM_HAMMADDE_CIKIS',N'C',@Miktar,@Birim,@Oran,@Aciklama);", baglanti, islem))
                        {
                            k.Parameters.Add("@Stok", SqlDbType.Int).Value = kalem.StokId;
                            k.Parameters.Add("@Islem", SqlDbType.BigInt).Value = stokIslemId;
                            UretimDecimalParametreEkle(k, "@Miktar", miktarKg);
                            k.Parameters.Add("@Birim", SqlDbType.NVarChar, 20).Value = kalem.Birim;
                            UretimDecimalParametreEkle(k, "@Oran", kalem.Oran, 9, 4);
                            k.Parameters.Add("@Aciklama", SqlDbType.NVarChar, 500).Value = "Üretim emri #" + emirId + " hammadde tüketimi";
                            k.ExecuteNonQuery();
                        }
                    }
                    // Fire mamul stoğuna eklenmez; sadece emrin ve işlem başlığının FireMiktari alanında saklanır.
                    if (uretilen > 0m)
                    {
                        decimal? bakiye = null;
                        string? bakiyeBirim = null;
                        using (SqlCommand k = new SqlCommand(
                            "SELECT Birim, Miktar FROM dbo.StokBakiyeleri WITH (UPDLOCK,HOLDLOCK) " +
                            "WHERE StokKartId=@Mamul;", baglanti, islem))
                        {
                            k.Parameters.Add("@Mamul", SqlDbType.Int).Value = mamulId;
                            using SqlDataReader r = k.ExecuteReader();
                            if (r.Read())
                            {
                                bakiyeBirim = r.GetString(0);
                                bakiye = r.GetDecimal(1);
                            }
                        }
                        if (bakiye.HasValue)
                        {
                            if (!string.Equals(bakiyeBirim, mamulBirim, StringComparison.OrdinalIgnoreCase))
                                throw new InvalidOperationException("Mamul stok bakiyesindeki birim ile stok kartının birimi farklı.");
                            using SqlCommand k = new SqlCommand(
                                "UPDATE dbo.StokBakiyeleri SET Miktar=Miktar+@Miktar, SonGuncelleme=SYSDATETIME() " +
                                "WHERE StokKartId=@Mamul AND Birim=@Birim;", baglanti, islem);
                            k.Parameters.Add("@Mamul", SqlDbType.Int).Value = mamulId;
                            k.Parameters.Add("@Birim", SqlDbType.NVarChar, 20).Value = bakiyeBirim;
                            UretimDecimalParametreEkle(k, "@Miktar", uretilen);
                            if (k.ExecuteNonQuery() != 1) throw new InvalidOperationException("Mamul stok bakiyesi güncellenemedi.");
                        }
                        else
                        {
                            using SqlCommand k = new SqlCommand(
                                "INSERT INTO dbo.StokBakiyeleri (StokKartId,Birim,Miktar) " +
                                "VALUES (@Mamul,@Birim,@Miktar);", baglanti, islem);
                            k.Parameters.Add("@Mamul", SqlDbType.Int).Value = mamulId;
                            k.Parameters.Add("@Birim", SqlDbType.NVarChar, 20).Value = mamulBirim;
                            UretimDecimalParametreEkle(k, "@Miktar", uretilen);
                            k.ExecuteNonQuery();
                        }
                        using (SqlCommand k = new SqlCommand(
                            "INSERT INTO dbo.StokHareketleri " +
                            "(StokKartId,UretimStokIslemId,HareketTipi,Yon,Miktar,Birim,Aciklama) " +
                            "VALUES (@Mamul,@Islem,N'URETIM_MAMUL_GIRIS',N'G',@Miktar,@Birim,@Aciklama);", baglanti, islem))
                        {
                            k.Parameters.Add("@Mamul", SqlDbType.Int).Value = mamulId;
                            k.Parameters.Add("@Islem", SqlDbType.BigInt).Value = stokIslemId;
                            UretimDecimalParametreEkle(k, "@Miktar", uretilen);
                            k.Parameters.Add("@Birim", SqlDbType.NVarChar, 20).Value = mamulBirim;
                            k.Parameters.Add("@Aciklama", SqlDbType.NVarChar, 500).Value = "Üretim emri #" + emirId + " sağlam mamul girişi";
                            k.ExecuteNonQuery();
                        }
                    }
                    using (SqlCommand k = new SqlCommand(
                        "UPDATE dbo.UretimEmirleri SET UretilenMiktar=@Mamul, FireMiktari=@Fire, Durum=N'Tamamlandı' " +
                        "WHERE Id=@Emir AND Durum=N'Üretimde';", baglanti, islem))
                    {
                        k.Parameters.Add("@Emir", SqlDbType.Int).Value = emirId;
                        UretimDecimalParametreEkle(k, "@Mamul", uretilen);
                        UretimDecimalParametreEkle(k, "@Fire", fire);
                        if (k.ExecuteNonQuery() != 1)
                            throw new InvalidOperationException("Üretim durumu değişti; tüm stok hareketleri iptal edildi.");
                    }
                    // Daha once ara kayitta yazilan toplamlar ikinci kez sayilmaz.
                    UretimGunlukFarkKaydet(baglanti, islem, emirId,
                        uretilen - eskiUretilen, fire - eskiFire);
                    new IsletmeServisi(connection,user).UretimPartile(baglanti,islem,emirId,stokIslemId,mamulId,uretilen);
                    islem.Commit();
                }
                catch
                {
                    islem.Rollback();
                    throw;
                }return hesaplananTuketimKg;}
public void Paketle(int emirId,int adet,int paketSayisi,bool varsayilaniKaydet){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiUretimServisi.Paketle","",new object?[]{emirId,adet,paketSayisi,varsayilaniKaydet});return;}
if(emirId<1||adet is <1 or >1000000||paketSayisi<1)throw new ArgumentException("Paket bilgileri geçersiz.");long toplam=(long)adet*paketSayisi;using var baglanti = new SqlConnection(connection);
                baglanti.Open();
                using var islem = baglanti.BeginTransaction(IsolationLevel.Serializable);
access.Yetki(baglanti,islem,"PRODUCTION.COMPLETE");
                try
                {
                    int mamulId;
                    decimal uretilen;
                    string birim;
                    using (var k = new SqlCommand(
                        "SELECT MamulStokId, MiktarBirimi, UretilenMiktar " +
                        "FROM dbo.UretimEmirleri WITH (UPDLOCK,HOLDLOCK) " +
                        "WHERE Id=@Emir AND Durum IN (N'Üretimde',N'Tamamlandı');", baglanti, islem))
                    {
                        k.Parameters.Add("@Emir", SqlDbType.Int).Value = emirId;
                        using var r = k.ExecuteReader();
                        if (!r.Read()) throw new InvalidOperationException("Emir paketleme için uygun durumda değil.");
                        mamulId = r.GetInt32(0);
                        birim = r.IsDBNull(1) ? "" : r.GetString(1);
                        uretilen = r.GetDecimal(2);
                    }
                    if (UretimBiriminiNormallestir(birim) != "adet")
                        throw new InvalidOperationException("Paketleme yalnızca Adet birimli emirlerde yapılır.");
                    decimal paketlenmis = UretimPaketlenmisToplam(baglanti, islem, emirId);
                    if (paketlenmis + toplam > uretilen)
                        throw new InvalidOperationException("Kayıt engellendi. Sağlam ürün: " +
                            uretimYazi(uretilen) + ", önce paketli: " + uretimYazi(paketlenmis) +
                            ", yeni paket: " + toplam + ". Üretilenden fazlası paketlenemez.");
                    using (var k = new SqlCommand(
                        "INSERT INTO dbo.UretimPaketlemeKayitlari " +
                        "(UretimEmriId,PaketIciAdet,PaketSayisi,ToplamAdet,KaydedenKullaniciId) " +
                        "VALUES(@Emir,@Adet,@Sayisi,@Toplam,@K);", baglanti, islem))
                    {
                        k.Parameters.Add("@Emir", SqlDbType.Int).Value = emirId;
                        k.Parameters.Add("@Adet", SqlDbType.Int).Value = adet;
                        k.Parameters.Add("@Sayisi", SqlDbType.Int).Value = paketSayisi;
                        k.Parameters.Add("@Toplam", SqlDbType.BigInt).Value = toplam;
                        k.Parameters.Add("@K", SqlDbType.Int).Value = user;
                        if (k.ExecuteNonQuery() != 1) throw new InvalidOperationException("Paket kaydı yazılamadı.");
                    }
                    if (varsayilaniKaydet)
                    {
                        using var k = new SqlCommand(
                            "UPDATE dbo.StokKartlari SET PaketIciAdet=@Adet WHERE Id=@Id;", baglanti, islem);
                        k.Parameters.Add("@Adet", SqlDbType.Int).Value = adet;
                        k.Parameters.Add("@Id", SqlDbType.Int).Value = mamulId;
                        if (k.ExecuteNonQuery() != 1) throw new InvalidOperationException("Paket varsayılanı kaydedilemedi.");
                    }
                    islem.Commit();
                }
                catch { islem.Rollback(); throw; }}
public void ReceteKaydet(ErpEskiRecete g){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiUretimServisi.ReceteKaydet","",new object?[]{g});return;}
var receteKalemleri=ReceteTablosu(g);string kod=g.Kod,ad=g.Ad;using (var baglanti = new SqlConnection(connection))
                {
                    baglanti.Open();
                    using (var islem = baglanti.BeginTransaction())
                    { access.Yetki(baglanti,islem,"PRODUCTION.RECIPE");
                        try
                        {
                            // Açık formda seçilen mamul daha sonra pasife alınmış olabilir.
                            using (var kontrol = new SqlCommand(
                                "SELECT COUNT(*) FROM dbo.StokKartlari WHERE Id=@Stok AND Aktif=1 AND StokTipi IN (N'Başlık',N'Mandallı',N'Kangal');",
                                baglanti, islem))
                            {
                                kontrol.Parameters.Add("@Stok", SqlDbType.Int).Value = g.Mamul;
                                if (Convert.ToInt32(kontrol.ExecuteScalar()) != 1)
                                    throw new InvalidOperationException("Seçilen mamul stok kartı artık aktif değil. Mamul listesini yenileyin.");
                            }
                            int receteId;
                            if (g.Id is int mevcutReceteId)
                            {
                                receteId = mevcutReceteId;
                                const string guncelle =
                                    "UPDATE dbo.UretimReceteleri SET ReceteKodu=@Kod, ReceteAdi=@Ad, MamulStokId=@Mamul " +
                                    "WHERE Id=@Id AND Aktif=1;";
                                using (var komut = new SqlCommand(guncelle, baglanti, islem))
                                {
                                    komut.Parameters.Add("@Kod", SqlDbType.NVarChar, 30).Value = kod;
                                    komut.Parameters.Add("@Ad", SqlDbType.NVarChar, 150).Value = ad;
                                    komut.Parameters.Add("@Mamul", SqlDbType.Int).Value = g.Mamul;
                                    komut.Parameters.Add("@Id", SqlDbType.Int).Value = receteId;
                                    if (komut.ExecuteNonQuery() != 1)
                                        throw new InvalidOperationException("Bu reçete artık aktif değil veya bulunamadı. Listeyi yenileyin.");
                                }
                                // Bütün hammadde kalemleri aynı işlem içerisinde değiştirilir.
                                using (var komut = new SqlCommand(
                                    "DELETE FROM dbo.UretimReceteKalemleri WHERE ReceteId=@Id;", baglanti, islem))
                                {
                                    komut.Parameters.Add("@Id", SqlDbType.Int).Value = receteId;
                                    komut.ExecuteNonQuery();
                                }
                            }
                            else
                            {
                                const string ekle =
                                    "INSERT INTO dbo.UretimReceteleri (ReceteKodu, ReceteAdi, MamulStokId) " +
                                    "OUTPUT INSERTED.Id VALUES (@Kod,@Ad,@Mamul);";
                                using (var komut = new SqlCommand(ekle, baglanti, islem))
                                {
                                    komut.Parameters.Add("@Kod", SqlDbType.NVarChar, 30).Value = kod;
                                    komut.Parameters.Add("@Ad", SqlDbType.NVarChar, 150).Value = ad;
                                    komut.Parameters.Add("@Mamul", SqlDbType.Int).Value = g.Mamul;
                                    receteId = Convert.ToInt32(komut.ExecuteScalar());
                                }
                            }

                            foreach (DataRow satir in receteKalemleri.Rows)
                            {
                                // Kart pasife alınmışsa hammaddeyle reçeteyi kaydetmeye izin verme.
                                using (var kontrol = new SqlCommand(
                                    "SELECT COUNT(*) FROM dbo.StokKartlari WHERE Id=@Stok AND Aktif=1 AND StokTipi=N'Hammadde' AND UPPER(Birim)=N'KG' AND StokTipi=N'Hammadde';",
                                    baglanti, islem))
                                {
                                    kontrol.Parameters.Add("@Stok", SqlDbType.Int).Value = Convert.ToInt32(satir["HammaddeStokId"]);
                                    if (Convert.ToInt32(kontrol.ExecuteScalar()) != 1)
                                        throw new InvalidOperationException("Pasif veya silinmiş hammadde var: " + Convert.ToString(satir["Hammadde"]));
                                }
                                using (var komut = new SqlCommand(
                                    "INSERT INTO dbo.UretimReceteKalemleri (ReceteId,HammaddeStokId,YuzdeOrani) " +
                                    "VALUES (@Recete,@Stok,@Yuzde);", baglanti, islem))
                                {
                                    komut.Parameters.Add("@Recete", SqlDbType.Int).Value = receteId;
                                    komut.Parameters.Add("@Stok", SqlDbType.Int).Value = Convert.ToInt32(satir["HammaddeStokId"]);
                                    var oran = komut.Parameters.Add("@Yuzde", SqlDbType.Decimal);
                                    oran.Precision = 9;
                                    oran.Scale = 4;
                                    oran.Value = Convert.ToDecimal(satir["Yuzde"]);
                                    komut.ExecuteNonQuery();
                                }
                            }
                            islem.Commit();
                        }
                        catch
                        {
                            islem.Rollback();
                            throw;
                        }
                    }
                }}
public void EmirKaydet(ErpUretimEmri g){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiUretimServisi.EmirKaydet","",new object?[]{g});return;}
EmirDogrula(g);string emirNo=g.No,birim=g.Birim;decimal planlananMiktar=g.Plan;int? receteId=g.Recete;decimal? hedefKg=g.HedefKg;DateTime? baslangic=g.Baslangic,bitis=g.Bitis;using (SqlConnection baglanti = new SqlConnection(connection))
                {
                    baglanti.Open();
using var serverTx=baglanti.BeginTransaction(IsolationLevel.Serializable);access.Yetki(baglanti,serverTx,"PRODUCTION.COMPLETE");
using(var product=ErpModulServisi.Komut(baglanti,serverTx,"SELECT COUNT(*) FROM dbo.StokKartlari WITH(UPDLOCK,HOLDLOCK) WHERE Id=@m AND Aktif=1 AND StokTipi IN(N'Başlık',N'Mandallı',N'Kangal')",("@m",g.Mamul)))if(Convert.ToInt32(product.ExecuteScalar())!=1)throw new ArgumentException("Aktif mamul seçin.");
if(receteId.HasValue){using var recipe=ErpModulServisi.Komut(baglanti,serverTx,"SELECT COUNT(*),ISNULL(SUM(k.YuzdeOrani),0) FROM dbo.UretimReceteleri r WITH(UPDLOCK,HOLDLOCK) LEFT JOIN dbo.UretimReceteKalemleri k ON k.ReceteId=r.Id WHERE r.Id=@r AND r.MamulStokId=@m AND r.Aktif=1",("@r",receteId),("@m",g.Mamul));using var reader=recipe.ExecuteReader();reader.Read();if(reader.GetInt32(0)==0||reader.GetDecimal(1)!=100)throw new ArgumentException("Aktif ve toplamı %100 olan mamul reçetesi seçin.");}


                    string sorgu;
                    if (g.Id.HasValue)
                    {
                        sorgu =
                            "UPDATE dbo.UretimEmirleri SET MamulStokId = @MamulStokId, " +
                            "PlanlananMiktar = @PlanlananMiktar, MiktarBirimi=@Birim, " +
                            "ReceteId=@ReceteId, HedefAgirlikKg=@HedefKg, PlanlananBaslangic = @Baslangic, " +
                            "PlanlananBitis = @Bitis, Aciklama = @Aciklama " +
                            "WHERE Id = @Id AND Durum = N'Planlandı' AND UretilenMiktar = 0 AND FireMiktari = 0;";
                    }
                    else
                    {
                        sorgu =
                            "INSERT INTO dbo.UretimEmirleri " +
                            "(UretimEmriNo, MamulStokId, PlanlananMiktar, MiktarBirimi, ReceteId, HedefAgirlikKg, " +
                            "PlanlananBaslangic, PlanlananBitis, Durum, Aciklama) " +
                            "VALUES (@EmirNo, @MamulStokId, @PlanlananMiktar, @Birim, @ReceteId, @HedefKg, " +
                            "@Baslangic, @Bitis, N'Planlandı', @Aciklama);";
                    }

                    using (SqlCommand komut = new SqlCommand(sorgu,baglanti,serverTx))
                    {
                        if (!g.Id.HasValue)
                            komut.Parameters.Add("@EmirNo", SqlDbType.NVarChar, 30).Value = emirNo;

                        komut.Parameters.Add("@MamulStokId", SqlDbType.Int).Value =
                            g.Mamul;

                        SqlParameter miktarParametresi =
                            komut.Parameters.Add("@PlanlananMiktar", SqlDbType.Decimal);
                        miktarParametresi.Precision = 18;
                        miktarParametresi.Scale = 3;
                        miktarParametresi.Value = planlananMiktar;
                        komut.Parameters.Add("@Birim", SqlDbType.NVarChar, 10).Value = birim;
                        komut.Parameters.Add("@ReceteId", SqlDbType.Int).Value =
                            receteId.HasValue ? (object)receteId.Value : DBNull.Value;
                        SqlParameter kgParam = komut.Parameters.Add("@HedefKg", SqlDbType.Decimal);
                        kgParam.Precision = 18;
                        kgParam.Scale = 3;
                        kgParam.Value = hedefKg.HasValue ? (object)hedefKg.Value : DBNull.Value;

                        komut.Parameters.Add("@Baslangic", SqlDbType.DateTime2).Value =
                            baslangic.HasValue ? (object)baslangic.Value.Date : DBNull.Value;
                        komut.Parameters.Add("@Bitis", SqlDbType.DateTime2).Value =
                            bitis.HasValue ? (object)bitis.Value.Date : DBNull.Value;
                        komut.Parameters.Add("@Aciklama", SqlDbType.NVarChar, 500).Value =
                            string.IsNullOrWhiteSpace(g.Aciklama)
                                ? DBNull.Value
                                : g.Aciklama.Trim();

                        if (g.Id.HasValue)
                            komut.Parameters.Add("@Id", SqlDbType.Int).Value = g.Id.Value;

                        int etkilenenSatir = komut.ExecuteNonQuery();
                        if(g.Id.HasValue&&etkilenenSatir==0)throw new InvalidOperationException("Emir artık düzenlenemez. Listeyi yenileyin.");
                    }
                serverTx.Commit();}}
public void EmirSil(int id){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiUretimServisi.EmirSil","",new object?[]{id});return;}
if(id<1)throw new ArgumentException("Kayıt seçin.");using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);access.Yetki(c,t,"PRODUCTION.COMPLETE");using var q=ErpModulServisi.Komut(c,t,"DELETE FROM dbo.UretimEmirleri WHERE Id = @Id AND Durum = N'Planlandı' AND UretilenMiktar = 0 AND FireMiktari = 0;",("@Id",id));if(q.ExecuteNonQuery()!=1)throw new InvalidOperationException("Kayıt bulunamadı veya işlem için uygun durumda değil.");t.Commit();}
public void RecetePasif(int id){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiUretimServisi.RecetePasif","",new object?[]{id});return;}
if(id<1)throw new ArgumentException("Kayıt seçin.");using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);access.Yetki(c,t,"PRODUCTION.RECIPE");using var q=ErpModulServisi.Komut(c,t,"UPDATE dbo.UretimReceteleri SET Aktif=0 WHERE Id=@Id AND Aktif=1;",("@Id",id));if(q.ExecuteNonQuery()!=1)throw new InvalidOperationException("Kayıt bulunamadı veya işlem için uygun durumda değil.");t.Commit();}
public void ReceteAktif(int id){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiUretimServisi.ReceteAktif","",new object?[]{id});return;}
if(id<1)throw new ArgumentException("Kayıt seçin.");using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);access.Yetki(c,t,"PRODUCTION.RECIPE");using var q=ErpModulServisi.Komut(c,t,"UPDATE dbo.UretimReceteleri SET Aktif=1 WHERE Id=@Id AND Aktif=0;",("@Id",id));if(q.ExecuteNonQuery()!=1)throw new InvalidOperationException("Kayıt bulunamadı veya işlem için uygun durumda değil.");t.Commit();}
public void EmirIptal(int id){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiUretimServisi.EmirIptal","",new object?[]{id});return;}
if(id<1)throw new ArgumentException("Emir seçin.");using var c=access.Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);access.Yetki(c,t,"PRODUCTION.COMPLETE");using var q=ErpModulServisi.Komut(c,t,"UPDATE dbo.UretimEmirleri SET Durum = N'İptal' WHERE Id = @Id AND Durum = N'Planlandı' AND UretilenMiktar = 0 AND FireMiktari = 0;",("@Id",id));if(q.ExecuteNonQuery()!=1)throw new InvalidOperationException("Yalnız başlamamış üretim emri iptal edilebilir.");t.Commit();}
}

