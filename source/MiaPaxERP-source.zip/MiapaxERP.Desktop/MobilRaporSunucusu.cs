using System.Data;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Data.SqlClient;

namespace MiapaxERP.Desktop;

public sealed record MobilEsleme(string Adres, string AnahtarOzeti);
public sealed record MobilRapor(string Bolum, DateTimeOffset OkumaZamani, int Sinir, object[] Kayitlar);

// The listener is deliberately loopback-only. External access requires an HTTPS reverse proxy.
// No factory connection strings or marketplace credentials are ever returned to the phone.
public sealed class MobilRaporSunucusu : IAsyncDisposable
{
    WebApplication? app;
    readonly SemaphoreSlim reads = new(4);
    public bool Calisiyor => app is not null;
    public const int Port = 5188;
    public static string YeniAnahtar() => Convert.ToHexString(RandomNumberGenerator.GetBytes(32));
    public static string Ozet(string token) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(token)));
    public static bool AnahtarDogru(string? authorization, string digest)
    {
        if(authorization is null || !authorization.StartsWith("Bearer ",StringComparison.Ordinal) || authorization.Length!=71)return false;
        try{return CryptographicOperations.FixedTimeEquals(Convert.FromHexString(Ozet(authorization[7..])),Convert.FromHexString(digest));}
        catch(FormatException){return false;}
    }
    public static Uri AdresDogrula(string address)
    {
        if(!Uri.TryCreate(address,UriKind.Absolute,out var uri) || uri.Scheme!="https" || uri.IsLoopback ||
           uri.HostNameType!=UriHostNameType.Dns || !string.IsNullOrEmpty(uri.UserInfo) ||
           !string.IsNullOrEmpty(uri.Query) || !string.IsNullOrEmpty(uri.Fragment) || uri.AbsolutePath!="/" || !uri.IsDefaultPort)
            throw new ArgumentException("Dış erişim için https://rapor.firmaniz.com biçiminde HTTPS alan adı girin.");
        return uri;
    }
    public static void Kaydet(string file, MobilEsleme settings)
    {
        AdresDogrula(settings.Adres);
        if(Convert.FromHexString(settings.AnahtarOzeti).Length!=32)throw new ArgumentException("Eşleme anahtarı özeti geçersiz.");
        Directory.CreateDirectory(Path.GetDirectoryName(file)!);
        File.WriteAllText(file+".tmp",JsonSerializer.Serialize(settings));File.Move(file+".tmp",file,true);
    }
    public static MobilEsleme? Oku(string file)=>File.Exists(file)?JsonSerializer.Deserialize<MobilEsleme>(File.ReadAllText(file)):null;
    public async Task Baslat(string connection,int user,string digest,Func<bool> sessionActive)
    {
        if(app is not null)throw new InvalidOperationException("Mobil sunucu zaten açık.");
        var builder=WebApplication.CreateSlimBuilder(new WebApplicationOptions {Args=[]});
        builder.Logging.ClearProviders();
        builder.WebHost.UseKestrel(o=>{o.Listen(IPAddress.Loopback,Port);o.Limits.MaxRequestBodySize=0;o.Limits.MaxConcurrentConnections=32;o.AddServerHeader=false;});
        var candidate=builder.Build();
        candidate.Use(async(context,next)=>
        {
            context.Response.Headers.CacheControl="no-store, private";
            context.Response.Headers["X-Content-Type-Options"]="nosniff";
            if(!sessionActive()){context.Response.StatusCode=503;return;}
            if(!AnahtarDogru(context.Request.Headers.Authorization.ToString(),digest)){context.Response.StatusCode=401;return;}
            if(!await reads.WaitAsync(0,context.RequestAborted)){context.Response.StatusCode=429;context.Response.Headers.RetryAfter="5";return;}
            try{await next(context);}finally{reads.Release();}
        });
        candidate.MapGet("/api/mobile/rapor/{bolum}",async(string bolum,HttpContext ctx)=>
        {
            try{return Results.Json(await Task.Run(()=>MobilRaporOku.Oku(connection,user,bolum,ctx.RequestAborted),ctx.RequestAborted));}
            catch(UnauthorizedAccessException){return Results.Json(new{mesaj="Bu rapor için yetkiniz yok."},statusCode:403);}
            catch(ArgumentException){return Results.Json(new{mesaj="Rapor bölümü bulunamadı."},statusCode:404);}
            catch(SqlException){return Results.Json(new{mesaj="Fabrika veritabanına ulaşılamadı veya bu modül kurulmamış."},statusCode:503);}
        });
        try{await candidate.StartAsync();app=candidate;}catch{await candidate.DisposeAsync();throw;}
    }
    public async ValueTask DisposeAsync()
    {
        var current=app;app=null;if(current is null)return;
        using var timeout=new CancellationTokenSource(TimeSpan.FromSeconds(5));
        try{await current.StopAsync(timeout.Token);}finally{await current.DisposeAsync();}
    }
}

public static class MobilRaporOku
{
    public static (string Yetki,string Sorgu) Tanim(string section)=>section switch
    {
        "stok"=>("STOCK.VIEW","SELECT TOP(200) s.StokKodu AS [Stok kodu],s.StokAdi AS [Ürün],s.Birim AS [Birim],COALESCE(b.Miktar,0) AS [Bakiye] FROM dbo.StokKartlari s LEFT JOIN dbo.StokBakiyeleri b ON b.StokKartId=s.Id WHERE s.Aktif=1 ORDER BY s.StokKodu,s.Id"),
        "satinalma"=>("PURCHASE.VIEW","SELECT TOP(200) BelgeNo AS [Belge],Tarih AS [Tarih],Tedarikci AS [Tedarikçi],Malzeme AS [Malzeme],Miktar AS [Miktar],Birim AS [Birim],BirimFiyat AS [Birim fiyat],ParaBirimi AS [Döviz],Durum AS [Durum] FROM dbo.BERP_SatinAlma ORDER BY Id DESC"),
        "satis"=>("CUSTOMER.VIEW","""
            SELECT TOP(200) b.BelgeNo AS [Satış no],c.Unvan AS [Müşteri],b.Tarih AS [Tarih],
            b.GenelToplam AS [Toplam (TRY)],b.OdemeDurumu AS [Ödeme durumu]
            FROM dbo.BoruERP_YeniBelgeler b JOIN dbo.CariKartlari c ON c.Id=b.CariId
            WHERE b.BelgeTuru=N'S' ORDER BY b.Id DESC
            """),
        "uretim"=>("PRODUCTION.VIEW","""
            SELECT TOP(200) ue.Id AS [Emir no],sk.StokKodu AS [Stok kodu],sk.StokAdi AS [Ürün],
            ue.Durum AS [Durum],ue.PlanlananMiktar AS [Planlanan],ue.UretilenMiktar AS [Üretilen],
            COALESCE(ue.MiktarBirimi,sk.Birim) AS [Birim]
            FROM dbo.UretimEmirleri ue JOIN dbo.StokKartlari sk ON sk.Id=ue.MamulStokId ORDER BY ue.Id DESC
            """),
        "muhasebe"=>("FINANCE.VIEW","""
            SELECT TOP(200) h.HesapAdi AS [Hesap],h.ParaBirimi AS [Döviz],
            COALESCE(SUM(CASE WHEN f.HareketTipi=N'Giriş' THEN f.Tutar WHEN f.HareketTipi=N'Çıkış' THEN -f.Tutar ELSE 0 END),0) AS [Bakiye]
            FROM dbo.FinansHesaplari h LEFT JOIN dbo.FinansHareketleri f ON f.HesapId=h.Id
            WHERE h.Aktif=1 GROUP BY h.Id,h.HesapAdi,h.ParaBirimi ORDER BY h.HesapAdi,h.Id
            """),
        "gelirgider"=>("FINANCE.VIEW","""
            SELECT TOP(200) g.Tarih AS [Tarih],g.Tur AS [Tür],h.Ad AS [Hesap],g.Tutar AS [Tutar (TRY)],
            g.BelgeNo AS [Belge no],g.Aciklama AS [Açıklama],g.Iptal AS [İptal]
            FROM dbo.BoruERP_GelirGider g JOIN dbo.BoruERP_GGHesaplar h ON h.Kod=g.HesapKodu
            ORDER BY g.Tarih DESC,g.Id DESC
            """),
        _=>throw new ArgumentException("Bölüm bulunamadı.")
    };
    public static (string Yetki,string Sorgu) Tanim(string section,string sector)
    {
        var (permission,sql)=Tanim(section);
        if(sector=="RESTORAN"&&section is "satis" or "uretim")
        {
            permission="RESTAURANT.VIEW";
            sql=section=="satis"?"""
                SELECT TOP(200) a.Id AS [Adisyon no],m.Ad AS [Masa],a.Acilis AS [Açılış],a.Durum AS [Durum],
                COALESCE(k.Toplam,0) AS [Toplam (TRY)],COALESCE(o.Odenen,0) AS [Net tahsilat (TRY)]
                FROM dbo.BERP200_Adisyon a JOIN dbo.BERP200_Masa m ON m.Id=a.MasaId
                OUTER APPLY(SELECT SUM(ROUND(Miktar*BirimFiyat,2)) AS Toplam FROM dbo.BERP200_AdisyonKalem WHERE AdisyonId=a.Id AND Iptal=0)k
                OUTER APPLY(SELECT SUM(Tutar) AS Odenen FROM dbo.BERP200_Odeme WHERE AdisyonId=a.Id AND IadeFinansId IS NULL)o ORDER BY a.Id DESC
                """:"""
                SELECT TOP(200) a.Id AS [Adisyon no],m.Ad AS [Masa],k.Ad AS [Ürün],k.Miktar AS [Miktar],s.Birim AS [Birim],k.MutfakDurumu AS [Durum]
                FROM dbo.BERP200_AdisyonKalem k JOIN dbo.BERP200_Adisyon a ON a.Id=k.AdisyonId
                JOIN dbo.BERP200_Masa m ON m.Id=a.MasaId JOIN dbo.StokKartlari s ON s.Id=k.MamulId
                WHERE a.Kapanis IS NULL AND k.Iptal=0 ORDER BY k.Id DESC
                """;
        }
        else if(sector!="BORU"&&section=="uretim")
            sql="""
                SELECT TOP(200) u.Id AS [Üretim no],u.Belge AS [Belge no],r.Ad AS [Reçete],u.Miktar AS [Üretilen],r.CiktiBirimi AS [Birim],N'Tamamlandı' AS [Durum]
                FROM dbo.BERP200_Uretim u JOIN dbo.BERP200_Recete r ON r.Id=u.ReceteId ORDER BY u.Id DESC
                """;
        return (permission,sql);
    }
    public static MobilRapor Oku(string connection,int user,string section,CancellationToken token=default)
    {
        LisansOturumu.Gerekli("MOBIL");
        var (permission,sql)=Tanim(section,LisansOturumu.Gecerli?.Sector??"BORU");var access=new ErpModulServisi(connection,user);
        using var c=access.Ac();access.Yetki(c,null,permission);
        using var cmd=ErpModulServisi.Komut(c,null,sql);cmd.CommandTimeout=15;
        using var cancel=token.Register(()=>cmd.Cancel());using var reader=cmd.ExecuteReader();
        var rows=new List<object>();
        while(reader.Read())
        {
            token.ThrowIfCancellationRequested();var row=new Dictionary<string,object?>();
            for(int i=0;i<reader.FieldCount;i++)row[reader.GetName(i)]=reader.IsDBNull(i)?null:reader.GetValue(i);
            rows.Add(row);
        }
        return new(section,DateTimeOffset.UtcNow,200,rows.ToArray());
    }
}
