using System.Data;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed partial class EskiTicariServisi(string connection,int user){
readonly ErpModulServisi access=new(connection,user);
SqlConnection Baglan()=>access.Ac();
void Zorunlu(SqlConnection c,SqlTransaction? t,string permission)=>access.Yetki(c,t,permission);
static SqlCommand Cmd(SqlConnection c,SqlTransaction? t,string sql,params(string,object?)[] ps){var q=ErpModulServisi.Komut(c,t,sql,ps);foreach(SqlParameter p in q.Parameters)if(p.SqlDbType==SqlDbType.Decimal){p.Precision=18;p.Scale=2;}return q;}
static void Text(string? v,int min,int max){if(v is null||v.Trim().Length<min||v.Length>max)throw new ArgumentException("Alan uzunluğu geçersiz.");}
static void Amount(decimal v){if(v<=0||v>9999999999999999.99m||decimal.Round(v,2)!=v)throw new ArgumentException("Tutar pozitif ve en fazla iki ondalıklı olmalı.");}
static void Choice(string name,string value)=>ErpEkranKurallari.Secim("TicariModullerPenceresi.xaml",name,value);

public void CariKaydet(int? duzenlenenCariId,string kod,string ad,string tip,string telefon,string vergiNo,string vergiDairesi,string adres){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiTicariServisi.CariKaydet","",new object?[]{duzenlenenCariId,kod,ad,tip,telefon,vergiNo,vergiDairesi,adres});return;}
Text(kod,2,40);Text(ad,2,200);Text(telefon,0,40);Text(vergiNo,0,20);Text(vergiDairesi,0,100);Text(adres,0,400);Choice("CmbCariTur",tip);using var con = Baglan(); using var trn = con.BeginTransaction(IsolationLevel.Serializable);
            Zorunlu(con, trn, "CUSTOMER.EDIT");
            using var cmd = Cmd(con, trn, duzenlenenCariId.HasValue ?
                "UPDATE dbo.CariKartlari SET CariKodu=@kod,Unvan=@ad,CariTipi=@tip,Telefon=@tel,VergiNo=@vergi,VergiDairesi=@vergiDairesi,Adres=@adres WHERE Id=@id;" :
                "INSERT INTO dbo.CariKartlari(CariKodu,Unvan,CariTipi,Telefon,VergiNo,VergiDairesi,Adres) VALUES(@kod,@ad,@tip,@tel,@vergi,@vergiDairesi,@adres);",
                ("@kod", kod), ("@ad", ad), ("@tip", tip), ("@tel", telefon),
                ("@vergi", vergiNo),
                ("@vergiDairesi", string.IsNullOrWhiteSpace(vergiDairesi) ? (object)DBNull.Value : vergiDairesi),
                ("@adres", string.IsNullOrWhiteSpace(adres) ? (object)DBNull.Value : adres),
                ("@id", duzenlenenCariId ?? -1));
            if (cmd.ExecuteNonQuery() != 1) throw new InvalidOperationException("Cari kartı bulunamadı.");
            trn.Commit();}
public void CariDurum(int id,bool aktif){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiTicariServisi.CariDurum","",new object?[]{id,aktif});return;}
if(id<1)throw new ArgumentException("Cari seçin.");using var con=Baglan(); using var tx=con.BeginTransaction(); Zorunlu(con,tx,"CUSTOMER.EDIT");
            using var cmd=Cmd(con,tx,"UPDATE dbo.CariKartlari SET Aktif=@a WHERE Id=@id;", ("@a", !aktif), ("@id",id));
            cmd.ExecuteNonQuery(); tx.Commit();}
public void CariHareketKaydet(int cari,decimal tutar,string aciklama,string tip,DateTime date){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiTicariServisi.CariHareketKaydet","",new object?[]{cari,tutar,aciklama,tip,date});return;}
Amount(tutar);Text(aciklama,3,400);Choice("CmbCariHareketTur",tip);using var con=Baglan(); using var tx=con.BeginTransaction(IsolationLevel.Serializable); Zorunlu(con,tx,"CUSTOMER.EDIT");
            using (var check=Cmd(con,tx,"SELECT COUNT(*) FROM dbo.CariKartlari WITH (UPDLOCK,HOLDLOCK) WHERE Id=@id AND Aktif=1;", ("@id",cari)))
                if (Convert.ToInt32(check.ExecuteScalar())!=1) throw new InvalidOperationException("Cari pasif veya bulunamadı.");
            using var cmd=Cmd(con,tx,"INSERT INTO dbo.CariHareketleri(CariId,Tarih,HareketTipi,Tutar,Aciklama,Kaynak,YapanKullaniciId) VALUES(@c,@d,@t,@v,@a,N'Manuel',@k);",
                ("@c",cari),("@d",date),("@t",tip),("@v",tutar),("@a",aciklama),("@k",user));
            cmd.ExecuteNonQuery(); tx.Commit();}
public void CariHareketTers(long id){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiTicariServisi.CariHareketTers","",new object?[]{id});return;}
if(id<1)throw new ArgumentException("Hareket seçin.");using var con=Baglan(); using var tx=con.BeginTransaction(IsolationLevel.Serializable); Zorunlu(con,tx,"CUSTOMER.EDIT");
            using (var linked=Cmd(con,tx,@"SELECT
(SELECT COUNT(*) FROM dbo.FinansHareketleri WITH(UPDLOCK,HOLDLOCK) WHERE CariHareketId=@id)+
(SELECT COUNT(*) FROM dbo.TicariBelgeler WITH(UPDLOCK,HOLDLOCK) WHERE CariHareketId=@id);", ("@id",id)))
                if (Convert.ToInt32(linked.ExecuteScalar())>0) throw new InvalidOperationException("Bu cari hareketi belge veya finans işlemine bağlı. Ters kaydı ilgili modülden yapın.");
            using var cmd=Cmd(con,tx,@"INSERT INTO dbo.CariHareketleri(CariId,Tarih,HareketTipi,Tutar,Aciklama,Kaynak,YapanKullaniciId,TersKayitId)
SELECT CariId,CONVERT(date,GETDATE()),CASE HareketTipi WHEN N'Borç' THEN N'Alacak' ELSE N'Borç' END,Tutar,
N'Ters kayıt - '+CONVERT(nvarchar(30),Id)+N' : '+Aciklama,N'Ters',@k,Id
FROM dbo.CariHareketleri WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND TersKayitId IS NULL
AND NOT EXISTS(SELECT 1 FROM dbo.CariHareketleri WHERE TersKayitId=@id);", ("@id",id),("@k",user));
            if(cmd.ExecuteNonQuery()!=1) throw new InvalidOperationException("Kayıt zaten terslenmiş veya ters kayıt seçilmiş.");
            tx.Commit();}
public void FinHesapKaydet(string kod,string ad,string hesapTur,string para){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiTicariServisi.FinHesapKaydet","",new object?[]{kod,ad,hesapTur,para});return;}
Text(kod,2,40);Text(ad,2,150);Choice("CmbFinHesapTur",hesapTur);Choice("CmbFinHesapBirim",para);using var con=Baglan();using var tx=con.BeginTransaction();Zorunlu(con,tx,"FINANCE.PAYMENT");
            using var cmd=Cmd(con,tx,"INSERT INTO dbo.FinansHesaplari(HesapKodu,HesapAdi,HesapTipi,ParaBirimi) VALUES(@k,@a,@t,@p);",
                ("@k",kod),("@a",ad),("@t",hesapTur),("@p",para));
            cmd.ExecuteNonQuery();tx.Commit();}
public void FinHesapDurum(int id,bool aktif){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiTicariServisi.FinHesapDurum","",new object?[]{id,aktif});return;}
if(id<1)throw new ArgumentException("Hesap seçin.");using var con=Baglan();using var tx=con.BeginTransaction();Zorunlu(con,tx,"FINANCE.PAYMENT");
            using var cmd=Cmd(con,tx,"UPDATE dbo.FinansHesaplari SET Aktif=@a WHERE Id=@id;",("@a",!aktif),("@id",id));
            cmd.ExecuteNonQuery();tx.Commit();}
public void FinHareketKaydet(int hesap,int? cari,decimal tutar,string tur,string aciklama,DateTime date){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiTicariServisi.FinHareketKaydet","",new object?[]{hesap,cari,tutar,tur,aciklama,date});return;}
Amount(tutar);Text(aciklama,3,400);Choice("CmbFinHareketTur",tur);using var con=Baglan();using var tx=con.BeginTransaction(IsolationLevel.Serializable);
            Zorunlu(con,tx,"FINANCE.PAYMENT");
            string para;
            using(var check=Cmd(con,tx,"SELECT ParaBirimi FROM dbo.FinansHesaplari WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Aktif=1;",("@id",hesap)))
                para=Convert.ToString(check.ExecuteScalar())??"";
            if(para.Length==0)throw new InvalidOperationException("Finans hesabı pasif veya bulunamadı.");
            if(cari.HasValue)
            {
                Zorunlu(con,tx,"CUSTOMER.EDIT");
                if(para!="TRY")throw new InvalidOperationException("Cari hesapların para birimi TRY. USD/EUR hesabından cari işlem için kur dönüşümü henüz eklenmedi.");
                using var check=Cmd(con,tx,"SELECT COUNT(*) FROM dbo.CariKartlari WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Aktif=1;",("@id",cari.Value));
                if(Convert.ToInt32(check.ExecuteScalar())!=1)throw new InvalidOperationException("Cari pasif veya bulunamadı.");
            }
            long? cariHareketId=null;
            if(cari.HasValue)
            {
                using var cariCmd=Cmd(con,tx,@"INSERT INTO dbo.CariHareketleri(CariId,Tarih,HareketTipi,Tutar,Aciklama,Kaynak,YapanKullaniciId)
VALUES(@c,@d,@t,@v,@a,N'Finans',@k);SELECT CAST(SCOPE_IDENTITY() AS bigint);",
                    ("@c",cari.Value),("@d",date),("@t",tur=="Giriş"?"Alacak":"Borç"),("@v",tutar),("@a",aciklama),("@k",user));
                cariHareketId=Convert.ToInt64(cariCmd.ExecuteScalar());
            }
            using var cmd=Cmd(con,tx,@"INSERT INTO dbo.FinansHareketleri(HesapId,CariId,CariHareketId,Tarih,HareketTipi,Tutar,Aciklama,YapanKullaniciId)
VALUES(@h,@c,@ch,@d,@t,@v,@a,@k);",("@h",hesap),("@c",(object?)cari??DBNull.Value),
                ("@ch",(object?)cariHareketId??DBNull.Value),("@d",date),("@t",tur),("@v",tutar),("@a",aciklama),("@k",user));
            cmd.ExecuteNonQuery();tx.Commit();}
public void FinHareketTers(long kaynak){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiTicariServisi.FinHareketTers","",new object?[]{kaynak});return;}
if(kaynak<1)throw new ArgumentException("Hareket seçin.");using var con=Baglan();using var tx=con.BeginTransaction(IsolationLevel.Serializable);
            Zorunlu(con,tx,"FINANCE.PAYMENT");
            using(var restaurant=Cmd(con,tx,"IF OBJECT_ID(N'dbo.BERP200_Odeme',N'U') IS NOT NULL IF EXISTS(SELECT 1 FROM dbo.BERP200_Odeme WHERE FinansHareketId=@id OR IadeFinansId=@id) THROW 51000,N'Adisyon tahsilatını restoran ekranından iade edin.',1;",("@id",kaynak)))restaurant.ExecuteNonQuery();
            long? cariHareket=null;
            using(var c=Cmd(con,tx,@"SELECT CariHareketId FROM dbo.FinansHareketleri WITH(UPDLOCK,HOLDLOCK)
WHERE Id=@id AND TersKayitId IS NULL
AND NOT EXISTS(SELECT 1 FROM dbo.FinansHareketleri WHERE TersKayitId=@id);",("@id",kaynak)))
            {var v=c.ExecuteScalar();if(v==null)throw new InvalidOperationException("Bu hareket bulunamadı veya zaten ters kaydedilmiş.");
             if(v!=DBNull.Value)cariHareket=Convert.ToInt64(v);}
            long? tersCariId=null;
            if(cariHareket.HasValue)
            {
                Zorunlu(con,tx,"CUSTOMER.EDIT");
                using var cariCmd=Cmd(con,tx,@"INSERT INTO dbo.CariHareketleri(CariId,Tarih,HareketTipi,Tutar,Aciklama,Kaynak,YapanKullaniciId,TersKayitId)
SELECT CariId,CONVERT(date,GETDATE()),CASE HareketTipi WHEN N'Borç' THEN N'Alacak' ELSE N'Borç' END,
Tutar,N'Finans ters kayıt - '+CONVERT(nvarchar(30),Id)+N' : '+Aciklama,N'Ters',@k,Id
FROM dbo.CariHareketleri WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND TersKayitId IS NULL
AND NOT EXISTS(SELECT 1 FROM dbo.CariHareketleri WHERE TersKayitId=@id);
SELECT CASE WHEN @@ROWCOUNT = 1 THEN CAST(SCOPE_IDENTITY() AS bigint) ELSE CAST(NULL AS bigint) END;",
                ("@id",cariHareket.Value),("@k",user));
                var v=cariCmd.ExecuteScalar();if(v==null||v==DBNull.Value)throw new InvalidOperationException("Bağlı cari hareketi terslenemedi.");
                tersCariId=Convert.ToInt64(v);
            }
            using var financeCmd=Cmd(con,tx,@"INSERT INTO dbo.FinansHareketleri(HesapId,CariId,CariHareketId,Tarih,HareketTipi,Tutar,Aciklama,YapanKullaniciId,TersKayitId)
SELECT HesapId,CariId,@ch,CONVERT(date,GETDATE()),CASE HareketTipi WHEN N'Giriş' THEN N'Çıkış' ELSE N'Giriş' END,
Tutar,N'Ters kayıt - '+CONVERT(nvarchar(30),Id)+N' : '+Aciklama,@k,Id
FROM dbo.FinansHareketleri WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND TersKayitId IS NULL
AND NOT EXISTS(SELECT 1 FROM dbo.FinansHareketleri WHERE TersKayitId=@id);",
                ("@id",kaynak),("@k",user),("@ch",(object?)tersCariId??DBNull.Value));
            if(financeCmd.ExecuteNonQuery()!=1)throw new InvalidOperationException("Finans hareketi terslenemedi.");
            tx.Commit();}
public void BelgeKaydet(string no,string tur,string aciklama,int cari,DateTime date,decimal ara,decimal oran){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiTicariServisi.BelgeKaydet","",new object?[]{no,tur,aciklama,cari,date,ara,oran});return;}
Text(no,2,80);Text(aciklama,3,400);Amount(ara);Choice("CmbBelgeTipi",tur);if(decimal.Truncate(oran)!=oran)throw new ArgumentException("KDV oranı geçersiz.");Choice("CmbBelgeKdv",oran.ToString("0",System.Globalization.CultureInfo.InvariantCulture));decimal kdv=decimal.Round(ara*oran/100m,2,MidpointRounding.AwayFromZero);decimal toplam=ara+kdv;Amount(toplam);using var con = Baglan(); using var tx = con.BeginTransaction(IsolationLevel.Serializable);
            Zorunlu(con, tx, "CUSTOMER.EDIT");
            using (var check = Cmd(con, tx, "SELECT COUNT(*) FROM dbo.CariKartlari WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Aktif=1;", ("@id", cari)))
                if (Convert.ToInt32(check.ExecuteScalar()) != 1) throw new InvalidOperationException("Cari pasif veya bulunamadı.");
            long hareket;
            using (var cmd = Cmd(con, tx, @"INSERT INTO dbo.CariHareketleri(CariId,Tarih,HareketTipi,Tutar,Aciklama,Kaynak,YapanKullaniciId)
VALUES(@c,@d,@t,@v,@a,N'Belge',@k); SELECT CAST(SCOPE_IDENTITY() AS bigint);",
                ("@c", cari), ("@d", date), ("@t", tur == "Satış" ? "Borç" : "Alacak"),
                ("@v", toplam), ("@a", tur + " belgesi " + no + ": " + aciklama), ("@k", user)))
                hareket = Convert.ToInt64(cmd.ExecuteScalar());
            using (var cmd = Cmd(con, tx, @"INSERT INTO dbo.TicariBelgeler
(BelgeNo,BelgeTipi,CariId,CariHareketId,BelgeTarihi,AraToplam,KdvOrani,KdvTutari,GenelToplam,Aciklama,YapanKullaniciId)
VALUES(@no,@tip,@c,@h,@date,@ara,@oran,@kdv,@genel,@a,@user);",
                ("@no", no), ("@tip", tur), ("@c", cari), ("@h", hareket), ("@date", date),
                ("@ara", ara), ("@oran", oran), ("@kdv", kdv), ("@genel", toplam), ("@a", aciklama), ("@user", user)))
                cmd.ExecuteNonQuery();
            tx.Commit();}
public void BelgeIptal(long id){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiTicariServisi.BelgeIptal","",new object?[]{id});return;}
if(id<1)throw new ArgumentException("Belge seçin.");using var con = Baglan(); using var tx = con.BeginTransaction(IsolationLevel.Serializable);
            Zorunlu(con, tx, "CUSTOMER.EDIT");
            long hareket;
            using (var cmd = Cmd(con, tx, "SELECT CariHareketId FROM dbo.TicariBelgeler WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Durum=N'Kaydedildi';", ("@id", id)))
            {
                var value = cmd.ExecuteScalar();
                if (value == null || value == DBNull.Value) throw new InvalidOperationException("Bu belge zaten iptal edilmiş veya bulunamadı.");
                hareket = Convert.ToInt64(value);
            }
            using (var cmd = Cmd(con, tx, @"INSERT INTO dbo.CariHareketleri(CariId,Tarih,HareketTipi,Tutar,Aciklama,Kaynak,YapanKullaniciId,TersKayitId)
SELECT CariId,CONVERT(date,GETDATE()),CASE HareketTipi WHEN N'Borç' THEN N'Alacak' ELSE N'Borç' END,
Tutar,N'Belge iptal ters kaydı - '+CONVERT(nvarchar(30),Id)+N' : '+Aciklama,N'Ters',@k,Id
FROM dbo.CariHareketleri WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND TersKayitId IS NULL
AND NOT EXISTS(SELECT 1 FROM dbo.CariHareketleri WHERE TersKayitId=@id);", ("@id", hareket), ("@k", user)))
                if (cmd.ExecuteNonQuery() != 1) throw new InvalidOperationException("İlgili cari hareketi zaten terslenmiş.");
            using (var cmd = Cmd(con, tx, "UPDATE dbo.TicariBelgeler SET Durum=N'İptal' WHERE Id=@id AND Durum=N'Kaydedildi';", ("@id", id)))
                if (cmd.ExecuteNonQuery() != 1) throw new InvalidOperationException("Belge iptal edilemedi.");
            tx.Commit();}
public void PlanliKaydet(string baslik,string birim,decimal tutar,DateTime vade,int? cari){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiTicariServisi.PlanliKaydet","",new object?[]{baslik,birim,tutar,vade,cari});return;}
Text(baslik,3,150);Amount(tutar);Choice("CmbPlanliBirim",birim);using var con = Baglan(); using var tx = con.BeginTransaction(); Zorunlu(con,tx,"FINANCE.PAYMENT");if(cari.HasValue){Zorunlu(con,tx,"CUSTOMER.VIEW");using var checkCari=Cmd(con,tx,"SELECT COUNT(*) FROM dbo.CariKartlari WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Aktif=1",("@id",cari));if(Convert.ToInt32(checkCari.ExecuteScalar())!=1)throw new ArgumentException("Aktif cari seçin.");}
            using var cmd = Cmd(con,tx,@"INSERT INTO dbo.PlanliOdemeler(Baslik,CariId,VadeTarihi,Tutar,ParaBirimi,YapanKullaniciId)
VALUES(@b,@c,@d,@v,@p,@k);",("@b",baslik),("@c",cari),("@d",vade),
                ("@v",tutar),("@p",birim),("@k",user));
            cmd.ExecuteNonQuery();tx.Commit();}
public void PlanliDurum(long id,string newStatus){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiTicariServisi.PlanliDurum","",new object?[]{id,newStatus});return;}
if(id<1)throw new ArgumentException("Plan seçin.");Choice("CmbPlanliYeniDurum",newStatus);using var con=Baglan(); using var tx=con.BeginTransaction(IsolationLevel.Serializable);
            Zorunlu(con,tx,"FINANCE.PAYMENT");
            using var cmd=Cmd(con,tx,@"UPDATE dbo.PlanliOdemeler SET Durum=@s,
IslemTarihi=CASE WHEN @s=N'Bekliyor' THEN NULL ELSE SYSDATETIME() END WHERE Id=@id;",("@s",newStatus),("@id",id));
            if(cmd.ExecuteNonQuery()!=1)throw new InvalidOperationException("Planlı ödeme bulunamadı.");
            tx.Commit();}
public void EvrakKaydet(string no,decimal tutar,DateTime date,string tip,string yon,int? cari,string para){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiTicariServisi.EvrakKaydet","",new object?[]{no,tutar,date,tip,yon,cari,para});return;}
Text(no,2,80);Amount(tutar);Choice("CmbEvrakTur",tip);Choice("CmbEvrakYon",yon);Choice("CmbEvrakBirim",para);using var con=Baglan();using var tx=con.BeginTransaction();Zorunlu(con,tx,"CHECKNOTE.EDIT");if(cari.HasValue){Zorunlu(con,tx,"CUSTOMER.VIEW");using var checkCari=Cmd(con,tx,"SELECT COUNT(*) FROM dbo.CariKartlari WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Aktif=1",("@id",cari));if(Convert.ToInt32(checkCari.ExecuteScalar())!=1)throw new ArgumentException("Aktif cari seçin.");}
            using var cmd=Cmd(con,tx,@"INSERT INTO dbo.CekSenetler(EvrakNo,EvrakTipi,Yon,CariId,VadeTarihi,Tutar,ParaBirimi,YapanKullaniciId)
VALUES(@n,@t,@y,@c,@d,@v,@p,@k);",("@n",no),("@t",tip),("@y",yon),
                ("@c",cari),("@d",date),("@v",tutar),("@p",para),("@k",user));
            cmd.ExecuteNonQuery();tx.Commit();}
public void EvrakDurum(long id,string durum){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EskiTicariServisi.EvrakDurum","",new object?[]{id,durum});return;}
if(id<1)throw new ArgumentException("Evrak seçin.");Choice("CmbEvrakYeniDurum",durum);using var con=Baglan();using var tx=con.BeginTransaction(IsolationLevel.Serializable);Zorunlu(con,tx,"CHECKNOTE.EDIT");
            string old;
            using (var check=Cmd(con,tx,"SELECT Durum FROM dbo.CekSenetler WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id;",("@id",id)))
                old=Convert.ToString(check.ExecuteScalar())??"";
            if(old.Length==0)throw new InvalidOperationException("Evrak bulunamadı.");
            if(old==durum){tx.Rollback();return;}
            using(var cmd=Cmd(con,tx,@"UPDATE dbo.CekSenetler SET Durum=@s,IslemTarihi=CASE WHEN @s=N'Bekliyor' THEN NULL ELSE SYSDATETIME() END
WHERE Id=@id;",("@s",durum),("@id",id)))
                if(cmd.ExecuteNonQuery()!=1)throw new InvalidOperationException("Evrak bulunamadı.");
            using(var cmd=Cmd(con,tx,@"INSERT INTO dbo.CekSenetDurumGecmisi(EvrakId,EskiDurum,YeniDurum,YapanKullaniciId)
VALUES(@id,@once,@sonra,@k);",("@id",id),("@once",old),("@sonra",durum),("@k",user)))
                cmd.ExecuteNonQuery();
            tx.Commit();}
}