using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace MiapaxERP.Desktop;

public static class TemaPencereServisi
{
    private static bool basladi;
    public static void Baslat()
    {
        if (basladi) return; basladi = true;
        EventManager.RegisterClassHandler(typeof(Window), FrameworkElement.LoadedEvent, new RoutedEventHandler((sender, _) =>
        {
            if (sender is Window window) { Uygula(window); GorunumRenkleri.Uygula(window, Tema170.Mevcut); }
        }));
    }
    public static void Uygula(Window window)
    {
        window.Icon = new System.Windows.Media.Imaging.BitmapImage(new Uri("pack://application:,,,/MiapaxERP.Desktop;component/Assets/MiapaxERP_App.png"));
        window.SetResourceReference(Control.FontFamilyProperty, "ErpFont");
        window.SetResourceReference(Control.ForegroundProperty, "ErpMetin");
        window.SetResourceReference(Control.BackgroundProperty, "ErpZemin");
        foreach (var node in Agac(window))
        {
            if (node is Border border)
            {
                Renk(border, Border.BackgroundProperty, false);
                Renk(border, Border.BorderBrushProperty, false, true);
                if (border.CornerRadius.TopLeft > 0) border.SetResourceReference(Border.CornerRadiusProperty, "ErpKose");
            }
            if (node is Panel panel) Renk(panel, Panel.BackgroundProperty, false);
            if (node is Control control)
            {
                Renk(control, Control.BackgroundProperty, false);
                Renk(control, Control.ForegroundProperty, true);
            }
            if (node is TextBlock text) Renk(text, TextBlock.ForegroundProperty, true);
        }
    }
    private static void Renk(FrameworkElement node, DependencyProperty property, bool foreground, bool line = false)
    {
        // Yalnız sabit nötr renkler dönüştürülür. Bağlamalar, durum renkleri ve dinamik kaynaklar korunur.
        if (node.ReadLocalValue(property) is not SolidColorBrush brush || brush.Color.A == 0) return;
        var c = brush.Color; int max = Math.Max(c.R, Math.Max(c.G,c.B)), min = Math.Min(c.R,Math.Min(c.G,c.B));
        bool neutral = max-min < 42 || new[] { "#FF1E3A5F", "#FF17263D", "#FF24364D", "#FF334155", "#FF475569", "#FF64748B" }.Contains(c.ToString());
        if (!neutral) return;
        if (foreground && max > 180) return; // Açık yazılar koyu menü/bantların üzerinde kalır.
        node.SetResourceReference(property, line ? "ErpCizgi" : foreground ? "ErpMetin" : max < 95 ? "ErpMenu" : "ErpKart");
    }
    private static IEnumerable<DependencyObject> Agac(DependencyObject node)
    {
        yield return node;
        for (int i=0;i<VisualTreeHelper.GetChildrenCount(node);i++)
            foreach (var child in Agac(VisualTreeHelper.GetChild(node,i))) yield return child;
    }
}
