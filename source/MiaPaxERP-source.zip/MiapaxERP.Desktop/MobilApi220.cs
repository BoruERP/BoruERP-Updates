using System.Net;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using System.Text.Json;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

public static class MobilApi220
{
 public static WebApplication Olustur(string connection,int port=5188,Action<WebApplicationBuilder>? configure=null,Action<KestrelServerOptions>? listen=null,Func<bool>? active=null){
  var b=WebApplication.CreateSlimBuilder(new WebApplicationOptions{Args=[]});b.Logging.ClearProviders();
  b.WebHost.UseKestrel(o=>{if(listen is null)o.Listen(IPAddress.Loopback,port);else listen(o);o.Limits.MaxRequestBodySize=64L*1024*1024;o.Limits.MaxConcurrentConnections=32;o.AddServerHeader=false;});
  configure?.Invoke(b);var app=b.Build();var accounts=new MobilHesapServisi(connection);var limit=new SemaphoreSlim(4);
  app.Use(async(ctx,next)=>{
   ctx.Response.Headers.CacheControl="no-store, private";ctx.Response.Headers["X-Content-Type-Options"]="nosniff";
   if(!await limit.WaitAsync(0,ctx.RequestAborted)){ctx.Response.StatusCode=429;ctx.Response.Headers.RetryAfter="5";return;}
   try{if(ctx.Request.Path.StartsWithSegments("/api/mobile/v2")){var body=ctx.Features.Get<Microsoft.AspNetCore.Http.Features.IHttpMaxRequestBodySizeFeature>();if(body is not null&&!body.IsReadOnly)body.MaxRequestBodySize=32768;}if(active?.Invoke()==false){ctx.Response.StatusCode=503;return;}
    if(ctx.Request.Path.StartsWithSegments("/api/mobile/v2")&&!(HttpMethods.IsGet(ctx.Request.Method)&&ctx.Request.Path=="/api/mobile/v2/health"))LisansOturumu.Gerekli("MOBIL");await next(ctx);}
   catch(UnauthorizedAccessException){ctx.Response.StatusCode=403;await ctx.Response.WriteAsJsonAsync(new{mesaj="Hesap, cihaz, lisans veya modül erişimi kapalı."});}
   catch(ArgumentException){ctx.Response.StatusCode=400;await ctx.Response.WriteAsJsonAsync(new{mesaj="Bilgileri kontrol edin."});}
   catch(JsonException){ctx.Response.StatusCode=400;}
   catch(KeyNotFoundException){ctx.Response.StatusCode=400;}
   catch(InvalidOperationException e){ctx.Response.StatusCode=409;await ctx.Response.WriteAsJsonAsync(new{mesaj=e.Message});}
   catch(SqlException e)when(e.Number is 2601 or 2627){ctx.Response.StatusCode=409;await ctx.Response.WriteAsJsonAsync(new{mesaj="Kayıt zaten var. Yenileyerek kontrol edin."});}
   catch(SqlException){ctx.Response.StatusCode=503;await ctx.Response.WriteAsJsonAsync(new{mesaj="Fabrika veritabanına ulaşılamadı veya modül kurulmamış."});}
   finally{limit.Release();}
  });
  HttpsApi.Kur(app,connection);
  // Yalnız yerel kurulum aracı kullanır; HTTPS vekili bu yolu yayımlamaz.
  app.MapGet("/internal/ready",(HttpContext ctx)=>{
   if(ctx.Connection.RemoteIpAddress is null||!IPAddress.IsLoopback(ctx.Connection.RemoteIpAddress))return Results.NotFound();
   if(LisansOturumu.Zorunlu&&LisansOturumu.Gecerli is null)return Results.StatusCode(503);
   using var con=new SqlConnection(connection);con.Open();using var q=new SqlCommand("SELECT CASE WHEN OBJECT_ID('dbo.Kullanicilar','U') IS NOT NULL AND OBJECT_ID('dbo.KullaniciRolAtamalari','U') IS NOT NULL AND OBJECT_ID('dbo.KullaniciRolleri','U') IS NOT NULL THEN 1 ELSE 0 END",con);
   return Convert.ToInt32(q.ExecuteScalar())==1?Results.Json(new{ready=true}):Results.StatusCode(503);
  });
  MobilKimlik Auth(HttpContext c){string header=c.Request.Headers.Authorization.ToString();if(!header.StartsWith("Bearer ",StringComparison.Ordinal))throw new UnauthorizedAccessException();return accounts.Dogrula(header[7..]);}
  app.MapGet("/api/mobile/v2/health",()=>Results.Json(new{service="MiapaxERP.MobileServer",api=2}));
  app.MapPost("/api/mobile/v2/pair",async(HttpContext c)=>{var d=await c.Request.ReadFromJsonAsync<JsonElement>();return Results.Json(accounts.Bagla(d.GetProperty("code").GetString()!,d.GetProperty("name").GetString()!));});
  app.MapGet("/api/mobile/v2/profile",(HttpContext c)=>{var k=Auth(c);return Results.Json(new{k.Id,k.Ad,k.Rol,modules=LisansOturumu.Gecerli?.Modules,offlineUntil=LisansOturumu.Gecerli?.ValidUntil??DateTimeOffset.UtcNow.AddDays(7)});});
  app.MapPost("/api/mobile/v2/rpc",async(HttpContext c)=>{
   var k=Auth(c);var d=await c.Request.ReadFromJsonAsync<JsonElement>();var s=new SahaServisi(connection,k.Kullanici,k);string? action=d.GetProperty("action").GetString();object result;
   if(action=="list")result=s.Liste(d.GetProperty("il").GetString()!,d.GetProperty("ilce").GetString()!,d.GetProperty("koy").GetString()!);
   else if(action=="province")result=s.IlGorusmeleri(d.GetProperty("il").GetString()!,d.GetProperty("ilce").GetString(),d.GetProperty("search").GetString(),d.GetProperty("offset").GetInt32());
   else if(action=="load")result=s.Oku(d.GetProperty("id").GetGuid());
   else if(action=="save")result=new{version=s.Kaydet(d.GetProperty("data").Deserialize<SahaMusterisi>(SahaServisi.Json)!,d.GetProperty("version").ValueKind==JsonValueKind.Null?null:d.GetProperty("version").GetString(),d.GetProperty("visitId").GetGuid(),d.GetProperty("visitDate").GetDateTimeOffset(),d.GetProperty("visit").GetString()!,d.GetProperty("operation").GetGuid())};
   else if(action=="report"){if(k.Rol!="PATRON")throw new UnauthorizedAccessException();result=MobilRaporOku.Oku(connection,k.Kullanici,d.GetProperty("section").GetString()!,c.RequestAborted);}
   else throw new ArgumentException();return Results.Json(result,SahaServisi.Json);
  });return app;
 }
}
