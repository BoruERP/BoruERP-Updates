using System.Windows;
using System.Windows.Controls;
namespace MiapaxERP.Desktop;
internal sealed class HttpsSifrePenceresi:Window
{
    internal HttpsSifrePenceresi(Window owner,string address,string username,bool recovery)
    {
        Owner=owner;Title="MiaPaxERP · "+(recovery?"Şifre kurtarma":"Şifre yenileme");Width=520;Height=550;WindowStartupLocation=WindowStartupLocation.CenterOwner;var p=new StackPanel{Margin=new Thickness(26)};Content=p;p.Children.Add(new TextBlock{Text=recovery?"Tek kullanımlık kurtarma kodunuzla yeni şifre belirleyin.":"Mevcut veya ilk giriş şifrenizle yeni şifre belirleyin.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,0,0,18)});p.Children.Add(new TextBlock{Text="Kullanıcı adı"});var name=new TextBox{Text=username,MaxLength=60,MinHeight=34};p.Children.Add(name);
        PasswordBox Field(string label){p.Children.Add(new TextBlock{Text=label,Margin=new Thickness(0,12,0,5)});var box=new PasswordBox{MaxLength=128,MinHeight=34};p.Children.Add(box);return box;}
        var old=Field(recovery?"Kurtarma kodu":"Mevcut / ilk giriş şifresi");var pass=Field("Yeni şifre (12–128 karakter)");var confirm=Field("Yeni şifre tekrar");var save=new Button{Content="Şifreyi güncelle",Padding=new Thickness(14),Margin=new Thickness(0,18,0,10)};p.Children.Add(save);var state=new TextBlock{TextWrapping=TextWrapping.Wrap};p.Children.Add(state);
        save.Click+=async(_,_)=>{save.IsEnabled=false;try{if(pass.Password.Length<12||pass.Password!=confirm.Password)throw new ArgumentException("Şifre en az 12 karakter olmalı ve tekrar alanıyla aynı olmalı.");using var client=new HttpsIstemci(address);string user=name.Text.Trim(),previous=old.Password,next=pass.Password;old.Clear();pass.Clear();confirm.Clear();if(recovery)await client.SifreKurtar(new(user,previous,next));else await client.SifreDegistir(new(user,previous,next));state.Text="Şifre güncellendi. Bu pencereyi kapatıp yeni şifrenizle giriş yapın.";}catch(Exception e){state.Text=e.Message;}finally{old.Clear();pass.Clear();confirm.Clear();save.IsEnabled=true;}};
    }
}
