using SqlConnection = MiapaxERP.Desktop.ErpSqlConnection;
using SqlCommand = MiapaxERP.Desktop.ErpSqlCommand;
using SqlTransaction = MiapaxERP.Desktop.ErpSqlTransaction;
using SqlDataReader = MiapaxERP.Desktop.ErpSqlReader;
using SqlDataAdapter = MiapaxERP.Desktop.ErpSqlDataAdapter;
using System;
using System.Data;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop
{
 public partial class StokFiyatPenceresi : Window
 {
  private readonly string connectionString;
  private readonly int stokId;
  private static readonly CultureInfo Tr = CultureInfo.GetCultureInfo("tr-TR");
  public StokFiyatPenceresi(string connectionString, int stokId, string stokKodu)
  {
   InitializeComponent(); this.connectionString=connectionString; this.stokId=stokId;
   Baslik.Text="Stok fiyatları: "+stokKodu;
   using var con=new SqlConnection(connectionString); con.Open();
   if (!TabloVar(con)) throw new InvalidOperationException("StokFiyatlari tablosu eksik. Önce 04_Ek_Ozellikler_Guvenli_Migrasyon.sql dosyasını çalıştırın.");
   using var cmd=new SqlCommand("SELECT AlisMaliyeti,BayiSatisFiyati,PerakendeSatisFiyati,ParaBirimi FROM dbo.StokFiyatlari WHERE StokKartId=@id",con);
   cmd.Parameters.Add("@id",SqlDbType.Int).Value=stokId;
   using var rd=cmd.ExecuteReader();
   if (rd.Read())
   {
    Alis.Text=rd.IsDBNull(0)?"":rd.GetDecimal(0).ToString("0.####",Tr);
    Bayi.Text=rd.IsDBNull(1)?"":rd.GetDecimal(1).ToString("0.####",Tr);
    Perakende.Text=rd.IsDBNull(2)?"":rd.GetDecimal(2).ToString("0.####",Tr);
    var pb=rd.GetString(3).Trim();
    foreach (ComboBoxItem item in ParaBirimi.Items)
     if (string.Equals(item.Content?.ToString(),pb,StringComparison.OrdinalIgnoreCase)) {ParaBirimi.SelectedItem=item;break;}
   }
  }
  private static bool TabloVar(SqlConnection con)
  {using var cmd=new SqlCommand("SELECT CASE WHEN OBJECT_ID(N'dbo.StokFiyatlari',N'U') IS NULL THEN 0 ELSE 1 END",con);return Convert.ToInt32(cmd.ExecuteScalar())==1;}
  private static decimal? FiyatOku(string text, string alan)
  {
   if(string.IsNullOrWhiteSpace(text))return null;
   if(!decimal.TryParse(text,NumberStyles.Number,Tr,out var n) || n<0 || n>99999999999999m)
    throw new InvalidOperationException(alan+" için sıfır veya pozitif geçerli sayı girin (örn. 125,50).");
   return n;
  }
  private void Kaydet_Click(object sender,RoutedEventArgs e)
  {
   try
   {
    var alis=FiyatOku(Alis.Text,"Alış"); var bayi=FiyatOku(Bayi.Text,"Bayi");
    var perakende=FiyatOku(Perakende.Text,"Perakende");
    var pb=(ParaBirimi.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "TRY";
if(HttpsOturumu.Uzak(connectionString)){new YardimciEkranServisi(connectionString,HttpsOturumu.Istemci!.Oturum!.Kullanici.Id).FiyatKaydet(stokId,alis,bayi,perakende,pb);}
else{    using var con=new SqlConnection(connectionString);con.Open();
    using var tran=con.BeginTransaction(IsolationLevel.Serializable);
    try
    {
     using var cmd=new SqlCommand(@"UPDATE dbo.StokFiyatlari WITH (UPDLOCK, HOLDLOCK)
SET AlisMaliyeti=@alis,BayiSatisFiyati=@bayi,PerakendeSatisFiyati=@perakende,
ParaBirimi=@pb,GuncellemeUtc=SYSUTCDATETIME() WHERE StokKartId=@id;
IF @@ROWCOUNT=0 INSERT INTO dbo.StokFiyatlari
(StokKartId,AlisMaliyeti,BayiSatisFiyati,PerakendeSatisFiyati,ParaBirimi)
VALUES (@id,@alis,@bayi,@perakende,@pb);",con,tran);
     cmd.Parameters.Add("@id",SqlDbType.Int).Value=stokId;
     foreach(var (key,val) in new[]{("@alis",alis),("@bayi",bayi),("@perakende",perakende)})
     {var p=cmd.Parameters.Add(key,SqlDbType.Decimal);p.Precision=18;p.Scale=4;p.Value=(object?)val??DBNull.Value;}
     cmd.Parameters.Add("@pb",SqlDbType.Char,3).Value=pb;
     cmd.ExecuteNonQuery();tran.Commit();
    }
    catch {tran.Rollback();throw;}
}
    MessageBox.Show("Fiyatlar kaydedildi.");DialogResult=true;
   }
   catch(Exception ex){MessageBox.Show("Kayıt yapılamadı: "+ex.Message);}
  }
  private void Iptal_Click(object sender,RoutedEventArgs e){DialogResult=false;}
 }
}
