SET XACT_ABORT ON;
BEGIN TRANSACTION;
DECLARE @lock201 int;
EXEC @lock201=sys.sp_getapplock @Resource=N'MiapaxERP.Moduller201',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=15000;
IF @lock201<0 THROW 51000,N'Restoran kurulum kilidi alınamadı.',1;
IF OBJECT_ID(N'dbo.FinansHesaplari',N'U') IS NULL OR OBJECT_ID(N'dbo.FinansHareketleri',N'U') IS NULL THROW 51000,N'Önce mevcut muhasebe SQL altyapısını kurun.',1;
IF OBJECT_ID(N'dbo.BERP200_Masa',N'U') IS NULL
BEGIN
 CREATE TABLE dbo.BERP200_Masa(Id int IDENTITY PRIMARY KEY,Ad nvarchar(50) NOT NULL UNIQUE,Aktif bit NOT NULL DEFAULT 1);
 CREATE TABLE dbo.BERP200_Menu(Id int IDENTITY PRIMARY KEY,Ad nvarchar(160) NOT NULL UNIQUE,MamulId int NOT NULL REFERENCES dbo.StokKartlari(Id),ReceteId bigint NULL REFERENCES dbo.BERP200_Recete(Id),BirimFiyat decimal(18,2) NOT NULL CHECK(BirimFiyat>=0),Aktif bit NOT NULL DEFAULT 1,Surum rowversion);
 CREATE TABLE dbo.BERP200_Adisyon(Id bigint IDENTITY PRIMARY KEY,Anahtar uniqueidentifier NOT NULL UNIQUE,MasaId int NOT NULL REFERENCES dbo.BERP200_Masa(Id),Durum nvarchar(20) NOT NULL DEFAULT N'Açık' CHECK(Durum IN(N'Açık',N'Mutfakta',N'Hazır',N'Ödendi',N'İptal')),Acilis datetime2 NOT NULL DEFAULT SYSUTCDATETIME(),Kapanis datetime2 NULL,KullaniciId int NOT NULL,Surum rowversion);
 CREATE UNIQUE INDEX UX_BERP200_AcikMasa ON dbo.BERP200_Adisyon(MasaId) WHERE Kapanis IS NULL;
 CREATE TABLE dbo.BERP200_AdisyonKalem(Id bigint IDENTITY PRIMARY KEY,Anahtar uniqueidentifier NOT NULL UNIQUE,AdisyonId bigint NOT NULL REFERENCES dbo.BERP200_Adisyon(Id),MenuId int NOT NULL REFERENCES dbo.BERP200_Menu(Id),Ad nvarchar(160) NOT NULL,MamulId int NOT NULL REFERENCES dbo.StokKartlari(Id),ReceteId bigint NULL REFERENCES dbo.BERP200_Recete(Id),Miktar decimal(18,3) NOT NULL CHECK(Miktar>0),BirimFiyat decimal(18,2) NOT NULL CHECK(BirimFiyat>=0),Tuketim nvarchar(max) NOT NULL,Iptal bit NOT NULL DEFAULT 0,MutfakDurumu nvarchar(20) NOT NULL DEFAULT N'Yeni');
 CREATE TABLE dbo.BERP200_Odeme(Id bigint IDENTITY PRIMARY KEY,Anahtar uniqueidentifier NOT NULL UNIQUE,AdisyonId bigint NOT NULL REFERENCES dbo.BERP200_Adisyon(Id),HesapId int NOT NULL REFERENCES dbo.FinansHesaplari(Id),Tutar decimal(18,2) NOT NULL CHECK(Tutar>0),Yontem nvarchar(30) NOT NULL,Belge nvarchar(80) NOT NULL,FinansHareketId bigint NOT NULL REFERENCES dbo.FinansHareketleri(Id),Tarih datetime2 NOT NULL DEFAULT SYSUTCDATETIME(),IadeFinansId bigint NULL REFERENCES dbo.FinansHareketleri(Id),KullaniciId int NOT NULL);
 CREATE TABLE dbo.BERP200_Tuketim(AdisyonId bigint NOT NULL REFERENCES dbo.BERP200_Adisyon(Id),StokId int NOT NULL REFERENCES dbo.StokKartlari(Id),Birim nvarchar(20) NOT NULL,Miktar decimal(18,3) NOT NULL CHECK(Miktar>0),PRIMARY KEY(AdisyonId,StokId));
END;
INSERT dbo.Yetkiler(YetkiKodu,Modul,Islem,Aciklama,Aktif)
SELECT 'RESTAURANT.'+v.Kod,N'Restoran',v.Ad,N'Restoran '+v.Ad,1 FROM(VALUES('VIEW',N'Görüntüle'),('EDIT',N'Adisyon düzenle'),('KITCHEN',N'Mutfak durumu'),('PAYMENT',N'Tahsilat'),('REFUND',N'İade'))v(Kod,Ad)
WHERE NOT EXISTS(SELECT 1 FROM dbo.Yetkiler WHERE YetkiKodu='RESTAURANT.'+v.Kod);
IF NOT EXISTS(SELECT 1 FROM dbo.BERP_Sema WHERE Surum=201)INSERT dbo.BERP_Sema(Surum)VALUES(201);
COMMIT;