using System.Data;
using System.Globalization;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;

public sealed record ErpStokGirdisi(int? Id,string Kod,string Ad,int Tip,string Birim,string Aciklama,double? Cap,string Basinc,double? Uzunluk,string Renk,double? Kalinlik,string Hammadde,double? Agirlik,int? Kategori,int? AltKategori,Dictionary<int,string> Ozellikler);
public sealed record ErpStokHareketi(int Stok,string Yon,decimal Miktar,string Aciklama,bool SatinAlma,int? Tedarikci,DateTime? AlimTarihi,decimal Fiyat,string Para);
public sealed partial class EskiStokServisi(string connection,int user)
{
    readonly ErpModulServisi access=new(connection,user);
    static void Miktar(decimal value){if(value<=0||decimal.Round(value,3)!=value||value>999999999999999.999m)throw new ArgumentException("Miktar pozitif ve en fazla üç ondalıklı olmalı.");}
    static void Metin(string? s,int min,int max){if(s is null||s.Trim().Length<min||s.Length>max)throw new ArgumentException("Stok alanı uzunluğu geçersiz.");}
    static void Dogrula(ErpStokGirdisi g)
    {
        Metin(g.Kod,1,50);Metin(g.Ad,1,200);Metin(g.Aciklama,0,500);Metin(g.Basinc,0,30);Metin(g.Renk,0,30);Metin(g.Hammadde,0,60);
        if(g.Tip<=0||g.Birim is not("KG" or "Metre" or "Adet" or "Ton" or "Gram" or "Litre" or "M2" or "M3")||g.Ozellikler is null||g.Ozellikler.Count>200)throw new ArgumentException("Stok tipi, birim veya özel alanlar geçersiz.");
        foreach(var n in new[]{g.Cap,g.Uzunluk,g.Kalinlik,g.Agirlik})if(n.HasValue&&(!double.IsFinite(n.Value)||n.Value<=0||n.Value>999999999.999||Math.Round(n.Value,3)<=0))throw new ArgumentException("Teknik ölçü pozitif ve en az 0,001 olmalı.");
    }
    void StokSqlYetkisiZorunlu(SqlConnection c,SqlTransaction? t,string permission){access.Yetki(c,t,"STOCK.VIEW");access.Yetki(c,t,permission);}
    static object BosIseNull(string s)=>string.IsNullOrWhiteSpace(s)?DBNull.Value:s.Trim();
    static void SqlOndalikEkle(SqlCommand q,string name,double? value){var p=q.Parameters.Add(name,SqlDbType.Decimal);p.Precision=12;p.Scale=3;p.Value=value.HasValue?value.Value:DBNull.Value;}
    static void HareketOndalikParametre(SqlCommand q,string name,decimal value){var p=q.Parameters.Add(name,SqlDbType.Decimal);p.Precision=18;p.Scale=3;p.Value=value;}
    void DinamikKaydet(SqlConnection c,SqlTransaction t,int id,ErpStokGirdisi g)
    {
        int? category=g.AltKategori??g.Kategori;
        if(g.AltKategori.HasValue&&!g.Kategori.HasValue)throw new ArgumentException("Üst kategori gerekli.");
        foreach(var pair in new[]{(Id:g.Kategori,Parent:(int?)null),(Id:g.AltKategori,Parent:g.Kategori)})
        {
            if(!pair.Id.HasValue)continue;
            using var q=ErpModulServisi.Komut(c,t,"SELECT COUNT(*) FROM dbo.StokKategorileri WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND StokTipId=@tip AND Aktif=1 AND ((@ust IS NULL AND UstKategoriId IS NULL) OR UstKategoriId=@ust)",("@id",pair.Id),("@tip",g.Tip),("@ust",pair.Parent));
            if(Convert.ToInt32(q.ExecuteScalar())!=1)throw new ArgumentException("Kategori stok tipi veya üst kategoriyle uyuşmuyor.");
        }
        using(var clear=ErpModulServisi.Komut(c,t,"DELETE dbo.StokKategoriSecimleri WHERE StokKartId=@id;DELETE dbo.StokOzellikDegerleri WHERE StokKartId=@id",("@id",id)))clear.ExecuteNonQuery();
        if(category.HasValue){using var q=ErpModulServisi.Komut(c,t,"INSERT dbo.StokKategoriSecimleri(StokKartId,KategoriId) VALUES(@id,@kat)",("@id",id),("@kat",category));q.ExecuteNonQuery();}
        var defs=new List<(int Id,string Ad,string Tur,string Secenek,bool Zorunlu)>();
        using(var q=ErpModulServisi.Komut(c,t,"SELECT Id,AlanAdi,AlanTuru,ISNULL(Secenekler,N''),Zorunlu FROM dbo.StokOzellikTanimlari WITH(UPDLOCK,HOLDLOCK) WHERE StokTipId=@tip AND Aktif=1 AND (KategoriId IS NULL OR KategoriId=@kok OR KategoriId=@alt)",("@tip",g.Tip),("@kok",g.Kategori),("@alt",g.AltKategori)))
        {using var r=q.ExecuteReader();while(r.Read())defs.Add((r.GetInt32(0),r.GetString(1),r.GetString(2),r.GetString(3),r.GetBoolean(4)));}
        if(g.Ozellikler.Keys.Any(k=>!defs.Any(d=>d.Id==k)))throw new ArgumentException("Stok özellik tanımı değişti. Formu yenileyin.");
        foreach(var d in defs)
        {
            string value=g.Ozellikler.GetValueOrDefault(d.Id,"")?.Trim()??"";Metin(value,0,450);
            if(value.Length==0){if(d.Zorunlu)throw new ArgumentException("Zorunlu alan: "+d.Ad);continue;}
            if(d.Tur=="Sayı")
            {if(!decimal.TryParse(value,NumberStyles.AllowDecimalPoint|NumberStyles.AllowLeadingSign,CultureInfo.GetCultureInfo("tr-TR"),out decimal number)||number<0)throw new ArgumentException("Geçerli pozitif sayı gerekli: "+d.Ad);value=number.ToString(CultureInfo.InvariantCulture);}
            if(d.Tur=="Seçim"&&!d.Secenek.Split('|',StringSplitOptions.RemoveEmptyEntries|StringSplitOptions.TrimEntries).Contains(value))throw new ArgumentException("Geçersiz seçim: "+d.Ad);
            if(d.Tur=="Tarih"&&!DateTime.TryParseExact(value,"yyyy-MM-dd",CultureInfo.InvariantCulture,DateTimeStyles.None,out _))throw new ArgumentException("Geçerli tarih gerekli: "+d.Ad);
            using var q=ErpModulServisi.Komut(c,t,"INSERT dbo.StokOzellikDegerleri(StokKartId,OzellikId,Deger) VALUES(@id,@alan,@v)",("@id",id),("@alan",d.Id),("@v",value));q.ExecuteNonQuery();
        }
    }
}
