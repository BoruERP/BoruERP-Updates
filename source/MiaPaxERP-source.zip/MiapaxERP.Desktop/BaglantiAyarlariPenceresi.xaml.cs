using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;

namespace MiapaxERP.Desktop
{
    public partial class BaglantiAyarlariPenceresi : Window
    {
        public BaglantiAyarlariPenceresi()
        {
            InitializeComponent();
            var ayar = MiapaxERPBaglantiAyarlari.Oku();
            CmbRol.SelectedIndex = ayar.Rol == "Yan" ? 1 : 0;
            TxtSunucu.Text = ayar.Sunucu;
            TxtVeritabani.Text = ayar.Veritabani;
            ChkUzakVpn.IsChecked=ayar.UzakVpn;
            ChkSertifikaDogrula.IsChecked=ayar.SertifikaDogrula;
            TxtSertifikaAdi.Text=ayar.SertifikaSunucuAdi;
            TxtBaglantiSure.Text=ayar.BaglantiZamanAsimi.ToString();
            CmbKimlik.SelectedIndex = ayar.KimlikDogrulama == "Sql" ? 1 : 0;
            TxtSqlKullanici.Text = ayar.SqlKullanici;
            if (ayar.KimlikDogrulama == "Sql")
            {
                try { TxtSqlParola.Password = ayar.ParolayiCoz(); }
                catch (Exception) { TxtDurum.Text = "Kayıtlı SQL parolası okunamadı; lütfen yeniden girin."; }
            }
            KimlikAlanlariniGuncelle();
            var yerelIcerik = Content;
            Content = null;
            var sekmeler = new System.Windows.Controls.TabControl();
            var kolay = new TabItem { Header = "Kolay bağlantı · Ana / Yan PC / Mobil" };
            kolay.Content = new KolayBaglantiPaneli(this, () => sekmeler.SelectedIndex = 1);
            sekmeler.Items.Add(kolay);
            sekmeler.Items.Add(new TabItem { Header = "Yerel ağ / SQL ayarları", Content = yerelIcerik });
            Content = sekmeler;
        }

        private void KimlikSecimi_Degisti(object sender, SelectionChangedEventArgs e)
            => KimlikAlanlariniGuncelle();

        private void KimlikAlanlariniGuncelle()
        {
            if (PnlSqlKimlik == null || CmbKimlik == null) return;
            PnlSqlKimlik.Visibility = (CmbKimlik.SelectedItem as ComboBoxItem)?.Tag?.ToString() == "Sql"
                ? Visibility.Visible : Visibility.Collapsed;
        }

        private MiapaxERPBaglantiAyarlari FormuOku()
        {
            var ayar = new MiapaxERPBaglantiAyarlari
            {
                Rol = (CmbRol.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "Ana",
                Sunucu = TxtSunucu.Text.Trim(),
                Veritabani = TxtVeritabani.Text.Trim(),
                KimlikDogrulama = (CmbKimlik.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "Windows",
                SqlKullanici = TxtSqlKullanici.Text.Trim(),
                UzakVpn=ChkUzakVpn.IsChecked==true,
                SertifikaDogrula=ChkSertifikaDogrula.IsChecked==true,
                SertifikaSunucuAdi=TxtSertifikaAdi.Text.Trim(),
                BaglantiZamanAsimi=int.TryParse(TxtBaglantiSure.Text,out int seconds)?seconds:throw new ArgumentException("Zaman aşımını sayı olarak girin.")
            };
            if (ayar.KimlikDogrulama == "Sql") ayar.ParolayiAyarla(TxtSqlParola.Password);
            return ayar;
        }

        private async void Test_Click(object sender, RoutedEventArgs e)
        {
            BtnTest.IsEnabled = false;
            TxtDurum.Text = "Bağlantı deneniyor...";
            try
            {
                string adres = FormuOku().BaglantiDizesi();
                string sonuc = await Task.Run(() =>
                {
                    using var con = new SqlConnection(adres);
                    con.Open();
                    using var cmd = new SqlCommand("SELECT DB_NAME();", con);
                    return Convert.ToString(cmd.ExecuteScalar()) ?? "Bilinmiyor";
                });
                TxtDurum.Text = "✓ Bağlantı başarılı. Açılan veritabanı: " + sonuc;
            }
            catch (Exception hata) { TxtDurum.Text = "✗ Bağlantı kurulamadı: " + hata.Message; }
            finally { BtnTest.IsEnabled = true; }
        }

        private void Kaydet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                FormuOku().Kaydet();
                MessageBox.Show("Bağlantı ayarı bu bilgisayara kaydedildi.\n\nYeni ayar için MiapaxERP’u kapatıp yeniden açın.",
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Information);
                Close();
            }
            catch (Exception hata) { TxtDurum.Text = "Kaydedilemedi: " + hata.Message; }
        }
    }
}
