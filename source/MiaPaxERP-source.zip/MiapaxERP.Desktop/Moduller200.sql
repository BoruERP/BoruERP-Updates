SET XACT_ABORT ON;
BEGIN TRANSACTION;
DECLARE @lock200 int;
EXEC @lock200=sys.sp_getapplock @Resource=N'MiapaxERP.Moduller200',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=15000;
IF @lock200<0 THROW 51000,N'Sektör kurulumu kilidi alınamadı.',1;
IF OBJECT_ID(N'dbo.BERP200_Recete',N'U') IS NULL
BEGIN
 CREATE TABLE dbo.BERP200_Recete(Id bigint IDENTITY PRIMARY KEY,Kod nvarchar(50) NOT NULL UNIQUE,Ad nvarchar(160) NOT NULL,Sektor varchar(20) NOT NULL,MamulId int NOT NULL REFERENCES dbo.StokKartlari(Id),CiktiBirimi nvarchar(20) NOT NULL,FireYuzde decimal(9,3) NOT NULL CHECK(FireYuzde BETWEEN 0 AND 100),Aktif bit NOT NULL DEFAULT 1,Surum rowversion);
 CREATE TABLE dbo.BERP200_ReceteKalem(Id bigint IDENTITY PRIMARY KEY,ReceteId bigint NOT NULL REFERENCES dbo.BERP200_Recete(Id),StokId int NOT NULL REFERENCES dbo.StokKartlari(Id),Birim nvarchar(20) NOT NULL,BirimCiktiIcinMiktar decimal(18,6) NOT NULL CHECK(BirimCiktiIcinMiktar>0),UNIQUE(ReceteId,StokId));
 CREATE TABLE dbo.BERP200_Uretim(Id bigint IDENTITY PRIMARY KEY,Anahtar uniqueidentifier NOT NULL UNIQUE,IstekOzeti char(64) NOT NULL,ReceteId bigint NOT NULL REFERENCES dbo.BERP200_Recete(Id),Miktar decimal(18,3) NOT NULL CHECK(Miktar>0),Belge nvarchar(80) NOT NULL,Tarih datetime2 NOT NULL DEFAULT SYSUTCDATETIME(),KullaniciId int NOT NULL,Detay nvarchar(max) NOT NULL);
END;
INSERT dbo.Yetkiler(YetkiKodu,Modul,Islem,Aciklama,Aktif)
SELECT v.Kod,N'Üretim',v.Ad,N'Sektör bazlı '+v.Ad,1 FROM(VALUES('PRODUCTION.RECIPE',N'Reçete kaydet'),('PRODUCTION.COMPLETE',N'Üretim tamamla'))v(Kod,Ad)
WHERE NOT EXISTS(SELECT 1 FROM dbo.Yetkiler WHERE YetkiKodu=v.Kod);
IF NOT EXISTS(SELECT 1 FROM dbo.BERP_Sema WHERE Surum=200)INSERT dbo.BERP_Sema(Surum)VALUES(200);
COMMIT;
