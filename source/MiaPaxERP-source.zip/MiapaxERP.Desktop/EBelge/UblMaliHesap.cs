namespace MiapaxERP.Desktop.EBelge;

public sealed record UblTevkifat(string Kod,string Ad,int Pay,int Payda=10);
public sealed record UblMaliAyar(string Doviz="TRY",decimal Kur=1,DateTime? KurTarihi=null,string KurDayanagi="",
 UblTevkifat? Tevkifat=null,decimal Yuvarlama=0,string IndirimAciklamasi="");
public sealed record UblIndirimSonucu(UblSatir[] Satirlar,decimal OncekiMatrah,decimal OncekiKdv,
 decimal BrutIndirim,decimal YeniMatrah,decimal YeniKdv,decimal YeniToplam,decimal Yuvarlama);

public static class UblMaliHesap
{
 public const string TevkifatKaynak="GİB UBL-TR Kod Listeleri v1.43 / Temmuz 2026";
 static readonly UblTevkifat[] Kismi=new[]{
  new UblTevkifat("601","Yapım ve birlikte mühendislik / mimarlık",4),new("602","Etüt / plan / danışmanlık / denetim",9),
  new("603","Makine / taşıt bakım onarım",7),new("604","Yemek servisi",5),new("605","Organizasyon",5),
  new("606","İşgücü temini",9),new("607","Özel güvenlik",9),new("608","Yapı denetim",9),
  new("609","Fason tekstil / çanta / ayakkabı",7),new("610","Turistik müşteri bulma",9),new("611","Spor kulübü yayın / reklam / isim hakkı",9),
  new("612","Temizlik",9),new("613","Çevre / bahçe bakımı",9),new("614","Servis taşımacılığı",5),new("615","Baskı / basım",7),
  new("616","Diğer hizmetler",5),new("617","Hurdadan külçe",7),new("618","Diğer metal külçe",7),new("619","Bakır / çinko / alüminyum ürünler",7),
  new("620","İstisnadan vazgeçilen hurda / atık",7),new("621","Hurdadan hammadde",9),new("622","Pamuk / tiftik / yün / ham deri",9),
  new("623","Ağaç / orman ürünleri",5),new("624","Yük taşımacılığı",2),new("625","Ticari reklam",3),new("626","Diğer teslimler",2),new("627","Demir / çelik ürünleri",5)
 };
 public static readonly IReadOnlyList<UblTevkifat> Tevkifatlar=Kismi.Concat(new[]{601,602,603,604,605,606,607,608,609,610,611,612,613,614,615,617,618,619,620,621,622,623,624,625,627}.Select((code,i)=>new UblTevkifat((801+i).ToString(System.Globalization.CultureInfo.InvariantCulture),"İsteğe bağlı tam · "+Kismi.Single(x=>x.Kod==code.ToString(System.Globalization.CultureInfo.InvariantCulture)).Ad,10))).ToArray();
 public static UblTevkifat Tevkifat(string kod)=>Tevkifatlar.SingleOrDefault(x=>x.Kod==kod)??throw new ArgumentException("Doğrulanmış kısmi KDV tevkifat kodunu seçin.");
 public static void Dogrula(UblMaliAyar m,DateTime issue)
 {
  if(m.Doviz is not("TRY" or "USD" or "EUR" or "GBP" or "CHF" or "JPY" or "CAD" or "AUD" or "SAR" or "AED"))throw new ArgumentException("Desteklenen belge para birimini seçin.");
  if(m.Kur<=0||m.Kur>10000000m||decimal.Round(m.Kur,6)!=m.Kur||m.Doviz=="TRY"&&m.Kur!=1)throw new ArgumentException("Kur 1 belge dövizi için TRY değeri olmalı; TRY kuru 1 olmalıdır. Hızlı Bilişim UBL kur alanı en fazla altı ondalık kabul eder.");
  if(m.Doviz!="TRY"&&(m.KurTarihi is null||m.KurTarihi.Value.Date>issue.Date||string.IsNullOrWhiteSpace(m.KurDayanagi)))throw new ArgumentException("Döviz kuru tarihi ve türü / kaynağı zorunludur; kur tarihi düzenlemeden ileri olamaz.");
  if(m.Tevkifat is{} t){var valid=Tevkifat(t.Kod);if(t.Pay!=valid.Pay||t.Payda!=10||string.IsNullOrWhiteSpace(t.Ad))throw new ArgumentException("Tevkifat kodu ve oranı güncel GİB listesiyle uyuşmuyor.");}
  if(Math.Abs(m.Yuvarlama)>10||m.Yuvarlama!=UblBelge.Yuvarla(m.Yuvarlama)||m.Yuvarlama!=0&&string.IsNullOrWhiteSpace(m.IndirimAciklamasi))throw new ArgumentException("Yuvarlama farkı ve indirim açıklamasını kontrol edin.");
 }
 /// <summary>Eski KDV-sonrası indirim yalnız açık onayla satırların kendi KDV oranına dağıtılır.
 /// Kaynak belge değişmez. Kuruş farkı ayrı PayableRoundingAmount olarak korunur.</summary>
 public static UblIndirimSonucu EskiBrutIndirim(UblSatir[] rows,decimal grossDiscount)
 {
  if(rows.Length==0||grossDiscount<0||grossDiscount!=UblBelge.Yuvarla(grossDiscount))throw new ArgumentException("İndirim tutarı kuruş hassasiyetinde olmalı.");
  var values=rows.Select(x=>{decimal n=UblBelge.Yuvarla(x.Miktar*x.Fiyat)-x.Iskonto;if(n<0||x.KdvOrani is not(1 or 10 or 20))throw new ArgumentException("İndirim satır matrahı/KDV türü geçersiz.");return(Net:n,Vat:UblBelge.Yuvarla(n*x.KdvOrani/100));}).ToArray();
  decimal gross=values.Sum(x=>x.Net+x.Vat);if(grossDiscount>=gross)throw new ArgumentException("İndirim belge toplamından az olmalı.");
  decimal remaining=grossDiscount;var allocated=new decimal[rows.Length];
  // Largest remainder avoids depending on the last line's size or grid ordering.
  var ideal=values.Select(x=>grossDiscount*(x.Net+x.Vat)/gross).ToArray();for(int i=0;i<rows.Length;i++){allocated[i]=decimal.Floor(ideal[i]*100)/100;remaining-=allocated[i];}
  foreach(int i in Enumerable.Range(0,rows.Length).OrderByDescending(i=>ideal[i]-allocated[i]).ThenBy(i=>rows[i].Id,StringComparer.Ordinal)){if(remaining<=0)break;allocated[i]+=.01m;remaining-=.01m;}
  var result=rows.Select((r,i)=>r with{Iskonto=r.Iskonto+UblBelge.Yuvarla(allocated[i]/(1+r.KdvOrani/100))}).ToArray();
  decimal net=result.Sum(r=>UblBelge.Yuvarla(r.Miktar*r.Fiyat)-r.Iskonto),vat=result.Sum(r=>UblBelge.Yuvarla((UblBelge.Yuvarla(r.Miktar*r.Fiyat)-r.Iskonto)*r.KdvOrani/100));
  decimal round=gross-grossDiscount-net-vat;if(Math.Abs(round)>.01m*rows.Length)throw new ArgumentException("İndirim kuruş dağılımı doğrulanamadı.");
  return new(result,values.Sum(x=>x.Net),values.Sum(x=>x.Vat),grossDiscount,net,vat,net+vat,round);
 }
}
