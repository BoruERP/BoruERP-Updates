using System.Text.Json;
namespace MiapaxERP.Desktop.EBelge;

public enum EbelgeOrtam {Test,Canli}
public enum EbelgeTuru {EFatura=1,EArsiv=3,EIrsaliye=5}
public enum EbelgeKutusu {GelenFatura=1,GidenFatura=2,GidenArsiv=3,GelenIrsaliye=4,GidenIrsaliye=5}
public sealed record HizliKimlik(EbelgeOrtam Ortam,string Vkn,string ApiKey,string SifreliKullanici,string SifreliParola)
{public override string ToString()=>"Hızlı Bilişim · şifreli bağlantı bilgileri";}
public sealed record HizliKayit(Guid UUID,int AppType,string DocumentId,string TargetTitle,string TargetIdentifier,string ProfileId,string DocumentTypeCode,string DocumentCurrencyCode,decimal TaxTotal,decimal PayableAmount,int Status,string StatusExp,int EnvelopeStatus,string EnvelopeExp,string RawIssueDate,string LocalReferenceId,bool? IsDraft=null,bool? Iptal=null);
public sealed record HizliMukellef(string Identifier,string Alias,string Title,string Type);
public sealed record HizliGonderi(int AppType,string SourceUrn,string DestinationIdentifier,string DestinationUrn,string XmlContent,string DocumentUUID,string DocumentId,string DocumentDate,string LocalId,bool UpdateDocument=false,bool IsDraft=true,bool IsDraftSend=false);
public sealed class EbelgeHatasi(string message,bool belirsiz=false):Exception(message){public bool Belirsiz{get;}=belirsiz;}
public static class EbelgeJson
{
 public static readonly JsonSerializerOptions Ayar=new(){PropertyNameCaseInsensitive=true};
 public static string Yaz<T>(T value)=>JsonSerializer.Serialize(value,Ayar);
 public static JsonElement P(JsonElement j,string key)=>j.ValueKind==JsonValueKind.Object&&j.TryGetProperty(key,out var p)?p:default;
 public static string S(JsonElement j,string key)=>P(j,key).ValueKind is JsonValueKind.Undefined or JsonValueKind.Null?"":P(j,key).ToString();
 public static bool Basarili(JsonElement j)=>P(j,"IsSucceeded").ValueKind==JsonValueKind.True;
 public static string YanitBicimi(JsonElement j)
 {
  if(j.ValueKind==JsonValueKind.Array)return "Yanıt: liste ("+j.GetArrayLength()+" eleman)"+(j.GetArrayLength()==1?" / "+YanitBicimi(j[0]):"");
  if(j.ValueKind!=JsonValueKind.Object)return "Yanıt türü: "+j.ValueKind;
  return string.Join("; ",new[]{"IsSucceeded","Message","gibUserLists","documents"}.Where(n=>P(j,n).ValueKind!=JsonValueKind.Undefined).Select(n=>n+":"+P(j,n).ValueKind+(P(j,n).ValueKind is JsonValueKind.True or JsonValueKind.False?"="+P(j,n).GetBoolean():"")));
 }
 public static string HataSinifi(JsonElement j)
 {
  string m=S(j,"Message").ToLowerInvariant();var codes=new List<string>();
  if(new[]{"bulunamad","bulunmamak","not found","kayıt yok","kayit yok"}.Any(m.Contains))codes.Add("Kayıt bulunamadı");
  if(new[]{"yetki","authoriz","permission"}.Any(m.Contains))codes.Add("Yetki kontrolü");
  if(new[]{"vkn","tckn","vergi","identifier"}.Any(m.Contains))codes.Add("VKN/TCKN kontrolü");
  if(new[]{"parametr","paramet","geçersiz","invalid"}.Any(m.Contains))codes.Add("Parametre kontrolü");
  if(new[]{"test","sandbox"}.Any(m.Contains))codes.Add("Test ortamı");
  if(new[]{"zaman aş","timeout","bağlan","connection","servis","service"}.Any(m.Contains))codes.Add("Servis bağlantısı");
  return codes.Count==0?"Sağlayıcının hata ayrıntısı ayrıca incelenmeli":string.Join(", ",codes);
 }
 public static void KimlikDogrula(HizliKimlik k){if(!Enum.IsDefined(k.Ortam)||!System.Text.RegularExpressions.Regex.IsMatch(k.Vkn,"^[0-9]{10,11}$"))throw new ArgumentException("Ortam ve şirket VKN/TCKN bilgisi geçersiz.");foreach(var s in new[]{k.ApiKey,k.SifreliKullanici,k.SifreliParola})if(string.IsNullOrWhiteSpace(s)||s.Length>8192||s.Any(char.IsControl))throw new ArgumentException("API bağlantı bilgileri eksik/geçersiz.");}
}
