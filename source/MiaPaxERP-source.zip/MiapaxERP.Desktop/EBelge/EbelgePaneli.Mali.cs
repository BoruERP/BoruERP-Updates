using System.Data;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
namespace MiapaxERP.Desktop.EBelge;
public sealed partial class EbelgePaneli
{
 readonly DataGrid fxGrid=new(){AutoGenerateColumns=true,IsReadOnly=true,CanUserAddRows=false,SelectionMode=DataGridSelectionMode.Single};
 void MaliBolumEkle()
 {
  var p=new DockPanel();var tools=new WrapPanel();DockPanel.SetDock(tools,Dock.Top);p.Children.Add(tools);p.Children.Add(fxGrid);
  void B(string text,Func<Task> action){var b=new Button{Content=text,Padding=new Thickness(10,7,10,7),Margin=new Thickness(3)};b.Click+=async(_,_)=>await Run(action);tools.Children.Add(b);}
  B("Belge bakiyeleri",()=>{fxGrid.ItemsSource=depo.DovizListesi(Key()).DefaultView;return Task.CompletedTask;});B("Seçili belgeye tahsilat / ödeme",DovizKapat);B("Gerçekleşen kur farkı raporu",()=>{fxGrid.ItemsSource=depo.KurFarkiRaporu(Key()).DefaultView;return Task.CompletedTask;});
  B("Seçili tahsilat / ödeme ters kaydı",DovizTersle);
  fxGrid.AutoGeneratingColumn+=(_,e)=>{if(e.PropertyName is "Surum" or "Id" or "TersId" or "OdemeId")e.Cancel=true;};tabs.Items.Add(new TabItem{Header="Döviz / tevkifat / belge kapama",Content=p});
 }
 Task SatisMaliDuzenle()
 {
  if(sales.SelectedItem is not DataRowView row)throw new ArgumentException("Bir satış seçin.");string currency=Convert.ToString(row["ParaBirimi"])??"TRY";
  var w=new Window{Title="Miapax ERP · Satış mali bilgileri",Owner=Window.GetWindow(this),Width=740,Height=760,WindowStartupLocation=WindowStartupLocation.CenterOwner};var p=new StackPanel{Margin=new Thickness(20)};w.Content=new ScrollViewer{Content=p};
  p.Children.Add(new TextBlock{Text=$"{row["BelgeNo"]} · {row["Unvan"]}\nSatış para birimi: {currency}. Satır fiyatları bu para birimindedir. Kaynak satışın tutarları değiştirilmez.",TextWrapping=TextWrapping.Wrap,FontSize=17});
  TextBox T(string label,string value=""){p.Children.Add(new TextBlock{Text=label,Margin=new Thickness(0,12,0,4),TextWrapping=TextWrapping.Wrap});var b=new TextBox{Text=value,Padding=new Thickness(6)};p.Children.Add(b);return b;}
  var rate=T("1 "+currency+" karşılığı TRY kuru (TRY için 1)",currency=="TRY"?"1":"");p.Children.Add(new TextBlock{Text="Kur tarihi (kaynak belgedeki tarih)"});var date=new DatePicker{SelectedDate=currency=="TRY"?(DateTime)row["Tarih"]:null};p.Children.Add(date);var source=T("Kur türü / kaynağı / dayanak (döviz alış, sözleşme vb.)",currency=="TRY"?"TRY / kur 1":"");
  p.Children.Add(new TextBlock{Text="KDV tevkifatı · GİB UBL-TR v1.43 (Temmuz 2026)",Margin=new Thickness(0,12,0,4)});var items=new[]{new{Kod="",Ad="Tevkifat yok"}}.Concat(UblMaliHesap.Tevkifatlar.Select(x=>new{Kod=x.Kod,Ad=$"{x.Kod} · {x.Ad} · {x.Pay}/10"})).ToArray();var tax=new ComboBox{ItemsSource=items,DisplayMemberPath="Ad",SelectedValuePath="Kod",SelectedIndex=0};p.Children.Add(tax);
  var eligible=new CheckBox{Content="İşlem türü, alıcı niteliği ve tevkifat uygulama koşullarını mali olarak doğruladım",Margin=new Thickness(0,12,0,5)};p.Children.Add(eligible);
  tax.SelectionChanged+=(_,_)=>{eligible.IsChecked=false;eligible.Content=Convert.ToString(tax.SelectedValue)?.StartsWith("8")==true?"İsteğe bağlı tam tevkifat için yazılı sözleşme ve uygulama koşullarını doğruladım":"İşlem türü, alıcı niteliği ve tevkifat uygulama koşullarını mali olarak doğruladım";};
  var discount=new CheckBox{Content=$"Eski KDV sonrası brüt indirimi ({row["Indirim"]} {currency}) satırların kendi KDV oranlarıyla matraha dağıtmayı onaylıyorum",Margin=new Thickness(0,12,0,5)};p.Children.Add(discount);
  var reason=T("Kontrol açıklaması / mali dayanak");var err=new TextBlock{TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,12,0,5)};p.Children.Add(err);var b=new Button{Content="Mali bilgileri kaydet · henüz belge göndermez",Padding=new Thickness(12)};p.Children.Add(b);
  b.Click+=(_,_)=>{try{if(!decimal.TryParse(rate.Text,NumberStyles.Number,CultureInfo.GetCultureInfo("tr-TR"),out var r))throw new ArgumentException("Geçerli TRY kurunu girin.");string code=Convert.ToString(tax.SelectedValue)??"";if(code!=""&&eligible.IsChecked!=true)throw new ArgumentException("Tevkifat uygunluk kontrolünü onaylayın.");var m=new UblMaliAyar(currency,r,date.SelectedDate,source.Text.Trim(),code==""?null:UblMaliHesap.Tevkifat(code));depo.SatisMaliKaydet(Convert.ToInt64(row["Id"]),m,discount.IsChecked==true,reason.Text.Trim());w.DialogResult=true;status.Text="Satış mali bilgileri kaydedildi. E-belge hazırlarken matrah, KDV, tevkifat ve ödenecek toplamı kontrol edin.";}catch(Exception e){err.Text=e.Message;}};w.ShowDialog();return Task.CompletedTask;
 }
 Task DovizTersle()
 {
  var k=Key();if(fxGrid.SelectedItem is not DataRowView row||!row.Row.Table.Columns.Contains("OdemeId"))throw new ArgumentException("Gerçekleşen kur farkı raporundan bir ödeme seçin.");
  var f=Form("Cari ve kasa/banka ters kaydı",("d","Ters kayıt tarihi",DateTime.Today.ToString("yyyy-MM-dd")),("g","Düzeltme gerekçesi",""));if(f is null)return Task.CompletedTask;
  if(!DateTime.TryParseExact(f["d"],"yyyy-MM-dd",CultureInfo.InvariantCulture,DateTimeStyles.None,out var date))throw new ArgumentException("Tarih geçersiz.");
  if(MessageBox.Show(Window.GetWindow(this),row["BelgeNo"]+" belgesinin seçili tahsilat/ödeme kaydı terslensin mi? Cari ve kasa/banka ters kayıtları oluşturulacak; belge bakiyesi yeniden açılacak.","Ters kayıt onayı",MessageBoxButton.YesNo)!=MessageBoxResult.Yes)return Task.CompletedTask;
  depo.DovizOdemeTersle(k,Convert.ToInt64(row["OdemeId"]),date,f["g"]);fxGrid.ItemsSource=depo.KurFarkiRaporu(k).DefaultView;status.Text="Tahsilat/ödeme ters kayıtları eklendi. Geçmiş korundu ve belge bakiyesi yeniden açıldı.";return Task.CompletedTask;
 }
 Task DovizKapat()
 {
  var k=Key();if(fxGrid.SelectedItem is not DataRowView row||!row.Row.Table.Columns.Contains("Id"))throw new ArgumentException("Belge bakiyeleri listesinden bir kayıt seçin.");
  if(row["TersId"] is not DBNull)throw new ArgumentException("Terslenmiş belge kapatılamaz.");
  var account=Sec("Tahsilat / ödeme hesabını seçin",depo.DovizHesaplari());if(account is null)return Task.CompletedTask;
  var f=Form("Belgeye bağlı tahsilat / ödeme",("m","Kapatılacak belge dövizi tutarı (kalan: "+row["Kalan"]+" "+row["ParaBirimi"]+")",""),("r","1 belge dövizi için işlem tarihindeki TRY kuru",row["ParaBirimi"].ToString()=="TRY"?"1":""),("d","Tahsilat / ödeme tarihi",DateTime.Today.ToString("yyyy-MM-dd")),("ref","Banka dekontu / kasa makbuzu numarası (tekrar denemede aynı numarayı kullanın)",""),("g","İşlem dayanağı ve kur kaynağı. Başka ekrandan aynı ödemeyi daha önce işlemediğinizi kontrol edin.",""));if(f is null)return Task.CompletedTask;
  if(!decimal.TryParse(f["m"],NumberStyles.Number,CultureInfo.GetCultureInfo("tr-TR"),out var amount)||!decimal.TryParse(f["r"],NumberStyles.Number,CultureInfo.GetCultureInfo("tr-TR"),out var rate)||!DateTime.TryParseExact(f["d"],"yyyy-MM-dd",CultureInfo.InvariantCulture,DateTimeStyles.None,out var date))throw new ArgumentException("Tutar, kur ve tarihi kontrol edin.");
  string reference=f["ref"].Trim();if(reference.Length is <1 or >80||f["g"].Length<5||f["g"].Length>300)throw new ArgumentException("Dekont/makbuz numarası 1–80, mali açıklama 5–300 karakter olmalıdır.");
  if(MessageBox.Show(Window.GetWindow(this),$"{row["BelgeNo"]}\n{amount:N2} {row["ParaBirimi"]} / TRY karşılığı {UblBelge.Yuvarla(amount*rate):N2}\n{account["HesapAdi"]}\nBu işlem kasa/banka ve cari hareketi oluşturacak. Uygulansın mı?","Tahsilat / ödeme onayı",MessageBoxButton.YesNo)!=MessageBoxResult.Yes)return Task.CompletedTask;
  string attempt=$"MiapaxBelgeOdeme|{k.Ortam}|{k.Vkn}|{row["Id"]}|{account["Id"]}|{reference.ToUpperInvariant()}";Guid paymentKey=new(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(attempt)).AsSpan(0,16));
  depo.DovizOde(k,paymentKey,Convert.ToInt64(row["Id"]),Convert.ToInt32(account["Id"]),amount,rate,date,"Dekont/makbuz: "+reference+" / "+f["g"]);fxGrid.ItemsSource=depo.DovizListesi(k).DefaultView;status.Text="Belge kapaması, banka/cari hareketi ve gerçekleşen kur farkı kaydedildi.";return Task.CompletedTask;
 }
}
