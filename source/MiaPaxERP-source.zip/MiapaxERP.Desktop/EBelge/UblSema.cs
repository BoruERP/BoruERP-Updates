using System.IO;
using System.Net;
using System.Xml;
using System.Xml.Schema;
namespace MiapaxERP.Desktop.EBelge;
public static class UblSema
{
 sealed class YerelCozucu(string root):XmlResolver
 {
  public override ICredentials? Credentials{set{}}
  public override object GetEntity(Uri absoluteUri,string? role,Type? ofObjectToReturn){string file=Path.GetFullPath(absoluteUri.LocalPath);if(!absoluteUri.IsFile||!file.StartsWith(root,StringComparison.OrdinalIgnoreCase)||!file.EndsWith(".xsd",StringComparison.OrdinalIgnoreCase))throw new XmlException("Şema dış kaynağı engellendi.");return File.OpenRead(file);}
 }
 public static void Dogrula(string xml)
 {
  var k=UblKimlik.Oku(xml);string folder=Path.GetFullPath(Path.Combine(AppContext.BaseDirectory,"Assets","EBelge","UblTr"))+Path.DirectorySeparatorChar;var schemas=new XmlSchemaSet{XmlResolver=null};
  // Resmî dsig XSD kendi sabit iç DTD'sini içerir. Bu izin yalnız paketlenmiş şemalara aittir;
  // kullanıcı UBL'sinde DTD hâlâ yasaktır, şemalarda da dış varlık çözümleyici yoktur.
  foreach(string file in Directory.GetFiles(Path.Combine(folder,"common"),"*.xsd").Append(Path.Combine(folder,"maindoc",k.Irsaliye?"UBL-DespatchAdvice-2.1.xsd":"UBL-Invoice-2.1.xsd"))){using var input=XmlReader.Create(file,new XmlReaderSettings{DtdProcessing=DtdProcessing.Parse,XmlResolver=null,MaxCharactersFromEntities=10000,MaxCharactersInDocument=10_000_000});schemas.Add(XmlSchema.Read(input,null)!);}schemas.XmlResolver=new YerelCozucu(folder);schemas.Compile();
  var settings=new XmlReaderSettings{DtdProcessing=DtdProcessing.Prohibit,XmlResolver=null,MaxCharactersInDocument=8_000_000,ValidationType=ValidationType.Schema,Schemas=schemas};using var reader=XmlReader.Create(new StringReader(xml),settings);try{while(reader.Read()){}}catch(XmlSchemaValidationException e){throw new ArgumentException("UBL şema kontrolü: "+e.Message);}
 }
}
