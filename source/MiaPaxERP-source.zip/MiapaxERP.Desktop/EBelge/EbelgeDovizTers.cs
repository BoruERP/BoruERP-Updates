using System.Data;
namespace MiapaxERP.Desktop.EBelge;
public sealed partial class EbelgeDeposu
{
 public void DovizOdemeTersle(HizliKimlik key,long payment,DateTime date,string reason)
 {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EbelgeDeposu.DovizOdemeTersle","",new object?[]{key,payment,date,reason});return;}

  if(key.Ortam!=EbelgeOrtam.Canli)throw new ArgumentException("TEST ödemesi gerçek ters kayıt oluşturamaz.");Gerekce(reason);using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"FINANCE.FX.REVERSE");check(c,t,"FINANCE.PAYMENT");check(c,t,"CUSTOMER.EDIT");
  long operation,ch,fh;decimal amount,book;DateTime original;
  using(var q=Q(c,t,"SELECT o.IslemId,o.CariHareketId,o.FinansHareketId,o.DovizTutar,o.DefterTry,o.Tarih FROM dbo.MPX280_DovizOdeme o WITH(UPDLOCK,HOLDLOCK) JOIN dbo.BERP270_EBelgeIslem i WITH(UPDLOCK,HOLDLOCK) ON i.Id=o.IslemId WHERE o.Id=@id AND i.Ortam=@o AND i.Vkn=@v AND i.TersId IS NULL AND o.TersCariHareketId IS NULL",("@id",payment),("@o",key.Ortam.ToString()),("@v",key.Vkn)))
  {using var r=q.ExecuteReader();if(!r.Read())throw new ArgumentException("Aktif ödeme bulunamadı veya daha önce terslendi.");operation=r.GetInt64(0);ch=r.GetInt64(1);fh=r.GetInt64(2);amount=r.GetDecimal(3);book=r.GetDecimal(4);original=r.GetDateTime(5);}
  if(date.Date<original.Date)throw new ArgumentException("Ters kayıt tarihi ödeme tarihinden önce olamaz.");
  using var cari=Q(c,t,"INSERT dbo.CariHareketleri(CariId,Tarih,HareketTipi,Tutar,Aciklama,Kaynak,YapanKullaniciId,TersKayitId)OUTPUT INSERTED.Id SELECT CariId,@d,CASE HareketTipi WHEN N'Borç' THEN N'Alacak' ELSE N'Borç' END,Tutar,@g,N'Miapax Belge Kapama Ters',@u,Id FROM dbo.CariHareketleri WITH(UPDLOCK,HOLDLOCK) WHERE Id=@h AND NOT EXISTS(SELECT 1 FROM dbo.CariHareketleri r WHERE r.TersKayitId=@h)",("@d",date.Date),("@g",reason),("@u",user),("@h",ch));object? value=cari.ExecuteScalar();if(value is null)throw new ArgumentException("Ödeme cari hareketi daha önce terslenmiş.");long rc=Convert.ToInt64(value);
  using var finance=Q(c,t,"INSERT dbo.FinansHareketleri(HesapId,CariId,CariHareketId,Tarih,HareketTipi,Tutar,Aciklama,YapanKullaniciId,TersKayitId)OUTPUT INSERTED.Id SELECT HesapId,CariId,@ch,@d,CASE HareketTipi WHEN N'Giriş' THEN N'Çıkış' ELSE N'Giriş' END,Tutar,@g,@u,Id FROM dbo.FinansHareketleri WITH(UPDLOCK,HOLDLOCK) WHERE Id=@h AND NOT EXISTS(SELECT 1 FROM dbo.FinansHareketleri r WHERE r.TersKayitId=@h)",("@ch",rc),("@d",date.Date),("@g",reason),("@u",user),("@h",fh));value=finance.ExecuteScalar();if(value is null)throw new ArgumentException("Kasa/banka hareketi daha önce terslenmiş.");long rf=Convert.ToInt64(value);
  using var update=Q(c,t,"UPDATE dbo.MPX280_EbelgeMali WITH(UPDLOCK,HOLDLOCK) SET Kapanan=Kapanan-@m,KapananTry=KapananTry-@try WHERE IslemId=@id AND Kapanan>=@m AND KapananTry>=@try",("@m",amount),("@try",book),("@id",operation));if(update.ExecuteNonQuery()!=1)throw new ArgumentException("Belge kapama toplamı tutarsız; ters kayıt uygulanmadı.");
  using var mark=Q(c,t,"UPDATE dbo.MPX280_DovizOdeme SET TersCariHareketId=@c,TersFinansHareketId=@f,TersTarih=@d,TersGerekce=@g,TersKullanici=@u WHERE Id=@id",("@c",rc),("@f",rf),("@d",date.Date),("@g",reason),("@u",user),("@id",payment));mark.ExecuteNonQuery();t.Commit();
 }
}
