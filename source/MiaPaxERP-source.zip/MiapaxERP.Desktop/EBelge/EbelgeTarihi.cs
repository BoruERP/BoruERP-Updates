using System.Globalization;
namespace MiapaxERP.Desktop.EBelge;
public static class EbelgeTarihi
{
 public static DateTime Oku(string source)
 {
  if(DateTimeOffset.TryParse(source,CultureInfo.InvariantCulture,DateTimeStyles.AllowWhiteSpaces,out var date))return date.Date;
  var m=System.Text.RegularExpressions.Regex.Match(source,"^/Date\\((-?[0-9]+)([+-][0-9]{4})?\\)/$");if(m.Success&&long.TryParse(m.Groups[1].Value,out var ms)){var d=DateTimeOffset.FromUnixTimeMilliseconds(ms);if(m.Groups[2].Success){string s=m.Groups[2].Value;var offset=new TimeSpan(int.Parse(s.Substring(1,2),CultureInfo.InvariantCulture),int.Parse(s.Substring(3,2),CultureInfo.InvariantCulture),0);d=d.ToOffset(s[0]=='-'?-offset:offset);}return d.Date;}
  throw new ArgumentException("Sağlayıcının belge tarihi çözümlenemedi; bugünün tarihi varsayılmadı.");
 }
}
