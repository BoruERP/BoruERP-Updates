using System.Text.Json;
using System.Text.RegularExpressions;
namespace MiapaxERP.Desktop.EBelge;

public static class HizliTokenYaniti
{
 static readonly string[] TokenNames={"token","access_token","accessToken","AccessToken","Token","BearerToken","bearerToken"};
 static readonly string[] Wrappers={"data","Data","result","Result","LoginResult","d"};
 public static string Oku(JsonElement root)
 {
  string? Walk(JsonElement value,int depth)
  {
   if(depth>3)return null;
   if(value.ValueKind==JsonValueKind.Array)return value.GetArrayLength()==1?Walk(value[0],depth+1):null;
   if(value.ValueKind==JsonValueKind.String){string s=(value.GetString()??"").Trim();if(s.StartsWith("Bearer ",StringComparison.OrdinalIgnoreCase))s=s[7..].Trim();if(s.Length<=32000&&Regex.IsMatch(s,"^[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+$"))return s;if(s.Length<=32000&&s.StartsWith('{')){try{using var nested=JsonDocument.Parse(s);return Walk(nested.RootElement,depth+1);}catch(JsonException){return null;}}return null;}
   if(value.ValueKind!=JsonValueKind.Object)return null;
   foreach(string n in new[]{"IsSucceeded","isSucceeded","success","Success"})if(value.TryGetProperty(n,out var flag)&&flag.ValueKind!=JsonValueKind.True)throw new EbelgeHatasi("Sağlayıcı girişi onaylamadı. API hesabı ve web servis kullanıcı bilgileri doğrulanmalı.");
   foreach(string n in TokenNames.Concat(Wrappers))if(value.TryGetProperty(n,out var child)){var found=Walk(child,depth+1);if(found is not null)return found;}
   return null;
  }
  return Walk(root,0)??throw new EbelgeHatasi("Login yanıtında kullanılabilir token bulunamadı. "+Bicim(root));
 }
 // Değerleri, mesaj metnini ve bilinmeyen alan adlarını raporlamaz.
 public static string Bicim(JsonElement root)
 {
  var items=new List<string>{"Yanıt türü: "+root.ValueKind};
  void Shape(JsonElement v,string path,int depth){if(depth>2)return;if(v.ValueKind==JsonValueKind.Array){items.Add(path+"eleman sayısı="+v.GetArrayLength());if(v.GetArrayLength()==1){items.Add(path+"[0]:"+v[0].ValueKind);Shape(v[0],path+"[0].",depth+1);}return;}if(v.ValueKind!=JsonValueKind.Object)return;foreach(string name in TokenNames.Concat(Wrappers).Concat(new[]{"IsSucceeded","isSucceeded","Success","success","Message","message","Error","error","LoginOutput","ServiceUsername","ServicePassword"}))if(v.TryGetProperty(name,out var child)){items.Add(path+name+":"+child.ValueKind+(child.ValueKind is JsonValueKind.True or JsonValueKind.False?"="+child.GetBoolean():""));Shape(child,path+name+".",depth+1);}if(!v.EnumerateObject().Any())items.Add(path+"boş nesne");}
  Shape(root,"",0);return string.Join("; ",items);
 }
}
