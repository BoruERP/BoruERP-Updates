using System.Data;
namespace MiapaxERP.Desktop.EBelge;
public sealed partial class EbelgeDeposu
{
 public DataTable Secimler(string kind,string tax="",int stock=0,decimal qty=0,string yon="",decimal amount=0,DateTime? date=null)
 {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"EbelgeDeposu.Secimler","",new object?[]{kind,tax,stock,qty,yon,amount,date});}

  using var c=Ac();check(c,null,kind.StartsWith("stok",StringComparison.Ordinal)?"STOCK.VIEW":"CUSTOMER.VIEW");string sql=kind switch{
   "cari"=>"SELECT Id,CariKodu,Unvan FROM dbo.CariKartlari WHERE Aktif=1 AND VergiNo=@v ORDER BY Unvan",
   "stok"=>"SELECT TOP(500) Id,StokKodu,StokAdi,Birim FROM dbo.StokKartlari WHERE Aktif=1 ORDER BY StokKodu",
   "carihareket"=>"SELECT TOP(200) Id,Tarih,HareketTipi,Tutar,Aciklama FROM dbo.CariHareketleri h WHERE CariId=@s AND HareketTipi=@y AND Tutar=@a AND Tarih=@d AND TersKayitId IS NULL AND NOT EXISTS(SELECT 1 FROM dbo.CariHareketleri r WHERE r.TersKayitId=h.Id) AND NOT EXISTS(SELECT 1 FROM dbo.BERP270_EBelgeIslem e WHERE e.CariHareketId=h.Id) ORDER BY Id DESC",
   "stokhareket"=>"SELECT TOP(200) Id,HareketTipi,Yon,Miktar,Birim,Aciklama FROM dbo.StokHareketleri h WHERE StokKartId=@s AND Yon=@y AND Miktar=@q AND NOT EXISTS(SELECT 1 FROM dbo.BERP270_EBelgeStokBag b WHERE b.HareketId=h.Id) ORDER BY Id DESC",
   _=>throw new ArgumentException("Seçim türü geçersiz.")};using var q=Q(c,null,sql,("@v",tax),("@s",stock),("@q",qty),("@y",yon),("@a",amount),("@d",date));using var r=q.ExecuteReader();var table=new DataTable();table.Load(r);return table;
 }
}
