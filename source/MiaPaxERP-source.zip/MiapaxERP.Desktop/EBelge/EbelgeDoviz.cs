using System.Data;
namespace MiapaxERP.Desktop.EBelge;
public sealed partial class EbelgeDeposu
{
 public DataTable DovizListesi(HizliKimlik key)
 {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"EbelgeDeposu.DovizListesi","",new object?[]{key});}

  using var c=Ac();check(c,null,"FINANCE.FX.VIEW");using var q=Q(c,null,"SELECT TOP(500) i.Id,i.BelgeNo,i.BelgeTipi,i.BelgeTarihi,c.Unvan,m.ParaBirimi,m.BelgeToplami,m.Tevkifat,m.Odenecek,m.Kur,m.KurTarihi,m.TryOdenecek,i.GenelToplam-i.Matrah-i.Kdv AS TryBelgeYuvarlamasi,m.Odenecek-m.Kapanan Kalan,m.TryOdenecek-m.KapananTry KalanTry,i.TersId,m.Surum FROM dbo.MPX280_EbelgeMali m JOIN dbo.BERP270_EBelgeIslem i ON i.Id=m.IslemId JOIN dbo.CariKartlari c ON c.Id=i.CariId WHERE i.Ortam=@o AND i.Vkn=@v ORDER BY i.Id DESC",("@o",key.Ortam.ToString()),("@v",key.Vkn));using var r=q.ExecuteReader();var dt=new DataTable();dt.Load(r);return dt;
 }
 public DataTable DovizHesaplari(){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"EbelgeDeposu.DovizHesaplari","",new object?[]{});}
using var c=Ac();check(c,null,"FINANCE.FX.PAY");using var q=Q(c,null,"SELECT Id,HesapAdi,ParaBirimi FROM dbo.FinansHesaplari WHERE Aktif=1 ORDER BY HesapAdi");using var r=q.ExecuteReader();var dt=new DataTable();dt.Load(r);return dt;}
 public long DovizOde(HizliKimlik key,Guid payment,long operation,int hesap,decimal amount,decimal rate,DateTime date,string reason)
 {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"EbelgeDeposu.DovizOde","",new object?[]{key,payment,operation,hesap,amount,rate,date,reason});}

  if(key.Ortam!=EbelgeOrtam.Canli)throw new ArgumentException("TEST belgesi gerçek tahsilat/ödeme oluşturamaz.");Gerekce(reason);if(amount<=0||UblBelge.Yuvarla(amount)!=amount||rate<=0||decimal.Round(rate,8)!=rate||rate>10000000m)throw new ArgumentException("Pozitif döviz tutarı ve sekiz ondalığa kadar kur gerekli.");
  using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"FINANCE.FX.PAY");check(c,t,"FINANCE.PAYMENT");check(c,t,"CUSTOMER.EDIT");
  using(var integrated=Q(c,t,"IF OBJECT_ID('dbo.MPX310_Satis') IS NOT NULL EXEC sp_executesql N'SELECT COUNT(*) FROM dbo.MPX310_Satis s JOIN dbo.BERP270_EBelgeIslem i ON i.CariHareketId=s.CariHareketId WHERE i.Id=@id',N'@id bigint',@id;ELSE SELECT 0;",("@id",operation)))if(Convert.ToInt32(integrated.ExecuteScalar())>0)throw new InvalidOperationException("Bu belge otomatik satış kaydına bağlı. Tahsilatı İşletme yönetimi → Satış tahsilatları ekranından yapın.");
  int cari;string direction,currency;decimal open,openTry,originalRate;DateTime issue;
  using(var q=Q(c,t,"SELECT i.CariId,h.HareketTipi,m.ParaBirimi,m.Odenecek-m.Kapanan,m.TryOdenecek-m.KapananTry,m.Kur,i.BelgeTarihi FROM dbo.MPX280_EbelgeMali m WITH(UPDLOCK,HOLDLOCK) JOIN dbo.BERP270_EBelgeIslem i WITH(UPDLOCK,HOLDLOCK) ON i.Id=m.IslemId JOIN dbo.CariHareketleri h WITH(UPDLOCK,HOLDLOCK) ON h.Id=i.CariHareketId WHERE i.Id=@id AND i.Ortam=@o AND i.Vkn=@v AND i.TersId IS NULL AND NOT EXISTS(SELECT 1 FROM dbo.CariHareketleri x WHERE x.TersKayitId=h.Id)",("@id",operation),("@o",key.Ortam.ToString()),("@v",key.Vkn)))
  {using var r=q.ExecuteReader();if(!r.Read())throw new ArgumentException("Bu firmaya ait aktif muhasebe kaydı bulunamadı.");cari=r.GetInt32(0);direction=r.GetString(1);currency=r.GetString(2);open=r.GetDecimal(3);openTry=r.GetDecimal(4);originalRate=r.GetDecimal(5);issue=r.GetDateTime(6);}
  using(var q=Q(c,t,"SELECT Id,IslemId,DovizTutar,Kur,Tarih,Dayanak,FinansHareketId,TersCariHareketId FROM dbo.MPX280_DovizOdeme WITH(UPDLOCK,HOLDLOCK) WHERE Anahtar=@k",("@k",payment)))
  {using var r=q.ExecuteReader();if(r.Read()){long id=r.GetInt64(0);if(!r.IsDBNull(7))throw new ArgumentException("Bu işlem daha önce terslenmiş. Yeni mali işlem için yeni bir işlem/dekont referansı kullanın.");if(r.GetInt64(1)!=operation||r.GetDecimal(2)!=amount||r.GetDecimal(3)!=rate||r.GetDateTime(4)!=date.Date||r.GetString(5)!=reason)throw new ArgumentException("Ödeme anahtarı farklı işlemde kullanılmış.");long finance=r.GetInt64(6);r.Close();using var h=Q(c,t,"SELECT HesapId FROM dbo.FinansHareketleri WHERE Id=@id",("@id",finance));if(Convert.ToInt32(h.ExecuteScalar())!=hesap)throw new ArgumentException("Ödeme hesabı önceki işlemle uyuşmuyor.");t.Commit();return id;}}
  if(amount>open||date.Date<issue.Date||currency=="TRY"&&rate!=1)throw new ArgumentException("Ödeme belge tarihinden önce veya kalan döviz tutarından fazla olamaz. TRY kuru 1'dir.");
  string bankCurrency;using(var q=Q(c,t,"SELECT ParaBirimi FROM dbo.FinansHesaplari WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Aktif=1",("@id",hesap)))bankCurrency=q.ExecuteScalar() as string??throw new ArgumentException("Aktif kasa/banka hesabı seçin.");
  if(bankCurrency!="TRY"&&bankCurrency!=currency)throw new ArgumentException("Banka hesabı TRY veya belge döviziyle aynı olmalı. Üçüncü döviz dönüşümü ayrı kur gerektirir.");
  decimal book=amount==open?openTry:UblBelge.Yuvarla(amount*originalRate),actual=UblBelge.Yuvarla(amount*rate),bank=bankCurrency=="TRY"?actual:amount;if(actual<=0)throw new ArgumentException("Ödemenin TRY karşılığı sıfır olamaz.");bool received=direction=="Borç";
  using var cariInsert=Q(c,t,"INSERT dbo.CariHareketleri(CariId,Tarih,HareketTipi,Tutar,Aciklama,Kaynak,YapanKullaniciId)OUTPUT INSERTED.Id VALUES(@c,@d,@y,@m,@a,N'Miapax Belge Kapama',@u)",("@c",cari),("@d",date.Date),("@y",received?"Alacak":"Borç"),("@m",book),("@a",reason),("@u",user));long ch=Convert.ToInt64(cariInsert.ExecuteScalar());
  using var bankInsert=Q(c,t,"INSERT dbo.FinansHareketleri(HesapId,CariId,CariHareketId,Tarih,HareketTipi,Tutar,Aciklama,YapanKullaniciId)OUTPUT INSERTED.Id VALUES(@h,@c,@ch,@d,@y,@m,@a,@u)",("@h",hesap),("@c",cari),("@ch",ch),("@d",date.Date),("@y",received?"Giriş":"Çıkış"),("@m",bank),("@a",reason),("@u",user));long fh=Convert.ToInt64(bankInsert.ExecuteScalar());
  using var save=Q(c,t,"INSERT dbo.MPX280_DovizOdeme(Anahtar,IslemId,Tarih,DovizTutar,Kur,BankaTutar,TryTutar,DefterTry,KurFarki,CariHareketId,FinansHareketId,Kullanici,Dayanak)OUTPUT INSERTED.Id VALUES(@k,@i,@d,@a,@r,@b,@tr,@def,@fx,@ch,@fh,@u,@g)",("@k",payment),("@i",operation),("@d",date.Date),("@a",amount),("@r",rate),("@b",bank),("@tr",actual),("@def",book),("@fx",received?actual-book:book-actual),("@ch",ch),("@fh",fh),("@u",user),("@g",reason));long result=Convert.ToInt64(save.ExecuteScalar());
  using var close=Q(c,t,"UPDATE dbo.MPX280_EbelgeMali SET Kapanan=Kapanan+@m,KapananTry=KapananTry+@try WHERE IslemId=@id",("@m",amount),("@try",book),("@id",operation));close.ExecuteNonQuery();t.Commit();return result;
 }
 public DataTable KurFarkiRaporu(HizliKimlik key)
 {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"EbelgeDeposu.KurFarkiRaporu","",new object?[]{key});}

  using var c=Ac();check(c,null,"FINANCE.FX.VIEW");using var q=Q(c,null,"SELECT o.Id AS OdemeId,i.BelgeNo,c.Unvan,o.Tarih,m.ParaBirimi,o.DovizTutar,o.Kur,o.TryTutar,o.DefterTry,CASE WHEN o.TersCariHareketId IS NULL THEN o.KurFarki ELSE 0 END AS AktifKurFarki,o.KurFarki AS IlkKurFarki,o.TersTarih,o.TersGerekce,o.Dayanak FROM dbo.MPX280_DovizOdeme o JOIN dbo.MPX280_EbelgeMali m ON m.IslemId=o.IslemId JOIN dbo.BERP270_EBelgeIslem i ON i.Id=m.IslemId JOIN dbo.CariKartlari c ON c.Id=i.CariId WHERE i.Ortam=@o AND i.Vkn=@v ORDER BY o.Id DESC",("@o",key.Ortam.ToString()),("@v",key.Vkn));using var r=q.ExecuteReader();var dt=new DataTable();dt.Load(r);return dt;
 }
}

