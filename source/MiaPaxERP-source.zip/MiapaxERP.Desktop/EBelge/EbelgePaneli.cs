using System.Data;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using TabControl=System.Windows.Controls.TabControl;


namespace MiapaxERP.Desktop.EBelge;

public sealed partial class EbelgePaneli:UserControl
{
 readonly string connection;readonly int user;readonly EbelgeDeposu depo;readonly string folder;
 readonly TextBlock status=new(){TextWrapping=TextWrapping.Wrap,Margin=new Thickness(8)};
 readonly TextBlock account=new(){Text="TEST bağlantısı seçilmedi.",Margin=new Thickness(8)};
 readonly DataGrid remote=new(){IsReadOnly=true,AutoGenerateColumns=true,CanUserAddRows=false};
 readonly DataGrid local=new(){IsReadOnly=true,AutoGenerateColumns=true,CanUserAddRows=false};
 readonly ComboBox box=new(){Width=190,ItemsSource=Enum.GetValues<EbelgeKutusu>(),SelectedIndex=0};
 readonly ComboBox drafts=new(){Width=140,ItemsSource=new[]{"Taslak dışı","Taslaklar","Tümü"},SelectedIndex=0};
 readonly DatePicker start=new(){SelectedDate=DateTime.Today.AddDays(-7),Width=130},end=new(){SelectedDate=DateTime.Today,Width=130};
 readonly WrapPanel tools=new();readonly TabControl tabs=new();HizliKimlik? key;bool? fetchedDraft;
 public bool IslemSuruyor{get;private set;}
 public EbelgePaneli(string connection,int user)
 {
  this.connection=connection;this.user=user;depo=new(connection,user);folder=HizliAyarDeposu.Klasor(connection,user);
  var root=new DockPanel{Margin=new Thickness(12)};Content=root;
  var top=new StackPanel();DockPanel.SetDock(top,Dock.Top);root.Children.Add(top);
  top.Children.Add(new TextBlock{Text="Hızlı Bilişim · E-Belge merkezi",FontSize=23,FontWeight=FontWeights.SemiBold});
  top.Children.Add(new TextBlock{Text="Gelen/giden e-Fatura, e-Arşiv ve e-İrsaliye sorguları; XML/PDF indirme ve UBL taslak kontrolü. Test işlemleri stok, cari veya kasa hareketi oluşturmaz. Taslak kabulü, GİB teslimi değildir.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,8,0,8)});
  top.Children.Add(account);top.Children.Add(tools);
  Button Add(string caption,Func<Task> action){var b=new Button{Content=caption,Padding=new Thickness(10,7,10,7),Margin=new Thickness(3)};b.Click+=async(_,_)=>await Run(action);tools.Children.Add(b);return b;}
  Add("E-belge tablolarını kur",()=>{depo.Kur();status.Text="E-belge tabloları ve ayrı kullanıcı yetkileri kuruldu. Yetkileri yönetim ekranından atayabilirsiniz.";return Task.CompletedTask;});
  Add("TEST bağlantı kurulumu",()=>{depo.Yetki("FINANCE.EBELGE.CONFIG");if(HttpsOturumu.Uzak(connection))new EbelgeSunucuBaglantisi(Window.GetWindow(this),connection,user,Ortam).ShowDialog();else new HizliBaglantiPenceresi{Owner=Window.GetWindow(this)}.ShowDialog();return Task.CompletedTask;});
  Add("Şifreli bağlantıyı yükle",Bagla);
  Add("Yerel kayıtları yenile",()=>{Yenile();return Task.CompletedTask;});
  DockPanel.SetDock(status,Dock.Bottom);root.Children.Add(status);root.Children.Add(tabs);
  var remotePage=new DockPanel();var filters=new WrapPanel{Margin=new Thickness(0,8,0,8)};DockPanel.SetDock(filters,Dock.Top);remotePage.Children.Add(filters);
  filters.Children.Add(box);filters.Children.Add(start);filters.Children.Add(end);filters.Children.Add(drafts);
  void Action(WrapPanel p,string label,Func<Task> action){var b=new Button{Content=label,Padding=new Thickness(10,7,10,7),Margin=new Thickness(3)};b.Click+=async(_,_)=>await Run(action);p.Children.Add(b);}
  Action(filters,"Sağlayıcıdan getir",Listele);Action(filters,"XML indir",()=>Indir("XML"));Action(filters,"PDF indir",()=>Indir("PDF"));remotePage.Children.Add(remote);
  tabs.Items.Add(new TabItem{Header="Sağlayıcı belge kutuları",Content=remotePage});
  var localPage=new DockPanel();var actions=new WrapPanel();DockPanel.SetDock(actions,Dock.Top);localPage.Children.Add(actions);
  Action(actions,"UBL XML'den test taslağı hazırla",Hazirla);Action(actions,"Seçili belgeyi gönder",TaslakGonder);Action(actions,"Seçili ETTN'yi sorgula",Sorgula);localPage.Children.Add(local);
  Action(actions,"Taslağı gönderime hazırla",()=>{var k=Key();var row=Secili();if(MessageBox.Show(Window.GetWindow(this),"Taslak aynı ETTN ve belge numarasıyla gönderime hazırlanacak. Henüz sağlayıcıya istek yapılmayacak. Devam edilsin mi?","Taslak onayı",MessageBoxButton.YesNo)==MessageBoxResult.Yes){depo.GonderimeHazirla(k,(long)row["Id"],(byte[])row["Surum"]);Yenile();status.Text="Belge hazır. Seçili belgeyi gönder düğmesiyle son gönderim onayını verebilirsiniz.";}return Task.CompletedTask;});
  tabs.Items.Add(new TabItem{Header="Kalıcı taslak / gönderim geçmişi",Content=localPage});
  BaglantilariEkle();
  Loaded+=async(_,_)=>{if(key is not null)return;await Run(()=>{depo.Yetki("FINANCE.EBELGE.VIEW");if(HttpsOturumu.Uzak(connection)){key=new EbelgeHttpsServisi(connection,user).Baglanti(Ortam);account.Text=key.Ortam+" · VKN/TCKN: "+key.Vkn+" · Sunucu bağlantısı";Yenile();return Task.CompletedTask;}var files=Directory.Exists(folder)?Directory.GetFiles(folder,"hizli-Test-*.dpapi"):Array.Empty<string>();if(files.Length==1){key=HizliAyarDeposu.Oku(files[0]);account.Text="TEST · VKN/TCKN: "+Key().Vkn+" · Hızlı Bilişim";Yenile();status.Text="Şifreli TEST bağlantı ayarı yüklendi; sorgu için ayrı yetki gerekir.";}else status.Text="Önce e-belge tablolarını kurun, yetkileri atayın ve şifreli TEST bağlantısını bağlayın.";return Task.CompletedTask;});};
 }
 async Task Run(Func<Task> action){if(IslemSuruyor)return;IslemSuruyor=true;tools.IsEnabled=false;tabs.IsEnabled=false;status.Text="İşlem sürüyor…";try{await action();}catch(Exception e){status.Text=e is EbelgeHatasi or ArgumentException or InvalidOperationException or UnauthorizedAccessException?e.Message:"İşlem tamamlanamadı. Veritabanı kurulumu, yetkiler ve bağlantıyı kontrol edin.";}finally{IslemSuruyor=false;tools.IsEnabled=true;tabs.IsEnabled=true;}}
 HizliKimlik Key(){var k=key??throw new InvalidOperationException("Önce seçili ortamın şifreli bağlantısını yükleyin.");if(k.Ortam!=Ortam)throw new InvalidOperationException("Seçili ortam ve bağlantı uyuşmuyor.");return k;}
 async Task Bagla()
 {
  depo.Yetki("FINANCE.EBELGE.CONFIG");if(HttpsOturumu.Uzak(connection)){key=await Task.Run(()=>new EbelgeHttpsServisi(connection,user).Baglanti(Ortam));account.Text=key.Ortam+" · VKN/TCKN: "+key.Vkn+" · Sunucu bağlantısı";Yenile();return;}string selected;
  if(Ortam==EbelgeOrtam.Canli){selected=Directory.GetFiles(folder,"hizli-Canli-*.dpapi").Single();}
  else if(File.Exists(Path.Combine(HizliAyarDeposu.KurulumKlasoru,"aktif-test.json")))selected=HizliAyarDeposu.AktifTestDosyasi(HizliAyarDeposu.KurulumKlasoru);
  else{var d=new OpenFileDialog{Title="Aynı Windows hesabında hazırlanmış şifreli TEST bağlantısını seçin",Filter="Şifreli bağlantı|*.dpapi",InitialDirectory=Directory.Exists(folder)?folder:HizliAyarDeposu.KurulumKlasoru};if(d.ShowDialog()!=true)return;selected=d.FileName;}
  var loaded=HizliAyarDeposu.Oku(selected);if(loaded.Ortam!=Ortam)throw new ArgumentException("Bağlantı ve seçili ortam uyuşmuyor.");if(loaded.Ortam==EbelgeOrtam.Canli)depo.FirmaEsle(loaded.Vkn);using var api=new HizliApi(loaded.Ortam,loaded,erpConnection:connection);await api.Giris(default);HizliAyarDeposu.Kaydet(folder,loaded);key=loaded;account.Text=loaded.Ortam+" · VKN/TCKN: "+loaded.Vkn+" · Hızlı Bilişim";status.Text="Bağlantı ERP veritabanı ve kullanıcı kapsamına şifreli kaydedildi.";Yenile();
 }
 void Yenile(){local.ItemsSource=depo.Liste(Key()).DefaultView;}
 bool? Taslak()=>drafts.SelectedIndex switch{0=>false,1=>true,_=>null};
 async Task Listele(){depo.Yetki("FINANCE.EBELGE.QUERY");var k=Key();using var api=new HizliApi(k.Ortam,k,erpConnection:connection);if(start.SelectedDate is not{} s||end.SelectedDate is not{} e)throw new ArgumentException("Başlangıç ve bitiş tarihini seçin.");bool? selected=Taslak();remote.ItemsSource=await api.Liste((EbelgeKutusu)box.SelectedItem,s.Date,e.Date.AddDays(1).AddTicks(-1),selected,default);fetchedDraft=selected;status.Text="Sağlayıcının döndürdüğü kayıtlar gösteriliyor. Liste eksiksiz bir muhasebe mutabakatı sayılmaz; nihai GİB durumu ayrıca değerlendirilir.";}
 async Task Indir(string type)
 {
  depo.Yetki("FINANCE.EBELGE.DOWNLOAD");var k=Key();if(remote.SelectedItem is not HizliKayit item)throw new ArgumentException("Bir sağlayıcı belgesi seçin.");var date=EbelgeTarihi.Oku(item.RawIssueDate);var save=new SaveFileDialog{Filter=type+"|*."+type.ToLowerInvariant(),FileName=item.UUID.ToString("D")+"."+type.ToLowerInvariant()};if(save.ShowDialog()!=true)return;
  bool? isDraft=item.IsDraft??fetchedDraft;if(isDraft is null)throw new ArgumentException("Taslak durumu bilinmiyor. Taslaklar veya Taslak dışı filtresiyle listeyi yeniden getirin.");
  using var api=new HizliApi(k.Ortam,k,erpConnection:connection);var bytes=await api.Dosya((EbelgeKutusu)item.AppType,item.UUID,type,isDraft,date,default);
  if(type=="PDF"&&!bytes.AsSpan().StartsWith("%PDF-"u8))throw new EbelgeHatasi("Sağlayıcı PDF yerine farklı içerik döndürdü; dosya kaydedilmedi.");
  if(type=="XML"){var text=new UTF8Encoding(false,true).GetString(bytes).TrimStart('\uFEFF');UblKimlik.Oku(text);}
  await File.WriteAllBytesAsync(save.FileName,bytes);status.Text="Belge dosyası kaydedildi. Dosya otomatik açılmadı.";
 }
 async Task Hazirla()
 {
  depo.Yetki("FINANCE.EBELGE.DRAFT");var k=Key();var open=new OpenFileDialog{Filter="UBL XML|*.xml",Title="Kimlik bilgileri ve tutarları hazırlanmış TEST UBL dosyası"};if(open.ShowDialog()!=true)return;if(new FileInfo(open.FileName).Length>8_000_000)throw new ArgumentException("XML en fazla 8 MB olabilir.");string xml=await File.ReadAllTextAsync(open.FileName);var u=UblKimlik.Oku(xml);int app=u.Irsaliye?5:u.Profil=="EARSIVFATURA"?3:1;if(u.Gonderen!=k.Vkn)throw new ArgumentException("UBL göndericisi TEST bağlantısının VKN/TCKN'siyle uyuşmuyor.");
  using var api=new HizliApi(k.Ortam,k,erpConnection:connection);var sender=await api.Mukellef(app==5?5:1,"GB",k.Vkn,default);var recipients=app==3?Array.Empty<HizliMukellef>():await api.Mukellef(app==5?5:1,"PK",u.Alici,default);
  string source=Etiket(sender,"Gönderici GB etiketi");string target=app==3?"":Etiket(recipients,"Alıcı PK etiketi");var input=new HizliGonderi(app,source,u.Alici,target,xml,u.Ettn.ToString("D"),u.No,u.Tarih.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture),"MIAPAX ERP-"+u.Ettn.ToString("N"));
  long id=depo.Hazirla(k,input);Yenile();status.Text="TEST taslak kaydı hazır: "+id+". Henüz sağlayıcıya gönderilmedi. Belge numarası/ETTN XML'den korundu; yeni numara varsayılmadı.";
 }
 string Etiket(HizliMukellef[] list,string title)
 {
  if(list.Length==0)throw new EbelgeHatasi(title+" bulunamadı.");var choose=new Window{Title=title,Width=650,Height=240,Owner=Window.GetWindow(this),WindowStartupLocation=WindowStartupLocation.CenterOwner};var p=new StackPanel{Margin=new Thickness(16)};choose.Content=p;var choices=new ComboBox{ItemsSource=list,DisplayMemberPath="Alias",SelectedIndex=0,Margin=new Thickness(0,16,0,16)};p.Children.Add(new TextBlock{Text="Kullanılacak kayıtlı etiketi seçip doğrulayın."});p.Children.Add(choices);var ok=new Button{Content="Bu etiketi kullan",Padding=new Thickness(12)};ok.Click+=(_,_)=>choose.DialogResult=true;p.Children.Add(ok);if(choose.ShowDialog()!=true)throw new InvalidOperationException("Etiket seçimi iptal edildi.");return ((HizliMukellef)choices.SelectedItem).Alias;
 }
 DataRowView Secili()=>local.SelectedItem as DataRowView??throw new ArgumentException("Yerel bir taslak kaydı seçin.");
 async Task TaslakGonder()
 {
  var k=Key();var r=Secili();bool draft=(bool)r["Taslak"];depo.Yetki(draft?"FINANCE.EBELGE.DRAFT":"FINANCE.EBELGE.SEND");if(k.Ortam==EbelgeOrtam.Canli)depo.FirmaEsle(k.Vkn);string intent=draft?"Sağlayıcıda TASLAK oluşturulacak.":k.Ortam==EbelgeOrtam.Canli?"CANLI ortamda resmî belge gönderimi başlatılacak.":"TEST ortamında gönderim başlatılacak.";if(MessageBox.Show(Window.GetWindow(this),intent+"\nBelge: "+r["BelgeNo"]+"\nAlıcı: "+r["Alici"]+"\nETTN: "+r["Ettn"]+"\n\nİçerik ve gönderim türünü kontrol ettiniz mi?","E-belge gönderim onayı",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)return;
  if(HttpsOturumu.Uzak(connection)){try{await Task.Run(()=>new EbelgeHttpsServisi(connection,user).Gonder(k.Ortam,(long)r["Id"],(byte[])r["Surum"]));status.Text="Sunucu gönderimi tamamladı. ETTN ile son durumu sorgulayın.";}finally{Yenile();}return;}
  using var api=new HizliApi(k.Ortam,k,erpConnection:connection);await api.Giris(default);long id=(long)r["Id"];var input=depo.Baslat(k,id,(byte[])r["Surum"]);try{await api.Gonder(input,default);depo.Sonuc(k,id,draft?"Taslak kabul edildi":"Gönderim kabul edildi","Sağlayıcı isteği kabul etti; nihai GİB durumu ayrıca sorgulanmalı.");status.Text="Sağlayıcı isteği kabul etti. ETTN ile son durumunu sorgulayın.";}
  catch(EbelgeHatasi e){depo.Sonuc(k,id,e.Belirsiz?"Belirsiz":"Reddedildi",e.Message);throw;}finally{Yenile();}
 }
 async Task Sorgula()
 {
  depo.Yetki("FINANCE.EBELGE.QUERY");var k=Key();var r=Secili();if(HttpsOturumu.Uzak(connection)){var result=await Task.Run(()=>new EbelgeHttpsServisi(connection,user).YerelSorgula(k.Ortam,(long)r["Id"]));Yenile();status.Text=result is null?"Sağlayıcı kayıt döndürmedi; yeniden göndermeden inceleyin.":"Sağlayıcı: "+result.Status+" / "+result.StatusExp;return;}using var api=new HizliApi(k.Ortam,k,erpConnection:connection);var found=await api.Sorgula(EbelgeDeposu.Kutu((int)r["AppType"]),(Guid)r["Ettn"],default);if(found is not null){depo.SorguKaydet(k,(long)r["Id"],found);Yenile();}status.Text=found is null?"Sağlayıcı kayıt döndürmedi. Bu sonuç yeniden gönderim izni değildir; kayıt ve hizmet durumu araştırılmalı.":"Sağlayıcı durumu: "+found.Status+" / "+found.StatusExp+" · Zarf: "+found.EnvelopeStatus+" / "+found.EnvelopeExp+". Bu kodlar otomatik mali kayıt oluşturmaz.";
 }
}

