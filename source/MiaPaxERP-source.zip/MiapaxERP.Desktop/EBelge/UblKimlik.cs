using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Xml;
using System.Xml.Linq;
namespace MiapaxERP.Desktop.EBelge;

// Kimlik denetimidir; GİB şema/schematron ve mali mevzuat doğrulamasının yerine geçmez.
public sealed record UblKimlik(Guid Ettn,string No,DateTime Tarih,string Gonderen,string Alici,bool Irsaliye,string Profil,string Tur,string Ozet)
{
 public static UblKimlik Oku(string xml)
 {
  if(string.IsNullOrWhiteSpace(xml)||Encoding.UTF8.GetByteCount(xml)>8_000_000)throw new ArgumentException("UBL XML boş veya 8 MB sınırını aşıyor.");
  var settings=new XmlReaderSettings{DtdProcessing=DtdProcessing.Prohibit,XmlResolver=null,MaxCharactersInDocument=8_000_000};XDocument doc;
  try{using var r=XmlReader.Create(new StringReader(xml),settings);doc=XDocument.Load(r);}catch(XmlException){throw new ArgumentException("UBL XML okunamadı. DTD ve dış kaynaklara izin verilmez.");}
  var root=doc.Root??throw new ArgumentException("XML kök öğesi eksik.");bool despatch=root.Name==XName.Get("DespatchAdvice","urn:oasis:names:specification:ubl:schema:xsd:DespatchAdvice-2");
  if(!despatch&&root.Name!=XName.Get("Invoice","urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"))throw new ArgumentException("Invoice veya DespatchAdvice UBL XML seçin.");
  XNamespace b="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2",a="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2";
  string Single(XElement e,XName name){var list=e.Elements(name).ToArray();if(list.Length!=1||string.IsNullOrWhiteSpace(list[0].Value))throw new ArgumentException("UBL alanı eksik/tekrarlı: "+name.LocalName);return list[0].Value.Trim();}
  string Tax(string name){var parties=root.Elements(a+name).ToArray();if(parties.Length!=1)throw new ArgumentException("UBL taraf bilgisi eksik/tekrarlı.");var ids=parties[0].Elements(a+"Party").Elements(a+"PartyIdentification").Elements(b+"ID").Where(x=>(string?)x.Attribute("schemeID") is "VKN" or "TCKN").ToArray();if(ids.Length!=1||!System.Text.RegularExpressions.Regex.IsMatch(ids[0].Value,"^[0-9]{10,11}$"))throw new ArgumentException("UBL tarafının tek bir VKN/TCKN kimliği olmalı.");return ids[0].Value;}
  if(!Guid.TryParse(Single(root,b+"UUID"),out var uuid)||uuid==Guid.Empty)throw new ArgumentException("UBL ETTN geçersiz.");string no=Single(root,b+"ID");if(!System.Text.RegularExpressions.Regex.IsMatch(no,"^[A-Z0-9]{3}[0-9]{13}$"))throw new ArgumentException("UBL belge numarası 3 karakter seri ve 13 rakamdan oluşmalı.");
  if(!DateTime.TryParseExact(Single(root,b+"IssueDate"),"yyyy-MM-dd",CultureInfo.InvariantCulture,DateTimeStyles.None,out var date)||no.Substring(3,4)!=date.Year.ToString(CultureInfo.InvariantCulture))throw new ArgumentException("UBL tarih ve belge numarası yılı uyuşmuyor.");
  return new(uuid,no,date,Tax(despatch?"DespatchSupplierParty":"AccountingSupplierParty"),Tax(despatch?"DeliveryCustomerParty":"AccountingCustomerParty"),despatch,Single(root,b+"ProfileID"),Single(root,b+(despatch?"DespatchAdviceTypeCode":"InvoiceTypeCode")),Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(xml))));
 }
 public void Esle(HizliKimlik key,HizliGonderi input)
 {
  if(Gonderen!=key.Vkn||Alici!=input.DestinationIdentifier||!Guid.TryParse(input.DocumentUUID,out var uuid)||uuid!=Ettn||input.DocumentId!=No||input.DocumentDate!=Tarih.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture)||Irsaliye!=(input.AppType==5))throw new ArgumentException("UBL ile gönderim kimliği, firma veya belge türü uyuşmuyor.");
  if(input.AppType==3&&Profil!="EARSIVFATURA"||input.AppType==1&&Profil=="EARSIVFATURA")throw new ArgumentException("e-Fatura/e-Arşiv uygulaması ve UBL profili uyuşmuyor.");
  if(string.IsNullOrWhiteSpace(input.SourceUrn)||input.AppType!=3&&string.IsNullOrWhiteSpace(input.DestinationUrn))throw new ArgumentException("Gönderici/alıcı etiketi seçilmedi.");
 }
}
