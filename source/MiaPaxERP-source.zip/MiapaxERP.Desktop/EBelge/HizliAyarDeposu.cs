using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop.EBelge;

public static class HizliAyarDeposu
{
 public static string KurulumKlasoru=>Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"BoruERP","EBelge","Kurulum");
 public static string Klasor(string connection,int user){if(user<1)throw new ArgumentException("ERP kullanıcı hesabı gerekli.");string scope;if(connection.StartsWith("miapax-https:",StringComparison.Ordinal))scope=connection;else{var b=new SqlConnectionStringBuilder(connection);scope=b.DataSource.Trim().ToUpperInvariant()+"|"+b.InitialCatalog.Trim().ToUpperInvariant();}string id=Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(scope)))[..32];return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"BoruERP","EBelge",id,user.ToString());}
 public static string Dosya(string folder,EbelgeOrtam env,string vkn){if(!System.Text.RegularExpressions.Regex.IsMatch(vkn,"^[0-9]{10,11}$"))throw new ArgumentException("VKN/TCKN geçersiz.");return Path.Combine(folder,"hizli-"+env+"-"+vkn+".dpapi");}
 public static string AktifTestDosyasi(string folder)
 {
  string index=Path.Combine(folder,"aktif-test.json");if(File.Exists(index)){string name=JsonSerializer.Deserialize<string>(File.ReadAllText(index))??"";if(!System.Text.RegularExpressions.Regex.IsMatch(name,"^hizli-Test-[0-9]{10,11}\\.dpapi$"))throw new InvalidDataException("Aktif test ayarı geçersiz.");return Path.Combine(folder,name);}
  return Directory.GetFiles(folder,"hizli-Test-*.dpapi").Single();
 }
 public static void AktifTestSec(string folder,HizliKimlik key)
 {
  if(key.Ortam!=EbelgeOrtam.Test)throw new ArgumentException("Yalnız TEST bağlantısı seçilebilir.");Kaydet(folder,key);string index=Path.Combine(folder,"aktif-test.json"),tmp=index+"."+Guid.NewGuid().ToString("N")+".tmp";try{File.WriteAllText(tmp,JsonSerializer.Serialize(Path.GetFileName(Dosya(folder,key.Ortam,key.Vkn))));File.Move(tmp,index,true);}finally{if(File.Exists(tmp))File.Delete(tmp);}
 }
 public static string Kaydet(string folder,HizliKimlik value)
 {
  EbelgeJson.KimlikDogrula(value);Directory.CreateDirectory(folder);string path=Dosya(folder,value.Ortam,value.Vkn),tmp=path+"."+Guid.NewGuid().ToString("N")+".tmp";byte[] plain=JsonSerializer.SerializeToUtf8Bytes(value,EbelgeJson.Ayar);
  try{byte[] data=ProtectedData.Protect(plain,null,DataProtectionScope.CurrentUser);try{using(var f=new FileStream(tmp,FileMode.CreateNew,FileAccess.Write,FileShare.None)){f.Write(data);f.Flush(true);}File.Move(tmp,path,true);}finally{if(File.Exists(tmp))File.Delete(tmp);}}finally{CryptographicOperations.ZeroMemory(plain);}return path;
 }
 public static HizliKimlik Oku(string path)
 {
  if(new FileInfo(path).Length>131072)throw new InvalidDataException("Şifreli bağlantı ayarı izin verilen boyutu aşıyor.");
  byte[] plain=ProtectedData.Unprotect(File.ReadAllBytes(path),null,DataProtectionScope.CurrentUser);try{var value=JsonSerializer.Deserialize<HizliKimlik>(plain,EbelgeJson.Ayar)??throw new InvalidDataException("Bağlantı ayarı okunamadı.");EbelgeJson.KimlikDogrula(value);return value;}finally{CryptographicOperations.ZeroMemory(plain);}
 }
}

