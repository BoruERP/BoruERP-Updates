using System.Data;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop.EBelge;
public sealed partial class EbelgeDeposu
{
 public void TarafKaydet(EbelgeOrtam env,UblTaraf taraf){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EbelgeDeposu.TarafKaydet","",new object?[]{env,taraf});return;}
if(!Enum.IsDefined(env)||!System.Text.RegularExpressions.Regex.IsMatch(taraf.Vkn,"^[0-9]{10,11}$"))throw new ArgumentException("Ortam/VKN geçersiz.");using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"FINANCE.EBELGE.CONFIG");using var q=Q(c,t,"UPDATE dbo.BERP270_EBelgeTaraf WITH(UPDLOCK,HOLDLOCK) SET Veri=@j,Kullanici=@u WHERE Ortam=@o AND Vkn=@v;IF @@ROWCOUNT=0 INSERT dbo.BERP270_EBelgeTaraf(Ortam,Vkn,Veri,Kullanici)VALUES(@o,@v,@j,@u)",("@j",EbelgeJson.Yaz(taraf)),("@u",user),("@o",env.ToString()),("@v",taraf.Vkn));q.ExecuteNonQuery();t.Commit();}
 public UblTaraf TarafOku(HizliKimlik key,string vkn){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<UblTaraf>(connection,"EbelgeDeposu.TarafOku","",new object?[]{key,vkn});}
using var c=Ac();check(c,null,"FINANCE.EBELGE.VIEW");return Taraf(c,null,key.Ortam,vkn);}
 static UblTaraf Taraf(SqlConnection c,SqlTransaction? t,EbelgeOrtam env,string vkn)
 {
  using(var q=Q(c,t,"SELECT Veri FROM dbo.BERP270_EBelgeTaraf WHERE Ortam=@o AND Vkn=@v",("@o",env.ToString()),("@v",vkn))){if(q.ExecuteScalar() is string data)return System.Text.Json.JsonSerializer.Deserialize<UblTaraf>(data)??throw new ArgumentException("E-belge tarafı okunamadı.");}
  if(env==EbelgeOrtam.Canli){using var q=Q(c,t,"SELECT TOP(1) VergiNo,FirmaAdi,VergiDairesi,Adres,Il,Ilce,Ulke FROM dbo.FirmaBilgileri WHERE VergiNo=@v",("@v",vkn));using var r=q.ExecuteReader();if(r.Read())return new(r.GetString(0),r.GetString(1),r.GetString(2),r.GetString(3),r.GetString(4),r.GetString(5),r.GetString(6));}
  throw new ArgumentException("Firma/cari için e-belge adres bilgilerini tanımlayın. VKN/TCKN: "+vkn);
 }
 public DataTable Satislar(){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"EbelgeDeposu.Satislar","",new object?[]{});}
using var c=Ac();check(c,null,"FINANCE.EBELGE.DRAFT");check(c,null,"CUSTOMER.VIEW");using var q=Q(c,null,"SELECT TOP(300) b.Id,b.BelgeNo,b.Tarih,b.CariId,c.Unvan,c.VergiNo,b.GenelToplam,b.Indirim,b.Durum,b.ParaBirimi FROM dbo.BoruERP_YeniBelgeler b JOIN dbo.CariKartlari c ON c.Id=b.CariId WHERE b.BelgeTuru=N'S' AND c.Aktif=1 ORDER BY b.Id DESC");using var r=q.ExecuteReader();var dt=new DataTable();dt.Load(r);return dt;}
 public string SatisXml(HizliKimlik key,long sale,Guid uuid,string no,DateTime issue,int app,string profile,UblSevk? sevk,string? gonderimSekli=null)
 {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<string>(connection,"EbelgeDeposu.SatisXml","",new object?[]{key,sale,uuid,no,issue,app,profile,sevk,gonderimSekli});}

  using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"FINANCE.EBELGE.DRAFT");check(c,t,"CUSTOMER.VIEW");string vkn,currency;decimal net,tax,total,discount;
  using(var q=Q(c,t,"SELECT c.VergiNo,b.AraToplam,b.KdvToplam,b.GenelToplam,b.Indirim,b.ParaBirimi FROM dbo.BoruERP_YeniBelgeler b WITH(UPDLOCK,HOLDLOCK) JOIN dbo.CariKartlari c WITH(HOLDLOCK) ON c.Id=b.CariId WHERE b.Id=@id AND b.BelgeTuru=N'S' AND c.Aktif=1 AND b.Durum<>N'İptal'",("@id",sale))){using var r=q.ExecuteReader();if(!r.Read())throw new ArgumentException("Aktif satış bulunamadı.");vkn=r.GetString(0);net=r.GetDecimal(1);tax=r.GetDecimal(2);total=r.GetDecimal(3);discount=r.GetDecimal(4);currency=r.GetString(5);}
  var settings=SatisMali(c,t,sale);var mali=settings.Mali;
  if(mali.Doviz!=currency)throw new ArgumentException("Satışın döviz kuru ve mali bilgilerini tanımlayın.");
  if(discount!=0&&!settings.Indirim&&app!=5)throw new ArgumentException("Eski KDV sonrası indirimin satır KDV'lerine dağılımını Mali bilgiler ekranında kontrol edip açıkça onaylayın.");
  var rows=new List<UblSatir>();using(var q=Q(c,t,"SELECT k.Id,s.StokKodu,k.UrunAciklama,k.Miktar,k.BirimFiyat,k.KdvOrani,b.Ubl,k.SatirAraToplam,k.KdvTutari,k.SatirGenelToplam FROM dbo.BoruERP_YeniBelgeKalemleri k WITH(HOLDLOCK) JOIN dbo.StokKartlari s ON s.Id=k.StokKartId LEFT JOIN dbo.BERP270_EBelgeBirim b ON b.Yerel=k.Birim WHERE k.BelgeId=@id ORDER BY k.Id",("@id",sale))){using var r=q.ExecuteReader();while(r.Read()){if(r.IsDBNull(6))throw new ArgumentException("Satış satırının yerel/UBL birim eşlemesi eksik.");var row=new UblSatir(Convert.ToString(r[0],System.Globalization.CultureInfo.InvariantCulture)!,r.GetString(1),r.GetString(2),r.GetDecimal(3),r.GetString(6),r.GetDecimal(4),r.GetDecimal(5));decimal amount=UblBelge.Yuvarla(row.Miktar*row.Fiyat),vat=UblBelge.Yuvarla(amount*row.KdvOrani/100);if(amount!=r.GetDecimal(7)||vat!=r.GetDecimal(8)||amount+vat!=r.GetDecimal(9))throw new ArgumentException("Kaydedilmiş satış satırı ile hesaplanan toplam uyuşmuyor; belge incelenmeli.");rows.Add(row);}}
  if(rows.Sum(x=>UblBelge.Yuvarla(x.Miktar*x.Fiyat))!=net||rows.Sum(x=>UblBelge.Yuvarla(UblBelge.Yuvarla(x.Miktar*x.Fiyat)*x.KdvOrani/100))!=tax||net+tax-discount!=total)throw new ArgumentException("Kaynak satış toplamları uyuşmuyor.");
  if(discount!=0&&app!=5){var split=UblMaliHesap.EskiBrutIndirim(rows.ToArray(),discount);rows=split.Satirlar.ToList();mali=mali with{Yuvarlama=split.Yuvarlama,IndirimAciklamasi="Kaynak satış KDV sonrası brüt indirim: "+discount+" "+currency+". Satırların kendi KDV oranıyla matraha dağıtıldı. Kuruş farkı: "+split.Yuvarlama+". Kontrol: "+settings.Dayanak};}
  var supplier=Taraf(c,t,key.Ortam,key.Vkn);var customer=Taraf(c,t,key.Ortam,vkn);string xml=UblBelge.Olustur(uuid,no,issue,app,profile,supplier,customer,rows.ToArray(),sevk,gonderimSekli,app==5?null:mali);var d=UblBelge.Oku(xml);if(app!=5&&d.Odenecek+d.Tevkifat!=total)throw new ArgumentException("Satış başlığı ile e-belge toplamı uyuşmuyor.");UblSema.Dogrula(xml);t.Commit();return xml;
 }
 public DataTable IslemListesi(HizliKimlik key){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"EbelgeDeposu.IslemListesi","",new object?[]{key});}
using var c=Ac();check(c,null,"FINANCE.EBELGE.VIEW");using var q=Q(c,null,"SELECT TOP(500) i.*,d.Kutu FROM dbo.BERP270_EBelgeIslem i LEFT JOIN dbo.BERP270_EBelgeDosya d ON d.Ortam=i.Ortam AND d.Vkn=i.Vkn AND d.Ettn=i.Ettn WHERE i.Ortam=@o AND i.Vkn=@v ORDER BY i.Id DESC",("@o",key.Ortam.ToString()),("@v",key.Vkn));using var r=q.ExecuteReader();var dt=new DataTable();dt.Load(r);return dt;}
}
