using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using static MiapaxERP.Desktop.EBelge.EbelgeJson;
namespace MiapaxERP.Desktop.EBelge;

public sealed class HizliApi:IDisposable
{
 readonly string? proxy;readonly EbelgeOrtam environment;
#if !MIAPAX_STANDALONE
 EbelgeHttpsServisi Proxy()=>new(proxy!,HttpsOturumu.Istemci?.Oturum?.Kullanici.Id??throw new UnauthorizedAccessException());
#endif
 readonly HttpClient http;readonly Uri root;readonly HizliKimlik? kimlik;readonly SemaphoreSlim login=new(1,1);string? token;
 public HizliApi(EbelgeOrtam ortam,HizliKimlik? kimlik=null,HttpMessageHandler? testHandler=null,string? erpConnection=null)
 {
#if !MIAPAX_STANDALONE
  environment=ortam;proxy=erpConnection is not null&&HttpsOturumu.Uzak(erpConnection)?erpConnection:null;
#else
  environment=ortam;proxy=null;
#endif
  if(!Enum.IsDefined(ortam)||kimlik is not null&&kimlik.Ortam!=ortam)throw new ArgumentException("Bağlantı ortamı uyuşmuyor.");if(kimlik is not null&&proxy is null)KimlikDogrula(kimlik);this.kimlik=kimlik;
  root=new Uri(ortam==EbelgeOrtam.Test?"https://econnecttest.hizliteknoloji.com.tr/HizliApi/RestApi/":"https://econnect.hizliteknoloji.com.tr/HizliApi/RestApi/");
  http=new HttpClient(testHandler??new SocketsHttpHandler{AllowAutoRedirect=false,UseCookies=false,UseProxy=false,ConnectTimeout=TimeSpan.FromSeconds(15)}){Timeout=TimeSpan.FromSeconds(90),MaxResponseContentBufferSize=32*1024*1024};
 }
 async Task<JsonElement> Request(HttpMethod method,string path,object? body,CancellationToken ct,bool authorized=false,bool mutation=false)
 {
  if(Uri.TryCreate(path,UriKind.Absolute,out _)||path.StartsWith('/')||path.Contains("..")||path.Contains('\\'))throw new ArgumentException("Servis yolu geçersiz.");
  if(authorized)await Giris(ct);using var q=new HttpRequestMessage(method,new Uri(root,path));q.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));q.Headers.UserAgent.ParseAdd("MiapaxERP/2.7");if(authorized)q.Headers.Authorization=new AuthenticationHeaderValue("Bearer",token);if(body is not null)q.Content=new StringContent(Yaz(body),Encoding.UTF8,"application/json");
  try{using var r=await http.SendAsync(q,ct);if(r.StatusCode==HttpStatusCode.Unauthorized)token=null;if((int)r.StatusCode is >=300 and <400)throw new EbelgeHatasi("Sağlayıcı yönlendirme döndürdü. Kimlik bilgileri başka adrese gönderilmedi.",mutation);if(!r.IsSuccessStatusCode)throw new EbelgeHatasi($"Hızlı Bilişim HTTP {(int)r.StatusCode}. Bağlantı bilgilerini ve servis yetkisini kontrol edin.",mutation&&(int)r.StatusCode>=500);string text=await r.Content.ReadAsStringAsync(ct);if(path=="Login"&&Regex.IsMatch(text.Trim(),"^[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+$"))return JsonSerializer.SerializeToElement(text.Trim());using var doc=JsonDocument.Parse(text);return doc.RootElement.Clone();}
  catch(EbelgeHatasi){throw;}catch(Exception e)when(e is HttpRequestException or TaskCanceledException or JsonException){throw new EbelgeHatasi(mutation?"İşlem sonucu belirsiz. ETTN/LocalId ile sorgulamadan tekrar göndermeyin.":"Sağlayıcıya ulaşılamadı veya yanıt okunamadı.",mutation);}
 }
 public async Task<HizliKimlik> IlkKurulum(string vkn,string apiKey,string secret,string user,string password,CancellationToken ct)
 {
#if !MIAPAX_STANDALONE
  if(proxy is not null){return await Task.Run(()=>Proxy().Kurulum(new(environment,vkn,apiKey,secret,user,password)),ct);}
#endif

  if(!Regex.IsMatch(vkn,"^[0-9]{10,11}$"))throw new ArgumentException("VKN/TCKN geçersiz.");foreach(var s in new[]{apiKey,secret,user,password})if(string.IsNullOrWhiteSpace(s)||s.Length>8192||s.Any(char.IsControl))throw new ArgumentException("Bağlantı alanları eksik/geçersiz.");
  var j=await Request(HttpMethod.Post,"UtilEncrypt",new{secretKey=secret,username=user,password},ct);string u=S(j,"username"),p=S(j,"password");if(u.Length==0||p.Length==0||u==user||p==password)throw new EbelgeHatasi("Sağlayıcı şifrelenmiş kullanıcı bilgilerini doğrulanabilir biçimde döndürmedi.");var k=new HizliKimlik(root.Host.StartsWith("econnecttest.")?EbelgeOrtam.Test:EbelgeOrtam.Canli,vkn,apiKey,u,p);KimlikDogrula(k);return k;
 }
 public async Task Giris(CancellationToken ct)
 {
#if !MIAPAX_STANDALONE
  if(proxy is not null){await Task.Run(()=>Proxy().Giris(environment),ct);return;}
#endif

  if(token is not null)return;if(kimlik is null)throw new ArgumentException("Önce güvenli bağlantı kurulumu yapın.");await login.WaitAsync(ct);try{if(token is not null)return;var j=await Request(HttpMethod.Post,"Login",new{apiKey=kimlik.ApiKey,username=kimlik.SifreliKullanici,password=kimlik.SifreliParola},ct);token=HizliTokenYaniti.Oku(j);}finally{login.Release();}
 }
 static string Query(params(string Name,string Value)[] values)=>string.Join("&",values.Select(x=>Uri.EscapeDataString(x.Name)+"="+Uri.EscapeDataString(x.Value)));
 public async Task<HizliMukellef[]> Mukellef(int appType,string type,string vkn,CancellationToken ct)
 {
#if !MIAPAX_STANDALONE
  if(proxy is not null){return await Task.Run(()=>Proxy().Mukellef(environment,appType,type,vkn),ct);}
#endif

  if(appType is not(1 or 5)||type is not("GB" or "PK")||!Regex.IsMatch(vkn,"^[0-9]{10,11}$"))throw new ArgumentException("Mükellef sorgusunda uygulama/etiket türü ve VKN/TCKN gerekli.");var j=await Request(HttpMethod.Get,"GetGibUserList?"+Query(("AppType",appType.ToString()),("Type",type),("Identifier",vkn)),null,ct,true);if(!Basarili(j))throw new EbelgeHatasi("Mükellef sorgusu başarısız. Başarısız yanıt, mükellef kaydı yok anlamına gelmez. "+YanitBicimi(j)+" / "+HataSinifi(j));var list=P(j,"gibUserLists");if(list.ValueKind!=JsonValueKind.Array)throw new EbelgeHatasi("Mükellef listesi yanıtı eksik.");return list.EnumerateArray().Select(x=>new HizliMukellef(S(x,"Identifier"),S(x,"Alias"),S(x,"Title"),S(x,"Type"))).Where(x=>x.Identifier==vkn).ToArray();
 }
 static bool? IptalDurumu(JsonElement x){var v=P(x,"CancelDate");if(v.ValueKind==JsonValueKind.Undefined)return null;if(v.ValueKind==JsonValueKind.Null||string.IsNullOrWhiteSpace(v.ToString()))return false;string date=v.ToString();if(date.StartsWith("0001-",StringComparison.Ordinal))return false;return EbelgeTarihi.Oku(date).Year>1900;}
 static HizliKayit[] Rows(JsonElement j)
 {
  if(!Basarili(j)||P(j,"documents").ValueKind!=JsonValueKind.Array)throw new EbelgeHatasi("Belge listesi doğrulanamadı.");var rows=new List<HizliKayit>();foreach(var x in P(j,"documents").EnumerateArray()){if(!Guid.TryParse(S(x,"UUID"),out var id))throw new EbelgeHatasi("Sağlayıcı geçersiz ETTN döndürdü.");decimal D(string name)=>P(x,name).ValueKind==JsonValueKind.Number?P(x,name).GetDecimal():throw new EbelgeHatasi("Belge tutarı yanıtı eksik.");int I(string name)=>P(x,name).ValueKind==JsonValueKind.Number?P(x,name).GetInt32():throw new EbelgeHatasi("Belge durum yanıtı eksik.");rows.Add(new(id,I("AppType"),S(x,"DocumentId"),S(x,"TargetTitle"),S(x,"TargetIdentifier"),S(x,"ProfileId"),S(x,"DocumentTypeCode"),S(x,"DocumentCurrencyCode"),D("TaxTotal"),D("PayableAmount"),I("Status"),S(x,"StatusExp"),I("EnvelopeStatus"),S(x,"EnvelopeExp"),S(x,"IssueDate"),S(x,"LocalReferenceId"),P(x,"IsDraft").ValueKind is JsonValueKind.True or JsonValueKind.False?P(x,"IsDraft").GetBoolean():null,IptalDurumu(x)));}return rows.ToArray();
 }
 public async Task<HizliKayit[]> Liste(EbelgeKutusu box,DateTime start,DateTime end,bool? draft,CancellationToken ct)
 {
#if !MIAPAX_STANDALONE
  if(proxy is not null){return await Task.Run(()=>Proxy().Liste(environment,box,start,end,draft),ct);}
#endif

  if(!Enum.IsDefined(box)||end<start||end-start>TimeSpan.FromDays(31))throw new ArgumentException("Belge kutusu ve en fazla 31 günlük tarih aralığı seçin.");string F(DateTime d)=>d.ToString("yyyy-MM-dd HH:mm:ss",System.Globalization.CultureInfo.InvariantCulture);var j=await Request(HttpMethod.Get,"GetDocumentList?"+Query(("AppType",((int)box).ToString()),("DateType","IssueDate"),("StartDate",F(start)),("EndDate",F(end)),("IsNew","false"),("IsExport","false"),("IsDraft",draft?.ToString().ToLowerInvariant()??""),("TakenFromEntegrator","ALL")),null,ct,true);var rows=Rows(j);if(rows.Any(x=>x.AppType!=(int)box))throw new EbelgeHatasi("Sağlayıcı farklı belge kutusundan yanıt verdi.");return rows;
 }
 public async Task<HizliKayit?> Sorgula(EbelgeKutusu box,Guid id,CancellationToken ct){
#if !MIAPAX_STANDALONE
  if(proxy is not null){return await Task.Run(()=>Proxy().Sorgula(environment,box,id),ct);}
#endif
if(!Enum.IsDefined(box)||id==Guid.Empty)throw new ArgumentException("Belge kutusu/ETTN geçersiz.");var j=await Request(HttpMethod.Post,"GetDocumentListGUID",new{AppType=(int)box,GUIDList=new[]{id.ToString("D")}},ct,true);var rows=Rows(j);if(rows.Any(x=>x.UUID!=id||x.AppType!=(int)box)||rows.Length>1)throw new EbelgeHatasi("ETTN sorgusu farklı/tekrarlı belge döndürdü.");return rows.SingleOrDefault();}
 public async Task<byte[]> Dosya(EbelgeKutusu box,Guid id,string type,bool? draft,DateTime issue,CancellationToken ct)
 {
#if !MIAPAX_STANDALONE
  if(proxy is not null){return await Task.Run(()=>Proxy().Dosya(environment,box,id,type,draft,issue),ct);}
#endif

  if(!Enum.IsDefined(box)||id==Guid.Empty||type is not("PDF" or "XML"))throw new ArgumentException("Dosya türü veya belge kimliği geçersiz.");
  // IssueDate başlığı sağlayıcının örneğinde zorunludur; URL'ye kimlik bilgisi konmaz.
  await Giris(ct);using var q=new HttpRequestMessage(HttpMethod.Get,new Uri(root,"GetDocumentFile?"+Query(("AppType",((int)box).ToString()),("Uuid",id.ToString("D")),("Tur",type),("IsDraft",draft?.ToString().ToLowerInvariant()??""))));q.Headers.Authorization=new AuthenticationHeaderValue("Bearer",token);q.Headers.Add("IssueDate",issue.ToString("yyyy-MM-dd",System.Globalization.CultureInfo.InvariantCulture));
  try{using var r=await http.SendAsync(q,ct);if(!r.IsSuccessStatusCode)throw new EbelgeHatasi("Belge dosyası alınamadı (HTTP "+(int)r.StatusCode+").");using var doc=JsonDocument.Parse(await r.Content.ReadAsStringAsync(ct));if(!Basarili(doc.RootElement))throw new EbelgeHatasi("Sağlayıcı dosya isteğini kabul etmedi.");var bytes=Convert.FromBase64String(S(doc.RootElement,"DocumentFile"));if(bytes.Length is 0 or >20000000)throw new EbelgeHatasi("Dosya boyutu geçersiz.");return bytes;}catch(Exception e)when(e is HttpRequestException or TaskCanceledException or JsonException or FormatException){throw new EbelgeHatasi("Belge dosyası indirilemedi veya yanıt biçimi geçersiz.");}
 }
 public async Task Gonder(HizliGonderi input,CancellationToken ct)
 {
#if !MIAPAX_STANDALONE
  if(proxy is not null){throw new InvalidOperationException("Gönderimi e-belge merkezindeki kayıt üzerinden başlatın.");}
#endif

  if(input.AppType is not(1 or 3 or 5)||!Guid.TryParse(input.DocumentUUID,out _)||input.LocalId.Length is <1 or >100||input.UpdateDocument||input.IsDraftSend&&input.IsDraft)throw new ArgumentException("Gönderim türü/kimliği/bayrakları geçersiz.");
  var j=await Request(HttpMethod.Post,"SendDocument",new[]{input},ct,true,true);if(j.ValueKind!=JsonValueKind.Array||j.GetArrayLength()!=1)throw new EbelgeHatasi("Gönderim yanıtı beklenen tek belge yanıtı değil. ETTN ile sorgulayın.",true);if(!Basarili(j[0]))throw new EbelgeHatasi("Sağlayıcı belgeyi kabul etmedi. "+GuvenliMesaj(S(j[0],"Message")));
 }
 string GuvenliMesaj(string message){foreach(string secret in new[]{kimlik?.ApiKey,kimlik?.SifreliKullanici,kimlik?.SifreliParola,token}.Where(s=>!string.IsNullOrEmpty(s)).Cast<string>())message=message.Replace(secret,"[gizli]",StringComparison.Ordinal);message=Regex.Replace(message,"[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+","[kod]");message=Regex.Replace(message,"(?<![0-9])[0-9]{10,11}(?![0-9])","[kimlik]");message=Regex.Replace(message,"[A-Za-z0-9_.+-]+@[A-Za-z0-9.-]+","[adres]");return message.Length>900?message[..900]:message;}
 public void Dispose(){token=null;http.Dispose();login.Dispose();}
}

