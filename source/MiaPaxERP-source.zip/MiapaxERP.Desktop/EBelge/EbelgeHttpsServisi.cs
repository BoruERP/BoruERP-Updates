using System.Data;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop.EBelge;
public sealed record EbelgeKurulum(EbelgeOrtam Ortam,string Vkn,string ApiKey,string Secret,string Kullanici,string Parola);
public sealed record EbelgeAlinan(long File,string Xml);
public sealed class EbelgeHttpsServisi(string connection,int user)
{
    readonly EbelgeDeposu db=new(connection,user);
    void Permission(string permission)=>db.Yetki(permission);
    static HizliKimlik Public(HizliKimlik k)=>new(k.Ortam,k.Vkn,"","","");
    internal HizliKimlik GercekKimlik(EbelgeOrtam env,string? tax=null)
    {
        if(!Enum.IsDefined(env))throw new ArgumentException("E-belge ortamı geçersiz.");using var c=new SqlConnection(connection);c.Open();using var q=ErpModulServisi.Komut(c,null,"SELECT Vkn,Sifreli FROM dbo.MPX310_Gizli WHERE Kullanici=@u AND Saglayici='Hizli' AND Ortam=@e",("@u",user),("@e",env.ToString()));using var r=q.ExecuteReader();if(!r.Read())throw new InvalidOperationException("E-belge sunucu bağlantısını önce kurun.");if(tax is not null&&r.GetString(0)!=tax)throw new UnauthorizedAccessException("E-belge firması oturumun kayıtlı bağlantısıyla uyuşmuyor.");byte[] plain=ProtectedData.Unprotect((byte[])r[1],"MiaPaxERP.Hizli.310"u8.ToArray(),DataProtectionScope.LocalMachine);try{return JsonSerializer.Deserialize<HizliKimlik>(plain,EbelgeJson.Ayar)??throw new InvalidOperationException("Sunucu bağlantısı okunamadı.");}finally{CryptographicOperations.ZeroMemory(plain);}
    }
    public HizliKimlik Baglanti(EbelgeOrtam env){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<HizliKimlik>(connection,"EbelgeHttpsServisi.Baglanti","",new object?[]{env});}
Permission("FINANCE.EBELGE.VIEW");return Public(GercekKimlik(env));}
    public HizliKimlik Kurulum(EbelgeKurulum input)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<HizliKimlik>(connection,"EbelgeHttpsServisi.Kurulum","",new object?[]{input});}

        Permission("FINANCE.EBELGE.CONFIG");if(input.Ortam==EbelgeOrtam.Canli)db.FirmaEsle(input.Vkn);using var stop=new CancellationTokenSource(TimeSpan.FromSeconds(100));using var api=new HizliApi(input.Ortam);var k=api.IlkKurulum(input.Vkn,input.ApiKey,input.Secret,input.Kullanici,input.Parola,stop.Token).GetAwaiter().GetResult();using(var connected=new HizliApi(k.Ortam,k))connected.Giris(stop.Token).GetAwaiter().GetResult();
        byte[] plain=JsonSerializer.SerializeToUtf8Bytes(k,EbelgeJson.Ayar);byte[] encrypted;try{encrypted=ProtectedData.Protect(plain,"MiaPaxERP.Hizli.310"u8.ToArray(),DataProtectionScope.LocalMachine);}finally{CryptographicOperations.ZeroMemory(plain);}using var c=new SqlConnection(connection);c.Open();using var t=c.BeginTransaction(IsolationLevel.Serializable);new ErpModulServisi(connection,user).Yetki(c,t,"FINANCE.EBELGE.CONFIG");using var q=ErpModulServisi.Komut(c,t,"UPDATE dbo.MPX310_Gizli WITH(UPDLOCK,HOLDLOCK) SET Vkn=@v,Sifreli=@s,Guncelleme=SYSDATETIMEOFFSET() WHERE Kullanici=@u AND Saglayici='Hizli' AND Ortam=@e;IF @@ROWCOUNT=0 INSERT dbo.MPX310_Gizli(Kullanici,Saglayici,Ortam,Vkn,Sifreli) VALUES(@u,'Hizli',@e,@v,@s)",("@v",k.Vkn),("@s",encrypted),("@u",user),("@e",k.Ortam.ToString()));q.ExecuteNonQuery();t.Commit();return Public(k);
    }
    public void Giris(EbelgeOrtam env){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EbelgeHttpsServisi.Giris","",new object?[]{env});return;}
Permission("FINANCE.EBELGE.VIEW");using var api=new HizliApi(env,GercekKimlik(env));api.Giris(default).GetAwaiter().GetResult();}
    public HizliMukellef[] Mukellef(EbelgeOrtam env,int app,string type,string tax){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<HizliMukellef[]>(connection,"EbelgeHttpsServisi.Mukellef","",new object?[]{env,app,type,tax});}
Permission("FINANCE.EBELGE.QUERY");using var api=new HizliApi(env,GercekKimlik(env));return api.Mukellef(app,type,tax,default).GetAwaiter().GetResult();}
    public HizliKayit[] Liste(EbelgeOrtam env,EbelgeKutusu box,DateTime start,DateTime end,bool? draft){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<HizliKayit[]>(connection,"EbelgeHttpsServisi.Liste","",new object?[]{env,box,start,end,draft});}
Permission("FINANCE.EBELGE.QUERY");using var api=new HizliApi(env,GercekKimlik(env));return api.Liste(box,start,end,draft,default).GetAwaiter().GetResult();}
    public HizliKayit? Sorgula(EbelgeOrtam env,EbelgeKutusu box,Guid id){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<HizliKayit?>(connection,"EbelgeHttpsServisi.Sorgula","",new object?[]{env,box,id});}
Permission("FINANCE.EBELGE.QUERY");using var api=new HizliApi(env,GercekKimlik(env));return api.Sorgula(box,id,default).GetAwaiter().GetResult();}
    public byte[] Dosya(EbelgeOrtam env,EbelgeKutusu box,Guid id,string type,bool? draft,DateTime issue)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<byte[]>(connection,"EbelgeHttpsServisi.Dosya","",new object?[]{env,box,id,type,draft,issue});}

        Permission("FINANCE.EBELGE.DOWNLOAD");using var api=new HizliApi(env,GercekKimlik(env));var bytes=api.Dosya(box,id,type,draft,issue,default).GetAwaiter().GetResult();if(type=="PDF"&&!bytes.AsSpan().StartsWith("%PDF-"u8))throw new EbelgeHatasi("Sağlayıcı PDF yerine farklı içerik döndürdü.");if(type=="XML")UblKimlik.Oku(new UTF8Encoding(false,true).GetString(bytes).TrimStart('\uFEFF'));return bytes;
    }
    public void Gonder(EbelgeOrtam env,long id,byte[] version)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EbelgeHttpsServisi.Gonder","",new object?[]{env,id,version});return;}

        var key=GercekKimlik(env);if(env==EbelgeOrtam.Canli)db.FirmaEsle(key.Vkn);using var api=new HizliApi(env,key);Permission("FINANCE.EBELGE.VIEW");api.Giris(default).GetAwaiter().GetResult();var input=db.Baslat(key,id,version);
        try{api.Gonder(input,default).GetAwaiter().GetResult();db.Sonuc(key,id,input.IsDraft?"Taslak kabul edildi":"Gönderim kabul edildi","Sağlayıcı isteği kabul etti; nihai GİB durumu ayrıca sorgulanmalı.");}catch(EbelgeHatasi e){db.Sonuc(key,id,e.Belirsiz?"Belirsiz":"Reddedildi",e.Message);throw;}
    }
    public HizliKayit? YerelSorgula(EbelgeOrtam env,long id)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<HizliKayit?>(connection,"EbelgeHttpsServisi.YerelSorgula","",new object?[]{env,id});}

        Permission("FINANCE.EBELGE.QUERY");var key=GercekKimlik(env);var rows=db.Liste(key).AsEnumerable().Where(r=>(long)r["Id"]==id).ToArray();if(rows.Length!=1)throw new ArgumentException("Belge bulunamadı.");var row=rows[0];using var api=new HizliApi(env,key);var found=api.Sorgula(EbelgeDeposu.Kutu((int)row["AppType"]),(Guid)row["Ettn"],default).GetAwaiter().GetResult();if(found is not null)db.SorguKaydet(key,id,found);return found;
    }
    public EbelgeAlinan BelgeAl(EbelgeOrtam env,EbelgeKutusu box,Guid id,bool draft)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<EbelgeAlinan>(connection,"EbelgeHttpsServisi.BelgeAl","",new object?[]{env,box,id,draft});}

        Permission("FINANCE.EBELGE.DOWNLOAD");var key=GercekKimlik(env);using var api=new HizliApi(env,key);var latest=api.Sorgula(box,id,default).GetAwaiter().GetResult()??throw new ArgumentException("Belge sağlayıcıda doğrulanamadı.");if(latest.IsDraft.HasValue&&latest.IsDraft.Value!=draft)throw new ArgumentException("Belgenin taslak durumu değişti.");var bytes=api.Dosya(box,id,"XML",draft,EbelgeTarihi.Oku(latest.RawIssueDate),default).GetAwaiter().GetResult();string xml=new UTF8Encoding(false,true).GetString(bytes).TrimStart('\uFEFF');UblBelge.Oku(xml);if(env==EbelgeOrtam.Canli)db.FirmaEsle(key.Vkn);long file=db.BelgeAl(key,box,latest,xml,draft,latest.Iptal??throw new ArgumentException("Sağlayıcı iptal durumunu doğrulamadı."));return new(file,xml);
    }
}
