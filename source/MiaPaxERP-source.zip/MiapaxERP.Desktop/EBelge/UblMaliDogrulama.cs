using System.Globalization;
using System.Xml.Linq;
namespace MiapaxERP.Desktop.EBelge;
internal static class UblMaliDogrulama
{
 static readonly XNamespace A=UblBelge.A,B=UblBelge.B;
 static decimal D(XElement p,string name){var a=p.Elements(B+name).ToArray();if(a.Length!=1||!decimal.TryParse(a[0].Value,NumberStyles.AllowDecimalPoint|NumberStyles.AllowLeadingSign,CultureInfo.InvariantCulture,out var n))throw new ArgumentException("UBL mali alanı eksik/tekrarlı: "+name);return n;}
 static void Currency(XElement p,string cur){if(p.DescendantsAndSelf().Any(e=>e.Attribute("currencyID") is{} a&&a.Value!=cur))throw new ArgumentException("UBL mali alanının dövizi belgeyle uyuşmuyor.");}
 static decimal Vat(XElement tax,string currency)
 {
  Currency(tax,currency);decimal sum=0;var subs=tax.Elements(A+"TaxSubtotal").ToArray();if(subs.Length==0)throw new ArgumentException("KDV alt toplamı eksik.");
  foreach(var s in subs){string code=s.Element(A+"TaxCategory")?.Element(A+"TaxScheme")?.Element(B+"TaxTypeCode")?.Value??"";decimal amount=D(s,"TaxAmount"),basis=D(s,"TaxableAmount"),rate=D(s,"Percent");if(code!="0015"||rate is not(0 or 1 or 10 or 20)||amount<0||basis<0||Math.Abs(UblBelge.Yuvarla(basis*rate/100)-amount)>.01m)throw new ArgumentException("KDV tutarı tutarsız veya KDV dışı / özel vergi eşlemesi gerekiyor.");sum+=amount;}
  if(sum!=D(tax,"TaxAmount"))throw new ArgumentException("KDV alt toplamları tutarsız.");return sum;
 }
 public static void Dogrula(XElement root,string currency)
 {
  if(!System.Text.RegularExpressions.Regex.IsMatch(currency,"^[A-Z]{3}$"))throw new ArgumentException("Belge para birimi geçersiz.");
  var totals=root.Elements(A+"LegalMonetaryTotal").ToArray();if(totals.Length!=1)throw new ArgumentException("Parasal toplam belirsiz.");var total=totals[0];Currency(total,currency);
  decimal lineNet=0,lineVat=0;foreach(var line in root.Elements(A+"InvoiceLine")){Currency(line,currency);decimal net=D(line,"LineExtensionAmount");if(net<0)throw new ArgumentException("Negatif satır matrahı desteklenmiyor; iade belge türünü kullanın.");lineNet+=net;var taxes=line.Elements(A+"TaxTotal").ToArray();if(taxes.Length!=1)throw new ArgumentException("Satır KDV toplamı belirsiz.");lineVat+=Vat(taxes[0],currency);}
  decimal discount=0,extra=0;foreach(var charge in root.Elements(A+"AllowanceCharge")){Currency(charge,currency);decimal n=D(charge,"Amount");string flag=charge.Element(B+"ChargeIndicator")?.Value??"";if(n<0||flag is not("true" or "false" or "1" or "0"))throw new ArgumentException("İndirim/artırım bilgisi geçersiz.");if(flag is "true" or "1")extra+=n;else discount+=n;}
  if(total.Element(B+"LineExtensionAmount") is not null&&D(total,"LineExtensionAmount")!=lineNet||UblBelge.Yuvarla(lineNet-discount+extra)!=D(total,"TaxExclusiveAmount"))throw new ArgumentException("Satır ve belge matrahı uyuşmuyor.");
  if(total.Element(B+"AllowanceTotalAmount") is not null&&D(total,"AllowanceTotalAmount")!=discount||total.Element(B+"ChargeTotalAmount") is not null&&D(total,"ChargeTotalAmount")!=extra)throw new ArgumentException("Belge indirim/artırım toplamı uyuşmuyor.");
  var taxTotal=root.Elements(A+"TaxTotal").Single(x=>(string?)x.Element(B+"TaxAmount")?.Attribute("currencyID")==currency);decimal vat=Vat(taxTotal,currency);if(discount==0&&extra==0&&vat!=lineVat)throw new ArgumentException("Satır ve belge KDV toplamları uyuşmuyor.");
  foreach(var w in root.Elements(A+"WithholdingTaxTotal"))Currency(w,currency);
  if(currency!="TRY")foreach(var tax in root.Elements(A+"TaxTotal").Where(x=>(string?)x.Element(B+"TaxAmount")?.Attribute("currencyID")=="TRY"))Vat(tax,"TRY");
  bool withholding=root.Elements(A+"WithholdingTaxTotal").Any();string type=root.Element(B+"InvoiceTypeCode")?.Value??"";if(withholding!=(type is "TEVKIFAT" or "TEVKIFATIADE"))throw new ArgumentException("Fatura türü ile tevkifat alanları uyuşmuyor.");
  if(currency!="TRY"){var rates=root.Elements().Where(x=>x.Name==A+"TaxExchangeRate"||x.Name==A+"PricingExchangeRate").ToArray();if(rates.Length==0||rates.Any(x=>x.Element(B+"SourceCurrencyCode")?.Value!=currency||x.Element(B+"TargetCurrencyCode")?.Value!="TRY"||D(x,"CalculationRate")<=0)||rates.Select(x=>D(x,"CalculationRate")).Distinct().Count()!=1)throw new ArgumentException("Vergi ve fiyatlandırma kurları tutarsız; ayrı mali inceleme gerekir.");}
 }
}
