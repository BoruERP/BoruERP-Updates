using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
namespace MiapaxERP.Desktop.EBelge;

public sealed class HizliBaglantiPenceresi:Window
{
 public HizliBaglantiPenceresi()
 {
  Title="MiapaxERP · Hızlı Bilişim TEST bağlantısı · 3";Width=700;Height=850;WindowStartupLocation=WindowStartupLocation.CenterScreen;
  var p=new StackPanel{Margin=new Thickness(26)};Content=new ScrollViewer{Content=p};p.Children.Add(new TextBlock{Text="Hızlı Bilişim · Test bağlantısı",FontSize=25,FontWeight=FontWeights.Bold});p.Children.Add(new TextBlock{Text="Bilgileri yalnız bu ekrana girin. Bu araç test hesabının girişini doğrular ve şifrelenmiş bağlantı ayarını hazırlar. Fatura/irsaliye gönderimi ve fabrika veritabanı işlemi yapmaz.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,12,0,16)});p.Children.Add(new TextBlock{Text="Servis: https://econnecttest.hizliteknoloji.com.tr",TextWrapping=TextWrapping.Wrap});
  void Label(string s)=>p.Children.Add(new TextBlock{Text=s,Margin=new Thickness(0,13,0,5)});
  Label("Test hesabınıza ait şirket VKN/TCKN");var vkn=new TextBox{Padding=new Thickness(8),MaxLength=11};p.Children.Add(vkn);
  PasswordBox Secret(string caption){Label(caption);var b=new PasswordBox{Padding=new Thickness(8),MaxLength=8192};p.Children.Add(b);return b;}
  PasswordBox api=Secret("API Key"),secret=Secret("Secret Key (yalnız bir defalık şifreleme için)"),username=Secret("Hızlı Bilişim WEB SERVİS kullanıcı adı"),password=Secret("Hızlı Bilişim WEB SERVİS şifresi");
  p.Children.Add(new TextBlock{Text="SecretKey ile açık kullanıcı adı/şifre dosyaya kaydedilmez. Sağlayıcının döndürdüğü şifrelenmiş kullanıcı bilgileri ve API Key ayrıca Windows hesabınıza bağlı DPAPI ile korunur.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,16,0,10)});
  var save=new Button{Content="Test bağlantısını doğrula ve ayarı hazırla",Padding=new Thickness(15),Margin=new Thickness(0,12,0,8)};p.Children.Add(save);var status=new TextBlock{TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,10,0,0)};p.Children.Add(status);var cancel=new CancellationTokenSource();
  var verify=new Button{Content="Kayıtlı TEST bağlantısını tekrar kontrol et",Padding=new Thickness(12),Margin=new Thickness(0,12,0,8)};p.Children.Add(verify);
  verify.Click+=async(_,_)=>{verify.IsEnabled=false;save.IsEnabled=false;try{var key=HizliAyarDeposu.Oku(HizliAyarDeposu.AktifTestDosyasi(HizliAyarDeposu.KurulumKlasoru));using var client=new HizliApi(EbelgeOrtam.Test,key);await client.Giris(cancel.Token);var gb=await client.Mukellef(1,"GB",key.Vkn,cancel.Token);var ir=await client.Mukellef(5,"GB",key.Vkn,cancel.Token);status.Text="Kayıtlı TEST hesabına giriş başarılı.\nTest firması VKN/TCKN: "+key.Vkn+"\ne-Fatura GB etiketi: "+gb.Length+" · e-İrsaliye GB etiketi: "+ir.Length+"\n\nBilgileri tekrar girmeniz gerekmez. Fatura/irsaliye gönderilmedi.";}catch(Exception e){status.Text=e is EbelgeHatasi?e.Message:"Kayıtlı test ayarı kontrol edilemedi.";}finally{verify.IsEnabled=true;save.IsEnabled=true;}};
  Loaded+=(_,_)=>{try{var key=HizliAyarDeposu.Oku(HizliAyarDeposu.AktifTestDosyasi(HizliAyarDeposu.KurulumKlasoru));vkn.Text=key.Vkn;status.Text="Şifreli TEST bağlantısı hazır. Bilgileri yeniden doldurmadan alttaki 'Kayıtlı TEST bağlantısını tekrar kontrol et' düğmesini kullanabilirsiniz.";}catch{}};
  Closed+=(_,_)=>cancel.Cancel();save.Click+=async(_,_)=>{
   save.IsEnabled=false;verify.IsEnabled=false;try{
    string tax=vkn.Text.Trim();if(!System.Text.RegularExpressions.Regex.IsMatch(tax,"^[0-9]{10,11}$"))throw new ArgumentException("Test hesabına ait 10 veya 11 haneli VKN/TCKN girin.");status.Text="Sağlayıcıyla güvenli test bağlantısı kuruluyor…";HizliKimlik key;
    using(var client=new HizliApi(EbelgeOrtam.Test))key=await client.IlkKurulum(tax,api.Password,secret.Password,username.Password,password.Password,cancel.Token);
    secret.Clear();username.Clear();password.Clear();string pending=HizliAyarDeposu.Kaydet(Path.Combine(HizliAyarDeposu.KurulumKlasoru,"Bekleyen"),key);using var connected=new HizliApi(EbelgeOrtam.Test,key);await connected.Giris(cancel.Token);string path=HizliAyarDeposu.Kaydet(HizliAyarDeposu.KurulumKlasoru,key);api.Clear();
    string registry="Sorgulanmadı";try{var users=await connected.Mukellef(1,"GB",tax,cancel.Token);registry=users.Length>0?"GB etiketi bulundu":"GB etiketi bulunamadı";}catch(EbelgeHatasi){registry="Etiket sorgusu doğrulanamadı";}
    var report=new{Saglayici="HizliBilisim",Ortam="Test",GirisBasarili=true,VknSonDort=tax[^4..],GondericiEtiketi=registry,TarihUtc=DateTimeOffset.UtcNow,ResmiBelgeGonderildi=false};Directory.CreateDirectory(HizliAyarDeposu.KurulumKlasoru);File.WriteAllText(Path.Combine(HizliAyarDeposu.KurulumKlasoru,"test-baglanti-sonucu.json"),JsonSerializer.Serialize(report,new JsonSerializerOptions{WriteIndented=true}));status.Text="TEST hesabına giriş başarılı. "+registry+".\n\nŞifreli bağlantı ayarı hazırlandı:\n"+path+"\n\nBu ekranı kapatabilirsiniz. Sonuç raporu API anahtarı, secret, parola veya token içermez.";
   }catch(Exception e){secret.Clear();username.Clear();password.Clear();if(e is EbelgeHatasi){try{Directory.CreateDirectory(HizliAyarDeposu.KurulumKlasoru);File.WriteAllText(Path.Combine(HizliAyarDeposu.KurulumKlasoru,"test-baglanti-hata.json"),JsonSerializer.Serialize(new{TarihUtc=DateTimeOffset.UtcNow,Hata=e.Message}));}catch(IOException){}}status.Text=e is EbelgeHatasi or ArgumentException?e.Message:"Bağlantı ayarı hazırlanamadı. Windows hesabı ve dosya erişimini kontrol edin. Bilgiler sohbete veya günlüğe yazılmadı.";}finally{save.IsEnabled=true;verify.IsEnabled=true;}
  };
 }
}
