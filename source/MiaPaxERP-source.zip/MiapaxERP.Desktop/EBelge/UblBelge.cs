using System.Globalization;
using System.IO;
using System.Xml;
using System.Xml.Linq;
namespace MiapaxERP.Desktop.EBelge;

public sealed record UblSatir(string Id,string Kod,string Ad,decimal Miktar,string Birim,decimal Fiyat,decimal KdvOrani,decimal Iskonto=0);
public sealed record UblTaraf(string Vkn,string Unvan,string VergiDairesi,string Adres,string Il,string Ilce,string Ulke="Türkiye",string Ad="",string Soyad="",string PostaKodu="");
public sealed record UblSevk(DateTime FiiliSevk,string Plaka,string SoforTckn,string SoforAd,string SoforSoyad);
public sealed record UblIcerik(UblKimlik Kimlik,string Doviz,decimal Matrah,decimal Vergi,decimal Toplam,decimal Odenecek,UblSatir[] Satirlar,decimal Tevkifat=0,decimal Kur=1,DateTime? KurTarihi=null,decimal Yuvarlama=0,decimal Pesinat=0,decimal? TryKdv=null);

public static class UblBelge
{
 internal static readonly XNamespace B="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2",A="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2";
 static string N(decimal n)=>n.ToString("0.########",CultureInfo.InvariantCulture);
 public static decimal Yuvarla(decimal n)=>decimal.Round(n,2,MidpointRounding.AwayFromZero);
 static XElement E(string name,object? value)=>new(B+name,value);
 static XElement Money(string name,decimal n,string currency="TRY")=>new(B+name,new XAttribute("currencyID",currency),N(n));
 public static XDocument Xml(string xml){UblKimlik.Oku(xml);using var r=XmlReader.Create(new StringReader(xml),new XmlReaderSettings{DtdProcessing=DtdProcessing.Prohibit,XmlResolver=null,MaxCharactersInDocument=8_000_000});return XDocument.Load(r);}
 public static UblIcerik Oku(string xml)
 {
  var k=UblKimlik.Oku(xml);var root=Xml(xml).Root!;string S(XElement x,XName n)=>x.Element(n)?.Value??"";
  decimal D(XElement x,XName n){if(!decimal.TryParse(S(x,n),NumberStyles.AllowDecimalPoint|NumberStyles.AllowLeadingSign,CultureInfo.InvariantCulture,out var v))throw new ArgumentException("UBL sayısal alanı eksik/geçersiz: "+n.LocalName);return v;}
  decimal matrah=0,vergi=0,total=0,pay=0,withheld=0,kur=1,round=0,prepaid=0;DateTime? kurDate=null;string currency=S(root,B+"DocumentCurrencyCode");
  if(!k.Irsaliye)
  {
   var m=root.Element(A+"LegalMonetaryTotal")??throw new ArgumentException("Fatura toplamları eksik.");matrah=D(m,B+"TaxExclusiveAmount");total=D(m,B+"TaxInclusiveAmount");pay=D(m,B+"PayableAmount");
   var taxes=root.Elements(A+"TaxTotal").Where(x=>(string?)x.Element(B+"TaxAmount")?.Attribute("currencyID")==currency).ToArray();if(taxes.Length!=1)throw new ArgumentException("Fatura vergi toplamı belirsiz.");vergi=D(taxes[0],B+"TaxAmount");
   foreach(var tax in root.Elements(A+"WithholdingTaxTotal"))
   {
    if((string?)tax.Element(B+"TaxAmount")?.Attribute("currencyID")!=currency)throw new ArgumentException("Tevkifat para birimi uyuşmuyor.");
    var subs=tax.Elements(A+"TaxSubtotal").ToArray();decimal sum=0;
    foreach(var st in subs){decimal baseVat=D(st,B+"TaxableAmount"),amount=D(st,B+"TaxAmount"),percent=D(st,B+"Percent");string code=st.Element(A+"TaxCategory")?.Element(A+"TaxScheme")?.Element(B+"TaxTypeCode")?.Value??"";var rule=UblMaliHesap.Tevkifat(code);if(percent!=rule.Pay*10||baseVat<0||amount<0||Yuvarla(baseVat*percent/100)!=amount)throw new ArgumentException("Tevkifat kodu, oranı veya tutarı uyuşmuyor.");sum+=amount;}
    if(subs.Length==0||sum!=D(tax,B+"TaxAmount"))throw new ArgumentException("Tevkifat toplamı uyuşmuyor.");withheld+=sum;
   }
   prepaid=m.Element(B+"PrepaidAmount") is null?0:D(m,B+"PrepaidAmount");round=m.Element(B+"PayableRoundingAmount") is null?0:D(m,B+"PayableRoundingAmount");
   if(matrah<0||vergi<0||total<=0||pay<0||Yuvarla(matrah+vergi)!=total||withheld>vergi||prepaid<0||Yuvarla(total-withheld-prepaid+round)!=pay)throw new ArgumentException("UBL fatura toplamları birbiriyle uyuşmuyor.");
  }
  var rows=root.Elements(A+(k.Irsaliye?"DespatchLine":"InvoiceLine")).Select(x=>{
   var q=x.Element(B+(k.Irsaliye?"DeliveredQuantity":"InvoicedQuantity"))??throw new ArgumentException("UBL miktarı eksik.");if(!decimal.TryParse(q.Value,NumberStyles.AllowDecimalPoint,CultureInfo.InvariantCulture,out var qty)||qty<=0)throw new ArgumentException("UBL miktarı geçersiz.");var item=x.Element(A+"Item")??throw new ArgumentException("UBL mal bilgisi eksik.");
   return new UblSatir(S(x,B+"ID"),item.Element(A+"SellersItemIdentification")?.Element(B+"ID")?.Value??"",S(item,B+"Name"),qty,(string?)q.Attribute("unitCode")??"",0,0);
  }).ToArray();if(rows.Length==0||rows.Select(x=>x.Id).Distinct().Count()!=rows.Length||rows.Any(x=>string.IsNullOrWhiteSpace(x.Id)||string.IsNullOrWhiteSpace(x.Birim)))throw new ArgumentException("UBL satır kimlikleri/birimleri eksik veya tekrarlı.");
  if(!k.Irsaliye&&currency!="TRY")
  {
   var exchange=root.Element(A+"TaxExchangeRate")??root.Element(A+"PricingExchangeRate")??throw new ArgumentException("Döviz faturasında TRY kuru eksik.");
   if(S(exchange,B+"SourceCurrencyCode")!=currency||S(exchange,B+"TargetCurrencyCode")!="TRY"||!DateTime.TryParseExact(S(exchange,B+"Date"),"yyyy-MM-dd",CultureInfo.InvariantCulture,DateTimeStyles.None,out var rateDate))throw new ArgumentException("Kur para birimi veya tarihi geçersiz.");kur=D(exchange,B+"CalculationRate");kurDate=rateDate;if(kur<=0||rateDate.Date>k.Tarih.Date)throw new ArgumentException("Kur tutarı veya tarihi geçersiz.");
  }
  decimal? tryKdv=null;if(!k.Irsaliye){UblMaliDogrulama.Dogrula(root,currency);var tryTaxes=root.Elements(A+"TaxTotal").Where(x=>(string?)x.Element(B+"TaxAmount")?.Attribute("currencyID")=="TRY").ToArray();if(tryTaxes.Length>1)throw new ArgumentException("TRY vergi toplamı belirsiz.");if(tryTaxes.Length==1)tryKdv=D(tryTaxes[0],B+"TaxAmount");}
  return new(k,currency,matrah,vergi,total,pay,rows,withheld,kur,kurDate,round,prepaid,tryKdv);
 }
 static XElement Taraf(string name,UblTaraf p)
 {
  if(!System.Text.RegularExpressions.Regex.IsMatch(p.Vkn,"^[0-9]{10,11}$")||new[]{p.Unvan,p.Adres,p.Il,p.Ilce,p.Ulke}.Any(string.IsNullOrWhiteSpace)||p.Vkn.Length==11&&(string.IsNullOrWhiteSpace(p.Ad)||string.IsNullOrWhiteSpace(p.Soyad)))throw new ArgumentException("Firma/cari VKN, ünvan, adres, il, ilçe; TCKN için ad/soyad gerekli.");
  return new(A+name,new XElement(A+"Party",new XElement(A+"PartyIdentification",new XElement(B+"ID",new XAttribute("schemeID",p.Vkn.Length==10?"VKN":"TCKN"),p.Vkn)),new XElement(A+"PartyName",E("Name",p.Unvan)),new XElement(A+"PostalAddress",E("StreetName",p.Adres),E("CitySubdivisionName",p.Ilce),E("CityName",p.Il),E("PostalZone",p.PostaKodu),new XElement(A+"Country",E("Name",p.Ulke))),new XElement(A+"PartyTaxScheme",new XElement(A+"TaxScheme",E("Name",p.VergiDairesi))),p.Vkn.Length==11?new XElement(A+"Person",E("FirstName",p.Ad),E("FamilyName",p.Soyad)):null));
 }
 static XElement Vergi(decimal net,decimal vat,decimal rate,string currency="TRY")=>new(A+"TaxSubtotal",Money("TaxableAmount",net,currency),Money("TaxAmount",vat,currency),E("Percent",N(rate)),new XElement(A+"TaxCategory",new XElement(A+"TaxScheme",E("Name","KDV"),E("TaxTypeCode","0015"))));
 public static string Olustur(Guid uuid,string no,DateTime tarih,int app,string profil,UblTaraf supplier,UblTaraf customer,UblSatir[] rows,UblSevk? sevk=null,string? gonderimSekli=null,UblMaliAyar? mali=null)
 {
  var m=mali??new UblMaliAyar();UblMaliHesap.Dogrula(m,tarih);
  XElement Money(string name,decimal value)=>UblBelge.Money(name,value,m.Doviz);
  XElement Vergi(decimal net,decimal vat,decimal rate)=>UblBelge.Vergi(net,vat,rate,m.Doviz);
  if(app is not(1 or 3 or 5)||rows.Length is <1 or >1000||rows.Select(x=>x.Id).Distinct().Count()!=rows.Length)throw new ArgumentException("Belge türü/satırları geçersiz.");bool irs=app==5;
  if(irs&&sevk is null||!irs&&sevk is not null||app==3&&profil!="EARSIVFATURA"||app==1&&profil is not("TEMELFATURA" or "TICARIFATURA")||irs&&profil!="TEMELIRSALIYE")throw new ArgumentException("Belge profili veya sevk bilgileri eksik/geçersiz.");
  if(app==3&&gonderimSekli is not("KAGIT" or "ELEKTRONIK"))throw new ArgumentException("e-Arşiv gönderim şeklini KAGIT veya ELEKTRONIK seçin.");
  if(irs&&(!System.Text.RegularExpressions.Regex.IsMatch(customer.PostaKodu,"^[0-9]{5}$")||!System.Text.RegularExpressions.Regex.IsMatch(supplier.PostaKodu,"^[0-9]{5}$")))throw new ArgumentException("İrsaliye taraflarının gerçek beş haneli posta kodlarını girin.");
  foreach(var row in rows)if(string.IsNullOrWhiteSpace(row.Ad)||string.IsNullOrWhiteSpace(row.Id)||!System.Text.RegularExpressions.Regex.IsMatch(row.Birim,"^[A-Z0-9]{2,3}$")||row.Miktar<=0||row.Fiyat<0||row.Iskonto<0||row.Iskonto>Yuvarla(row.Miktar*row.Fiyat)||!irs&&row.KdvOrani is not(1 or 10 or 20))throw new ArgumentException("Satır miktarı, fiyatı, iskontosu veya KDV türü eksik. İstisna/özel vergi senaryosu standart satışa çevrilemez.");
  XNamespace ns="urn:oasis:names:specification:ubl:schema:xsd:"+(irs?"DespatchAdvice":"Invoice")+"-2";var root=new XElement(ns+(irs?"DespatchAdvice":"Invoice"),new XAttribute(XNamespace.Xmlns+"cac",A),new XAttribute(XNamespace.Xmlns+"cbc",B),E("UBLVersionID","2.1"),E("CustomizationID","TR1.2"),E("ProfileID",profil),E("ID",no),E("CopyIndicator","false"),E("UUID",uuid.ToString("D")),E("IssueDate",tarih.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture)),E("IssueTime",tarih.ToString("HH:mm:ss",CultureInfo.InvariantCulture)),E(irs?"DespatchAdviceTypeCode":"InvoiceTypeCode","SEVK"));
  XNamespace ext="urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2";
  root.AddFirst(new XElement(ext+"UBLExtensions",new XElement(ext+"UBLExtension",new XElement(ext+"ExtensionContent",new XElement(XName.Get("SignaturePending","urn:miapaxerp:unsigned-document"),"Özel entegratör imzası bekleniyor")))));
  if(!irs){root.Element(B+"InvoiceTypeCode")!.Value=m.Tevkifat is null?"SATIS":"TEVKIFAT";if(m.IndirimAciklamasi!="")root.Add(E("Note",m.IndirimAciklamasi));root.Add(E("DocumentCurrencyCode",m.Doviz));if(m.Doviz!="TRY")root.Add(E("TaxCurrencyCode","TRY"));}root.Add(E("LineCountNumeric",rows.Length));
  if(app==3)root.Add(new XElement(A+"AdditionalDocumentReference",E("ID",uuid.ToString("D")),E("IssueDate",tarih.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture)),E("DocumentTypeCode","GONDERIM_SEKLI"),E("DocumentType",gonderimSekli)));
  root.Add(new XElement(A+"Signature",new XElement(B+"ID",new XAttribute("schemeID","VKN_TCKN"),supplier.Vkn),new XElement(A+"SignatoryParty",Taraf("Supplier",supplier).Element(A+"Party")!.Elements()),new XElement(A+"DigitalSignatureAttachment",new XElement(A+"ExternalReference",E("URI","#Signature_"+uuid.ToString("N"))))));
  root.Add(Taraf(irs?"DespatchSupplierParty":"AccountingSupplierParty",supplier),Taraf(irs?"DeliveryCustomerParty":"AccountingCustomerParty",customer));
  if(irs)
  {
   var s=sevk!;if(s.FiiliSevk<tarih||string.IsNullOrWhiteSpace(s.Plaka)||!System.Text.RegularExpressions.Regex.IsMatch(s.SoforTckn,"^[0-9]{11}$")||string.IsNullOrWhiteSpace(s.SoforAd)||string.IsNullOrWhiteSpace(s.SoforSoyad))throw new ArgumentException("Fiili sevk zamanı, plaka ve gerçek şoför bilgilerini girin.");
   root.Add(new XElement(A+"Shipment",E("ID",uuid.ToString("N")),new XElement(A+"ShipmentStage",new XElement(A+"TransportMeans",new XElement(A+"RoadTransport",new XElement(B+"LicensePlateID",new XAttribute("schemeID","PLAKA"),s.Plaka.Replace(" ","").ToUpperInvariant()))),new XElement(A+"DriverPerson",E("FirstName",s.SoforAd),E("FamilyName",s.SoforSoyad),E("NationalityID",s.SoforTckn))),new XElement(A+"Delivery",new XElement(A+"DeliveryAddress",E("StreetName",customer.Adres),E("CitySubdivisionName",customer.Ilce),E("CityName",customer.Il),E("PostalZone",customer.PostaKodu),new XElement(A+"Country",E("Name",customer.Ulke))),new XElement(A+"Despatch",E("ActualDespatchDate",s.FiiliSevk.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture)),E("ActualDespatchTime",s.FiiliSevk.ToString("HH:mm:ss",CultureInfo.InvariantCulture))))));
  }
  var calc=rows.Select(r=>(Row:r,Net:Yuvarla(r.Miktar*r.Fiyat)-r.Iskonto,Vat:Yuvarla((Yuvarla(r.Miktar*r.Fiyat)-r.Iskonto)*r.KdvOrani/100))).ToArray();
  decimal Withheld(decimal vat)=>m.Tevkifat is{} w?Yuvarla(vat*w.Pay/w.Payda):0;
  var withheldLines=calc.ToDictionary(x=>x.Row.Id,x=>m.Tevkifat is{} w?decimal.Floor(x.Vat*w.Pay/w.Payda*100)/100:0);
  decimal withholdingTotal=Withheld(calc.Sum(x=>x.Vat)),remainingWithholding=withholdingTotal-withheldLines.Values.Sum();
  if(m.Tevkifat is{} rule)foreach(var x in calc.OrderByDescending(x=>x.Vat*rule.Pay/rule.Payda-withheldLines[x.Row.Id]).ThenBy(x=>x.Row.Id,StringComparer.Ordinal)){if(remainingWithholding<=0)break;withheldLines[x.Row.Id]+=.01m;remainingWithholding-=.01m;}
  XElement Withholding(decimal vat,decimal amount)=>new(A+"WithholdingTaxTotal",Money("TaxAmount",amount),new XElement(A+"TaxSubtotal",Money("TaxableAmount",vat),Money("TaxAmount",amount),E("Percent",m.Tevkifat!.Pay*100/m.Tevkifat.Payda),new XElement(A+"TaxCategory",new XElement(A+"TaxScheme",E("Name",m.Tevkifat.Ad),E("TaxTypeCode",m.Tevkifat.Kod)))));
  if(!irs)
  {
   if(Math.Abs(m.Yuvarlama)>.01m*rows.Length)throw new ArgumentException("Yuvarlama farkı satır kuruş sınırını aşıyor.");
   if(m.Doviz!="TRY")foreach(string exchange in new[]{"TaxExchangeRate","PricingExchangeRate"})root.Add(new XElement(A+exchange,E("SourceCurrencyCode",m.Doviz),E("TargetCurrencyCode","TRY"),E("CalculationRate",N(m.Kur)),E("Date",m.KurTarihi!.Value.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture))));
   root.Add(new XElement(A+"TaxTotal",Money("TaxAmount",calc.Sum(x=>x.Vat)),calc.GroupBy(x=>x.Row.KdvOrani).Select(g=>Vergi(g.Sum(x=>x.Net),g.Sum(x=>x.Vat),g.Key))));
   if(m.Doviz!="TRY")root.Add(new XElement(A+"TaxTotal",UblBelge.Money("TaxAmount",calc.GroupBy(x=>x.Row.KdvOrani).Sum(g=>Yuvarla(g.Sum(x=>x.Vat)*m.Kur)),"TRY"),calc.GroupBy(x=>x.Row.KdvOrani).Select(g=>UblBelge.Vergi(Yuvarla(g.Sum(x=>x.Net)*m.Kur),Yuvarla(g.Sum(x=>x.Vat)*m.Kur),g.Key,"TRY"))));
   decimal withheld=withholdingTotal;if(m.Tevkifat is not null)root.Add(new XElement(A+"WithholdingTaxTotal",Money("TaxAmount",withheld),new XElement(A+"TaxSubtotal",Money("TaxableAmount",calc.Sum(x=>x.Vat)),Money("TaxAmount",withheld),E("Percent",m.Tevkifat.Pay*10),new XElement(A+"TaxCategory",new XElement(A+"TaxScheme",E("Name",m.Tevkifat.Ad),E("TaxTypeCode",m.Tevkifat.Kod))))));
   // The withholding total is the sum of individually rounded line taxes.
   var totals=new XElement(A+"LegalMonetaryTotal",Money("LineExtensionAmount",calc.Sum(x=>x.Net)),Money("TaxExclusiveAmount",calc.Sum(x=>x.Net)),Money("TaxInclusiveAmount",calc.Sum(x=>x.Net+x.Vat)),Money("AllowanceTotalAmount",0));
   if(m.Yuvarlama!=0)totals.Add(Money("PayableRoundingAmount",m.Yuvarlama));totals.Add(Money("PayableAmount",calc.Sum(x=>x.Net+x.Vat)-withheld+m.Yuvarlama));root.Add(totals);
  }
  foreach(var x in calc){var r=x.Row;var line=new XElement(A+(irs?"DespatchLine":"InvoiceLine"),E("ID",r.Id),new XElement(B+(irs?"DeliveredQuantity":"InvoicedQuantity"),new XAttribute("unitCode",r.Birim),N(r.Miktar)));if(irs)line.Add(new XElement(A+"OrderLineReference",E("LineID",r.Id)));else{line.Add(Money("LineExtensionAmount",x.Net));if(r.Iskonto>0)line.Add(new XElement(A+"AllowanceCharge",E("ChargeIndicator","false"),Money("Amount",r.Iskonto)));line.Add(new XElement(A+"TaxTotal",Money("TaxAmount",x.Vat),Vergi(x.Net,x.Vat,r.KdvOrani)));if(m.Tevkifat is not null)line.Add(Withholding(x.Vat,withheldLines[r.Id]));}line.Add(new XElement(A+"Item",E("Name",r.Ad),new XElement(A+"SellersItemIdentification",E("ID",r.Kod))));if(!irs)line.Add(new XElement(A+"Price",Money("PriceAmount",r.Fiyat)));root.Add(line);}
  string xml=new XDocument(new XDeclaration("1.0","utf-8",null),root).ToString();var result=Oku(xml);if(result.Kimlik.Ettn!=uuid)throw new ArgumentException("Üretilen UBL kimliği doğrulanamadı.");return xml;
 }
}
