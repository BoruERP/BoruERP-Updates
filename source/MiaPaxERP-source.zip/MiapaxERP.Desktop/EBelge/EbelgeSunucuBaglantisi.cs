using System.Windows;
using System.Windows.Controls;
namespace MiapaxERP.Desktop.EBelge;
public sealed class EbelgeSunucuBaglantisi:Window
{
    public EbelgeSunucuBaglantisi(Window owner,string connection,int user,EbelgeOrtam environment)
    {
        Owner=owner;Title="MiaPaxERP · E-belge sunucu bağlantısı";Width=650;Height=740;WindowStartupLocation=WindowStartupLocation.CenterOwner;var p=new StackPanel{Margin=new Thickness(26)};Content=new ScrollViewer{Content=p};p.Children.Add(new TextBlock{Text="Hızlı Bilişim · "+environment,FontSize=25,FontWeight=FontWeights.Bold});p.Children.Add(new TextBlock{Text="Bilgiler HTTPS üzerinden ana sunucuya iletilir. Sağlayıcı doğrulaması sunucuda yapılır; bağlantı bilgileri sunucuda şifreli saklanır. Bu işlem fatura göndermez.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,12,0,16)});
        p.Children.Add(new TextBlock{Text="Şirket VKN / TCKN"});var tax=new TextBox{MaxLength=11,Padding=new Thickness(8)};p.Children.Add(tax);
        PasswordBox Field(string caption){p.Children.Add(new TextBlock{Text=caption,Margin=new Thickness(0,14,0,5)});var field=new PasswordBox{MaxLength=8192,Padding=new Thickness(8)};p.Children.Add(field);return field;}
        var api=Field("API Key");var secret=Field("Secret Key (ilk kurulum için)");var name=Field("Web servis kullanıcı adı");var pass=Field("Web servis şifresi");var save=new Button{Content="Sunucu bağlantısını doğrula ve kaydet",Padding=new Thickness(15),Margin=new Thickness(0,20,0,10)};p.Children.Add(save);var state=new TextBlock{TextWrapping=TextWrapping.Wrap};p.Children.Add(state);
        save.Click+=async(_,_)=>{save.IsEnabled=false;try{var input=new EbelgeKurulum(environment,tax.Text.Trim(),api.Password,secret.Password,name.Password,pass.Password);secret.Clear();name.Clear();pass.Clear();api.Clear();var result=await Task.Run(()=>new EbelgeHttpsServisi(connection,user).Kurulum(input));state.Text="Sunucu bağlantısı doğrulandı: "+result.Vkn+". E-belge merkezinden bağlantıyı yükleyebilirsiniz.";}catch(Exception e){state.Text=e.Message;}finally{secret.Clear();name.Clear();pass.Clear();api.Clear();save.IsEnabled=true;}};
    }
}
