namespace MiapaxERP.Desktop.EBelge;
public static class EbelgeRaporu
{
 public const string AlisSatis="""
 SELECT b.BelgeNo,b.BelgeTipi,c.Unvan AS Cari,b.BelgeTarihi,b.AraToplam,b.KdvOrani,b.KdvTutari,b.GenelToplam,
 CASE WHEN b.Durum=N'Kaydedildi' AND EXISTS(SELECT 1 FROM dbo.CariHareketleri r WHERE r.TersKayitId=b.CariHareketId) THEN N'Terslendi' ELSE b.Durum END AS Durum,b.Aciklama,N'Manuel' AS Kaynak
 FROM dbo.TicariBelgeler b JOIN dbo.CariKartlari c ON c.Id=b.CariId
 WHERE b.BelgeTarihi>=@bas AND b.BelgeTarihi<DATEADD(day,1,@bit)
 UNION ALL
 SELECT i.BelgeNo,i.BelgeTipi,c.Unvan,i.BelgeTarihi,i.Matrah,CAST(NULL AS decimal(18,4)),i.Kdv,i.GenelToplam,
 CASE WHEN i.TersId IS NULL THEN N'Muhasebeleştirildi' ELSE N'Terslendi' END,i.Gerekce,N'E-Belge'
 FROM dbo.BERP270_EBelgeIslem i JOIN dbo.CariKartlari c ON c.Id=i.CariId
 WHERE i.Ortam='Canli' AND i.Islem='Muhasebe' AND i.BelgeTarihi>=@bas AND i.BelgeTarihi<DATEADD(day,1,@bit)
 AND NOT EXISTS(SELECT 1 FROM dbo.TicariBelgeler b WHERE b.CariHareketId=i.CariHareketId)
 ORDER BY BelgeTarihi DESC,BelgeNo DESC
 """;
}
