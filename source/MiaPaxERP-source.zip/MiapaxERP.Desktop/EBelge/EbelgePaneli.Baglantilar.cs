using System.Data;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop.EBelge;
public sealed partial class EbelgePaneli
{
 readonly ComboBox ortam=new(){ItemsSource=Enum.GetValues<EbelgeOrtam>(),SelectedIndex=0,Width=110};
 readonly DataGrid sales=new(){AutoGenerateColumns=true,IsReadOnly=true,CanUserAddRows=false};
 readonly DataGrid operations=new(){AutoGenerateColumns=true,IsReadOnly=true,CanUserAddRows=false};
 EbelgeOrtam Ortam=>(EbelgeOrtam)ortam.SelectedItem;
 void BaglantilariEkle()
 {
  tools.Children.Insert(0,ortam);ortam.SelectionChanged+=(_,_)=>{key=null;remote.ItemsSource=null;local.ItemsSource=null;operations.ItemsSource=null;account.Text=Ortam+" bağlantısı seçilmedi.";};
  void Button(WrapPanel p,string title,Func<Task> action){var b=new Button{Content=title,Padding=new Thickness(10,7,10,7),Margin=new Thickness(3)};b.Click+=async(_,_)=>await Run(action);p.Children.Add(b);}
  Button(tools,"Canlı bağlantıyı tanımla",CanliBagla);Button(tools,"Firma / cari e-belge adresi",TarafDuzenle);Button(tools,"Stok birimi eşleştir",BirimDuzenle);
  var salePage=new DockPanel();var saleActions=new WrapPanel();DockPanel.SetDock(saleActions,Dock.Top);salePage.Children.Add(saleActions);salePage.Children.Add(sales);
  Button(saleActions,"Satışları getir",()=>{sales.ItemsSource=depo.Satislar().DefaultView;return Task.CompletedTask;});Button(saleActions,"Seçili satıştan e-belge hazırla",SatisHazirla);Button(saleActions,"Döviz / tevkifat / eski indirim",SatisMaliDuzenle);
  tabs.Items.Add(new TabItem{Header="Satıştan e-belge",Content=salePage});
  var page=new DockPanel();var actions=new WrapPanel();DockPanel.SetDock(actions,Dock.Top);page.Children.Add(actions);page.Children.Add(operations);
  Button(actions,"Seçili sağlayıcı faturasını muhasebeleştir",MuhasebeIsle);Button(actions,"Seçili sağlayıcı irsaliyesini stoğa işle",StokIsle);Button(actions,"İşlem geçmişini getir",()=>{operations.ItemsSource=depo.IslemListesi(Key()).DefaultView;return Task.CompletedTask;});Button(actions,"Muhasebe ters kaydı",Tersle);
  tabs.Items.Add(new TabItem{Header="Muhasebe / sevkiyat bağlantıları",Content=page});MaliBolumEkle();
 }
 Dictionary<string,string>? Form(string title,params(string Key,string Label,string Value)[] fields)
 {
  var w=new Window{Title=title,Width=750,Height=650,MaxHeight=Math.Max(400,SystemParameters.WorkArea.Height-40),Owner=Window.GetWindow(this),WindowStartupLocation=WindowStartupLocation.CenterOwner};var p=new StackPanel{Margin=new Thickness(20)};w.Content=new ScrollViewer{Content=p};var readers=new Dictionary<string,Func<string>>();var combos=new Dictionary<string,ComboBox>();
  foreach(var f in fields)
  {
   string label=f.Key switch{"tip"=>"Belge türü","profil"=>"Belge senaryosu","gonderim"=>"e-Arşiv teslim şekli","taslak"=>"Hazırlama seçimi","date"=>"Düzenleme tarihi ve saati","sevk"=>"Fiili sevk tarihi ve saati","d"=>"Muhasebe tarihi",_=>f.Label};p.Children.Add(new TextBlock{Text=label,Margin=new Thickness(0,8,0,4),TextWrapping=TextWrapping.Wrap});
   (string Kod,string Ad)[] options=f.Key switch{
    "tip"=>new[]{("1","e-Fatura"),("3","e-Arşiv"),("5","e-İrsaliye")},
    "profil"=>new[]{("TEMELFATURA","Temel fatura"),("TICARIFATURA","Ticari fatura"),("EARSIVFATURA","e-Arşiv"),("TEMELIRSALIYE","Temel irsaliye")},
    "gonderim"=>new[]{("KAGIT","Kağıt"),("ELEKTRONIK","Elektronik")},
    "taslak"=>new[]{("EVET","Taslak kaydet"),("HAYIR","Gönderime hazırla (hemen göndermez)")},
    "ubl"=>new[]{("C62","Adet"),("MTR","Metre"),("KGM","Kilogram"),("LTR","Litre"),("MTK","Metrekare"),("MTQ","Metreküp")},_=>Array.Empty<(string,string)>()};
   if(options.Length>0){var choices=options.Select(x=>new{ x.Kod,x.Ad}).ToArray();var b=new ComboBox{ItemsSource=choices,DisplayMemberPath="Ad",SelectedValuePath="Kod",SelectedValue=f.Value,Padding=new Thickness(6)};p.Children.Add(b);readers.Add(f.Key,()=>Convert.ToString(b.SelectedValue)??"");combos.Add(f.Key,b);}
   else if(f.Key is "date" or "sevk" or "d")
   {DateTime? initial=DateTime.TryParse(f.Value,CultureInfo.InvariantCulture,DateTimeStyles.None,out var parsed)?parsed:null;var date=new DatePicker{SelectedDate=initial?.Date,Width=180};var time=new TextBox{Text=initial?.ToString("HH:mm:ss",CultureInfo.InvariantCulture)??"",Width=100,Padding=new Thickness(6),ToolTip="Saat:dakika:saniye"};var row=new WrapPanel();row.Children.Add(date);if(f.Key!="d")row.Children.Add(time);p.Children.Add(row);bool onlyDate=f.Key=="d";readers.Add(f.Key,()=>date.SelectedDate is{} value?value.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture)+(onlyDate?"":" "+time.Text.Trim()):"");}
   else{var b=new TextBox{Text=f.Value,Padding=new Thickness(6),MaxLength=f.Key=="g"?400:1000,AcceptsReturn=f.Key=="g",MinHeight=f.Key=="g"?70:0};p.Children.Add(b);readers.Add(f.Key,()=>b.Text.Trim());}
  }
  if(combos.TryGetValue("tip",out var type)&&combos.TryGetValue("profil",out var profile))type.SelectionChanged+=(_,_)=>profile.SelectedValue=Convert.ToString(type.SelectedValue) switch{"3"=>"EARSIVFATURA","5"=>"TEMELIRSALIYE",_=>"TEMELFATURA"};
  var ok=new Button{Content="Bilgileri doğrula ve devam et",Padding=new Thickness(12),Margin=new Thickness(0,18,0,0)};ok.Click+=(_,_)=>w.DialogResult=true;p.Children.Add(ok);return w.ShowDialog()==true?readers.ToDictionary(x=>x.Key,x=>x.Value()):null;
 }
 DataRowView? Sec(string title,DataTable values,string? yeni=null)
 {
  if(yeni is null&&values.Rows.Count==0)throw new ArgumentException("Uygun kayıt bulunamadı. Önce cari/stok kartını tanımlayın.");
  if(yeni is not null){foreach(DataColumn col in values.Columns){col.ReadOnly=false;col.AllowDBNull=true;}var n=values.NewRow();foreach(DataColumn col in values.Columns)n[col]=col.ColumnName=="Id"?0:col.ColumnName=="Aciklama"?yeni:DBNull.Value;values.Rows.InsertAt(n,0);}
  var w=new Window{Title=title,Width=1000,Height=550,Owner=Window.GetWindow(this),WindowStartupLocation=WindowStartupLocation.CenterOwner};var root=new DockPanel();w.Content=root;var grid=new DataGrid{ItemsSource=values.DefaultView,IsReadOnly=true,AutoGenerateColumns=true,CanUserAddRows=false,SelectionMode=DataGridSelectionMode.Single};grid.AutoGeneratingColumn+=(_,e)=>{if(e.PropertyName=="Id")e.Cancel=true;};var b=new Button{Content="Seçili kayıtla devam et",Padding=new Thickness(12)};DockPanel.SetDock(b,Dock.Bottom);root.Children.Add(b);root.Children.Add(grid);b.Click+=(_,_)=>{if(grid.SelectedItem is DataRowView)w.DialogResult=true;};return w.ShowDialog()==true?grid.SelectedItem as DataRowView:null;
 }
 Task CanliBagla()
 {
  depo.Yetki("FINANCE.EBELGE.CONFIG");if(Ortam!=EbelgeOrtam.Canli)throw new ArgumentException("Önce ortam listesinden Canli seçin.");
  if(HttpsOturumu.Uzak(connection)){new EbelgeSunucuBaglantisi(Window.GetWindow(this),connection,this.user,Ortam).ShowDialog();return Task.CompletedTask;}
  var w=new Window{Title="Hızlı Bilişim · CANLI hesap kurulumu",Width=650,Height=670,Owner=Window.GetWindow(this),WindowStartupLocation=WindowStartupLocation.CenterOwner};var p=new StackPanel{Margin=new Thickness(20)};w.Content=new ScrollViewer{Content=p};p.Children.Add(new TextBlock{Text="Gerçek firmanın web servis hesabını girin. Bu ekran yalnız giriş yapar; belge göndermez. SecretKey ve açık kullanıcı adı/şifre kaydedilmez.",TextWrapping=TextWrapping.Wrap});var v=new TextBox{Padding=new Thickness(6)};p.Children.Add(new TextBlock{Text="Firma VKN/TCKN"});p.Children.Add(v);
  PasswordBox Secret(string label){p.Children.Add(new TextBlock{Text=label,Margin=new Thickness(0,12,0,4)});var b=new PasswordBox{Padding=new Thickness(6)};p.Children.Add(b);return b;}var api=Secret("API Key");var secret=Secret("Secret Key");var user=Secret("Gerçek firma web servis kullanıcı adı");var pass=Secret("Gerçek firma web servis şifresi");var text=new TextBlock{TextWrapping=TextWrapping.Wrap};var b=new Button{Content="Yalnız canlı hesap girişini doğrula",Padding=new Thickness(12),Margin=new Thickness(0,15,0,10)};p.Children.Add(b);p.Children.Add(text);var cancel=new CancellationTokenSource();w.Closed+=(_,_)=>cancel.Cancel();
  b.Click+=async(_,_)=>{b.IsEnabled=false;try{depo.FirmaEsle(v.Text.Trim());using var initial=new HizliApi(EbelgeOrtam.Canli);var k=await initial.IlkKurulum(v.Text.Trim(),api.Password,secret.Password,user.Password,pass.Password,cancel.Token);secret.Clear();user.Clear();pass.Clear();using var client=new HizliApi(k.Ortam,k,erpConnection:connection);await client.Giris(cancel.Token);HizliAyarDeposu.Kaydet(folder,k);key=k;account.Text="CANLI · "+k.Vkn+" · Hızlı Bilişim";api.Clear();text.Text="Canlı hesap girişi başarılı. Henüz belge gönderilmedi.";}catch(Exception e){secret.Clear();user.Clear();pass.Clear();text.Text=e is EbelgeHatasi or ArgumentException?e.Message:"Canlı bağlantı kurulamadı.";}finally{b.IsEnabled=true;}};w.ShowDialog();return Task.CompletedTask;
 }
 Task TarafDuzenle()
 {
  var k=Key();var f=Form("Firma / cari e-belge bilgileri",("v","VKN/TCKN",k.Vkn),("u","Ünvan",""),("vd","Vergi dairesi",""),("a","Açık adres",""),("il","İl",""),("ilce","İlçe",""),("ulke","Ülke adı","Türkiye"),("posta","Beş haneli posta kodu",""),("ad","TCKN ise ad",""),("soyad","TCKN ise soyad",""));if(f is null)return Task.CompletedTask;depo.TarafKaydet(k.Ortam,new(f["v"],f["u"],f["vd"],f["a"],f["il"],f["ilce"],f["ulke"],f["ad"],f["soyad"],f["posta"]));status.Text="E-belge adresi bu ortam için kaydedildi; eski firma/cari kartı değiştirilmedi.";return Task.CompletedTask;
 }
 Task BirimDuzenle(){var f=Form("Birim eşlemesi (miktar dönüştürmez)",("yerel","Stok kartındaki birim",""),("ubl","UBL birim kodu (ör. C62 adet, MTR metre, KGM kilogram)",""));if(f is not null){depo.BirimKaydet(f["yerel"],f["ubl"]);status.Text="Birim kodu eşlendi. Miktar için dönüşüm katsayısı uygulanmaz.";}return Task.CompletedTask;}
 async Task SatisHazirla()
 {
  var k=Key();if(sales.SelectedItem is not DataRowView selected)throw new ArgumentException("Bir satış seçin.");var f=Form("Satıştan e-belge hazırlama",("tip","Belge türü: 1 e-Fatura, 3 e-Arşiv, 5 e-İrsaliye","1"),("no","Seri/yıl/sıra numarası (16 karakter)",""),("date","Düzenleme tarihi ve saati: yyyy-MM-dd HH:mm:ss",DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss",CultureInfo.InvariantCulture)),("profil","Profil: TEMELFATURA / TICARIFATURA / EARSIVFATURA / TEMELIRSALIYE","TEMELFATURA"),("gonderim","e-Arşiv gönderim şekli: KAGIT / ELEKTRONIK","") ,("taslak","Taslak için EVET; doğrudan gönderime hazır belge için HAYIR","EVET"),("sevk","İrsaliye fiili sevk tarihi: yyyy-MM-dd HH:mm:ss",""),("plaka","İrsaliye araç plakası",""),("tckn","İrsaliye şoför TCKN",""),("ad","Şoför adı",""),("soyad","Şoför soyadı",""));if(f is null)return;
  if(!int.TryParse(f["tip"],out var app)||app is not(1 or 3 or 5)||!DateTime.TryParseExact(f["date"],"yyyy-MM-dd HH:mm:ss",CultureInfo.InvariantCulture,DateTimeStyles.None,out var date)||f["taslak"] is not("EVET" or "HAYIR"))throw new ArgumentException("Belge türü, tarih veya taslak seçimi geçersiz.");UblSevk? sevk=null;if(app==5){if(!DateTime.TryParseExact(f["sevk"],"yyyy-MM-dd HH:mm:ss",CultureInfo.InvariantCulture,DateTimeStyles.None,out var shipping))throw new ArgumentException("Fiili sevk tarihini girin.");sevk=new(shipping,f["plaka"],f["tckn"],f["ad"],f["soyad"]);}
  Guid uuid=Guid.NewGuid();string xml=depo.SatisXml(k,Convert.ToInt64(selected["Id"]),uuid,f["no"],date,app,f["profil"],sevk,app==3?f["gonderim"]:null);var u=UblBelge.Oku(xml);var preview=new Window{Title="UBL önizleme · henüz gönderilmedi",Width=1000,Height=720,Owner=Window.GetWindow(this),WindowStartupLocation=WindowStartupLocation.CenterOwner};var panel=new DockPanel();preview.Content=panel;var maliOzet=new TextBlock{Text=$"Matrah: {u.Matrah:N2} / KDV: {u.Vergi:N2} / Tevkifat: {u.Tevkifat:N2} / Ödenecek: {u.Odenecek:N2} {u.Doviz} / Kuruş farkı: {u.Yuvarlama:N2}",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(12),FontSize=16};DockPanel.SetDock(maliOzet,Dock.Top);panel.Children.Add(maliOzet);var ok=new Button{Content="Bu içeriği kalıcı e-belge kaydına hazırla",Padding=new Thickness(12)};DockPanel.SetDock(ok,Dock.Bottom);panel.Children.Add(ok);panel.Children.Add(new TextBox{Text=xml,IsReadOnly=true,AcceptsReturn=true,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,HorizontalScrollBarVisibility=ScrollBarVisibility.Auto});ok.Click+=(_,_)=>preview.DialogResult=true;if(preview.ShowDialog()!=true)return;
  using var api=new HizliApi(k.Ortam,k,erpConnection:connection);string source=Etiket(await api.Mukellef(app==5?5:1,"GB",k.Vkn,default),"Gönderici GB etiketi"),target=app==3?"":Etiket(await api.Mukellef(app==5?5:1,"PK",u.Kimlik.Alici,default),"Alıcı PK etiketi");bool draft=f["taslak"]=="EVET";long id=depo.Hazirla(k,new(app,source,u.Kimlik.Alici,target,xml,uuid.ToString("D"),f["no"],date.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture),"MIAPAX ERP-"+uuid.ToString("N"),IsDraft:draft),draft,Convert.ToInt64(selected["Id"]));Yenile();status.Text="Satışa bağlı e-belge hazır: "+id+". Henüz sağlayıcıya gönderilmedi.";
 }
 async Task<(long File,UblIcerik Doc)> SeciliDosyayiAl()
 {
  var k=Key();if(remote.SelectedItem is not HizliKayit r)throw new ArgumentException("Sağlayıcı belge kutusundan bir kayıt seçin.");bool? draft=r.IsDraft??fetchedDraft;if(draft is null)throw new ArgumentException("Taslak durumunu belirleyen filtreyle yeniden listeleyin.");if(HttpsOturumu.Uzak(connection)){var package=await Task.Run(()=>new EbelgeHttpsServisi(connection,user).BelgeAl(k.Ortam,(EbelgeKutusu)r.AppType,r.UUID,draft.Value));return(package.File,UblBelge.Oku(package.Xml));}using var api=new HizliApi(k.Ortam,k,erpConnection:connection);var latest=await api.Sorgula((EbelgeKutusu)r.AppType,r.UUID,default)??throw new ArgumentException("Belge sağlayıcıda doğrulanamadı.");var bytes=await api.Dosya((EbelgeKutusu)r.AppType,r.UUID,"XML",draft,EbelgeTarihi.Oku(latest.RawIssueDate),default);string xml=new UTF8Encoding(false,true).GetString(bytes).TrimStart('\uFEFF');var doc=UblBelge.Oku(xml);if(k.Ortam==EbelgeOrtam.Canli)depo.FirmaEsle(k.Vkn);long id=depo.BelgeAl(k,(EbelgeKutusu)r.AppType,latest,xml,draft.Value,latest.Iptal??throw new ArgumentException("Sağlayıcı iptal durumunu doğrulamadı; kayıt işlenmedi."));return(id,doc);
 }
 async Task MuhasebeIsle()
 {
  var k=Key();if(k.Ortam!=EbelgeOrtam.Canli)throw new ArgumentException("Test belgeleri gerçek carilere işlenemez.");var(file,d)=await SeciliDosyayiAl();if(d.Kimlik.Irsaliye)throw new ArgumentException("Fatura seçin; irsaliye cari borç oluşturmaz.");bool incoming=(remote.SelectedItem as HizliKayit)?.AppType==1;var cariRow=Sec("Belgedeki VKN/TCKN ile eşleşen cari",depo.Secimler("cari",incoming?d.Kimlik.Gonderen:d.Kimlik.Alici));if(cariRow is null)return;int cari=Convert.ToInt32(cariRow["Id"]);string direction=incoming?"Alacak":"Borç";if(d.Kimlik.Tur is "IADE" or "TEVKIFATIADE")direction=direction=="Borç"?"Alacak":"Borç";
  var movement=Sec("Önceden işlenmişse mevcut cari hareketini seçin",depo.Secimler("carihareket",stock:cari,yon:direction,amount:UblBelge.Yuvarla(d.Odenecek*d.Kur),date:d.Kimlik.Tarih),"Yeni cari hareketi oluştur");if(movement is null)return;long selected=Convert.ToInt64(movement["Id"]);var f=Form("Cari bağlantısı · kasa veya stok hareketi oluşturmaz",("g","Mali kontrol / işlem açıklaması; dövizliyse belgedeki TRY kurunun dayanağı",""));if(f is null)return;if(MessageBox.Show(Window.GetWindow(this),d.Kimlik.No+"\nCari: "+cariRow["Unvan"]+"\nFatura toplamı: "+d.Toplam+" "+d.Doviz+"\nTevkifat: "+d.Tevkifat+"\nCari tutarı: "+d.Odenecek+" "+d.Doviz+" / TRY "+UblBelge.Yuvarla(d.Odenecek*d.Kur)+"\nCari hareketi işlensin mi?","Muhasebe onayı",MessageBoxButton.YesNo)!=MessageBoxResult.Yes)return;long result=depo.Muhasebelestir(k,file,cari,f["g"],selected==0?null:selected,f["g"]);operations.ItemsSource=depo.IslemListesi(k).DefaultView;status.Text="Muhasebe bağlantısı tamamlandı. İşlem: "+result+". Kasa/banka hareketi oluşturulmadı.";
 }
 async Task StokIsle()
 {
  var k=Key();if(k.Ortam!=EbelgeOrtam.Canli)throw new ArgumentException("Test irsaliyesi gerçek stoğa işlenemez.");var(file,d)=await SeciliDosyayiAl();if(!d.Kimlik.Irsaliye)throw new ArgumentException("e-İrsaliye seçin.");bool incoming=(remote.SelectedItem as HizliKayit)?.AppType==4;var maps=new List<EbelgeStokEsleme>();foreach(var row in d.Satirlar){var stockRow=Sec(row.Ad+" · "+row.Miktar+" "+row.Birim+" için stok kartı seçin",depo.Secimler("stok"));if(stockRow is null)return;int stock=Convert.ToInt32(stockRow["Id"]);var movement=Sec("Önceden sevk/teslim yapıldıysa mevcut hareketi seçin",depo.Secimler("stokhareket",stock:stock,qty:row.Miktar,yon:incoming?"G":"C"),incoming?"Yeni stok girişi oluştur":"Yeni stok çıkışı oluştur (stoktan düşer)");if(movement is null)return;long selected=Convert.ToInt64(movement["Id"]);maps.Add(new(row.Id,stock,selected==0?null:selected));}
  var reason=Form("Stok işlemi onayı",("g","Fiili sevk/teslim açıklaması (stok hareketi oluşturur veya mevcut harekete bağlar)",""));if(reason is null)return;long id=depo.StokIsle(k,file,maps.ToArray(),reason["g"]);operations.ItemsSource=depo.IslemListesi(k).DefaultView;status.Text="İrsaliye stok bağlantısı tamamlandı. İşlem: "+id;
 }
 Task Tersle(){var k=Key();if(operations.SelectedItem is not DataRowView row)throw new ArgumentException("İşlem geçmişinden muhasebe kaydı seçin.");var f=Form("Yalnız muhasebe ters kaydı · GİB belgesini iptal etmez",("g","Düzeltmenin gerekçesi",""),("d","Muhasebe ters kayıt tarihi yyyy-MM-dd",DateTime.Today.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture)));if(f is null)return Task.CompletedTask;if(!DateTime.TryParseExact(f["d"],"yyyy-MM-dd",CultureInfo.InvariantCulture,DateTimeStyles.None,out var date))throw new ArgumentException("Geçerli kayıt tarihi gerekli.");depo.MuhasebeTersle(k,(long)row["Id"],f["g"],date);operations.ItemsSource=depo.IslemListesi(k).DefaultView;status.Text="Muhasebe ters kaydı eklendi; geçmiş kayıt silinmedi. Resmî belge iptali yapılmadı.";return Task.CompletedTask;}
}
public sealed partial class EbelgeDeposu
{
 public void FirmaEsle(string vkn){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EbelgeDeposu.FirmaEsle","",new object?[]{vkn});return;}
using var c=Ac();check(c,null,"FINANCE.VIEW");using var q=Q(c,null,"SELECT COUNT(*) FROM dbo.FirmaBilgileri WHERE VergiNo=@v",("@v",vkn));if(Convert.ToInt32(q.ExecuteScalar())!=1)throw new ArgumentException("Canlı bağlantı VKN/TCKN'si kayıtlı gerçek firma ile eşleşmeli.");}
}
