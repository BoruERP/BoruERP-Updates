using System.Data;
using System.Text.Json;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop.EBelge;
public sealed partial class EbelgeDeposu
{
 public void SatisMaliKaydet(long sale,UblMaliAyar mali,bool discountApproved,string reason)
 {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EbelgeDeposu.SatisMaliKaydet","",new object?[]{sale,mali,discountApproved,reason});return;}

  Gerekce(reason);using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"FINANCE.EBELGE.DRAFT");check(c,t,"CUSTOMER.EDIT");
  DateTime date;string currency;using(var q=Q(c,t,"SELECT Tarih,ParaBirimi FROM dbo.BoruERP_YeniBelgeler WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND BelgeTuru=N'S' AND Durum<>N'İptal'",("@id",sale))){using var r=q.ExecuteReader();if(!r.Read())throw new ArgumentException("Satış bulunamadı.");date=r.GetDateTime(0);currency=r.GetString(1);}
  if(mali.Doviz!=currency)throw new ArgumentException("Belge para birimi satışın kaydedildiği para birimiyle aynı olmalıdır. Eski TRY satışını döviz diye yeniden yorumlayamazsınız.");
  if(mali.Yuvarlama!=0)throw new ArgumentException("Kuruş dağılımını sistem hesaplar; elle yuvarlama girilmez.");UblMaliHesap.Dogrula(mali,date);
  if(Exists(c,t,"SELECT COUNT(*) FROM dbo.BERP270_EBelgeSatisBag WITH(UPDLOCK,HOLDLOCK) WHERE SatisId=@id AND Tur='Fatura'",("@id",sale)))throw new ArgumentException("Faturası hazırlanmış satışın mali eşlemesi değiştirilemez.");
  using var save=Q(c,t,"UPDATE dbo.MPX280_SatisMali WITH(UPDLOCK,HOLDLOCK) SET Mali=@m,BrutIndirimOnay=@b,Dayanak=@r,Kullanici=@u WHERE SatisId=@id;IF @@ROWCOUNT=0 INSERT dbo.MPX280_SatisMali(SatisId,Mali,BrutIndirimOnay,Dayanak,Kullanici)VALUES(@id,@m,@b,@r,@u)",("@id",sale),("@m",JsonSerializer.Serialize(mali)),("@b",discountApproved),("@r",reason),("@u",user));save.ExecuteNonQuery();t.Commit();
 }
 (UblMaliAyar Mali,bool Indirim,string Dayanak) SatisMali(SqlConnection c,SqlTransaction t,long sale)
 {
  using var q=Q(c,t,"SELECT Mali,BrutIndirimOnay,Dayanak FROM dbo.MPX280_SatisMali WITH(HOLDLOCK) WHERE SatisId=@id",("@id",sale));using var r=q.ExecuteReader();return r.Read()?(JsonSerializer.Deserialize<UblMaliAyar>(r.GetString(0))!,r.GetBoolean(1),r.GetString(2)):(new UblMaliAyar(),false,"");
 }
}
