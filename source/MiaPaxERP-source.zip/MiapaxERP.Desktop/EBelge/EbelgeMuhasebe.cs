using System.Data;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop.EBelge;
public sealed record EbelgeStokEsleme(string Satir,int StokId,long? MevcutHareketId=null);

public sealed partial class EbelgeDeposu
{
 public void BirimKaydet(string yerel,string ubl)
 {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EbelgeDeposu.BirimKaydet","",new object?[]{yerel,ubl});return;}

  if(string.IsNullOrWhiteSpace(yerel)||yerel.Length>20||!System.Text.RegularExpressions.Regex.IsMatch(ubl,"^[A-Z0-9]{2,3}$"))throw new ArgumentException("Yerel stok birimi ve UBL birim kodu gerekli.");using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"FINANCE.EBELGE.CONFIG");using var q=Q(c,t,"UPDATE dbo.BERP270_EBelgeBirim WITH(UPDLOCK,HOLDLOCK) SET Ubl=@u WHERE Yerel=@y;IF @@ROWCOUNT=0 INSERT dbo.BERP270_EBelgeBirim(Yerel,Ubl)VALUES(@y,@u)",("@y",yerel),("@u",ubl));q.ExecuteNonQuery();t.Commit();
 }
 public long BelgeAl(HizliKimlik key,EbelgeKutusu box,HizliKayit remote,string xml,bool isDraft,bool cancelled)
 {
  if(remote.IsDraft is{} actualDraft&&actualDraft!=isDraft||remote.Iptal is{} actualCancelled&&actualCancelled!=cancelled)throw new ArgumentException("Sağlayıcı taslak/iptal durumu ile işlem seçimi uyuşmuyor.");
  var u=UblBelge.Oku(xml);if(remote.UUID!=u.Kimlik.Ettn||remote.DocumentId!=u.Kimlik.No||remote.AppType!=(int)box||u.Kimlik.Irsaliye!=(box is EbelgeKutusu.GelenIrsaliye or EbelgeKutusu.GidenIrsaliye))throw new ArgumentException("Sağlayıcı kaydı ile XML kimliği/türü uyuşmuyor.");bool incoming=box is EbelgeKutusu.GelenFatura or EbelgeKutusu.GelenIrsaliye;if((incoming?u.Kimlik.Alici:u.Kimlik.Gonderen)!=key.Vkn)throw new ArgumentException("Belge bu bağlantının firmasına ait değil.");
  using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"FINANCE.EBELGE.QUERY");
  using(var old=Q(c,t,"SELECT Id,Ozet FROM dbo.BERP270_EBelgeDosya WITH(UPDLOCK,HOLDLOCK) WHERE Ortam=@o AND Vkn=@v AND Ettn=@e AND Kutu=@k",("@o",key.Ortam.ToString()),("@v",key.Vkn),("@e",u.Kimlik.Ettn),("@k",(int)box))){using var r=old.ExecuteReader();if(r.Read()){if(r.GetString(1)!=u.Kimlik.Ozet)throw new InvalidOperationException("Sağlayıcı aynı ETTN için farklı XML döndürdü. Önce fark incelenmeli.");long id=r.GetInt64(0);r.Close();using var update=Q(c,t,"UPDATE dbo.BERP270_EBelgeDosya SET Taslak=@d,Durum=@s,ZarfDurum=@z,Iptal=@i,Alindi=SYSDATETIMEOFFSET() WHERE Id=@id",("@d",isDraft),("@s",remote.Status),("@z",remote.EnvelopeStatus),("@i",cancelled),("@id",id));update.ExecuteNonQuery();t.Commit();return id;}}
  using var q=Q(c,t,"INSERT dbo.BERP270_EBelgeDosya(Ortam,Vkn,Ettn,Kutu,Xml,Ozet,Taslak,Durum,ZarfDurum,Iptal) OUTPUT INSERTED.Id VALUES(@o,@v,@e,@k,@x,@h,@d,@s,@z,@i)",("@o",key.Ortam.ToString()),("@v",key.Vkn),("@e",u.Kimlik.Ettn),("@k",(int)box),("@x",xml),("@h",u.Kimlik.Ozet),("@d",isDraft),("@s",remote.Status),("@z",remote.EnvelopeStatus),("@i",cancelled));long result=Convert.ToInt64(q.ExecuteScalar());t.Commit();return result;
 }
 (UblIcerik Doc,EbelgeKutusu Box) Islenecek(SqlConnection c,SqlTransaction t,HizliKimlik key,long file)
 {
  if(key.Ortam!=EbelgeOrtam.Canli)throw new InvalidOperationException("TEST belgesi gerçek cari veya stok hareketi oluşturamaz.");using var q=Q(c,t,"SELECT Xml,Ozet,Kutu,Taslak,Iptal FROM dbo.BERP270_EBelgeDosya WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Ortam=@o AND Vkn=@v",("@id",file),("@o",key.Ortam.ToString()),("@v",key.Vkn));using var r=q.ExecuteReader();if(!r.Read())throw new InvalidOperationException("Belge dosyası bulunamadı.");if(r.GetBoolean(3)||r.GetBoolean(4))throw new InvalidOperationException("Taslak veya iptal edilmiş belge işlenemez.");var d=UblBelge.Oku(r.GetString(0));if(d.Kimlik.Ozet!=r.GetString(1))throw new InvalidOperationException("Belge içeriği değişti.");return(d,(EbelgeKutusu)r.GetInt32(2));
 }
 void CariKontrol(SqlConnection c,SqlTransaction t,int id,string vkn){using var q=Q(c,t,"SELECT COUNT(*) FROM dbo.CariKartlari WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Aktif=1 AND VergiNo=@v",("@id",id),("@v",vkn));if(Convert.ToInt32(q.ExecuteScalar())!=1)throw new ArgumentException("Aktif carinin VKN/TCKN'si belge tarafıyla aynı olmalı.");}
 public long Muhasebelestir(HizliKimlik key,long file,int cari,string reason,long? mevcutCariHareket=null,string kurDayanak="")
 {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"EbelgeDeposu.Muhasebelestir","",new object?[]{key,file,cari,reason,mevcutCariHareket,kurDayanak});}

  Gerekce(reason);using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"FINANCE.EBELGE.POST");check(c,t,"CUSTOMER.EDIT");var(d,box)=Islenecek(c,t,key,file);if(d.Kimlik.Irsaliye||d.Pesinat!=0||d.Kimlik.Tur is not("SATIS" or "IADE" or "TEVKIFAT" or "TEVKIFATIADE"))throw new ArgumentException("Satış/iade/tevkifat faturası seçin; peşinat varsa önce tahsilatla eşlenmelidir. İrsaliye cari borç oluşturmaz.");
  if(d.Doviz!="TRY"&&(string.IsNullOrWhiteSpace(kurDayanak)||kurDayanak.Length>400))throw new ArgumentException("Belgedeki TRY kurunu ve mali dayanağını doğrulayın.");decimal receivable=UblBelge.Yuvarla(d.Odenecek*d.Kur);
  bool incoming=box==EbelgeKutusu.GelenFatura;CariKontrol(c,t,cari,incoming?d.Kimlik.Gonderen:d.Kimlik.Alici);string direction=incoming?"Alacak":"Borç";if(d.Kimlik.Tur is "IADE" or "TEVKIFATIADE")direction=direction=="Borç"?"Alacak":"Borç";
  if(!incoming)
  {
   using var integrated=Q(c,t,"IF OBJECT_ID('dbo.MPX310_Satis') IS NOT NULL EXEC sp_executesql N'SELECT s.CariHareketId FROM dbo.MPX310_Satis s JOIN dbo.BERP270_EBelgeSatisBag b ON b.SatisId=s.BelgeId JOIN dbo.BERP270_EBelge e ON e.Id=b.EbelgeId WHERE b.Ortam=@o AND b.Vkn=@v AND e.Ettn=@e AND b.Tur=''Fatura''',N'@o varchar(10),@v varchar(11),@e uniqueidentifier',@o,@v,@e;",("@o",key.Ortam.ToString()),("@v",key.Vkn),("@e",d.Kimlik.Ettn));
   var linked=integrated.ExecuteScalar();if(linked is not null and not DBNull){long original=Convert.ToInt64(linked);if(mevcutCariHareket.HasValue&&mevcutCariHareket!=original)throw new ArgumentException("E-belge bu satışın otomatik cari hareketine bağlanmalı.");mevcutCariHareket=original;}
  }
  using(var old=Q(c,t,"SELECT Id,CariId,OncekiHareketId FROM dbo.BERP270_EBelgeIslem WITH(UPDLOCK,HOLDLOCK) WHERE Ortam=@o AND Vkn=@v AND Ettn=@e AND Islem='Muhasebe'",("@o",key.Ortam.ToString()),("@v",key.Vkn),("@e",d.Kimlik.Ettn))){using var r=old.ExecuteReader();if(r.Read()){if(r.GetInt32(1)!=cari||(!r.IsDBNull(2)?r.GetInt64(2):(long?)null)!=mevcutCariHareket)throw new InvalidOperationException("Belge daha önce farklı bir eşlemeyle muhasebeleştirildi.");long oldId=r.GetInt64(0);r.Close();t.Commit();return oldId;}}
  long hareket;
  if(mevcutCariHareket is{} existing)
  {
   using var q=Q(c,t,"SELECT COUNT(*) FROM dbo.CariHareketleri h WITH(UPDLOCK,HOLDLOCK) WHERE h.Id=@id AND h.CariId=@c AND h.HareketTipi=@y AND h.Tutar=@m AND h.Tarih=@d AND h.TersKayitId IS NULL AND NOT EXISTS(SELECT 1 FROM dbo.CariHareketleri r WHERE r.TersKayitId=h.Id) AND NOT EXISTS(SELECT 1 FROM dbo.BERP270_EBelgeIslem e WHERE e.CariHareketId=h.Id)",("@id",existing),("@c",cari),("@y",direction),("@m",receivable),("@d",d.Kimlik.Tarih));if(Convert.ToInt32(q.ExecuteScalar())!=1)throw new ArgumentException("Mevcut cari hareketinin cari, tarih, yön ve tutarı uyuşmuyor veya daha önce bağlandı.");hareket=existing;
  }
  else
  {
   // Eski manuel kayıt ile aynı numara bulunduysa sessizce ikinci borç/alacak yaratılmaz.
   if(Exists(c,t,"SELECT COUNT(*) FROM dbo.TicariBelgeler WHERE CariId=@c AND BelgeNo=@n AND Durum=N'Kaydedildi'",("@c",cari),("@n",d.Kimlik.No)))throw new InvalidOperationException("Aynı numaralı eski ticari belge var; mevcut cari hareketini seçerek bağlayın.");
   using var q=Q(c,t,"INSERT dbo.CariHareketleri(CariId,Tarih,HareketTipi,Tutar,Aciklama,Kaynak,YapanKullaniciId) OUTPUT INSERTED.Id VALUES(@c,@d,@y,@m,@a,N'E-Belge',@u)",("@c",cari),("@d",d.Kimlik.Tarih),("@y",direction),("@m",receivable),("@a",d.Kimlik.No+" / "+d.Kimlik.Ettn),("@u",user));hareket=Convert.ToInt64(q.ExecuteScalar());
  }
  using var save=Q(c,t,"INSERT dbo.BERP270_EBelgeIslem(Ortam,Vkn,Ettn,Islem,CariId,CariHareketId,OncekiHareketId,Gerekce,Kullanici,BelgeNo,BelgeTipi,BelgeTarihi,Matrah,Kdv,GenelToplam) OUTPUT INSERTED.Id VALUES(@o,@v,@e,'Muhasebe',@c,@h,@p,@g,@u,@bn,@bt,@bd,@mat,@kdv,@gt)",("@o",key.Ortam.ToString()),("@v",key.Vkn),("@e",d.Kimlik.Ettn),("@c",cari),("@h",hareket),("@p",mevcutCariHareket),("@g",reason),("@u",user),("@bn",d.Kimlik.No),("@bt",(incoming?"Alış":"Satış")+(d.Kimlik.Tur is "IADE" or "TEVKIFATIADE"?" iade":"")),("@bd",d.Kimlik.Tarih),("@mat",UblBelge.Yuvarla(d.Matrah*d.Kur)),("@kdv",d.TryKdv??UblBelge.Yuvarla(d.Vergi*d.Kur)),("@gt",UblBelge.Yuvarla(d.Toplam*d.Kur)));long result=Convert.ToInt64(save.ExecuteScalar());
  using var fx=Q(c,t,"INSERT dbo.MPX280_EbelgeMali(IslemId,ParaBirimi,Kur,KurTarihi,KurDayanak,BelgeToplami,Tevkifat,Odenecek,TryOdenecek)VALUES(@i,@p,@r,@d,@k,@b,@t,@o,@try)",("@i",result),("@p",d.Doviz),("@r",d.Kur),("@d",d.KurTarihi??d.Kimlik.Tarih),("@k",d.Doviz=="TRY"?"TRY / kur 1":kurDayanak),("@b",d.Toplam),("@t",d.Tevkifat),("@o",d.Odenecek),("@try",receivable));fx.ExecuteNonQuery();t.Commit();return result;
 }
 static bool Exists(SqlConnection c,SqlTransaction t,string sql,params(string,object?)[] p){using var q=Q(c,t,sql,p);return Convert.ToInt32(q.ExecuteScalar())>0;}
 static void Gerekce(string value){if(string.IsNullOrWhiteSpace(value)||value.Length<5||value.Length>400)throw new ArgumentException("5-400 karakter kontrol/işlem açıklaması gerekli.");}
 public long StokIsle(HizliKimlik key,long file,EbelgeStokEsleme[] maps,string reason)
 {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"EbelgeDeposu.StokIsle","",new object?[]{key,file,maps,reason});}

  Gerekce(reason);using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"FINANCE.EBELGE.STOCK");var(d,box)=Islenecek(c,t,key,file);if(!d.Kimlik.Irsaliye)throw new ArgumentException("Stok yalnız e-İrsaliye üzerinden işlenir; fatura ikinci stok çıkışı oluşturmaz.");bool incoming=box==EbelgeKutusu.GelenIrsaliye;check(c,t,incoming?"STOCK.RECEIVE":"STOCK.ISSUE");
  if(maps.Length!=d.Satirlar.Length||maps.Select(x=>x.Satir).Distinct().Count()!=maps.Length||maps.Any(x=>x.StokId<1)||d.Satirlar.Any(r=>!maps.Any(m=>m.Satir==r.Id)||decimal.Round(r.Miktar,3)!=r.Miktar))throw new ArgumentException("Her irsaliye satırını bir stoğa eşleyin. Üç ondalıktan hassas miktar dönüştürülmeden işlenemez.");
  if(Exists(c,t,"SELECT COUNT(*) FROM dbo.BERP270_EBelgeIslem WITH(UPDLOCK,HOLDLOCK) WHERE Ortam=@o AND Vkn=@v AND Ettn=@e AND Islem='Stok'",("@o",key.Ortam.ToString()),("@v",key.Vkn),("@e",d.Kimlik.Ettn)))throw new InvalidOperationException("Bu irsaliyenin stok hareketi daha önce işlendi.");
  using var save=Q(c,t,"INSERT dbo.BERP270_EBelgeIslem(Ortam,Vkn,Ettn,Islem,Gerekce,Kullanici) OUTPUT INSERTED.Id VALUES(@o,@v,@e,'Stok',@g,@u)",("@o",key.Ortam.ToString()),("@v",key.Vkn),("@e",d.Kimlik.Ettn),("@g",reason),("@u",user));long operation=Convert.ToInt64(save.ExecuteScalar());
  foreach(var map in maps.OrderBy(x=>x.StokId).ThenBy(x=>x.Satir,StringComparer.Ordinal))
  {
   var row=d.Satirlar.Single(x=>x.Id==map.Satir);string unit;
   using(var q=Q(c,t,"SELECT s.Birim FROM dbo.StokKartlari s WITH(UPDLOCK,HOLDLOCK) JOIN dbo.BERP270_EBelgeBirim b ON b.Yerel=s.Birim AND b.Ubl=@b WHERE s.Id=@id AND s.Aktif=1",("@b",row.Birim),("@id",map.StokId)))unit=q.ExecuteScalar() as string??throw new ArgumentException("Stok aktif değil veya yerel/UBL birim eşlemesi tanımlanmadı.");
   long movement;
   if(map.MevcutHareketId is{} existing){using var q=Q(c,t,"SELECT COUNT(*) FROM dbo.StokHareketleri WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND StokKartId=@s AND Yon=@y AND Miktar=@m AND Birim=@b AND NOT EXISTS(SELECT 1 FROM dbo.BERP270_EBelgeStokBag WHERE HareketId=@id)",("@id",existing),("@s",map.StokId),("@y",incoming?"G":"C"),("@m",row.Miktar),("@b",unit));if(Convert.ToInt32(q.ExecuteScalar())!=1)throw new ArgumentException("Mevcut stok hareketi satırla uyuşmuyor veya bağlanmış.");movement=existing;}
   else
   {
    using(var q=Q(c,t,"IF EXISTS(SELECT 1 FROM dbo.StokBakiyeleri WITH(UPDLOCK,HOLDLOCK) WHERE StokKartId=@s AND Birim<>@b)THROW 51272,N'Stok bakiye birimi uyuşmuyor.',1;UPDATE dbo.StokBakiyeleri WITH(UPDLOCK,HOLDLOCK) SET Miktar=Miktar+@m,SonGuncelleme=SYSDATETIME() WHERE StokKartId=@s AND Miktar+@m>=0;IF @@ROWCOUNT=0 BEGIN IF @m<0 OR EXISTS(SELECT 1 FROM dbo.StokBakiyeleri WHERE StokKartId=@s)THROW 51272,N'Yetersiz stok.',1;INSERT dbo.StokBakiyeleri(StokKartId,Birim,Miktar)VALUES(@s,@b,@m);END",("@s",map.StokId),("@b",unit),("@m",incoming?row.Miktar:-row.Miktar)))q.ExecuteNonQuery();
    using var insert=Q(c,t,"INSERT dbo.StokHareketleri(StokKartId,HareketTipi,Yon,Miktar,Birim,Aciklama)OUTPUT INSERTED.Id VALUES(@s,N'E_IRSALIYE',@y,@m,@b,@a)",("@s",map.StokId),("@y",incoming?"G":"C"),("@m",row.Miktar),("@b",unit),("@a",d.Kimlik.No+" / "+d.Kimlik.Ettn));movement=Convert.ToInt64(insert.ExecuteScalar());
   }
   using var link=Q(c,t,"INSERT dbo.BERP270_EBelgeStokBag(IslemId,Satir,StokId,HareketId)VALUES(@i,@r,@s,@h)",("@i",operation),("@r",row.Id),("@s",map.StokId),("@h",movement));link.ExecuteNonQuery();
  }
  t.Commit();return operation;
 }
 public long MuhasebeTersle(HizliKimlik key,long operation,string reason,DateTime date)
 {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"EbelgeDeposu.MuhasebeTersle","",new object?[]{key,operation,reason,date});}

  Gerekce(reason);if(key.Ortam!=EbelgeOrtam.Canli)throw new ArgumentException("Test kaydı muhasebe ters kaydı oluşturamaz.");using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"FINANCE.EBELGE.REVERSE");long hareket;Guid ett;
  using(var q=Q(c,t,"SELECT CariHareketId,Ettn,TersId FROM dbo.BERP270_EBelgeIslem WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Ortam=@o AND Vkn=@v AND Islem='Muhasebe'",("@id",operation),("@o",key.Ortam.ToString()),("@v",key.Vkn))){using var r=q.ExecuteReader();if(!r.Read()||!r.IsDBNull(2))throw new InvalidOperationException("Muhasebe kaydı bulunamadı veya terslenmiş.");hareket=r.GetInt64(0);ett=r.GetGuid(1);}
  if(Exists(c,t,"SELECT COUNT(*) FROM dbo.MPX280_DovizOdeme o JOIN dbo.MPX280_EbelgeMali m ON m.IslemId=o.IslemId WHERE m.IslemId=@id AND o.TersCariHareketId IS NULL",("@id",operation)))throw new InvalidOperationException("Belgeye bağlı ödeme/tahsilat var; önce bunların mali düzeltmesi tamamlanmalıdır.");
  using var reverse=Q(c,t,"INSERT dbo.CariHareketleri(CariId,Tarih,HareketTipi,Tutar,Aciklama,Kaynak,YapanKullaniciId,TersKayitId) OUTPUT INSERTED.Id SELECT CariId,@d,CASE HareketTipi WHEN N'Borç' THEN N'Alacak' ELSE N'Borç' END,Tutar,@g,N'E-Belge Ters',@u,Id FROM dbo.CariHareketleri WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND TersKayitId IS NULL AND NOT EXISTS(SELECT 1 FROM dbo.CariHareketleri WHERE TersKayitId=@id)",("@d",date.Date),("@g",reason),("@u",user),("@id",hareket));var value=reverse.ExecuteScalar();if(value is null)throw new InvalidOperationException("Cari hareketi daha önce terslenmiş.");long result=Convert.ToInt64(value);
  using var record=Q(c,t,"INSERT dbo.BERP270_EBelgeIslem(Ortam,Vkn,Ettn,Islem,CariHareketId,Gerekce,Kullanici,TersId)OUTPUT INSERTED.Id VALUES(@o,@v,@e,'Ters',@h,@g,@u,@id)",("@o",key.Ortam.ToString()),("@v",key.Vkn),("@e",ett),("@h",result),("@g",reason),("@u",user),("@id",operation));long reverseId=Convert.ToInt64(record.ExecuteScalar());using var update=Q(c,t,"UPDATE dbo.BERP270_EBelgeIslem SET TersId=@r WHERE Id=@id",("@r",reverseId),("@id",operation));update.ExecuteNonQuery();t.Commit();return result;
 }
}
