using System.Data;
using System.IO;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop.EBelge;

public sealed partial class EbelgeDeposu
{
 readonly string connection;readonly int user;readonly Action<SqlConnection,SqlTransaction?,string> check;
 public EbelgeDeposu(string connection,int user):this(connection,user,(c,t,p)=>new ErpModulServisi(connection,user).Yetki(c,t,p)){}
 internal EbelgeDeposu(string connection,int user,Action<SqlConnection,SqlTransaction?,string> check){this.connection=connection;this.user=user;this.check=check;}
 SqlConnection Ac(){var c=new SqlConnection(connection);c.Open();return c;}
 static SqlCommand Q(SqlConnection c,SqlTransaction? t,string sql,params(string,object?)[] values){var q=ErpModulServisi.Komut(c,t,sql,values);foreach(SqlParameter p in q.Parameters)if(p.SqlDbType==SqlDbType.Decimal){p.Precision=28;p.Scale=8;}return q;}
 void Olay(SqlConnection c,SqlTransaction t,long id,string state,string info){using var q=Q(c,t,"INSERT dbo.BERP270_EBelgeOlay(BelgeId,Kullanici,Islem,Aciklama) VALUES(@id,@u,@s,@a)",("@id",id),("@u",user),("@s",state),("@a",info));q.ExecuteNonQuery();}
 public void Kur(){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EbelgeDeposu.Kur","",new object?[]{});return;}
using var c=Ac();check(c,null,"MODULES.INSTALL");check(c,null,"FINANCE.PAYMENT");using var q=Q(c,null,File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"EBelge270.sql")));q.ExecuteNonQuery();using var extra=Q(c,null,File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"EBelge271.sql")));extra.ExecuteNonQuery();using var mali=Q(c,null,File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"EBelge280.sql")));mali.ExecuteNonQuery();}
 public void Yetki(string permission){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EbelgeDeposu.Yetki","",new object?[]{permission});return;}
using var c=Ac();check(c,null,permission);}
 public DataTable Liste(HizliKimlik key){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"EbelgeDeposu.Liste","",new object?[]{key});}
using var c=Ac();check(c,null,"FINANCE.EBELGE.VIEW");using var q=Q(c,null,"SELECT TOP(500) Id,Ettn,BelgeNo,BelgeTarihi,AppType,Alici,Durum,Sonuc,Guncelleme,Taslak,Surum FROM dbo.BERP270_EBelge WHERE Ortam=@o AND Vkn=@v ORDER BY Id DESC",("@o",key.Ortam.ToString()),("@v",key.Vkn));using var r=q.ExecuteReader();var dt=new DataTable();dt.Load(r);return dt;}
 public long Hazirla(HizliKimlik key,HizliGonderi input,bool taslak=true,long? satisId=null)
 {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<long>(connection,"EbelgeDeposu.Hazirla","",new object?[]{key,input,taslak,satisId});}

  EbelgeJson.KimlikDogrula(key);var u=UblKimlik.Oku(input.XmlContent);u.Esle(key,input);if(input.UpdateDocument||input.IsDraft!=taslak||input.IsDraftSend)throw new ArgumentException("Bu akış yalnız yeni taslak hazırlar.");
  using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"FINANCE.EBELGE.DRAFT");
  if(satisId is{} sale){check(c,t,"CUSTOMER.VIEW");using var checkSale=Q(c,t,"SELECT COUNT(*) FROM dbo.BoruERP_YeniBelgeler b WITH(UPDLOCK,HOLDLOCK) JOIN dbo.CariKartlari c ON c.Id=b.CariId WHERE b.Id=@s AND b.BelgeTuru=N'S' AND b.Durum<>N'İptal' AND c.VergiNo=@v",("@s",sale),("@v",input.DestinationIdentifier));if(Convert.ToInt32(checkSale.ExecuteScalar())!=1)throw new ArgumentException("Satış ve e-belge alıcısı uyuşmuyor.");using var duplicate=Q(c,t,"SELECT COUNT(*) FROM dbo.BERP270_EBelgeSatisBag WITH(UPDLOCK,HOLDLOCK) WHERE Ortam=@o AND Vkn=@v AND SatisId=@s AND Tur=@k",("@o",key.Ortam.ToString()),("@v",key.Vkn),("@s",sale),("@k",input.AppType==5?"Irsaliye":"Fatura"));if(Convert.ToInt32(duplicate.ExecuteScalar())!=0)throw new InvalidOperationException("Bu satış için bu türde bir e-belge zaten hazırlandı.");}
  using(var old=Q(c,t,"SELECT Id,Ozet,KaynakEtiket,HedefEtiket,AppType,Alici,Taslak FROM dbo.BERP270_EBelge WITH(UPDLOCK,HOLDLOCK) WHERE Ortam=@o AND Vkn=@v AND Ettn=@e",("@o",key.Ortam.ToString()),("@v",key.Vkn),("@e",u.Ettn)))
  {using var r=old.ExecuteReader();if(r.Read()){if(r.GetString(1)!=u.Ozet||r.GetString(2)!=input.SourceUrn||r.GetString(3)!=input.DestinationUrn||r.GetInt32(4)!=input.AppType||r.GetString(5)!=input.DestinationIdentifier||r.GetBoolean(6)!=taslak)throw new ArgumentException("Aynı ETTN farklı içerik veya etikette kullanılamaz.");long existing=r.GetInt64(0);r.Close();t.Commit();return existing;}}
  // ERP tarafından üretilir; arayüz yeniden açıldığında veya ağ kesildiğinde değişmez.
  string local="MIAPAX ERP-"+u.Ettn.ToString("N");using var q=Q(c,t,"INSERT dbo.BERP270_EBelge(Ortam,Vkn,Ettn,BelgeNo,BelgeTarihi,AppType,Alici,KaynakEtiket,HedefEtiket,YerelId,Xml,Ozet,Olusturan,Taslak) OUTPUT INSERTED.Id VALUES(@o,@v,@e,@n,@d,@a,@al,@k,@h,@l,@x,@oz,@u,@taslak)",("@o",key.Ortam.ToString()),("@v",key.Vkn),("@e",u.Ettn),("@n",u.No),("@d",u.Tarih),("@a",input.AppType),("@al",u.Alici),("@k",input.SourceUrn),("@h",input.DestinationUrn),("@l",local),("@x",input.XmlContent),("@oz",u.Ozet),("@u",user),("@taslak",taslak));long id=Convert.ToInt64(q.ExecuteScalar());if(satisId is{} source){using var link=Q(c,t,"INSERT dbo.BERP270_EBelgeSatisBag(Ortam,Vkn,SatisId,Tur,EbelgeId)VALUES(@o,@v,@s,@k,@id);UPDATE dbo.BERP270_EBelge SET SatisId=@s WHERE Id=@id;",("@o",key.Ortam.ToString()),("@v",key.Vkn),("@s",source),("@k",input.AppType==5?"Irsaliye":"Fatura"),("@id",id));link.ExecuteNonQuery();}Olay(c,t,id,"Hazır","UBL kimliği doğrulandı; şema/schematron sonucu değildir.");t.Commit();return id;
 }
 public HizliGonderi Baslat(HizliKimlik key,long id,byte[] version)
 {
  using var c=Ac();using var t=c.BeginTransaction();HizliGonderi input;
  using(var q=Q(c,t,"SELECT AppType,KaynakEtiket,Alici,HedefEtiket,Xml,Ettn,BelgeNo,BelgeTarihi,YerelId,Ozet,Taslak,TaslakGonder FROM dbo.BERP270_EBelge WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Ortam=@o AND Vkn=@v AND Durum=N'Hazır' AND Surum=@s",("@id",id),("@o",key.Ortam.ToString()),("@v",key.Vkn),("@s",version)))
  {using var r=q.ExecuteReader();if(!r.Read())throw new InvalidOperationException("Kayıt değişti veya gönderim daha önce başlatıldı. Yenileyip ETTN ile sorgulayın.");input=new(r.GetInt32(0),r.GetString(1),r.GetString(2),r.GetString(3),r.GetString(4),r.GetGuid(5).ToString("D"),r.GetString(6),r.GetDateTime(7).ToString("yyyy-MM-dd"),r.GetString(8),IsDraft:r.GetBoolean(10),IsDraftSend:r.GetBoolean(11));var u=UblKimlik.Oku(input.XmlContent);u.Esle(key,input);if(u.Ozet!=r.GetString(9))throw new InvalidOperationException("UBL içerik özeti değişti.");}
  check(c,t,input.IsDraft?"FINANCE.EBELGE.DRAFT":"FINANCE.EBELGE.SEND");if(!input.IsDraft)UblSema.Dogrula(input.XmlContent);
  using(var q=Q(c,t,"UPDATE dbo.BERP270_EBelge SET Durum=N'Gönderim başladı',Guncelleme=SYSDATETIMEOFFSET() WHERE Id=@id",("@id",id)))q.ExecuteNonQuery();Olay(c,t,id,"Gönderim başladı",input.IsDraft?"Taslak; ağ isteği öncesi kalıcı kayıt.":"Gönderim; ağ isteği öncesi kalıcı kayıt.");t.Commit();return input;
 }
 public void Sonuc(HizliKimlik key,long id,string durum,string info)
 {
  if(durum is not("Taslak kabul edildi" or "Gönderim kabul edildi" or "Belirsiz" or "Reddedildi" or "Sağlayıcıda bulundu")||info.Length>1000)throw new ArgumentException("İşlem sonucu geçersiz.");using var c=Ac();using var t=c.BeginTransaction();bool draft;using(var read=Q(c,t,"SELECT Taslak FROM dbo.BERP270_EBelge WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Ortam=@o AND Vkn=@v",("@id",id),("@o",key.Ortam.ToString()),("@v",key.Vkn)))draft=read.ExecuteScalar() as bool? ?? throw new ArgumentException("Belge bulunamadı.");check(c,t,draft?"FINANCE.EBELGE.DRAFT":"FINANCE.EBELGE.SEND");if(draft&&durum=="Gönderim kabul edildi"||!draft&&durum=="Taslak kabul edildi")throw new ArgumentException("Belge gönderim türü ve sonuç uyuşmuyor.");using var q=Q(c,t,"UPDATE dbo.BERP270_EBelge SET Durum=@d,Sonuc=@s,Guncelleme=SYSDATETIMEOFFSET() WHERE Id=@id AND Ortam=@o AND Vkn=@v AND Durum IN(N'Gönderim başladı',N'Belirsiz',N'Reddedildi',N'Taslak kabul edildi',N'Gönderim kabul edildi',N'Sağlayıcıda bulundu')",("@d",durum),("@s",info),("@id",id),("@o",key.Ortam.ToString()),("@v",key.Vkn));if(q.ExecuteNonQuery()!=1)throw new InvalidOperationException("Sonuç kaydı güncellenemedi.");Olay(c,t,id,durum,info);t.Commit();
 }
 public static EbelgeKutusu Kutu(int sendType)=>sendType switch{1=>EbelgeKutusu.GidenFatura,3=>EbelgeKutusu.GidenArsiv,5=>EbelgeKutusu.GidenIrsaliye,_=>throw new ArgumentException("Belge türü geçersiz.")};
 public void SorguKaydet(HizliKimlik key,long id,HizliKayit found)
 {
  string info=("Sağlayıcı: "+found.Status+" / "+found.StatusExp+" · Zarf: "+found.EnvelopeStatus+" / "+found.EnvelopeExp);if(info.Length>900)info=info[..900];
  using var c=Ac();using var t=c.BeginTransaction();check(c,t,"FINANCE.EBELGE.QUERY");using var q=Q(c,t,"UPDATE dbo.BERP270_EBelge SET Durum=CASE WHEN Durum=N'Hazır' AND TaslakGonder=1 THEN N'Hazır' ELSE N'Sağlayıcıda bulundu' END,Sonuc=@s,Guncelleme=SYSDATETIMEOFFSET() WHERE Id=@id AND Ortam=@o AND Vkn=@v AND Ettn=@e AND BelgeNo=@n AND CASE AppType WHEN 1 THEN 2 ELSE AppType END=@a",("@s",info),("@id",id),("@o",key.Ortam.ToString()),("@v",key.Vkn),("@e",found.UUID),("@n",found.DocumentId),("@a",found.AppType));if(q.ExecuteNonQuery()!=1)throw new InvalidOperationException("Sorgu sonucu yerel belge kimliğiyle uyuşmuyor.");Olay(c,t,id,"ETTN ile sorgulandı",info+"; nihai mali durum otomatik yorumlanmadı.");t.Commit();
 }
 public void GonderimeHazirla(HizliKimlik key,long id,byte[] version)
 {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"EbelgeDeposu.GonderimeHazirla","",new object?[]{key,id,version});return;}

  using var c=Ac();using var t=c.BeginTransaction(IsolationLevel.Serializable);check(c,t,"FINANCE.EBELGE.SEND");string state,xml;bool providerDraft;
  using(var q=Q(c,t,"SELECT Durum,Xml FROM dbo.BERP270_EBelge WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Ortam=@o AND Vkn=@v AND Taslak=1 AND Surum=@s",("@id",id),("@o",key.Ortam.ToString()),("@v",key.Vkn),("@s",version))){using var r=q.ExecuteReader();if(!r.Read())throw new InvalidOperationException("Taslak değişti veya daha önce gönderime hazırlandı.");state=r.GetString(0);xml=r.GetString(1);}
  if(state is not("Hazır" or "Taslak kabul edildi" or "Sağlayıcıda bulundu"))throw new InvalidOperationException("Belirsiz/başlatılmış/reddedilmiş kaydı ETTN ile incelemeden gönderime geçiremezsiniz.");
  providerDraft=state!="Hazır";if(providerDraft&&!Exists(c,t,"SELECT COUNT(*) FROM dbo.BERP270_EBelgeOlay WHERE BelgeId=@id AND Islem=N'Taslak kabul edildi'",("@id",id)))throw new InvalidOperationException("Sağlayıcı taslak kabulü doğrulanmadı.");UblSema.Dogrula(xml);
  using var update=Q(c,t,"UPDATE dbo.BERP270_EBelge SET Taslak=0,TaslakGonder=@p,Durum=N'Hazır',Guncelleme=SYSDATETIMEOFFSET() WHERE Id=@id",("@p",providerDraft),("@id",id));update.ExecuteNonQuery();Olay(c,t,id,"Gönderime hazırlandı",providerDraft?"Aynı ETTN/LocalId ile sağlayıcı taslağından gönderim; henüz istek yapılmadı.":"Yerel taslak aynı ETTN/LocalId ile gönderime açıldı; henüz istek yapılmadı.");t.Commit();
 }
}
