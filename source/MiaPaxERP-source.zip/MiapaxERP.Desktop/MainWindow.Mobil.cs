using System.Windows;
using System.Windows.Controls;
using System.Data;
namespace MiapaxERP.Desktop;
public partial class MainWindow{
 MobilYerelSunucu? yerelMobil;
 internal MobilYerelTanim? YerelMobilTanim=>yerelMobil?.Tanim;
 internal async Task<MobilYerelTanim> YerelMobilBaslat(string ip){
  if(HttpsOturumu.Uzak(baglantiAdresi))throw new InvalidOperationException("Yan cihazda sunucu başlatılmaz. Ana sunucunun HTTPS telefon kodunu kullanın.");
  if(aktifKullanici is null||DemoModu)throw new InvalidOperationException("SQL oturumu gerekli.");
  string cs=baglantiAdresi;int user=aktifKullanici.KullaniciId;
  using(var c=new ErpModulServisi(cs,user).Ac())MobilHesapServisi.Yonetici(c,null,user);
  if(yerelMobil is not null){await yerelMobil.DisposeAsync();yerelMobil=null;}
  var next=new MobilYerelSunucu();bool Active()=>Dispatcher.Invoke(()=>IsVisible&&!DemoModu&&aktifKullanici?.KullaniciId==user&&baglantiAdresi==cs);
  try{var info=await next.Baslat(cs,ip,Active);yerelMobil=next;Closed-=YerelMobilKapandi;Closed+=YerelMobilKapandi;return info;}catch{await next.DisposeAsync();throw;}
 }
 async void YerelMobilKapandi(object? sender,EventArgs e){if(yerelMobil is not null){await yerelMobil.DisposeAsync();yerelMobil=null;}}
 void MobilRaporlar_Click(object sender,RoutedEventArgs e){
  if(aktifKullanici is null||DemoModu){MessageBox.Show("SQL Server oturumu açın.");return;}
  try{new MobilHesapPenceresi(baglantiAdresi,aktifKullanici.KullaniciId,this){Owner=this}.ShowDialog();}catch(Exception ex){MessageBox.Show(ex.Message,"Mobil hesaplar");}
 }
}
public sealed class MobilHesapPenceresi:Window{
 public MobilHesapPenceresi(string connection,int admin,MainWindow? ana=null){
  var service=new MobilHesapServisi(connection);service.Kur(admin);
  Title="Mobil kullanıcı ve cihaz yetkileri · 2.2.2";Width=960;Height=850;WindowStartupLocation=WindowStartupLocation.CenterOwner;
  var p=new StackPanel{Margin=new Thickness(24)};Content=new ScrollViewer{Content=p};
  p.Children.Add(new TextBlock{Text="Mobil hesaplar",FontSize=26});
  p.Children.Add(new TextBlock{Text="Her çalışan için ayrı ERP kullanıcısı seçin. SAHA yalnız kendi saha müşterilerini yönetir. PATRON tüm saha müşterilerini görür; raporlar ERP yetkileriyle açılır. MOBIL lisansı zorunludur; saha işlemleri ayrıca CRM lisansı gerektirir.",TextWrapping=TextWrapping.Wrap});
  p.Children.Add(new TextBlock{Text="Aynı Wi-Fi / yerel ağ",FontSize=20,Margin=new Thickness(0,16,0,5)});
  var ips=new ComboBox{ItemsSource=MobilYerelSunucu.Aglar(),SelectedIndex=0,MinHeight=30};p.Children.Add(ips);
  var lanStatus=new TextBlock{Text=ana?.YerelMobilTanim is {} ready?"Yerel bağlantı açık: "+ready.Adres:"Ana bilgisayara ait Wi-Fi/Ethernet IPv4 adresini seçin.",TextWrapping=TextWrapping.Wrap};p.Children.Add(lanStatus);
  var lanBar=new WrapPanel();p.Children.Add(lanBar);
  var startLan=new Button{Content="Aynı Wi-Fi bağlantısını başlat",Padding=new Thickness(8),Margin=new Thickness(4)};lanBar.Children.Add(startLan);
  startLan.Click+=async(_,_)=>{startLan.IsEnabled=false;try{if(ana is null)throw new InvalidOperationException("Ana programdan açın.");var info=await ana.YerelMobilBaslat((ips.SelectedItem as MobilAgAdresi)?.Ip??"");lanStatus.Text="Yerel bağlantı açık: "+info.Adres+" · Ana programı açık tutun.";}catch(Exception ex){lanStatus.Text=ex.Message;}finally{startLan.IsEnabled=true;}};
  var firewall=new Button{Content="Windows yerel ağ iznini ayarla",Padding=new Thickness(8),Margin=new Thickness(4)};lanBar.Children.Add(firewall);
  firewall.Click+=(_,_)=>{try{MobilYerelSunucu.AgIzni();lanStatus.Text="Windows yönetici iznini tamamlayın. Yalnız Özel/Etki Alanı ağında yerel alt ağa izin verilir.";}catch(Exception ex){lanStatus.Text="Ağ izni tamamlanmadı: "+ex.Message;}};
  if(HttpsOturumu.Uzak(connection)){ips.IsEnabled=false;startLan.IsEnabled=false;firewall.IsEnabled=false;lanStatus.Text="Bu cihaz ana sunucuya HTTPS ile bağlı. Telefon için HTTPS kodu üretin.";}
  var grid=new DataGrid{Height=230,IsReadOnly=true,AutoGenerateColumns=true,SelectionMode=DataGridSelectionMode.Single,Margin=new Thickness(0,12,0,12)};p.Children.Add(grid);
  var user=new TextBox();var name=new TextBox();var role=new ComboBox{ItemsSource=new[]{"SAHA","PATRON"},SelectedIndex=0};
  p.Children.Add(new TextBlock{Text="ERP kullanıcı numarası"});p.Children.Add(user);p.Children.Add(new TextBlock{Text="Görünen ad"});p.Children.Add(name);p.Children.Add(new TextBlock{Text="Rol"});p.Children.Add(role);
  var code=new TextBox{IsReadOnly=true,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,10,0,10)};var status=new TextBlock{TextWrapping=TextWrapping.Wrap};var bar=new WrapPanel();p.Children.Add(bar);p.Children.Add(code);p.Children.Add(status);
  void Refresh()=>grid.ItemsSource=service.Liste(admin).DefaultView;
  Guid Selected()=>grid.SelectedItem is DataRowView r?(Guid)r["Id"]:throw new ArgumentException("Hesap seçin.");
  void Button(string text,Action action){var b=new Button{Content=text,Padding=new Thickness(8),Margin=new Thickness(4)};bar.Children.Add(b);b.Click+=(_,_)=>{try{action();Guid? selected=grid.SelectedItem is DataRowView row?(Guid)row["Id"]:null;Refresh();if(selected.HasValue)grid.SelectedItem=grid.Items.Cast<DataRowView>().FirstOrDefault(r=>(Guid)r["Id"]==selected.Value);}catch(Exception ex){status.Text=ex.Message;}};}
  Button("Kendi patron hesabımı hazırla",()=>{var existing=service.Liste(admin).AsEnumerable().FirstOrDefault(r=>r.Field<int>("KullaniciId")==admin);var id=service.Kaydet(admin,admin,existing?.Field<string>("Ad")??"Patron","PATRON");Refresh();grid.SelectedItem=grid.Items.Cast<DataRowView>().First(r=>(Guid)r["Id"]==id);status.Text="Patron hesabınız seçildi. Şimdi 'Aynı Wi-Fi için telefon kodu' düğmesini kullanın.";});
  Button("Hesabı kaydet / etkinleştir",()=>{service.Kaydet(admin,int.Parse(user.Text),name.Text,role.SelectedItem.ToString()!);status.Text="Hesap kaydedildi. Eşleme için listeden seçin.";});
  Button("Aynı Wi-Fi için telefon kodu",()=>{var info=ana?.YerelMobilTanim??throw new InvalidOperationException("Önce Aynı Wi-Fi bağlantısını başlatın.");code.Text=MobilYerelSunucu.Paket(info,service.Esle(admin,Selected()));status.Text="Bu kodu telefonda 'Aynı Wi-Fi kodunu yapıştır' alanına bütünüyle yapıştırın. 15 dakika geçerli; tek kullanımlık. Windows yerel ağ izni gerekli olabilir.";});
  Button("Kodu kopyala",()=>{if(string.IsNullOrEmpty(code.Text))throw new InvalidOperationException("Önce kod üretin.");Clipboard.SetText(code.Text);status.Text="Kod kopyalandı. Yalnız ilgili telefona aktarın.";});
  Button("15 dakikalık tek kullanımlık kod",()=>{code.Text=service.Esle(admin,Selected());status.Text="Kodu yalnız ilgili çalışana verin. APK'ya HTTPS adresiyle girilir. Kod 15 dakika geçerli ve tek kullanımlıktır.";});
  Button("HTTPS için telefon kodu",()=>{var profile=KolayBaglantiProfili.Oku();var address=KolayBaglantiProfili.KisaAdres(KolayBaglantiProfili.Https(HttpsOturumu.Uzak(connection)?HttpsOturumu.Istemci!.Adres:profile.MobilHttps));var pair=service.Esle(admin,Selected());var packet=System.Text.Json.JsonSerializer.SerializeToUtf8Bytes(new{v=1,address,code=pair});code.Text="MPX-HTTPS1:"+Convert.ToBase64String(packet).TrimEnd('=').Replace('+','-').Replace('/','_');status.Text="Telefonun ilk kurulumundaki bağlantı kodu alanına bütünüyle yapıştırın. HTTPS adresi ve bu çalışanın tek kullanımlık kodu birlikte doldurulur; 15 dakika geçerlidir.";});
  Button("Hesap ve tüm cihazları iptal et",()=>{service.Iptal(admin,Selected());code.Clear();status.Text="Hesap kapatıldı; yeniden etkinleştirilse bile eski cihazlar açılmaz.";});
  p.Children.Add(new TextBlock{Text="Aynı Wi-Fi modunda ana program açık ve aynı SQL oturumunda kalmalı; yönetim penceresini kapatabilirsiniz. Dışarıdan erişim için ayrıca bağımsız mobil sunucu ve HTTPS kurulumu gerekir. Yerel kod yalnız fabrika ağı içindir.",Margin=new Thickness(0,18,0,0),TextWrapping=TextWrapping.Wrap});Refresh();
 }
}
