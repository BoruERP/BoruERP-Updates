using System.Data;
using System.IO;
using System.Windows.Media.Imaging;
using Microsoft.Data.SqlClient;

namespace MiapaxERP.Desktop;
public static class StokGorselServisi
{
    public static BitmapImage Resim(byte[] bytes, int width=128)
    {
        using var stream=new MemoryStream(bytes);
        var image=new BitmapImage();image.BeginInit();image.CacheOption=BitmapCacheOption.OnLoad;
        image.DecodePixelWidth=width;image.StreamSource=stream;image.EndInit();image.Freeze();return image;
    }
    public static byte[] Hazirla(string file)
    {
        if(new FileInfo(file).Length>20*1024*1024)throw new InvalidDataException("Fotoğraf en fazla 20 MB olmalı.");
        var bytes=File.ReadAllBytes(file);
        if(bytes.Length<8 || !(bytes[0]==255 && bytes[1]==216 && bytes[2]==255 || bytes.Take(8).SequenceEqual(new byte[]{137,80,78,71,13,10,26,10})))throw new InvalidDataException("Geçerli JPG veya PNG seçin.");
        using(var check=new MemoryStream(bytes)){
            var decoder=BitmapDecoder.Create(check,BitmapCreateOptions.DelayCreation,BitmapCacheOption.None);
            var frame=decoder.Frames[0];if((long)frame.PixelWidth*frame.PixelHeight>100_000_000)throw new InvalidDataException("Fotoğraf boyutlarını küçültün; en fazla 100 megapiksel destekleniyor.");
        }
        var image=Resim(bytes,1600);var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(image));
        using var output=new MemoryStream();encoder.Save(output);
        if(output.Length>5*1024*1024)throw new InvalidDataException("Görsel dönüştürüldükten sonra 5 MB sınırını aşıyor.");
        return output.ToArray();
    }
    public static void TabloyuDogrula(ErpSqlConnection con)
    {
        if(!con.Uzak){TabloyuDogrula((SqlConnection)con);return;}
        using var q=new ErpSqlCommand("SELECT CASE WHEN OBJECT_ID(N'dbo.UrunGorselleri',N'U') IS NULL THEN 0 ELSE 1 END",con);
        if(Convert.ToInt32(q.ExecuteScalar())!=1)throw new InvalidOperationException("Ürün görselleri tablosu eksik.");
    }
    public static void TabloyuDogrula(SqlConnection con)
    {
        using var cmd=new SqlCommand("IF OBJECT_ID(N'dbo.UrunGorselleri',N'U') IS NULL THROW 51000, N'Ürün görselleri tablosu yok. StokGorselleri_Kurulum.sql kurulumunu yönetici çalıştırmalıdır.', 1;",con);
        cmd.ExecuteNonQuery();
    }
    public static Dictionary<int,BitmapImage> Kapaklar(string connection,IEnumerable<int> ids)
    {
        if(HttpsOturumu.Uzak(connection))
        {
            var remote=new Dictionary<int,BitmapImage>();
            foreach(var group in ids.Distinct().Chunk(150))foreach(var image in new YardimciEkranServisi(connection,HttpsOturumu.Istemci!.Oturum!.Kullanici.Id).Kapaklar(group))remote[image.StokId]=Resim(image.Veri);
            return remote;
        }
        var result=new Dictionary<int,BitmapImage>();using var db=new SqlConnection(connection);db.Open();TabloyuDogrula(db);
        foreach(var group in ids.Distinct().Chunk(150))
        {
            using var cmd=new SqlCommand("SELECT StokKartId,GorselVerisi FROM (SELECT StokKartId,GorselVerisi,ROW_NUMBER() OVER(PARTITION BY StokKartId ORDER BY KapakMi DESC,SiraNo,Id) rn FROM dbo.UrunGorselleri WHERE StokKartId IN ("+string.Join(',',group.Select((_,i)=>"@p"+i))+")) g WHERE rn=1",db);
            for(int i=0;i<group.Length;i++)cmd.Parameters.Add("@p"+i,SqlDbType.Int).Value=group[i];
            using var reader=cmd.ExecuteReader();while(reader.Read())
                try{result[reader.GetInt32(0)]=Resim((byte[])reader[1]);}catch(Exception ex) when(ex is NotSupportedException or IOException or ArgumentException){System.Diagnostics.Trace.WriteLine("Ürün görseli çözümlenemedi: "+reader.GetInt32(0));}
        }
        return result;
    }
}
