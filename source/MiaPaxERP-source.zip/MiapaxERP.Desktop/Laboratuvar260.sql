SET XACT_ABORT ON;
BEGIN TRANSACTION;
DECLARE @lock260 int;
EXEC @lock260=sys.sp_getapplock @Resource=N'MiapaxERP.Laboratuvar.260',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=15000;
IF @lock260<0 THROW 51260,N'Laboratuvar kurulum kilidi alınamadı.',1;
IF OBJECT_ID(N'dbo.StokKartlari',N'U') IS NULL OR OBJECT_ID(N'dbo.StokBakiyeleri',N'U') IS NULL OR OBJECT_ID(N'dbo.StokHareketleri',N'U') IS NULL OR OBJECT_ID(N'dbo.Yetkiler',N'U') IS NULL THROW 51260,N'Önce ana stok ve yetki tabloları kurulmalıdır.',1;
IF OBJECT_ID(N'dbo.BERP_Sema',N'U') IS NULL CREATE TABLE dbo.BERP_Sema(Surum int PRIMARY KEY,Tarih datetime2 NOT NULL DEFAULT SYSUTCDATETIME());
IF OBJECT_ID(N'dbo.BERP260_LabPlan',N'U') IS NULL
BEGIN
 CREATE TABLE dbo.BERP260_LabPlan(Id bigint IDENTITY PRIMARY KEY,Ad nvarchar(160) NOT NULL,Aile nvarchar(40) NOT NULL,Veri nvarchar(max) NOT NULL,Olusturan int NOT NULL,Olusma datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET(),Onaylayan int NULL,OnayZamani datetimeoffset NULL,Surum rowversion,CHECK(Onaylayan IS NULL OR Onaylayan<>Olusturan));
 CREATE TABLE dbo.BERP260_LabCihaz(Id bigint IDENTITY PRIMARY KEY,Kod nvarchar(40) NOT NULL,Ad nvarchar(160) NOT NULL,Kalibrasyon date NOT NULL,Gecerlilik date NOT NULL,Belge nvarchar(250) NOT NULL,Olusturan int NOT NULL,Olusma datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET(),CHECK(Gecerlilik>=Kalibrasyon));
 CREATE TABLE dbo.BERP260_LabNumune(Id bigint IDENTITY PRIMARY KEY,Anahtar uniqueidentifier NOT NULL UNIQUE,Ozet char(64) NOT NULL,StokId int NOT NULL REFERENCES dbo.StokKartlari(Id),Kaynak nvarchar(40) NOT NULL,KaynakId bigint NULL,KaynakBilgi nvarchar(1000) NOT NULL,PlanId bigint NOT NULL REFERENCES dbo.BERP260_LabPlan(Id),PlanAnlik nvarchar(max) NOT NULL,Aciklama nvarchar(2000) NOT NULL,Alan int NOT NULL,Alindi datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET(),Durum nvarchar(30) NOT NULL DEFAULT N'Çalışılıyor',Inceleyen int NULL,IncelemeZamani datetimeoffset NULL,SerbestBirakan int NULL,SerbestZamani datetimeoffset NULL,Termin date NOT NULL,Surum rowversion,CHECK(Durum IN(N'Çalışılıyor',N'İncelemede',N'Onaylandı',N'Reddedildi',N'Serbest',N'İptal')));
 CREATE TABLE dbo.BERP260_LabSonuc(Id bigint IDENTITY PRIMARY KEY,Anahtar uniqueidentifier NOT NULL UNIQUE,Ozet char(64) NOT NULL,NumuneId bigint NOT NULL REFERENCES dbo.BERP260_LabNumune(Id),TestKodu nvarchar(30) NOT NULL,Veri nvarchar(max) NOT NULL,CihazId bigint NOT NULL REFERENCES dbo.BERP260_LabCihaz(Id),CihazAnlik nvarchar(max) NOT NULL,Degerlendirme nvarchar(max) NOT NULL,Durum nvarchar(20) NOT NULL,Yapan int NOT NULL,KayitZamani datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET(),CHECK(Durum IN(N'Uygun',N'Uygunsuz',N'Belirsiz')));
 CREATE INDEX IX_LabSonuc_NumuneTest ON dbo.BERP260_LabSonuc(NumuneId,TestKodu,Id DESC);
 CREATE TABLE dbo.BERP260_LabBloke(NumuneId bigint PRIMARY KEY REFERENCES dbo.BERP260_LabNumune(Id),StokId int NOT NULL REFERENCES dbo.StokKartlari(Id),Aktif bit NOT NULL DEFAULT 1);
 CREATE INDEX IX_LabBloke_Stok ON dbo.BERP260_LabBloke(StokId,Aktif);
 CREATE TABLE dbo.BERP260_LabOlay(Id bigint IDENTITY PRIMARY KEY,NumuneId bigint NULL REFERENCES dbo.BERP260_LabNumune(Id),Kullanici int NOT NULL,Olay nvarchar(100) NOT NULL,Gerekce nvarchar(2000) NOT NULL,Zaman datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET());
 CREATE TABLE dbo.BERP260_LabEk(Id bigint IDENTITY PRIMARY KEY,Anahtar uniqueidentifier NOT NULL UNIQUE,NumuneId bigint NOT NULL REFERENCES dbo.BERP260_LabNumune(Id),Ad nvarchar(180) NOT NULL,Tur varchar(30) NOT NULL,Veri varbinary(max) NOT NULL,Sha256 char(64) NOT NULL,Ekleyen int NOT NULL,Zaman datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET(),CHECK(DATALENGTH(Veri) BETWEEN 1 AND 10485760));
END;
IF OBJECT_ID(N'dbo.BERP260_LabGorev',N'U') IS NULL
BEGIN
 CREATE TABLE dbo.BERP260_LabGorev(Id bigint IDENTITY PRIMARY KEY,Anahtar uniqueidentifier NOT NULL UNIQUE,Ozet char(64) NOT NULL,NumuneId bigint NOT NULL REFERENCES dbo.BERP260_LabNumune(Id),TestKodu nvarchar(30) NOT NULL,CihazId bigint NOT NULL REFERENCES dbo.BERP260_LabCihaz(Id),Baslangic datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET(),BeklenenBitis datetimeoffset NOT NULL,Bitis datetimeoffset NULL,Kullanici int NOT NULL,Aciklama nvarchar(2000) NOT NULL,Iptal bit NOT NULL DEFAULT 0);
 CREATE UNIQUE INDEX UX_LabGorev_Aktif ON dbo.BERP260_LabGorev(NumuneId,TestKodu) WHERE Bitis IS NULL;
 CREATE TABLE dbo.BERP260_LabBag(Id bigint IDENTITY PRIMARY KEY,HammaddeNumune bigint NOT NULL REFERENCES dbo.BERP260_LabNumune(Id),UrunNumune bigint NOT NULL REFERENCES dbo.BERP260_LabNumune(Id),Kullanici int NOT NULL,Aciklama nvarchar(2000) NOT NULL,Zaman datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET(),UNIQUE(HammaddeNumune,UrunNumune),CHECK(HammaddeNumune<>UrunNumune));
END;
INSERT dbo.Yetkiler(YetkiKodu,Modul,Islem,Aciklama,Aktif)
SELECT 'LAB.'+v.Kod,N'Laboratuvar',v.Ad,v.Ad,1 FROM(VALUES('VIEW',N'Laboratuvarı görüntüle'),('SAMPLE',N'Numune kabul ve karantina'),('RESULT',N'Test sonucu kaydet'),('REVIEW',N'Teknik inceleme ve rapor onayı'),('RELEASE',N'Stok serbest bırak / boş numuneyi iptal et'),('CONFIG',N'Cihaz ve test planı oluştur'),('PLAN_APPROVE',N'Başkasının test planını onayla'),('EXPORT',N'Rapor ve ek dosya dışa aktar'))v(Kod,Ad)
WHERE NOT EXISTS(SELECT 1 FROM dbo.Yetkiler WHERE YetkiKodu='LAB.'+v.Kod);

-- Bakiye azalmasını bütün masaüstü/eski sürüm/servis yollarında aynı DB içinde engeller.
EXEC(N'CREATE OR ALTER TRIGGER dbo.tr_BERP260_LabBakiye ON dbo.StokBakiyeleri AFTER INSERT,UPDATE,DELETE AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @stocks TABLE(Id int PRIMARY KEY);
 INSERT @stocks SELECT StokKartId FROM deleted UNION SELECT StokKartId FROM inserted;
 DECLARE @dummy int;
 SELECT @dummy=s.Id FROM dbo.StokKartlari s WITH(UPDLOCK,HOLDLOCK) JOIN @stocks a ON a.Id=s.Id ORDER BY s.Id;
 IF EXISTS(SELECT 1 FROM (SELECT StokKartId,SUM(Miktar) M FROM deleted GROUP BY StokKartId) d
 LEFT JOIN (SELECT StokKartId,SUM(Miktar) M FROM inserted GROUP BY StokKartId) i ON i.StokKartId=d.StokKartId
 JOIN dbo.BERP260_LabBloke b WITH(HOLDLOCK) ON b.StokId=d.StokKartId AND b.Aktif=1 WHERE COALESCE(i.M,0)<d.M)
 THROW 51261,N''Laboratuvar karantinası: bu stok kartının tüm çıkışları durduruldu. Yetkili serbest bırakma gerekli.'',1;
END');
EXEC(N'CREATE OR ALTER TRIGGER dbo.tr_BERP260_LabHareket ON dbo.StokHareketleri AFTER INSERT,UPDATE AS
BEGIN
 SET NOCOUNT ON;
 IF NOT EXISTS(SELECT 1 FROM inserted WHERE Yon=N''C'') RETURN;
 DECLARE @dummy int;
 SELECT @dummy=s.Id FROM dbo.StokKartlari s WITH(UPDLOCK,HOLDLOCK) JOIN inserted i ON i.StokKartId=s.Id ORDER BY s.Id;
 IF EXISTS(SELECT 1 FROM inserted i JOIN dbo.BERP260_LabBloke b WITH(HOLDLOCK) ON b.StokId=i.StokKartId AND b.Aktif=1 WHERE i.Yon=N''C'')
 THROW 51261,N''Laboratuvar karantinası: stok çıkış hareketi oluşturulamaz.'',1;
END');
IF NOT EXISTS(SELECT 1 FROM dbo.BERP_Sema WHERE Surum=260)INSERT dbo.BERP_Sema(Surum)VALUES(260);
COMMIT;

IF OBJECT_ID('dbo.BERP260_LabCihazPdf','U') IS NULL
CREATE TABLE dbo.BERP260_LabCihazPdf(Id bigint IDENTITY PRIMARY KEY,Anahtar uniqueidentifier NOT NULL UNIQUE,CihazId bigint NOT NULL REFERENCES dbo.BERP260_LabCihaz(Id),Ad nvarchar(180) NOT NULL,Veri varbinary(max) NOT NULL,Sha256 char(64) NOT NULL,Ekleyen int NOT NULL,Eklenme datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET());
