using SqlConnection = MiapaxERP.Desktop.ErpSqlConnection;
using SqlCommand = MiapaxERP.Desktop.ErpSqlCommand;
using SqlTransaction = MiapaxERP.Desktop.ErpSqlTransaction;
using SqlDataReader = MiapaxERP.Desktop.ErpSqlReader;
using SqlDataAdapter = MiapaxERP.Desktop.ErpSqlDataAdapter;
using System.Data;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public partial class MainWindow
{
    bool SektorUretimOzeti(SqlConnection c,int user,AnaSayfaVeriPaketi result)
    {
        string sector=LisansOturumu.Gecerli?.Sector??gorunum.Sektor;if(sector=="BORU")return false;
        string permission=sector=="RESTORAN"?"RESTAURANT.VIEW":"PRODUCTION.VIEW";
        try{if(HttpsOturumu.Uzak(baglantiAdresi)){if(!new YardimciEkranServisi(baglantiAdresi,user).YetkiVar(permission))throw new UnauthorizedAccessException();}else new ErpModulServisi(baglantiAdresi,user).Yetki(c,null,permission);result.UretimGoruntulemeYetkisi=true;}catch(UnauthorizedAccessException){result.UretimGoruntulemeYetkisi=false;}
        if(!result.UretimGoruntulemeYetkisi)return true;
        string table=sector=="RESTORAN"?"dbo.BERP200_AdisyonKalem":"dbo.BERP200_Uretim";
        using(var exists=new SqlCommand("SELECT OBJECT_ID(@t,N'U')",c)){exists.Parameters.AddWithValue("@t",table);if(exists.ExecuteScalar() is DBNull){result.AktifUretimSayisi=-1;return true;}}
        string sql=sector=="RESTORAN"?"""
            SELECT TOP(5) k.Ad AS StokAdi,FORMAT(k.Miktar,'0.###','tr-TR')+N' '+s.Birim AS PlanlananMetin,k.MutfakDurumu AS UretilenMetin,
            CONVERT(decimal(9,2),NULL) AS Ilerleme,CONVERT(decimal(9,2),NULL) AS PaketIlerleme
            FROM dbo.BERP200_AdisyonKalem k JOIN dbo.BERP200_Adisyon a ON a.Id=k.AdisyonId JOIN dbo.StokKartlari s ON s.Id=k.MamulId
            WHERE a.Kapanis IS NULL AND k.Iptal=0 ORDER BY k.Id
            """:"""
            SELECT TOP(5) r.Ad AS StokAdi,FORMAT(u.Miktar,'0.###','tr-TR')+N' '+r.CiktiBirimi AS PlanlananMetin,
            N'Tamamlandı' AS UretilenMetin,CONVERT(decimal(9,2),100) AS Ilerleme,CONVERT(decimal(9,2),NULL) AS PaketIlerleme
            FROM dbo.BERP200_Uretim u JOIN dbo.BERP200_Recete r ON r.Id=u.ReceteId ORDER BY u.Id DESC
            """;
        using(var q=new SqlCommand(sql,c)){using var rd=q.ExecuteReader();result.Uretim.Load(rd);}
        using(var count=new SqlCommand(sector=="RESTORAN"?"SELECT COUNT_BIG(*) FROM dbo.BERP200_Adisyon WHERE Kapanis IS NULL":"SELECT COUNT_BIG(*) FROM dbo.BERP200_Uretim",c))result.AktifUretimSayisi=Convert.ToInt64(count.ExecuteScalar());
        return true;
    }
    void SektorOzetYazilariniUygula(AnaSayfaVeriPaketi result)
    {
        string sector=LisansOturumu.Gecerli?.Sector??gorunum.Sektor;if(sector=="BORU")return;
        TxtAnaUretimSayi.Text=!result.UretimGoruntulemeYetkisi?"Yetki yok":result.AktifUretimSayisi<0?"Kurulum gerekli":result.AktifUretimSayisi+(sector=="RESTORAN"?" açık adisyon":" üretim kaydı");
        TxtAnaUretimDurum.Text=!result.UretimGoruntulemeYetkisi?"Bu sektör bölümünü görüntüleme yetkiniz yok.":result.AktifUretimSayisi<0?"Sektör modülünü ilk kez yönetici hesabıyla açıp kurun.":sector=="RESTORAN"?"Açık adisyonların mutfak kalemleri gösteriliyor.":"Son tamamlanan reçeteli üretimler gösteriliyor.";
    }
}
