using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using Microsoft.Data.SqlClient;

namespace MiapaxERP.Desktop
{
    public partial class BaglantiAyarlariPenceresi
    {
        private bool otomatikKesifCalisiyor;
        private bool otomatikKesifPencereKapatiliyor;
        private CancellationTokenSource? otomatikKesifIptal;

        private async void AgKesifPenceresiYuklendi(object sender, RoutedEventArgs e)
        {
            // İnternet/RDS profili açılırken başka ağdaki SQL sunucusunu arayıp
            // eski yerel ayarı otomatik değiştirmeyin. Yerel sekmede arama düğmesi var.
            if (Content is System.Windows.Controls.TabControl sekmeler && sekmeler.SelectedIndex == 0) return;
            // Yeni kurulan makinede localhost yoksa hicbir SQL sifresi istemeden agda ara.
            // Var olan baglanti ayarini yanlislikla degistirme.
            var ayar = MiapaxERPBaglantiAyarlari.Oku();
            if(ayar.UzakVpn){TxtKesifDurum.Text="VPN profili etkin. Fabrika adresi korunur; bulunduğunuz ağda otomatik ana bilgisayar araması yapılmaz.";BtnAnaPcBul.IsEnabled=false;return;}
            if (ayar.Rol == "Yan")
            {
                var mevcut = new MiapaxERPAnaMakineDuyurusu.KesifAdayi
                { Sunucu = ayar.Sunucu, Veritabani = ayar.Veritabani };
                var kontrol = await MiapaxERPAnaMakineDuyurusu.SqlDogrulaAsync(mevcut);
                if (!kontrol.Basarili && !otomatikKesifPencereKapatiliyor)
                    await AgKesfiBaslatAsync(true);
            }
            else if (ayar.Sunucu.Equals("localhost", StringComparison.OrdinalIgnoreCase) ||
                     ayar.Sunucu == "." || ayar.Sunucu == "127.0.0.1")
            {
                var mevcut = new MiapaxERPAnaMakineDuyurusu.KesifAdayi
                { Sunucu = ayar.Sunucu, Veritabani = ayar.Veritabani };
                var kontrol = await MiapaxERPAnaMakineDuyurusu.SqlDogrulaAsync(mevcut);
                if (!kontrol.Basarili && !otomatikKesifPencereKapatiliyor)
                    await AgKesfiBaslatAsync(true);
            }
        }

        private void AgKesifPenceresiKapandi(object? sender, EventArgs e)
        {
            otomatikKesifPencereKapatiliyor = true;
            otomatikKesifIptal?.Cancel();
        }

        private async void AnaPcBul_Click(object sender, RoutedEventArgs e) =>
            await AgKesfiBaslatAsync(false);

        private async Task AgKesfiBaslatAsync(bool otomatik)
        {
            if(ChkUzakVpn.IsChecked==true){TxtKesifDurum.Text="VPN modunda fabrika IP adresini manuel kullanın. Yerel ağ araması yapılmadı.";return;}
            if (otomatikKesifCalisiyor || otomatikKesifPencereKapatiliyor) return;
            otomatikKesifCalisiyor = true;
            BtnAnaPcBul.IsEnabled = false;
            TxtKesifDurum.Text = "Ağdaki MiapaxERP ana bilgisayarları aranıyor...";
            using var kaynak = new CancellationTokenSource();
            otomatikKesifIptal = kaynak;
            try
            {
                var adaylar = await MiapaxERPAnaMakineDuyurusu.AnaBilgisayarlariBulAsync(kaynak.Token);
                if (otomatikKesifPencereKapatiliyor||ChkUzakVpn.IsChecked==true) return;
                if (adaylar.Count == 0)
                {
                    TxtKesifDurum.Text = "Ana PC bulunamadı. Ana PC'de MiapaxERP açık olmalı; UDP 38765 yerel ağda erişilebilir olmalı. Aşağıdan IP ile manuel deneyebilirsiniz.";
                    return;
                }
                if (adaylar.Count > 1)
                {
                    TxtKesifDurum.Text = "Birden fazla ana PC bulundu (" +
                        string.Join(" | ", adaylar.Select(a => a.Bilgisayar + ": " + a.Sunucu)) +
                        "). Yanlış veritabanına bağlanmamak için otomatik seçim yapılmadı. Manuel bağlantı alanını kullanın.";
                    return;
                }
                var aday = adaylar[0];
                TxtKesifDurum.Text = aday.Bilgisayar + " bulundu (" + aday.Sunucu + "). SQL girişi doğrulanıyor...";
                var sonuc = await MiapaxERPAnaMakineDuyurusu.SqlDogrulaAsync(aday);
                if (otomatikKesifPencereKapatiliyor||ChkUzakVpn.IsChecked==true) return;
                if (!sonuc.Basarili)
                {
                    // Bulunmus IP'yi kullanicinin onune koy; baglanti testi basarisizsa ASLA otomatik kaydetme.
                    TxtSunucu.Text = aday.Sunucu;
                    TxtVeritabani.Text = aday.Veritabani;
                    CmbRol.SelectedIndex = 1;
                    TxtKesifDurum.Text = "Ana PC bulundu; fakat SQL erişimi başarısız: " + sonuc.Hata +
                        "  — TCP/IP, sabit SQL portu ve Windows kullanıcı iznini kontrol edin. Manuel panel açık.";
                    return;
                }
                CmbRol.SelectedIndex = 1;
                TxtSunucu.Text = aday.Sunucu;
                TxtVeritabani.Text = aday.Veritabani;
                FormuOku().Kaydet();
                TxtKesifDurum.Text = "✓ Ana PC ve MiapaxERP veritabanı doğrulandı. Bağlantı kaydedildi (" +
                    aday.Sunucu + "). Programı kapatıp yeniden açın.";
                TxtDurum.Text = "✓ Otomatik bağlantı kaydedildi. Değişikliğin uygulanması için programı yeniden başlatın.";
            }
            catch (OperationCanceledException) { }
            catch (Exception ex)
            {
                if (!otomatikKesifPencereKapatiliyor)
                    TxtKesifDurum.Text = "Otomatik arama tamamlanamadı: " + ex.Message + ". Manuel bağlantıyı deneyin.";
            }
            finally
            {
                otomatikKesifIptal = null;
                otomatikKesifCalisiyor = false;
                if (!otomatikKesifPencereKapatiliyor) BtnAnaPcBul.IsEnabled = ChkUzakVpn.IsChecked!=true;
            }
        }
    }
}
