using System.IO;
namespace MiapaxERP.Desktop;
public sealed class MagazaHttpsServisi(string connection,int user)
{
    string Folder=>Path.Combine(GorunumDeposu.Klasor(connection,user),"Magazalar");
    void Check(string p){var db=new ErpModulServisi(connection,user);using var c=db.Ac();db.Yetki(c,null,p);}
    public void Yetki(string p){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"MagazaHttpsServisi.Yetki","",new object?[]{p});return;}
if(p is not("ECOM.VIEW" or "ECOM.EDIT"))throw new ArgumentException("Mağaza yetkisi geçersiz.");Check(p);}
    public MagazaAyar? Oku(string kanal){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<MagazaAyar?>(connection,"MagazaHttpsServisi.Oku","",new object?[]{kanal});}
Check("ECOM.VIEW");var a=MagazaBaglantisi.Oku(Folder,kanal);return a is null?null:a with{Anahtar="",Gizli=""};}
    MagazaAyar Merge(MagazaAyar a){var old=MagazaBaglantisi.Oku(Folder,a.Kanal);if(old is not null){if(old.Magaza!=a.Magaza)throw new ArgumentException("Mağaza değişiyorsa bağlantıyı yeni anahtarlarla tekrar tanımlayın.");a=a with{Anahtar=a.Anahtar.Length==0?old.Anahtar:a.Anahtar,Gizli=a.Gizli.Length==0?old.Gizli:a.Gizli};}return a;}
    public void Kaydet(MagazaAyar a){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"MagazaHttpsServisi.Kaydet","",new object?[]{a});return;}
Check("ECOM.EDIT");if(a.Magaza.Length>300||a.Anahtar.Length>8192||a.Gizli.Length>8192||a.Entegrator.Length>300)throw new ArgumentException("Mağaza bağlantı alanları çok uzun.");a=Merge(a);MagazaBaglantisi.Kaydet(Folder,a);}
    public MagazaSayfa Getir(MagazaAyar a,string? cursor){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<MagazaSayfa>(connection,"MagazaHttpsServisi.Getir","",new object?[]{a,cursor});}
Check("ECOM.EDIT");a=Merge(a);return MagazaBaglantisi.Getir(a,cursor,default).GetAwaiter().GetResult();}
}
