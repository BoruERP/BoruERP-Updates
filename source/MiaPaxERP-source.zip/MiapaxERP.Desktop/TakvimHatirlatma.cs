namespace MiapaxERP.Desktop;

public sealed record TakvimHatirlatma(int Id, DateTime Tarih, string Baslik, string Durum)
{
    public string Anahtar => $"{Id}:{Tarih.Ticks}";
    public bool OzetteGoster(DateTime now) => Durum == "Bekliyor" && Tarih < now.Date.AddDays(2);
    public bool ZamaniGeldi(DateTime now) => Durum == "Bekliyor" && Tarih <= now;
    public string Satir(DateTime now) => $"{(Tarih < now ? "GECİKMİŞ" : Tarih.Date == now.Date ? "BUGÜN" : "YARIN")} • {Tarih:dd.MM HH:mm} • {Baslik}";
}
