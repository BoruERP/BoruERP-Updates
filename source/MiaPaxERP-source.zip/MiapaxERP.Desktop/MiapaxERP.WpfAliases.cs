// MiapaxERP WPF/Windows Forms isim cakismalarini giderir.
// Windows Forms yalnizca tam adiyla (System.Windows.Forms.NotifyIcon gibi) kullanilmalidir.
global using MessageBox = MiapaxERP.Desktop.ModernMesaj;
global using Application = System.Windows.Application;
global using TextBox = System.Windows.Controls.TextBox;
global using Button = System.Windows.Controls.Button;
global using Panel = System.Windows.Controls.Panel;
global using Control = System.Windows.Controls.Control;
global using ComboBox = System.Windows.Controls.ComboBox;
global using UserControl = System.Windows.Controls.UserControl;
global using DataGrid = System.Windows.Controls.DataGrid;
global using KeyEventArgs = System.Windows.Input.KeyEventArgs;
global using Color = System.Windows.Media.Color;
global using Brushes = System.Windows.Media.Brushes;
global using Brush = System.Windows.Media.Brush;
global using Pen = System.Windows.Media.Pen;
global using FontFamily = System.Windows.Media.FontFamily;
global using ColorConverter = System.Windows.Media.ColorConverter;
global using SaveFileDialog = Microsoft.Win32.SaveFileDialog;
global using OpenFileDialog = Microsoft.Win32.OpenFileDialog;
global using PrintDialog = System.Windows.Controls.PrintDialog;
global using Clipboard = System.Windows.Clipboard;
global using CheckBox = System.Windows.Controls.CheckBox;
