using System.Windows;
namespace MiapaxERP.Desktop;
public partial class TicariModullerPaneli
{
    private void YeniTicariEkranAc_Click(object sender, RoutedEventArgs e) => BolumIstendi?.Invoke("teklif");
}
