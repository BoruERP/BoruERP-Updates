SET XACT_ABORT ON;
BEGIN TRANSACTION;
DECLARE @lock int;EXEC @lock=sys.sp_getapplock @Resource=N'MiapaxERP.Ebelge.280',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=15000;
IF @lock<0 THROW 51280,N'Mali belge kurulum kilidi alınamadı.',1;
IF OBJECT_ID('dbo.MPX280_SatisMali','U') IS NULL CREATE TABLE dbo.MPX280_SatisMali(SatisId bigint PRIMARY KEY,Mali nvarchar(max) NOT NULL CHECK(ISJSON(Mali)=1),BrutIndirimOnay bit NOT NULL,Dayanak nvarchar(400) NOT NULL,Kullanici int NOT NULL,Surum rowversion);
IF OBJECT_ID('dbo.BoruERP_YeniBelgeler','U') IS NOT NULL AND COL_LENGTH('dbo.BoruERP_YeniBelgeler','ParaBirimi') IS NULL EXEC(N'ALTER TABLE dbo.BoruERP_YeniBelgeler ADD ParaBirimi varchar(3) NOT NULL CONSTRAINT DF_MPX280_SatisPara DEFAULT ''TRY''');
IF OBJECT_ID('dbo.MPX280_EbelgeMali','U') IS NULL
BEGIN
 CREATE TABLE dbo.MPX280_EbelgeMali(IslemId bigint PRIMARY KEY REFERENCES dbo.BERP270_EBelgeIslem(Id),ParaBirimi varchar(3) NOT NULL,Kur decimal(18,8) NOT NULL CHECK(Kur>0),KurTarihi date NOT NULL,KurDayanak nvarchar(400) NOT NULL,
 BelgeToplami decimal(18,2) NOT NULL,Tevkifat decimal(18,2) NOT NULL,Odenecek decimal(18,2) NOT NULL,TryOdenecek decimal(18,2) NOT NULL,Kapanan decimal(18,2) NOT NULL DEFAULT 0,KapananTry decimal(18,2) NOT NULL DEFAULT 0,Surum rowversion);
 CREATE TABLE dbo.MPX280_DovizOdeme(Id bigint IDENTITY PRIMARY KEY,Anahtar uniqueidentifier NOT NULL UNIQUE,IslemId bigint NOT NULL REFERENCES dbo.MPX280_EbelgeMali(IslemId),Tarih date NOT NULL,DovizTutar decimal(18,2) NOT NULL,Kur decimal(18,8) NOT NULL,BankaTutar decimal(18,2) NOT NULL,TryTutar decimal(18,2) NOT NULL,DefterTry decimal(18,2) NOT NULL,KurFarki decimal(18,2) NOT NULL,CariHareketId bigint NOT NULL UNIQUE,FinansHareketId bigint NOT NULL UNIQUE,Kullanici int NOT NULL,Dayanak nvarchar(400) NOT NULL,Zaman datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET());
END;
IF COL_LENGTH('dbo.MPX280_DovizOdeme','TersCariHareketId') IS NULL ALTER TABLE dbo.MPX280_DovizOdeme ADD TersCariHareketId bigint NULL,TersFinansHareketId bigint NULL,TersTarih date NULL,TersGerekce nvarchar(400) NULL,TersKullanici int NULL;
INSERT dbo.Yetkiler(YetkiKodu,Modul,Islem,Aciklama,Aktif)
SELECT p.Kod,N'Muhasebe',p.Islem,p.Aciklama,1 FROM(VALUES
('FINANCE.FX.VIEW',N'Döviz görüntüle',N'Belge dövizi, TRY karşılıkları ve gerçekleşen kur farkı'),
('FINANCE.FX.PAY',N'Döviz kapat',N'Kur bilgisiyle belgeye bağlı kısmi / tam tahsilat veya ödeme'),
('FINANCE.FX.REVERSE',N'Döviz ödeme ters kaydı',N'Belge kapamasını cari/kasa/banka ters kayıtlarıyla düzeltme'),
('FINANCE.RECONCILE.VIEW',N'Mutabakat',N'Alış/satış mutabakatı ve eski BA/BS arşivi'))p(Kod,Islem,Aciklama)
WHERE NOT EXISTS(SELECT 1 FROM dbo.Yetkiler y WHERE y.YetkiKodu=p.Kod);
IF OBJECT_ID('dbo.MPX280_BabsArsiv','U') IS NULL CREATE TABLE dbo.MPX280_BabsArsiv(Id bigint IDENTITY PRIMARY KEY,Yil int NOT NULL,Ay int NOT NULL CHECK(Ay BETWEEN 1 AND 12),Tur varchar(2) NOT NULL CHECK(Tur IN('BA','BS')),Aciklama nvarchar(400) NOT NULL,Dosya varbinary(max) NOT NULL,Ozet char(64) NOT NULL,Kullanici int NOT NULL,Zaman datetimeoffset NOT NULL DEFAULT SYSDATETIMEOFFSET(),CHECK(Yil BETWEEN 2000 AND 2024 AND (Yil<2024 OR Ay<=8)),UNIQUE(Yil,Ay,Tur,Ozet));
INSERT dbo.Yetkiler(YetkiKodu,Modul,Islem,Aciklama,Aktif)
SELECT p.Kod,N'Muhasebe',p.Islem,p.Aciklama,1 FROM(VALUES
('FINANCE.RECONCILE.ARCHIVE',N'BA/BS arşivle',N'Eylül 2024 öncesi tarihî bildirim PDF arşivi'),
('FINANCE.RECONCILE.DOWNLOAD',N'Arşiv indir',N'Tarihî BA/BS arşivi indirme'))p(Kod,Islem,Aciklama)
WHERE NOT EXISTS(SELECT 1 FROM dbo.Yetkiler y WHERE y.YetkiKodu=p.Kod);
COMMIT;
