namespace MiapaxERP.Desktop;
public sealed partial class YardimciEkranServisi
{
    public bool YetkiVar(string code){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<bool>(connection,"YardimciEkranServisi.YetkiVar","",new object?[]{code});}
if(code is null||code.Length is <1 or >80)throw new ArgumentException("Yetki kodu geçersiz.");using var c=access.Ac();try{access.Yetki(c,null,code);return true;}catch(UnauthorizedAccessException){return false;}}
    public void OturumKontrol(){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"YardimciEkranServisi.OturumKontrol","",new object?[]{});return;}
using var c=access.Ac();using var q=Q(c,null,"SELECT COUNT(*) FROM dbo.Kullanicilar WHERE Id=@u AND Aktif=1",("@u",user));if(Convert.ToInt32(q.ExecuteScalar())!=1)throw new UnauthorizedAccessException();}
}
