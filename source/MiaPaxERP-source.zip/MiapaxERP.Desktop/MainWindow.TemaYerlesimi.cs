using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Effects;

namespace MiapaxERP.Desktop;

public partial class MainWindow
{
    private void KabukYerlesiminiUygula(GorunumTercihleri a)
    {
        string layout = Tema170.Yerlesim(a), density = Tema170.Yogunluk(a);
        bool top = layout == "Üst menü", right = layout == "Sağ menü";
        double width = density == "Ferah" ? 260 : density == "Kompakt" ? 210 : 235;
        TemaKabuk.ColumnDefinitions[0].Width = top || right ? new GridLength(1, GridUnitType.Star) : new GridLength(width);
        TemaKabuk.ColumnDefinitions[1].Width = top ? new GridLength(0) : right ? new GridLength(width) : new GridLength(1, GridUnitType.Star);
        TemaKabuk.RowDefinitions[0].Height = top ? GridLength.Auto : new GridLength(1, GridUnitType.Star);
        TemaKabuk.RowDefinitions[1].Height = top ? new GridLength(1, GridUnitType.Star) : new GridLength(0);
        Grid.SetColumn(TemaMenu, right ? 1 : 0); Grid.SetColumn(TemaIcerik, top || right ? 0 : 1);
        Grid.SetRow(TemaIcerik, top ? 1 : 0);
        TemaMenuOgeleri.Orientation = top ? System.Windows.Controls.Orientation.Horizontal : System.Windows.Controls.Orientation.Vertical;
        TemaMenuKaydir.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
        TemaMenuKaydir.VerticalScrollBarVisibility = top ? ScrollBarVisibility.Disabled : ScrollBarVisibility.Auto;
        TemaMarka.Visibility = top ? Visibility.Collapsed : Visibility.Visible;
        TemaMenu.Padding = new Thickness(top ? 8 : 0);
        foreach (Button button in TemaMenuOgeleri.Children.OfType<Button>())
        {
            button.Height = density == "Ferah" ? 52 : density == "Kompakt" ? 36 : 44;
            button.Margin = new Thickness(top ? 4 : 10, 3, top ? 4 : 10, 3);
            button.Padding = new Thickness(14,0,14,0);
            button.FontSize = a.Tema == "VIP" ? 14 : 13;
            // Genel düğme şablonu klavye, devre dışı ve üzerine gelme durumlarını korur.
            button.Template = ((Style)Application.Current.FindResource(typeof(Button))).Setters.OfType<Setter>().First(s => s.Property == Button.TemplateProperty).Value as ControlTemplate;
        }
        KartKisayol.Columns = a.KisayolSutun == 0 ? a.Tema == "VIP" ? 4 : a.Tema == "Eskitme" ? 7 : a.Tema == "Kültürel" ? 3 : 5 : a.KisayolSutun;
        SayfaBasligi.FontFamily = new FontFamily(a.Tema is "VIP" or "Eskitme" or "Kültürel" ? "Cambria" : a.YaziTipi);
        SayfaBasligi.FontSize = a.Tema == "VIP" ? 27 : 23;
        foreach (Button button in KartKisayol.Children.OfType<Button>())
        {
            button.SetResourceReference(Control.BackgroundProperty, "ErpMenu");
            button.MinHeight = density == "Kompakt" ? 76 : density == "Ferah" ? 116 : 96;
        }
        if (BrdIsTakvimi.Parent is StackPanel dashboard)
        {
            UIElement[] sections = Tema170.AnaSayfaDuzeni(a) switch {
                "Modül odaklı" => [KartKisayol, BrdIsTakvimi, KartHaber],
                "Haber odaklı" => [KartHaber, KartKisayol, BrdIsTakvimi],
                _ => [BrdIsTakvimi, KartKisayol, KartHaber]
            };
            foreach (var section in sections) dashboard.Children.Remove(section);
            for (int i=0;i<sections.Length;i++) dashboard.Children.Insert(i,sections[i]);
        }
        foreach (Border card in new[] { BrdIsTakvimi, KartHaber })
        {
            card.SetResourceReference(Border.BackgroundProperty,"ErpKart");
            card.SetResourceReference(Border.BorderBrushProperty,"ErpCizgi");
            foreach (TextBlock text in KartYazilari(card)) text.SetResourceReference(TextBlock.ForegroundProperty,"ErpMetin");
        }
        foreach (string id in GorunumTercihleri.Kartlar.Select(k => k.Id).Append("IsTakvimi"))
        {
            if (FindName(id == "IsTakvimi" ? "BrdIsTakvimi" : "Kart" + id) is not Border card) continue;
            card.SetResourceReference(Border.CornerRadiusProperty, "ErpKose");
            card.Padding = new Thickness(density == "Ferah" ? 22 : density == "Kompakt" ? 10 : 16);
            card.Effect = a.Golge ? new DropShadowEffect { BlurRadius = a.Tema == "VIP" ? 22 : 10, ShadowDepth = 2, Opacity = .12, Color = Colors.Black } : null;
        }
    }
    private static IEnumerable<TextBlock> KartYazilari(DependencyObject parent)
    {
        foreach (var child in LogicalTreeHelper.GetChildren(parent).OfType<DependencyObject>())
        {
            if (child is Button or DataGrid or Calendar) continue;
            if (child is TextBlock text) yield return text;
            foreach (var nested in KartYazilari(child)) yield return nested;
        }
    }
    private void TakvimYerlesiminiUygula()
    {
        bool narrow = TemaTakvimAlani.ActualWidth < 650;
        TemaTakvimAlani.ColumnDefinitions[0].Width = narrow ? new GridLength(1,GridUnitType.Star) : GridLength.Auto;
        TemaTakvimAlani.ColumnDefinitions[1].Width = narrow ? new GridLength(0) : new GridLength(1,GridUnitType.Star);
        Grid.SetColumn(TemaTakvimListeAlani,narrow ? 0 : 1); Grid.SetRow(TemaTakvimListeAlani,narrow ? 1 : 0);
        IsTakvimiTakvim.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
        TemaTakvimListeAlani.Margin = narrow ? new Thickness(0,12,0,0) : new Thickness(0);
    }
}


