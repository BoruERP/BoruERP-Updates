using System.Data;
namespace MiapaxERP.Desktop;
public sealed partial class IsletmeServisi
{
    public DataTable SatisBakiyeleri(){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"IsletmeServisi.SatisBakiyeleri","",new object?[]{});}
using var c=access.Ac();Yetki(c,null,"FINANCE.VIEW");return Table(Q(c,null,"SELECT TOP(500) s.BelgeId Id,d.BelgeNo,c.Unvan Musteri,d.Tarih,s.Doviz,s.Kur,s.Toplam,s.Kapanan,s.Toplam-s.Kapanan Kalan,h.Tutar-COALESCE((SELECT SUM(DefterTutar) FROM dbo.MPX310_Tahsilat WHERE BelgeId=s.BelgeId),0) KalanTRY,s.Surum FROM dbo.MPX310_Satis s JOIN dbo.BoruERP_YeniBelgeler d ON d.Id=s.BelgeId JOIN dbo.CariKartlari c ON c.Id=d.CariId JOIN dbo.CariHareketleri h ON h.Id=s.CariHareketId WHERE d.Durum<>N'İptal' ORDER BY s.BelgeId DESC"));}
}
