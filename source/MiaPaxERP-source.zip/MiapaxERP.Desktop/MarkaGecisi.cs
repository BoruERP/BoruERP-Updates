using System.IO;
using System.IO.Compression;

namespace MiapaxERP.Desktop;

// Yalnız önceki yayınlarda dağıtılan program dosyaları. Müşteri verisi ve
// bağlantı/lisans ayarları bu listeye hiçbir zaman dahil edilmez.
public static class MarkaGecisi
{
    private static readonly string[] OncekiAdlar = ["BoruERP.Desktop", "MiaSoft.Desktop", "BoruERP.Updater", "MiaSoft.Updater", "MiapaxERP.EskiSurumKoprusu"];
    private static readonly string[] Uzantilar = [".exe", ".dll", ".pdb", ".deps.json", ".runtimeconfig.json"];
    public static string[] EskiProgramDosyalari(string kurulum) => OncekiAdlar
        .SelectMany(ad => Uzantilar.Select(uzanti => Path.Combine(kurulum, ad + uzanti)))
        .Where(File.Exists).ToArray();

    public static string? Temizle(string kurulum, string yedekKoku)
    {
        kurulum = Path.GetFullPath(kurulum);
        if ((File.GetAttributes(kurulum) & FileAttributes.ReparsePoint) != 0)
            throw new IOException("Kurulum bağlantı klasörü olamaz.");
        string[] eskiAyarlar = new[] { "MiaSoft.guncelleme.json", "BoruERP.guncelleme.json" }
            .Select(n => Path.Combine(kurulum, n)).Where(File.Exists).ToArray();
        string[] dosyalar = EskiProgramDosyalari(kurulum).Concat(eskiAyarlar).ToArray();
        if (dosyalar.Length == 0) return null;
        if (dosyalar.Any(d => (File.GetAttributes(d) & FileAttributes.ReparsePoint) != 0))
            throw new IOException("Program dosyası bağlantı olamaz.");
        string yedek = Path.Combine(Path.GetFullPath(yedekKoku), "MarkaGecisi-" + Guid.NewGuid().ToString("N") + ".zip");
        if (yedek.StartsWith(kurulum.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            throw new IOException("Yedek program klasörünün dışında olmalı.");
        Directory.CreateDirectory(Path.GetDirectoryName(yedek)!);
        using (var zip = ZipFile.Open(yedek, ZipArchiveMode.Create))
            foreach (string dosya in dosyalar) zip.CreateEntryFromFile(dosya, Path.GetFileName(dosya));
        var silinen = new List<string>();
        string yeniAyar = Path.Combine(kurulum, "MiapaxERP.guncelleme.json");
        bool yeniAyarOlustu = false;
        try
        {
            if (!File.Exists(yeniAyar) && eskiAyarlar.Length > 0)
            {
                using var json = System.Text.Json.JsonDocument.Parse(File.ReadAllText(eskiAyarlar[0]));
                if (json.RootElement.ValueKind != System.Text.Json.JsonValueKind.Object) throw new IOException("Güncelleme ayarı geçersiz.");
                File.Copy(eskiAyarlar[0], yeniAyar, false); yeniAyarOlustu = true;
            }
            foreach (string dosya in dosyalar) { File.Delete(dosya); silinen.Add(dosya); }
        }
        catch
        {
            using var zip = ZipFile.OpenRead(yedek);
            foreach (string dosya in silinen) zip.GetEntry(Path.GetFileName(dosya))!.ExtractToFile(dosya, true);
            if (yeniAyarOlustu) File.Delete(yeniAyar);
            throw;
        }
        return yedek;
    }
}
