
namespace MiapaxERP.Guncelleme;

internal static class GuncellemeAnahtari
{
    // MiapaxERP otomatik güncelleme sisteminin açık anahtarı.
    // Güncelleme manifestlerinin RSA-PSS SHA-256 imzasını doğrular.
    // Özel anahtar yalnızca geliştiricinin bilgisayarında saklanır.

    public const string Pem = """
        -----BEGIN PUBLIC KEY-----
        MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAxJXw6nkTzeX1c8DV7Lv+
        xb/I5qyqD0FiYNT0IbvHdyQnLyknjnnFhnlZkuWxIczxpEmTpb/o/Infs5+ms63S
        cSgtGghXvEThUzs3umF6rkhjqixjg73W0q/LWsaenl4Y2pHQUUQQ6jFTGQ9JacLT
        SPlkfj+uXTXCG2QLGDDL5GeY3atwA5qCtbYWwMzOm1mhyqeoH12I8MjpQXlQCT+g
        DmiRux0uDwxsVFQ0H1xMb3yokZUJZUaZdtwiwQlrewlyjeWEd5hYAy6/mYq45Pf1
        NNewK99gGo3u9Scqmg2AOUtpo8GxXCk4nCseSVS65yMhVtokNVxBDqJ+jxm5Ifa/
        LbAtQFAKtQpbAiADwDPI2LJMl5xxP2UjlshQ8N0rBWf5Bb76m9rHydseM3q2yf4J
        RQc++jg1b7BdxHNmMgoRMFLTEgABNHZY2wr0UYT2oWVbb7oTZEyypC6i8VPAfrtR
        BUshO5a5g7XKuxdxKiHYmGYbzwpK3J9BTyLaRkyL0XipAgMBAAE=
        -----END PUBLIC KEY-----
        """;
}
