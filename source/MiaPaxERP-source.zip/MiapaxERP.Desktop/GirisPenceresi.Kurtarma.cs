using System;
using System.Collections.Generic;
using System.Data;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Data.SqlClient;

namespace MiapaxERP.Desktop
{
    public partial class GirisPenceresi
    {
        internal sealed class KurtarmaKodPaketi
        {
            public KurtarmaKodPaketi(){}
            public Guid GrupId { get; init; }
            public string[] Kodlar { get; init; } = Array.Empty<string>();
        }

        // Admin / 1234 varsayılanı yalnızca İLK kurulumda, sıfır kullanıcı ve kurulum
        // işareti bulunmadığında oluşur. Var olan hesaplar değişmez, silinmiş DB tekrar
        // otomatik olarak Admin/1234 üretemez.
        private bool IlkAdminHesabiniGerekirseOlustur()
        {
            using var baglanti = new SqlConnection(baglantiAdresi);
            baglanti.Open();
            using var islem = baglanti.BeginTransaction(IsolationLevel.Serializable);
            try
            {
                long kullaniciSayisi;
                using (var komut = new SqlCommand(
                    "SELECT COUNT_BIG(*) FROM dbo.Kullanicilar WITH (TABLOCKX, HOLDLOCK);", baglanti, islem))
                    kullaniciSayisi = Convert.ToInt64(komut.ExecuteScalar());

                long tamamlandi;
                using (var komut = new SqlCommand(
                    "SELECT COUNT_BIG(*) FROM dbo.BoruERP_IlkKurulum WITH (UPDLOCK, HOLDLOCK) WHERE Id=1;",
                    baglanti, islem))
                    tamamlandi = Convert.ToInt64(komut.ExecuteScalar());

                if (kullaniciSayisi != 0 || tamamlandi != 0)
                {
                    islem.Commit();
                    return false;
                }

                int rolId;
                using (var komut = new SqlCommand(
                    "SELECT TOP (1) Id FROM dbo.KullaniciRolleri WHERE RolAdi=N'Yönetici' AND Aktif=1;",
                    baglanti, islem))
                {
                    object? sonuc = komut.ExecuteScalar();
                    if (sonuc == null || sonuc == DBNull.Value)
                        throw new InvalidOperationException("Aktif Yönetici rolü bulunamadı.");
                    rolId = Convert.ToInt32(sonuc);
                }

                int adminId;
                using (var komut = new SqlCommand(@"
INSERT INTO dbo.Kullanicilar
    (KullaniciAdi, AdSoyad, SifreOzeti, Aktif, SifreDegistirmeli)
VALUES (N'Admin', N'İlk Yönetici', @SifreOzeti, 1, 1);
SELECT CAST(SCOPE_IDENTITY() AS INT);", baglanti, islem))
                {
                    komut.Parameters.Add("@SifreOzeti", SqlDbType.NVarChar, 512).Value = SifreOzetiOlustur("1234");
                    adminId = Convert.ToInt32(komut.ExecuteScalar());
                }
                using (var komut = new SqlCommand(@"
INSERT INTO dbo.KullaniciRolAtamalari (KullaniciId, RolId)
VALUES (@KullaniciId, @RolId);", baglanti, islem))
                {
                    komut.Parameters.Add("@KullaniciId", SqlDbType.Int).Value = adminId;
                    komut.Parameters.Add("@RolId", SqlDbType.Int).Value = rolId;
                    komut.ExecuteNonQuery();
                }
                using (var komut = new SqlCommand(
                    "INSERT INTO dbo.BoruERP_IlkKurulum (Id) VALUES (1);", baglanti, islem))
                    komut.ExecuteNonQuery();

                islem.Commit();
                return true;
            }
            catch
            {
                try { islem.Rollback(); } catch { }
                throw;
            }
        }

        // 128 bit rastgele kod -> 8 adet 4 haneli onaltılık grup. Kodlar SQL'e
        // açık metin olarak değil SHA-256 özetleriyle yazılır.
        private static string YeniKurtarmaKodu()
        {
            string ham = Convert.ToHexString(RandomNumberGenerator.GetBytes(16));
            var parcalar = new string[8];
            for (int i = 0; i < 8; i++) parcalar[i] = ham.Substring(i * 4, 4);
            return string.Join("-", parcalar);
        }

        private static byte[] KurtarmaKodOzeti(string kod)
        {
            string temiz = kod.Trim().Replace("-", "").Replace(" ", "").ToUpperInvariant();
            if (temiz.Length != 32) throw new FormatException("Geçersiz kurtarma kodu.");
            // FromHexString: yalnızca [0-9A-F] karakterlerini kabul eder.
            byte[] ham = Convert.FromHexString(temiz);
            return SHA256.HashData(ham);
        }

        // Bu metot çağrılmadan önce aynı SQL transaction içinde kullanıcı satırı
        // kilitlenmiş olmalıdır (INSERT, UPDATE veya UPDLOCK).
        private static KurtarmaKodPaketi KurtarmaKodlariniUret(
            SqlConnection baglanti, SqlTransaction islem, int kullaniciId)
        {
            using (var iptal = new SqlCommand(@"
UPDATE dbo.KullaniciKurtarmaKodlari
SET GecersizUtc=SYSUTCDATETIME()
WHERE KullaniciId=@Id AND GecersizUtc IS NULL AND KullanildiUtc IS NULL;", baglanti, islem))
            {
                iptal.Parameters.Add("@Id", SqlDbType.Int).Value = kullaniciId;
                iptal.ExecuteNonQuery();
            }

            Guid grupId = Guid.NewGuid();
            var kodlar = new string[8];
            for (int i = 0; i < kodlar.Length; i++)
            {
                string kod = YeniKurtarmaKodu();
                kodlar[i] = kod;
                using var komut = new SqlCommand(@"
INSERT INTO dbo.KullaniciKurtarmaKodlari
    (KullaniciId, GrupId, KodOzeti)
VALUES (@KullaniciId, @GrupId, @KodOzeti);", baglanti, islem);
                komut.Parameters.Add("@KullaniciId", SqlDbType.Int).Value = kullaniciId;
                komut.Parameters.Add("@GrupId", SqlDbType.UniqueIdentifier).Value = grupId;
                komut.Parameters.Add("@KodOzeti", SqlDbType.Binary, 32).Value = KurtarmaKodOzeti(kod);
                komut.ExecuteNonQuery();
            }

            using (var komut = new SqlCommand(@"
IF EXISTS (SELECT 1 FROM dbo.KurtarmaKoduTeslimDurumu WITH (UPDLOCK,HOLDLOCK)
           WHERE KullaniciId=@KullaniciId)
    UPDATE dbo.KurtarmaKoduTeslimDurumu
       SET GrupId=@GrupId, OnayUtc=NULL, OlusturulmaUtc=SYSUTCDATETIME()
     WHERE KullaniciId=@KullaniciId;
ELSE
    INSERT INTO dbo.KurtarmaKoduTeslimDurumu (KullaniciId, GrupId)
    VALUES (@KullaniciId,@GrupId);", baglanti, islem))
            {
                komut.Parameters.Add("@KullaniciId", SqlDbType.Int).Value = kullaniciId;
                komut.Parameters.Add("@GrupId", SqlDbType.UniqueIdentifier).Value = grupId;
                komut.ExecuteNonQuery();
            }
            return new KurtarmaKodPaketi { GrupId = grupId, Kodlar = kodlar };
        }

        // Şifresini doğrulamış ancak kodları olmayan / kod teslimini tamamlamamış
        // kullanıcılara, oturum açılmadan önce yeni kodlar verilir.
        internal static KurtarmaKodPaketi? GiristeKurtarmaKodlariniHazirla(int kullaniciId,string baglantiAdresi)
        {
            using var baglanti = new SqlConnection(baglantiAdresi);
            baglanti.Open();
            using var islem = baglanti.BeginTransaction(IsolationLevel.Serializable);
            try
            {
                using (var kilit = new SqlCommand(
                    "SELECT Id FROM dbo.Kullanicilar WITH (UPDLOCK, HOLDLOCK) WHERE Id=@Id AND Aktif=1;",
                    baglanti, islem))
                {
                    kilit.Parameters.Add("@Id", SqlDbType.Int).Value = kullaniciId;
                    if (kilit.ExecuteScalar() == null)
                        throw new InvalidOperationException("Aktif hesap bulunamadı.");
                }
                bool teslimEdildi = false;
                using (var komut = new SqlCommand(@"
SELECT TOP (1) OnayUtc FROM dbo.KurtarmaKoduTeslimDurumu
WHERE KullaniciId=@Id;", baglanti, islem))
                {
                    komut.Parameters.Add("@Id", SqlDbType.Int).Value = kullaniciId;
                    using var okuyucu = komut.ExecuteReader();
                    if (okuyucu.Read() && !okuyucu.IsDBNull(0))
                    {
                        // Okuyucu kapatılmadan transaction commit edilmeyecek.
                        // Aşağıdaki dış kontrol, using bloğundan sonra çalışır.
                        teslimEdildi = true;
                    }
                }
                if (teslimEdildi)
                {
                    islem.Commit();
                    return null;
                }
                KurtarmaKodPaketi paket = KurtarmaKodlariniUret(baglanti, islem, kullaniciId);
                islem.Commit();
                return paket;
            }
            catch
            {
                try { islem.Rollback(); } catch { }
                throw;
            }
        }

        internal static bool KurtarmaKodlariniTeslimOnayla(int kullaniciId, Guid grupId,string baglantiAdresi)
        {
            using var baglanti = new SqlConnection(baglantiAdresi);
            baglanti.Open();
            using var komut = new SqlCommand(@"
UPDATE dbo.KurtarmaKoduTeslimDurumu
SET OnayUtc=SYSUTCDATETIME()
WHERE KullaniciId=@Id AND GrupId=@GrupId AND OnayUtc IS NULL;", baglanti);
            komut.Parameters.Add("@Id", SqlDbType.Int).Value = kullaniciId;
            komut.Parameters.Add("@GrupId", SqlDbType.UniqueIdentifier).Value = grupId;
            return komut.ExecuteNonQuery() == 1;
        }

        private bool KurtarmaKodlariniGosterVeOnayla(int kullaniciId, KurtarmaKodPaketi paket)
        {
            // Eski şifre/oturum formunu gizle; ÖNEMLİ başlıklı ayrı pencereyi aç.
            Visibility girisOnce = GirisPaneli.Visibility;
            Visibility sifreOnce = SifreDegistirPaneli.Visibility;
            Visibility kayitOnce = KayitPaneli.Visibility;
            GirisPaneli.Visibility = Visibility.Collapsed;
            SifreDegistirPaneli.Visibility = Visibility.Collapsed;
            KayitPaneli.Visibility = Visibility.Collapsed;
            bool onaylandi;
            try
            {
                var pencere = new OnemliKurtarmaKodlariPenceresi(paket.Kodlar) { Owner = this };
                onaylandi = pencere.ShowDialog() == true;
            }
            finally
            {
                // Kullanıcı X'e basarsa önceki forma dönebilmek için görünümü koru.
                GirisPaneli.Visibility = girisOnce;
                SifreDegistirPaneli.Visibility = sifreOnce;
                KayitPaneli.Visibility = kayitOnce;
            }
            if (!onaylandi) return false;
            try
            {
                if (KurtarmaKodlariniTeslimOnayla(kullaniciId, paket.GrupId,baglantiAdresi)) return true;
                MessageBox.Show("Kurtarma kodu teslimi kaydedilemedi. Tekrar giriş yaptığınızda yeni kodlar oluşturulur.",
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            catch (Exception hata)
            {
                MessageBox.Show("Kod onayı kaydedilemedi: " + hata.Message +
                    "\nYeni şifreniz geçerlidir; tekrar giriş yaptığınızda kodlar yenilenir.",
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
        }

        private void SifremiUnuttum_Click(object sender, RoutedEventArgs e)
        {
            var pencere = new SifreKurtarmaPenceresi(baglantiAdresi) { Owner = this };
            if (pencere.ShowDialog() == true)
                TxtGirisDurum.Text = "Şifreniz değiştirildi. Yeni şifrenizle giriş yapabilirsiniz.";
        }

        internal static bool KurtarmaKoduIleSifreSifirla(
            string baglantiAdresi, string kullaniciAdi, string kod, string yeniSifre)
        {
            byte[] kodOzeti = KurtarmaKodOzeti(kod);
            string yeniOzet = SifreOzetiOlustur(yeniSifre);
            using var baglanti = new SqlConnection(baglantiAdresi);
            baglanti.Open();
            using var islem = baglanti.BeginTransaction(IsolationLevel.Serializable);
            try
            {
                int kullaniciId;
                // Kod hem güncel/teslim edilmiş olmalı hem de yalnız bir kez kullanılmalı.
                using (var komut = new SqlCommand(@"
UPDATE kk SET KullanildiUtc=SYSUTCDATETIME()
OUTPUT INSERTED.KullaniciId
FROM dbo.KullaniciKurtarmaKodlari AS kk
JOIN dbo.Kullanicilar AS k ON k.Id=kk.KullaniciId
JOIN dbo.KurtarmaKoduTeslimDurumu AS t
  ON t.KullaniciId=k.Id AND t.GrupId=kk.GrupId
WHERE k.KullaniciAdi=@Adi AND k.Aktif=1
  AND kk.KodOzeti=@Kod AND kk.KullanildiUtc IS NULL AND kk.GecersizUtc IS NULL
  AND t.OnayUtc IS NOT NULL;", baglanti, islem))
                {
                    komut.Parameters.Add("@Adi", SqlDbType.NVarChar, 60).Value = kullaniciAdi;
                    komut.Parameters.Add("@Kod", SqlDbType.Binary, 32).Value = kodOzeti;
                    object? sonuc = komut.ExecuteScalar();
                    if (sonuc == null || sonuc == DBNull.Value)
                    {
                        islem.Rollback();
                        return false;
                    }
                    kullaniciId = Convert.ToInt32(sonuc);
                }
                using (var komut = new SqlCommand(@"
UPDATE dbo.Kullanicilar
SET SifreOzeti=@YeniOzet, SifreDegistirmeli=0,
    BasarisizGirisSayisi=0, KilitBitisUtc=NULL, GuncellemeTarihiUtc=SYSUTCDATETIME()
WHERE Id=@Id AND Aktif=1;", baglanti, islem))
                {
                    komut.Parameters.Add("@YeniOzet", SqlDbType.NVarChar, 512).Value = yeniOzet;
                    komut.Parameters.Add("@Id", SqlDbType.Int).Value = kullaniciId;
                    if (komut.ExecuteNonQuery() != 1)
                        throw new InvalidOperationException("Hesap güncellenemedi.");
                }
                islem.Commit();
                return true;
            }
            catch
            {
                try { islem.Rollback(); } catch { }
                throw;
            }
        }
    }

    // Yeni ayrı pencere: başka XAML dosyası gerektirmez.
    public sealed class OnemliKurtarmaKodlariPenceresi : Window
    {
        public OnemliKurtarmaKodlariPenceresi(string[] kodlar)
        {
            Title = "ÖNEMLİ | MiapaxERP Kurtarma Kodları";
            Width = 690;
            Height = 660;
            MinWidth = 690;
            MinHeight = 660;
            ResizeMode = ResizeMode.NoResize;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            Background = new SolidColorBrush(Color.FromRgb(246, 248, 252));
            FontFamily = new FontFamily("Segoe UI");
            ShowInTaskbar = false;

            var panel = new StackPanel { Margin = new Thickness(28) };
            panel.Children.Add(new TextBlock
            {
                Text = "ÖNEMLİ — KURTARMA KODLARINIZ",
                FontSize = 24, FontWeight = FontWeights.Bold,
                Foreground = Brushes.DarkRed, Margin = new Thickness(0, 0, 0, 14)
            });
            panel.Children.Add(new TextBlock
            {
                Text = "Şifreniz başarıyla oluşturuldu. Aşağıdaki 8 kod yalnızca şimdi gösterilir. " +
                       "Şifrenizi unutursanız bu kodlardan BİRİNİ kullanabilirsiniz.",
                TextWrapping = TextWrapping.Wrap, FontSize = 15,
                Margin = new Thickness(0, 0, 0, 16)
            });
            var satirlar = new List<string>();
            for (int i = 0; i < kodlar.Length; i++)
                satirlar.Add($"{i + 1}.  {kodlar[i]}");
            string metin = string.Join(Environment.NewLine, satirlar);
            var kutu = new TextBox
            {
                Text = metin, IsReadOnly = true, Height = 270,
                FontFamily = new FontFamily("Consolas"), FontSize = 16,
                Padding = new Thickness(18),
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                TextWrapping = TextWrapping.NoWrap
            };
            panel.Children.Add(kutu);

            var kopyala = new Button
            {
                Content = "Kodların Tamamını Kopyala", Height = 39,
                Margin = new Thickness(0, 12, 0, 14)
            };
            kopyala.Click += (_, _) =>
            {
                try
                {
                    Clipboard.SetText(metin);
                    MessageBox.Show("Kodlar panoya kopyalandı. Çevrimdışı, güvenli bir yere kaydedin. " +
                                    "Ortak bilgisayarın panosunda bırakmayın.", "MiapaxERP");
                }
                catch (Exception hata)
                {
                    MessageBox.Show("Panoya kopyalanamadı: " + hata.Message, "MiapaxERP");
                }
            };
            panel.Children.Add(kopyala);
            panel.Children.Add(new TextBlock
            {
                Text = "• Kodları başkalarıyla paylaşmayın.\n" +
                       "• Her kod yalnızca 1 kez kullanılabilir.\n" +
                       "• Kodlar veritabanında düz metin saklanmaz. Bu pencereyi kapatınca tekrar gösterilemez.",
                TextWrapping = TextWrapping.Wrap, FontSize = 12,
                Foreground = new SolidColorBrush(Color.FromRgb(100, 116, 139)),
                Margin = new Thickness(0, 0, 0, 12)
            });
            var onay = new CheckBox
            {
                Content = "8 kurtarma kodunu güvenli bir yere kaydettim.",
                FontSize = 14, FontWeight = FontWeights.SemiBold,
                Margin = new Thickness(0, 0, 0, 14)
            };
            panel.Children.Add(onay);
            var devam = new Button
            {
                Content = "Kodları Kaydettim — MiapaxERP’a Devam Et",
                Height = 44, IsEnabled = false,
                Foreground = Brushes.White,
                Background = new SolidColorBrush(Color.FromRgb(37, 99, 235)),
                BorderThickness = new Thickness(0)
            };
            onay.Checked += (_, _) => devam.IsEnabled = true;
            onay.Unchecked += (_, _) => devam.IsEnabled = false;
            devam.Click += (_, _) => { DialogResult = true; };
            panel.Children.Add(devam);
            Content = new ScrollViewer
            {
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Content = panel
            };
        }
    }

    public sealed class SifreKurtarmaPenceresi : Window
    {
        private readonly string baglantiAdresi;
        private readonly TextBox kullanici = new TextBox { Height = 34, MaxLength = 60 };
        private readonly TextBox kod = new TextBox { Height = 34, MaxLength = 48 };
        private readonly PasswordBox yeni = new PasswordBox { Height = 34, MaxLength = 128 };
        private readonly PasswordBox tekrar = new PasswordBox { Height = 34, MaxLength = 128 };
        private readonly TextBlock durum = new TextBlock { Foreground = Brushes.DarkRed, TextWrapping = TextWrapping.Wrap };
        private readonly Button sifirla = new Button { Content = "Şifremi Sıfırla", Height = 43 };

        public SifreKurtarmaPenceresi(string sqlBaglantiAdresi)
        {
            baglantiAdresi = sqlBaglantiAdresi;
            Title = "MiapaxERP | Kurtarma Koduyla Şifre Sıfırla";
            Width = 550; Height = 520;
            ResizeMode = ResizeMode.NoResize;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            ShowInTaskbar = false;
            Background = Brushes.White;
            FontFamily = new FontFamily("Segoe UI");

            var p = new StackPanel { Margin = new Thickness(27) };
            p.Children.Add(new TextBlock { Text = "Şifremi Unuttum", FontSize = 25,
                FontWeight = FontWeights.Bold, Margin = new Thickness(0, 0, 0, 12) });
            p.Children.Add(new TextBlock { Text = "Önceden sakladığınız tek kullanımlık kurtarma kodunu girin.",
                TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 14) });
            AlanEkle(p, "Kullanıcı adı", kullanici);
            AlanEkle(p, "Kurtarma kodu", kod);
            AlanEkle(p, "Yeni şifre (en az 12 karakter)", yeni);
            AlanEkle(p, "Yeni şifre tekrar", tekrar);
            durum.Margin = new Thickness(0, 12, 0, 12);
            p.Children.Add(durum);
            sifirla.Click += Sifirla_Click;
            p.Children.Add(sifirla);
            Content = new ScrollViewer { Content = p, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        }

        private static void AlanEkle(Panel panel, string etiket, Control alan)
        {
            panel.Children.Add(new TextBlock { Text = etiket, Margin = new Thickness(0, 10, 0, 5) });
            panel.Children.Add(alan);
        }

        private async void Sifirla_Click(object sender, RoutedEventArgs e)
        {
            string ad = kullanici.Text.Trim();
            string kurtarmaKodu = kod.Text.Trim();
            string yeniSifre = yeni.Password;
            if (ad.Length == 0 || kurtarmaKodu.Length == 0 ||
                yeniSifre.Length < 12 || yeniSifre.Length > 128 || yeniSifre != tekrar.Password)
            {
                durum.Text = "Kullanıcı adı, kurtarma kodu ve eşleşen 12-128 karakterli yeni şifre girin.";
                return;
            }
            sifirla.IsEnabled = false;
            durum.Text = "Kurtarma kodu doğrulanıyor...";
            try
            {
                bool basarili = await Task.Run(() =>
                    GirisPenceresi.KurtarmaKoduIleSifreSifirla(baglantiAdresi, ad, kurtarmaKodu, yeniSifre));
                if (!basarili)
                {
                    durum.Text = "Bilgiler eşleşmedi veya kurtarma kodu kullanılmış/geçersiz. Lütfen kontrol edin.";
                    return;
                }
                MessageBox.Show("Şifreniz değiştirildi. Bu kurtarma kodu artık tekrar kullanılamaz.",
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Information);
                DialogResult = true;
            }
            catch (FormatException)
            {
                durum.Text = "Kurtarma kodu biçimi geçersiz.";
            }
            catch (Exception hata)
            {
                durum.Text = "Şifre kurtarma tamamlanamadı: " + hata.Message;
            }
            finally
            {
                yeniSifre = "";
                yeni.Clear(); tekrar.Clear(); kod.Clear();
                sifirla.IsEnabled = true;
            }
        }
    }
}

