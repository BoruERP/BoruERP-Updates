namespace MiapaxERP.Desktop;

public record TicaretKalem(string Kod,string Urun,decimal Adet,decimal Fiyat,decimal Indirim,decimal VergiOrani=0,string Birim="ADET")
{
    public decimal Net()
    {
        if(string.IsNullOrWhiteSpace(Urun) || Adet<=0 || Fiyat<0 || Indirim<0 || Indirim>100 || VergiOrani<0 || VergiOrani>100 || string.IsNullOrWhiteSpace(Birim))
            throw new ArgumentException("Kalemlerde ürün, pozitif miktar, geçerli birim fiyat ve %0–100 indirim gerekli.");
        return decimal.Round(Adet*Fiyat*(1-Indirim/100),2,MidpointRounding.AwayFromZero);
    }
    public decimal Vergi()=>decimal.Round(Net()*VergiOrani/100,2,MidpointRounding.AwayFromZero);
    public decimal Toplam()=>Net()+Vergi();
}
