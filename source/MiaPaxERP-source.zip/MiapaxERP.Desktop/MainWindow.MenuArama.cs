using System.Globalization;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
namespace MiapaxERP.Desktop;

public partial class MainWindow
{
    Button? sonMenuHedefi;
    sealed record MenuAramaKaydi(string Baslik,string Yol,Button Hedef);
    internal static string MenuAramaMetni(string text)
    {
        var s=new StringBuilder();foreach(char ch in text.Replace('ı','i').Replace('İ','I').Normalize(NormalizationForm.FormD))
            if(CharUnicodeInfo.GetUnicodeCategory(ch)!=UnicodeCategory.NonSpacingMark)s.Append(char.ToUpperInvariant(ch));
        return s.ToString();
    }
    void MenuAramaBagla()
    {
        foreach(var pair in new[]{("Sevkiyat ve kantar","Sevkiyat"),("Boru basınç testleri","BasincTest"),("Depo · raf · parti","Depo"),("Satın alma eşleştirme","SatinAlma"),("Genel muhasebe","Muhasebe"),("Satış tahsilatları","Tahsilat"),("Makine ve kapasite","Makine"),("MRP ve üretim maliyeti","UretimMaliyet")})
        {
            var module=new Button{Content=pair.Item1,Margin=new Thickness(0,4,0,4),Padding=new Thickness(10),HorizontalContentAlignment=System.Windows.HorizontalAlignment.Left};
            module.Click+=(_,_)=>{if(aktifKullanici is null){MessageBox.Show(this,"Önce oturum açın.","MiaPaxERP");return;}new IsletmePenceresi(this,MiapaxERPBaglantiAyarlari.BaglantiAdresi(),aktifKullanici.KullaniciId,pair.Item2).ShowDialog();};TemaMenuOgeleri.Children.Add(module);
        }
        if(TemaMarka.Parent is not DockPanel dock)return;
        var tools=new DockPanel{Margin=new Thickness(12,4,12,12)};
        var locate=new Button{Content="⌖",Width=40,MinHeight=36,Margin=new Thickness(6,0,0,0),ToolTip="Bulunduğunuz sekmenin menüdeki yerini göster"};DockPanel.SetDock(locate,Dock.Right);tools.Children.Add(locate);
        var find=new Button{Content="⌕  Menüde ara",MinHeight=36,ToolTip="Ekranları bul · Ctrl+K"};tools.Children.Add(find);DockPanel.SetDock(tools,Dock.Top);dock.Children.Insert(Math.Min(1,dock.Children.Count),tools);
        find.Click+=(_,_)=>MenuAramaAc();locate.Click+=(_,_)=>{if(sonMenuHedefi is not null)MenuKonumuGoster(sonMenuHedefi);else MenuAramaAc();};
        TemaMenuOgeleri.AddHandler(Button.ClickEvent,new RoutedEventHandler((_,e)=>{if(e.OriginalSource is DependencyObject source){for(var p=source;p is not null;p=System.Windows.Media.VisualTreeHelper.GetParent(p))if(p is Button b){sonMenuHedefi=b;break;}}}),true);
        CommandBindings.Add(new CommandBinding(ApplicationCommands.Find,(_,_)=>MenuAramaAc()));InputBindings.Add(new KeyBinding(ApplicationCommands.Find,new KeyGesture(Key.K,ModifierKeys.Control)));
    }
    IEnumerable<MenuAramaKaydi> MenuKayitlari()
    {
        foreach(var b in TemaMenuOgeleri.Children.OfType<Button>())
        {
            if(b.Visibility!=Visibility.Visible||!b.IsEnabled||b.Content is not string title)continue;
            string name=title.Trim();if(name.Length==0)continue;yield return new(name,"Ana menü → "+name,b);
        }
    }
    void MenuKonumuGoster(Button target)
    {
        target.BringIntoView();target.Focus();
        var tip=new System.Windows.Controls.ToolTip{Content="← "+target.Content+"\nBu sekmenin menüdeki yeri",PlacementTarget=target,Placement=System.Windows.Controls.Primitives.PlacementMode.Right,StaysOpen=true,IsOpen=true};
        var timer=new System.Windows.Threading.DispatcherTimer{Interval=TimeSpan.FromSeconds(4)};timer.Tick+=(_,_)=>{tip.IsOpen=false;timer.Stop();};timer.Start();
    }
    void MenuAramaAc()
    {
        var window=new Window{Owner=this,Title="MiaPaxERP · Menüde ara",Width=740,Height=620,MinWidth=480,MinHeight=400,WindowStartupLocation=WindowStartupLocation.CenterOwner};
        var root=new DockPanel{Margin=new Thickness(22)};window.Content=root;
        var top=new StackPanel();DockPanel.SetDock(top,Dock.Top);root.Children.Add(top);top.Children.Add(new TextBlock{Text="Hangi ekranı arıyorsunuz?",FontSize=23,FontWeight=FontWeights.SemiBold});
        var search=new TextBox{MinHeight=40,Padding=new Thickness(10),Margin=new Thickness(0,14,0,10),ToolTip="Ekran veya işlem adı yazın; Türkçe karakter kullanmadan da arayabilirsiniz."};top.Children.Add(search);
        top.Children.Add(new TextBlock{Text="Aç ile ekrana gidin. ⌖ ile ekrana girmeden menüdeki yerini görün.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,0,0,12)});
        var list=new System.Windows.Controls.ListBox{BorderThickness=new Thickness(0),HorizontalContentAlignment=System.Windows.HorizontalAlignment.Stretch};root.Children.Add(list);var entries=MenuKayitlari().ToArray();
        void Filter()
        {
            list.Items.Clear();var tokens=MenuAramaMetni(search.Text).Split(' ',StringSplitOptions.RemoveEmptyEntries|StringSplitOptions.TrimEntries);
            foreach(var item in entries.Where(x=>tokens.All(t=>MenuAramaMetni(x.Baslik+" "+MenuAramaEsAnlamlari(x.Baslik)).Contains(t))))
            {
                var row=new DockPanel{Margin=new Thickness(0,4,0,6)};
                var position=new Button{Content="⌖",Width=38,Margin=new Thickness(6,0,0,0),ToolTip="Menüdeki yerini göster"};DockPanel.SetDock(position,Dock.Right);row.Children.Add(position);
                var open=new Button{Content="Aç",Padding=new Thickness(14,6,14,6)};DockPanel.SetDock(open,Dock.Right);row.Children.Add(open);
                var text=new StackPanel{Margin=new Thickness(4,5,8,5)};text.Children.Add(new TextBlock{Text=item.Baslik,FontSize=16,FontWeight=FontWeights.SemiBold});text.Children.Add(new TextBlock{Text=item.Yol,FontSize=11,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,4,0,0)});row.Children.Add(text);
                open.Click+=(_,_)=>{window.Close();sonMenuHedefi=item.Hedef;item.Hedef.RaiseEvent(new RoutedEventArgs(Button.ClickEvent,item.Hedef));};
                position.Click+=(_,_)=>{window.Close();MenuKonumuGoster(item.Hedef);};list.Items.Add(row);
            }
            if(list.Items.Count==0)list.Items.Add(new TextBlock{Text="Eşleşen ekran bulunamadı. Daha kısa bir adla arayın.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(8)});
        }
        search.TextChanged+=(_,_)=>Filter();window.Loaded+=(_,_)=>search.Focus();Filter();window.ShowDialog();
    }
    static string MenuAramaEsAnlamlari(string title)
    {
        string name=MenuAramaMetni(title);var words=new List<string>();
        if(name.Contains("STOK"))words.Add("depo raf envanter malzeme ürün");
        if(name.Contains("FINANS")||name.Contains("MUHASEBE"))words.Add("kasa banka tahsilat ödeme mizan yevmiye maliyet döviz kur");
        if(name.Contains("E-BELGE"))words.Add("e fatura efatura e arşiv irsaliye entegrasyon");
        if(name.Contains("LABORATUVAR"))words.Add("kalibre kalibrasyon kalite numune test pdf");
        if(name.Contains("URETIM"))words.Add("makine kapasite planlama malzeme mrp reçete");
        if(name.Contains("SEVKIYAT"))words.Add("nakliye araç plaka şöför şoför taşıma kantar");
        if(name.Contains("BASINC"))words.Add("boru pn deney test video resim fotoğraf");
        return string.Join(' ',words);
    }
}

