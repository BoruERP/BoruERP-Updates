using System.Data;
using System.Text.Json;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed partial class TicaretDosyalari
{
    public static void Dogrula(TicaretGirdi g)
    {
        foreach(var (s,max) in new[]{(g.Referans,80),(g.Firma,160),(g.Baslik,180),(g.Sorumlu,100),(g.Aciklama,2000)})
            if(s is null || s.Length>max)throw new ArgumentException($"Alan uzunluğu en fazla {max} karakter olmalı.");
        if(g.Detay is null || g.Detay.Count>60 || g.Detay.Any(p=>p.Key.Length>100 || p.Value is null || p.Value.Length>200000))throw new ArgumentException("Detay boyutu geçersiz.");
        if(g.Detay.TryGetValue("Kalemler",out string? json))
        {
            var items=JsonSerializer.Deserialize<TicaretKalem[]>(json)??[];
            if(items.Length is 0 or >500 || items.Sum(k=>k.Toplam())!=g.Tutar)throw new ArgumentException("Kalem toplamı ile belge tutarı uyuşmuyor.");
        }
    }
    public static void GecisDogrula(string module,string next,Dictionary<string,string> d)
    {
        void Gerekli(params string[] fields){foreach(var f in fields)if(string.IsNullOrWhiteSpace(d.GetValueOrDefault(f)))throw new ArgumentException(next+" için gerekli: "+f);}
        if(next=="Faturalandı")Gerekli("Fatura numarası");
        if(module=="SALES" && next=="Sevk edildi")Gerekli("Teslimat adresi","İrsaliye no");
        if(module=="PURCHASE" && next=="Mal kabul")Gerekli("Mal kabul belgesi");
        if(module=="ECOM" && next=="Kargoda")Gerekli("Kargo firması","Takip numarası","Teslimat adresi");
        if(module=="TRADE" && next=="Belgeler hazır")Gerekli("Menşe ülkesi","Varış ülkesi","GTİP","Teslim şekli","Proforma / fatura");
        if(module=="TRADE" && next=="Gümrük")Gerekli("Beyanname no");
    }
    static decimal NetOdeme(SqlConnection c,SqlTransaction tx,long id)
    {
        using var q=ErpModulServisi.Komut(c,tx,"SELECT COALESCE(SUM(CASE WHEN Tur=N'İade' THEN -Tutar ELSE Tutar END),0) FROM dbo.BERP_TicaretOdeme WHERE DosyaId=@id",("@id",id));return Convert.ToDecimal(q.ExecuteScalar());
    }
    public DataTable Odemeler(long id){if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<DataTable>(connection,"TicaretDosyalari.Odemeler",modul,new object?[]{id});}return Oku("SELECT p.Id,p.Tarih,p.Tur,p.Tutar,d.Doviz,p.Yontem,p.Belge,p.Aciklama FROM dbo.BERP_TicaretOdeme p JOIN dbo.BERP_TicaretDosya d ON d.Id=p.DosyaId WHERE d.Modul=@m AND d.Id=@id ORDER BY p.Id DESC",id);}
    public void Odeme(Guid key,long id,DateTime date,decimal amount,string type,string method,string document,string note)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"TicaretDosyalari.Odeme",modul,new object?[]{key,id,date,amount,type,method,document,note});return;}

        if(amount<=0 || decimal.Round(amount,2)!=amount || type is not ("Ödeme" or "İade") || string.IsNullOrWhiteSpace(method) || method.Length>40 || string.IsNullOrWhiteSpace(document) || document.Length>120 || note.Length>320)throw new ArgumentException("Pozitif iki ondalıklı tutar, yöntem ve belge numarası gerekli.");
        using var c=access.Ac();using var tx=c.BeginTransaction(IsolationLevel.Serializable);access.Yetki(c,tx,modul+".PAYMENT");
        using(var exists=ErpModulServisi.Komut(c,tx,"SELECT COUNT(*) FROM dbo.BERP_TicaretOdeme WHERE Anahtar=@k AND DosyaId=@id",("@k",key),("@id",id)))if(Convert.ToInt32(exists.ExecuteScalar())>0){tx.Commit();return;}
        decimal total;string state;
        using(var q=ErpModulServisi.Komut(c,tx,"SELECT Tutar,Durum FROM dbo.BERP_TicaretDosya WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Modul=@m",("@id",id),("@m",modul)))
        {using var rd=q.ExecuteReader();if(!rd.Read())throw new ArgumentException("Dosya bulunamadı.");total=rd.GetDecimal(0);state=rd.GetString(1);}
        if(state==Akis.Sonuc)throw new ArgumentException("İptal/iade edilmiş dosyaya ödeme eklenemez.");
        if(state==Akis.Adimlar[^1] && !(modul=="ECOM" && type=="İade"))throw new ArgumentException("Kapalı dosyaya ödeme eklenemez.");
        decimal net=NetOdeme(c,tx,id);if(type=="İade"?amount>net:net+amount>total)throw new ArgumentException("Ödeme belge tutarını, iade net ödemeyi aşamaz.");
        using(var q=ErpModulServisi.Komut(c,tx,"INSERT dbo.BERP_TicaretOdeme(Anahtar,DosyaId,Tarih,Tutar,Tur,Yontem,Belge,Aciklama,KullaniciId) VALUES(@k,@id,@t,@a,@type,@method,@doc,@note,@u)",("@k",key),("@id",id),("@t",date.Date),("@a",amount),("@type",type),("@method",method),("@doc",document),("@note",note),("@u",user)))q.ExecuteNonQuery();
        Olay(c,tx,id,$"{type}: {amount:0.00} / {document}");tx.Commit();
    }
}
