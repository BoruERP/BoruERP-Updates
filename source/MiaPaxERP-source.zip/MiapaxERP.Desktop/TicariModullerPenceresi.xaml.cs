using SqlConnection = MiapaxERP.Desktop.ErpSqlConnection;
using SqlCommand = MiapaxERP.Desktop.ErpSqlCommand;
using SqlTransaction = MiapaxERP.Desktop.ErpSqlTransaction;
using SqlDataReader = MiapaxERP.Desktop.ErpSqlReader;
using SqlDataAdapter = MiapaxERP.Desktop.ErpSqlDataAdapter;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Data.SqlClient;
using Microsoft.Win32;

namespace MiapaxERP.Desktop
{
    /// <summary>
    /// Test v0.6: cari, finans, cek-senet, rapor, gorunum ve firma ayarlari.
    /// SQL Server Windows Authentication: istemci kontrolleri sunucu tarafli guvenlik yerine gecmez.
    /// </summary>
    public partial class TicariModullerPaneli : UserControl
    {
        private bool panelHazir;
        private int istenenBolum;
        private readonly string baglantiAdresi;
        private readonly int kullaniciId;
        private readonly string kullaniciAdi;
        private int? duzenlenenCariId;
        private DataTable? sonRapor;

        private static readonly CultureInfo tr = CultureInfo.GetCultureInfo("tr-TR");

        public TicariModullerPaneli(string connectionString, int userId, string userName, int tabIndex)
        {
            baglantiAdresi = connectionString;
            kullaniciId = userId;
            kullaniciAdi = userName;
            InitializeComponent();
            istenenBolum = tabIndex;
            MuhasebeGorunum.SekmeBasliklariniGizle(Sekmeler);
            MuhasebeGorunum.SekmeBasliklariniGizle(FinansSekmeleri);
            CmbCariTur.SelectedIndex = 0;
            CmbCariHareketTur.SelectedIndex = 0;
            CmbFinHesapTur.SelectedIndex = 0;
            CmbFinHesapBirim.SelectedIndex = 0;
            CmbFinHareketTur.SelectedIndex = 0;
            CmbBelgeTipi.SelectedIndex = 0;
            CmbBelgeKdv.SelectedIndex = 3;
            DpBelgeTarih.SelectedDate = DateTime.Today;
            CmbPlanliBirim.SelectedIndex = 0;
            CmbPlanliYeniDurum.SelectedIndex = 0;
            DpPlanliVade.SelectedDate = DateTime.Today;
            CmbEvrakTur.SelectedIndex = 0;
            CmbEvrakYon.SelectedIndex = 0;
            CmbEvrakBirim.SelectedIndex = 0;
            CmbEvrakYeniDurum.SelectedIndex = 0;
            CmbTema.SelectedIndex = 0;
            CmbVurgu.SelectedIndex = 0;
            DpCariHareketTarih.SelectedDate = DateTime.Today;
            DpFinHareketTarih.SelectedDate = DateTime.Today;
            DpEvrakVade.SelectedDate = DateTime.Today;
            DpRaporBaslangic.SelectedDate = DateTime.Today.AddMonths(-1);
            DpRaporBitis.SelectedDate = DateTime.Today;
            foreach (var ad in new[] { "Cari Bakiyeleri", "Cari Hareketleri", "Kasa / Banka Bakiyeleri", "Kasa / Banka Hareketleri", "Alış / Satış Belgeleri", "Planlı Ödemeler", "Çek / Senet", "Stok Bakiyeleri", "Üretim Emirleri" })
                CmbRaporTur.Items.Add(ad);
            CmbRaporTur.SelectedIndex = 0;
            TxtYetkiBilgi.Text = "Aktif kullanıcı: " + kullaniciAdi;
            Loaded += (_, _) =>
            {
                if (panelHazir) return;
                try
                {
                    using var con = Baglan();
                    if (!TablolarHazir(con))
                    {
                        MessageBox.Show("Önce MiapaxERP_TicariModuller_Kurulum.sql dosyasını SSMS'de çalıştırın.",
                            "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Warning);
                        IsEnabled = false;
                        return;
                    }
                    AyarlariYukle();
                    Sekmeler.SelectedIndex = istenenBolum;
                    BolumuYukle(istenenBolum);
                    panelHazir = true;
                }
                catch (Exception ex) { Hata(ex); IsEnabled = false; }
            };
        }

        private SqlConnection Baglan()
        {
            var con = new SqlConnection(baglantiAdresi);
            con.Open();
            return con;
        }
        private static bool TablolarHazir(SqlConnection con)
        {
            using var cmd = new SqlCommand(@"SELECT CASE WHEN OBJECT_ID(N'dbo.CariKartlari',N'U') IS NOT NULL AND
                 OBJECT_ID(N'dbo.CariHareketleri',N'U') IS NOT NULL AND OBJECT_ID(N'dbo.FinansHesaplari',N'U') IS NOT NULL AND
                 OBJECT_ID(N'dbo.FinansHareketleri',N'U') IS NOT NULL AND OBJECT_ID(N'dbo.CekSenetler',N'U') IS NOT NULL AND
                 OBJECT_ID(N'dbo.TicariBelgeler',N'U') IS NOT NULL AND OBJECT_ID(N'dbo.PlanliOdemeler',N'U') IS NOT NULL AND
                 OBJECT_ID(N'dbo.CekSenetDurumGecmisi',N'U') IS NOT NULL AND
                 OBJECT_ID(N'dbo.KullaniciGorunumAyarlari',N'U') IS NOT NULL AND OBJECT_ID(N'dbo.FirmaBilgileri',N'U') IS NOT NULL
                 THEN 1 ELSE 0 END;", con);
            return Convert.ToInt32(cmd.ExecuteScalar()) == 1;
        }
        private bool Yetki(string kod)
        {
            try { using var con = Baglan(); return SqlYetki(con, null, kod); }
            catch { return false; }
        }
        private bool Gerekli(string kod)
        {
            if (Yetki(kod)) return true;
            MessageBox.Show("İşlem yetkiniz bulunmuyor: " + kod, "MiapaxERP | Yetki", MessageBoxButton.OK, MessageBoxImage.Warning);
            return false;
        }
        private bool SqlYetki(SqlConnection con, SqlTransaction? tran, string kod)
        {
            LisansOturumu.YetkiGerekli(kod);
            using var cmd = new SqlCommand(@"SELECT CASE WHEN EXISTS(
SELECT 1 FROM dbo.vw_KullaniciEtkinYetkileri WHERE KullaniciId=@k AND YetkiKodu=@y AND Yetkili=1)
AND EXISTS(SELECT 1 FROM dbo.Kullanicilar WHERE Id=@k AND Aktif=1)
THEN 1 ELSE 0 END;", con, tran);
            cmd.Parameters.Add("@k", SqlDbType.Int).Value = kullaniciId;
            cmd.Parameters.Add("@y", SqlDbType.NVarChar, 80).Value = kod;
            return Convert.ToInt32(cmd.ExecuteScalar()) == 1;
        }
        private void Zorunlu(SqlConnection con, SqlTransaction tran, string kod)
        {
            if (!SqlYetki(con, tran, kod)) throw new UnauthorizedAccessException("Bu işlem için yetki yok: " + kod);
        }
        private static SqlCommand Cmd(SqlConnection con, SqlTransaction? tran, string sql, params (string key, object value)[] args)
        {
            var c = new SqlCommand(sql, con, tran) { CommandTimeout = 20 };
            foreach (var (key, value) in args) c.Parameters.AddWithValue(key, value ?? DBNull.Value);
            return c;
        }
        private DataTable Oku(string sql, params (string key, object value)[] args)
        {
            using var con = Baglan(); using var cmd = Cmd(con, null, sql, args); using var reader = cmd.ExecuteReader();
            var table = new DataTable(); table.Load(reader); return table;
        }
        private static string Metin(TextBox t) => t.Text.Trim();
        private static string Sec(ComboBox c) => (c.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "";
        private static object Id(ComboBox c) => c.SelectedValue is int id ? id : DBNull.Value;
        private static int SeciliId(ComboBox c) => c.SelectedValue is int id ? id : throw new InvalidOperationException("Lütfen listeden bir kayıt seçin.");
        private static decimal Para(TextBox t)
        {
            // Binlik ayiraci KABUL ETME: 1.234 nokta/virgul farkindan yanlis tutar okunabilir.
            // 1234,56 veya 1234.56 kullanilabilir; 1.234,56 gibi karisik ayirac REDDEDILIR.
            string input = t.Text.Trim();
            if (input.Contains(' ') || (input.Contains(',') && input.Contains('.')) ||
                input.Count(ch => ch == '.' || ch == ',') > 1)
                throw new ArgumentException("Binlik ayıracı kullanmayın. Örnek: 1234,56");
            string normalized = input.Replace(',', '.');
            int nokta = normalized.IndexOf('.');
            if (nokta >= 0 && normalized.Length - nokta - 1 > 2)
                throw new ArgumentException("Tutar alanında en fazla iki ondalık hane kullanılabilir. 1000 veya 1000,50 yazın; 1.000 yazmayın.");
            bool ok = decimal.TryParse(normalized, NumberStyles.AllowDecimalPoint,
                CultureInfo.InvariantCulture, out decimal value);
            if (!ok || value <= 0 || value > 9999999999999999m || decimal.Round(value, 2) != value)
                throw new ArgumentException("Tutar sıfırdan büyük ve en fazla iki ondalıklı olmalı. Örnek: 1250,50");
            return value;
        }
        private static DateTime Tarih(DatePicker dp) => dp.SelectedDate?.Date ?? throw new ArgumentException("Tarih seçin.");
        private static void ComboYukle(ComboBox cmb, DataTable data, string text, bool bos = false)
        {
            var onceki = cmb.SelectedValue;
            var view = data.DefaultView;
            if (bos)
            {
                var copy = new DataTable();
                copy.Columns.Add("Id", typeof(int));
                copy.Columns.Add(text, typeof(string));
                copy.Rows.Add(DBNull.Value, "(Cari seçme)");
                foreach (DataRow original in data.Rows)
                    copy.Rows.Add(original["Id"], original[text]);
                view = copy.DefaultView;
            }
            cmb.ItemsSource = view;
            cmb.DisplayMemberPath = text; cmb.SelectedValuePath = "Id";
            cmb.SelectedIndex = data.Rows.Count > 0 || bos ? 0 : -1;
            if (onceki is int id && view.Cast<DataRowView>().Any(r => r["Id"] is int v && v == id)) cmb.SelectedValue = id;
        }
        private void Durum(string message) => TxtGenelDurum.Text = message;
        private void Hata(Exception ex)
        {
            Durum("Hata: " + ex.Message);
            MessageBox.Show(ex.Message, "MiapaxERP | İşlem tamamlanamadı", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        private void Calistir(Action work)
        {
            try { work(); }
            catch (Exception ex) { Hata(ex); }
        }
        private static bool Onay(string text) => MessageBox.Show(text, "MiapaxERP | Onay", MessageBoxButton.YesNo,
                                                      MessageBoxImage.Question) == MessageBoxResult.Yes;
        private void Sekmeler_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (!IsLoaded || !ReferenceEquals(e.Source, Sekmeler)) return;
            Calistir(() => { BolumuYukle(Sekmeler.SelectedIndex); TemaUygula(); });
        }
        private void BolumuYukle(int index)
        {
            string permission = index switch { 0 => "CUSTOMER.VIEW", 1 => "FINANCE.VIEW", 2 => "REPORT.VIEW", _ => "SETTINGS.VIEW" };
            bool hasAccess = index == 1 ?
                (Yetki("FINANCE.VIEW") || Yetki("CHECKNOTE.VIEW")) : Yetki(permission);
            if (!hasAccess)
            {
                Durum("Bu sekmeyi görüntüleme yetkiniz yok: " + permission);
                if (index == 0) { GridCariler.ItemsSource = null; GridCariHareketler.ItemsSource = null; }
                else if (index == 1) { GridFinHesaplar.ItemsSource = null; GridFinHareketler.ItemsSource = null; GridBelgeler.ItemsSource = null; GridPlanliOdemeler.ItemsSource = null; GridEvraklar.ItemsSource = null; }
                else if (index == 2) GridRapor.ItemsSource = null;
                else { /* Firma bilgileri artık bağımsız ekrandadır. */ }
                return;
            }
            if (index == 0) CarileriYukle();
            if (index == 1) FinansYukle();
            if (index == 2) RaporGetir();
            if (index == 3) AyarlariYukle();
        }

        // ---------------- CARILER ----------------
        private void CarileriYukle()
        {
            if (!Gerekli("CUSTOMER.VIEW")) return;
            GridCariler.ItemsSource = Oku(@"SELECT c.Id,c.CariKodu,c.Unvan,c.CariTipi,c.Telefon,c.VergiNo,c.VergiDairesi,c.Adres,c.Aktif,
    CAST(ISNULL(SUM(CASE h.HareketTipi WHEN N'Borç' THEN h.Tutar ELSE -h.Tutar END),0) AS decimal(18,2)) AS BakiyeTRY
FROM dbo.CariKartlari c LEFT JOIN dbo.CariHareketleri h ON h.CariId=c.Id
GROUP BY c.Id,c.CariKodu,c.Unvan,c.CariTipi,c.Telefon,c.VergiNo,c.VergiDairesi,c.Adres,c.Aktif ORDER BY c.Unvan;").DefaultView;
            GridCariHareketler.ItemsSource = Oku(@"SELECT TOP(250) h.Id,h.Tarih,c.CariKodu,c.Unvan,h.HareketTipi,h.Tutar,h.Aciklama,h.Kaynak,h.TersKayitId
FROM dbo.CariHareketleri h JOIN dbo.CariKartlari c ON c.Id=h.CariId ORDER BY h.Id DESC;").DefaultView;
            var cariler = Oku("SELECT Id,CariKodu + N' - ' + Unvan AS Baslik FROM dbo.CariKartlari WHERE Aktif=1 ORDER BY Unvan;");
            ComboYukle(CmbCariHareketCari, cariler, "Baslik");
            ComboYukle(CmbBelgeCari, cariler, "Baslik");
            ComboYukle(CmbFinHareketCari, cariler, "Baslik", true);
            ComboYukle(CmbEvrakCari, cariler, "Baslik", true);
            Durum("Cari kayıtları yüklendi.");
        }
        private void CariKaydet_Click(object s, RoutedEventArgs e) => Calistir(() =>
        {
            if (!Gerekli("CUSTOMER.EDIT")) return;
            string kod = Metin(TxtCariKod), ad = Metin(TxtCariUnvan), tip = Sec(CmbCariTur);
            if (kod.Length < 2 || ad.Length < 2 || kod.Length > 40 || ad.Length > 200)
                throw new ArgumentException("Cari kodu ve unvanı en az 2 karakter olmalı; alan uzunluklarını kontrol edin.");
            string vergiNo = Metin(TxtCariVergi), vergiDairesi = Metin(TxtCariVergiDairesi);
            string adres = Metin(TxtCariAdres);
            if (vergiNo.Length > 20 || vergiDairesi.Length > 100 || adres.Length > 400)
                throw new ArgumentException("Vergi numarası (20), vergi dairesi (100) veya adres (400) karakter sınırını aşıyor.");
            {new EskiTicariServisi(baglantiAdresi,kullaniciId).CariKaydet(duzenlenenCariId,kod,ad,tip,Metin(TxtCariTelefon),vergiNo,vergiDairesi,adres);} duzenlenenCariId = null; CariTemizle(); CarileriYukle(); Durum("Cari kartı kaydedildi.");
        });
        private void CariDuzenle_Click(object s, RoutedEventArgs e) => Calistir(() =>
        {
            if (!Gerekli("CUSTOMER.EDIT")) return;
            if (GridCariler.SelectedItem is not DataRowView r) throw new ArgumentException("Önce cari seçin.");
            duzenlenenCariId = Convert.ToInt32(r["Id"]);
            TxtCariKod.Text = Convert.ToString(r["CariKodu"]);
            TxtCariUnvan.Text = Convert.ToString(r["Unvan"]);
            TxtCariTelefon.Text = Convert.ToString(r["Telefon"]);
            TxtCariVergi.Text = Convert.ToString(r["VergiNo"]);
            TxtCariVergiDairesi.Text = Convert.ToString(r["VergiDairesi"]);
            TxtCariAdres.Text = Convert.ToString(r["Adres"]);
            for (int i=0;i<CmbCariTur.Items.Count;i++)
                if ((CmbCariTur.Items[i] as ComboBoxItem)?.Content?.ToString() == Convert.ToString(r["CariTipi"])) CmbCariTur.SelectedIndex = i;
            Durum("Cari kartı düzenleniyor. Kayıt için 'Cari Kartı Kaydet' butonuna basın.");
        });
        private void CariTemizle()
        {
            duzenlenenCariId = null; TxtCariKod.Clear(); TxtCariUnvan.Clear(); TxtCariTelefon.Clear();
            TxtCariVergi.Clear(); TxtCariVergiDairesi.Clear(); TxtCariAdres.Clear(); CmbCariTur.SelectedIndex = 0;
        }
        private void CariFormTemizle_Click(object s, RoutedEventArgs e) => CariTemizle();
        private void CariYenile_Click(object s, RoutedEventArgs e) => Calistir(CarileriYukle);
        private void CariDurum_Click(object s, RoutedEventArgs e) => Calistir(() =>
        {
            if (!Gerekli("CUSTOMER.EDIT")) return;
            if (GridCariler.SelectedItem is not DataRowView r) throw new ArgumentException("Önce cari seçin.");
            int id = Convert.ToInt32(r["Id"]); bool aktif = Convert.ToBoolean(r["Aktif"]);
            if (!Onay(aktif ? "Cariyi pasife al? Geçmiş hareketler korunur." : "Cariyi tekrar aktifleştir?")) return;
            {new EskiTicariServisi(baglantiAdresi,kullaniciId).CariDurum(id,aktif);} CarileriYukle(); Durum("Cari durumu güncellendi.");
        });
        private void CariHareketKaydet_Click(object s, RoutedEventArgs e) => Calistir(() =>
        {
            if (!Gerekli("CUSTOMER.EDIT")) return;
            int cari=SeciliId(CmbCariHareketCari); decimal tutar=Para(TxtCariHareketTutar);
            string aciklama=Metin(TxtCariHareketAciklama), tip=Sec(CmbCariHareketTur);
            DateTime date=Tarih(DpCariHareketTarih);
            if (aciklama.Length<3 || aciklama.Length>400) throw new ArgumentException("En az 3 karakter açıklama girin.");
            if (!Onay($"{tip} • {tutar:N2} TRY • Cari hareketi kaydedilsin mi?")) return;
            {new EskiTicariServisi(baglantiAdresi,kullaniciId).CariHareketKaydet(cari,tutar,aciklama,tip,date);} TxtCariHareketTutar.Clear(); TxtCariHareketAciklama.Clear(); CarileriYukle(); Durum("Cari hareketi kaydedildi.");
        });
        private void CariHareketTers_Click(object s, RoutedEventArgs e) => Calistir(() =>
        {
            if (!Gerekli("CUSTOMER.EDIT")) return;
            if (GridCariHareketler.SelectedItem is not DataRowView r) throw new ArgumentException("Önce bir cari hareketi seçin.");
            long id=Convert.ToInt64(r["Id"]);
            if (!Onay("Bu cari hareketi ters kayıt ile düzeltmek istiyor musunuz? Eski kayıt silinmez.")) return;
            {new EskiTicariServisi(baglantiAdresi,kullaniciId).CariHareketTers(id);} CarileriYukle(); Durum("Cari hareketi ters kaydedildi.");
        });

        // ---------------- FINANS / CEK SENET ----------------
        private void FinansYukle()
        {
            bool financeAllowed = Yetki("FINANCE.VIEW");
            bool checkAllowed = Yetki("CHECKNOTE.VIEW");
            if (!financeAllowed && !checkAllowed) return;
            if (financeAllowed)
            {
            GridFinHesaplar.ItemsSource = Oku(@"SELECT h.Id,h.HesapKodu,h.HesapAdi,h.HesapTipi,h.ParaBirimi,h.Aktif,
CAST(ISNULL(SUM(CASE f.HareketTipi WHEN N'Giriş' THEN f.Tutar ELSE -f.Tutar END),0) AS decimal(18,2)) AS Bakiye
FROM dbo.FinansHesaplari h LEFT JOIN dbo.FinansHareketleri f ON f.HesapId=h.Id
GROUP BY h.Id,h.HesapKodu,h.HesapAdi,h.HesapTipi,h.ParaBirimi,h.Aktif ORDER BY h.HesapAdi;").DefaultView;
            GridFinHareketler.ItemsSource = Oku(@"SELECT TOP(250) f.Id,f.Tarih,h.HesapAdi,h.ParaBirimi,f.HareketTipi,f.Tutar,
c.Unvan AS Cari,f.Aciklama,f.CariHareketId,f.TersKayitId
FROM dbo.FinansHareketleri f JOIN dbo.FinansHesaplari h ON h.Id=f.HesapId
LEFT JOIN dbo.CariKartlari c ON c.Id=f.CariId ORDER BY f.Id DESC;").DefaultView;
            var hesaplar = Oku("SELECT Id,HesapKodu+N' - '+HesapAdi+N' ('+ParaBirimi+N')' AS Baslik FROM dbo.FinansHesaplari WHERE Aktif=1 ORDER BY HesapAdi;");
            ComboYukle(CmbFinHareketHesap, hesaplar, "Baslik");
            }
            else
            {
                GridFinHesaplar.ItemsSource = null;
                GridFinHareketler.ItemsSource = null;
                GridBelgeler.ItemsSource = null;
                CmbFinHareketHesap.ItemsSource = null;
            }
            if (Yetki("CUSTOMER.VIEW"))
            {
                var cariler = Oku("SELECT Id,CariKodu+N' - '+Unvan AS Baslik FROM dbo.CariKartlari WHERE Aktif=1 ORDER BY Unvan;");
                ComboYukle(CmbFinHareketCari, cariler, "Baslik", true);
                ComboYukle(CmbEvrakCari, cariler, "Baslik", true);
                ComboYukle(CmbBelgeCari, cariler, "Baslik");
                ComboYukle(CmbPlanliCari, cariler, "Baslik", true);
            }
            else { CmbFinHareketCari.ItemsSource = null; CmbEvrakCari.ItemsSource = null; CmbBelgeCari.ItemsSource = null; CmbPlanliCari.ItemsSource = null; }
            if (financeAllowed && Yetki("CUSTOMER.VIEW"))
                GridBelgeler.ItemsSource = Oku(@"SELECT TOP(250) b.Id,b.BelgeNo,b.BelgeTipi,c.Unvan AS Cari,
b.BelgeTarihi,b.AraToplam,b.KdvOrani,b.KdvTutari,b.GenelToplam,b.Durum,b.Aciklama,b.CariHareketId
FROM dbo.TicariBelgeler b JOIN dbo.CariKartlari c ON c.Id=b.CariId ORDER BY b.Id DESC;").DefaultView;
            else GridBelgeler.ItemsSource = null;
            if (financeAllowed)
                GridPlanliOdemeler.ItemsSource = Oku(@"SELECT TOP(250) p.Id,p.Baslik,p.VadeTarihi,p.Tutar,p.ParaBirimi,c.Unvan AS Cari,p.Durum
FROM dbo.PlanliOdemeler p LEFT JOIN dbo.CariKartlari c ON c.Id=p.CariId ORDER BY p.VadeTarihi,p.Id;").DefaultView;
            else GridPlanliOdemeler.ItemsSource = null;
            if (Yetki("CHECKNOTE.VIEW"))
                GridEvraklar.ItemsSource = Oku(@"SELECT TOP(250) e.Id,e.EvrakNo,e.EvrakTipi,e.Yon,c.Unvan AS Cari,
e.VadeTarihi,e.Tutar,e.ParaBirimi,e.Durum,e.Aciklama FROM dbo.CekSenetler e
LEFT JOIN dbo.CariKartlari c ON c.Id=e.CariId ORDER BY e.VadeTarihi,e.Id;").DefaultView;
            else GridEvraklar.ItemsSource = null;
            Durum("Kasa, banka ve çek/senet kayıtları yüklendi.");
        }
        private void FinYenile_Click(object s,RoutedEventArgs e) => Calistir(FinansYukle);
        private void FinHesapKaydet_Click(object s,RoutedEventArgs e) => Calistir(() =>
        {
            if(!Gerekli("FINANCE.PAYMENT")) return;
            string kod=Metin(TxtFinHesapKod),ad=Metin(TxtFinHesapAd);
            if(kod.Length<2||ad.Length<2||kod.Length>40||ad.Length>150) throw new ArgumentException("Hesap kodu ve adını kontrol edin.");
            {new EskiTicariServisi(baglantiAdresi,kullaniciId).FinHesapKaydet(kod,ad,Sec(CmbFinHesapTur),Sec(CmbFinHesapBirim));}TxtFinHesapKod.Clear();TxtFinHesapAd.Clear();FinansYukle();Durum("Finans hesabı eklendi.");
        });
        private void FinHesapDurum_Click(object s,RoutedEventArgs e) => Calistir(() =>
        {
            if(!Gerekli("FINANCE.PAYMENT")) return;
            if(GridFinHesaplar.SelectedItem is not DataRowView r) throw new ArgumentException("Önce hesap seçin.");
            int id=Convert.ToInt32(r["Id"]);bool aktif=Convert.ToBoolean(r["Aktif"]);
            if(!Onay(aktif?"Hesap pasife alınsın mı? Geçmiş hareketler korunur.":"Hesap aktifleştirilsin mi?"))return;
            {new EskiTicariServisi(baglantiAdresi,kullaniciId).FinHesapDurum(id,aktif);}FinansYukle();
        });
        private void FinHareketKaydet_Click(object s,RoutedEventArgs e) => Calistir(() =>
        {
            if(!Gerekli("FINANCE.PAYMENT"))return;
            int hesap=SeciliId(CmbFinHareketHesap);
            int? cari=CmbFinHareketCari.SelectedValue is int cid?cid:null;
            decimal tutar=Para(TxtFinHareketTutar);
            string tur=Sec(CmbFinHareketTur), aciklama=Metin(TxtFinHareketAciklama);
            DateTime date=Tarih(DpFinHareketTarih);
            if(aciklama.Length<3||aciklama.Length>400)throw new ArgumentException("Açıklama en az 3 karakter olmalı.");
            if(!Onay($"{tur} • {tutar:N2} • {aciklama}\nCari: {(cari.HasValue ? "Bağlı" : "Bağlı değil")}\nİşlem kaydedilsin mi?"))return;
            {new EskiTicariServisi(baglantiAdresi,kullaniciId).FinHareketKaydet(hesap,cari,tutar,tur,aciklama,date);}TxtFinHareketTutar.Clear();TxtFinHareketAciklama.Clear();FinansYukle();Durum("Finans hareketi ve varsa cari yansıması kaydedildi.");
        });
        private void FinHareketTers_Click(object s,RoutedEventArgs e) => Calistir(() =>
        {
            if(!Gerekli("FINANCE.PAYMENT"))return;
            if(GridFinHareketler.SelectedItem is not DataRowView r)throw new ArgumentException("Önce finans hareketi seçin.");
            long kaynak=Convert.ToInt64(r["Id"]);
            if(!Onay("Seçilen hareketin ters kaydı oluşturulsun mu? Cari bağlantısı varsa birlikte terslenir; geçmiş kayıt silinmez."))return;
            {new EskiTicariServisi(baglantiAdresi,kullaniciId).FinHareketTers(kaynak);}FinansYukle();Durum("Finans hareketi ve bağlı cari kaydı terslendi.");
        });
        private void BelgeKaydet_Click(object s,RoutedEventArgs e) => Calistir(() =>
        {
            if (!Gerekli("CUSTOMER.EDIT")) return;
            string no = Metin(TxtBelgeNo), tur = Sec(CmbBelgeTipi), aciklama = Metin(TxtBelgeAciklama);
            int cari = SeciliId(CmbBelgeCari);
            DateTime date = Tarih(DpBelgeTarih);
            decimal ara = Para(TxtBelgeAraToplam);
            if (!decimal.TryParse(Sec(CmbBelgeKdv), NumberStyles.Integer, CultureInfo.InvariantCulture, out decimal oran))
                throw new ArgumentException("KDV oranı seçin.");
            decimal kdv = decimal.Round(ara * oran / 100m, 2, MidpointRounding.AwayFromZero);
            decimal toplam = ara + kdv;
            if (toplam > 9999999999999999m) throw new ArgumentException("Belge tutarı izin verilen sınırı aşıyor.");
            if (no.Length < 2 || no.Length > 80 || aciklama.Length < 3 || aciklama.Length > 400)
                throw new ArgumentException("Belge no (2-80) ve açıklama (3-400) karakter olmalı.");
            if (!Onay($"{tur} belgesi: {no} • {toplam:N2} TRY (KDV {kdv:N2})\nCari bakiyesine yansıtılsın mı?\nBu işlem e-fatura veya stok hareketi oluşturmaz.")) return;
            {new EskiTicariServisi(baglantiAdresi,kullaniciId).BelgeKaydet(no,tur,aciklama,cari,date,ara,oran);} TxtBelgeNo.Clear(); TxtBelgeAraToplam.Clear(); TxtBelgeAciklama.Clear();
            FinansYukle(); Durum("Ticari belge ve cari hareketi birlikte kaydedildi.");
        });
        private void BelgeIptal_Click(object s,RoutedEventArgs e) => Calistir(() =>
        {
            if (!Gerekli("CUSTOMER.EDIT")) return;
            if (GridBelgeler.SelectedItem is not DataRowView r) throw new ArgumentException("Önce belge seçin.");
            long id = Convert.ToInt64(r["Id"]);
            if (!Onay("Belge iptal edilsin mi? İlgili cari hareketine ters kayıt oluşturulacak. Belge ve geçmiş kayıtlar silinmez.")) return;
            {new EskiTicariServisi(baglantiAdresi,kullaniciId).BelgeIptal(id);} FinansYukle(); Durum("Belge iptal edildi ve cari ters kaydı oluşturuldu.");
        });

        private void PlanliKaydet_Click(object s, RoutedEventArgs e) => Calistir(() =>
        {
            if (!Gerekli("FINANCE.PAYMENT")) return;
            string baslik = Metin(TxtPlanliBaslik), birim = Sec(CmbPlanliBirim);
            if (baslik.Length < 3 || baslik.Length > 150) throw new ArgumentException("Ödeme başlığı 3-150 karakter olmalı.");
            decimal tutar = Para(TxtPlanliTutar);
            DateTime vade = Tarih(DpPlanliVade);
            if (!Onay($"{baslik} • {tutar:N2} {birim} • {vade:dd.MM.yyyy} planlı ödeme kaydedilsin mi?")) return;
            {new EskiTicariServisi(baglantiAdresi,kullaniciId).PlanliKaydet(baslik,birim,tutar,vade,CmbPlanliCari.SelectedValue is int planliCari?planliCari:null);}TxtPlanliBaslik.Clear();TxtPlanliTutar.Clear();FinansYukle();Durum("Planlı ödeme eklendi.");
        });
        private void PlanliDurum_Click(object s, RoutedEventArgs e) => Calistir(() =>
        {
            if (!Gerekli("FINANCE.PAYMENT")) return;
            if (GridPlanliOdemeler.SelectedItem is not DataRowView r) throw new ArgumentException("Önce planlı ödeme seçin.");
            long id = Convert.ToInt64(r["Id"]);string newStatus=Sec(CmbPlanliYeniDurum);
            if(!Onay("Planlı ödeme durumu '"+newStatus+"' olarak değiştirilsin mi?\nBu işlem finans hareketi oluşturmaz.")) return;
            {new EskiTicariServisi(baglantiAdresi,kullaniciId).PlanliDurum(id,newStatus);}FinansYukle();Durum("Planlı ödeme durumu güncellendi.");
        });

        private void EvrakKaydet_Click(object s,RoutedEventArgs e) => Calistir(() =>
        {
            if(!Gerekli("CHECKNOTE.EDIT"))return;
            string no=Metin(TxtEvrakNo);decimal tutar=Para(TxtEvrakTutar);DateTime date=Tarih(DpEvrakVade);
            if(no.Length<2||no.Length>80)throw new ArgumentException("Evrak numarası 2-80 karakter olmalı.");
            {new EskiTicariServisi(baglantiAdresi,kullaniciId).EvrakKaydet(no,tutar,date,Sec(CmbEvrakTur),Sec(CmbEvrakYon),CmbEvrakCari.SelectedValue is int evrakCari?evrakCari:null,Sec(CmbEvrakBirim));}TxtEvrakNo.Clear();TxtEvrakTutar.Clear();FinansYukle();Durum("Çek/senet kaydı oluşturuldu. Finans hareketi oluşmadı.");
        });
        private void EvrakDurum_Click(object s,RoutedEventArgs e) => Calistir(() =>
        {
            if(!Gerekli("CHECKNOTE.EDIT"))return;
            if(GridEvraklar.SelectedItem is not DataRowView r)throw new ArgumentException("Önce çek/senet seçin.");
            long id=Convert.ToInt64(r["Id"]);string durum=Sec(CmbEvrakYeniDurum);
            if(!Onay("Evrak durumu '"+durum+"' olarak değiştirilsin mi?\nBu işlem otomatik para hareketi oluşturmaz."))return;
            {new EskiTicariServisi(baglantiAdresi,kullaniciId).EvrakDurum(id,durum);}FinansYukle();Durum("Evrak durumu ve değişiklik geçmişi kaydedildi.");
        });

        // ---------------- RAPORLAR ----------------
        private void RaporGetir_Click(object s,RoutedEventArgs e) => Calistir(RaporGetir);
        private void RaporGetir()
        {
            if(!Gerekli("REPORT.VIEW"))return;
            string title=CmbRaporTur.SelectedItem?.ToString()??"";
            string? extra=title switch {
                "Cari Bakiyeleri" or "Cari Hareketleri" => "CUSTOMER.VIEW",
                "Kasa / Banka Bakiyeleri" or "Kasa / Banka Hareketleri" => "FINANCE.VIEW",
                "Alış / Satış Belgeleri" => "FINANCE.VIEW",
                "Planlı Ödemeler" => "FINANCE.VIEW",
                "Çek / Senet" => "CHECKNOTE.VIEW",
                "Stok Bakiyeleri" => "STOCK.VIEW",
                "Üretim Emirleri" => "PRODUCTION.VIEW",
                _=>null
            };
            if(extra==null||!Gerekli(extra) ||
               (title=="Alış / Satış Belgeleri" && !Gerekli("CUSTOMER.VIEW")))
            { GridRapor.ItemsSource=null; sonRapor=null; return; }
            DateTime start=Tarih(DpRaporBaslangic),end=Tarih(DpRaporBitis);
            if(start>end)throw new ArgumentException("Başlangıç tarihi bitişten sonra olamaz.");
            string sql=title switch {
                "Cari Bakiyeleri" => @"SELECT c.CariKodu,c.Unvan,c.CariTipi,
CAST(ISNULL(SUM(CASE h.HareketTipi WHEN N'Borç' THEN h.Tutar ELSE -h.Tutar END),0) AS decimal(18,2)) AS BakiyeTRY,
c.Aktif FROM dbo.CariKartlari c LEFT JOIN dbo.CariHareketleri h ON h.CariId=c.Id
GROUP BY c.CariKodu,c.Unvan,c.CariTipi,c.Aktif ORDER BY c.Unvan;",
                "Cari Hareketleri" => @"SELECT h.Tarih,c.CariKodu,c.Unvan,h.HareketTipi,h.Tutar,h.Aciklama,h.Kaynak
FROM dbo.CariHareketleri h JOIN dbo.CariKartlari c ON c.Id=h.CariId
WHERE h.Tarih>=@bas AND h.Tarih<DATEADD(day,1,@bit) ORDER BY h.Tarih DESC,h.Id DESC;",
                "Kasa / Banka Bakiyeleri" => @"SELECT h.HesapKodu,h.HesapAdi,h.HesapTipi,h.ParaBirimi,
CAST(ISNULL(SUM(CASE f.HareketTipi WHEN N'Giriş' THEN f.Tutar ELSE -f.Tutar END),0) AS decimal(18,2)) AS Bakiye,
h.Aktif FROM dbo.FinansHesaplari h LEFT JOIN dbo.FinansHareketleri f ON f.HesapId=h.Id
GROUP BY h.HesapKodu,h.HesapAdi,h.HesapTipi,h.ParaBirimi,h.Aktif ORDER BY h.HesapAdi;",
                "Kasa / Banka Hareketleri" => @"SELECT f.Tarih,h.HesapKodu,h.HesapAdi,h.ParaBirimi,f.HareketTipi,f.Tutar,c.Unvan AS Cari,f.Aciklama
FROM dbo.FinansHareketleri f JOIN dbo.FinansHesaplari h ON h.Id=f.HesapId
LEFT JOIN dbo.CariKartlari c ON c.Id=f.CariId WHERE f.Tarih>=@bas AND f.Tarih<DATEADD(day,1,@bit)
ORDER BY f.Tarih DESC,f.Id DESC;",
                "Alış / Satış Belgeleri" => @"SELECT b.BelgeNo,b.BelgeTipi,c.Unvan AS Cari,b.BelgeTarihi,b.AraToplam,b.KdvOrani,b.KdvTutari,b.GenelToplam,b.Durum,b.Aciklama
FROM dbo.TicariBelgeler b JOIN dbo.CariKartlari c ON c.Id=b.CariId
WHERE b.BelgeTarihi>=@bas AND b.BelgeTarihi<DATEADD(day,1,@bit) ORDER BY b.BelgeTarihi DESC,b.Id DESC;",
                "Planlı Ödemeler" => @"SELECT p.Baslik,p.VadeTarihi,p.Tutar,p.ParaBirimi,c.Unvan AS Cari,p.Durum
FROM dbo.PlanliOdemeler p LEFT JOIN dbo.CariKartlari c ON c.Id=p.CariId
WHERE p.VadeTarihi>=@bas AND p.VadeTarihi<DATEADD(day,1,@bit) ORDER BY p.VadeTarihi,p.Id;",
                "Çek / Senet" => @"SELECT e.EvrakNo,e.EvrakTipi,e.Yon,c.Unvan AS Cari,e.VadeTarihi,e.Tutar,e.ParaBirimi,e.Durum
FROM dbo.CekSenetler e LEFT JOIN dbo.CariKartlari c ON c.Id=e.CariId
WHERE e.VadeTarihi>=@bas AND e.VadeTarihi<DATEADD(day,1,@bit) ORDER BY e.VadeTarihi,e.Id;",
                "Stok Bakiyeleri" => @"SELECT s.StokKodu,s.StokAdi,s.StokTipi,s.Birim,ISNULL(b.Miktar,0) AS Miktar,s.MinimumStokMiktari,
CASE WHEN s.MinimumStokMiktari IS NOT NULL AND ISNULL(b.Miktar,0)<=s.MinimumStokMiktari THEN N'Kritik' ELSE N'Normal' END AS Durum
FROM dbo.StokKartlari s LEFT JOIN dbo.StokBakiyeleri b ON b.StokKartId=s.Id WHERE s.Aktif=1 ORDER BY s.StokAdi;",
                "Üretim Emirleri" => @"SELECT e.UretimEmriNo,s.StokKodu,s.StokAdi,e.PlanlananMiktar,e.UretilenMiktar,e.FireMiktari,
e.MiktarBirimi,e.Durum,e.KayitTarihi FROM dbo.UretimEmirleri e JOIN dbo.StokKartlari s ON s.Id=e.MamulStokId
WHERE e.KayitTarihi>=@bas AND e.KayitTarihi<DATEADD(day,1,@bit) ORDER BY e.Id DESC;",
                _ => throw new ArgumentException("Rapor seçin.")
            };
            if(title=="Alış / Satış Belgeleri"){using var con=Baglan();using var table=Cmd(con,null,"SELECT COL_LENGTH('dbo.BERP270_EBelgeIslem','BelgeNo')");if(table.ExecuteScalar() is not DBNull)sql=EBelge.EbelgeRaporu.AlisSatis;}
            sonRapor=Oku(sql,("@bas",start),("@bit",end));
            GridRapor.ItemsSource=sonRapor.DefaultView;
            TxtRaporBilgi.Text=title+" • "+sonRapor.Rows.Count+" satır • "+DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");
            Durum("Rapor hazır.");
        }
        private void RaporCsv_Click(object s,RoutedEventArgs e) => Calistir(() =>
        {
            if(!Gerekli("REPORT.VIEW")||sonRapor==null) return;
            // Rapor izinleri degistiyse eskiden bellekte tutulan veriyi disari verme.
            RaporGetir();
            if(sonRapor==null)return;
            var dialog = new SaveFileDialog { Filter="CSV dosyası (*.csv)|*.csv",FileName="MiapaxERP_Rapor_"+DateTime.Now.ToString("yyyyMMdd_HHmm")+".csv" };
            if(dialog.ShowDialog(Window.GetWindow(this))!=true)return;
            static string Esc(string value)
            {
                // CSV/Excel formül enjeksiyonuna karşı dışarı aktarılan metin hücreleri korunur.
                if (value.Length > 0 && "=+@-\t\r".Contains(value[0])) value = "'" + value;
                return "\"" + value.Replace("\"", "\"\"") + "\"";
            }
            var sb=new StringBuilder();
            sb.AppendLine(string.Join(";",sonRapor.Columns.Cast<DataColumn>().Select(c=>Esc(c.ColumnName))));
            foreach(DataRow row in sonRapor.Rows)
                sb.AppendLine(string.Join(";",row.ItemArray.Select(o=>Esc(Convert.ToString(o,tr)??""))));
            File.WriteAllText(dialog.FileName,sb.ToString(),new UTF8Encoding(true));
            Durum("Rapor kaydedildi: "+dialog.FileName);
        });

        // ---------------- AYARLAR ----------------
        private void AyarlariYukle()
        {
            if(!Yetki("SETTINGS.VIEW"))return;
            var prefs=Oku("SELECT Tema,VurguRengi,Kompakt FROM dbo.KullaniciGorunumAyarlari WHERE KullaniciId=@k;",("@k",kullaniciId));
            if(prefs.Rows.Count>0)
            {
                var row=prefs.Rows[0];
                for(int i=0;i<CmbTema.Items.Count;i++)
                    if((CmbTema.Items[i] as ComboBoxItem)?.Content?.ToString()==Convert.ToString(row["Tema"]))CmbTema.SelectedIndex=i;
                string color=Convert.ToString(row["VurguRengi"])??"#2563EB";
                for(int i=0;i<CmbVurgu.Items.Count;i++)
                    if((CmbVurgu.Items[i] as ComboBoxItem)?.Tag?.ToString()==color)CmbVurgu.SelectedIndex=i;
                ChkKompakt.IsChecked=Convert.ToBoolean(row["Kompakt"]);
            }
            TemaUygula();

        }
        private void TemaUygula()
        {
            var a = GorunumDeposu.Oku(GorunumDeposu.Klasor(baglantiAdresi, kullaniciId));
            GorunumRenkleri.Uygula(this, a);

        }
        private static IEnumerable<Button> TumButonlar(DependencyObject root)
        {
            for(int i=0;i<VisualTreeHelper.GetChildrenCount(root);i++)
            {
                var child=VisualTreeHelper.GetChild(root,i);
                if(child is Button button)yield return button;
                foreach(var altButon in TumButonlar(child))yield return altButon;
            }
        }
        private void AyarTemaKaydet_Click(object s, RoutedEventArgs e) => Calistir(() =>
        {
            if (!Gerekli("SETTINGS.THEME")) return;
            var klasor = GorunumDeposu.Klasor(baglantiAdresi, kullaniciId);
            var pencere = new GorunumPenceresi(klasor, GorunumDeposu.Oku(klasor), () =>
            {
                using var con = Baglan(); using var tx = con.BeginTransaction();
                Zorunlu(con, tx, "SETTINGS.THEME"); tx.Commit();
            }, a =>
            {
                TemaUygula();
                foreach (var ana in Application.Current.Windows.OfType<MainWindow>()) ana.GorunumuUygula(a);
                Durum("Tema ve ana sayfa tercihleriniz kaydedildi.");
            }) { Owner = Window.GetWindow(this) };
            pencere.ShowDialog();
        });
        // Eski XAML dosyalarında kalan firma kaydet butonu için uyumluluk.
        // Firma bilgileri artık ayrı pencerede yönetilir.
        private void AyarFirmaKaydet_Click(object sender, RoutedEventArgs e)
        {
            var firma = new FirmaBilgileriPenceresi(baglantiAdresi, kullaniciId)
            {
                Owner = Window.GetWindow(this)
            };
            firma.ShowDialog();
        }

    }
}


