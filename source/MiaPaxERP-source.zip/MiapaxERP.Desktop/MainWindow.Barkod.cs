using System;
using System.Windows;

namespace MiapaxERP.Desktop;

public partial class MainWindow
{
    private void BarkodEtiketiAc_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var pencere = new BarkodEtiketiPenceresi { Owner = this };
            pencere.ShowDialog();
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "Barkod etiketi ekranı açılamadı.\n\n" + ex.Message,
                "MiapaxERP",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }
}
