using System.Data;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
public sealed partial class IsletmeServisi{
SqlConnection Baglan()=>access.Ac();
static SqlCommand Komut(SqlConnection c,SqlTransaction? t,string sql)=>new(sql,c,t){CommandTimeout=60};
void YetkiZorunlu(SqlConnection c,SqlTransaction? t,string code)=>Yetki(c,t,code);
static void DecimalParam(SqlCommand q,string key,decimal v){var p=q.Parameters.Add(key,SqlDbType.Decimal);p.Precision=18;p.Scale=2;p.Value=v;}
static object Bos(string s)=>string.IsNullOrWhiteSpace(s)?DBNull.Value:s.Trim();
public void NakitKaydet(int hesap,string yon,decimal tutar,DateTime tarih,string aciklama){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"IsletmeServisi.NakitKaydet","",new object?[]{hesap,yon,tutar,tarih,aciklama});return;}
Money(tutar);Text(aciklama,1,400,"Açıklama");if(tutar<=0||yon is not("Giriş" or "Çıkış"))throw new ArgumentException("Tutar ve yönü kontrol edin.");using var con = Baglan(); using var tx = con.BeginTransaction(IsolationLevel.Serializable);
                try
                {
                    YetkiZorunlu(con, tx, "FINANCE.PAYMENT");
                    using (var kontrol = Komut(con, tx, "SELECT COUNT(1) FROM dbo.FinansHesaplari WITH (UPDLOCK,HOLDLOCK) WHERE Id=@Id AND Aktif=1;"))
                    {
                        kontrol.Parameters.Add("@Id", SqlDbType.Int).Value = hesap;
                        if (Convert.ToInt32(kontrol.ExecuteScalar()) != 1) throw new InvalidOperationException("Hesap aktif değil.");
                    }
                    using var cmd = Komut(con, tx, @"INSERT INTO dbo.FinansHareketleri
(HesapId,CariId,CariHareketId,Tarih,HareketTipi,Tutar,Aciklama,YapanKullaniciId)
VALUES(@Hesap,NULL,NULL,@Tarih,@Yon,@Tutar,@Aciklama,@Kul);");
                    cmd.Parameters.Add("@Hesap", SqlDbType.Int).Value = hesap;
                    cmd.Parameters.Add("@Tarih", SqlDbType.Date).Value = tarih;
                    cmd.Parameters.Add("@Yon", SqlDbType.NVarChar, 10).Value = yon;
                    DecimalParam(cmd, "@Tutar", tutar);
                    cmd.Parameters.Add("@Aciklama", SqlDbType.NVarChar, 400).Value = aciklama;
                    cmd.Parameters.Add("@Kul", SqlDbType.Int).Value = user;
                    if (cmd.ExecuteNonQuery() != 1) throw new InvalidOperationException("Kasa hareketi kaydedilemedi.");
                    tx.Commit();
                }
                catch { tx.Rollback(); throw; }}
public void MasrafKaydet(DateTime tarih,string kategori,decimal tutar,int? cariId,bool odendi,int? hesapId,string aciklama){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"IsletmeServisi.MasrafKaydet","",new object?[]{tarih,kategori,tutar,cariId,odendi,hesapId,aciklama});return;}
Money(tutar);Text(kategori,1,100,"Kategori");Text(aciklama,0,400,"Açıklama");if(tutar<=0||odendi&&!hesapId.HasValue)throw new ArgumentException("Masraf tutarı ve hesabını kontrol edin.");using var con = Baglan(); using var tx = con.BeginTransaction(IsolationLevel.Serializable);
                try
                {
                    YetkiZorunlu(con, tx, "FINANCE.PAYMENT");if(cariId.HasValue){using var customer=Q(con,tx,"SELECT COUNT(*) FROM dbo.CariKartlari WITH(HOLDLOCK) WHERE Id=@i AND Aktif=1",("@i",cariId));if(Convert.ToInt32(customer.ExecuteScalar())!=1)throw new ArgumentException("Aktif cari seçin.");}
                    long? finansId = null;
                    if (odendi)
                    {
                        using (var kontrol = Komut(con, tx, "SELECT COUNT(1) FROM dbo.FinansHesaplari WITH(UPDLOCK,HOLDLOCK) WHERE Id=@Id AND ParaBirimi=N'TRY' AND Aktif=1;"))
                        {
                            kontrol.Parameters.Add("@Id", SqlDbType.Int).Value = hesapId!.Value;
                            if (Convert.ToInt32(kontrol.ExecuteScalar()) != 1)
                                throw new InvalidOperationException("Masraf çıkışı için aktif TRY hesabı seçin.");
                        }
                        using var f = Komut(con, tx, @"INSERT INTO dbo.FinansHareketleri
(HesapId,CariId,CariHareketId,Tarih,HareketTipi,Tutar,Aciklama,YapanKullaniciId)
OUTPUT INSERTED.Id VALUES(@Hesap,NULL,NULL,@Tarih,N'Çıkış',@Tutar,@Aciklama,@Kul);");
                        f.Parameters.Add("@Hesap", SqlDbType.Int).Value = hesapId.Value;
                        f.Parameters.Add("@Tarih", SqlDbType.Date).Value = tarih;
                        DecimalParam(f, "@Tutar", tutar);
                        f.Parameters.Add("@Aciklama", SqlDbType.NVarChar, 400).Value =
                            ("Masraf / " + kategori + " / " + aciklama).Substring(0, Math.Min(400, ("Masraf / " + kategori + " / " + aciklama).Length));
                        f.Parameters.Add("@Kul", SqlDbType.Int).Value = user;
                        finansId = Convert.ToInt64(f.ExecuteScalar());
                    }
                    using var cmd = Komut(con, tx, @"INSERT INTO dbo.BoruERP_YeniMasraflar
(Tarih,Kategori,Tutar,CariId,FinansHareketId,Aciklama,YapanKullaniciId)
VALUES(@Tarih,@Kategori,@Tutar,@Cari,@Finans,@Aciklama,@Kul);");
                    cmd.Parameters.Add("@Tarih", SqlDbType.Date).Value = tarih;
                    cmd.Parameters.Add("@Kategori", SqlDbType.NVarChar, 100).Value = kategori;
                    DecimalParam(cmd, "@Tutar", tutar);
                    cmd.Parameters.Add("@Cari", SqlDbType.Int).Value = cariId.HasValue ? (object)cariId.Value : DBNull.Value;
                    cmd.Parameters.Add("@Finans", SqlDbType.BigInt).Value = finansId.HasValue ? (object)finansId.Value : DBNull.Value;
                    cmd.Parameters.Add("@Aciklama", SqlDbType.NVarChar, 400).Value = Bos(aciklama);
                    cmd.Parameters.Add("@Kul", SqlDbType.Int).Value = user;
                    if (cmd.ExecuteNonQuery() != 1) throw new InvalidOperationException("Masraf kaydı oluşmadı.");
                    tx.Commit();
                }
                catch { tx.Rollback(); throw; }}
public void ManuelGelenFatura(string no,int cari,DateTime tarih,DateTime? vade,decimal matrah,decimal kdv,decimal toplam,string aciklama){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"IsletmeServisi.ManuelGelenFatura","",new object?[]{no,cari,tarih,vade,matrah,kdv,toplam,aciklama});return;}
Text(no,1,80,"Fatura no");Text(aciklama,0,400,"Açıklama");Money(matrah);Money(kdv);if(matrah<=0||toplam!=matrah+kdv||vade.HasValue&&vade<tarih)throw new ArgumentException("Fatura tutarları veya vade geçersiz.");using var con = Baglan(); using var tx = con.BeginTransaction();
                try
                {
                    YetkiZorunlu(con, tx, "FINANCE.PAYMENT");using(var customer=Q(con,tx,"SELECT COUNT(*) FROM dbo.CariKartlari WITH(HOLDLOCK) WHERE Id=@i AND Aktif=1",("@i",cari)))if(Convert.ToInt32(customer.ExecuteScalar())!=1)throw new ArgumentException("Aktif cari seçin.");
                    using var cmd = Komut(con, tx, @"INSERT INTO dbo.BoruERP_GelenEFaturalar
(FaturaNo,CariId,FaturaTarihi,VadeTarihi,Matrah,Kdv,GenelToplam,Aciklama,YapanKullaniciId)
VALUES(@No,@Cari,@Tarih,@Vade,@Matrah,@Kdv,@Genel,@Aciklama,@Kul);");
                    cmd.Parameters.Add("@No", SqlDbType.NVarChar, 80).Value = no;
                    cmd.Parameters.Add("@Cari", SqlDbType.Int).Value = cari;
                    cmd.Parameters.Add("@Tarih", SqlDbType.Date).Value = tarih;
                    cmd.Parameters.Add("@Vade", SqlDbType.Date).Value = vade.HasValue ? (object)vade.Value : DBNull.Value;
                    DecimalParam(cmd, "@Matrah", matrah); DecimalParam(cmd, "@Kdv", kdv); DecimalParam(cmd, "@Genel", toplam);
                    cmd.Parameters.Add("@Aciklama", SqlDbType.NVarChar, 400).Value = Bos(aciklama);
                    cmd.Parameters.Add("@Kul", SqlDbType.Int).Value = user;
                    if (cmd.ExecuteNonQuery() != 1) throw new InvalidOperationException("Fatura kaydedilemedi.");
                    tx.Commit();
                }
                catch { tx.Rollback(); throw; }}
}