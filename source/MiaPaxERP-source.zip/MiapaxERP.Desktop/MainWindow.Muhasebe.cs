using System.Windows;

namespace MiapaxERP.Desktop;
public partial class MainWindow
{
    private MuhasebePaneli? muhasebePaneli;
    public void MuhasebeBolumAc(string? bolum)
    {
        if(aktifKullanici==null || DemoModu)
        {MessageBox.Show("Muhasebe için kullanıcı oturumu ve SQL Server bağlantısı gereklidir.","MiapaxERP");return;}
        if(muhasebePaneli==null)
        {
            muhasebePaneli=new MuhasebePaneli(baglantiAdresi,aktifKullanici.KullaniciId,aktifKullanici.AdSoyad,StokYetkisiVar);
            MuhasebeIcerik.Content=muhasebePaneli;
        }
        bool acildi=muhasebePaneli.Ac(bolum);
        if(!acildi && muhasebePaneli.AktifBolum!=null)return;
        TumIcerikleriGizle();MuhasebeIcerik.Visibility=Visibility.Visible;
        SayfaBasligi.Text=bolum=="ayar"?"Ayarlar":"Muhasebe";
    }
    private void MuhasebeOturumunuTemizle()
    {
        MuhasebeIcerik.Content=null;MuhasebeIcerik.Visibility=Visibility.Collapsed;muhasebePaneli=null;
    }
}
