using SqlConnection = MiapaxERP.Desktop.ErpSqlConnection;
using SqlCommand = MiapaxERP.Desktop.ErpSqlCommand;
using SqlTransaction = MiapaxERP.Desktop.ErpSqlTransaction;
using SqlDataReader = MiapaxERP.Desktop.ErpSqlReader;
using SqlDataAdapter = MiapaxERP.Desktop.ErpSqlDataAdapter;
using System;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;

namespace MiapaxERP.Desktop
{
    public partial class TicariYeniIslemlerPenceresi : Window
    {
        private readonly string baglantiAdresi;
        private readonly int kullaniciId;
        private static readonly CultureInfo Tr = CultureInfo.GetCultureInfo("tr-TR");
        private readonly DataTable teklifKalemleri = YeniKalemTablosu();
        private readonly DataTable satisKalemleri = YeniKalemTablosu();
        private long? kaynakTeklifId;
        private bool ekranHazir;

        public TicariYeniIslemlerPenceresi(string connectionString, int userId)
        {
            baglantiAdresi = connectionString;
            kullaniciId = userId;
            InitializeComponent();
            GridTeklifKalemler.ItemsSource = teklifKalemleri.DefaultView;
            GridSatisKalemler.ItemsSource = satisKalemleri.DefaultView;
            DpTeklifTarih.SelectedDate = DateTime.Today;
            DpTeklifGecerlilik.SelectedDate = DateTime.Today.AddDays(15);
            DpSatisTarih.SelectedDate = DateTime.Today;
            DpNakitTarih.SelectedDate = DateTime.Today;
            DpMasrafTarih.SelectedDate = DateTime.Today;
            DpEfaturaTarih.SelectedDate = DateTime.Today;
            DpEfaturaVade.SelectedDate = DateTime.Today;
            CmbTeklifKdv.SelectedIndex = 3;
            CmbTeklifFiyatTipi.SelectedIndex = 0;
            CmbSatisKdv.SelectedIndex = 3;
            CmbSatisOdeme.SelectedIndex = 0;
            CmbNakitYon.SelectedIndex = 0;
            CmbMasrafKategori.SelectedIndex = 0;
            YeniBelgeNo("T");
            YeniBelgeNo("S");
            Loaded += (_, _) => Baslat();
        }

        private static DataTable YeniKalemTablosu()
        {
            var t = new DataTable();
            t.Columns.Add("StokKartId", typeof(int));
            t.Columns.Add("Urun", typeof(string));
            t.Columns.Add("Birim", typeof(string));
            t.Columns.Add("Miktar", typeof(decimal));
            t.Columns.Add("Fiyat", typeof(decimal));
            t.Columns.Add("Kdv", typeof(decimal));
            t.Columns.Add("AraToplam", typeof(decimal));
            t.Columns.Add("KdvTutari", typeof(decimal));
            t.Columns.Add("SatirToplam", typeof(decimal));
            return t;
        }

        private SqlConnection Baglan()
        {
            var con = new SqlConnection(baglantiAdresi);
            con.Open();
            return con;
        }

        private static SqlCommand Komut(SqlConnection con, SqlTransaction? tx, string sql)
            => new SqlCommand(sql, con, tx) { CommandTimeout = 30 };

        private static void DecimalParam(SqlCommand cmd, string ad, decimal deger, byte scale = 2)
        {
            var p = cmd.Parameters.Add(ad, SqlDbType.Decimal);
            p.Precision = 18; p.Scale = scale; p.Value = deger;
        }

        private static object Bos(string s) => string.IsNullOrWhiteSpace(s) ? DBNull.Value : s.Trim();

        private static bool SayiyiOku(string text, int ondalik, bool sifirOlabilir, out decimal deger)
        {
            deger = 0;
            string s = text.Trim();
            if (s.Length == 0 || s.Contains(' ') || (s.Contains(',') && s.Contains('.')) ||
                s.Count(c => c == '.' || c == ',') > 1) return false;
            s = s.Replace(',', '.');
            int nokta = s.IndexOf('.');
            if (nokta >= 0 && s.Length - nokta - 1 > ondalik) return false;
            return decimal.TryParse(s, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out deger) &&
                (sifirOlabilir ? deger >= 0 : deger > 0) && deger <= 999999999999m;
        }

        private static decimal Para(string text, bool sifirOlabilir = false)
        {
            if (!SayiyiOku(text, 2, sifirOlabilir, out var value))
                throw new ArgumentException("Geçerli tutar girin (örn. 1250,50). Binlik ayıracı kullanmayın.");
            return value;
        }

        private static decimal Miktar(string text)
        {
            if (!SayiyiOku(text, 3, false, out var value))
                throw new ArgumentException("Miktar pozitif ve en fazla 3 ondalıklı olmalı (örn. 25 veya 25,5).");
            return value;
        }

        private static DateTime Tarih(DatePicker dp) => dp.SelectedDate?.Date ??
            throw new ArgumentException("Tarih seçmelisiniz.");

        private static int Secili(ComboBox cmb, string aciklama) => cmb.SelectedValue is int id
            ? id : throw new ArgumentException(aciklama + " seçmelisiniz.");

        private static decimal KdvSec(ComboBox cmb)
        {
            if (cmb.SelectedItem is ComboBoxItem item && decimal.TryParse(item.Content?.ToString(), out var kdv))
                return kdv;
            throw new ArgumentException("KDV oranını seçin.");
        }

        private static void Bagla(ComboBox combo, DataTable data)
        {
            combo.ItemsSource = data.DefaultView;
            combo.DisplayMemberPath = "Secim";
            combo.SelectedValuePath = "Id";
            combo.SelectedIndex = -1;
        }

        private bool Yetki(SqlConnection con, SqlTransaction? tx, string kod)
        {
            LisansOturumu.YetkiGerekli(kod);
            using var cmd = Komut(con, tx, @"SELECT CASE WHEN EXISTS(
SELECT 1 FROM dbo.vw_KullaniciEtkinYetkileri WHERE KullaniciId=@Id AND YetkiKodu=@Kod AND Yetkili=1)
AND EXISTS(SELECT 1 FROM dbo.Kullanicilar WHERE Id=@Id AND Aktif=1) THEN 1 ELSE 0 END;");
            cmd.Parameters.Add("@Id", SqlDbType.Int).Value = kullaniciId;
            cmd.Parameters.Add("@Kod", SqlDbType.NVarChar, 80).Value = kod;
            return Convert.ToInt32(cmd.ExecuteScalar()) == 1;
        }

        private void YetkiZorunlu(SqlConnection con, SqlTransaction? tx, string kod)
        {
            if (!Yetki(con, tx, kod)) throw new UnauthorizedAccessException("Bu işlem için yetkiniz yok: " + kod);
        }

        private void Baslat()
        {
            try
            {
                using var con = Baglan();
                using var kontrol = Komut(con, null, @"SELECT CASE WHEN
OBJECT_ID(N'dbo.BoruERP_YeniBelgeler',N'U') IS NOT NULL AND
OBJECT_ID(N'dbo.BoruERP_YeniBelgeKalemleri',N'U') IS NOT NULL AND
OBJECT_ID(N'dbo.BoruERP_YeniMasraflar',N'U') IS NOT NULL AND
OBJECT_ID(N'dbo.BoruERP_GelenEFaturalar',N'U') IS NOT NULL THEN 1 ELSE 0 END;");
                if (Convert.ToInt32(kontrol.ExecuteScalar()) != 1)
                    throw new InvalidOperationException("Önce 01_SQL_TEKLIF_SATIS_MASRAF_EFATURA.sql dosyasını SSMS'de çalıştırın.");
                ekranHazir = true;
                ListeleriYukle();
            }
            catch (Exception ex)
            {
                ekranHazir = false;
                MessageBox.Show("Yeni ticari modüller açılamadı:\n\n" + ex.Message,
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Error);
                Close();
            }
        }

        private void Hata(Exception ex)
        {
            TxtDurum.Text = "İşlem başarısız: " + ex.Message;
            MessageBox.Show(ex.Message, "MiapaxERP | İşlem Yapılamadı", MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        private DataTable Oku(string sql)
        {
            using var con = Baglan(); using var cmd = Komut(con, null, sql);
            using var dr = cmd.ExecuteReader(); var tablo = new DataTable(); tablo.Load(dr);
            return tablo;
        }

        // Stok fiyat kartından seçilen müşteri türüne göre önerilen fiyatı yükler.
        // Fiyat kaydı yoksa boş bırakır; sıfır fiyatla yanlışlıkla teklif oluşturmaz.
        private void TeklifUrun_Degisti(object sender, SelectionChangedEventArgs e) => TeklifOnerilenFiyatiYukle();
        private void TeklifFiyatTipi_Degisti(object sender, SelectionChangedEventArgs e) => TeklifOnerilenFiyatiYukle();

        private void TeklifOnerilenFiyatiYukle()
        {
            if (!ekranHazir || CmbTeklifUrun.SelectedValue is not int stokId) return;
            try
            {
                using var con = Baglan();
                YetkiZorunlu(con, null, "STOCK.VIEW");
                using var cmd = Komut(con, null, @"SELECT BayiSatisFiyati, PerakendeSatisFiyati, ParaBirimi
FROM dbo.StokFiyatlari WHERE StokKartId=@StokId;");
                cmd.Parameters.Add("@StokId", SqlDbType.Int).Value = stokId;
                using var reader = cmd.ExecuteReader();
                if (!reader.Read()) { TxtTeklifFiyat.Clear(); return; }
                string pb = reader.IsDBNull(2) ? "TRY" : reader.GetString(2).Trim();
                if (!string.Equals(pb, "TRY", StringComparison.OrdinalIgnoreCase))
                {
                    TxtTeklifFiyat.Clear();
                    TxtDurum.Text = "Bu ürünün fiyatı " + pb + ". Teklifler TRY olduğundan otomatik fiyat atanmadı.";
                    return;
                }
                int col = CmbTeklifFiyatTipi.SelectedIndex == 1 ? 1 : 0;
                TxtTeklifFiyat.Text = reader.IsDBNull(col) ? "" :
                    reader.GetDecimal(col).ToString("0.####", Tr);
            }
            catch (SqlException ex) when (ex.Number == 208)
            {
                TxtTeklifFiyat.Clear();
                TxtDurum.Text = "Fiyat tablosu bulunamadı. Önce 04_Ek_Ozellikler_Guvenli_Migrasyon.sql çalıştırılmalı.";
            }
            catch (Exception ex)
            {
                TxtTeklifFiyat.Clear();
                TxtDurum.Text = "Önerilen fiyat yüklenemedi: " + ex.Message;
            }
        }

        private void ListeleriYukle()
        {
            using var con = Baglan();
            if (Yetki(con, null, "CUSTOMER.VIEW"))
            {
                var cariler = Oku("SELECT Id, CariKodu + N' - ' + Unvan AS Secim FROM dbo.CariKartlari WHERE Aktif=1 ORDER BY Unvan;");
                Bagla(CmbTeklifCari, cariler); Bagla(CmbSatisCari, cariler.Copy());
                Bagla(CmbEfaturaCari, cariler.Copy());
                var secmeli = cariler.Clone();
                secmeli.Rows.Add(0, NakitBosSecenek());
                foreach (DataRow r in cariler.Rows) secmeli.ImportRow(r);
                Bagla(CmbMasrafCari, secmeli);
                CmbMasrafCari.SelectedIndex = 0;
            }
            if (Yetki(con, null, "STOCK.VIEW"))
            {
                var urunler = Oku("SELECT Id, StokKodu + N' - ' + StokAdi + N' (' + Birim + N')' AS Secim FROM dbo.StokKartlari WHERE Aktif=1 ORDER BY StokAdi;");
                Bagla(CmbTeklifUrun, urunler); Bagla(CmbSatisUrun, urunler.Copy());
            }
            if (Yetki(con, null, "FINANCE.VIEW"))
            {
                var hesaplar = Oku("SELECT Id, HesapAdi + N' (' + ParaBirimi + N')' AS Secim, ParaBirimi FROM dbo.FinansHesaplari WHERE Aktif=1 ORDER BY HesapAdi;");
                Bagla(CmbNakitHesap, hesaplar);
                var tryHesaplar = hesaplar.Clone();
                foreach (DataRow r in hesaplar.Rows) if (Convert.ToString(r["ParaBirimi"]) == "TRY") tryHesaplar.ImportRow(r);
                Bagla(CmbMasrafHesap, tryHesaplar);
            }
            TeklifleriListele(); SatislariListele(); NakitiListele(); MasraflariListele(); EfaturalariListele();
        }

        private static string NakitBosSecenek() => "(Cari seçilmedi)";

        private void YeniBelgeNo(string tur)
        {
            var no = (tur == "T" ? "TK-" : "ST-") + DateTime.Now.ToString("yyyyMMdd-HHmmss-fff", CultureInfo.InvariantCulture);
            if (tur == "T") TxtTeklifNo.Text = no;
            else TxtSatisNo.Text = no;
        }

        private static decimal Yuvarla(decimal d) => decimal.Round(d, 2, MidpointRounding.AwayFromZero);

        private void KalemEkle(DataTable tablo, ComboBox cmbUrun, TextBox txtMiktar,
            TextBox txtFiyat, ComboBox cmbKdv)
        {
            int stokId = Secili(cmbUrun, "Ürün");
            decimal miktar = Miktar(txtMiktar.Text);
            decimal fiyat = Para(txtFiyat.Text);
            decimal kdv = KdvSec(cmbKdv);
            string urun = (cmbUrun.SelectedItem as DataRowView)?["Secim"]?.ToString() ?? "";
            string birim = urun.EndsWith(")") && urun.Contains('(')
                ? urun.Substring(urun.LastIndexOf('(') + 1).TrimEnd(')') : "Adet";
            decimal ara = Yuvarla(miktar * fiyat);
            decimal kdvTutar = Yuvarla(ara * kdv / 100m);
            decimal toplam = ara + kdvTutar;
            if (ara <= 0m || toplam > 999999999999m) throw new ArgumentException("Satır tutarı geçersiz veya çok büyük.");
            tablo.Rows.Add(stokId, urun, birim, miktar, fiyat, kdv, ara, kdvTutar, toplam);
            txtMiktar.Clear(); txtFiyat.Clear();
            ToplamlariYenile();
        }

        private static void KalemCikar(DataGrid grid, DataTable tablo)
        {
            if (grid.SelectedItem is DataRowView r) tablo.Rows.Remove(r.Row);
        }

        private void ToplamlariYenile()
        {
            if (TxtTeklifToplam == null || TxtSatisToplam == null) return;
            TxtTeklifToplam.Text = ToplamMetni(teklifKalemleri, TxtTeklifIndirim?.Text);
            TxtSatisToplam.Text = ToplamMetni(satisKalemleri, TxtSatisIndirim?.Text);
        }

        private static string ToplamMetni(DataTable table, string? indirim)
        {
            decimal ara = table.AsEnumerable().Sum(r => r.Field<decimal>("AraToplam"));
            decimal kdv = table.AsEnumerable().Sum(r => r.Field<decimal>("KdvTutari"));
            bool gecerli = SayiyiOku(indirim ?? "0", 2, true, out var dus);
            return "Ara toplam: " + ara.ToString("N2", Tr) + " ₺  |  KDV: " + kdv.ToString("N2", Tr) +
                " ₺  |  Genel toplam: " + (gecerli ? (ara + kdv - dus).ToString("N2", Tr) + " ₺" : "İndirim hatalı");
        }

        private void TeklifKalemEkle_Click(object sender, RoutedEventArgs e)
        { try { KalemEkle(teklifKalemleri, CmbTeklifUrun, TxtTeklifMiktar, TxtTeklifFiyat, CmbTeklifKdv); } catch (Exception ex) { Hata(ex); } }
        private void SatisKalemEkle_Click(object sender, RoutedEventArgs e)
        { try { KalemEkle(satisKalemleri, CmbSatisUrun, TxtSatisMiktar, TxtSatisFiyat, CmbSatisKdv); } catch (Exception ex) { Hata(ex); } }
        private void TeklifKalemCikar_Click(object sender, RoutedEventArgs e) { KalemCikar(GridTeklifKalemler, teklifKalemleri); ToplamlariYenile(); }
        private void SatisKalemCikar_Click(object sender, RoutedEventArgs e) { KalemCikar(GridSatisKalemler, satisKalemleri); ToplamlariYenile(); }
        private void TeklifIndirimDegisti(object sender, TextChangedEventArgs e) => ToplamlariYenile();
        private void SatisIndirimDegisti(object sender, TextChangedEventArgs e) => ToplamlariYenile();

        private void BelgeKaydet(bool teklif)
        {
            var tablo = teklif ? teklifKalemleri : satisKalemleri;
            if (tablo.Rows.Count == 0) throw new ArgumentException("Önce en az bir ürün kalemi ekleyin.");
            string belgeNo = (teklif ? TxtTeklifNo.Text : TxtSatisNo.Text).Trim();
            if (belgeNo.Length == 0 || belgeNo.Length > 80) throw new ArgumentException("Belge numarası 1–80 karakter olmalıdır.");
            int cari = Secili(teklif ? CmbTeklifCari : CmbSatisCari, "Müşteri / Cari");
            DateTime tarih = Tarih(teklif ? DpTeklifTarih : DpSatisTarih);
            DateTime? son = teklif ? Tarih(DpTeklifGecerlilik) : null;
            if (son.HasValue && son < tarih) throw new ArgumentException("Teklif geçerlilik tarihi teklif tarihinden önce olamaz.");
            decimal ara = tablo.AsEnumerable().Sum(r => r.Field<decimal>("AraToplam"));
            decimal kdv = tablo.AsEnumerable().Sum(r => r.Field<decimal>("KdvTutari"));
            decimal indirim = Para((teklif ? TxtTeklifIndirim : TxtSatisIndirim).Text, true);
            decimal toplam = ara + kdv - indirim;
            if (indirim > ara + kdv || toplam <= 0 || toplam > 999999999999m)
                throw new ArgumentException("İndirim genel toplamı sıfır veya negatif yapamaz.");
            string aciklama = (teklif ? TxtTeklifAciklama : TxtSatisAciklama).Text.Trim();
            string odeme = teklif ? "" : (CmbSatisOdeme.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Ödenmedi";
            if (MessageBox.Show(belgeNo + " için " + toplam.ToString("N2", Tr) + " ₺ tutarında " +
                (teklif ? "teklif" : "satış belgesi") + " kaydedilsin mi?\n\nSatışta stok, cari ve muhasebe birlikte işlenir. Tahsilat bilgileri sonraki panelde alınır.",
                "Kayıt Onayı", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
            var service=new IsletmeServisi(baglantiAdresi,kullaniciId);
            decimal belgeKuru=1,tahsilatKuru=1,tahsilat=0;int? tahsilatHesabi=null;
            if(!teklif)
            {
                var owner=Window.GetWindow(this);var payment=new IsletmeForm(owner,"Satış ve tahsilat");
                payment.Note("Satış kaydı stok, cari ve muhasebeyi birlikte işler. Tahsilat yapıldıysa gerçek hesabı ve tutarı girin; yapılmadıysa tutarı 0 bırakın.");
                payment.Number("rate","Belge kuru (1 PARA = kaç TRY)",1);
                payment.Select("account","Tahsilat hesabı (tahsilat varsa)",service.Secimler("hesap"));
                payment.Number("paid","Tahsil edilen tutar (belge para biriminde)",0);
                payment.Number("payrate","Tahsilat kuru (1 PARA = kaç TRY)",1);
                if(payment.ShowDialog()!=true)return;belgeKuru=payment.N("rate");tahsilat=payment.N("paid");tahsilatKuru=payment.N("payrate");if(tahsilat>0)tahsilatHesabi=payment.I("account");
            }
            var input=new SatisGirdisi(Guid.NewGuid(),teklif,belgeNo,cari,tarih,son,"TRY",belgeKuru,indirim,aciklama,teklif?null:kaynakTeklifId,
                tablo.AsEnumerable().Select(r=>new SatisKalemi(r.Field<int>("StokKartId"),r.Field<decimal>("Miktar"),r.Field<decimal>("Fiyat"),r.Field<decimal>("Kdv"))).ToArray(),tahsilatHesabi,tahsilat,tahsilatKuru);
            service.SatisKaydet(input);
            if (teklif) { TeklifFormTemizle(); TeklifleriListele(); }
            else { SatisFormTemizle(); SatislariListele(); }
            TxtDurum.Text = (teklif ? "Teklif" : "Satış") + " kaydedildi: " + belgeNo +
                (teklif?". Teklif kaydı stok ve cari bakiyesini etkilemez.":". Stok, cari, muhasebe ve girilen tahsilat birlikte kaydedildi.");
        }

        private void TeklifKaydet_Click(object sender, RoutedEventArgs e) { try { BelgeKaydet(true); } catch (Exception ex) { Hata(ex); } }
        private void SatisKaydet_Click(object sender, RoutedEventArgs e) { try { BelgeKaydet(false); } catch (Exception ex) { Hata(ex); } }
        private void TeklifYeni_Click(object sender, RoutedEventArgs e) => TeklifFormTemizle();
        private void SatisYeni_Click(object sender, RoutedEventArgs e) => SatisFormTemizle();
        private void TeklifListeYenile_Click(object sender, RoutedEventArgs e) { try { TeklifleriListele(); } catch (Exception ex) { Hata(ex); } }
        private void SatisListeYenile_Click(object sender, RoutedEventArgs e) { try { SatislariListele(); } catch (Exception ex) { Hata(ex); } }

        private void TeklifFormTemizle()
        {
            teklifKalemleri.Clear(); YeniBelgeNo("T"); CmbTeklifCari.SelectedIndex = -1;
            TxtTeklifMiktar.Clear(); TxtTeklifFiyat.Clear(); TxtTeklifAciklama.Clear();
            TxtTeklifIndirim.Text = "0"; ToplamlariYenile();
        }
        private void SatisFormTemizle()
        {
            satisKalemleri.Clear(); YeniBelgeNo("S"); CmbSatisCari.SelectedIndex = -1;
            TxtSatisMiktar.Clear(); TxtSatisFiyat.Clear(); TxtSatisAciklama.Clear();
            TxtSatisIndirim.Text = "0"; kaynakTeklifId = null;
            CmbSatisOdeme.SelectedIndex = 0; ToplamlariYenile();
        }

        private void TeklifleriListele()
        {
            using var con = Baglan(); if (!Yetki(con, null, "CUSTOMER.VIEW")) { GridTeklifler.ItemsSource = null; return; }
            GridTeklifler.ItemsSource = Oku(@"SELECT TOP(300) b.Id,b.BelgeNo AS TeklifNo,c.Unvan,b.Tarih,b.GecerlilikTarihi AS Gecerlilik,
b.GenelToplam,b.Durum FROM dbo.BoruERP_YeniBelgeler b INNER JOIN dbo.CariKartlari c ON c.Id=b.CariId
WHERE b.BelgeTuru=N'T' ORDER BY b.Id DESC;").DefaultView;
        }
        private void SatislariListele()
        {
            using var con = Baglan(); if (!Yetki(con, null, "CUSTOMER.VIEW")) { GridSatislar.ItemsSource = null; return; }
            GridSatislar.ItemsSource = Oku(@"SELECT TOP(300) b.Id,b.BelgeNo AS SatisNo,c.Unvan,b.Tarih,b.GenelToplam,b.OdemeDurumu
FROM dbo.BoruERP_YeniBelgeler b INNER JOIN dbo.CariKartlari c ON c.Id=b.CariId
WHERE b.BelgeTuru=N'S' ORDER BY b.Id DESC;").DefaultView;
        }

        private void TeklifSatisAktar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (GridTeklifler.SelectedItem is not DataRowView r)
                    throw new ArgumentException("Önce listeden bir teklif seçin.");
                long teklifId = Convert.ToInt64(r["Id"]);
                using var con = Baglan();
                YetkiZorunlu(con, null, "CUSTOMER.VIEW");
                using (var kontrol = Komut(con, null, "SELECT COUNT_BIG(*) FROM dbo.BoruERP_YeniBelgeler WHERE BelgeTuru=N'S' AND KaynakTeklifId=@Id;"))
                {
                    kontrol.Parameters.Add("@Id", SqlDbType.BigInt).Value = teklifId;
                    if (Convert.ToInt64(kontrol.ExecuteScalar()) > 0)
                        throw new InvalidOperationException("Bu tekliften daha önce satış kaydedilmiş. Çift satış oluşturmamak için aktarım engellendi.");
                }
                long cariId; decimal indirim; string aciklama;
                using (var cmd = Komut(con, null, "SELECT CariId,Indirim,Aciklama FROM dbo.BoruERP_YeniBelgeler WHERE Id=@Id AND BelgeTuru=N'T';"))
                {
                    cmd.Parameters.Add("@Id", SqlDbType.BigInt).Value = teklifId;
                    using var dr = cmd.ExecuteReader();
                    if (!dr.Read()) throw new InvalidOperationException("Teklif bulunamadı.");
                    cariId = dr.GetInt32(0); indirim = dr.GetDecimal(1);
                    aciklama = dr.IsDBNull(2) ? "" : dr.GetString(2);
                }
                var detay = new DataTable();
                using (var cmd = Komut(con, null, @"SELECT StokKartId,UrunAciklama,Birim,Miktar,BirimFiyat,KdvOrani,SatirAraToplam,KdvTutari,SatirGenelToplam
FROM dbo.BoruERP_YeniBelgeKalemleri WHERE BelgeId=@Id ORDER BY Id;"))
                {
                    cmd.Parameters.Add("@Id", SqlDbType.BigInt).Value = teklifId;
                    using var dr = cmd.ExecuteReader(); detay.Load(dr);
                }
                if (detay.Rows.Count == 0) throw new InvalidOperationException("Teklifte ürün kalemi yok.");
                SatisFormTemizle();
                foreach (DataRow k in detay.Rows)
                    satisKalemleri.Rows.Add(k["StokKartId"], k["UrunAciklama"], k["Birim"],
                        k["Miktar"], k["BirimFiyat"], k["KdvOrani"], k["SatirAraToplam"],
                        k["KdvTutari"], k["SatirGenelToplam"]);
                CmbSatisCari.SelectedValue = Convert.ToInt32(cariId);
                TxtSatisIndirim.Text = indirim.ToString("0.##", Tr);
                TxtSatisAciklama.Text = aciklama;
                kaynakTeklifId = teklifId;
                IslemSekmeleri.SelectedIndex = 1;
                ToplamlariYenile();
                TxtDurum.Text = "Teklif satış formuna aktarıldı. Kaydetmeden stok/cari değişmez.";
            }
            catch (Exception ex) { Hata(ex); }
        }

        private void NakitKaydet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int hesap = Secili(CmbNakitHesap, "Kasa / banka hesabı");
                string yon = (CmbNakitYon.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "";
                if (yon != "Giriş" && yon != "Çıkış") throw new ArgumentException("Hareket yönünü seçin.");
                decimal tutar = Para(TxtNakitTutar.Text);
                DateTime tarih = Tarih(DpNakitTarih);
                string aciklama = TxtNakitAciklama.Text.Trim();
                if (aciklama.Length == 0) throw new ArgumentException("Açıklama girin.");
                if (MessageBox.Show(yon + " / " + tutar.ToString("N2", Tr) + " tutarı kasa/banka hesabına işlensin mi?",
                    "Nakit Hareketi", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
                new IsletmeServisi(baglantiAdresi,kullaniciId).NakitKaydet(hesap,yon,tutar,tarih,aciklama);
                TxtNakitTutar.Clear(); TxtNakitAciklama.Clear(); NakitiListele();
                TxtDurum.Text = "Kasa/banka hareketi kaydedildi. Eski Muhasebe ekranında da görünecek.";
            }
            catch (Exception ex) { Hata(ex); }
        }

        private void NakitiListele()
        {
            using var con = Baglan(); if (!Yetki(con, null, "FINANCE.VIEW")) { GridNakit.ItemsSource = null; GridNakitBakiyeler.ItemsSource = null; return; }
            GridNakitBakiyeler.ItemsSource = Oku(@"SELECT h.HesapAdi,h.HesapTipi,h.ParaBirimi,
COALESCE(SUM(CASE WHEN f.HareketTipi=N'Giriş' THEN f.Tutar WHEN f.HareketTipi=N'Çıkış' THEN -f.Tutar ELSE 0 END),0) AS Bakiye
FROM dbo.FinansHesaplari h LEFT JOIN dbo.FinansHareketleri f ON f.HesapId=h.Id
WHERE h.Aktif=1 GROUP BY h.Id,h.HesapAdi,h.HesapTipi,h.ParaBirimi ORDER BY h.HesapAdi;").DefaultView;
            GridNakit.ItemsSource = Oku(@"SELECT TOP(300) f.Tarih,h.HesapAdi,f.HareketTipi,f.Tutar,h.ParaBirimi,f.Aciklama
FROM dbo.FinansHareketleri f INNER JOIN dbo.FinansHesaplari h ON h.Id=f.HesapId ORDER BY f.Id DESC;").DefaultView;
        }
        private void NakitYenile_Click(object sender, RoutedEventArgs e) { try { NakitiListele(); } catch (Exception ex) { Hata(ex); } }

        private void MasrafOdemeDegisti(object sender, RoutedEventArgs e)
        {
            if (CmbMasrafHesap != null) CmbMasrafHesap.IsEnabled = ChkMasrafOdendi.IsChecked == true;
        }

        private void MasrafKaydet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DateTime tarih = Tarih(DpMasrafTarih);
                string kategori = CmbMasrafKategori.Text.Trim();
                if (kategori.Length == 0 || kategori.Length > 100) throw new ArgumentException("Masraf kategorisi 1–100 karakter olmalıdır.");
                decimal tutar = Para(TxtMasrafTutar.Text);
                int? cariId = CmbMasrafCari.SelectedValue is int cid && cid > 0 ? cid : null;
                bool odendi = ChkMasrafOdendi.IsChecked == true;
                int? hesapId = odendi ? Secili(CmbMasrafHesap, "Ödeme yapılacak TRY hesabı") : null;
                string aciklama = TxtMasrafAciklama.Text.Trim();
                if (MessageBox.Show(kategori + " için " + tutar.ToString("N2", Tr) + " ₺ masraf kaydedilsin mi?" +
                        (odendi ? "\nSeçili kasa/banka hesabından ÇIKIŞ da kaydedilir." : "\nKasa hareketi oluşturulmaz."),
                        "Masraf Onayı", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
                new IsletmeServisi(baglantiAdresi,kullaniciId).MasrafKaydet(tarih,kategori,tutar,cariId,odendi,hesapId,aciklama);
                TxtMasrafTutar.Clear(); TxtMasrafAciklama.Clear(); ChkMasrafOdendi.IsChecked = false;
                MasraflariListele(); NakitiListele(); TxtDurum.Text = "Masraf kaydedildi.";
            }
            catch (Exception ex) { Hata(ex); }
        }

        private void MasraflariListele()
        {
            using var con = Baglan(); if (!Yetki(con, null, "FINANCE.VIEW")) { GridMasraf.ItemsSource = null; return; }
            GridMasraf.ItemsSource = Oku(@"SELECT TOP(300) m.Tarih,m.Kategori,c.Unvan,m.Tutar,
CASE WHEN m.FinansHareketId IS NULL THEN N'Ödenmedi' ELSE N'Ödendi' END AS OdemeDurumu,m.Aciklama
FROM dbo.BoruERP_YeniMasraflar m LEFT JOIN dbo.CariKartlari c ON c.Id=m.CariId ORDER BY m.Id DESC;").DefaultView;
        }
        private void MasrafYenile_Click(object sender, RoutedEventArgs e) { try { MasraflariListele(); } catch (Exception ex) { Hata(ex); } }

        private void EfaturaHesapDegisti(object sender, TextChangedEventArgs e)
        {
            if (TxtEfaturaToplam == null || TxtEfaturaMatrah == null || TxtEfaturaKdv == null) return;
            bool a = SayiyiOku(TxtEfaturaMatrah.Text, 2, false, out var matrah);
            bool b = SayiyiOku(TxtEfaturaKdv.Text, 2, true, out var kdv);
            TxtEfaturaToplam.Text = a && b ? (matrah + kdv).ToString("N2", Tr) + " ₺" : "Miktarları kontrol edin";
        }

        private void EfaturaKaydet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string no = TxtEfaturaNo.Text.Trim();
                if (no.Length == 0 || no.Length > 80) throw new ArgumentException("Fatura numarası 1–80 karakter olmalıdır.");
                int cari = Secili(CmbEfaturaCari, "Tedarikçi / Cari");
                DateTime tarih = Tarih(DpEfaturaTarih);
                DateTime? vade = DpEfaturaVade.SelectedDate?.Date;
                if (vade.HasValue && vade.Value < tarih) throw new ArgumentException("Vade tarihi fatura tarihinden önce olamaz.");
                decimal matrah = Para(TxtEfaturaMatrah.Text);
                decimal kdv = Para(TxtEfaturaKdv.Text, true);
                decimal toplam = matrah + kdv;
                if (toplam > 999999999999m) throw new ArgumentException("Fatura toplamı çok yüksek.");
                string aciklama = TxtEfaturaAciklama.Text.Trim();
                if (MessageBox.Show(no + " numaralı gelen e-fatura " + toplam.ToString("N2", Tr) +
                    " ₺ tutarla MANUEL kayıt edilsin mi?\nCari/kasa hareketi otomatik yapılmaz.",
                    "Manuel Gelen E-Fatura", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
                new IsletmeServisi(baglantiAdresi,kullaniciId).ManuelGelenFatura(no,cari,tarih,vade,matrah,kdv,toplam,aciklama);
                TxtEfaturaNo.Clear(); TxtEfaturaMatrah.Clear(); TxtEfaturaKdv.Clear(); TxtEfaturaAciklama.Clear();
                EfaturalariListele(); TxtDurum.Text = "Gelen e-fatura yalnızca manuel iç kayıt olarak saklandı.";
            }
            catch (Exception ex) { Hata(ex); }
        }

        private void EfaturalariListele()
        {
            using var con = Baglan(); if (!Yetki(con, null, "FINANCE.VIEW")) { GridEfaturalar.ItemsSource = null; return; }
            GridEfaturalar.ItemsSource = Oku(@"SELECT TOP(300) e.FaturaNo,c.Unvan,e.FaturaTarihi,e.VadeTarihi,e.Matrah,e.Kdv,e.GenelToplam
FROM dbo.BoruERP_GelenEFaturalar e INNER JOIN dbo.CariKartlari c ON c.Id=e.CariId ORDER BY e.Id DESC;").DefaultView;
        }
        private void EfaturaYenile_Click(object sender, RoutedEventArgs e) { try { EfaturalariListele(); } catch (Exception ex) { Hata(ex); } }

        private void IslemSekmeleri_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (!ekranHazir || e.Source != IslemSekmeleri) return;
            try
            {
                if (IslemSekmeleri.SelectedIndex == 0) TeklifleriListele();
                else if (IslemSekmeleri.SelectedIndex == 1) SatislariListele();
                else { NakitiListele(); MasraflariListele(); EfaturalariListele(); }
            }
            catch (Exception ex) { TxtDurum.Text = "Yükleme uyarısı: " + ex.Message; }
        }
    }
}
