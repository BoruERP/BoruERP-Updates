SET XACT_ABORT ON;
BEGIN TRANSACTION;
DECLARE @lock int;
EXEC @lock=sys.sp_getapplock @Resource=N'MiapaxERP.Ticaret170',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=15000;
IF @lock<0 THROW 51000,N'Kurulum kilidi alınamadı.',1;
IF OBJECT_ID('dbo.BERP_TicaretDosya','U') IS NULL
CREATE TABLE dbo.BERP_TicaretDosya(
 Id bigint IDENTITY PRIMARY KEY, Modul varchar(10) NOT NULL, Referans nvarchar(80) NOT NULL,
 Tur nvarchar(40) NOT NULL, Firma nvarchar(160) NOT NULL, Baslik nvarchar(180) NOT NULL,
 Sorumlu nvarchar(100) NOT NULL, Tarih date NOT NULL, Vade date NOT NULL,
 Tutar decimal(18,2) NOT NULL CHECK(Tutar>=0), Doviz char(3) NOT NULL,
 Durum nvarchar(50) NOT NULL, Detay nvarchar(max) NOT NULL, Aciklama nvarchar(2000) NOT NULL,
 Surum rowversion, UNIQUE(Modul,Referans), CHECK(Modul IN ('CRM','ECOM','TRADE')));
IF OBJECT_ID('dbo.BERP_TicaretOlay','U') IS NULL
CREATE TABLE dbo.BERP_TicaretOlay(
 Id bigint IDENTITY PRIMARY KEY, DosyaId bigint NOT NULL REFERENCES dbo.BERP_TicaretDosya(Id),
 Zaman datetime2 NOT NULL DEFAULT SYSDATETIME(), KullaniciId int NOT NULL, Olay nvarchar(350) NOT NULL);
IF OBJECT_ID('dbo.Yetkiler','U') IS NOT NULL
INSERT dbo.Yetkiler(YetkiKodu,Modul,Islem,Aciklama,Aktif)
SELECT m.Kod+'.'+p.Kod,m.Ad,p.Ad,m.Ad+' '+p.Ad,1
FROM (VALUES('CRM',N'CRM'),('ECOM',N'E-ticaret'),('TRADE',N'Dış ticaret')) m(Kod,Ad)
CROSS JOIN (VALUES('VIEW',N'Görüntüle'),('EDIT',N'Kaydet')) p(Kod,Ad)
WHERE NOT EXISTS(SELECT 1 FROM dbo.Yetkiler WHERE YetkiKodu=m.Kod+'.'+p.Kod);
COMMIT;
