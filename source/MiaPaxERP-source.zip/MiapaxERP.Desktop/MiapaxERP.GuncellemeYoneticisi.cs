using System;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using MiapaxERP.Guncelleme;

namespace MiapaxERP.Desktop;

internal sealed class GuncellemeManifesti
{
    public string Version { get; set; } = "";
    public string Channel { get; set; } = "";
    public string PackageUrl { get; set; } = "";
    public string Sha256 { get; set; } = "";
    public string Signature { get; set; } = "";
}

internal sealed class GuncellemeAyarlari
{
    public string ManifestUrl { get; set; } = "";
    public string Channel { get; set; } = "Yan";
    public int CheckMinutes { get; set; } = 30;
}

internal static class MiapaxERPGuncelleme
{
    private static bool GelistirmeSurumu { get {
#if DEBUG
        return true;
#else
        return false;
#endif
    } }

    private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(45) };
    private static readonly string Local = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "BoruERP", "Guncelleme",
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(Path.GetFullPath(AppContext.BaseDirectory).TrimEnd('\\', '/').ToUpperInvariant())))[..16]);
    private static readonly string PendingFile = Path.Combine(Local, "pending.json");
    private static int busy;
    private static readonly CancellationTokenSource Kapanis = new();
    private static Version Normalize(Version v) => new(v.Major, v.Minor, Math.Max(0, v.Build), Math.Max(0, v.Revision));
    public static bool IndirmeHazir
    {
        get
        {
            try
            {
                if (!File.Exists(PendingFile) || !File.Exists(Path.Combine(Local, "paket.zip"))) return false;
                var m = JsonSerializer.Deserialize<GuncellemeManifesti>(File.ReadAllText(PendingFile));
                var a = JsonSerializer.Deserialize<GuncellemeAyarlari>(File.ReadAllText(GuncellemeKanalAyari.DosyaYolu(AppContext.BaseDirectory)));
                if (m == null || a == null || !string.Equals(m.Channel, a.Channel, StringComparison.OrdinalIgnoreCase) ||
                    !Version.TryParse(m.Version, out var remote) ||
                    Normalize(remote) <= Normalize(typeof(MiapaxERPGuncelleme).Assembly.GetName().Version ?? new Version(0, 0))) return false;
                ImzayiKontrolEt(m);
                return true;
            }
            catch { return false; }
        }
    }

    // Dakika ayarı, dosya eksik/hatalı olsa bile uygulama açılmasını engellemez.
    public static TimeSpan KontrolAraligi
    {
        get
        {
            try
            {
                string file = GuncellemeKanalAyari.DosyaYolu(AppContext.BaseDirectory);
                if (!File.Exists(file)) return TimeSpan.FromMinutes(30);
                var a = JsonSerializer.Deserialize<GuncellemeAyarlari>(File.ReadAllText(file));
                return TimeSpan.FromMinutes(Math.Clamp(a?.CheckMinutes ?? 30, 5, 1440));
            }
            catch { return TimeSpan.FromMinutes(30); }
        }
    }


    private static void Log(string text)
    {
        try
        {
            Directory.CreateDirectory(Local);
            File.AppendAllText(Path.Combine(Local, "guncelleme.log"),
                DateTimeOffset.Now.ToString("O") + " | " + text + Environment.NewLine);
        }
        catch { /* Güncelleme kaydı uygulamayı kapatmamalı. */ }
    }

    public static string SonDurum { get; private set; } = "Henüz kontrol edilmedi.";
    public static async Task KontrolEtAsync(bool manuel = false)
    {
if (GelistirmeSurumu) { SonDurum = "Geliştirme (Debug) sürümü Visual Studio üzerinden derlenir. Otomatik güncelleme yalnız yayımlanmış Release kurulumlarında kullanılabilir.";
            return; }

        if (Interlocked.Exchange(ref busy, 1) == 1) { SonDurum = "Güncelleme kontrolü zaten sürüyor."; return; }
        SonDurum = "Güncelleme kontrol ediliyor.";
        try
        {
            Directory.CreateDirectory(Local);
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(Kapanis.Token);
            timeout.CancelAfter(TimeSpan.FromMinutes(10));
            var cancellation = timeout.Token;
            if (!manuel && File.Exists(Path.Combine(Local,"paused"))) { SonDurum = "Önceki sürüme dönüş sonrası otomatik güncelleme duraklatıldı."; return; }
            if (manuel) File.Delete(Path.Combine(Local,"paused"));
            // Henüz yayın adresi/anahtarı yoksa sessizce geç; ilk kurulum zarar görmez.
            string configPath = GuncellemeKanalAyari.DosyaYolu(AppContext.BaseDirectory);
            if (!File.Exists(configPath) || GuncellemeAnahtari.Pem.Contains("PUBLIC_KEY_NOT_CONFIGURED")) throw new InvalidOperationException("Güncelleme yapılandırması veya yayıncı anahtarı eksik.");
            var config = JsonSerializer.Deserialize<GuncellemeAyarlari>(await File.ReadAllTextAsync(configPath));
            if (config == null || string.IsNullOrWhiteSpace(config.ManifestUrl)) throw new InvalidOperationException("Manifest adresi eksik.");
            if (!Uri.TryCreate(config.ManifestUrl, UriKind.Absolute, out var manifestUri) ||
                manifestUri.Scheme != Uri.UriSchemeHttps)
                throw new InvalidOperationException("Güncelleme adresi HTTPS olmalıdır.");

            string json = await Http.GetStringAsync(manifestUri, cancellation);
            if (json.Length > 20_000) throw new InvalidOperationException("Güncelleme bildirimi çok büyük.");
            var m = JsonSerializer.Deserialize<GuncellemeManifesti>(json)
                ?? throw new InvalidDataException("Güncelleme bildirimi boş.");
            if (!string.Equals(m.Channel, config.Channel, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Manifest ana/yan PC kanalıyla eşleşmiyor.");
            if (!Version.TryParse(m.Version, out var remote)) throw new InvalidDataException("Sürüm geçersiz.");
            var installed = typeof(MiapaxERPGuncelleme).Assembly.GetName().Version ?? new Version(0, 0);
            if (Normalize(remote) <= Normalize(installed)) { SonDurum = "Program güncel. Kurulu sürüm: " + installed; return; }
            if (!File.Exists(Path.Combine(AppContext.BaseDirectory, "MiapaxERP.Updater.exe")))
                throw new InvalidOperationException("Güncelleyici dosyası eksik (MiapaxERP.Updater.exe). Bu kurulum onarılmadan güncelleme yüklenemez. Programı kapatmanız sorunu çözmez.");
            ImzayiKontrolEt(m);
            if (!Uri.TryCreate(m.PackageUrl, UriKind.Absolute, out var downloadUri) ||
                downloadUri.Scheme != Uri.UriSchemeHttps)
                throw new InvalidDataException("Güncelleme paket adresi HTTPS olmalıdır.");
            if (File.Exists(PendingFile))
            {
                var previous = JsonSerializer.Deserialize<GuncellemeManifesti>(await File.ReadAllTextAsync(PendingFile));
                if (previous != null && Canonical(previous) == Canonical(m) &&
                    File.Exists(Path.Combine(Local, "paket.zip")))
                {
                    await using var cached = File.OpenRead(Path.Combine(Local, "paket.zip"));
                    if (Convert.ToHexString(await SHA256.HashDataAsync(cached, cancellation)).Equals(m.Sha256, StringComparison.OrdinalIgnoreCase))
                    {
                        SonDurum = "Doğrulanmış güncelleme hazır. Programı kapatınca kurulacak.";
                        return;
                    }
                }
            }
            Directory.CreateDirectory(Local);
            string temp = Path.Combine(Local, "indiriliyor.tmp");
            using (var response = await Http.GetAsync(downloadUri, HttpCompletionOption.ResponseHeadersRead, cancellation))
            {
                response.EnsureSuccessStatusCode();
                if (response.Content.Headers.ContentLength > 500L * 1024 * 1024)
                    throw new InvalidDataException("Güncelleme paketi 500MB üstü olamaz.");
                await using var src = await response.Content.ReadAsStreamAsync(cancellation);
                await using var dest = File.Create(temp);
                byte[] buf = new byte[65536];
                long total = 0;
                int bytes;
                while ((bytes = await src.ReadAsync(buf.AsMemory(), cancellation)) != 0)
                {
                    total += bytes;
                    if (total > 500L * 1024 * 1024) throw new InvalidDataException("Paket indirme sınırı aşıldı.");
                    await dest.WriteAsync(buf.AsMemory(0, bytes), cancellation);
                }
            }
            string hash;
            await using (var hashStream = File.OpenRead(temp))
                hash = Convert.ToHexString(await SHA256.HashDataAsync(hashStream, cancellation));
            if (!hash.Equals(m.Sha256, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Güncelleme paketi SHA256 doğrulamasını geçmedi.");
            File.Move(temp, Path.Combine(Local, "paket.zip"), true);
            // İmzalı manifest, yalnızca paket tam doğrulandıktan sonra pending olarak saklanır.
            await File.WriteAllTextAsync(PendingFile + ".tmp", JsonSerializer.Serialize(m));
            File.Move(PendingFile + ".tmp", PendingFile, true);
            SonDurum = "Doğrulanmış güncelleme hazır. Programı kapatınca kurulacak.";
            Log("İmzalı paket indirildi: " + m.Version + " (program kapanınca kurulum denenir)");
        }
        catch (Exception e) { SonDurum = "Güncelleme alınamadı: " + e.Message; Log(SonDurum); }
        finally { Interlocked.Exchange(ref busy, 0); }
    }

    public static void ImzayiKontrolEt(GuncellemeManifesti m)
    {
        if (m.Sha256.Length != 64 || !System.Text.RegularExpressions.Regex.IsMatch(m.Sha256, "^[a-fA-F0-9]{64}$"))
            throw new InvalidDataException("SHA256 biçimi geçersiz.");
        string payload = Canonical(m);
        using RSA rsa = RSA.Create();
        rsa.ImportFromPem(GuncellemeAnahtari.Pem);
        if (!rsa.VerifyData(Encoding.UTF8.GetBytes(payload), Convert.FromBase64String(m.Signature),
            HashAlgorithmName.SHA256, RSASignaturePadding.Pss))
            throw new CryptographicException("Güncelleme yayıncı imzası geçersiz.");
    }

    public static string Canonical(GuncellemeManifesti m) =>
        m.Version + "\n" + m.Channel + "\n" + m.PackageUrl + "\n" + m.Sha256.ToLowerInvariant() + "\n";

    private static bool geriDonus;
    public static void GeriDonusuHazirla()
    {
        if (!File.Exists(Path.Combine(Local, "previous.json")) &&
            !(Directory.Exists(Path.Combine(Local, "yedek")) && Directory.Exists(Path.Combine(Local, "acilan"))))
            throw new InvalidOperationException("Bu kurulumda önceki sürüm yedeği yok. İlk yeni güncelleme kurulduktan sonra geri dönüş kullanılabilir.");
        if(!File.Exists(Path.Combine(AppContext.BaseDirectory,"MiapaxERP.Updater.exe"))) throw new InvalidOperationException("Güncelleyici bulunamadı.");
        geriDonus=true;
    }
    public static void UygulamaKapanirken()
    {
if (GelistirmeSurumu) return;

        try
        {
            Kapanis.Cancel();
            // İndirme sürerken paket dosyaları değişebilir; kurulum sonraki açılışa ertelenir.
            if (Volatile.Read(ref busy) != 0) { Log("İndirme/kontrol sürerken kapanıldı; güncelleme ertelendi."); return; }
            if (!geriDonus && !IndirmeHazir) return;
            string updater = Path.Combine(AppContext.BaseDirectory, "MiapaxERP.Updater.exe");
            if (!File.Exists(updater)) { Log("Updater bulunamadı. Güncelleme ertelendi."); return; }
            Directory.CreateDirectory(Local);
            string tempUpdater = Path.Combine(Local, "MiapaxERP.Updater.exe");
            File.Copy(updater, tempUpdater, true);
            var psi = GuncelleyiciBaslatma.Olustur(tempUpdater, Local, AppContext.BaseDirectory,
                Process.GetCurrentProcess().Id, geriDonus ? Path.Combine(Local,"previous.json") : PendingFile,
                geriDonus, GuncelleyiciBaslatma.Yazilabilir(AppContext.BaseDirectory));
            Process.Start(psi);
        }
        catch (System.ComponentModel.Win32Exception e) when (e.NativeErrorCode == 1223)
        {
            Log("Windows yönetici izni onaylanmadı; güncelleme kurulmadı.");
            System.Windows.MessageBox.Show("Windows yönetici izni onaylanmadığı için güncelleme kurulmadı. Programı yeniden açıp güncellemeyi tekrar başlatabilirsiniz.", "MiapaxERP Güncelleme");
        }
        catch (Exception e) { Log("Güncelleyici açılamadı: " + e.Message); }
    }
}


