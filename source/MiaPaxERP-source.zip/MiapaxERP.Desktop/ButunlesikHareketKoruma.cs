using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop;
internal static class ButunlesikHareketKoruma
{
    internal static void Cari(SqlConnection c,SqlTransaction t,long id)
    {
        using var q=ErpModulServisi.Komut(c,t,"SELECT COUNT(*) FROM dbo.CariHareketleri WITH(UPDLOCK,HOLDLOCK) WHERE Id=@id AND Kaynak LIKE N'MPX310%'",("@id",id));
        if(Convert.ToInt32(q.ExecuteScalar())>0)throw new InvalidOperationException("Bu hareket otomatik satış, alış veya tahsilata bağlıdır. Düzeltmeyi kaynak işlem üzerinden yapın.");
    }
    internal static void Finans(SqlConnection c,SqlTransaction t,long id)
    {
        using var q=ErpModulServisi.Komut(c,t,"SELECT COUNT(*) FROM dbo.FinansHareketleri f WITH(UPDLOCK,HOLDLOCK) JOIN dbo.CariHareketleri h WITH(UPDLOCK,HOLDLOCK) ON h.Id=f.CariHareketId WHERE f.Id=@id AND h.Kaynak LIKE N'MPX310%'",("@id",id));
        if(Convert.ToInt32(q.ExecuteScalar())>0)throw new InvalidOperationException("Bu finans hareketi bütünleşik tahsilata bağlıdır. Düzeltmeyi kaynak işlem üzerinden yapın.");
    }
}
