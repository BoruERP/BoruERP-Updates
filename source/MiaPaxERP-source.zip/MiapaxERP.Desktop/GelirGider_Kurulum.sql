SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET ARITHABORT ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET NUMERIC_ROUNDABORT OFF;
SET XACT_ABORT ON;
BEGIN TRANSACTION;
DECLARE @lock int;
EXEC @lock=sys.sp_getapplock @Resource=N'BoruERP_GelirGider_Kurulum',@LockMode=N'Exclusive',@LockOwner=N'Transaction',@LockTimeout=15000;
IF @lock<0 THROW 51000,N'Kurulum kilidi alınamadı.',1;
SET XACT_ABORT ON;
IF OBJECT_ID(N'dbo.FinansHareketleri',N'U') IS NULL OR OBJECT_ID(N'dbo.Kullanicilar',N'U') IS NULL
    THROW 51000,N'Önce MiapaxERP temel muhasebe kurulumu yapılmalıdır.',1;

IF OBJECT_ID(N'dbo.BoruERP_GGHesaplar',N'U') IS NULL
CREATE TABLE dbo.BoruERP_GGHesaplar(
 Kod nvarchar(20) NOT NULL PRIMARY KEY, Ad nvarchar(200) NOT NULL,
 GrupKodu nvarchar(3) NOT NULL, Tur nvarchar(5) NOT NULL CHECK(Tur IN(N'Gelir',N'Gider')),
 Detay bit NOT NULL, Aktif bit NOT NULL DEFAULT 1);
IF OBJECT_ID(N'dbo.BoruERP_MaliyetMerkezleri',N'U') IS NULL
CREATE TABLE dbo.BoruERP_MaliyetMerkezleri(
 Id int IDENTITY PRIMARY KEY, Kod nvarchar(30) NOT NULL UNIQUE, Ad nvarchar(150) NOT NULL,
 Aktif bit NOT NULL DEFAULT 1);
IF OBJECT_ID(N'dbo.BoruERP_GelirGider',N'U') IS NULL
CREATE TABLE dbo.BoruERP_GelirGider(
 Id bigint IDENTITY PRIMARY KEY, IslemAnahtari uniqueidentifier NOT NULL UNIQUE,
 Tarih date NOT NULL, Tur nvarchar(5) NOT NULL CHECK(Tur IN(N'Gelir',N'Gider')),
 HesapKodu nvarchar(20) NOT NULL REFERENCES dbo.BoruERP_GGHesaplar(Kod),
 MaliyetMerkeziId int NOT NULL REFERENCES dbo.BoruERP_MaliyetMerkezleri(Id),
 Tutar decimal(18,2) NOT NULL CHECK(Tutar>0), BelgeNo nvarchar(80) NOT NULL DEFAULT N'', Aciklama nvarchar(400) NOT NULL,
 EskiMasrafId bigint NULL, YapanKullaniciId int NOT NULL REFERENCES dbo.Kullanicilar(Id),
 KayitZamani datetime2 NOT NULL DEFAULT SYSDATETIME(),
 Iptal bit NOT NULL DEFAULT 0, IptalKullaniciId int NULL REFERENCES dbo.Kullanicilar(Id), IptalZamani datetime2 NULL,
 IptalNedeni nvarchar(400) NULL);
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.BoruERP_GelirGider') AND name=N'UX_GG_EskiMasraf')
CREATE UNIQUE INDEX UX_GG_EskiMasraf ON dbo.BoruERP_GelirGider(EskiMasrafId) WHERE EskiMasrafId IS NOT NULL;
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.BoruERP_GelirGider') AND name=N'IX_GG_TarihMerkez')
CREATE INDEX IX_GG_TarihMerkez ON dbo.BoruERP_GelirGider(Tarih,MaliyetMerkeziId,HesapKodu) INCLUDE(Tur,Tutar,Iptal);
IF OBJECT_ID(N'dbo.BoruERP_GGOdemeler',N'U') IS NULL
CREATE TABLE dbo.BoruERP_GGOdemeler(
 Id bigint IDENTITY PRIMARY KEY, KayitId bigint NOT NULL REFERENCES dbo.BoruERP_GelirGider(Id),
 FinansHareketId bigint NOT NULL UNIQUE REFERENCES dbo.FinansHareketleri(Id));
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.BoruERP_GGOdemeler') AND name=N'IX_GGOdeme_Kayit')
CREATE INDEX IX_GGOdeme_Kayit ON dbo.BoruERP_GGOdemeler(KayitId);

INSERT INTO dbo.BoruERP_MaliyetMerkezleri(Kod,Ad)
SELECT s.Kod,s.Ad FROM (VALUES
(N'URT',N'Üretim'),(N'YON',N'Yönetim'),(N'PAZ',N'Pazarlama ve Satış'),
(N'DEP',N'Depo ve Sevkiyat'),(N'BAK',N'Bakım ve Onarım'),(N'FIN',N'Finansman'))s(Kod,Ad)
WHERE NOT EXISTS(SELECT 1 FROM dbo.BoruERP_MaliyetMerkezleri m WHERE m.Kod=s.Kod);

DECLARE @Hesaplar TABLE(Kod nvarchar(20),Ad nvarchar(200),GrupKodu nvarchar(3),Tur nvarchar(5),Detay bit);
INSERT INTO @Hesaplar VALUES
(N'740',N'ÜRETİM MALİYE HESABI',N'740',N'Gider',0),
(N'740.01.001',N'Maaş Normal Ücret Hakediş',N'740',N'Gider',1),
(N'740.01.002',N'İzin Ücreti',N'740',N'Gider',1),
(N'740.01.003',N'Fazla Mesai',N'740',N'Gider',1),
(N'740.01.004',N'Verilen Satış Primleri',N'740',N'Gider',1),
(N'740.01.005',N'İhbar Tazminatı',N'740',N'Gider',1),
(N'740.01.006',N'Kıdem Tazminatı',N'740',N'Gider',1),
(N'740.01.007',N'Personel Yemek ve İaşe Giderleri',N'740',N'Gider',1),
(N'740.01.008',N'Personele Verilen Hizmet İkramiyeleri',N'740',N'Gider',1),
(N'740.01.009',N'Eğitim Giderleri',N'740',N'Gider',1),
(N'760',N'PAZARLAMA SATIŞ DAĞIRIM HESABI',N'760',N'Gider',0),
(N'760.12.001',N'Nakliye  Gideri',N'760',N'Gider',1),
(N'760.12.002',N'Nakliye Siğorta Giderleri',N'760',N'Gider',1),
(N'760.13.001',N'Marka Reklam Giderleri',N'760',N'Gider',1),
(N'760.13.002',N'Marka Tv Reklam Giderleri',N'760',N'Gider',1),
(N'760.13.003',N'Marka Radyo Reklam Giderleri',N'760',N'Gider',1),
(N'760.13.004',N'Marka Gazete Dergi Reklam Giderleri',N'760',N'Gider',1),
(N'760.13.005',N'Marka Sosyal Medya Reklam Giderleri',N'760',N'Gider',1),
(N'760.13.006',N'İnternet Sitesi Yapım geliştirme giderleri',N'760',N'Gider',1),
(N'760.13.007',N'İnternet sitesi Ödenen Aidat Kota Giderleri',N'760',N'Gider',1),
(N'760.13.008',N'İnternet Sitesi Sosyal Medya Reklam Giderleri',N'760',N'Gider',1),
(N'770',N'GENEL YÖNETİM GİDER HESABI',N'770',N'Gider',0),
(N'770.03.001',N'Mali Müşavirlik Giderleri (SMMM)',N'770',N'Gider',1),
(N'770.03.002',N'Hukuki Müşavirlik Avukat Giderleri',N'770',N'Gider',1),
(N'770.03.003',N'Ekspertiz ve Gözetim Giderleri',N'770',N'Gider',1),
(N'770.04.001',N'Dava ve İcra Giderleri',N'770',N'Gider',1),
(N'770.04.002',N'Noter Giderleri',N'770',N'Gider',1),
(N'770.05.001',N'Elektrik Giderleri',N'770',N'Gider',1),
(N'770.05.002',N'Su Giderleri',N'770',N'Gider',1),
(N'770.05.003',N'Doğalgaz Giderleri',N'770',N'Gider',1),
(N'770.05.004',N'Muhtelif Tamir Malzemeleri Alış Gideri',N'770',N'Gider',1),
(N'770.05.005',N'Dışardan Sağlanan İşçilik Gideri (Kurulum Monj.)',N'770',N'Gider',1),
(N'770.05.006',N'Ürün Teslimat Bedelleri',N'770',N'Gider',1),
(N'770.05.007',N'Güvenlik Giderleri',N'770',N'Gider',1),
(N'770.06.001',N'Tesis Makine ve Cihaz Bakım Onarım Giderleri',N'770',N'Gider',1),
(N'770.06.002',N'Büro Demirbaşları Bakım Onarım Giderleri',N'770',N'Gider',1),
(N'770.06.003',N'Mağaza Teşhir Aksesuar Gideri',N'770',N'Gider',1),
(N'770.07.001',N'Sabit Telefon Giderleri',N'770',N'Gider',1),
(N'770.07.002',N'GSM Telefon Giderleri',N'770',N'Gider',1),
(N'770.07.003',N'Araç Takip Gsm Gideri',N'770',N'Gider',1),
(N'770.07.004',N'Evrak Kargo Giderleri',N'770',N'Gider',1),
(N'770.07.005',N'Evrak Posta Gideri',N'770',N'Gider',1),
(N'770.07.010',N'İnternet Giderleri',N'770',N'Gider',1),
(N'770.08.007',N'Seyehat Konaklama (Otel)',N'770',N'Gider',1),
(N'770.08.008',N'Seyehat Ulaşım Giderleri',N'770',N'Gider',1),
(N'770.08.009',N'Seyehat Harcırah',N'770',N'Gider',1),
(N'770.08.010',N'Seyehat Hediye Alım Giderleri',N'770',N'Gider',1),
(N'770.08.011',N'Seyahat Otopark -Köprü-Otoyol-HGS Diğerle',N'770',N'Gider',1),
(N'770.08.012',N'Seyehat Yemek Giderleri',N'770',N'Gider',1),
(N'770.09.001',N'Konaklama (Otel )',N'770',N'Gider',1),
(N'770.09.020',N'Yemek Giderleri',N'770',N'Gider',1),
(N'770.09.021',N'Ulaşım Giderleri',N'770',N'Gider',1),
(N'770.09.022',N'Hediye Alım Giderleri',N'770',N'Gider',1),
(N'770.10.001',N'İş Yeri Kira Giderleri',N'770',N'Gider',1),
(N'770.10.002',N'Kira Stopajları Gider',N'770',N'Gider',1),
(N'770.10.004',N'Bina Aitdat Giderleri',N'770',N'Gider',1),
(N'770.10.005',N'Bina Bakım Onarım Gideri',N'770',N'Gider',1),
(N'770.10.006',N'Yemekhane İaşe Gideri',N'770',N'Gider',1),
(N'770.10.007',N'Zekat Yardım Gideri',N'770',N'Gider',1),
(N'770.10.008',N'Verilen Depozito ve Teminatlar',N'770',N'Gider',1),
(N'770.10.009',N'İşyeri Açılış Giderleri',N'770',N'Gider',1),
(N'770.10.010',N'İş Yeri Sigorta Giderleri',N'770',N'Gider',1),
(N'770.11.001',N'Akaryakıt Giderleri',N'770',N'Gider',1),
(N'770.11.002',N'Sigorta ve Kasko Giderleri',N'770',N'Gider',1),
(N'770.11.003',N'Araç Kiralama Giderleri',N'770',N'Gider',1),
(N'770.11.004',N'MTV Giderleri',N'770',N'Gider',1),
(N'770.11.005',N'Araç Bakım Onarım Gideri',N'770',N'Gider',1),
(N'770.11.006',N'Araç Otopark OGS ve Çeş.Gideri',N'770',N'Gider',1),
(N'770.15.001',N'Kırtasiye Giderleri',N'770',N'Gider',1),
(N'770.15.002',N'Bilgi İşlem Giderleri',N'770',N'Gider',1),
(N'770.15.003',N'Abonelik ve Aidat Giderleri',N'770',N'Gider',1),
(N'770.15.004',N'Temizlik Giderleri',N'770',N'Gider',1),
(N'770.15.005',N'Gider Yazılan Küçük Demirbaşlar',N'770',N'Gider',1),
(N'770.16.001',N'Sosyal Güvenlik (SGK) gideri',N'770',N'Gider',1),
(N'770.16.002',N'Katma Deger Verg.(K.D.V) gideri',N'770',N'Gider',1),
(N'770.16.003',N'Kurumlar - Geçiçi Vergi Gideri',N'770',N'Gider',1),
(N'770.16.004',N'Belediye Vergi ve Harç (Totem Reklam. Gid.)',N'770',N'Gider',1),
(N'770.16.005',N'Oda Aidat Giderleri',N'770',N'Gider',1),
(N'770.16.006',N'Tescil ve İlan Giderleri',N'770',N'Gider',1),
(N'770.16.007',N'Usulsüzlük ve Ceza Giderleri',N'770',N'Gider',1),
(N'770.16.008',N'Stopaj İşci (Muhtasar) Gider',N'770',N'Gider',1),
(N'780',N'FİNANSMAN GİDER HESABI',N'780',N'Gider',0),
(N'780.01.001',N'Pos İşlem Masraf ve Komisyonları',N'780',N'Gider',1),
(N'780.01.002',N'Havale ve Eft Masrafları',N'780',N'Gider',1),
(N'780.01.003',N'Hesap İşletim Ücreti',N'780',N'Gider',1),
(N'602',N'DİĞER GELİRLER HESABI',N'602',N'Gelir',0),
(N'602.01.001',N'Araç Kira Bedeli Yansıtması',N'602',N'Gelir',1),
(N'602.01.002',N'Araç Yakıt Bedeli Gelirleri',N'602',N'Gelir',1),
(N'602.01.003',N'Diğer Gelirler',N'602',N'Gelir',1),
(N'602.01.004',N'Fiyat Farkı Gelirleri',N'602',N'Gelir',1),
(N'602.01.005',N'Kira Gelirleri',N'602',N'Gelir',1),
(N'602.01.006',N'Nakliye Gelirleri',N'602',N'Gelir',1),
(N'602.01.007',N'Pazarlama Reklam Gelirleri',N'602',N'Gelir',1),
(N'602.01.008',N'Prim Gelirleri',N'602',N'Gelir',1),
(N'602.01.009',N'Servis Bedeli Yansıtma Gelirleri',N'602',N'Gelir',1),
(N'602.01.010',N'Teknik Servis Hizmet Gelirleri',N'602',N'Gelir',1),
(N'602.01.011',N'Telefon Kullanım Ücreti Yansıtması',N'602',N'Gelir',1),
(N'602.01.012',N'Teslimat Bedeli Gelirleri',N'602',N'Gelir',1),
(N'602.01.013',N'Dekorasyon Desteği Yansıtma',N'602',N'Gelir',1),
(N'602.01.014',N'Reklam Katılım Bedeli Yansıtma',N'602',N'Gelir',1),
(N'602.01.015',N'Personel Yansıtma Gideri (vergi maaş ücret)',N'602',N'Gelir',1),
(N'602.01.016',N'Ürün iptali Sözleşmeden Dönme Cezası',N'602',N'Gelir',1);
INSERT INTO dbo.BoruERP_GGHesaplar(Kod,Ad,GrupKodu,Tur,Detay) SELECT Kod,Ad,GrupKodu,Tur,Detay FROM @Hesaplar h WHERE NOT EXISTS(SELECT 1 FROM dbo.BoruERP_GGHesaplar t WHERE t.Kod=h.Kod);

COMMIT TRANSACTION;

