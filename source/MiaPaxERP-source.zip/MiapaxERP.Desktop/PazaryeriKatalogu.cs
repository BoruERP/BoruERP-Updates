namespace MiapaxERP.Desktop;

public sealed record PazaryeriTanimi(string Ad, string Kategori, bool SiparisOkumaHazir, string Gerekenler, string Dokuman);

public static class PazaryeriKatalogu
{
    public static readonly PazaryeriTanimi[] Tum =
    [
        new("Trendyol", "Pazaryerleri", true, "Satıcı ID, API key ve API secret. Order V2 ile son bir haftanın sipariş paketleri okunur.", "https://developers.trendyol.com/"),
        new("Hepsiburada", "Pazaryerleri", true, "Merchant ID, API kullanıcı adı, servis anahtarı ve Hepsiburada tarafından verilen entegratör User-Agent bilgisi.", "https://developers.hepsiburada.com/"),
        new("Amazon Türkiye", "Pazaryerleri", false, "Amazon SP-API uygulama kaydı, satıcı yetkilendirmesi, LWA client ID/secret ve refresh token gerekir. Bu sürümde sipariş bağdaştırıcısı henüz yok.", "https://developer-docs.amazon.com/sp-api/"),
        new("n11", "Pazaryerleri", false, "Satıcı hesabı ve geliştirici API erişimi gerekir. Bu sürümde sipariş bağdaştırıcısı henüz yok.", "https://magazadestek.n11.com/"),
        new("Pazarama", "Pazaryerleri", false, "Satıcı hesabı ve Pazarama entegrasyon bilgileri gerekir. Bu sürümde sipariş bağdaştırıcısı henüz yok.", "https://isortagim.pazarama.com/"),
        new("ÇiçekSepeti", "Pazaryerleri", false, "Satıcı hesabı ve API yetkisi gerekir. Bu sürümde sipariş bağdaştırıcısı henüz yok.", "https://bayi.ciceksepeti.com/"),
        new("Shopify", "Mağaza altyapıları", true, "myshopify.com alan adı ve read_orders kapsamlı Admin API access token gerekir.", "https://shopify.dev/docs/api/admin-graphql"),
        new("WooCommerce", "Mağaza altyapıları", true, "HTTPS mağaza alan adı, sipariş okuma yetkili consumer key ve consumer secret gerekir.", "https://woocommerce.github.io/woocommerce-rest-api-docs/")
    ];
}
