using System.Data;
using System.Net;
using System.Text;
namespace MiapaxERP.Desktop;
public sealed partial class IsletmeServisi
{
    public void BasincDisariAktarYetkisi(){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"IsletmeServisi.BasincDisariAktarYetkisi","",new object?[]{});return;}
using var c=access.Ac();Yetki(c,null,"PRESSURE.EXPORT");}
    public string BasincRaporu(long id)
    {
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<string>(connection,"IsletmeServisi.BasincRaporu","",new object?[]{id});}

        using var c=access.Ac();Yetki(c,null,"PRESSURE.VIEW");var row=Read(c,null,id,"BasincTest");var g=Veri<BasincTestGirdisi>((string)row["Veri"]);var product=Table(Q(c,null,"SELECT s.StokKodu,s.StokAdi,l.Kod Parti,l.Kalite FROM dbo.MPX310_Lot l JOIN dbo.StokKartlari s ON s.Id=l.StokId WHERE l.Id=@l",("@l",g.Lot)));var device=Table(Q(c,null,"SELECT Kod,Ad,Kalibrasyon,Gecerlilik,Belge FROM dbo.BERP260_LabCihaz WHERE Id=@i",("@i",g.Cihaz)));var media=Table(Q(c,null,"SELECT Ad,Tur,Sha256,Zaman FROM dbo.MPX310_Ek WHERE KayitId=@i ORDER BY Id",("@i",id)));var audit=Table(Q(c,null,"SELECT Zaman,Kullanici,Tur,Aciklama FROM dbo.MPX310_Olay WHERE KayitId=@i ORDER BY Id",("@i",id)));
        string E(object? v)=>WebUtility.HtmlEncode(Convert.ToString(v)??"");var b=new StringBuilder("<!doctype html><html lang='tr'><meta charset='utf-8'><style>body{font:13px Arial;margin:28px;color:#18354a}table{border-collapse:collapse;width:100%;margin:12px 0}td,th{border:1px solid #b9c8d2;padding:8px;text-align:left}h1{font-size:25px}h2{font-size:18px}@media print{tr{break-inside:avoid}}</style><h1>MiaPaxERP · Boru basınç testi</h1><table>");
        void Pair(string label,object? v)=>b.Append("<tr><th>").Append(E(label)).Append("</th><td>").Append(E(v)).Append("</td></tr>");
        Pair("Test no",g.No);Pair("Kayıt / durum",id+" / "+row["Durum"]);Pair("Yöntem",g.Yontem);Pair("Standart / şartname",g.Standart);Pair("Başlangıç",g.Baslangic);Pair("Bitiş",g.Bitis);Pair("Gerçek süre (saat)",(g.Bitis-g.Baslangic).TotalHours);Pair("Gerekli süre (saat)",g.GerekliSaat);Pair("Sıcaklık (°C)",g.Sicaklik);Pair("Hedef en düşük basınç (bar)",g.HedefBar);Pair("Başlangıç / bitiş basıncı (bar)",g.IlkBar+" / "+g.SonBar);Pair("Sızıntı",g.Sizinti?"Var":"Yok");Pair("Gözlemler",g.Aciklama);b.Append("</table>");
        void TableHtml(string title,DataTable table){b.Append("<h2>").Append(E(title)).Append("</h2><table><tr>");foreach(DataColumn col in table.Columns)b.Append("<th>").Append(E(col.ColumnName)).Append("</th>");b.Append("</tr>");foreach(DataRow r in table.Rows){b.Append("<tr>");foreach(DataColumn col in table.Columns)b.Append("<td>").Append(E(r[col])).Append("</td>");b.Append("</tr>");}b.Append("</table>");}
        TableHtml("Ürün ve parti",product);TableHtml("Cihazın güncel kalibrasyon kaydı",device);TableHtml("Fotoğraf / video arşivi",media);TableHtml("İşlem geçmişi",audit);b.Append("<p>Sonuç, kaydedilen ölçümler ve belirtilen şartname ölçütlerine göre teknik incelemeye tabidir. Taslak kayıt onaylı deney raporu değildir.</p></html>");return b.ToString();
    }
}
