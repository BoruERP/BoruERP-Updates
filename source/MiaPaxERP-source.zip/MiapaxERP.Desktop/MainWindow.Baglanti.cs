using SqlConnection = MiapaxERP.Desktop.ErpSqlConnection;
using SqlCommand = MiapaxERP.Desktop.ErpSqlCommand;
using SqlTransaction = MiapaxERP.Desktop.ErpSqlTransaction;
using SqlDataReader = MiapaxERP.Desktop.ErpSqlReader;
using SqlDataAdapter = MiapaxERP.Desktop.ErpSqlDataAdapter;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.Data.SqlClient;

namespace MiapaxERP.Desktop
{
    // Ağ izlemesi + yetkiye göre şifrelenmiş yerel, salt-okunur kopyalar.
    // Çevrimdışı yazma/eşitleme BU SÜRÜMDE YOKTUR; tehlikeli yazma ekranları devre dışıdır.
    public partial class MainWindow
    {
        private readonly DispatcherTimer agKontrolZamanlayici = new DispatcherTimer();
        private bool agBagli;
        private bool agKontrolEdiliyor;
        private bool agKopyaIndiriliyor;
        private DateTime agSonKopyaUtc = DateTime.MinValue;

        private void AgIzlemeyiBaslat()
        {
            Loaded += async (_, _) =>
            {
                agKontrolZamanlayici.Interval = TimeSpan.FromSeconds(12);
                agKontrolZamanlayici.Tick += async (_, _) => await AgBaglantisiniKontrolEtAsync();
                agKontrolZamanlayici.Start();
                await AgBaglantisiniKontrolEtAsync();
            };
        }

        private void AgIzlemeyiDurdur() => agKontrolZamanlayici.Stop();

        private async Task AgBaglantisiniKontrolEtAsync()
        {
            if (agKontrolEdiliyor || DemoModu) return;
            agKontrolEdiliyor = true;
            try
            {
                bool yeniDurum = await Task.Run(() =>
                {
                    try
                    {
                        if(HttpsOturumu.Uzak(baglantiAdresi)){new YardimciEkranServisi(baglantiAdresi,aktifKullanici?.KullaniciId??0).OturumKontrol();return true;}
                        using var con = new SqlConnection(baglantiAdresi);
                        con.Open();
                        using var cmd = new SqlCommand("SELECT 1;", con) { CommandTimeout = 2 };
                        return Convert.ToInt32(cmd.ExecuteScalar()) == 1;
                    }
                    catch (SqlException) { return false; }
                    catch (InvalidOperationException) { return false; }
                    catch (UnauthorizedAccessException) { return false; }
                });
                bool durumDegisti = agBagli != yeniDurum;
                agBagli = yeniDurum;
                AgDurumunuEkranaYansit();

                if (agBagli && aktifKullanici != null)
                {
                    if (durumDegisti)
                    {
                        // Yetkiler bağlantı yeniden geldiğinde SQL'den yeniden okunur.
                        StokYetkiGorunumuYenile();
                        _ = AnaSayfaVerileriniYukleAsync();
                        _ = AnaSayfaTicariYukleAsync();
                    }
                    if (durumDegisti || DateTime.UtcNow - agSonKopyaUtc > TimeSpan.FromMinutes(5))
                        _ = AgOnbellekYenileAsync();
                }
            }
            finally { agKontrolEdiliyor = false; }
        }

        private void AgDurumunuEkranaYansit()
        {
            if (TxtAgDurumu == null) return;
            TxtAgDurumu.Text = agBagli ? "● Sunucu bağlı" : "⚠ Çevrimdışı";
            TxtAgDurumu.Foreground = agBagli
                ? new SolidColorBrush(Color.FromRgb(15, 118, 110))
                : new SolidColorBrush(Color.FromRgb(180, 83, 9));
            BtnAgDurumu.ToolTip = agBagli
                ? "Ana SQL Server'a bağlı. Ağ ayarlarını aç."
                : "Ana bilgisayara ulaşılamıyor. Son eşitlenen bilgiler salt okunur kullanılabilir.";

            bool oturum = DemoModu || aktifKullanici != null;
            BtnYerelVeriler.Visibility = oturum ? Visibility.Visible : Visibility.Collapsed;
            BtnYerelVeriler.Content = agBagli ? "Son Veri" : "Yerel Veri";

            // Offline iken hiçbir SQL yazma ekranının etkin kalmaması için menüleri kapat.
            // Dashboard ve salt-okunur yerel kopyalar kullanılabilir; sekme içindeki yetkiler sunucudayken işler.
            if (!agBagli)
            {
                BtnMenuStok.IsEnabled = false;
                BtnMenuStokHareket.IsEnabled = false;
                BtnMenuUretim.IsEnabled = false;
                BtnMenuRecete.IsEnabled = false;
                BtnMenuCari.IsEnabled = false;
                BtnMenuFinans.IsEnabled = false;
                BtnMenuRaporlar.IsEnabled = false;
                BtnMenuKullanici.IsEnabled = false;
                BtnMenuAyarlar.IsEnabled = false;
                // Mevcut formların içeriklerinde veri yazan düğmeler de tıklanmasın.
                StokIcerik.IsEnabled = false;
                StokHareketIcerik.IsEnabled = false;
                StokAcilisIcerik.IsEnabled = false;
                YeniStokIcerik.IsEnabled = false;
                UretimIcerik.IsEnabled = false;
                ReceteIcerik.IsEnabled = false;
            }
            else
            {
                BtnMenuUretim.IsEnabled = oturum;
                BtnMenuRecete.IsEnabled = oturum;
                BtnMenuCari.IsEnabled = oturum;
                BtnMenuFinans.IsEnabled = oturum;
                BtnMenuRaporlar.IsEnabled = oturum;
                BtnMenuKullanici.IsEnabled = oturum;
                BtnMenuAyarlar.IsEnabled = oturum;
                StokIcerik.IsEnabled = true;
                StokHareketIcerik.IsEnabled = true;
                StokAcilisIcerik.IsEnabled = true;
                YeniStokIcerik.IsEnabled = true;
                UretimIcerik.IsEnabled = true;
                ReceteIcerik.IsEnabled = true;
                // Stok butonlarının yetki durumunu ayrı mevcut fonksiyon belirler.
            }
        }

        private void AgDurum_Click(object sender, RoutedEventArgs e)
        {
            if (aktifKullanici != null &&
                !aktifKullanici.Roller.Contains("Yönetici", StringComparison.OrdinalIgnoreCase))
            {
                MessageBox.Show("Ağ bağlantısı ayarlarını yönetici değiştirebilir.\n" +
                    "Son eşitlenen veriler için 'Yerel Veri' düğmesini kullanın.",
                    "MiapaxERP", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            new BaglantiAyarlariPenceresi { Owner = this }.ShowDialog();
        }

        private void YerelVeriler_Click(object sender, RoutedEventArgs e)
        {
            if (aktifKullanici == null) return;
            new CevrimdisiVerilerPenceresi(baglantiAdresi, aktifKullanici.KullaniciId)
            { Owner = this }.ShowDialog();
        }

        private async Task AgOnbellekYenileAsync()
        {
            if (!agBagli || agKopyaIndiriliyor || aktifKullanici == null) return;
            int kullaniciId = aktifKullanici.KullaniciId;
            agKopyaIndiriliyor = true;
            try
            {
                // Erişim yetkileri sunucuda doğrulanır; yetkisiz bölümlerin yerel kopyası silinir.
                await Task.Run(() =>
                {
                    using var con = new SqlConnection(baglantiAdresi);
                    con.Open();
                    using (var cmd = new SqlCommand(
                        "SELECT COUNT(*) FROM dbo.Kullanicilar WHERE Id=@id AND Aktif=1;", con))
                    {
                        cmd.Parameters.Add("@id", SqlDbType.Int).Value = kullaniciId;
                        if (Convert.ToInt32(cmd.ExecuteScalar()) != 1) return;
                    }
                    var kategoriler = new (string Kod, string Yetki, string Sql)[]
                    {
                        ("Stok", "STOCK.VIEW", @"SELECT TOP (3000) sk.StokKodu, sk.StokAdi, sk.StokTipi, sk.Birim,
                            ISNULL(sb.Miktar,0) AS Miktar,
                            sk.MinimumStokMiktari,
                            CASE WHEN sk.Aktif=1 THEN N'Aktif' ELSE N'Pasif' END AS Durum
                            FROM dbo.StokKartlari sk
                            LEFT JOIN dbo.StokBakiyeleri sb ON sb.StokKartId = sk.Id
                            ORDER BY sk.Id DESC;"),
                        ("Uretim", "PRODUCTION.VIEW", @"SELECT TOP (3000)
                            ue.UretimEmriNo, sk.StokAdi, ue.PlanlananMiktar, ue.UretilenMiktar,
                            ue.FireMiktari, ue.Durum, ue.PlanlananBaslangic, ue.PlanlananBitis
                            FROM dbo.UretimEmirleri ue
                            INNER JOIN dbo.StokKartlari sk ON sk.Id=ue.MamulStokId
                            ORDER BY ue.Id DESC;"),
                        ("Recete", "RECIPE.VIEW", @"SELECT TOP (3000)
                            r.ReceteKodu, r.ReceteAdi, sk.StokAdi AS Mamul,
                            CASE WHEN r.Aktif=1 THEN N'Aktif' ELSE N'Pasif' END AS Durum
                            FROM dbo.UretimReceteleri r
                            JOIN dbo.StokKartlari sk ON sk.Id=r.MamulStokId
                            ORDER BY r.Id DESC;"),
                        ("Cari", "CUSTOMER.VIEW", @"SELECT TOP (3000)
                            CariKodu, Unvan, CariTipi,
                            CASE WHEN Aktif=1 THEN N'Aktif' ELSE N'Pasif' END AS Durum
                            FROM dbo.CariKartlari ORDER BY Id DESC;"),
                        ("Odeme", "FINANCE.VIEW", @"SELECT TOP (3000)
                            Baslik, VadeTarihi, Tutar, ParaBirimi, Durum
                            FROM dbo.PlanliOdemeler ORDER BY Id DESC;"),
                        ("CekSenet", "CHECKNOTE.VIEW", @"SELECT TOP (3000)
                            EvrakNo, EvrakTipi, Yon, VadeTarihi, Tutar, ParaBirimi, Durum
                            FROM dbo.CekSenetler ORDER BY Id DESC;")
                    };
                    foreach (var k in kategoriler)
                    {
                        try
                        {
                            bool izin = StokSqlYetkisiVar(con, null, kullaniciId, k.Yetki);
                            if (!izin)
                            {
                                MiapaxERPYerelKopya.Sil(baglantiAdresi, kullaniciId, k.Kod);
                                continue;
                            }
                            using var cmd = new SqlCommand(k.Sql, con) { CommandTimeout = 10 };
                            using var reader = cmd.ExecuteReader();
                            var tablo = new DataTable();
                            tablo.Load(reader);
                            MiapaxERPYerelKopya.Kaydet(baglantiAdresi, kullaniciId, k.Kod, tablo);
                        }
                        catch (SqlException)
                        {
                            // Henüz kurulmamış modüller veya geçici bağlantı kesintisi kopya
                            // indirme döngüsünü / çalışan UI'yi durdurmaz.
                        }
                    }
                });
                if (aktifKullanici?.KullaniciId == kullaniciId)
                    agSonKopyaUtc = DateTime.UtcNow;
            }
            catch (Exception)
            {
                // Eşitleme başarısızlığı asla programı kapatmaz; başarılı eski kopyalar kalır.
            }
            finally { agKopyaIndiriliyor = false; }
        }
    }
}

