using System.Globalization;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using static MiapaxERP.Desktop.WebYonetimi.WebJson;
namespace MiapaxERP.Desktop.WebYonetimi;

public sealed class WordPressWeb(WebSite site,WebHttp http):IWebSaglayici
{
 bool Woo=>site.Platform==WebPlatform.WooCommerce;
 HttpRequestMessage Request(HttpMethod method,string path,bool commerce=false,object? body=null)
 {
  var s=site.Sirlar;if(commerce&&(s.WooAnahtar.Length==0||s.WooGizli.Length==0)||!commerce&&(s.WpKullanici.Length==0||s.WpUygulamaParolasi.Length==0))throw new ArgumentException(commerce?"WooCommerce API anahtarı ve gizli anahtarını girin.":"WordPress kullanıcı adı ve uygulama parolası gerekli.");
  var q=http.Istek(method,path,commerce?s.WooAnahtar:s.WpKullanici,commerce?s.WooGizli:s.WpUygulamaParolasi);if(body is not null)q.Content=WebHttp.Govde(body);return q;
 }
 static string Number(string id){if(!long.TryParse(id,out var n)||n<1||id!=n.ToString(CultureInfo.InvariantCulture))throw new ArgumentException("Site kayıt kimliği geçersiz.");return id;}
 string Path(WebBolum kind,string id="",string parent="")
 {
  string path=kind switch{WebBolum.Urun or WebBolum.Stok=>parent.Length>0?"wp-json/wc/v3/products/"+Number(parent)+"/variations":"wp-json/wc/v3/products",WebBolum.Varyant=>"wp-json/wc/v3/products/"+Number(parent)+"/variations",WebBolum.Sayfa=>"wp-json/wp/v2/pages",WebBolum.Yazi=>"wp-json/wp/v2/posts",WebBolum.Gorsel=>"wp-json/wp/v2/media",WebBolum.Siparis=>"wp-json/wc/v3/orders",_=>throw new ArgumentException("Bu bölüm WordPress'te desteklenmiyor.")};
  if(kind is WebBolum.Urun or WebBolum.Varyant or WebBolum.Stok or WebBolum.Siparis&&!Woo)throw new ArgumentException("Bu sitede WooCommerce bağlantısı seçilmedi.");
  return path+(id.Length>0?"/"+Number(id):"");
 }
 static bool Commerce(WebBolum k)=>k is WebBolum.Urun or WebBolum.Varyant or WebBolum.Stok or WebBolum.Siparis;
 public async Task<WebBaglanti> BaglantiDene(CancellationToken ct)
 {
  var (me,_)=await http.Json(Request(HttpMethod.Get,"wp-json/wp/v2/users/me?context=edit"),ct);string currency="";if(Woo){var(c,_)=await http.Json(Request(HttpMethod.Get,"wp-json/wc/v3/data/currencies/current",true),ct);currency=S(c,"code");if(currency.Length==0)currency=S(c,"id");if(currency.Length!=3)throw new WebApiHatasi("Mağazanın para birimi doğrulanamadı.");}
  return new(S(me,"name"),currency,Woo?["urun","varyant","fiyat","stok","siparis","sayfa","yazi","gorsel"]:["sayfa","yazi","gorsel"],"WordPress çekirdek API'sinde kayıt sürümü yazma anında atomik karşılaştırılmaz. Kaydetmeden önce güncel kayıt karşılaştırılır; otomatik arka plan stok/fiyat eşitlemesi yapılmaz.");
 }
 static string Raw(JsonElement j,string key){var p=P(j,key);return p.ValueKind==JsonValueKind.Object?(P(p,"raw").ValueKind==JsonValueKind.String?S(p,"raw"):S(p,"rendered")):p.ToString();}
 static WebKayit Row(WebBolum kind,JsonElement j,string parent="")
 {
  string id=S(j,"id"),title=Commerce(kind)?S(j,"name"):Raw(j,"title"),body=Commerce(kind)?S(j,"description"):Raw(j,kind==WebBolum.Gorsel?"caption":"content");int? qty=null;var sq=P(j,"stock_quantity");if(P(j,"manage_stock").ValueKind==JsonValueKind.True&&sq.ValueKind==JsonValueKind.Number&&sq.TryGetInt32(out var value))qty=value;
  if(kind==WebBolum.Siparis){var billing=P(j,"billing");title=S(j,"number")+" · "+S(billing,"first_name")+" "+S(billing,"last_name");body=string.Join("; ",A(P(j,"line_items")).Select(x=>S(x,"name")+" × "+S(x,"quantity")));}
  var result=new WebKayit(kind,id,title,body,S(j,"status"),"",parent,S(j,"sku"),S(j,"regular_price"),S(j,"currency"),S(j,"total"),kind==WebBolum.Gorsel?S(j,"source_url"):S(j,"link"),kind==WebBolum.Siparis?S(j,"date_created_gmt"):S(j,"type"),qty,AltMetin:S(j,"alt_text"));
  if(kind==WebBolum.Urun)result=result with{Gorseller=A(P(j,"images")).Select(x=>S(x,"id")).ToArray()};
  if(kind==WebBolum.Siparis){var bill=P(j,"billing");string customer=S(bill,"company");if(customer.Length==0)customer=(S(bill,"first_name")+" "+S(bill,"last_name")).Trim();result=result with{Musteri=customer,Numara=S(j,"number"),Tarih=S(j,"date_created"),Adres=string.Join(" ",new[]{S(P(j,"shipping"),"address_1"),S(P(j,"shipping"),"address_2"),S(P(j,"shipping"),"city"),S(P(j,"shipping"),"country")}.Where(x=>x.Length>0))};}
  return result with{Surum=Ozet(new{result,modified=S(j,Commerce(kind)?"date_modified_gmt":"modified_gmt")})};
 }
 public async Task<WebSayfa> Liste(WebBolum kind,string parent,string? cursor,CancellationToken ct)
 {
  int page=cursor is null?1:int.TryParse(cursor,out var n)&&n>=1&&n<=100000?n:throw new ArgumentException("Sayfa geçersiz.");
  string path=Path(kind,"",parent)+$"?per_page=50&page={page}&context=edit";if(kind is WebBolum.Sayfa or WebBolum.Yazi)path+="&status=publish,draft,pending,private,future";
  var (j,h)=await http.Json(Request(HttpMethod.Get,path,Commerce(kind)),ct);if(j.ValueKind!=JsonValueKind.Array)throw new WebApiHatasi("Site liste yanıtı geçersiz.");var rows=A(j).Select(x=>Row(kind,x,parent)).ToArray();
  int total=0;if(h.TryGetValues("X-WP-TotalPages",out var totals))int.TryParse(totals.FirstOrDefault(),out total);return new(rows,total>page||total==0&&rows.Length==50?(page+1).ToString():null);
 }
 public async Task<WebKayit> Oku(WebBolum kind,string id,string parent,CancellationToken ct)
 {var(j,_)=await http.Json(Request(HttpMethod.Get,Path(kind,id,parent)+"?context=edit",Commerce(kind)),ct);return Row(kind,j,parent);}
 public async Task<WebSonuc> Kaydet(WebDegisiklik d,Guid operation,CancellationToken ct)
 {
  Dogrula(d);object body;
  if(d.Bolum==WebBolum.GorselBagla){var old=await Oku(d.HedefBolum,d.Id,d.ParentId,ct);if(old.Surum!=d.BeklenenSurum)throw new WebApiHatasi("Görsel hedefi değişti. Yenileyin.");_=Number(d.MedyaId);await Oku(WebBolum.Gorsel,d.MedyaId,"",ct);object attachment=d.HedefBolum==WebBolum.Urun?new{images=new[]{d.MedyaId}.Concat(old.Gorseller??[]).Distinct().Select(id=>new{id=long.Parse(Number(id))}).ToArray()}:(object)new{featured_media=long.Parse(d.MedyaId)};var(result,_)=await http.Json(Request(HttpMethod.Post,Path(d.HedefBolum,d.Id,d.ParentId),Commerce(d.HedefBolum),attachment),ct,true);if(S(result,"id").Length==0)throw new WebApiHatasi("Görsel bağlama sonucu eksik.",true);return new(S(result,"id"),S(result,"status"),"Görsel bağlandı; mevcut ürün galerisi korundu.");}
  if(d.Id.Length>0){var current=await Oku(d.Bolum,d.Id,d.ParentId,ct);if(current.Surum!=d.BeklenenSurum)throw new WebApiHatasi("Kayıt sitede değişti. Yenileyip düzenleyin.");if(d.Bolum==WebBolum.Urun&&d.Fiyat is not null&&current.Ek!="simple")throw new ArgumentException("Bu ürünün fiyatı varyantlarından değiştirilmelidir.");if(d.Bolum==WebBolum.Stok&&current.Miktar!=d.BeklenenMiktar)throw new WebApiHatasi("Site stok miktarı değişti. Yenileyin.");}
  else if(d.Bolum is WebBolum.Varyant or WebBolum.Stok or WebBolum.Gorsel)throw new ArgumentException("Bu kayıt bu ekrandan oluşturulamaz.");
  if(d.Bolum is WebBolum.Urun or WebBolum.Varyant){if(d.Durum is not("draft" or "publish" or "pending" or "private")||d.Bolum==WebBolum.Varyant&&d.Durum is not("publish" or "private"))throw new ArgumentException("Yayın durumu geçersiz.");body=new{name=d.Bolum==WebBolum.Varyant?null:d.Baslik,description=d.Icerik,status=d.Id.Length==0?"draft":d.Durum,regular_price=d.Fiyat,type=d.Id.Length==0?"simple":null};}
  else if(d.Bolum==WebBolum.Stok)body=new{stock_quantity=d.Miktar};
  else if(d.Bolum==WebBolum.Gorsel)body=new{title=d.Baslik,caption=d.Icerik,alt_text=d.AltMetin};
  else{if(d.Durum is not("draft" or "publish" or "pending" or "private" or "future"))throw new ArgumentException("Yayın durumu geçersiz.");body=new{title=d.Baslik,content=d.Icerik,status=d.Id.Length==0?"draft":d.Durum};}
  var(j,_)=await http.Json(Request(HttpMethod.Post,Path(d.Bolum,d.Id,d.ParentId),Commerce(d.Bolum),body),ct,true);string id=S(j,"id");if(id.Length==0)throw new WebApiHatasi("Site kayıt kimliği dönmedi; sonucu sitede kontrol edin.",true);return new(id,S(j,"status"),"Site API'si kaydı kabul etti. Listeyi yenileyin.");
 }
 public async Task<WebSonuc> GorselYukle(string fileName,byte[] bytes,string mime,string alt,Guid operation,CancellationToken ct)
 {
  var q=Request(HttpMethod.Post,"wp-json/wp/v2/media");var form=new MultipartFormDataContent();var file=new ByteArrayContent(bytes);file.Headers.ContentType=new MediaTypeHeaderValue(mime);form.Add(file,"file",fileName);form.Add(new StringContent(alt),"alt_text");q.Content=form;
  var(j,_)=await http.Json(q,ct,true);string id=S(j,"id");if(id.Length==0)throw new WebApiHatasi("Yükleme kimliği alınamadı; medya kütüphanesini kontrol edin.",true);return new(id,"uploaded","Görsel medya kütüphanesine eklendi.");
 }
}
