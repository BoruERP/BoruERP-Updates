using System.Net;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
namespace MiapaxERP.Desktop.WebYonetimi;

public sealed class WebHttp:IDisposable
{
 readonly HttpClient client;public Uri Root{get;}
 public WebHttp(WebSite site,HttpMessageHandler? testHandler=null)
 {
  Root=Adres(site);var handler=testHandler??new SocketsHttpHandler{AllowAutoRedirect=false,UseProxy=false,UseCookies=false,AutomaticDecompression=DecompressionMethods.GZip|DecompressionMethods.Deflate,ConnectTimeout=TimeSpan.FromSeconds(10),ConnectCallback=Baglan};
  client=new HttpClient(handler){Timeout=TimeSpan.FromSeconds(45),MaxResponseContentBufferSize=8*1024*1024};
 }
 public static Uri Adres(WebSite site)
 {
  if(site.Id==Guid.Empty||string.IsNullOrWhiteSpace(site.Ad)||site.Ad.Length>160||site.Surum<1)throw new ArgumentException("Site kimliği/adı geçersiz.");
  if(!Uri.TryCreate(site.Adres,UriKind.Absolute,out var u)||u.Scheme!="https"||u.Port!=443||u.HostNameType!=UriHostNameType.Dns||u.IsLoopback||IPAddress.TryParse(u.Host,out _)||u.UserInfo.Length>0||u.Query.Length>0||u.Fragment.Length>0||!u.Host.Contains('.')||site.Adres.Contains('\\'))throw new ArgumentException("Sitenin HTTPS alan adını girin. IP, kullanıcı bilgisi, sorgu veya özel port kullanmayın.");
  if(site.Adres.Contains('%')||u.AbsolutePath.Contains('%')||u.AbsolutePath.Contains("//")||site.Adres.Split('/').Any(p=>p is "." or ".."))throw new ArgumentException("Site kurulum yolu geçersiz.");
  if(site.Platform==WebPlatform.Shopify&&(u.AbsolutePath!="/"||!u.IdnHost.EndsWith(".myshopify.com",StringComparison.OrdinalIgnoreCase)))throw new ArgumentException("Shopify için mağaza.myshopify.com kök adresini kullanın.");
  return new Uri(u.GetLeftPart(UriPartial.Path).TrimEnd('/')+"/");
 }
 public static bool GenelIp(IPAddress ip)
 {
  if(ip.IsIPv4MappedToIPv6)return GenelIp(ip.MapToIPv4());var b=ip.GetAddressBytes();
  if(ip.AddressFamily==AddressFamily.InterNetwork)return !(b[0] is 0 or 10 or 127||b[0]>=224||b[0]==169&&b[1]==254||b[0]==172&&b[1]>=16&&b[1]<=31||b[0]==192&&b[1]==168||b[0]==100&&b[1]>=64&&b[1]<=127||b[0]==198&&b[1] is 18 or 19||b[0]==192&&b[1]==0&&b[2] is 0 or 2||b[0]==198&&b[1]==51&&b[2]==100||b[0]==203&&b[1]==0&&b[2]==113||b[0]==192&&b[1]==88&&b[2]==99);
  return ip.AddressFamily==AddressFamily.InterNetworkV6&&b[0]>=0x20&&b[0]<=0x3f&&!(b[0]==0x20&&b[1]==0x01&&b[2]==0x0d&&b[3]==0xb8)&&!(b[0]==0x20&&b[1]==0x02)&&!(b[0]==0x20&&b[1]==0x01&&b[2]<2);
 }
 static async ValueTask<Stream> Baglan(SocketsHttpConnectionContext ctx,CancellationToken ct)
 {
  var ips=await Dns.GetHostAddressesAsync(ctx.DnsEndPoint.Host,ct);if(ips.Length==0||ips.Any(ip=>!GenelIp(ip)))throw new HttpRequestException("Site adresi genel internette güvenli bir hedefe çözülmüyor.");
  foreach(var ip in ips){var socket=new Socket(ip.AddressFamily,SocketType.Stream,ProtocolType.Tcp);try{await socket.ConnectAsync(new IPEndPoint(ip,ctx.DnsEndPoint.Port),ct);return new NetworkStream(socket,true);}catch{socket.Dispose();if(ct.IsCancellationRequested)throw;}}
  throw new HttpRequestException("Siteye bağlanılamadı.");
 }
 public HttpRequestMessage Istek(HttpMethod method,string relative,string? user=null,string? password=null,string? token=null)
 {
  if(Uri.TryCreate(relative,UriKind.Absolute,out _)||relative.StartsWith('/')||relative.Contains('\\')||relative.Split('/').Any(x=>x==".."))throw new ArgumentException("API yolu geçersiz.");
  var uri=new Uri(Root,relative);if(uri.Authority!=Root.Authority||!uri.AbsolutePath.StartsWith(Root.AbsolutePath,StringComparison.Ordinal))throw new ArgumentException("İstek site dışına çıkamaz.");
  var q=new HttpRequestMessage(method,uri);q.Headers.UserAgent.ParseAdd("MiapaxERP/2.5");
  if(token is not null)q.Headers.Authorization=new AuthenticationHeaderValue("Bearer",token);
  else if(user is not null)q.Headers.Authorization=new AuthenticationHeaderValue("Basic",Convert.ToBase64String(Encoding.UTF8.GetBytes(user+":"+password)));
  return q;
 }
 public async Task<(JsonElement Json,HttpResponseHeaders Headers)> Json(HttpRequestMessage q,CancellationToken ct,bool mutation=false)
 {
  try{using(q)using(var r=await client.SendAsync(q,ct)){
   if((int)r.StatusCode is >=300 and <400)throw new WebApiHatasi("Site yönlendirme döndürdü. Doğrudan HTTPS kurulum adresini kullanın; kimlik bilgileri yönlendirmeye gönderilmedi.",mutation);
   if(!r.IsSuccessStatusCode)throw new WebApiHatasi((int)r.StatusCode switch{401 or 403=>"Site API izni reddetti. Bu kullanıcı için gerekli erişimleri kontrol edin.",429=>"Site istek sınırına ulaştı. İşlemi göndermeden önce güncel durumu kontrol edin.",409 or 412=>"Sitedeki kayıt değişmiş. Yenileyip tekrar düzenleyin.",_=>$"Site API HTTP {(int)r.StatusCode} yanıtı verdi."},mutation&&(int)r.StatusCode>=500);
   using var doc=JsonDocument.Parse(await r.Content.ReadAsStringAsync(ct));return(doc.RootElement.Clone(),r.Headers);
  }}catch(WebApiHatasi){throw;}catch(Exception e)when(e is HttpRequestException or TaskCanceledException or JsonException){throw new WebApiHatasi(mutation?"İşlem sonucu kesinleşmedi. Yeniden göndermeden önce sitedeki kayıtları kontrol edin.":"Siteye ulaşılamadı veya yanıt okunamadı.",mutation);}
 }
 public static StringContent Govde(object value)=>new(WebJson.Yaz(value),Encoding.UTF8,"application/json");
 public async Task StagedUpload(string url,Dictionary<string,string> parameters,string name,byte[] bytes,string mime,CancellationToken ct)
 {
  if(!Uri.TryCreate(url,UriKind.Absolute,out var uri)||uri.Scheme!="https"||uri.Port!=443||uri.UserInfo.Length>0||uri.IsLoopback||uri.HostNameType!=UriHostNameType.Dns)throw new WebApiHatasi("Görsel yükleme hedefi geçersiz.");
  using var q=new HttpRequestMessage(HttpMethod.Post,uri);using var form=new MultipartFormDataContent();foreach(var p in parameters)form.Add(new StringContent(p.Value),p.Key);var file=new ByteArrayContent(bytes);file.Headers.ContentType=new(mime);form.Add(file,"file",name);q.Content=form;
  try{using var r=await client.SendAsync(q,ct);if(!r.IsSuccessStatusCode)throw new WebApiHatasi("Görselin yükleme aşaması tamamlanamadı.",true);}catch(HttpRequestException){throw new WebApiHatasi("Görsel yükleme sonucu belirsiz; siteden kontrol edin.",true);}
 }
 public void Dispose()=>client.Dispose();
}
