using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
namespace MiapaxERP.Desktop.WebYonetimi;

public enum WebPlatform { WordPress, WooCommerce, Shopify, OzelApi }
public enum WebBolum { Urun, Varyant, Sayfa, Yazi, Gorsel, Siparis, Blog, Stok, GorselBagla }
public sealed record WebSirlar(string WpKullanici="",string WpUygulamaParolasi="",string WooAnahtar="",string WooGizli="",string Token="")
{public override string ToString()=>"[Şifreli bağlantı bilgileri]";}
public sealed record WebSite(Guid Id,string Ad,WebPlatform Platform,string Adres,WebSirlar Sirlar,int Surum=1)
{public override string ToString()=>Ad;}
public sealed record WebKayit(WebBolum Bolum,string Id,string Baslik,string Icerik,string Durum,string Surum,string ParentId="",string Sku="",string Fiyat="",string Doviz="",string Tutar="",string Url="",string Ek="",int? Miktar=null,string EnvanterId="",string KonumId="",string AltMetin="",string Yazar="",string Musteri="",string Numara="",string Tarih="",string Adres="",string[]? Gorseller=null);
public sealed record WebSayfa(WebKayit[] Kayitlar,string? Sonraki);
public sealed record WebBaglanti(string Ad,string Doviz,string[] Ozellikler,string Not);
public sealed record WebDegisiklik(WebBolum Bolum,string Id,string Baslik,string Icerik,string Durum,string BeklenenSurum,string ParentId="",string? Fiyat=null,int? Miktar=null,int? BeklenenMiktar=null,string EnvanterId="",string KonumId="",string AltMetin="",string Yazar="",string BeklenenDoviz="",WebBolum HedefBolum=WebBolum.Urun,string MedyaId="");
public sealed record WebSonuc(string Id,string Durum,string Mesaj="");
public sealed class WebApiHatasi(string message,bool sonucBelirsiz=false):Exception(message){public bool SonucBelirsiz{get;}=sonucBelirsiz;}
public interface IWebSaglayici
{
 Task<WebBaglanti> BaglantiDene(CancellationToken ct);
 Task<WebSayfa> Liste(WebBolum bolum,string parent,string? cursor,CancellationToken ct);
 Task<WebKayit> Oku(WebBolum bolum,string id,string parent,CancellationToken ct);
 Task<WebSonuc> Kaydet(WebDegisiklik veri,Guid islem,CancellationToken ct);
 Task<WebSonuc> GorselYukle(string fileName,byte[] bytes,string mime,string alt,Guid islem,CancellationToken ct);
}
public static class WebJson
{
 public static readonly JsonSerializerOptions Ayar=new(){PropertyNamingPolicy=JsonNamingPolicy.CamelCase,DefaultIgnoreCondition=JsonIgnoreCondition.WhenWritingNull};
 public static string Yaz(object value)=>JsonSerializer.Serialize(value,Ayar);
 public static JsonElement P(JsonElement j,string key)=>j.ValueKind==JsonValueKind.Object&&j.TryGetProperty(key,out var v)?v:default;
 public static string S(JsonElement j,string key)=>P(j,key).ValueKind is JsonValueKind.Undefined or JsonValueKind.Null?"":P(j,key).ToString();
 public static IEnumerable<JsonElement> A(JsonElement j)=>j.ValueKind==JsonValueKind.Array?j.EnumerateArray():[];
 public static string Ozet(object value)=>Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(Yaz(value))));
 public static decimal Para(string value){if(!decimal.TryParse(value,NumberStyles.AllowDecimalPoint,CultureInfo.InvariantCulture,out var n)||n<0||n>999999999999m)throw new ArgumentException("Tutar geçersiz. Nokta ondalık ayırıcıyla, negatif olmayan sayı gerekir.");return n;}
 public static bool Yayinda(string s)=>s is "publish" or "ACTIVE" or "published";
 public static void Dogrula(WebDegisiklik d)
 {
  if(d.Baslik.Length>1000||d.Icerik.Length>500000||d.AltMetin.Length>1000)throw new ArgumentException("Başlık, içerik veya alternatif metin çok uzun.");
  if(d.Bolum is WebBolum.Siparis or WebBolum.Blog)throw new ArgumentException("Bu bölüm salt okunurdur.");
  if(d.Bolum is WebBolum.Sayfa or WebBolum.Yazi or WebBolum.Urun&&string.IsNullOrWhiteSpace(d.Baslik))throw new ArgumentException("Başlık gerekli.");
  if(d.Id.Length>0&&d.BeklenenSurum.Length==0)throw new ArgumentException("Önce sitedeki güncel kaydı yükleyin.");
  if(d.Fiyat is not null){_=Para(d.Fiyat);if(d.BeklenenDoviz.Length!=3||d.BeklenenDoviz.Any(c=>c<'A'||c>'Z'))throw new ArgumentException("Fiyat için doğrulanmış mağaza para birimi gerekir.");}
  if(d.Miktar<0||d.Miktar>100000000)throw new ArgumentException("Yeni site stok miktarı geçersiz.");
  if(d.Bolum==WebBolum.Stok&&(d.Miktar is null||d.BeklenenMiktar is null))throw new ArgumentException("Yeni ve okunan stok miktarı gerekli.");
  if(d.Bolum==WebBolum.GorselBagla&&(d.Id.Length==0||d.MedyaId.Length==0||d.HedefBolum is not(WebBolum.Urun or WebBolum.Sayfa or WebBolum.Yazi)))throw new ArgumentException("Görsel ve uygun hedef kayıt gerekli.");
 }
 public static string ResimTuru(byte[] bytes)
 {
  if(bytes.Length<12||bytes.Length>10*1024*1024)throw new ArgumentException("Görsel boyutu 12 bayt–10 MB olmalı.");
  if(bytes[0]==0xff&&bytes[1]==0xd8&&bytes[2]==0xff)return "image/jpeg";
  if(bytes.Take(8).SequenceEqual(new byte[]{137,80,78,71,13,10,26,10}))return "image/png";
  if(Encoding.ASCII.GetString(bytes,0,4)=="RIFF"&&Encoding.ASCII.GetString(bytes,8,4)=="WEBP")return "image/webp";
  throw new ArgumentException("Yalnız JPEG, PNG ve WebP görselleri desteklenir. Dosyanın gerçek biçimi kontrol edilir.");
 }
}
