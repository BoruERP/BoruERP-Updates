using System.Globalization;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using Binding=System.Windows.Data.Binding;
using Microsoft.Win32;
using Microsoft.Web.WebView2.Wpf;
namespace MiapaxERP.Desktop.WebYonetimi;

public sealed class WebYonetimPenceresi:Window
{
 readonly ComboBox sites=new(){MinWidth=270,DisplayMemberPath="Ad"},sections=new(){MinWidth=180,DisplayMemberPath="Ad",SelectedValuePath="Kod"};
 readonly DataGrid grid=new(){AutoGenerateColumns=false,IsReadOnly=true,CanUserAddRows=false,SelectionMode=DataGridSelectionMode.Single};
 readonly TextBlock status=new(){TextWrapping=TextWrapping.Wrap,Margin=new Thickness(8)},context=new(){TextWrapping=TextWrapping.Wrap,Margin=new Thickness(8)};
 readonly StackPanel tools=new();readonly WebDepo store;readonly Action<string> access;readonly string connection;readonly int actor;readonly CancellationTokenSource stop=new();
 WebYonetimServisi? service;WebBaglanti? linked;string? next;string parent="";bool busy;readonly List<Control> controls=[];
 readonly Dictionary<string,Button> actions=[];
 WebSite Site=>sites.SelectedItem as WebSite??throw new ArgumentException("Önce site bağlantısını seçin.");
 WebBolum Kind=>sections.SelectedValue is WebBolum b?b:WebBolum.Sayfa;
 public WebYonetimPenceresi(string connection,int actor)
 {
  this.connection=connection;this.actor=actor;var db=new ErpModulServisi(connection,actor);access=p=>{if(HttpsOturumu.Uzak(connection))new WebHttpsServisi(connection,actor).Yetki(p);else{using var c=db.Ac();db.Yetki(c,null,p);}};access("ECOM.VIEW");store=new WebDepo(WebDepo.Klasor(connection,actor),connection);
  Title="MiapaxERP | Web Sitesi Yönetimi";Width=1260;Height=820;MinWidth=980;WindowStartupLocation=WindowStartupLocation.CenterOwner;
  var shell=new DockPanel{Margin=new Thickness(22)};Content=shell;var top=new StackPanel();DockPanel.SetDock(top,Dock.Top);shell.Children.Add(top);
  top.Children.Add(new TextBlock{Text="Web Sitesi Yönetimi",FontSize=27,FontWeight=FontWeights.Bold});
  top.Children.Add(new TextBlock{Text="Kendi sitenizin ürün, stok, fiyat, sipariş ve içeriklerini yönetin. Bağlantılar bu veritabanı ve ERP kullanıcısına özeldir.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,7,0,14)});
  var connectionBar=new WrapPanel();top.Children.Add(connectionBar);connectionBar.Children.Add(sites);controls.Add(sites);
  Button(connectionBar,"+ Site ekle",()=>{EditConnection(null);return Task.CompletedTask;});Button(connectionBar,"Bağlantıyı düzenle",()=>{EditConnection(Site);return Task.CompletedTask;});Button(connectionBar,"Bağlantıyı doğrula",Connect);
  var resourceBar=new WrapPanel{Margin=new Thickness(0,14,0,0)};top.Children.Add(resourceBar);resourceBar.Children.Add(sections);controls.Add(sections);
  actions["parent"]=Button(resourceBar,"Üst kayıt seç",async()=>{var p=await Pick(WebBolum.Urun);if(p is not null){parent=p.Id;context.Text="Seçili üst kayıt: "+p.Baslik;await Load(false);}});
  Button(resourceBar,"Listeyi getir",()=>Load(false));Button(resourceBar,"Sonraki sayfa",()=>Load(true));
  var buttons=new WrapPanel();top.Children.Add(buttons);
  actions["create"]=Button(buttons,"Yeni taslak",Create);actions["edit"]=Button(buttons,"Seçili kaydı düzenle",Edit);actions["variants"]=Button(buttons,"Ürünün varyantları",Variants);actions["stock"]=Button(buttons,"Site stok miktarı",Stock);actions["upload"]=Button(buttons,"Görsel yükle",Upload);actions["copy"]=Button(buttons,"Görsel bağlantısını kopyala",CopyImage);actions["attach"]=Button(buttons,"Görsel bağla",Attach);actions["import"]=Button(buttons,"Siparişi ERP'ye aktar",Import);Button(buttons,"İşlem geçmişi",History);
  top.Children.Add(context);DockPanel.SetDock(status,Dock.Bottom);shell.Children.Add(status);shell.Children.Add(grid);
  foreach(var (name,path,width)in new[]{("Kayıt / Başlık","Baslik",320),("Durum","Durum",110),("Stok kodu","Sku",140),("Fiyat","Fiyat",95),("Miktar","Miktar",75),("Döviz","Doviz",65),("Sipariş tutarı","Tutar",110),("Kimlik","Id",200)})grid.Columns.Add(new DataGridTextColumn{Header=name,Binding=new Binding(path),Width=width});
  sites.SelectionChanged+=(_,_)=>{if(busy)return;service?.Dispose();service=null;linked=null;parent="";next=null;grid.ItemsSource=null;context.Text="";Sections();status.Text="Bağlantı seçildi. Önce Bağlantıyı doğrula düğmesini kullanın.";};
  sections.SelectionChanged+=(_,_)=>{parent="";next=null;grid.ItemsSource=null;context.Text="";RefreshTools();};
  Closed+=(_,_)=>{stop.Cancel();if(!busy)service?.Dispose();};LoadConnections();
 }
 Button Button(Panel panel,string text,Func<Task> action)
 {
  var b=new Button{Content=text,Margin=new Thickness(5),Padding=new Thickness(10,7,10,7)};panel.Children.Add(b);controls.Add(b);
  b.Click+=async(_,_)=>{if(busy)return;busy=true;foreach(var c in controls)c.IsEnabled=false;try{await action();}catch(OperationCanceledException){status.Text="İşlem durdu. Gönderilmiş değişiklikler için site listesini kontrol edin.";}catch(Exception e){status.Text=e.Message;}finally{busy=false;if(!IsLoaded)service?.Dispose();else foreach(var c in controls)c.IsEnabled=true;}};
  return b;
 }
 void RefreshTools(){void Show(string key,bool visible){if(actions.TryGetValue(key,out var b))b.Visibility=visible?Visibility.Visible:Visibility.Collapsed;}Show("parent",Kind==WebBolum.Varyant);Show("create",Kind is WebBolum.Urun or WebBolum.Sayfa or WebBolum.Yazi);Show("edit",Kind!=WebBolum.Siparis);Show("variants",Kind==WebBolum.Urun);Show("stock",Kind is WebBolum.Urun or WebBolum.Varyant);Show("upload",Kind==WebBolum.Gorsel);Show("copy",Kind==WebBolum.Gorsel);Show("import",Kind==WebBolum.Siparis);Show("attach",sites.SelectedItem is WebSite s&&s.Platform!=WebPlatform.OzelApi&&(Kind==WebBolum.Urun||(s.Platform is WebPlatform.WordPress or WebPlatform.WooCommerce)&&(Kind is WebBolum.Sayfa or WebBolum.Yazi)));}
 void LoadConnections(Guid? choose=null){sites.ItemsSource=store.Siteler().OrderBy(x=>x.Ad).ToArray();if(choose.HasValue)sites.SelectedItem=sites.Items.Cast<WebSite>().FirstOrDefault(s=>s.Id==choose);else if(sites.Items.Count>0)sites.SelectedIndex=0;Sections();}
 void Sections()
 {
  var items=new List<Section>{new(WebBolum.Sayfa,"Sayfalar"),new(WebBolum.Yazi,"Yazılar / Duyurular"),new(WebBolum.Gorsel,"Görseller")};
  if(sites.SelectedItem is WebSite{Platform:not WebPlatform.WordPress}){items.Insert(0,new(WebBolum.Urun,"Ürünler"));items.Insert(1,new(WebBolum.Varyant,"Varyantlar / Fiyatlar"));items.Add(new(WebBolum.Siparis,"Siparişler"));}
  if(sites.SelectedItem is WebSite{Platform:WebPlatform.OzelApi}&&linked is not null){string Feature(WebBolum b)=>b switch{WebBolum.Urun=>"products",WebBolum.Varyant=>"variants",WebBolum.Sayfa=>"pages",WebBolum.Yazi=>"posts",WebBolum.Gorsel=>"media",WebBolum.Siparis=>"orders",_=>""};items.RemoveAll(i=>!linked.Ozellikler.Contains(Feature(i.Kod)));}
  sections.ItemsSource=items;sections.SelectedIndex=items.Count>0?0:-1;RefreshTools();
 }
 public sealed record Section(WebBolum Kod,string Ad);
 async Task Connect()
 {
  service?.Dispose();service=new(Site,store.Folder,access,erpConnection:connection);linked=null;grid.ItemsSource=null;next=null;status.Text="Site API bağlantısı kontrol ediliyor…";
  linked=await Task.Run(()=>service.BaglantiDene(stop.Token));Sections();status.Text=linked.Ad+(linked.Doviz.Length>0?" · "+linked.Doviz:"")+" · "+linked.Not;
 }
 WebYonetimServisi Ready()=>service is not null&&linked is not null?service:throw new InvalidOperationException("Önce site bağlantısını doğrulayın.");
 WebKayit Selected()=>grid.SelectedItem as WebKayit??throw new ArgumentException("Listeden bir kayıt seçin.");
 async Task Load(bool more)
 {
  var s=Ready();if(more&&next is null){status.Text="Devam sayfası yok.";return;}if(Kind==WebBolum.Varyant&&parent.Length==0)throw new ArgumentException("Önce Üst kayıt seç ile ürünü seçin.");
  var page=await Task.Run(()=>s.Liste(Kind,parent,more?next:null,stop.Token));next=page.Sonraki;grid.ItemsSource=page.Kayitlar.Select(x=>x.Doviz.Length==0?x with{Doviz=linked!.Doviz}:x).ToArray();status.Text=$"{page.Kayitlar.Length} kayıt. "+(next is null?"Son sayfa.":"Sonraki sayfadan devam edebilirsiniz.");
 }
 async Task<WebKayit?> Pick(WebBolum kind,string pickParent="")
 {
  var s=Ready();var w=new Window{Title=kind==WebBolum.Blog?"Yazının blogunu seçin":kind==WebBolum.Stok?"Stok konumunu seçin":"Ürünü seçin",Owner=this,Width=850,Height=570,WindowStartupLocation=WindowStartupLocation.CenterOwner};var dock=new DockPanel{Margin=new Thickness(18)};w.Content=dock;var bar=new WrapPanel();DockPanel.SetDock(bar,Dock.Bottom);dock.Children.Add(bar);var rows=new DataGrid{AutoGenerateColumns=false,IsReadOnly=true,CanUserAddRows=false};rows.Columns.Add(new DataGridTextColumn{Header="Başlık / Konum",Binding=new Binding("Baslik"),Width=380});rows.Columns.Add(new DataGridTextColumn{Header="Miktar",Binding=new Binding("Miktar"),Width=80});rows.Columns.Add(new DataGridTextColumn{Header="Kimlik",Binding=new Binding("Id"),Width=270});dock.Children.Add(rows);string? cursor=null;WebKayit? result=null;
  Button choose=new(){Content="Seç",Padding=new Thickness(15,8,15,8),Margin=new Thickness(5)},more=new(){Content="Sonraki sayfa",Padding=new Thickness(15,8,15,8),Margin=new Thickness(5)};bar.Children.Add(choose);bar.Children.Add(more);choose.Click+=(_,_)=>{if(rows.SelectedItem is WebKayit r){result=r;w.DialogResult=true;}};
  async Task Fetch(){more.IsEnabled=false;try{var p=await Task.Run(()=>s.Liste(kind,pickParent,cursor,stop.Token));rows.ItemsSource=p.Kayitlar;cursor=p.Sonraki;more.IsEnabled=cursor is not null;}catch(Exception e){MessageBox.Show(w,e.Message);}}
  more.Click+=async(_,_)=>await Fetch();await Fetch();w.ShowDialog();return result;
 }
 async Task Create()
 {
  var s=Ready();if(Kind is not(WebBolum.Urun or WebBolum.Sayfa or WebBolum.Yazi))throw new InvalidOperationException("Bu bölümde yeni taslak oluşturulmaz.");string upper="";if(Kind==WebBolum.Yazi&&Site.Platform==WebPlatform.Shopify){var blog=await Pick(WebBolum.Blog);if(blog is null)return;upper=blog.Id;}
  var row=new WebKayit(Kind,"","","",Site.Platform==WebPlatform.Shopify&&Kind==WebBolum.Urun?"DRAFT":"draft","",upper);await EditRecord(row);
 }
 async Task Edit(){var r=Selected();if(r.Bolum==WebBolum.Siparis)throw new InvalidOperationException("Siparişler burada izlenir ve ERP'ye aktarılır. Tahsilat/iade/kargo değişikliği yapılmaz.");var full=await Task.Run(()=>Ready().Oku(r.Bolum,r.Id,r.ParentId,stop.Token));await EditRecord(full);}
 async Task Variants(){var p=Selected();if(p.Bolum!=WebBolum.Urun)throw new ArgumentException("Önce ürün seçin.");sections.SelectedValue=WebBolum.Varyant;parent=p.Id;context.Text="Ürün: "+p.Baslik;await Load(false);}
 async Task Stock()
 {
  var row=Selected();if(row.Bolum is not(WebBolum.Urun or WebBolum.Varyant))throw new ArgumentException("Önce ürün veya varyant seçin.");WebKayit? stock;
  if(Site.Platform==WebPlatform.Shopify){if(row.Bolum!=WebBolum.Varyant||row.EnvanterId.Length==0||row.Durum!="tracked")throw new ArgumentException("Önce stok takibi açık bir varyant seçin.");stock=await Pick(WebBolum.Stok,row.EnvanterId);}
  else stock=await Task.Run(()=>Ready().Oku(WebBolum.Stok,row.Id,row.ParentId,stop.Token));
  if(stock is null)return;if(stock.Miktar is null)throw new InvalidOperationException("Bu ürünün site stok takibi açık değil. Site yönetiminde takibi açıp yeniden yükleyin.");await EditRecord(stock);
 }
 async Task EditRecord(WebKayit before)
 {
  var s=Ready();access("ECOM.EDIT");bool creating=before.Id.Length==0,isStock=before.Bolum==WebBolum.Stok,isVariant=before.Bolum==WebBolum.Varyant,isMedia=before.Bolum==WebBolum.Gorsel;
  var w=new Window{Title=creating?"Yeni taslak":"Site kaydını düzenle",Owner=this,Width=850,Height=isStock?460:830,WindowStartupLocation=WindowStartupLocation.CenterOwner};var p=new StackPanel{Margin=new Thickness(22)};w.Content=new ScrollViewer{Content=p};p.Children.Add(new TextBlock{Text=Site.Ad+" · "+WebHttp.Adres(Site).AbsoluteUri,FontSize=18,FontWeight=FontWeights.SemiBold});
  TextBox Field(string caption,string value,bool multi=false){p.Children.Add(new TextBlock{Text=caption,Margin=new Thickness(0,13,0,5)});var f=new TextBox{Text=value,Padding=new Thickness(7),MinHeight=32,AcceptsReturn=multi,TextWrapping=multi?TextWrapping.Wrap:TextWrapping.NoWrap,VerticalScrollBarVisibility=multi?ScrollBarVisibility.Auto:ScrollBarVisibility.Disabled};if(multi)f.Height=230;p.Children.Add(f);return f;}
  var title=Field("Başlık / Ürün",before.Baslik);title.IsReadOnly=isStock||isVariant||isMedia&&Site.Platform==WebPlatform.Shopify;
  TextBox? content=null,price=null,quantity=null,alt=null,author=null;ComboBox? state=null;
  if(isStock){p.Children.Add(new TextBlock{Text="Okunan site stok miktarı: "+before.Miktar,Margin=new Thickness(0,13,0,3)});quantity=Field("Yeni site stok miktarı",before.Miktar!.Value.ToString());p.Children.Add(new TextBlock{Text="Bu işlem yalnız seçili site ürününü/konumunu değiştirir. Fabrika stok hareketi oluşturmaz. Sitedeki siparişler stok miktarını değiştirebilir.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,12,0,0)});}
  else
  {
   content=Field(isMedia?"Açıklama / Başlık altı":"İçerik / Açıklama (mevcut biçimlendirme korunur)",before.Icerik,true);content.IsReadOnly=isVariant&&Site.Platform==WebPlatform.Shopify||isMedia&&Site.Platform==WebPlatform.Shopify;
   if(!isVariant&&!isMedia){p.Children.Add(new TextBlock{Text="Yayın durumu",Margin=new Thickness(0,12,0,5)});var states=Site.Platform==WebPlatform.Shopify?(before.Bolum==WebBolum.Urun?new[]{"DRAFT","ACTIVE","ARCHIVED"}:new[]{"draft","published"}):new[]{"draft","publish","pending","private","future"};state=new ComboBox{ItemsSource=states,SelectedItem=before.Durum,MinHeight=32,IsEnabled=!creating};p.Children.Add(state);if(creating)p.Children.Add(new TextBlock{Text="Yeni kayıt önce taslak oluşturulur. Yayımlamak için kaydı yeniden açıp durumunu değiştirin.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,7,0,0)});}
   bool canPrice=isVariant||before.Bolum==WebBolum.Urun&&Site.Platform==WebPlatform.WooCommerce&&!creating&&before.Ek=="simple";
   if(canPrice){if(linked!.Doviz.Length!=3)throw new InvalidOperationException("Fiyat değiştirmeden önce mağazanın para birimini doğrulayın.");price=Field("Site satış fiyatı ("+linked.Doviz+") · nokta ondalık ayırıcı",before.Fiyat);}
   if(isMedia)alt=Field("Görsel alternatif metni",before.AltMetin);
   if(creating&&before.Bolum==WebBolum.Yazi&&Site.Platform==WebPlatform.Shopify)author=Field("Yazar adı","");
  }
  var feedback=new TextBlock{TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,12,0,12)};p.Children.Add(feedback);var bar=new WrapPanel();p.Children.Add(bar);
  var preview=new Button{Content="İçeriği önizle",Padding=new Thickness(12),Margin=new Thickness(4),IsEnabled=content is not null&&!isMedia&&!isVariant};bar.Children.Add(preview);preview.Click+=async(_,_)=>{try{await Preview(content!.Text);}catch(Exception e){feedback.Text=e.Message;}};
  var save=new Button{Content=isStock?"Stok düzeltmesini gönder":creating?"Taslak oluştur":"Değişiklikleri gönder",Padding=new Thickness(12),Margin=new Thickness(4)};bar.Children.Add(save);Guid operation=Guid.NewGuid();bool attempted=false;
  save.Click+=async(_,_)=>{
   save.IsEnabled=false;try{
    string targetState=state?.SelectedItem as string??before.Durum;
    int? targetQuantity=null;if(isStock){if(!int.TryParse(quantity!.Text,out var q))throw new ArgumentException("Stok tam sayı olmalı.");targetQuantity=q;}
    string? targetPrice=null;if(price is not null){_=WebJson.Para(price.Text);if(price.Text!=before.Fiyat)targetPrice=price.Text;}
    var change=new WebDegisiklik(before.Bolum,before.Id,title.Text,content?.Text??before.Icerik,targetState,before.Surum,before.ParentId,targetPrice,targetQuantity,before.Miktar,before.EnvanterId,before.KonumId,alt?.Text??before.AltMetin,author?.Text??before.Yazar,linked!.Doviz);
    WebJson.Dogrula(change);string summary=Site.Ad+"\n"+WebHttp.Adres(Site).AbsoluteUri+"\n\n"+before.Bolum+": "+change.Baslik+"\nDurum: "+before.Durum+" → "+(creating?"Taslak":change.Durum)+(targetPrice is not null?"\nFiyat: "+before.Fiyat+" → "+targetPrice+" "+linked!.Doviz:"")+(isStock?"\nSite stok miktarı: "+before.Miktar+" → "+targetQuantity:"");
    if(MessageBox.Show(w,summary+"\n\nBu siteye gönderilsin mi?","Site değişikliği",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)return;
    var result=await Task.Run(()=>s.Kaydet(change,operation,stop.Token));status.Text=result.Mesaj+" · Kimlik: "+result.Id;w.DialogResult=true;
   }catch(Exception e){attempted=HttpsOturumu.Uzak(connection)?new WebHttpsServisi(connection,actor).DenemeVar(Site.Id,operation):new WebIslemDefteri(store.Folder).DenemeVar(Site.Id,operation);feedback.Text=e.Message+(attempted?" Düzenlemeyi kapatıp site listesini yenileyin; bu deneme tekrar gönderilmez.":"");}finally{save.IsEnabled=!attempted;}
  };
  w.ShowDialog();await Task.CompletedTask;
 }
 async Task Upload()
 {
  var s=Ready();access("ECOM.APPROVE");var dialog=new OpenFileDialog{Filter="Görseller|*.jpg;*.jpeg;*.png;*.webp",Multiselect=false};if(dialog.ShowDialog(this)!=true)return;
  if(MessageBox.Show(this,Site.Ad+" sitesinin medya kütüphanesine "+Path.GetFileName(dialog.FileName)+" yüklenecek. Dosya sitede herkese açık olabilir. Devam edilsin mi?","Görsel yükleme",MessageBoxButton.YesNo)!=MessageBoxResult.Yes)return;
  var result=await Task.Run(()=>s.GorselYukle(dialog.FileName,"",Guid.NewGuid(),stop.Token));status.Text=result.Mesaj+" · "+result.Id;
 }
 Task CopyImage(){var r=Selected();if(r.Bolum!=WebBolum.Gorsel||!Uri.TryCreate(r.Url,UriKind.Absolute,out var url)||url.Scheme!="https")throw new ArgumentException("Önce hazır bir görsel seçin. İşlenmekte olan dosyanın bağlantısı henüz oluşmamış olabilir.");Clipboard.SetText(url.AbsoluteUri);status.Text="Görsel bağlantısı kopyalandı. İçerikte bu görsele bağlantı verebilirsiniz.";return Task.CompletedTask;}
 async Task Attach(){access("ECOM.APPROVE");var selected=Selected();if(selected.Bolum is not(WebBolum.Urun or WebBolum.Sayfa or WebBolum.Yazi))throw new ArgumentException("Önce ürün, sayfa veya yazı seçin.");var current=await Task.Run(()=>Ready().Oku(selected.Bolum,selected.Id,selected.ParentId,stop.Token));var image=await Pick(WebBolum.Gorsel);if(image is null)return;if(MessageBox.Show(this,Site.Ad+"\n"+WebHttp.Adres(Site).AbsoluteUri+"\n"+current.Baslik+"\n\nSeçilen görsel bu kayda bağlansın mı? WooCommerce ürününde kapak yapılır ve mevcut galeri korunur; Shopify ürününde galeriye eklenir.","Görsel bağla",MessageBoxButton.YesNo)!=MessageBoxResult.Yes)return;var result=await Task.Run(()=>Ready().Kaydet(new(WebBolum.GorselBagla,current.Id,current.Baslik,"",current.Durum,current.Surum,current.ParentId,HedefBolum:current.Bolum,MedyaId:image.Id),Guid.NewGuid(),stop.Token));status.Text=result.Mesaj;}
 async Task Import()
 {
  Ready();access("ECOM.EDIT");var r=Selected();if(r.Bolum!=WebBolum.Siparis)throw new ArgumentException("Bir sipariş seçin.");r=await Task.Run(()=>Ready().Oku(WebBolum.Siparis,r.Id,r.ParentId,stop.Token));if(r.Ek=="partial")throw new InvalidOperationException("Siparişin kalemleri kısmi. Tam kalem bilgisi olmadan bu ekrandan aktarılmaz; mevcut sağlayıcı ekranını veya site yönetimini kullanın.");
  var input=WebSiparisBelgesi.Olustur(Site,r);
  if(MessageBox.Show(this,$"{input.Firma}\nKaynak tarih: {input.Tarih:d}\nTutar: {input.Tutar} {input.Doviz}\n\nERP e-ticaret dosyası olarak kaydedilsin mi? Site siparişinin ödeme/kargo durumu değişmez; ödeme koşulu ve vade ayrıca kontrol edilir.","Sipariş aktarımı",MessageBoxButton.YesNo)!=MessageBoxResult.Yes)return;
  await Task.Run(()=>new TicaretDosyalari(connection,actor,"ECOM").Kaydet(input));status.Text="Sipariş e-ticaret dosyalarına aktarıldı. Aynı kaynak başvurusu tekrar eklenmez.";
 }
 Task History(){var rows=HttpsOturumu.Uzak(connection)?new WebHttpsServisi(connection,actor).Gecmis():new WebIslemDefteri(store.Folder).Liste();var w=new Window{Title="Web işlem geçmişi · son 100",Owner=this,Width=1000,Height=540,WindowStartupLocation=WindowStartupLocation.CenterOwner};var g=new DataGrid{IsReadOnly=true,CanUserAddRows=false,AutoGenerateColumns=false,ItemsSource=rows};foreach(var(h,path)in new[]{("Zaman","Zaman"),("Site kimliği","Site"),("İşlem","Islem"),("Durum","Durum"),("Sonuç kaydı","Sonuc.Id")})g.Columns.Add(new DataGridTextColumn{Header=h,Binding=new Binding(path),Width=180});w.Content=g;w.ShowDialog();return Task.CompletedTask;}
 void EditConnection(WebSite? before)
 {
  access("ECOM.EDIT");var w=new Window{Title="Site bağlantısı",Owner=this,Width=680,Height=820,WindowStartupLocation=WindowStartupLocation.CenterOwner};var p=new StackPanel{Margin=new Thickness(22)};w.Content=new ScrollViewer{Content=p};
  Panel container=p;
  TextBox Text(string caption,string value){container.Children.Add(new TextBlock{Text=caption,Margin=new Thickness(0,10,0,5)});var x=new TextBox{Text=value,Padding=new Thickness(6),MinHeight=30};container.Children.Add(x);return x;}
  PasswordBox Secret(string caption,string value){container.Children.Add(new TextBlock{Text=caption,Margin=new Thickness(0,10,0,5)});var x=new PasswordBox{Password=value,Padding=new Thickness(6),MinHeight=30};container.Children.Add(x);return x;}
  var name=Text("Site adı",before?.Ad??"");p.Children.Add(new TextBlock{Text="Altyapı",Margin=new Thickness(0,10,0,5)});var platform=new ComboBox{ItemsSource=Enum.GetValues<WebPlatform>(),SelectedItem=before?.Platform??WebPlatform.WooCommerce,MinHeight=32,IsEnabled=before is null};p.Children.Add(platform);var url=Text("HTTPS site adresi · WordPress alt klasörü desteklenir",before?.Adres??"");url.IsReadOnly=before is not null;
  StackPanel wp=new(),woo=new(),tokenPanel=new();p.Children.Add(wp);p.Children.Add(woo);p.Children.Add(tokenPanel);
  container=wp;var wpUser=Text("WordPress kullanıcı adı",before?.Sirlar.WpKullanici??"");var wpPass=Secret("WordPress uygulama parolası · ana hesap parolası değil",before?.Sirlar.WpUygulamaParolasi??"");container=woo;var wcKey=Secret("WooCommerce tüketici anahtarı",before?.Sirlar.WooAnahtar??"");var wcSecret=Secret("WooCommerce gizli anahtarı",before?.Sirlar.WooGizli??"");container=tokenPanel;var token=Secret("Shopify / özel API erişim token'ı",before?.Sirlar.Token??"");container=p;
  void Groups(){var value=(WebPlatform)platform.SelectedItem;wp.Visibility=value is WebPlatform.WordPress or WebPlatform.WooCommerce?Visibility.Visible:Visibility.Collapsed;woo.Visibility=value==WebPlatform.WooCommerce?Visibility.Visible:Visibility.Collapsed;tokenPanel.Visibility=value is WebPlatform.Shopify or WebPlatform.OzelApi?Visibility.Visible:Visibility.Collapsed;}platform.SelectionChanged+=(_,_)=>Groups();Groups();
  p.Children.Add(new TextBlock{Text="WordPress/WooCommerce için içerik ve mağaza API bilgileri ayrıdır. Shopify için mağaza.myshopify.com kullanın. Özel sitenin MiapaxERP Web API v1 sözleşmesini uygulaması gerekir. Kullanılmayan alanlar boş kalabilir.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,12,0,10)});
  var result=new TextBlock{TextWrapping=TextWrapping.Wrap};p.Children.Add(result);var save=new Button{Content="Şifreli bağlantıyı kaydet",Padding=new Thickness(12),Margin=new Thickness(0,15,0,0)};p.Children.Add(save);
  save.Click+=(_,_)=>{try{var type=(WebPlatform)platform.SelectedItem;var secret=type switch{WebPlatform.WordPress=>new WebSirlar(wpUser.Text.Trim(),wpPass.Password),WebPlatform.WooCommerce=>new WebSirlar(wpUser.Text.Trim(),wpPass.Password,wcKey.Password,wcSecret.Password),_=>new WebSirlar(Token:token.Password)};var site=new WebSite(before?.Id??Guid.NewGuid(),name.Text.Trim(),type,url.Text.Trim(),secret,before?.Surum??1);access("ECOM.EDIT");store.Kaydet(site);service?.Dispose();service=null;linked=null;LoadConnections(site.Id);w.DialogResult=true;status.Text="Bağlantı şifreli kaydedildi. Henüz canlı API doğrulaması yapılmadı; Bağlantıyı doğrula düğmesini kullanın.";}catch(Exception e){result.Text=e.Message;}};
  w.ShowDialog();
 }
 async Task Preview(string html)
 {
  var w=new Window{Title="İçerik önizleme · betikler ve dış bağlantılar kapalı",Owner=this,Width=850,Height=650,WindowStartupLocation=WindowStartupLocation.CenterOwner};var web=new WebView2();w.Content=web;w.Show();try{await web.EnsureCoreWebView2Async();var core=web.CoreWebView2;core.Settings.IsScriptEnabled=false;core.Settings.AreHostObjectsAllowed=false;core.Settings.IsWebMessageEnabled=false;core.Settings.AreDefaultScriptDialogsEnabled=false;core.NewWindowRequested+=(_,e)=>e.Handled=true;core.DownloadStarting+=(_,e)=>e.Cancel=true;core.PermissionRequested+=(_,e)=>e.State=Microsoft.Web.WebView2.Core.CoreWebView2PermissionState.Deny;core.NavigationStarting+=(_,e)=>{if(e.Uri!="about:blank")e.Cancel=true;};core.AddWebResourceRequestedFilter("*",Microsoft.Web.WebView2.Core.CoreWebView2WebResourceContext.All);core.WebResourceRequested+=(_,e)=>e.Response=core.Environment.CreateWebResourceResponse(new MemoryStream(),403,"Blocked","");core.NavigateToString("<!doctype html><meta charset=utf-8><meta http-equiv=\"Content-Security-Policy\" content=\"default-src 'none'; img-src data:; style-src 'unsafe-inline'; script-src 'none'; frame-src 'none'; form-action 'none'; base-uri 'none'\"><style>body{font-family:Segoe UI;margin:25px;line-height:1.6;overflow-wrap:anywhere}</style>"+html);}catch{w.Close();throw;}w.Closed+=(_,_)=>web.Dispose();
 }
}
