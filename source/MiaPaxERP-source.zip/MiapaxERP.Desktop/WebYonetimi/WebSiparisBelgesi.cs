using System.Globalization;
namespace MiapaxERP.Desktop.WebYonetimi;
public static class WebSiparisBelgesi
{
 public static bool AyniKaynak(Dictionary<string,string> left,Dictionary<string,string> right)
 {
  static (string,string,string)? Key(Dictionary<string,string> d){var id=d.GetValueOrDefault("Kaynak kimliği","");var channel=d.GetValueOrDefault("Kanal / mağaza","").Split(" / ",2);if(id.Length==0||channel.Length!=2||channel[0] is not("WooCommerce" or "Shopify" or "WordPress" or "OzelApi"))return null;var root=d.GetValueOrDefault("Site kökü",channel[1]);if(!root.StartsWith("https://",StringComparison.OrdinalIgnoreCase))root="https://"+root;if(!Uri.TryCreate(root,UriKind.Absolute,out var u)||u.Scheme!="https"||u.UserInfo.Length>0)return null;return(channel[0],u.GetLeftPart(UriPartial.Authority).ToLowerInvariant()+u.AbsolutePath.TrimEnd('/'),id);}
  var a=Key(left);return a is not null&&a==Key(right);
 }
 public static string Kaynak(WebSite site,string id){var u=WebHttp.Adres(site);return site.Platform+"|"+u.GetLeftPart(UriPartial.Authority).ToLowerInvariant()+u.AbsolutePath.TrimEnd('/')+"|"+id;}
 public static TicaretGirdi Olustur(WebSite site,WebKayit order)
 {
  if(order.Bolum!=WebBolum.Siparis||order.Id.Length==0||order.Ek=="partial")throw new ArgumentException("Tam kaynak sipariş kaydı gerekli.");
  if(!DateTimeOffset.TryParse(order.Tarih,CultureInfo.InvariantCulture,DateTimeStyles.AssumeUniversal,out var date))throw new ArgumentException("Kaynak sipariş tarihi eksik/geçersiz; bugünün tarihi atanmadı.");
  if(order.Musteri.Length==0||order.Musteri.Length>160)throw new ArgumentException("Kaynak müşteri adı eksik/çok uzun. Site API erişimini kontrol edin; müşteri bilgisi uydurulmadı.");
  if(order.Doviz is not("TRY" or "USD" or "EUR" or "GBP"))throw new ArgumentException("Mevcut ERP sipariş dosyası TRY/USD/EUR/GBP destekler. Kur veya para birimi dönüşümü otomatik yapılmadı.");
  var total=WebJson.Para(order.Tutar);if(decimal.Round(total,2)!=total)throw new ArgumentException("ERP sipariş tutarı en fazla iki ondalık kabul eder. Kaynak tutar yuvarlanmadı.");var root=WebHttp.Adres(site);var title="Sipariş "+order.Numara;
  return new("WEB-"+WebJson.Ozet(Kaynak(site,order.Id))[..48],"Mağaza siparişi",order.Musteri,title.Length>180?title[..180]:title,"",date.Date,date.Date,total,order.Doviz,new(){["Kanal / mağaza"]=site.Platform+" / "+root.AbsoluteUri,["Kaynak kimliği"]=order.Id,["Kaynak sipariş no"]=order.Numara,["Kaynak durumu"]=order.Durum,["Kaynak tarihi"]=order.Tarih,["Site kökü"]=root.AbsoluteUri,["Teslimat adresi"]=order.Adres,["Ürünler ve adetleri"]=order.Icerik},"Web Sitesi Yönetimi aktarımı. Kaynak takvim tarihi kullanıldı; vade/ödeme koşulu ERP'de ayrıca doğrulanmalıdır. Stok, fatura veya tahsilat oluşturulmadı.");
 }
}
