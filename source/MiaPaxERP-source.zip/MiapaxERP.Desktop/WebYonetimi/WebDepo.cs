using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Data.SqlClient;
namespace MiapaxERP.Desktop.WebYonetimi;

public sealed class WebDepo(string folder,string? erpConnection=null)
{
 WebHttpsServisi Proxy()=>new(erpConnection!,HttpsOturumu.Istemci?.Oturum?.Kullanici.Id??throw new UnauthorizedAccessException());
 bool Remote=>erpConnection is not null&&HttpsOturumu.Uzak(erpConnection);
 public string Folder{get;}=Path.GetFullPath(folder);
 public static string Klasor(string connection,int user){if(user<1)throw new ArgumentException("ERP kullanıcısı gerekli.");string scope;if(HttpsOturumu.Uzak(connection))scope=connection;else{var b=new SqlConnectionStringBuilder(connection);scope=b.DataSource.Trim().ToUpperInvariant()+"|"+b.InitialCatalog.Trim().ToUpperInvariant();}return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"BoruERP","WebYonetim",WebJson.Ozet(scope)[..32],user.ToString());}
 internal static void Yaz(string path,object value)
 {
  Directory.CreateDirectory(Path.GetDirectoryName(path)!);byte[] plain=JsonSerializer.SerializeToUtf8Bytes(value,WebJson.Ayar);try{var bytes=ProtectedData.Protect(plain,null,DataProtectionScope.CurrentUser);string tmp=path+"."+Guid.NewGuid().ToString("N")+".tmp";try{using(var f=new FileStream(tmp,FileMode.CreateNew,FileAccess.Write,FileShare.None)){f.Write(bytes);f.Flush(true);}File.Move(tmp,path,true);}finally{if(File.Exists(tmp))File.Delete(tmp);}}finally{CryptographicOperations.ZeroMemory(plain);}
 }
 internal static T Oku<T>(string path){var bytes=ProtectedData.Unprotect(File.ReadAllBytes(path),null,DataProtectionScope.CurrentUser);try{return JsonSerializer.Deserialize<T>(bytes,WebJson.Ayar)??throw new InvalidDataException("Şifreli kayıt boş.");}finally{CryptographicOperations.ZeroMemory(bytes);}}
 public WebSite[] Siteler()=>Remote?Proxy().Siteler():Directory.Exists(Folder)?Directory.EnumerateFiles(Folder,"site-*.dpapi").Select(Oku<WebSite>).ToArray():[];
 public void Kaydet(WebSite site)
 {
  if(Remote){Proxy().SiteKaydet(site);return;}

  _=WebHttp.Adres(site);foreach(var secret in new[]{site.Sirlar.WpKullanici,site.Sirlar.WpUygulamaParolasi,site.Sirlar.WooAnahtar,site.Sirlar.WooGizli,site.Sirlar.Token})if(secret.Length>4096||secret.Any(char.IsControl))throw new ArgumentException("API bilgileri geçersiz.");
  string path=Path.Combine(Folder,"site-"+site.Id.ToString("N")+".dpapi");Directory.CreateDirectory(Folder);using var locked=new FileStream(path+".lock",FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);
  if(File.Exists(path)){var old=Oku<WebSite>(path);if(old.Surum!=site.Surum)throw new InvalidOperationException("Bağlantı başka pencerede değişti. Listeyi yeniden yükleyin.");if(old.Platform!=site.Platform||WebHttp.Adres(old)!=WebHttp.Adres(site))throw new InvalidOperationException("Farklı site adresi/altyapısı için yeni bağlantı oluşturun. Mevcut işlemler başka siteye taşınmaz.");}
  Yaz(path,site with{Surum=site.Surum+1});
 }
}
public sealed record WebIslemKaydi(Guid Islem,Guid Site,string Ozet,string Durum,DateTimeOffset Zaman,WebSonuc? Sonuc=null);
public sealed class WebIslemDefteri(string folder)
{
 public async Task<WebSonuc> Calistir(Guid site,Guid id,string digest,string resource,Func<Task<WebSonuc>> send)
 {
  if(site==Guid.Empty||id==Guid.Empty||digest.Length!=64)throw new ArgumentException("İşlem kimliği geçersiz.");string root=Path.Combine(folder,"Islemler",site.ToString("N"));Directory.CreateDirectory(root);
  string record=Path.Combine(root,id.ToString("N")+".dpapi");
  // FileShare.None locks cover other processes and RDS sessions, not only this UI.
  using var operationLock=Lock(record+".lock");
  if(File.Exists(record)){var old=WebDepo.Oku<WebIslemKaydi>(record);if(old.Ozet!=digest)throw new InvalidOperationException("Bu düzenleme için önceki bir deneme var. Düzenlemeyi kapatıp site listesinden güncel kaydı yeniden açın.");if(old.Durum=="succeeded"&&old.Sonuc is not null)return old.Sonuc;throw new InvalidOperationException("Bu değişiklik daha önce gönderilmeye çalışıldı. Düzenlemeyi kapatıp sitedeki sonucu kontrol edin; otomatik tekrar yapılmadı.");}
  using var targetLock=Lock(Path.Combine(root,"hedef-"+WebJson.Ozet(resource)+".lock"));
  var row=new WebIslemKaydi(id,site,digest,"sending",DateTimeOffset.UtcNow);WebDepo.Yaz(record,row);
  try{var result=await send();WebDepo.Yaz(record,row with{Durum="succeeded",Sonuc=result});return result;}
  catch(Exception e){try{WebDepo.Yaz(record,row with{Durum=e is WebApiHatasi{SonucBelirsiz:false} or ArgumentException or UnauthorizedAccessException?"rejected":"unknown"});}catch{}throw;}
 }
 static FileStream Lock(string path){try{return new(path,FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);}catch(IOException){throw new InvalidOperationException("Aynı site kaydı başka bir pencerede işleniyor. İşlem bitince listeyi yenileyin.");}}
 public WebIslemKaydi[] Liste()=>Directory.Exists(Path.Combine(folder,"Islemler"))?Directory.EnumerateFiles(Path.Combine(folder,"Islemler"),"*.dpapi",SearchOption.AllDirectories).OrderByDescending(File.GetLastWriteTimeUtc).Take(100).Select(WebDepo.Oku<WebIslemKaydi>).OrderByDescending(x=>x.Zaman).ToArray():[];
 public bool DenemeVar(Guid site,Guid operation)=>File.Exists(Path.Combine(folder,"Islemler",site.ToString("N"),operation.ToString("N")+".dpapi"));
}
