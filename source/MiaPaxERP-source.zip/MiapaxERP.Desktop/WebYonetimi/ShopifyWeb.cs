using System.Net.Http;
using System.Text.Json;
using System.Text.RegularExpressions;
using static MiapaxERP.Desktop.WebYonetimi.WebJson;
namespace MiapaxERP.Desktop.WebYonetimi;

public sealed class ShopifyWeb(WebSite site,WebHttp http):IWebSaglayici
{
 const string EndPoint="admin/api/2026-10/graphql.json";
 const string Product="id title descriptionHtml status updatedAt";
 const string Variant="id title price updatedAt product{id} inventoryItem{id sku tracked}";
 const string Page="id title body isPublished updatedAt";
 const string Article="id title body isPublished updatedAt blog{id} author{name}";
 const string Media="id alt fileStatus createdAt ... on MediaImage{image{url}}";
 const string Stock="id updatedAt item{id} location{id name} quantities(names:[\"available\"]){name quantity}";
 const string Order="id name createdAt displayFinancialStatus totalPriceSet{shopMoney{amount currencyCode}} shippingAddress{name formatted} lineItems(first:50){nodes{name quantity} pageInfo{hasNextPage}}";
 static void Gid(string id,string kind){if(!Regex.IsMatch(id,"^gid://shopify/"+kind+"/[0-9]+"+(kind=="InventoryLevel"?"(?:\\?inventory_item_id=[0-9]+)?":"")+"$"))throw new ArgumentException("Shopify kayıt kimliği geçersiz.");}
 async Task<JsonElement> Query(string query,object variables,CancellationToken ct,bool write=false)
 {
  if(site.Sirlar.Token.Length==0)throw new ArgumentException("Shopify erişim token'ını girin.");
  var q=http.Istek(HttpMethod.Post,EndPoint);q.Headers.Add("X-Shopify-Access-Token",site.Sirlar.Token);q.Content=WebHttp.Govde(new{query,variables});var(j,_)=await http.Json(q,ct,write);
  if(A(P(j,"errors")).Any())throw new WebApiHatasi("Shopify sorguyu reddetti. API sürümü, kapsamlar ve erişim izinlerini kontrol edin.",write);
  var data=P(j,"data");if(data.ValueKind!=JsonValueKind.Object)throw new WebApiHatasi("Shopify veri yanıtı geçersiz.",write);return data;
 }
 static JsonElement Payload(JsonElement data,string key){var p=P(data,key);if(p.ValueKind!=JsonValueKind.Object)throw new WebApiHatasi("Shopify işlem sonucu eksik.",true);if(A(P(p,"userErrors")).Any())throw new WebApiHatasi("Shopify değişikliği kabul etmedi. Kayıt değerleri, yetki ve stok sürümünü yenileyerek kontrol edin.");return p;}
 public async Task<WebBaglanti> BaglantiDene(CancellationToken ct)
 {
  var d=await Query("query{shop{name currencyCode} currentAppInstallation{accessScopes{handle}}}",new{},ct);var shop=P(d,"shop");var scopes=A(P(P(d,"currentAppInstallation"),"accessScopes")).Select(s=>S(s,"handle")).ToArray();
  return new(S(shop,"name"),S(shop,"currencyCode"),scopes,"Shopify Admin GraphQL 2026-10. Stok değişikliği seçili konumda okunan miktarı atomik karşılaştırır. Ürün durumu ACTIVE yapmak, ürünü yeni satış kanallarına otomatik yayımlamaz.");
 }
 static string Kind(WebBolum kind)=>kind switch{WebBolum.Urun=>"Product",WebBolum.Varyant=>"ProductVariant",WebBolum.Sayfa=>"Page",WebBolum.Yazi=>"Article",WebBolum.Gorsel=>"MediaImage",WebBolum.Stok=>"InventoryLevel",WebBolum.Siparis=>"Order",_=>throw new ArgumentException("Kayıt türü geçersiz.")};
 static string Fields(WebBolum k)=>k switch{WebBolum.Urun=>Product,WebBolum.Varyant=>Variant,WebBolum.Sayfa=>Page,WebBolum.Yazi=>Article,WebBolum.Gorsel=>Media,WebBolum.Stok=>Stock,WebBolum.Siparis=>Order,WebBolum.Blog=>"id title",_=>throw new ArgumentException("Bölüm geçersiz.")};
 static WebKayit Row(WebBolum kind,JsonElement j,string parent="")
 {
  string title=S(j,"title"),body=S(j,"body"),status=P(j,"isPublished").ValueKind==JsonValueKind.True?"published":"draft",sku="",inventory="",location="",url="",extra="";int? qty=null;
  if(kind==WebBolum.Urun){body=S(j,"descriptionHtml");status=S(j,"status");}
  if(kind==WebBolum.Varyant){parent=S(P(j,"product"),"id");var item=P(j,"inventoryItem");sku=S(item,"sku");inventory=S(item,"id");status=P(item,"tracked").ValueKind==JsonValueKind.True?"tracked":"untracked";}
  if(kind==WebBolum.Yazi)parent=S(P(j,"blog"),"id");
  if(kind==WebBolum.Gorsel){title=S(j,"id");status=S(j,"fileStatus");url=S(P(j,"image"),"url");}
  if(kind==WebBolum.Stok){inventory=S(P(j,"item"),"id");location=S(P(j,"location"),"id");title=S(P(j,"location"),"name");var amount=A(P(j,"quantities")).FirstOrDefault(x=>S(x,"name")=="available");if(P(amount,"quantity").ValueKind==JsonValueKind.Number)qty=P(amount,"quantity").GetInt32();}
  if(kind==WebBolum.Siparis){var li=P(j,"lineItems");title=S(j,"name")+" · "+S(P(j,"shippingAddress"),"name");body=string.Join("; ",A(P(li,"nodes")).Select(x=>S(x,"name")+" × "+S(x,"quantity")));status=S(j,"displayFinancialStatus");if(P(P(li,"pageInfo"),"hasNextPage").ValueKind==JsonValueKind.True)extra="partial";else extra=S(j,"createdAt");}
  var money=P(P(j,"totalPriceSet"),"shopMoney");return new(kind,S(j,"id"),title,body,status,Ozet(j),parent,sku,S(j,"price"),S(money,"currencyCode"),S(money,"amount"),url,extra,qty,inventory,location,S(j,"alt"),S(P(j,"author"),"name"),S(P(j,"shippingAddress"),"name"),S(j,"name"),S(j,"createdAt"),string.Join(" ",A(P(P(j,"shippingAddress"),"formatted")).Select(x=>x.ToString())));
 }
 public async Task<WebSayfa> Liste(WebBolum kind,string parent,string? cursor,CancellationToken ct)
 {
  if(cursor?.Length>2000)throw new ArgumentException("Sayfalama kimliği geçersiz.");
  string connection=kind switch{WebBolum.Urun=>"products",WebBolum.Sayfa=>"pages",WebBolum.Yazi=>"articles",WebBolum.Gorsel=>"files",WebBolum.Siparis=>"orders",WebBolum.Blog=>"blogs",WebBolum.Varyant=>"variants",WebBolum.Stok=>"inventoryLevels",_=>throw new ArgumentException("Bölüm geçersiz.")};
  string args="first:50,after:$cursor";if(kind==WebBolum.Gorsel)args+=",query:\"media_type:IMAGE\"";
  string inner=connection+"("+args+"){nodes{"+Fields(kind)+"} pageInfo{hasNextPage endCursor}}",query="query($cursor:String){"+inner+"}";object variables=new{cursor};
  if(kind is WebBolum.Varyant or WebBolum.Stok){Gid(parent,kind==WebBolum.Varyant?"Product":"InventoryItem");query="query($cursor:String,$id:ID!){"+(kind==WebBolum.Varyant?"product":"inventoryItem")+"(id:$id){"+inner+"}}";variables=new{cursor,id=parent};}
  var d=await Query(query,variables,ct);var container=kind==WebBolum.Varyant?P(d,"product"):kind==WebBolum.Stok?P(d,"inventoryItem"):d;var c=P(container,connection);if(c.ValueKind!=JsonValueKind.Object)throw new WebApiHatasi("Shopify liste veya üst kayıt bulunamadı.");
  var page=P(c,"pageInfo");var next=P(page,"hasNextPage").ValueKind==JsonValueKind.True?S(page,"endCursor"):null;if(next is not null&&(next.Length==0||next==cursor))throw new WebApiHatasi("Shopify sayfalama yanıtı geçersiz.");return new(A(P(c,"nodes")).Select(x=>Row(kind,x,parent)).ToArray(),next);
 }
 public async Task<WebKayit> Oku(WebBolum kind,string id,string parent,CancellationToken ct)
 {Gid(id,Kind(kind));var d=await Query("query($id:ID!){node(id:$id){... on "+Kind(kind)+"{"+Fields(kind)+"}}}",new{id},ct);var n=P(d,"node");if(n.ValueKind!=JsonValueKind.Object)throw new WebApiHatasi("Kayıt sitede bulunamadı.");return Row(kind,n,parent);}
 public async Task<WebSonuc> Kaydet(WebDegisiklik v,Guid operation,CancellationToken ct)
 {
  Dogrula(v);WebKayit? before=null;if(v.Id.Length>0){before=await Oku(v.Bolum==WebBolum.GorselBagla?v.HedefBolum:v.Bolum,v.Id,v.ParentId,ct);if(before.Surum!=v.BeklenenSurum)throw new WebApiHatasi("Sitedeki kayıt değişmiş; yeniden yükleyin.");}
  if(v.Bolum==WebBolum.GorselBagla){if(v.HedefBolum!=WebBolum.Urun)throw new ArgumentException("Shopify'da bu ekrandan görsel yalnız ürüne bağlanır.");Gid(v.MedyaId,"MediaImage");var media=await Oku(WebBolum.Gorsel,v.MedyaId,"",ct);if(media.Durum!="READY")throw new WebApiHatasi("Görsel henüz hazır değil. Medya listesini yenileyin.");var attached=await Query("mutation($files:[FileUpdateInput!]!){fileUpdate(files:$files){files{id} userErrors{field message}}}",new{files=new[]{new{id=v.MedyaId,referencesToAdd=new[]{v.Id}}}},ct,true);var added=Payload(attached,"fileUpdate");if(!A(P(added,"files")).Any())throw new WebApiHatasi("Görsel ilişkilendirme sonucu eksik.",true);return new(v.Id,before!.Durum,"Görsel ürüne eklendi; diğer görseller kaldırılmadı.");}
  string mutation,payloadKey,resultKey;object variables;
  switch(v.Bolum)
  {
   case WebBolum.Urun:
    if(v.Durum is not("DRAFT" or "ACTIVE" or "ARCHIVED"))throw new ArgumentException("Shopify ürün durumu geçersiz.");
    bool create=v.Id.Length==0;payloadKey=create?"productCreate":"productUpdate";resultKey="product";
    mutation="mutation($product:"+(create?"ProductCreateInput":"ProductUpdateInput")+"!){"+payloadKey+"(product:$product){product{id status} userErrors{field message}}}";
    variables=new{product=new{id=create?null:v.Id,title=v.Baslik,descriptionHtml=v.Icerik,status=create?"DRAFT":v.Durum}};break;
   case WebBolum.Varyant:
    if(v.Fiyat is null)throw new ArgumentException("Varyant fiyatını girin.");Gid(v.ParentId,"Product");payloadKey="productVariantsBulkUpdate";resultKey="productVariants";
    mutation="mutation($productId:ID!,$variants:[ProductVariantsBulkInput!]!){productVariantsBulkUpdate(productId:$productId,variants:$variants,allowPartialUpdates:false){productVariants{id} userErrors{field message}}}";
    variables=new{productId=v.ParentId,variants=new[]{new{id=v.Id,price=Para(v.Fiyat).ToString(System.Globalization.CultureInfo.InvariantCulture)}}};break;
   case WebBolum.Stok:
    Gid(v.EnvanterId,"InventoryItem");Gid(v.KonumId,"Location");if(before!.EnvanterId!=v.EnvanterId||before.KonumId!=v.KonumId||before.Miktar!=v.BeklenenMiktar)throw new WebApiHatasi("Stok konumu veya miktarı değişmiş.");
    payloadKey="inventorySetQuantities";resultKey="inventoryAdjustmentGroup";
    mutation="mutation($input:InventorySetQuantitiesInput!,$idempotencyKey:String!){inventorySetQuantities(input:$input) @idempotent(key:$idempotencyKey){inventoryAdjustmentGroup{reason} userErrors{code field message}}}";
    variables=new{input=new{name="available",reason="correction",referenceDocumentUri="miapaxerp://web/"+operation.ToString("D"),quantities=new[]{new{inventoryItemId=v.EnvanterId,locationId=v.KonumId,quantity=v.Miktar,changeFromQuantity=v.BeklenenMiktar}}},idempotencyKey=operation.ToString("D")};break;
   case WebBolum.Sayfa:
    if(v.Durum is not("draft" or "published"))throw new ArgumentException("Sayfa durumu geçersiz.");
    bool newPage=v.Id.Length==0;payloadKey=newPage?"pageCreate":"pageUpdate";resultKey="page";
    mutation=newPage?"mutation($page:PageCreateInput!){pageCreate(page:$page){page{id} userErrors{field message}}}":"mutation($id:ID!,$page:PageUpdateInput!){pageUpdate(id:$id,page:$page){page{id} userErrors{field message}}}";
    variables=newPage?new{page=(object)new{title=v.Baslik,body=v.Icerik,isPublished=false}}:(object)new{id=v.Id,page=new{title=v.Baslik,body=v.Icerik,isPublished=v.Durum=="published"}};break;
   case WebBolum.Yazi:
    if(v.Durum is not("draft" or "published"))throw new ArgumentException("Yazı durumu geçersiz.");
    bool newPost=v.Id.Length==0;payloadKey=newPost?"articleCreate":"articleUpdate";resultKey="article";
    mutation=newPost?"mutation($article:ArticleCreateInput!){articleCreate(article:$article){article{id} userErrors{field message}}}":"mutation($id:ID!,$article:ArticleUpdateInput!){articleUpdate(id:$id,article:$article){article{id} userErrors{field message}}}";
    if(newPost){Gid(v.ParentId,"Blog");if(string.IsNullOrWhiteSpace(v.Yazar))throw new ArgumentException("Yazının yazar adını girin.");variables=new{article=new{blogId=v.ParentId,title=v.Baslik,body=v.Icerik,isPublished=false,author=new{name=v.Yazar}}};}
    else variables=new{id=v.Id,article=new{title=v.Baslik,body=v.Icerik,isPublished=v.Durum=="published"}};break;
   case WebBolum.Gorsel:
    payloadKey="fileUpdate";resultKey="files";mutation="mutation($files:[FileUpdateInput!]!){fileUpdate(files:$files){files{id} userErrors{field message}}}";variables=new{files=new[]{new{id=v.Id,alt=v.AltMetin}}};break;
   default:throw new ArgumentException("Bu Shopify işlemi desteklenmiyor.");
  }
  var data=await Query(mutation,variables,ct,true);var payload=Payload(data,payloadKey);var result=P(payload,resultKey);string id=result.ValueKind==JsonValueKind.Array?S(A(result).FirstOrDefault(),"id"):S(result,"id");if(v.Bolum==WebBolum.Stok){if(result.ValueKind!=JsonValueKind.Object)throw new WebApiHatasi("Stok sonucu doğrulanamadı.",true);id=v.Id;}if(id.Length==0)throw new WebApiHatasi("Shopify sonuç kimliği eksik; sitede kontrol edin.",true);return new(id,v.Id.Length==0?"draft":v.Durum,"Shopify değişikliği kabul etti. Son durumu yenileyin.");
 }
 public async Task<WebSonuc> GorselYukle(string name,byte[] bytes,string mime,string alt,Guid operation,CancellationToken ct)
 {
  var data=await Query("mutation($input:[StagedUploadInput!]!){stagedUploadsCreate(input:$input){stagedTargets{url resourceUrl parameters{name value}} userErrors{field message}}}",new{input=new[]{new{resource="IMAGE",filename=name,mimeType=mime,httpMethod="POST",fileSize=bytes.Length.ToString()}}},ct,true);
  var p=Payload(data,"stagedUploadsCreate");var target=A(P(p,"stagedTargets")).SingleOrDefault();string url=S(target,"url"),resource=S(target,"resourceUrl");if(url.Length==0||!Uri.TryCreate(resource,UriKind.Absolute,out var resourceUri)||resourceUri.Scheme!="https")throw new WebApiHatasi("Shopify yükleme hedefini doğrulayamadı.",true);
  await http.StagedUpload(url,A(P(target,"parameters")).ToDictionary(x=>S(x,"name"),x=>S(x,"value")),name,bytes,mime,ct);
  data=await Query("mutation($files:[FileCreateInput!]!){fileCreate(files:$files){files{id fileStatus} userErrors{field message}}}",new{files=new[]{new{originalSource=resource,contentType="IMAGE",alt}}},ct,true);p=Payload(data,"fileCreate");var file=A(P(p,"files")).SingleOrDefault();if(S(file,"id").Length==0)throw new WebApiHatasi("Yükleme kimliği eksik; dosyaları sitede kontrol edin.",true);if(S(file,"fileStatus")=="FAILED")throw new WebApiHatasi("Shopify görseli işleyemedi. Dosya listesini kontrol edin; yükleme otomatik tekrarlanmadı.",true);return new(S(file,"id"),S(file,"fileStatus"),"Görsel Shopify tarafından işleniyor olabilir; hazır durumunu listeyi yenileyerek kontrol edin.");
 }
}
