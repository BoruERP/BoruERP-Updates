using System.IO;
using System.Net.Http;
using static MiapaxERP.Desktop.WebYonetimi.WebJson;
namespace MiapaxERP.Desktop.WebYonetimi;

public sealed class WebYonetimServisi:IDisposable
{
 readonly string? proxy;
 WebHttpsServisi Proxy()=>new(proxy!,HttpsOturumu.Istemci?.Oturum?.Kullanici.Id??throw new UnauthorizedAccessException());
 readonly WebSite site;readonly WebHttp? http;readonly IWebSaglayici? provider;readonly Action<string> access;readonly WebIslemDefteri journal;
 public WebYonetimServisi(WebSite site,string folder,Action<string> check,HttpMessageHandler? testHandler=null,string? erpConnection=null)
 {
  this.site=site;access=check;journal=new(folder);proxy=erpConnection is not null&&HttpsOturumu.Uzak(erpConnection)?erpConnection:null;if(proxy is not null)return;http=new WebHttp(site,testHandler);journal=new(folder);provider=site.Platform switch{WebPlatform.WordPress or WebPlatform.WooCommerce=>new WordPressWeb(site,http),WebPlatform.Shopify=>new ShopifyWeb(site,http),WebPlatform.OzelApi=>new OzelWebApi(site,http),_=>throw new ArgumentException("Site altyapısı desteklenmiyor.")};
 }
 public Task<WebBaglanti> BaglantiDene(CancellationToken ct){if(proxy is not null){return Task.Run(()=>Proxy().Baglanti(site.Id),ct);}access("ECOM.VIEW");return provider!.BaglantiDene(ct);}
 public Task<WebSayfa> Liste(WebBolum kind,string parent,string? cursor,CancellationToken ct){if(proxy is not null){return Task.Run(()=>Proxy().Liste(site.Id,kind,parent,cursor),ct);}access("ECOM.VIEW");return provider!.Liste(kind,parent,cursor,ct);}
 public Task<WebKayit> Oku(WebBolum kind,string id,string parent,CancellationToken ct){if(proxy is not null){return Task.Run(()=>Proxy().Oku(site.Id,kind,id,parent),ct);}access("ECOM.VIEW");return provider!.Oku(kind,id,parent,ct);}
 public Task<WebSonuc> Kaydet(WebDegisiklik value,Guid operation,CancellationToken ct)
 {if(proxy is not null){return Task.Run(()=>Proxy().Kaydet(site.Id,value,operation),ct);}
  access("ECOM.EDIT");Dogrula(value);string digest=Ozet(new{site.Id,root=WebHttp.Adres(site).AbsoluteUri,value});
  var lockKind=value.Bolum==WebBolum.GorselBagla?value.HedefBolum:value.Bolum;if(lockKind==WebBolum.Stok&&site.Platform==WebPlatform.WooCommerce)lockKind=value.ParentId.Length>0?WebBolum.Varyant:WebBolum.Urun;
  return journal.Calistir(site.Id,operation,digest,lockKind+"|"+value.ParentId+"|"+value.Id,async()=>{
   WebKayit? before=null;if(value.Id.Length>0){before=await provider!.Oku(value.Bolum==WebBolum.GorselBagla?value.HedefBolum:value.Bolum,value.Id,value.ParentId,ct);if(before.Surum!=value.BeklenenSurum)throw new WebApiHatasi("Kayıt sitede değişti. Güncel kaydı yükleyin.");}
   bool approve=value.Bolum is WebBolum.Stok or WebBolum.Varyant or WebBolum.Gorsel or WebBolum.GorselBagla||value.Fiyat is not null||Yayinda(value.Durum)||before is not null&&Yayinda(before.Durum);
   access(approve?"ECOM.APPROVE":"ECOM.EDIT");if(value.Fiyat is not null){var currentShop=await provider!.BaglantiDene(ct);if(currentShop.Doviz!=value.BeklenenDoviz)throw new WebApiHatasi("Mağazanın para birimi değişmiş. Bağlantıyı ve fiyatı yeniden doğrulayın.");}
   if(value.Bolum==WebBolum.Stok&&before?.Miktar!=value.BeklenenMiktar)throw new WebApiHatasi("Site stok miktarı değişti. Yenileyin.");
   var result=await provider!.Kaydet(value,operation,ct);if(value.Id.Length>0&&result.Id!=value.Id)throw new WebApiHatasi("Site farklı kayıt kimliği döndürdü. Sonucu siteden kontrol edin; işlem otomatik tekrarlanmadı.",true);return result;
  });
 }
 public async Task<WebSonuc> GorselYukle(string path,string alt,Guid operation,CancellationToken ct)
 {
  access("ECOM.APPROVE");var info=new FileInfo(path);if(info.Length>10*1024*1024||alt.Length>1000)throw new ArgumentException("Görsel/alternatif metin sınırı aşıldı.");byte[] bytes=await File.ReadAllBytesAsync(path,ct);return await GorselYukleVeri(bytes,alt,operation,ct);
 }
 public async Task<WebSonuc> GorselYukleVeri(byte[] bytes,string alt,Guid operation,CancellationToken ct)
 {
  if(proxy is not null)return await Task.Run(()=>Proxy().Gorsel(site.Id,bytes,alt,operation),ct);
  access("ECOM.APPROVE");if(alt.Length>1000)throw new ArgumentException("Alternatif metin çok uzun.");string mime=ResimTuru(bytes),name=operation.ToString("N")+(mime=="image/jpeg"?".jpg":mime=="image/png"?".png":".webp");string digest=Ozet(new{site.Id,content=Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(bytes)),alt});
  return await journal.Calistir(site.Id,operation,digest,"media-upload",()=>{access("ECOM.APPROVE");return provider!.GorselYukle(name,bytes,mime,alt,operation,ct);});
 }
 public void Dispose()=>http?.Dispose();
}
