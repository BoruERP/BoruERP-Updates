namespace MiapaxERP.Desktop.WebYonetimi;
public sealed class WebHttpsServisi(string connection,int user)
{
    void Permission(string p){var access=new ErpModulServisi(connection,user);using var c=access.Ac();access.Yetki(c,null,p);}
    WebDepo Store()=>new(WebDepo.Klasor(connection,user));
    WebYonetimServisi Service(Guid id){Permission("ECOM.VIEW");var store=Store();var site=store.Siteler().SingleOrDefault(s=>s.Id==id)??throw new ArgumentException("Kullanıcının kayıtlı site bağlantısı bulunamadı.");return new(site,store.Folder,Permission);}
    public void Yetki(string p){
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"WebHttpsServisi.Yetki","",new object?[]{p});return;}
if(p is not("ECOM.VIEW" or "ECOM.EDIT" or "ECOM.APPROVE"))throw new ArgumentException("Web yetkisi geçersiz.");Permission(p);}
    public WebSite[] Siteler(){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<WebSite[]>(connection,"WebHttpsServisi.Siteler","",new object?[]{});}
Permission("ECOM.VIEW");return Store().Siteler().Select(s=>s with{Sirlar=new()}).ToArray();}
    public void SiteKaydet(WebSite site)
    {
if(HttpsOturumu.Uzak(connection)){HttpsOturumu.Cagir<object?>(connection,"WebHttpsServisi.SiteKaydet","",new object?[]{site});return;}

        Permission("ECOM.EDIT");if(site.Id==Guid.Empty||site.Ad.Length is <1 or >160)throw new ArgumentException("Site kimliği ve adı gerekli.");var store=Store();var old=store.Siteler().SingleOrDefault(s=>s.Id==site.Id);
        if(old is not null){string Keep(string value,string current)=>value.Length==0?current:value;site=site with{Sirlar=new(Keep(site.Sirlar.WpKullanici,old.Sirlar.WpKullanici),Keep(site.Sirlar.WpUygulamaParolasi,old.Sirlar.WpUygulamaParolasi),Keep(site.Sirlar.WooAnahtar,old.Sirlar.WooAnahtar),Keep(site.Sirlar.WooGizli,old.Sirlar.WooGizli),Keep(site.Sirlar.Token,old.Sirlar.Token))};}store.Kaydet(site);
    }
    public WebBaglanti Baglanti(Guid site){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<WebBaglanti>(connection,"WebHttpsServisi.Baglanti","",new object?[]{site});}
using var service=Service(site);return service.BaglantiDene(default).GetAwaiter().GetResult();}
    public WebSayfa Liste(Guid site,WebBolum kind,string parent,string? cursor){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<WebSayfa>(connection,"WebHttpsServisi.Liste","",new object?[]{site,kind,parent,cursor});}
using var service=Service(site);return service.Liste(kind,parent,cursor,default).GetAwaiter().GetResult();}
    public WebKayit Oku(Guid site,WebBolum kind,string id,string parent){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<WebKayit>(connection,"WebHttpsServisi.Oku","",new object?[]{site,kind,id,parent});}
using var service=Service(site);return service.Oku(kind,id,parent,default).GetAwaiter().GetResult();}
    public WebSonuc Kaydet(Guid site,WebDegisiklik value,Guid operation){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<WebSonuc>(connection,"WebHttpsServisi.Kaydet","",new object?[]{site,value,operation});}
using var service=Service(site);return service.Kaydet(value,operation,default).GetAwaiter().GetResult();}
    public WebSonuc Gorsel(Guid site,byte[] bytes,string alt,Guid operation){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<WebSonuc>(connection,"WebHttpsServisi.Gorsel","",new object?[]{site,bytes,alt,operation});}
using var service=Service(site);return service.GorselYukleVeri(bytes,alt,operation,default).GetAwaiter().GetResult();}
    public WebIslemKaydi[] Gecmis(){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<WebIslemKaydi[]>(connection,"WebHttpsServisi.Gecmis","",new object?[]{});}
Permission("ECOM.VIEW");return new WebIslemDefteri(Store().Folder).Liste();}
    public bool DenemeVar(Guid site,Guid operation){
if(HttpsOturumu.Uzak(connection)){return HttpsOturumu.Cagir<bool>(connection,"WebHttpsServisi.DenemeVar","",new object?[]{site,operation});}
Permission("ECOM.VIEW");using var check=Service(site);return new WebIslemDefteri(Store().Folder).DenemeVar(site,operation);}
}
