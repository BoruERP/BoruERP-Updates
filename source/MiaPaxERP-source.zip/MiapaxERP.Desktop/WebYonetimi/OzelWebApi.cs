using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Text.RegularExpressions;
using static MiapaxERP.Desktop.WebYonetimi.WebJson;
namespace MiapaxERP.Desktop.WebYonetimi;

public sealed class OzelWebApi(WebSite site,WebHttp http):IWebSaglayici
{
 bool? atomicStock;
 static string Kind(WebBolum kind)=>kind switch{WebBolum.Urun=>"products",WebBolum.Varyant=>"variants",WebBolum.Sayfa=>"pages",WebBolum.Yazi=>"posts",WebBolum.Gorsel=>"media",WebBolum.Siparis=>"orders",WebBolum.Blog=>"blogs",WebBolum.Stok=>"inventory",_=>throw new ArgumentException("Kaynak türü geçersiz.")};
 static string Id(string id){if(!Regex.IsMatch(id,"^[A-Za-z0-9_-]{1,128}$"))throw new ArgumentException("Özel API kimliği harf/rakam/tire/alt çizgi olmalı.");return id;}
 HttpRequestMessage Request(HttpMethod method,string path){if(site.Sirlar.Token.Length==0)throw new ArgumentException("Özel API erişim token'ını girin.");return http.Istek(method,"miapaxerp/v1/"+path,token:site.Sirlar.Token);}
 public async Task<WebBaglanti> BaglantiDene(CancellationToken ct)
 {
  var(j,_)=await http.Json(Request(HttpMethod.Get,"capabilities"),ct);if(P(j,"protocol").ValueKind!=JsonValueKind.Number||P(j,"protocol").GetInt32()!=1)throw new WebApiHatasi("Site MiapaxERP Web API v1 sözleşmesini desteklemiyor; sağlayıcı bağdaştırıcısı gerekir.");
  atomicStock=P(j,"atomicStock").ValueKind==JsonValueKind.True;var features=A(P(j,"features")).Select(x=>x.GetString()??"").ToArray();return new(S(j,"siteName"),S(j,"currency"),features,"Özel API'de güçlü ETag/If-Match ve Idempotency-Key zorunludur. Stok güncellemesi yalnız sunucu atomik karşılaştırmayı desteklediğini bildirirse açılır.");
 }
 static WebKayit Row(JsonElement j,WebBolum kind){var row=j.Deserialize<WebKayit>(Ayar)??throw new WebApiHatasi("Özel API kayıt yanıtı eksik.");Id(row.Id);if(!Regex.IsMatch(row.Surum??"","^[A-Za-z0-9_-]{1,128}$"))throw new WebApiHatasi("Özel API güçlü kayıt sürümü dönmedi.");return row with{Bolum=kind};}
 public async Task<WebSayfa> Liste(WebBolum kind,string parent,string? cursor,CancellationToken ct)
 {
  if(cursor?.Length>2000||parent.Length>200)throw new ArgumentException("Sayfalama/üst kimlik geçersiz.");
  var(j,_)=await http.Json(Request(HttpMethod.Get,"resources/"+Kind(kind)+"?limit=50&cursor="+Uri.EscapeDataString(cursor??"")+"&parent="+Uri.EscapeDataString(parent)),ct);var rows=A(P(j,"items")).Select(x=>Row(x,kind)).ToArray();var next=S(j,"nextCursor");if(next.Length>2000||next.Length>0&&next==cursor)throw new WebApiHatasi("Özel API sayfalama yanıtı geçersiz.");return new(rows,next.Length==0?null:next);
 }
 public async Task<WebKayit> Oku(WebBolum kind,string id,string parent,CancellationToken ct)
 {var(j,_)=await http.Json(Request(HttpMethod.Get,"resources/"+Kind(kind)+"/"+Id(id)+"?parent="+Uri.EscapeDataString(parent)),ct);return Row(j,kind);}
 public async Task<WebSonuc> Kaydet(WebDegisiklik d,Guid operation,CancellationToken ct)
 {
  Dogrula(d);if(d.Bolum==WebBolum.GorselBagla)throw new ArgumentException("Özel site görsel ilişkisini kendi API bağdaştırıcısında uygulamalıdır. Bu genel sözleşmede bağlama işlemi açık değil.");if(atomicStock is null)await BaglantiDene(ct);if(d.Bolum==WebBolum.Stok&&atomicStock!=true)throw new WebApiHatasi("Bu özel API atomik stok karşılaştırması sunmuyor; stok gönderimi kapalı.");
  var q=Request(d.Id.Length==0?HttpMethod.Post:HttpMethod.Put,"resources/"+Kind(d.Bolum)+(d.Id.Length>0?"/"+Id(d.Id):""));q.Headers.Add("Idempotency-Key",operation.ToString("D"));
  if(d.Id.Length>0){if(!Regex.IsMatch(d.BeklenenSurum,"^[A-Za-z0-9_-]{1,128}$"))throw new ArgumentException("Kayıt sürümü geçersiz.");q.Headers.IfMatch.Add(new EntityTagHeaderValue("\""+d.BeklenenSurum+"\""));}
  q.Content=WebHttp.Govde(d with{Durum=d.Id.Length==0?"draft":d.Durum});var(j,_)=await http.Json(q,ct,true);var result=j.Deserialize<WebSonuc>(Ayar)??throw new WebApiHatasi("Özel API işlem yanıtı geçersiz.",true);if(result.Id.Length==0)throw new WebApiHatasi("Sonuç kimliği eksik.",true);return result;
 }
 public async Task<WebSonuc> GorselYukle(string name,byte[] bytes,string mime,string alt,Guid operation,CancellationToken ct)
 {
  var q=Request(HttpMethod.Post,"media");q.Headers.Add("Idempotency-Key",operation.ToString("D"));var form=new MultipartFormDataContent();var image=new ByteArrayContent(bytes);image.Headers.ContentType=new(mime);form.Add(image,"file",name);form.Add(new StringContent(alt),"alt");q.Content=form;var(j,_)=await http.Json(q,ct,true);var result=j.Deserialize<WebSonuc>(Ayar)??throw new WebApiHatasi("Görsel yanıtı eksik.",true);if(result.Id.Length==0)throw new WebApiHatasi("Görsel kimliği eksik.",true);return result;
 }
}
