using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Input;
using System.Windows.Controls;

internal static class Program
{
    static string root = "", updater = "", oldExe = "", newExe = "";
    static RSA rsa = null!;
    static readonly List<object> results = new();
    static int failed;

    [STAThread]
    static int Main(string[] args)
    {
        string source = args.Length > 0 ? Path.GetFullPath(args[0]) : @"C:\MiapaxERP\MiapaxERP";
        root = Path.Combine(Path.GetTempPath(), "MiapaxERP-GuncellemeTest-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(root);
        using var key = RSA.Create(2048);
        rsa = key;
        File.WriteAllText(Path.Combine(root, "TestPublicKey.cs"), "namespace MiapaxERP.Guncelleme; internal static class GuncellemeAnahtari { public const string Pem = \"\"\"\n" + rsa.ExportSubjectPublicKeyInfoPem() + "\n\"\"\"; }");
        string xmlRoot = System.Security.SecurityElement.Escape(source);
        File.WriteAllText(Path.Combine(root, "Updater.csproj"), "<Project Sdk=\"Microsoft.NET.Sdk\"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net10.0</TargetFramework><ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable><EnableDefaultCompileItems>false</EnableDefaultCompileItems><AssemblyName>TestUpdater</AssemblyName></PropertyGroup><ItemGroup><Compile Include=\"" + xmlRoot + "/MiapaxERP.Updater/*.cs\"/><Compile Include=\"" + xmlRoot + "/MiapaxERP.Desktop/MarkaGecisi.cs\"/><Compile Include=\"" + xmlRoot + "/MiapaxERP.Desktop/GuncellemeKanalAyari.cs\"/><Compile Include=\"TestPublicKey.cs\"/></ItemGroup></Project>");
        Run("dotnet", "build", Path.Combine(root, "Updater.csproj"), "-o", Path.Combine(root, "updater"), "--verbosity", "quiet");
        updater = Path.Combine(root, "updater", "TestUpdater.dll");
        string fixture = Path.Combine(root, "Fixture"); Directory.CreateDirectory(fixture);
        File.WriteAllText(Path.Combine(fixture, "Fixture.csproj"), "<Project Sdk=\"Microsoft.NET.Sdk\"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net10.0</TargetFramework><AssemblyName>MiapaxERP.Desktop</AssemblyName></PropertyGroup></Project>");
        File.WriteAllText(Path.Combine(fixture, "Program.cs"), "return 0;");
        foreach (string version in new[] { "1.5.2", "1.7.1" })
            Run("dotnet", "build", Path.Combine(fixture, "Fixture.csproj"), "-o", Path.Combine(root, version), "-p:Version=" + version, "-p:FileVersion=" + version + ".0", "--verbosity", "quiet");
        oldExe = Path.Combine(root, "1.5.2", "MiapaxERP.Desktop.exe");
        newExe = Path.Combine(root, "1.7.1", "MiapaxERP.Desktop.exe");

        Test("1.5.2 -> 1.7.1 kurulum ve ayar/veri koruma", () => {
            var f = Prepare(); Package(f);
            Assert(Apply(f) == 0, "Kurulum başarısız");
            Assert(FileHash(Path.Combine(f.Install, "MiapaxERP.Desktop.exe")) == FileHash(newExe), "Yeni sürüm yüklenmedi");
            Assert(File.ReadAllText(Path.Combine(f.Install, "Data", "fabrika.db")) == "FABRIKA VERISI", "Veri değişti");
            Assert(File.ReadAllText(Path.Combine(f.Install, "ag-baglantisi.json")) == "SQL AYARI", "SQL ayarı değişti");
            Assert(File.ReadAllText(Path.Combine(f.Install, "MiapaxERP.guncelleme.json")) == "{\"Channel\":\"Ana\"}", "Kanal ayarı değişti");
            Assert(File.Exists(Path.Combine(f.Local, "previous.json")) && !File.Exists(f.Manifest), "Geçmiş kaydı yok");
        });
        Test("Önceki sürüme dönüş ve yeni dosyaların temizlenmesi", () => {
            var f = Prepare(); Package(f); Assert(Apply(f) == 0, "Kurulum başarısız");
            int code = InvokeUpdater("rollback", f.Install, Path.Combine(f.Local, "previous.json"));
            Assert(code == 0, "Geri dönüş başarısız");
            Assert(FileHash(Path.Combine(f.Install, "MiapaxERP.Desktop.exe")) == FileHash(oldExe), "Eski sürüm geri gelmedi");
            Assert(!File.Exists(Path.Combine(f.Install, "new.dll")), "Yeni dosya kalmış");
            Assert(File.Exists(Path.Combine(f.Local, "paused")), "Otomatik tekrar kurulum duraklatılmadı");
        });
        Test("1.5.2 biçimindeki indekssiz yedekten geri dönüş", () => {
            var f = Prepare(); Package(f); Assert(Apply(f) == 0, "Kurulum başarısız");
            using (var index = JsonDocument.Parse(File.ReadAllText(Path.Combine(f.Local, "previous.json"))))
                Directory.Move(index.RootElement.GetProperty("Backup").GetString()!, Path.Combine(f.Local, "yedek", "1.7.1"));
            File.Delete(Path.Combine(f.Local, "previous.json"));
            Assert(InvokeUpdater("rollback", f.Install, Path.Combine(f.Local, "previous.json")) == 0, "Eski yedek biçimi okunamadı");
            Assert(FileHash(Path.Combine(f.Install, "MiapaxERP.Desktop.exe")) == FileHash(oldExe), "Eski sürüm geri gelmedi");
        });
        Test("Bozuk SHA256 paketi reddedilir", () => {
            var f = Prepare(); Package(f); File.AppendAllText(Path.Combine(f.Local, "paket.zip"), "DEGISIK"); Reject(f);
        });
        Test("Yanlış yayıncı imzası reddedilir", () => {
            var f = Prepare(); Package(f); var m = ReadManifest(f); m.Signature = Convert.ToBase64String(new byte[256]); WriteManifest(f, m); Reject(f);
        });
        Test("İmzalı kanal uyuşmazlığı reddedilir", () => { var f = Prepare(); Package(f, channel: "Yan"); Reject(f); });
        Test("Aynı sürüm tekrar kurulamaz", () => { var f = Prepare(); Package(f, version: "1.5.2"); Reject(f); });
        Test("Eski sürüm kurulamaz", () => { var f = Prepare(); Package(f, version: "1.5.1"); Reject(f); });
        Test("İmzalı sürüm ile gerçek EXE sürümü eşleşmeli", () => { var f = Prepare(); Package(f, version: "1.7.2"); Reject(f); });
        Test("Tekrarlanan arşiv yolu reddedilir", () => { var f = Prepare(); Package(f, extra: "NEW.dll"); Reject(f); });
        foreach (string bad in new[] { "../disari.txt", "Data/fabrika.db", "UserData/ayar.json", "MiapaxERP.guncelleme.json", "BoruERP.guncelleme.json", "ag-baglantisi.json", "fabrika.mdf", "fabrika.ldf", "gizli.pem", "lisans.json", "alt/../kacis.txt", "bos./a.dll", "C:/kacis.txt" })
            Test("Korunan/güvensiz yol reddi: " + bad, () => { var f = Prepare(); Package(f, extra: bad); Reject(f); });
        Test("Yazma hatasında değişen dosyalar geri alınır", () => {
            var f = Prepare(); Package(f); Directory.CreateDirectory(Path.Combine(f.Install, "new.dll")); Reject(f);
        });
        Test("Geçmiş kaydı yazılamazsa kurulum geri alınır", () => {
            var f = Prepare(); Package(f); Directory.CreateDirectory(Path.Combine(f.Local, "previous.json")); Reject(f);
        });
        Test("Bozulmuş geri dönüş yedeği reddedilir", () => {
            var f = Prepare(); Package(f); Assert(Apply(f) == 0, "Kurulum başarısız");
            using var index = JsonDocument.Parse(File.ReadAllText(Path.Combine(f.Local, "previous.json")));
            File.WriteAllText(Path.Combine(index.RootElement.GetProperty("Backup").GetString()!, "MiapaxERP.Desktop.exe"), "BOZUK");
            Assert(InvokeUpdater("rollback", f.Install, Path.Combine(f.Local, "previous.json")) != 0, "Bozuk yedek kabul edildi");
            Assert(FileHash(Path.Combine(f.Install, "MiapaxERP.Desktop.exe")) == FileHash(newExe), "Kurulum bozuldu");
        });
        if(!args.Contains("--no-ui")) Test("Kroki UserControl yükleme ve Boru Çiz düğmesi", () => {
            var control = new MiapaxERP.Desktop.KrokiYonetimi();
            Assert(control.Content is TabControl, "Kroki sekmeleri yüklenmedi");
            var tabs=(TabControl)control.Content;
            var manual=(Grid)((TabItem)tabs.Items[1]).Content;
            var button = Descendants(manual).OfType<Button>().Single(b => b.Content?.ToString()?.Contains("Boru Çiz") == true);
            button.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            var canvas = (Canvas)control.FindName("KrokiCanvas");
            Assert(canvas.Cursor == Cursors.Cross, "Çizim modu açılmadı");
            canvas.RaiseEvent(new MouseButtonEventArgs(Mouse.PrimaryDevice, 0, MouseButton.Right) { RoutedEvent = UIElement.MouseRightButtonDownEvent });
            Assert(canvas.Cursor == Cursors.Arrow, "Çizim modu bitmedi");
        });
        Test("Üretim açık anahtarının okunabilirliği", () => {
            string path = Path.Combine(source, "MiapaxERP.Desktop", "GuncellemeAnahtari.g.cs");
            string pem = System.Text.RegularExpressions.Regex.Match(File.ReadAllText(path), "-----BEGIN PUBLIC KEY-----[\\s\\S]+?-----END PUBLIC KEY-----").Value;
            using var publicKey = RSA.Create(); publicKey.ImportFromPem(pem);
            Assert(publicKey.KeySize >= 2048, "Anahtar geçersiz");
        });
        string output = Path.Combine(source, "MiapaxERP.Tests.Guncelleme", "sonuc.json");
        Directory.CreateDirectory(Path.GetDirectoryName(output)!);
        File.WriteAllText(output, JsonSerializer.Serialize(new { At = DateTimeOffset.Now, Total = results.Count, Failed = failed, TestDirectory = root, Results = results }, new JsonSerializerOptions { WriteIndented = true }));
        Console.WriteLine($"TOPLAM: {results.Count}, BASARILI: {results.Count - failed}, HATALI: {failed}");
        Console.WriteLine("Deneme klasörü: " + root);
        return failed == 0 ? 0 : 1;
    }

    static IEnumerable<DependencyObject> Descendants(DependencyObject parent)
    {
        int count = System.Windows.Media.VisualTreeHelper.GetChildrenCount(parent);
        for (int i = 0; i < count; i++) { var child = System.Windows.Media.VisualTreeHelper.GetChild(parent, i); yield return child; foreach (var node in Descendants(child)) yield return node; }
    }
    record Fixture(string Install, string Local) { public string Manifest => Path.Combine(Local, "pending.json"); }
    sealed class Manifest { public string Version {get;set;} = ""; public string Channel {get;set;} = ""; public string PackageUrl {get;set;} = ""; public string Sha256 {get;set;} = ""; public string Signature {get;set;} = ""; }
    static Fixture Prepare()
    {
        string dir = Path.Combine(root, Guid.NewGuid().ToString("N"));
        var f = new Fixture(Path.Combine(dir, "install"), Path.Combine(dir, "local"));
        Directory.CreateDirectory(f.Install); Directory.CreateDirectory(f.Local);
        File.Copy(oldExe, Path.Combine(f.Install, "MiapaxERP.Desktop.exe"));
        File.Copy(Path.ChangeExtension(oldExe, ".dll"), Path.Combine(f.Install, "MiapaxERP.Desktop.dll"));
        File.WriteAllText(Path.Combine(f.Install, "MiapaxERP.guncelleme.json"), "{\"Channel\":\"Ana\"}");
        File.WriteAllText(Path.Combine(f.Install, "ag-baglantisi.json"), "SQL AYARI");
        Directory.CreateDirectory(Path.Combine(f.Install, "Data"));
        File.WriteAllText(Path.Combine(f.Install, "Data", "fabrika.db"), "FABRIKA VERISI");
        return f;
    }
    static void Package(Fixture f, string version = "1.7.1", string channel = "Ana", string? extra = null)
    {
        string zip = Path.Combine(f.Local, "paket.zip");
        using (var archive = ZipFile.Open(zip, ZipArchiveMode.Create))
        {
            archive.CreateEntryFromFile(newExe, "MiapaxERP.Desktop.exe");
            archive.CreateEntryFromFile(Path.ChangeExtension(newExe, ".dll"), "MiapaxERP.Desktop.dll");
            using (var w = new StreamWriter(archive.CreateEntry("new.dll").Open())) w.Write("YENI DOSYA");
            if (extra != null) { using var w = new StreamWriter(archive.CreateEntry(extra).Open()); w.Write("YASAK"); }
        }
        var m = new Manifest {Version=version, Channel=channel, PackageUrl="https://example.invalid/test.zip", Sha256=FileHash(zip)};
        m.Signature = Convert.ToBase64String(rsa.SignData(Encoding.UTF8.GetBytes(m.Version + "\n" + m.Channel + "\n" + m.PackageUrl + "\n" + m.Sha256.ToLowerInvariant() + "\n"), HashAlgorithmName.SHA256, RSASignaturePadding.Pss));
        WriteManifest(f, m);
    }
    static Manifest ReadManifest(Fixture f) => JsonSerializer.Deserialize<Manifest>(File.ReadAllText(f.Manifest))!;
    static void WriteManifest(Fixture f, Manifest m) => File.WriteAllText(f.Manifest, JsonSerializer.Serialize(m));
    static string FileHash(string path) { using var stream = File.OpenRead(path); return Convert.ToHexString(SHA256.HashData(stream)).ToLowerInvariant(); }
    static int Apply(Fixture f) => InvokeUpdater("apply", f.Install, f.Manifest);
    static int InvokeUpdater(string action, string install, string manifest)
    {
        using var done = Process.Start(new ProcessStartInfo("cmd.exe") { Arguments = "/c exit 0", CreateNoWindow = true, UseShellExecute = false })!;
        done.WaitForExit();
        return Run("dotnet", new[] {updater, action, done.Id.ToString(), install, manifest}, false);
    }
    static void Reject(Fixture f)
    {
        Assert(Apply(f) != 0, "Güvensiz paket kabul edildi");
        Assert(FileHash(Path.Combine(f.Install, "MiapaxERP.Desktop.exe")) == FileHash(oldExe), "Eski dosya korunmadı");
        Assert(File.ReadAllText(Path.Combine(f.Install, "Data", "fabrika.db")) == "FABRIKA VERISI", "Veri bozuldu");
    }
    static int Run(string exe, params string[] args) => Run(exe, args, true);
    static int Run(string exe, string[] args, bool required)
    {
        var start = new ProcessStartInfo(exe) {UseShellExecute=false, CreateNoWindow=true, RedirectStandardOutput=true, RedirectStandardError=true};
        foreach (var arg in args) start.ArgumentList.Add(arg);
        using var p = Process.Start(start)!;
        var stdout = p.StandardOutput.ReadToEndAsync(); var stderr = p.StandardError.ReadToEndAsync();
        if (!p.WaitForExit(120000)) { p.Kill(true); throw new Exception("Deneme zaman aşımı"); }
        Task.WaitAll(stdout, stderr);
        if (required && p.ExitCode != 0) throw new Exception(stdout.Result + stderr.Result);
        return p.ExitCode;
    }
    static void Assert(bool success, string message) { if (!success) throw new Exception(message); }
    static void Test(string name, Action action)
    {
        try { action(); results.Add(new {Name=name, Passed=true}); Console.WriteLine("OK: " + name); }
        catch (Exception e) { failed++; results.Add(new {Name=name, Passed=false, Error=e.Message}); Console.WriteLine("FAIL: " + name + " - " + e.Message); }
    }
}
