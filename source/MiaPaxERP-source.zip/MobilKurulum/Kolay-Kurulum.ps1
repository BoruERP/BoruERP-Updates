#requires -Version 5.1
$ErrorActionPreference='Stop'
$exe=Join-Path $PSScriptRoot 'Sunucu\MiapaxERP.MobileServer.exe'
if(-not(Test-Path -LiteralPath $exe -PathType Leaf)){throw 'Tam kurulum paketindeki Sunucu klasörü bulunamadı.'}
Start-Process -FilePath $exe -ArgumentList 'setup' -WorkingDirectory (Split-Path -Parent $exe) -Verb RunAs -WindowStyle Hidden
