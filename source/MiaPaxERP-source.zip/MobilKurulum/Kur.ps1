#requires -Version 5.1
#requires -RunAsAdministrator
param([string]$Hedef=(Join-Path $env:ProgramFiles 'MiapaxERP MobilSunucu'))
$ErrorActionPreference='Stop'
$source=Join-Path $PSScriptRoot 'Sunucu'
if(!(Test-Path -LiteralPath (Join-Path $source 'MiapaxERP.MobileServer.exe'))){throw 'Sunucu dosyaları eksik.'}
$service=Get-Service -Name 'MiapaxERPMobil' -ErrorAction SilentlyContinue
$oldService=Get-CimInstance Win32_Service -Filter "Name='MiapaxERPMobil'"
$wasRunning=$service -and $service.Status -eq 'Running'
# Önce ayrı sürüm klasörüne kopyala; çalışan/eski dosyaların üzerine yazma.
$appFolder=Join-Path $Hedef ('surum-2.4-'+[Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $appFolder -Force | Out-Null
Get-ChildItem -LiteralPath $source | Copy-Item -Destination $appFolder -Recurse -Force
$exe=Join-Path $appFolder 'MiapaxERP.MobileServer.exe'
$config=Join-Path $env:ProgramData 'BoruERP\MobilSunucu\ayarlar.dpapi'
$backup=$config+'.kurulum-'+[Guid]::NewGuid().ToString('N')+'.bak'
$hadConfig=Test-Path -LiteralPath $config
if($hadConfig){Copy-Item -LiteralPath $config -Destination $backup}
$created=$false;$completed=$false;$restored=$false
try {
 if($service){Stop-Service -Name 'MiapaxERPMobil';$service.WaitForStatus('Stopped',[TimeSpan]::FromSeconds(30))}
 & $exe configure
 if($LASTEXITCODE -ne 0){throw 'Ayarlar tamamlanmadı.'}
 $quoted='"'+$exe+'"'
 if(!$service){New-Service -Name 'MiapaxERPMobil' -BinaryPathName $quoted -DisplayName 'MiapaxERP Mobil Sunucu' -StartupType Automatic | Out-Null;$created=$true}
 else{& sc.exe config MiapaxERPMobil binPath= $quoted;if($LASTEXITCODE -ne 0){throw 'Servis yolu değiştirilemedi.'}}
 & sc.exe failure MiapaxERPMobil reset= 86400 actions= restart/30000/restart/60000/restart/120000 | Out-Null
 Start-Service -Name 'MiapaxERPMobil'
 (Get-Service MiapaxERPMobil).WaitForStatus('Running',[TimeSpan]::FromSeconds(45))
 $ready=$false
 for($attempt=0;$attempt -lt 30;$attempt++) {
  try {$health=Invoke-RestMethod 'http://127.0.0.1:5188/api/mobile/v2/health' -TimeoutSec 2;if($health.service -eq 'MiapaxERP.MobileServer' -and $health.api -eq 2){$ready=$true;break}} catch {}
  Start-Sleep -Seconds 1
 }
 if(-not $ready){throw 'Mobil servis sağlık yanıtı vermedi.'}
 $completed=$true
 Write-Host 'Mobil servis çalışıyor. Sağlık kontrolü SQL, kullanıcı veya lisans doğrulaması değildir; telefon eşlemesiyle ayrıca kontrol edin. Dış erişim için HTTPS/VPN kurulumu gerekir.'
} catch {
 $originalError=$_
 try {
  $current=Get-Service MiapaxERPMobil -ErrorAction SilentlyContinue
  if($current -and $current.Status -ne 'Stopped'){Stop-Service MiapaxERPMobil;$current.WaitForStatus('Stopped',[TimeSpan]::FromSeconds(30))}
  if($hadConfig){Copy-Item -LiteralPath $backup -Destination $config -Force}
  elseif(Test-Path -LiteralPath $config){Remove-Item -LiteralPath $config}
  if($oldService){& sc.exe config MiapaxERPMobil binPath= $oldService.PathName;if($LASTEXITCODE -ne 0){throw 'Eski servis yolu geri yüklenemedi.'};if($wasRunning){Start-Service MiapaxERPMobil}}
  elseif($created){& sc.exe delete MiapaxERPMobil | Out-Null;if($LASTEXITCODE -ne 0){throw 'Yeni servis kaydı kaldırılamadı.'}}
  $restored=$true
 } catch {throw ('Kurulum ve geri dönüş tamamlanamadı. Korumalı ayar yedeğini saklayın: '+$backup+'. Servis yöneticisiyle kontrol edin.')}
 throw $originalError
} finally {
 if(($completed -or $restored) -and (Test-Path -LiteralPath $backup)){Remove-Item -LiteralPath $backup}
}
