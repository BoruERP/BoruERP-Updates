@echo off
powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0Kolay-Kurulum.ps1"
