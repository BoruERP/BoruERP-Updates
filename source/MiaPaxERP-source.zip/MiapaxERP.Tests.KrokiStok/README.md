# Saat, gelişmiş kroki ve stok görselleri

Yerel MiapaxERP projesine uygulandı. Kaynak yedeği:
`C:\MiapaxERP\MiapaxERP\KrokiGorselYedek-20261104-150421`.

## Kullanım

- Yeni plan: saat/dakika listelerinden seçin. **Otomatik saat**, bugün sonraki 15 dakikayı, başka bir gün için 09:00'u önerir. **30 dk sonra / 1 saat sonra** kısa yolları vardır; gece yarısı tarih de ilerler.
- Kroki: **Otomatik plan • Harita • 3D** sekmesini açın. Önce ölçüyü veya sınırı, ardından kaynak debisini girin. Yağmurlama/damlama, başlık debisi ve çalışma basıncı, boru iç çapları, kot farkı ve sulama derinliği düzenlenebilir. **Otomatik çiz ve hesapla** yerleşimi, hız esaslı çap önerisini, debiye göre sektörleri, basınç kaybı ön hesabını, su miktarını ve süreyi hesaplar. S1/S2 işaretleri ve renkler sektörleri gösterir.
- Parçaları 2D/3D üzerinde taşıyabilir, boru uçlarını düzenleyebilir, parça ekleyip silebilirsiniz. **Geri al**, **Planı indir**, **Plan aç** desteklenir. Ana hat/kaynak bağlantıları ve ürün verileri uygulamadan önce kontrol edilmelidir.
- **PDF dosyasını kaydet** doğrudan A4 PDF üretir. **Logolu PDF / Yazdır** yazıcı iletişim kutusunu açar. Ayarlarda yüklenen firma logosu varsa o, yoksa MiapaxERP logosu kullanılır. 3D görüntü raporda istendiğinde 3D sekmesinden çıktı alın.
- **TKGM Parsel Sorgu**, **Google Maps'te ara**, **Google Earth** bağlantıları açılır. Dosyadan sınır aktarımı WGS84 KML veya tek/deliksiz GeoJSON Polygon destekler. Leaflet/OpenStreetMap üzerinde de köşeler seçilebilir. İçe aktarılan sınır haritada gösterilir, yaklaşık metre ve alan hesabına aktarılır. İl/ilçe/mahalle/ada/parsel bilgileri plan dosyasında korunur.
- Stok listesi, hareket geçmişi, bakiye listesi ve hareket ürün seçicisinde kapak fotoğrafı görünür. Fotoğraf penceresi kapatılınca görüntüler yenilenir. Çoklu yükleme önce tüm dosyaları doğrular ve tek işlemde kaydeder; hatalı bir dosya varsa yarım yükleme yapılmaz. Dosyalar taşınabilir PNG olarak SQL'de saklanır; yerel dosyaya bağımlı değildir. Düzenleme için STOCK.EDIT yetkisi gerekir.

## Sınırlar

- Sadece ada/parsel numarasından sınırı otomatik indiren bir TKGM/Google servisi bağlanmadı. TKGM sorgulaması ve dışarı aktarılan sınır dosyası kullanılmalıdır; Google adres araması kadastro doğrulaması değildir.
- 3D arazi düzlemseldir; gerçek yükseklik modeli indirilmez. Kot farkı kullanıcı girdisidir.
- Hesap ön tasarımdır. Gerçek pompa eğrisi, başlık eğrisi, rüzgâr, toprak, örtüşme ve ayrıntılı hidrolik ağ çözümü içermez. Boru çapı **iç çap** olarak yorumlanır. Hazen–Williams tam debi kaybı ve %20 yerel kayıp payı konservatif yaklaşım olarak kullanılır. Tek hat kaynak debisini aşarsa veya basınç yetmezse uyarı verilir; uygulanabilir proje gibi sunulmaz.
- Karmaşık/delikli/çok parçalı parseller açık hata ile reddedilir. 120 köşe ve 500 çizim parçası sınırı vardır; büyük tarlalar bloklar halinde planlanmalıdır.
- Gelişmiş düzenleyici Microsoft Edge WebView2 Runtime gerektirir. 2D/3D kütüphaneleri yereldir; harita karoları internet gerektirir. WebView2 açılamazsa mevcut basit elle çizim kullanılabilir.
- GitHub yayını ve uygulama sürüm numarası değiştirilmedi. Visual Studio'daki eski çalışan Debug sürümü yeniden derlenmelidir.

## Doğrulama

```powershell
node MiapaxERP.Tests.KrokiStok/hydraulics.test.mjs
dotnet run --project MiapaxERP.Tests.KrokiStok/KrokiStokTestleri.csproj -c Release
dotnet run --project MiapaxERP.Tests.TemaTakvim/TemaTakvimTestleri.csproj -c Release
dotnet test MiapaxERP.Tests/MiapaxERP.Tests.csproj -c Release
dotnet build MiapaxERP.slnx -c Release
```

23 hesap/parsel testi, 21 masaüstü kontrolü, önceki 53 görünüm/takvim kontrolü ve 3 mevcut test geçti.
Masaüstü testleri izole tarayıcı profili, örnek ürün görüntüsü ve önizleme pencereleri kullanır.
SQL'de yalnız salt okunur şema/sayı kontrolü yapıldı: UrunGorselleri tablosu ve bir mevcut fotoğraf bulundu.
Gerçek ürün kayıtlarında ekleme/silme/değiştirme testi yapılmadı. Mevcut veriler korunmuştur.
Eksik kurulumlar için `StokGorselleri_Kurulum.sql` eklendi; mevcut veritabanında çalıştırılmadı.
Örnek PDF ve ekranlar `bin/Release/net10.0-windows/Sonuclar` klasöründedir.
Önceden mevcut ExcelVeYazdirmaPenceresi.xaml.cs:574 CS8629 uyarısı sürer.

## Kaynaklar ve kullanılan bileşenler

- Yerel MiaPlast `/Home/TarlaPlanlayici` kaynakları MiapaxERP içinde bağımsız kopya olarak kullanıldı; web sitesi değiştirilmedi.
- Three.js ve Leaflet yerel lisanslarıyla taşındı. Haritada OpenStreetMap atfı korunur.
- TKGM sorgulama ve KML dışa aktarma: https://www.tkgm.gov.tr/e-hizmetler/sik-kullanilanlar/parsel-sorgulama
- Google Maps URL sözleşmesi: https://developers.google.com/maps/documentation/urls/get-started
- Hidrolik denklem/birim doğrulaması: https://usepa.github.io/EPANET2.2/12_analysis_algorithms.html
- WebView2 yerel kaynak eşlemesi: https://learn.microsoft.com/en-us/dotnet/api/microsoft.web.webview2.core.corewebview2.setvirtualhostnametofoldermapping
