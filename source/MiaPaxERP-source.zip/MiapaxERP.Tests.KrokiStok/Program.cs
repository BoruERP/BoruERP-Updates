using System.IO;
using System.Reflection;
using System.Text.Json;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using MiapaxERP.Desktop;
using Microsoft.Data.SqlClient;
using Microsoft.Web.WebView2.Wpf;
using Microsoft.Web.WebView2.Core;

internal static class Program
{
 static int count;
 static string Output=Path.Combine(AppContext.BaseDirectory,"Sonuclar");
 [STAThread] static int Main(string[] args){
  if(args.Contains("--schema")){Schema();return 0;}
  Directory.CreateDirectory(Output);
  var app=new Application{ShutdownMode=ShutdownMode.OnExplicitShutdown};
  app.Resources.MergedDictionaries.Add(new ResourceDictionary{Source=new Uri("pack://application:,,,/MiapaxERP.Desktop;component/Assets/ModernKontroller.xaml")});Tema170.Uygula(new());
  var kroki=(KrokiYonetimi)Activator.CreateInstance(typeof(KrokiYonetimi),BindingFlags.Instance|BindingFlags.NonPublic,null,new object[]{Path.Combine(Output,"TarayiciTesti-"+Guid.NewGuid().ToString("N"))},null)!;
  var window=new Window{Title="MiapaxERP • Kroki test önizlemesi",Width=1400,Height=1000,Content=kroki};int exit=0;
  window.Loaded+=async (_,_)=>{try{
   var now=new DateTime(2026,11,4,23,54,0);
   Check("Otomatik saat gece gün değiştirir",TakvimPlanPenceresi.OnerilenSaat(now.Date,now)==now.Date.AddDays(1));
   Check("Gelecek gün 09:00",TakvimPlanPenceresi.OnerilenSaat(now.Date.AddDays(2),now)==now.Date.AddDays(2).AddHours(9));
   var calendar=new TakvimPlanPenceresi{PlanTarihi=new DateTime(2026,11,5,14,37,0)};Check("Saat dakika seçimi kaybolmaz",calendar.PlanTarihi==new DateTime(2026,11,5,14,37,0));calendar.Close();
   var original=BitmapSource.Create(8,8,96,96,PixelFormats.Bgra32,null,Enumerable.Repeat((byte)180,8*8*4).ToArray(),8*4);
   var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(original));string file=Path.Combine(Output,"urun.png");using(var stream=File.Create(file))encoder.Save(stream);
   byte[] bytes=StokGorselServisi.Hazirla(file);Check("Görsel dosya kapandıktan sonra okunur",StokGorselServisi.Resim(bytes).IsFrozen);
   string bad=Path.Combine(Output,"sahte.png");File.WriteAllText(bad,"not an image");bool rejected=false;try{StokGorselServisi.Hazirla(bad);}catch(InvalidDataException){rejected=true;}Check("Sahte görsel reddedilir",rejected);
   var web=(WebView2)typeof(KrokiYonetimi).GetField("web",BindingFlags.Instance|BindingFlags.NonPublic)!.GetValue(kroki)!;
   var deadline=DateTime.UtcNow.AddSeconds(35);while((web.CoreWebView2==null || await web.ExecuteScriptAsync("!!window.MiapaxERP")!="true")&&DateTime.UtcNow<deadline)await Task.Delay(200);
   Check("Masaüstü kroki modülleri yüklenir",web.CoreWebView2!=null&&await web.ExecuteScriptAsync("!!window.MiapaxERP")=="true");
   await web.ExecuteScriptAsync("document.getElementById('fpAutoForm').requestSubmit()");
   Console.WriteLine(await web.ExecuteScriptAsync("JSON.stringify({message:document.getElementById('fpAutoMessage').textContent,invalid:[...document.querySelectorAll('input:invalid')].map(x=>({id:x.id,value:x.value,why:x.validationMessage}))})"));
   Check("Debiyle otomatik yerleşim",await web.ExecuteScriptAsync("MiapaxERP.getPlan().items.length>10")=="true");
   Check("Hidrolik raporu oluşur",await web.ExecuteScriptAsync("document.getElementById('hyd-result').textContent.includes('sektör')")=="true");
   Check("Varsayımlar planda saklanır",await web.ExecuteScriptAsync("MiapaxERP.getPlan().settings.hydraulics.flow===12")=="true");
   Check("KML sınırı okunur",await web.ExecuteScriptAsync("import('./js/parcel-import.mjs').then(m=>window.kmlTest=m.fromKml('<kml xmlns=\"http://www.opengis.net/kml/2.2\"><Placemark><Polygon><outerBoundaryIs><LinearRing><coordinates>35,38 35.001,38 35.001,38.001 35,38.001 35,38</coordinates></LinearRing></outerBoundaryIs></Polygon></Placemark></kml>').boundary.length)")!="null");
   await Task.Delay(100);Check("KML dört köşe korunur",await web.ExecuteScriptAsync("window.kmlTest===4")=="true");
   await web.ExecuteScriptAsync("window.savedPlan=MiapaxERP.getPlan();let changed=MiapaxERP.getPlan();changed.items.pop();MiapaxERP.apply(changed);");
   Check("Çizim düzenlemesi modele yansır",await web.ExecuteScriptAsync("MiapaxERP.getPlan().items.length===savedPlan.items.length-1")=="true");
   await web.ExecuteScriptAsync("MiapaxERP.apply(JSON.parse(JSON.stringify(savedPlan)));document.getElementById('hyd-flow').value='6';document.getElementById('hyd-flow').dispatchEvent(new Event('input',{bubbles:true}));document.getElementById('fpAutoForm').requestSubmit();");
   Check("Debi değişikliği yeni plana kaydedilir",await web.ExecuteScriptAsync("MiapaxERP.getPlan().settings.hydraulics.flow===6")=="true");
   await web.ExecuteScriptAsync("MiapaxERP.apply(savedPlan)");
   await web.ExecuteScriptAsync("document.querySelector('.fp-workspace').scrollIntoView();MiapaxERP.setView('3d');");await Task.Delay(1500);
   Check("3D WebGL tuvali oluşur",await web.ExecuteScriptAsync("document.querySelector('#fp3D canvas')!==null")=="true");
   using(var stream=File.Create(Path.Combine(Output,"kroki-3d.png")))await web.CoreWebView2!.CapturePreviewAsync(CoreWebView2CapturePreviewImageFormat.Png,stream);
   // Yerel rapor hazırlığı yazıcı veya kaydet iletişim kutusu açmadan doğrulanır.
   await web.ExecuteScriptAsync("window.prepareBoruReport().then(()=>window.reportReady=true)");
   deadline=DateTime.UtcNow.AddSeconds(15);while(await web.ExecuteScriptAsync("!!window.reportReady")!="true"&&DateTime.UtcNow<deadline)await Task.Delay(100);
   Check("Rapor logolu ve hidrolik özetli",await web.ExecuteScriptAsync("!!document.querySelector('#fpPrintReport header img')&&document.getElementById('fpPrintReport').textContent.includes('sektörleri')")=="true");
   string pdf=Path.Combine(Output,"MiapaxERP-ornek-sulama-plani.pdf");var ps=web.CoreWebView2!.Environment.CreatePrintSettings();ps.PageWidth=8.2677;ps.PageHeight=11.6929;ps.MarginTop=.47;ps.MarginBottom=.47;ps.MarginLeft=.47;ps.MarginRight=.47;ps.ShouldPrintBackgrounds=true;
   Check("PDF dosyası oluşur",await web.CoreWebView2.PrintToPdfAsync(pdf,ps)&&new FileInfo(pdf).Length>10000);
   await web.ExecuteScriptAsync("document.body.classList.remove('fp-printing');MiapaxERP.setView('sketch');");
   using(var stream=File.Create(Path.Combine(Output,"kroki-2d.png")))await web.CoreWebView2.CapturePreviewAsync(CoreWebView2CapturePreviewImageFormat.Png,stream);
   Check("Dış sayfa yerel host içine açılamaz",(bool)typeof(KrokiYonetimi).GetMethod("Yerel",BindingFlags.NonPublic|BindingFlags.Static)!.Invoke(null,new object[]{"https://example.com"})! ==false);
   var preview=(MainWindow)Activator.CreateInstance(typeof(MainWindow),BindingFlags.Instance|BindingFlags.NonPublic,null,new object[]{true},null)!;
   preview.Width=1200;preview.Height=800;((FrameworkElement)preview.FindName("GenelIcerik")).Visibility=Visibility.Collapsed;((FrameworkElement)preview.FindName("StokIcerik")).Visibility=Visibility.Visible;
   var table=new System.Data.DataTable();foreach(string col in new[]{"Id","StokKodu","StokAdi","StokTipi","Birim","Durum"})table.Columns.Add(col);table.Columns.Add("KapakGorseli",typeof(BitmapImage));
   table.Rows.Add("1","TEST-001","Örnek sulama borusu","Mamül","Metre","Aktif",StokGorselServisi.Resim(bytes));
   var grid=(System.Windows.Controls.DataGrid)preview.FindName("StokTablosu");grid.ItemsSource=table.DefaultView;preview.Show();preview.UpdateLayout();
   Check("Stok listesinde görsel sütunu",grid.Columns[0].Header.ToString()=="Görsel");
   Check("Stok görseli WPF içinde bağlanır",Descendants(grid).OfType<System.Windows.Controls.Image>().Any(i=>i.Source!=null));
   Check("Hareket listesinde görsel sütunu",((System.Windows.Controls.DataGrid)preview.FindName("StokHareketGecmisiTablosu")).Columns[0].Header.ToString()=="Görsel");
   Check("Hareket ürün seçiminde resimli şablon",((System.Windows.Controls.ComboBox)preview.FindName("CmbHareketStok")).ItemTemplate!=null);preview.Close();
   Console.WriteLine($"PASS: {count} kontrol. {Output}");File.WriteAllText(Path.Combine(Output,"sonuc.txt"),$"{count} kontrol başarılı.");
  }catch(Exception ex){Console.WriteLine(ex);exit=1;}finally{window.Close();app.Shutdown();}};
  window.Show();app.Run();return exit;
 }
 static void Check(string text,bool ok){if(!ok)throw new Exception("FAIL: "+text);count++;Console.WriteLine("PASS: "+text);}
 static IEnumerable<DependencyObject> Descendants(DependencyObject root){for(int i=0;i<VisualTreeHelper.GetChildrenCount(root);i++){var c=VisualTreeHelper.GetChild(root,i);yield return c;foreach(var n in Descendants(c))yield return n;}}
 static void Schema(){try{
  var builder=new SqlConnectionStringBuilder(MiapaxERPBaglantiAyarlari.BaglantiAdresi()){ConnectTimeout=5};using var db=new SqlConnection(builder.ConnectionString);db.Open();
  using var cmd=new SqlCommand("SELECT c.name,TYPE_NAME(c.user_type_id),c.is_nullable,OBJECT_DEFINITION(c.default_object_id) FROM sys.columns c WHERE c.object_id=OBJECT_ID(N'dbo.UrunGorselleri') ORDER BY c.column_id",db);
  using var rd=cmd.ExecuteReader();int n=0;while(rd.Read()){Console.WriteLine($"{rd[0]} | {rd[1]} | nullable={rd[2]} | default={rd[3]}");n++;}Console.WriteLine($"Görsel tablosu sütun sayısı: {n}");rd.Close();using var counts=new SqlCommand("SELECT COUNT_BIG(*),COUNT(DISTINCT StokKartId) FROM dbo.UrunGorselleri",db);using var cr=counts.ExecuteReader();if(cr.Read())Console.WriteLine($"Fotoğraf sayısı: {cr[0]}; görseli olan ürün: {cr[1]}");
 }catch(SqlException ex){Console.WriteLine("SQL şema kontrolü başarısız. Hata kodu: "+ex.Number);}}
}

