﻿# MiaPaxERP bağlantıları HTTPS servisinden yapılır.
throw 'Bu eski kurulum yolu kaldırıldı. ERP > Ağ / Sunucu > Ana sunucu > HTTPS sunucusunu hazırla düğmesini kullanın.'
