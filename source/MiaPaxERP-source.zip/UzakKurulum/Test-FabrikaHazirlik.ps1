#requires -Version 5.1
param([string]$Cikti)
$ErrorActionPreference='Stop'
$os=Get-CimInstance Win32_OperatingSystem
$sql=Get-Service | Where-Object { $_.Name -eq 'MSSQLSERVER' -or $_.Name -like 'MSSQL$*' } | Select-Object Name,Status
$mobile=Get-Service MiapaxERPMobil -ErrorAction SilentlyContinue
$result=[ordered]@{
 Surum=1
 IsletimSistemi=$os.Caption
 WindowsServer=($os.ProductType -ne 1)
 CokKullaniciliRdsIcinSunucuGerekir=($os.ProductType -eq 1)
 SqlServisleri=@($sql)
 MobilServis=if($mobile){[string]$mobile.Status}else{'Kurulu değil'}
 Not='Salt okunur inceleme; port açmaz, ağ/SQL/lisans ayarı değiştirmez. Sabit dış IP ve modem port yönlendirmesi bu bilgisayardan doğrulanamaz.'
}
$text=$result|ConvertTo-Json -Depth 5
if($Cikti){[IO.File]::WriteAllText([IO.Path]::GetFullPath($Cikti),$text,[Text.UTF8Encoding]::new($false))}
$text
