using MiapaxERP.Desktop.EBelge;
static class MaliTest
{
 static int count;
 static void Check(bool b,string n){if(!b)throw new Exception(n);count++;Console.WriteLine("PASS "+n);}
 static UblTaraf S=>new("1234567890","TEST Üretici","TEST","TEST adres","Kayseri","Kocasinan",PostaKodu:"38010");
 static UblTaraf C=>new("9876543210","TEST Alıcı","TEST","TEST adres","Kayseri","Melikgazi",PostaKodu:"38030");
 public static void Run()
 {
  var date=new DateTime(2026,11,12);var rows=new[]{new UblSatir("1","ST1","TEST ürün",10,"C62",100,20),new UblSatir("2","ST2","TEST ürün 2",1,"C62",100,10)};
  string Xml(UblMaliAyar m,UblSatir[]? r=null)=>UblBelge.Olustur(Guid.NewGuid(),"TST2026000000010",date,1,"TEMELFATURA",S,C,r??rows,mali:m);
  var xml=Xml(new());UblSema.Dogrula(xml);Check(UblBelge.Oku(xml).Odenecek==1310,"standard invoice regression and official XSD");
  xml=Xml(new("USD",35,date,"TEST elle doğrulanmış döviz alış"));UblSema.Dogrula(xml);var d=UblBelge.Oku(xml);Check(d.Doviz=="USD"&&d.Kur==35&&d.KurTarihi==date&&d.Odenecek==1310,"foreign currency UBL and tax exchange rate XSD");
  xml=Xml(new(Tevkifat:UblMaliHesap.Tevkifat("627")));UblSema.Dogrula(xml);d=UblBelge.Oku(xml);Check(d.Kimlik.Tur=="TEVKIFAT"&&d.Tevkifat==105&&d.Odenecek==1205,"withholding payable distinct from VAT inclusive total");
  xml=Xml(new("EUR",40,date,"TEST kur",UblMaliHesap.Tevkifat("624")));UblSema.Dogrula(xml);d=UblBelge.Oku(xml);Check(d.Tevkifat==42&&d.Odenecek==1268,"foreign withholding invoice schema");
  foreach(var rule in UblMaliHesap.Tevkifatlar){xml=Xml(new(Tevkifat:rule));UblSema.Dogrula(xml);var parsed=UblBelge.Oku(xml);Check(parsed.Tevkifat==UblBelge.Yuvarla(210m*rule.Pay/10)&&parsed.Odenecek==1310-parsed.Tevkifat,"catalog code and proportion "+rule.Kod);}
  xml=Xml(new("USD",35.123456m,date,"TEST kur"));d=UblBelge.Oku(xml);Check(d.TryKdv==7375.92m&&d.TryKdv!=UblBelge.Yuvarla(d.Vergi*d.Kur),"preserves actual TRY VAT total rather than recomputing a different cent");
  void Reject(string invalid,string label){try{UblBelge.Oku(invalid);}catch(ArgumentException){Check(true,label);return;}throw new Exception("Accepted: "+label);}
  var parsedXml=UblBelge.Xml(xml);parsedXml.Root!.Element(UblBelge.A+"LegalMonetaryTotal")!.Element(UblBelge.B+"PayableAmount")!.SetAttributeValue("currencyID","EUR");Reject(parsedXml.ToString(),"wrong payable currency rejected");
  parsedXml=UblBelge.Xml(xml);parsedXml.Root!.Element(UblBelge.A+"PricingExchangeRate")!.Element(UblBelge.B+"CalculationRate")!.Value="40";Reject(parsedXml.ToString(),"conflicting price and tax rate rejected");
  parsedXml=UblBelge.Xml(Xml(new(Tevkifat:UblMaliHesap.Tevkifat("624"))));parsedXml.Root!.Element(UblBelge.B+"InvoiceTypeCode")!.Value="SATIS";Reject(parsedXml.ToString(),"withholding cannot hide behind normal sale type");
  var discount=UblMaliHesap.EskiBrutIndirim(rows,131);Check(discount.YeniMatrah==990&&discount.YeniKdv==189&&discount.YeniToplam==1179,"mixed VAT gross discount keeps line VAT rates");Check(rows[0].Iskonto==0&&rows[1].Iskonto==0,"source sale rows remain immutable");
  var r=new Random(280);for(int i=0;i<100;i++){var many=Enumerable.Range(1,7).Select(n=>new UblSatir(n.ToString(),"T","TEST",1,"C62",r.Next(1,10000)/100m,new[]{1m,10m,20m}[r.Next(3)])).ToArray();decimal before=many.Sum(x=>x.Fiyat+UblBelge.Yuvarla(x.Fiyat*x.KdvOrani/100));decimal reduction=UblBelge.Yuvarla(before*r.Next(1,90)/100);var calc=UblMaliHesap.EskiBrutIndirim(many,reduction);xml=Xml(new(Yuvarlama:calc.Yuvarlama,IndirimAciklamasi:"TEST eski brüt indirimi açık onaylı dağıtım"),calc.Satirlar);UblSema.Dogrula(xml);d=UblBelge.Oku(xml);Check(d.Odenecek==before-reduction,"gross-discount exact payable and schema "+i);}
  Console.WriteLine($"Passed {count} fiscal UBL and discount checks.");
 }
}
