using Microsoft.Data.SqlClient;
using MiapaxERP.Desktop.EBelge;
using System.Data;
static class MaliSqlTest
{
 static int count;
 static void Check(bool b,string n){if(!b)throw new Exception(n);count++;Console.WriteLine("PASS "+n);}
 static object? Scalar(SqlConnection c,string sql){using var q=new SqlCommand(sql,c);return q.ExecuteScalar();}
 static void Exec(SqlConnection c,string sql){using var q=new SqlCommand(sql,c);q.ExecuteNonQuery();}
 static void Reject(Action a,string n){try{a();}catch(Exception e)when(e is ArgumentException or InvalidOperationException or UnauthorizedAccessException or SqlException){Check(true,n);return;}throw new Exception("Accepted: "+n);}
 public static void Run()
 {
  string name="MiapaxFiscalTest_"+Guid.NewGuid().ToString("N");string master="Server=(localdb)\\MSSQLLocalDB;Database=master;Integrated Security=true;TrustServerCertificate=true;Pooling=false";using var admin=new SqlConnection(master);admin.Open();Exec(admin,"CREATE DATABASE ["+name+"]");
  try
  {
   var cs=new SqlConnectionStringBuilder(master){InitialCatalog=name}.ConnectionString;using var c=new SqlConnection(cs);c.Open();Exec(c,"""
   CREATE TABLE dbo.Yetkiler(YetkiKodu varchar(100) PRIMARY KEY,Modul nvarchar(100),Islem nvarchar(100),Aciklama nvarchar(200),Aktif bit);
   CREATE TABLE dbo.CariKartlari(Id int PRIMARY KEY,CariKodu nvarchar(50),Unvan nvarchar(100),VergiNo varchar(11),Aktif bit);INSERT dbo.CariKartlari VALUES(1,'C1',N'TEST müşteri','9876543210',1);
   CREATE TABLE dbo.CariHareketleri(Id bigint IDENTITY PRIMARY KEY,CariId int,Tarih date,HareketTipi nvarchar(30),Tutar decimal(18,2),Aciklama nvarchar(400),Kaynak nvarchar(100),YapanKullaniciId int,TersKayitId bigint NULL);
   CREATE TABLE dbo.FinansHesaplari(Id int PRIMARY KEY,HesapAdi nvarchar(100),Aktif bit,ParaBirimi varchar(3));INSERT dbo.FinansHesaplari VALUES(1,N'TEST TRY',1,'TRY'),(2,N'TEST USD',1,'USD'),(3,N'TEST EUR',1,'EUR');
   CREATE TABLE dbo.FinansHareketleri(Id bigint IDENTITY PRIMARY KEY,HesapId int,CariId int,CariHareketId bigint,Tarih date,HareketTipi nvarchar(30),Tutar decimal(18,2),Aciklama nvarchar(400),YapanKullaniciId int,TersKayitId bigint NULL);
   CREATE TABLE dbo.TicariBelgeler(Id bigint PRIMARY KEY,CariId int,BelgeNo varchar(80),Durum nvarchar(30));
   CREATE TABLE dbo.BoruERP_YeniBelgeler(Id bigint PRIMARY KEY,BelgeNo nvarchar(80),BelgeTuru nchar(1),CariId int,Tarih date,Durum nvarchar(30),AraToplam decimal(18,2),KdvToplam decimal(18,2),GenelToplam decimal(18,2),Indirim decimal(18,2));
   CREATE TABLE dbo.StokKartlari(Id int PRIMARY KEY,StokKodu nvarchar(50));INSERT dbo.StokKartlari VALUES(1,'TEST');
   CREATE TABLE dbo.BoruERP_YeniBelgeKalemleri(Id bigint PRIMARY KEY,BelgeId bigint,StokKartId int,UrunAciklama nvarchar(350),Birim nvarchar(20),Miktar decimal(18,3),BirimFiyat decimal(18,2),KdvOrani decimal(5,2),SatirAraToplam decimal(18,2),KdvTutari decimal(18,2),SatirGenelToplam decimal(18,2));
   INSERT dbo.BoruERP_YeniBelgeler VALUES(1,'SALE1','S',1,'2026-11-12',N'Kaydedildi',1000,200,1080,120),(2,'SALE2','S',1,'2026-11-12',N'Kaydedildi',1000,200,1200,0);
   INSERT dbo.BoruERP_YeniBelgeKalemleri VALUES(1,1,1,N'TEST ürün',N'Adet',10,100,20,1000,200,1200),(2,2,1,N'TEST ürün',N'Adet',10,100,20,1000,200,1200);
   """);
   EbelgeDeposu D(bool allow=true)=>new(cs,1,(_,_,_)=>{if(!allow)throw new UnauthorizedAccessException();});var d=D();d.Kur();d.Kur();var key=new HizliKimlik(EbelgeOrtam.Canli,"1234567890","fixture-api","enc-user","enc-pass");var date=new DateTime(2026,11,12);
   var supplier=new UblTaraf(key.Vkn,"TEST üretici","TEST","TEST adres","Kayseri","Kocasinan");var customer=new UblTaraf("9876543210","TEST alıcı","TEST","TEST adres","Kayseri","Melikgazi");d.TarafKaydet(key.Ortam,supplier);d.TarafKaydet(key.Ortam,customer);d.BirimKaydet("Adet","C62");
   Reject(()=>d.SatisXml(key,1,Guid.NewGuid(),"TST2026000000001",date,1,"TEMELFATURA",null),"legacy gross discount needs explicit approval");d.SatisMaliKaydet(1,new(),true,"TEST brüt indirim dağılımı");var sale=UblBelge.Oku(d.SatisXml(key,1,Guid.NewGuid(),"TST2026000000001",date,1,"TEMELFATURA",null));Check(sale.Matrah==900&&sale.Vergi==180&&sale.Odenecek==1080,"approved historical gross discount to legal line VAT");Check(Convert.ToDecimal(Scalar(c,"SELECT GenelToplam FROM dbo.BoruERP_YeniBelgeler WHERE Id=1"))==1080,"historical stored total unchanged");
   Reject(()=>d.SatisMaliKaydet(1,new("USD",35,date,"TEST"),true,"TEST yanlış döviz"),"existing TRY sale cannot be reinterpreted as USD");Exec(c,"UPDATE dbo.BoruERP_YeniBelgeler SET ParaBirimi='USD' WHERE Id=2");decimal initialRate=35.123456m;d.SatisMaliKaydet(2,new("USD",initialRate,date,"TEST kur kaynağı",UblMaliHesap.Tevkifat("627")),false,"TEST doğrulanmış tevkifat ve kur");string xml=d.SatisXml(key,2,Guid.NewGuid(),"TST2026000000002",date,1,"TEMELFATURA",null);UblSema.Dogrula(xml);var doc=UblBelge.Oku(xml);Check(doc.Tevkifat==100&&doc.Odenecek==1100&&doc.Kur==initialRate,"FX withholding sale preserves original currency and provider six-decimal rate");
   var record=new HizliKayit(doc.Kimlik.Ettn,2,doc.Kimlik.No,"TEST",customer.Vkn,"TEMELFATURA","TEVKIFAT","USD",200,1100,0,"TEST",0,"TEST","2026-11-12","TEST",IsDraft:false,Iptal:false);long file=d.BelgeAl(key,EbelgeKutusu.GidenFatura,record,xml,false,false);
   Reject(()=>d.Muhasebelestir(key,file,1,"TEST matrah kontrol"),"foreign posting requires reviewed rate source");long operation=d.Muhasebelestir(key,file,1,"TEST mali kontrol",kurDayanak:"TEST kur kaynağı");decimal tryReceivable=UblBelge.Yuvarla(1100*initialRate);Check(Convert.ToDecimal(Scalar(c,"SELECT Tutar FROM dbo.CariHareketleri WHERE Id=1"))==tryReceivable,"ledger posts net withholding payable converted to TRY");Check(Convert.ToDecimal(Scalar(c,"SELECT Kur FROM dbo.MPX280_EbelgeMali"))==initialRate,"SQL rate keeps all provider six-decimal rate");Check(d.Muhasebelestir(key,file,1,"TEST tekrar",kurDayanak:"TEST")==operation,"FX invoice posting remains idempotent");
   Reject(()=>D(false).DovizOde(key,Guid.NewGuid(),operation,1,100,36,date,"TEST tahsilat"),"unauthorized FX payment rejected");Reject(()=>d.DovizOde(key with{Ortam=EbelgeOrtam.Test},Guid.NewGuid(),operation,1,100,36,date,"TEST tahsilat"),"sandbox cannot create actual payment");Reject(()=>d.DovizOde(key,Guid.NewGuid(),operation,3,100,36,date,"TEST tahsilat"),"third currency account rejected");Reject(()=>d.DovizOde(key,Guid.NewGuid(),operation,1,1101,36,date,"TEST tahsilat"),"overpayment rejected");
   Guid pay=Guid.NewGuid();long paid=d.DovizOde(key,pay,operation,1,100,36,date,"TEST ilk tahsilat");Check(d.DovizOde(key,pay,operation,1,100,36,date,"TEST ilk tahsilat")==paid,"payment retry idempotent");Check(Convert.ToDecimal(Scalar(c,"SELECT Tutar FROM dbo.FinansHareketleri WHERE Id=1"))==3600,"TRY bank records actual settlement rate");Check(Convert.ToDecimal(Scalar(c,"SELECT KurFarki FROM dbo.MPX280_DovizOdeme WHERE Id=1"))==3600-UblBelge.Yuvarla(100*initialRate),"realized FX difference separated from customer balance");
   Reject(()=>d.MuhasebeTersle(key,operation,"TEST kaynak iptal",date),"invoice cannot reverse while linked settlements exist");d.DovizOde(key,Guid.NewGuid(),operation,2,1000,36,date,"TEST kalan tahsilat");Check(Convert.ToDecimal(Scalar(c,"SELECT Tutar FROM dbo.FinansHareketleri WHERE Id=2"))==1000,"USD bank remains in original account currency");Check(Convert.ToDecimal(Scalar(c,"SELECT SUM(CASE HareketTipi WHEN N'Borç' THEN Tutar ELSE -Tutar END) FROM dbo.CariHareketleri"))==0,"full settlement allocates final rounding residual and closes TRY customer balance");Check(Convert.ToDecimal(Scalar(c,"SELECT Odenecek-Kapanan FROM dbo.MPX280_EbelgeMali"))==0,"original currency balance closed");
   Reject(()=>d.DovizOde(key,Guid.NewGuid(),operation,1,1,36,date,"TEST fazla"),"closed invoice cannot be collected again");Check(d.DovizListesi(key with{Vkn="1111111111"}).Rows.Count==0,"FX balance tenant isolation");
   Exec(c,"ALTER TABLE dbo.TicariBelgeler ADD CariHareketId bigint NULL,BelgeTarihi date NULL,BelgeTipi nvarchar(40) NULL,AraToplam decimal(18,4) NULL,KdvTutari decimal(18,4) NULL,GenelToplam decimal(18,4) NULL");
   var recon=new MiapaxERP.Desktop.Muhasebe280.MutabakatDeposu(cs,1,(_,_,_)=>{});Check(recon.Ozet(date,date).Rows.Count==1,"current reconciliation includes posted e-document");
   Exec(c,"INSERT dbo.TicariBelgeler(Id,CariId,BelgeNo,Durum,CariHareketId,BelgeTarihi,BelgeTipi,AraToplam,KdvTutari,GenelToplam)SELECT 1,CariId,BelgeNo,N'Kaydedildi',CariHareketId,BelgeTarihi,BelgeTipi,Matrah,Kdv,GenelToplam FROM dbo.BERP270_EBelgeIslem WHERE Id="+operation);
   Check(recon.Ozet(date,date).Rows.Count==1,"manual/electronic shared posting not counted twice");
   Reject(()=>recon.Arsivle(2024,9,"BA","TEST arşiv","%PDF-1.4\n%%EOF"u8.ToArray()),"abolished current BA/BS period cannot be filed");
   var pdf="%PDF-1.4\n%%EOF"u8.ToArray();long ar=recon.Arsivle(2024,8,"BA","TEST eski bildirim",pdf);Check(recon.Arsivle(2024,8,"BA","TEST eski bildirim",pdf)==ar&&recon.Indir(ar).SequenceEqual(pdf),"historical BA/BS archive hash and duplicate handling");
   d.DovizOdemeTersle(key,paid,date,"TEST ilk tahsilat ters kayıt");Check(Convert.ToDecimal(Scalar(c,"SELECT Odenecek-Kapanan FROM dbo.MPX280_EbelgeMali"))==100,"settlement reversal reopens original currency amount");
   Reject(()=>d.DovizOdemeTersle(key,paid,date,"TEST tekrar ters kayıt"),"settlement cannot reverse twice");
   long last=Convert.ToInt64(Scalar(c,"SELECT MAX(Id) FROM dbo.MPX280_DovizOdeme"));d.DovizOdemeTersle(key,last,date,"TEST kalan tahsilat ters kayıt");d.MuhasebeTersle(key,operation,"TEST kaynak belge ters kayıt",date);
   Check(Convert.ToDecimal(Scalar(c,"SELECT SUM(CASE HareketTipi WHEN N'Borç' THEN Tutar ELSE -Tutar END) FROM dbo.CariHareketleri"))==0,"complete reversal chain retains zero customer balance");
   Check(recon.Ozet(date,date).Rows.Count==0,"reversed invoice excluded from reconciliation");
   Console.WriteLine($"Passed {count} fiscal SQL integration checks.");
  }
  finally{if(!System.Text.RegularExpressions.Regex.IsMatch(name,"^MiapaxFiscalTest_[a-f0-9]{32}$"))throw new Exception("Test cleanup guard");Exec(admin,"ALTER DATABASE ["+name+"] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;DROP DATABASE ["+name+"]");}
 }
}
