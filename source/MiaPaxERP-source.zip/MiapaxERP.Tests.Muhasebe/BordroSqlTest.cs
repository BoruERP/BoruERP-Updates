using Microsoft.Data.SqlClient;
using System.Data;
using MiapaxERP.Desktop.Muhasebe280;
static class BordroSqlTest
{
 static int count;
 static void Check(bool b,string n){if(!b)throw new Exception(n);count++;Console.WriteLine("PASS "+n);}
 static object? Scalar(SqlConnection c,string sql){using var q=new SqlCommand(sql,c);return q.ExecuteScalar();}
 static void Exec(SqlConnection c,string sql){using var q=new SqlCommand(sql,c);q.ExecuteNonQuery();}
 static void Reject(Action a,string n){try{a();}catch(Exception e)when(e is ArgumentException or InvalidOperationException or UnauthorizedAccessException or SqlException){Check(true,n);return;}throw new Exception("Accepted: "+n);}
 public static void Run()
 {
  string name="MiapaxPayrollTest_"+Guid.NewGuid().ToString("N");string master="Server=(localdb)\\MSSQLLocalDB;Database=master;Integrated Security=true;TrustServerCertificate=true;Pooling=false";using var admin=new SqlConnection(master);admin.Open();Exec(admin,"CREATE DATABASE ["+name+"]");
  try
  {
   var cs=new SqlConnectionStringBuilder(master){InitialCatalog=name}.ConnectionString;using var c=new SqlConnection(cs);c.Open();Exec(c,"""
   CREATE TABLE dbo.Yetkiler(YetkiKodu varchar(100) PRIMARY KEY,Modul nvarchar(100),Islem nvarchar(100),Aciklama nvarchar(200),Aktif bit);
   CREATE TABLE dbo.BERP_Personel(Id int PRIMARY KEY,Sicil nvarchar(50),AdSoyad nvarchar(100),IseGiris date,IstenCikis date NULL);
   INSERT dbo.BERP_Personel VALUES(1,'P1',N'TEST PERSONEL','2025-01-01',NULL);
   CREATE TABLE dbo.CariKartlari(Id int PRIMARY KEY,CariKodu nvarchar(50),Unvan nvarchar(100),Aktif bit);INSERT dbo.CariKartlari VALUES(1,'P1',N'TEST PERSONEL',1);
   CREATE TABLE dbo.CariHareketleri(Id bigint IDENTITY PRIMARY KEY,CariId int,Tarih date,HareketTipi nvarchar(30),Tutar decimal(18,2),Aciklama nvarchar(400),Kaynak nvarchar(100),YapanKullaniciId int,TersKayitId bigint NULL);
   CREATE TABLE dbo.FinansHesaplari(Id int PRIMARY KEY,HesapAdi nvarchar(100),Aktif bit,ParaBirimi varchar(3));INSERT dbo.FinansHesaplari VALUES(1,N'TEST Banka',1,'TRY'),(2,N'TEST USD',1,'USD');
   CREATE TABLE dbo.FinansHareketleri(Id bigint IDENTITY PRIMARY KEY,HesapId int,CariId int,CariHareketId bigint,Tarih date,HareketTipi nvarchar(30),Tutar decimal(18,2),Aciklama nvarchar(400),YapanKullaniciId int,TersKayitId bigint NULL);
   CREATE TABLE dbo.FactorySentinel(Id int PRIMARY KEY,Value decimal(18,2));INSERT dbo.FactorySentinel VALUES(1,987654.32);
   """);
   BordroDeposu S(bool allow=true)=>new(cs,1,(_,_,_)=>{if(!allow)throw new UnauthorizedAccessException();});var d=S();d.Kur();d.Kur();Check(d.Secimler(true).Rows.Count==1,"existing personnel schema without imaginary active column");Check(Convert.ToInt32(Scalar(c,"SELECT COUNT(*) FROM dbo.Yetkiler"))==6,"payroll migration idempotent");
   var g=new BordroGirdi(2026,1,UcretEsasi.Brut,33030,30,SigortaTuru.Normal4A,0,0,true);Guid key=Guid.NewGuid();Reject(()=>S(false).Hazirla(key,1,1,g,"TEST bordro"),"unauthorized payroll rejected");long id=d.Hazirla(key,1,1,g,"TEST bordro");Check(d.Hazirla(key,1,1,g,"TEST bordro")==id,"payroll preparation idempotent");Reject(()=>d.Hazirla(key,1,1,g with{Ucret=40000},"TEST bordro"),"idempotency key cannot switch wages");
   Check(Convert.ToInt32(Scalar(c,"SELECT COUNT(*) FROM dbo.CariHareketleri"))==0,"draft does not post employee debt");var row=d.Liste().Rows[0];byte[] ver=(byte[])row["Surum"];Reject(()=>S(false).Onayla(id,ver,"TEST onay"),"unauthorized accrual rejected");d.Onayla(id,ver,"TEST onay");Reject(()=>d.Onayla(id,ver,"TEST tekrar"),"duplicate accrual blocked");Check(Convert.ToDecimal(Scalar(c,"SELECT SUM(Tutar) FROM dbo.CariHareketleri WHERE HareketTipi=N'Alacak'"))==28075.50m,"employee wage payable posted once");Check(Convert.ToInt32(Scalar(c,"SELECT COUNT(*) FROM dbo.FinansHareketleri"))==0,"accrual is not payment");
   row=d.Liste().Rows[0];ver=(byte[])row["Surum"];Reject(()=>d.Ode(id,ver,2,new(2026,2,1),"TEST ödeme"),"payroll cannot debit foreign currency account");d.Ode(id,ver,1,new(2026,2,1),"TEST ödeme");Reject(()=>d.Ode(id,ver,1,new(2026,2,1),"TEST tekrar"),"duplicate payment blocked");Check(Convert.ToInt32(Scalar(c,"SELECT COUNT(*) FROM dbo.FinansHareketleri"))==1,"one bank withdrawal");Check(Convert.ToDecimal(Scalar(c,"SELECT SUM(CASE HareketTipi WHEN N'Borç' THEN Tutar ELSE -Tutar END) FROM dbo.CariHareketleri"))==0,"employee payable settled");
   var next=g with{Ay=2,OncekiMatrah=28075.50m,OncekiIstisnaMatrahi=28075.50m};Reject(()=>d.Hazirla(Guid.NewGuid(),1,1,next with{OncekiMatrah=0},"TEST yanlış matrah"),"previous cumulative cannot reset silently");long nextId=d.Hazirla(Guid.NewGuid(),1,1,next,"TEST Şubat");row=d.Liste().Rows[0];d.Onayla(nextId,(byte[])row["Surum"],"TEST onay");row=d.Liste().Rows[0];d.Iptal(nextId,(byte[])row["Surum"],"Onaylandı","TEST düzeltme",new(2026,2,28));Check(Convert.ToDecimal(Scalar(c,"SELECT SUM(CASE HareketTipi WHEN N'Borç' THEN Tutar ELSE -Tutar END) FROM dbo.CariHareketleri"))==0,"cancelled unpaid accrual reverses without deleting history");
   Check(Convert.ToDecimal(Scalar(c,"SELECT Value FROM dbo.FactorySentinel"))==987654.32m,"existing factory data unchanged");Check(Convert.ToInt32(Scalar(c,"SELECT COUNT(*) FROM dbo.MPX280_BordroOlay"))==6,"payroll audit history retained");
   row=d.Liste().AsEnumerable().Single(r=>(long)r["Id"]==id);d.OdemeTersle(id,(byte[])row["Surum"],new(2026,2,28),"TEST ücret ödeme düzeltme");Check(Convert.ToDecimal(Scalar(c,"SELECT SUM(CASE HareketTipi WHEN N'Çıkış' THEN Tutar ELSE -Tutar END) FROM dbo.FinansHareketleri"))==0,"payroll payment reversal restores bank with history");
   row=d.Liste().AsEnumerable().Single(r=>(long)r["Id"]==id);d.Iptal(id,(byte[])row["Surum"],"Onaylandı","TEST tahakkuk düzeltme",new(2026,2,28));Check(Convert.ToDecimal(Scalar(c,"SELECT SUM(CASE HareketTipi WHEN N'Borç' THEN Tutar ELSE -Tutar END) FROM dbo.CariHareketleri"))==0,"paid payroll can be corrected by payment then accrual reversal");
   Exec(c,"INSERT dbo.CariHareketleri(CariId,Tarih,HareketTipi,Tutar,Aciklama,Kaynak,YapanKullaniciId)VALUES(1,'2026-03-01',N'Borç',1000,N'TEST ücret avansı',N'Avans',1)");long advance=Convert.ToInt64(Scalar(c,"SELECT MAX(Id) FROM dbo.CariHareketleri"));
   long march=d.Hazirla(Guid.NewGuid(),1,1,g with{Ay=3,Avans=1000},"TEST avanslı bordro");row=d.Liste().AsEnumerable().Single(r=>(long)r["Id"]==march);byte[] marchVersion=(byte[])row["Surum"];
   Reject(()=>d.Onayla(march,marchVersion,"TEST eksik avans"),"payroll advance requires existing paid advance link");
   d.Onayla(march,marchVersion,"TEST avans mahsup",advance);Check(Convert.ToDecimal(Scalar(c,"SELECT Tutar FROM dbo.CariHareketleri WHERE Id=(SELECT CariHareketId FROM dbo.MPX280_Bordro WHERE Id="+march+")"))==28075.50m,"accrual remains full net before previously paid advance");
   row=d.Liste().AsEnumerable().Single(r=>(long)r["Id"]==march);d.Ode(march,(byte[])row["Surum"],1,new(2026,3,31),"TEST avans sonrası ücret");Check(Convert.ToDecimal(Scalar(c,"SELECT SUM(CASE HareketTipi WHEN N'Borç' THEN Tutar ELSE -Tutar END) FROM dbo.CariHareketleri"))==0,"advance is deducted once across existing cash and payroll ledger");
   Console.WriteLine($"Passed {count} isolated SQL payroll checks.");
  }
  finally{if(!System.Text.RegularExpressions.Regex.IsMatch(name,"^MiapaxPayrollTest_[a-f0-9]{32}$"))throw new Exception("Test cleanup guard");Exec(admin,"ALTER DATABASE ["+name+"] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;DROP DATABASE ["+name+"]");}
 }
}
