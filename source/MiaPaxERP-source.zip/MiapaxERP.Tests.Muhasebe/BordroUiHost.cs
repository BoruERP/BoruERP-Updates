using Microsoft.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using MiapaxERP.Desktop.Muhasebe280;
static class BordroUiHost
{
 static void Sql(SqlConnection c,string text){using var q=new SqlCommand(text,c);q.ExecuteNonQuery();}
 public static void Run(bool render=false)
 {
  string db="MiapaxUiTest_"+Guid.NewGuid().ToString("N"),master="Server=(localdb)\\MSSQLLocalDB;Database=master;Integrated Security=true;TrustServerCertificate=true;Pooling=false";using var admin=new SqlConnection(master);admin.Open();Sql(admin,"CREATE DATABASE ["+db+"]");
  try
  {
   string cs=new SqlConnectionStringBuilder(master){InitialCatalog=db}.ConnectionString;using var c=new SqlConnection(cs);c.Open();Sql(c,"""
   CREATE TABLE dbo.Yetkiler(YetkiKodu varchar(100) PRIMARY KEY,Modul nvarchar(100),Islem nvarchar(100),Aciklama nvarchar(200),Aktif bit);
   CREATE TABLE dbo.BERP_Personel(Id int PRIMARY KEY,Sicil nvarchar(50),AdSoyad nvarchar(100),Aktif bit,IseGiris date,IstenCikis date NULL);INSERT dbo.BERP_Personel VALUES(1,'TEST-001',N'TEST PERSONEL',1,'2025-01-01',NULL);
   CREATE TABLE dbo.CariKartlari(Id int PRIMARY KEY,CariKodu nvarchar(50),Unvan nvarchar(100),Aktif bit);INSERT dbo.CariKartlari VALUES(1,'TEST-PERSONEL',N'TEST PERSONEL',1);
   CREATE TABLE dbo.CariHareketleri(Id bigint IDENTITY PRIMARY KEY,CariId int,Tarih date,HareketTipi nvarchar(30),Tutar decimal(18,2),Aciklama nvarchar(400),Kaynak nvarchar(100),YapanKullaniciId int,TersKayitId bigint NULL);
   CREATE TABLE dbo.FinansHesaplari(Id int PRIMARY KEY,HesapAdi nvarchar(100),Aktif bit,ParaBirimi varchar(3));INSERT dbo.FinansHesaplari VALUES(1,N'TEST BANKA',1,'TRY');
   CREATE TABLE dbo.FinansHareketleri(Id bigint IDENTITY PRIMARY KEY,HesapId int,CariId int,CariHareketId bigint,Tarih date,HareketTipi nvarchar(30),Tutar decimal(18,2),Aciklama nvarchar(400),YapanKullaniciId int,TersKayitId bigint NULL);
   """);
   var store=new BordroDeposu(cs,1,(_,_,_)=>{});store.Kur();var app=new Application();var tabs=new TabControl();tabs.Items.Add(new TabItem{Header="Bordro TEST",Content=new BordroPaneli(store)});tabs.Items.Add(new TabItem{Header="Mutabakat TEST",Content=new MutabakatPaneli(new MutabakatDeposu(cs,1,(_,_,_)=>{}))});
   var logo=new Image{Source=new BitmapImage(new Uri("pack://application:,,,/MiapaxERP.Desktop;component/Assets/MiapaxERP_Wordmark.png")),MaxWidth=650,Stretch=Stretch.Uniform};tabs.Items.Add(new TabItem{Header="Miapax logo",Content=new Border{Padding=new Thickness(40),Background=Brushes.White,Child=logo}});
   if(render)
   {
    for(int i=0;i<tabs.Items.Count;i++){var item=(TabItem)tabs.Items[i];var view=(FrameworkElement)item.Content;item.Content=null;var root=new Border{Background=Brushes.White,Child=view};var size=new Size(1360,900);root.Measure(size);root.Arrange(new Rect(size));root.UpdateLayout();var image=new RenderTargetBitmap(1360,900,96,96,PixelFormats.Pbgra32);image.Render(root);var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(image));using var file=System.IO.File.Create(System.IO.Path.Combine(AppContext.BaseDirectory,"arayuz-"+i+".png"));encoder.Save(file);root.Child=null;Console.WriteLine("PASS rendered UI page "+i);}app.Shutdown();
   }
   else app.Run(new Window{Title="Miapax ERP 2.8 · YALNIZ TEST · Fabrika verisi içermez",Width=1360,Height=900,WindowStartupLocation=WindowStartupLocation.CenterScreen,Content=tabs});
  }
  finally{if(!System.Text.RegularExpressions.Regex.IsMatch(db,"^MiapaxUiTest_[a-f0-9]{32}$"))throw new Exception("Test cleanup guard");Sql(admin,"ALTER DATABASE ["+db+"] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;DROP DATABASE ["+db+"]");}
 }
}
