using MiapaxERP.Desktop.Muhasebe280;
static class Program
{
 static int passed;
 static void Eq(decimal a,decimal b,string message){if(a!=b)throw new Exception($"{message}: {a} != {b}");passed++;Console.WriteLine("PASS "+message);}
 static void Reject(Action a,string message){try{a();}catch(ArgumentException){passed++;Console.WriteLine("PASS "+message);return;}throw new Exception("Accepted: "+message);}
 [STAThread]static void Main(string[] args)
 {
  if(args.SequenceEqual(new[]{"--arayuz-test"})){BordroUiHost.Run();return;}
  if(args.SequenceEqual(new[]{"--render-arayuz"})){BordroUiHost.Run(true);return;}
  var g=new BordroGirdi(2026,1,UcretEsasi.Brut,33030,30,SigortaTuru.Normal4A,0,0,true);var s=BordroHesabi.Hesapla(g);
  Eq(s.Net,28075.50m,"Ministry published minimum net");Eq(s.IsciSgk,4624.20m,"minimum SGK");Eq(s.IsciIssizlik,330.30m,"minimum unemployment");Eq(s.GelirVergisi,0,"minimum income exemption");Eq(s.DamgaVergisi,0,"minimum stamp exemption");
  Eq(s.IsverenMaliyeti,40874.63m,"undiscounted cost");Eq(BordroHesabi.Hesapla(g with{IsverenIndirimPuani=5,IndirimDayanagi="İmalat uygunluğu test"}).IsverenMaliyeti,39223.13m,"Ministry manufacturing cost");
  Eq(BordroHesabi.Vergi(190000),28500,"bracket1");Eq(BordroHesabi.Vergi(400000),70500,"bracket2");Eq(BordroHesabi.Vergi(1500000),367500,"WAGE third bracket");Eq(BordroHesabi.Vergi(5300000),1697500,"bracket4");Eq(BordroHesabi.Vergi(5300001),1697500.40m,"bracket5");
  for(int m=1;m<=12;m++){var b=BordroHesabi.Hesapla(g with{Ay=m,OncekiMatrah=(m-1)*28075.5m,OncekiIstisnaMatrahi=(m-1)*28075.5m});Eq(b.Net,28075.50m,"minimum exemption month "+m);}
  foreach(var gross in new[]{33030m,40000m,80000m,300000m,1000000m})foreach(var cumulative in new[]{0m,189000m,399000m,1499000m,5299000m}){var input=g with{Ay=6,Ucret=gross,OncekiMatrah=cumulative,OncekiIstisnaMatrahi=5*28075.50m};var grossResult=BordroHesabi.Hesapla(input);var solved=BordroHesabi.Hesapla(input with{Esas=UcretEsasi.Net,Ucret=grossResult.Net});if(Math.Abs(solved.Net-grossResult.Net)>.01m)throw new Exception("net solve");passed++;}
  Eq(BordroHesabi.Hesapla(g with{Ucret=500000}).Pek,297270,"2026 SGK ceiling nine times minimum");Eq(BordroHesabi.Hesapla(g with{PrimGunu=15,Ucret=16515}).Net,14037.75m,"partial minimum");
  Eq(BordroHesabi.Hesapla(g with{Sigorta=SigortaTuru.EmekliSGDP}).IsciSgk,2477.25m,"SGDP worker");Eq(BordroHesabi.Hesapla(g with{Sigorta=SigortaTuru.EmekliSGDP}).IsverenSgk,8174.93m,"SGDP employer");
  Reject(()=>BordroHesabi.Hesapla(g with{Yil=2027}),"unverified year rejected");Reject(()=>BordroHesabi.Hesapla(g with{Ucret=30000}),"below minimum rejected");Reject(()=>BordroHesabi.Hesapla(g with{PrimGunu=31}),"invalid days rejected");Reject(()=>BordroHesabi.Hesapla(g with{OncekiMatrah=1}),"January cumulative reset");Reject(()=>BordroHesabi.Hesapla(g with{IsverenIndirimPuani=5}),"no assumed incentive eligibility");Reject(()=>BordroHesabi.Hesapla(g with{Avans=50000}),"negative payable rejected");
  Console.WriteLine($"Passed {passed} payroll calculation checks.");
  BordroSqlTest.Run();
  MaliTest.Run();
  MaliSqlTest.Run();
 }
}
