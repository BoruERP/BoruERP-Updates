[CmdletBinding()]
param(
    [string]$CozumKlasoru = (Split-Path -Parent $PSScriptRoot),
    [Parameter(Mandatory=$true)][ValidateSet('Ana','Yan')][string]$Kanal,
    [Parameter(Mandatory=$true)][string]$Surum,
    [Parameter(Mandatory=$true)][string]$HttpsPaketUrl,
    [string]$OzelAnahtar = (Join-Path $env:USERPROFILE 'BoruERP_GizliAnahtarlar\boruerp-private.pem'),
    [string]$Cikti = (Join-Path $env:USERPROFILE 'Documents\MiapaxERP_Yayinlar'),
    [string]$HazirYayinKlasoru
)
$ErrorActionPreference = 'Stop'
if ($Surum -notmatch '^\d+\.\d+\.\d+$') { throw 'Sürüm x.y.z biçiminde olmalı.' }
$uri = $null
if (![Uri]::TryCreate($HttpsPaketUrl, [UriKind]::Absolute, [ref]$uri) -or $uri.Scheme -ne 'https') { throw 'Paket adresi HTTPS olmalı.' }
$desktopProject = Join-Path $CozumKlasoru 'MiapaxERP.Desktop\MiapaxERP.Desktop.csproj'
$public = Join-Path $CozumKlasoru 'MiapaxERP.Desktop\GuncellemeAnahtari.g.cs'
foreach ($file in @($desktopProject, $OzelAnahtar, $public)) {
    if (!(Test-Path -LiteralPath $file -PathType Leaf)) { throw "Dosya eksik: $file" }
}
# Eski kurulumların güvendiği anahtar değiştirilmez. Anahtar içeriği ekrana yazılmaz.
$rsa = [Security.Cryptography.RSA]::Create()
$publicRsa = [Security.Cryptography.RSA]::Create()
try {
    $rsa.ImportFromPem([IO.File]::ReadAllText($OzelAnahtar))
    $pem = [regex]::Match([IO.File]::ReadAllText($public), '-----BEGIN PUBLIC KEY-----[\s\S]+?-----END PUBLIC KEY-----').Value
    $publicRsa.ImportFromPem($pem)
    if ([Convert]::ToBase64String($rsa.ExportSubjectPublicKeyInfo()) -ne [Convert]::ToBase64String($publicRsa.ExportSubjectPublicKeyInfo())) {
        throw 'İmzalama anahtarı uygulamanın açık anahtarıyla eşleşmiyor.'
    }
    New-Item -ItemType Directory -Path $Cikti -Force | Out-Null
    $zip = Join-Path $Cikti "MiapaxERP-$Kanal-v$Surum.zip"
    $manifest = Join-Path $Cikti "manifest-$($Kanal.ToLowerInvariant()).json"
    if ((Test-Path -LiteralPath $zip) -or (Test-Path -LiteralPath $manifest)) { throw 'Bu sürüm paketi zaten var. Yeni bir çıktı klasörü seçin.' }
    $appDir = Join-Path $Cikti ("Uygulama_${Kanal}_${Surum}_" + [Guid]::NewGuid().ToString('N'))
    if ($HazirYayinKlasoru) {
        if (!(Test-Path -LiteralPath (Join-Path $HazirYayinKlasoru 'MiapaxERP.Desktop.exe'))) { throw 'Hazır yayın bulunamadı.' }
        New-Item -ItemType Directory -Path $appDir | Out-Null
        Get-ChildItem -LiteralPath $HazirYayinKlasoru | Copy-Item -Destination $appDir -Recurse
    } else {
        & dotnet publish $desktopProject -c Release -r win-x64 --self-contained true "-p:Version=$Surum" "-p:AssemblyVersion=${Surum}.0" "-p:FileVersion=${Surum}.0" -p:PublishSingleFile=false -p:PublishTrimmed=false -o $appDir
        if ($LASTEXITCODE -ne 0) { throw 'Desktop publish başarısız.' }
    }
    $desktopExe = Join-Path $appDir 'MiapaxERP.Desktop.exe'
    $updaterExe = Join-Path $appDir 'MiapaxERP.Updater.exe'
    if (!(Test-Path -LiteralPath $desktopExe) -or !(Test-Path -LiteralPath $updaterExe)) { throw 'Uygulama veya bağımsız güncelleyici eksik.' }
    if ([Version]([Diagnostics.FileVersionInfo]::GetVersionInfo($desktopExe).FileVersion) -ne [Version]"$Surum.0") { throw 'Paketin gerçek dosya sürümü bildirimle eşleşmiyor.' }
    $config = Join-Path $appDir 'MiapaxERP.guncelleme.json'
    Get-ChildItem -LiteralPath $appDir -Recurse -File -Filter '*.pdb' | Remove-Item
    foreach($configName in @('MiapaxERP.guncelleme.json','BoruERP.guncelleme.json')) { $channelFile=Join-Path $appDir $configName; if(Test-Path -LiteralPath $channelFile){Remove-Item -LiteralPath $channelFile} }
    $unwanted = @(Get-ChildItem -LiteralPath $appDir -Recurse -File | Where-Object {
        $_.Extension -in @('.db','.sqlite','.sqlite3','.mdf','.ldf','.bak','.pem','.pfx','.dpapi') -or
        $_.Name -eq 'ag-baglantisi.json' -or $_.FullName -match '[\\/](Data|UserData)[\\/]'
    })
    if ($unwanted.Count) { throw "Yayın klasöründe veri/özel anahtar bulundu: $($unwanted[0].Name)" }
    [IO.Compression.ZipFile]::CreateFromDirectory($appDir, $zip, [IO.Compression.CompressionLevel]::Optimal, $false)
    $sha = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
    $canonical = "$Surum`n$Kanal`n$HttpsPaketUrl`n$sha`n"
    $bytes = [Text.Encoding]::UTF8.GetBytes($canonical)
    $signature = $rsa.SignData($bytes, [Security.Cryptography.HashAlgorithmName]::SHA256, [Security.Cryptography.RSASignaturePadding]::Pss)
    if (!$publicRsa.VerifyData($bytes, $signature, [Security.Cryptography.HashAlgorithmName]::SHA256, [Security.Cryptography.RSASignaturePadding]::Pss)) { throw 'İmza doğrulanamadı.' }
    $m = [ordered]@{Version=$Surum;Channel=$Kanal;PackageUrl=$HttpsPaketUrl;Sha256=$sha;Signature=[Convert]::ToBase64String($signature)}
    [IO.File]::WriteAllText($manifest, ($m | ConvertTo-Json), [Text.UTF8Encoding]::new($false))
    $kurulum = Join-Path $Cikti "KurulumAyarlari\$Kanal"
    New-Item -ItemType Directory -Path $kurulum -Force | Out-Null
    $ayar = [ordered]@{ManifestUrl="https://raw.githubusercontent.com/MiaPaxERP/MiapaxERP-Updates/main/manifest-$($Kanal.ToLowerInvariant()).json";Channel=$Kanal;CheckMinutes=30}
    [IO.File]::WriteAllText((Join-Path $kurulum 'MiapaxERP.guncelleme.json'), ($ayar | ConvertTo-Json), [Text.UTF8Encoding]::new($false))
    Write-Output "Paket: $zip"
    Write-Output "Manifest: $manifest"
    Write-Output "SHA256: $sha"
    Write-Output "Hazır yayın: $appDir"
} finally {
    $rsa.Dispose()
    $publicRsa.Dispose()
}
