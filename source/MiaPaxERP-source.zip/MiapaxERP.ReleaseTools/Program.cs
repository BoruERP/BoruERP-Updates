using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

try
{
    if (args.Length == 3 && args[0] == "init-key")
    {
        string privateKeyPath = Path.GetFullPath(args[1]);
        string pubCsPath = Path.GetFullPath(args[2]);
        if (File.Exists(privateKeyPath)) throw new InvalidOperationException("Özel anahtar mevcut, üzerine yazılamaz!");
        using RSA rsa = RSA.Create(3072);
        Directory.CreateDirectory(Path.GetDirectoryName(privateKeyPath)!);
        Directory.CreateDirectory(Path.GetDirectoryName(pubCsPath)!);
        File.WriteAllText(privateKeyPath, rsa.ExportPkcs8PrivateKeyPem());
        var pem = rsa.ExportSubjectPublicKeyInfoPem();
        File.WriteAllText(pubCsPath, "// Kamuya açık doğrulama anahtarı. ÖZEL ANAHTARI yayınlama.\n" +
            "namespace MiapaxERP.Guncelleme;\ninternal static class GuncellemeAnahtari\n{\n" +
            "    public const string Pem = @\"" + pem.Replace("\"", "\"\"") + "\";\n}\n");
        Console.WriteLine("Kamuya açık anahtar C# dosyasına yazıldı. Özel PEM'İ kimseyle paylaşma: " + privateKeyPath);
        return 0;
    }
    if (args.Length == 7 && args[0] == "sign")
    {
        string privateKeyPath = args[1], version = args[2], channel = args[3], url = args[4], zipPath = args[5], outputPath = args[6];
        if (!Version.TryParse(version, out _)) throw new ArgumentException("Sürüm 1.0.1 gibi olmalı.");
        if (channel is not ("Ana" or "Yan")) throw new ArgumentException("Kanal Ana veya Yan olmalı.");
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri) || uri.Scheme != "https") throw new ArgumentException("Paket URL HTTPS olmalı.");
        using RSA rsa = RSA.Create();
        rsa.ImportFromPem(File.ReadAllText(privateKeyPath));
        string hash = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(zipPath))).ToLowerInvariant();
        string canonical = version + "\n" + channel + "\n" + url + "\n" + hash + "\n";
        string signature = Convert.ToBase64String(rsa.SignData(Encoding.UTF8.GetBytes(canonical),
            HashAlgorithmName.SHA256, RSASignaturePadding.Pss));
        var manifest = new { Version = version, Channel = channel, PackageUrl = url, Sha256 = hash, Signature = signature };
        File.WriteAllText(outputPath, JsonSerializer.Serialize(manifest, new JsonSerializerOptions { WriteIndented = true }));
        Console.WriteLine("İmzalı manifest hazır: " + outputPath);
        return 0;
    }
    Console.Error.WriteLine("Kullanım: init-key <ozel.pem> <Desktop/GuncellemeAnahtari.g.cs>\n" +
        "       sign <ozel.pem> <version> <Ana|Yan> <https:zip-url> <zip-file> <manifest.json>");
    return 2;
}
catch (Exception e) { Console.Error.WriteLine(e.Message); return 1; }
