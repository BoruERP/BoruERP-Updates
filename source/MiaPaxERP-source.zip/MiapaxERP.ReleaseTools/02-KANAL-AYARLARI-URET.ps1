[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$AnaManifestUrl,
    [Parameter(Mandatory=$true)][string]$YanManifestUrl,
    [string]$Cikti = (Join-Path $env:USERPROFILE 'Documents\MiapaxERP_Kurulum_Ayarlari')
)
$ErrorActionPreference = 'Stop'
foreach($url in @($AnaManifestUrl,$YanManifestUrl)){
    if ($url -notmatch '^https://') { throw 'Her iki manifest adresi HTTPS olmalı.' }
}
foreach($c in @(@{Ad='Ana';Url=$AnaManifestUrl},@{Ad='Yan';Url=$YanManifestUrl})){
    $folder = Join-Path $Cikti $c.Ad
    New-Item -ItemType Directory -Path $folder -Force | Out-Null
    @{ManifestUrl=$c.Url;Channel=$c.Ad;CheckMinutes=30} | ConvertTo-Json | Set-Content -Encoding UTF8 (Join-Path $folder 'MiapaxERP.guncelleme.json')
}
Write-Host "Kurulum için Ana/Yan JSON ayarları hazır: $Cikti" -ForegroundColor Green
Write-Host 'Ana PC Setup, Ana JSON dosyasını; Yan PC Setup, Yan JSON dosyasını ilk kurulumda yüklemeli.'
