[CmdletBinding()]
param(
    [string]$CozumKlasoru = (Split-Path -Parent $PSScriptRoot),
    [string]$OzelAnahtar = (Join-Path $env:USERPROFILE 'Documents\MiapaxERP_Yayin_Anahtari\guncelleme-private.pem')
)
$ErrorActionPreference = 'Stop'
$desktop = Join-Path $CozumKlasoru 'MiapaxERP.Desktop'
$pub = Join-Path $desktop 'GuncellemeAnahtari.g.cs'
$project = Join-Path $CozumKlasoru 'MiapaxERP.ReleaseTools\MiapaxERP.ReleaseTools.csproj'
if (!(Test-Path $project)) { throw "YayinAraclari bulunamadı: $project" }
if (!(Test-Path $pub)) { throw "Desktop public key dosyası yok: $pub" }
if (Test-Path $OzelAnahtar) { throw 'Özel anahtar zaten mevcut; ikinci anahtar oluşturma! Mevcut PEM korunmalıdır.' }
if ((Get-Content -Raw $pub) -notmatch 'PUBLIC_KEY_NOT_CONFIGURED') { throw 'Public anahtar zaten ayarlı. Özel PEM kayıpsa devam etme.' }
& dotnet run --project $project -- init-key $OzelAnahtar $pub
if ($LASTEXITCODE -ne 0) { throw 'Anahtar üretimi başarısız.' }
Write-Host "Anahtar üretildi. Private PEM: $OzelAnahtar" -ForegroundColor Green
Write-Host 'Özel anahtarı ZIP, Setup, GitHub veya fabrika bilgisayarlarına koyma.' -ForegroundColor Yellow
