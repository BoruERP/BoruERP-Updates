namespace MiapaxERP.MobileServer;
public static class MobilLisansBakimi
{
    public static async Task Deneme(Func<Task> renew,Action<Exception> error,CancellationToken stop=default)
    {
        try{await renew();}
        catch(OperationCanceledException)when(stop.IsCancellationRequested){throw;}
        catch(Exception e){error(e);}
    }
    public static async Task Dongu(Func<Task> renew,TimeSpan interval,Action<Exception> error,CancellationToken stop)
    {
        try{using var timer=new PeriodicTimer(interval);while(await timer.WaitForNextTickAsync(stop))await Deneme(renew,error,stop);}
        catch(OperationCanceledException)when(stop.IsCancellationRequested){}
    }
}
