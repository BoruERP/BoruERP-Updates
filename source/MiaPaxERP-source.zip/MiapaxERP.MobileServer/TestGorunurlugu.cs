using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("MiapaxERP.Tests.UzakCalisma")]
