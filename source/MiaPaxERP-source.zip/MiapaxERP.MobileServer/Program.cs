using System.IO;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Text.Json;
using System.Security.Principal;
using MiapaxERP.Desktop;
using Microsoft.Data.SqlClient;
using MiapaxERP.MobileServer;

record Settings(string Connection,string? ActivationKey,string HttpsAddress="");
class Program{
 internal static readonly string Folder=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),"BoruERP","MobilSunucu");
 internal static readonly string FilePath=Path.Combine(Folder,"ayarlar.dpapi");
 internal static void Store(Settings s){Directory.CreateDirectory(Folder);var acl=new DirectorySecurity();acl.SetAccessRuleProtection(true,false);foreach(var sid in new[]{WellKnownSidType.BuiltinAdministratorsSid,WellKnownSidType.LocalSystemSid})acl.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(sid,null),FileSystemRights.FullControl,InheritanceFlags.ContainerInherit|InheritanceFlags.ObjectInherit,PropagationFlags.None,AccessControlType.Allow));new DirectoryInfo(Folder).SetAccessControl(acl);File.WriteAllBytes(FilePath+".tmp",ProtectedData.Protect(JsonSerializer.SerializeToUtf8Bytes(s),null,DataProtectionScope.LocalMachine));File.Move(FilePath+".tmp",FilePath,true);}
 internal static Settings Read()=>JsonSerializer.Deserialize<Settings>(ProtectedData.Unprotect(File.ReadAllBytes(FilePath),null,DataProtectionScope.LocalMachine))??throw new InvalidDataException("Sunucu ayarı okunamadı.");
 static string Secret(string prompt){Console.Write(prompt);var s=new System.Text.StringBuilder();ConsoleKeyInfo k;while((k=Console.ReadKey(true)).Key!=ConsoleKey.Enter){if(k.Key==ConsoleKey.Backspace){if(s.Length>0)s.Length--;}else if(!char.IsControl(k.KeyChar))s.Append(k.KeyChar);}Console.WriteLine();return s.ToString();}
 public static async Task<int> Main(string[] args){
  try{
   if(args.Length>0 && args[0]=="setup"){KolaySunucuKurulumu.Ac(args.Length>1?args[1]:"");return 0;}
   if(args.Length>0 && args[0]=="https-proxy"){await HttpsProxyServisi.Calistir();return 0;}
   if(args.Contains("configure")){
    if(!new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator))throw new InvalidOperationException("Yönetici olarak çalıştırın.");
    Console.Write("SQL Server adı: ");string server=Console.ReadLine()!.Trim();Console.Write("Veritabanı adı: ");string database=Console.ReadLine()!.Trim();
    Console.Write("Windows kimliği kullanılsın mı? (E/H): ");bool integrated=Console.ReadLine()?.Trim().Equals("E",StringComparison.OrdinalIgnoreCase)==true;
    var cs=new SqlConnectionStringBuilder{DataSource=server,InitialCatalog=database,IntegratedSecurity=integrated,Encrypt=SqlConnectionEncryptOption.Mandatory,TrustServerCertificate=false,ConnectTimeout=15};
    if(!integrated){Console.Write("SQL kullanıcısı: ");cs.UserID=Console.ReadLine();cs.Password=Secret("SQL parolası: ");}
    Console.Write("SQL sertifikası özel/yerel ve doğrulanamıyor mu? Yalnız güvenilen yerel SQL için E: ");cs.TrustServerCertificate=Console.ReadLine()?.Trim().Equals("E",StringComparison.OrdinalIgnoreCase)==true;
    string key=Secret("64 karakterlik lisans anahtarı: ");if(key.Length!=64)throw new ArgumentException("Lisans anahtarı 64 karakter olmalı.");
    Store(new(cs.ConnectionString,key));Console.WriteLine("Şifreli ayarlar hazır. Servisi kurun veya yeniden başlatın. Windows SQL kimliği, servis hesabına aittir.");return 0;
   }
   var settings=Read();LisansOturumu.Hazirla(settings.Connection);
   async Task Renew(){
    bool ok=await LisansOturumu.YenileAsync(settings.ActivationKey);
    if(ok&&settings.ActivationKey is not null){settings=settings with{ActivationKey=null};Store(settings);}
    LisansOturumu.SaatIziniGuncelle();
    Console.WriteLine(DateTimeOffset.UtcNow.ToString("O")+" "+(LisansOturumu.Gecerli is not null?"Ana sunucu lisansı doğrulandı.":"Ana sunucu erişimi kapalı. Lisans/bağlantı kontrol edilmeli."));
   }
   void LogRenewError(Exception e)=>Console.Error.WriteLine(DateTimeOffset.UtcNow.ToString("O")+" Lisans bakım denemesi başarısız: "+e.GetType().Name+". Sonraki denemede yeniden kontrol edilecek; imzalı izin süresi uzatılmaz.");
   await MobilLisansBakimi.Deneme(Renew,LogRenewError);
   await using var app=MobilApi220.Olustur(settings.Connection,5188,b=>b.Host.UseWindowsService(o=>o.ServiceName="MiapaxERPMobil"));
   using var stop=new CancellationTokenSource();var renew=MobilLisansBakimi.Dongu(Renew,TimeSpan.FromMinutes(30),LogRenewError,stop.Token);
   try{await app.RunAsync();}finally{stop.Cancel();await renew;}return 0;
  }catch(Exception e){Console.Error.WriteLine("Ana sunucu servisi başlatılamadı: "+e.GetType().Name+". Ayarları, SQL bağlantısını ve servis olay günlüğünü kontrol edin.");return 1;}
 }
}
