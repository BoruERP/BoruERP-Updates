using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net.Http;
using System.Security.Cryptography;
using System.Security.Principal;
using System.ServiceProcess;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Win32;
using MiapaxERP.Desktop;

namespace MiapaxERP.MobileServer;

internal sealed class KolaySunucuKurulumu : Window
{
    [System.Runtime.InteropServices.DllImport("kernel32.dll")] static extern bool FreeConsole();
    readonly TextBox server=new(), database=new(), sqlUser=new(), url=new();
    readonly PasswordBox sqlPass=new(), license=new();
    readonly CheckBox trust=new(){Content="Yalnız yerel SQL için: kurum içi SQL sertifikasını kullan"};
    readonly CheckBox terms=new(){Content="HTTPS için Caddy ve Let's Encrypt koşullarını okudum/kabul ediyorum. Alan adım bu sunucuya yönleniyor."};
    readonly TextBlock status=new(){TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,16,0,10)};
    bool busy;
    Settings? previous;
    internal static void Ac(string address)
    {
        FreeConsole();
        var thread=new Thread(()=>{var app=new System.Windows.Application();app.Run(new KolaySunucuKurulumu(address));});
        thread.SetApartmentState(ApartmentState.STA);thread.Start();thread.Join();
    }
    KolaySunucuKurulumu(string address)
    {
        Title="MiaPaxERP · Ana HTTPS sunucusu";Width=720;Height=850;MinWidth=620;MinHeight=560;WindowStartupLocation=WindowStartupLocation.CenterScreen;
        var p=new StackPanel{Margin=new Thickness(26)};Content=new ScrollViewer{Content=p,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};
        p.Children.Add(new TextBlock{Text="PC ve mobil sunucusunu hazırla",FontSize=25,FontWeight=FontWeights.SemiBold});
        p.Children.Add(new TextBlock{Text="Bu işlemi yalnız ana sunucuda yapın. PC ve mobil servisi program kapalıyken de çalışır. SQL parolası ve ilk lisans anahtarı makineye bağlı şifrelemeyle, yalnız yöneticiler ve servis hesabının erişebildiği klasörde tutulur.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,10,0,12)});
        void Field(string title,Control c){p.Children.Add(new TextBlock{Text=title,Margin=new Thickness(0,10,0,4),FontWeight=FontWeights.SemiBold});c.MinHeight=34;p.Children.Add(c);}
        Field("PC ve mobil HTTPS adresi",url);url.Text=address.Length>0?address:"https://erp.firmaniz.com";
        Field("Yerel SQL sunucusu",server);Field("Veritabanı",database);Field("Servis için SQL kullanıcı adı",sqlUser);Field("SQL parolası",sqlPass);p.Children.Add(trust);
        Field("Lisans anahtarı · ilk kurulumda gerekli",license);
        p.Children.Add(new TextBlock{Text="Servis ayrı Windows hesabında çalışır; bu kurulum SQL kullanıcı adı/parola kullanır. Ana sunucuda ERP kullanıcı tabloları kurulmuş olmalı. Telefon eşlemesi için ayrıca Android / Mobil hesaplar ekranından mobil modülünü hazırlayın. Windows kullanıcı hesabınıza verilen SQL izni servise otomatik geçmez.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,10,0,10)});
        terms.Content=new TextBlock{Text="HTTPS için Caddy ve Let's Encrypt koşullarını okudum/kabul ediyorum. Alan adım bu sunucuya yönleniyor.",TextWrapping=TextWrapping.Wrap,MaxWidth=600};terms.Margin=new Thickness(0,10,0,8);p.Children.Add(terms);
        var links=new WrapPanel();p.Children.Add(links);
        Link(links,"Caddy koşulları / lisans", "https://github.com/caddyserver/caddy/blob/v2.11.9/LICENSE");
        Link(links,"Let's Encrypt koşulları", "https://letsencrypt.org/repository/");
        var bar=new WrapPanel();p.Children.Add(bar);
        Button(bar,"Bilgileri kontrol et",async()=>{await SqlKontrol(Oku().Connection);status.Text="SQL bağlantısı ve kullanıcı tabloları doğrulandı. Henüz servis kurulmadı.";});
        Button(bar,"Kur / güncelle",async()=>
        {
            if(!terms.IsChecked.GetValueOrDefault())throw new ArgumentException("HTTPS sağlayıcısı koşullarını kabul ettikten sonra kuruluma devam edin.");
            var settings=Oku();await SqlKontrol(settings.Connection);
            if(!new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator))throw new InvalidOperationException("Bu pencereyi ana programdaki 'HTTPS sunucusunu hazırla' düğmesiyle yönetici olarak açın.");
            if(MessageBox.Show(this,"MiaPaxERP ve HTTPS servisleri bu sunucuda kurulacak/güncellenecek. HTTPS için dışarıdan TCP 80 ve HTTPS adresinizin portuna yönlendirme gerekir. SQL portu açılmaz. Mevcut mobil servis kısa süre durabilir. Devam edilsin mi?","Ana sunucu kurulumu",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)return;
            await MobilHttpsKurucu.Kur(settings,s=>Dispatcher.Invoke(()=>status.Text=s));
            previous=settings;status.Text="MiaPaxERP ve HTTPS servisleri çalışıyor. Sertifika edinimi/yenilemesi için DNS ve modem yönlendirmesi açık kalmalı. Bağlantı panelinde HTTPS testini çalıştırın; son kontrolü Wi-Fi kapalı telefondan yapın. Yan PC ve telefon aynı HTTPS adresini kullanır.";
        });
        Button(bar,"HTTPS bağlantısını kontrol et",async()=>status.Text=(await KolayBaglantiKontrolu.Https(url.Text.Trim(),false)).Mesaj);
        p.Children.Add(status);
        p.Children.Add(new TextBlock{Text="PC ve mobil aynı HTTPS adresini kullanır. Modemde TCP 80 ve HTTPS portunu (genellikle 443) bu bilgisayara yönlendirin. SQL portunu internete açmayın. Modem ve alan adı ayarlarını kendi hesaplarınızdan yapın.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,14,0,0)});
        try
        {
            var local=MiapaxERPBaglantiAyarlari.Oku();server.Text=local.Sunucu;database.Text=local.Veritabani;sqlUser.Text=local.SqlKullanici;trust.IsChecked=!local.SertifikaDogrula;
            if(local.KimlikDogrulama=="Sql")sqlPass.Password=local.ParolayiCoz();
            if(File.Exists(Program.FilePath)){previous=Program.Read();var cs=new SqlConnectionStringBuilder(previous.Connection);server.Text=cs.DataSource;database.Text=cs.InitialCatalog;sqlUser.Text=cs.UserID;sqlPass.Password=cs.Password;trust.IsChecked=cs.TrustServerCertificate;if(address.Length==0&&previous.HttpsAddress.Length>0)url.Text=previous.HttpsAddress;}
        }
        catch(Exception e)when(e is IOException or CryptographicException or JsonException or ArgumentException or UnauthorizedAccessException or FormatException){status.Text="Önceki ayarlar otomatik okunamadı. Mevcut ayarlar değiştirilmedi; bilgileri kontrol ederek girin.";}
        Closing+=(_,e)=>{if(busy){e.Cancel=true;status.Text="Kurulum veya kontrol sürüyor. Tamamlandıktan sonra pencereyi kapatabilirsiniz.";}};
    }
    void Link(Panel p,string text,string address){var b=new System.Windows.Controls.Button{Content=text,Margin=new Thickness(0,4,8,4),Padding=new Thickness(8)};p.Children.Add(b);b.Click+=(_,_)=>Process.Start(new ProcessStartInfo(address){UseShellExecute=true});}
    void Button(Panel p,string text,Func<Task> action){var b=new System.Windows.Controls.Button{Content=text,Margin=new Thickness(0,8,8,4),Padding=new Thickness(12,9,12,9)};p.Children.Add(b);b.Click+=async(_,_)=>{if(busy)return;busy=true;b.IsEnabled=false;try{await action();}catch(Exception e){status.Text="İşlem tamamlanmadı: "+(e is SqlException?"SQL bağlantısı, servis hesabı izni veya sertifika doğrulanamadı. Sunucu ve SQL bilgilerini kontrol edin.":e.Message);}finally{busy=false;b.IsEnabled=true;}};}
    Settings Oku()
    {
        var address=KolayBaglantiProfili.KisaAdres(KolayBaglantiProfili.Https(url.Text.Trim()));
        if(server.Text.Trim().Length==0||database.Text.Trim().Length==0||sqlUser.Text.Trim().Length==0||sqlPass.Password.Length==0)throw new ArgumentException("Yerel SQL sunucusu, veritabanı, kullanıcı adı ve parolayı doldurun.");
        string key=license.Password.Trim();if(key.Length>0&&!System.Text.RegularExpressions.Regex.IsMatch(key,"^[a-fA-F0-9]{64}$"))throw new ArgumentException("Lisans anahtarı 64 onaltılık karakter olmalı.");
        if(key.Length==0&&previous is null)throw new ArgumentException("İlk kurulum için lisans anahtarını girin.");
        var cs=new SqlConnectionStringBuilder{DataSource=server.Text.Trim(),InitialCatalog=database.Text.Trim(),UserID=sqlUser.Text.Trim(),Password=sqlPass.Password,Encrypt=SqlConnectionEncryptOption.Mandatory,TrustServerCertificate=trust.IsChecked==true,ConnectTimeout=15,ApplicationName="MiapaxERP Mobil Sunucu"};
        return new(cs.ConnectionString,key.Length>0?key:previous?.ActivationKey,address);
    }
    static async Task SqlKontrol(string connection)
    {
        using var c=new SqlConnection(connection);await c.OpenAsync();
        using var cmd=new SqlCommand("SELECT CASE WHEN OBJECT_ID('dbo.Kullanicilar','U') IS NOT NULL AND OBJECT_ID('dbo.KullaniciRolAtamalari','U') IS NOT NULL AND OBJECT_ID('dbo.KullaniciRolleri','U') IS NOT NULL THEN 1 ELSE 0 END",c);
        if(Convert.ToInt32(await cmd.ExecuteScalarAsync())!=1)throw new InvalidOperationException("Ana sunucuda ERP kullanıcı ve rol tabloları bulunamadı. Veritabanını ve mevcut ERP kurulumunu kontrol edin.");
    }
}

internal static class MobilHttpsKurucu
{
    internal const string CaddyVersion="2.11.9";
    internal static string CaddyConfig(string address,string storage)
    {
        var u=KolayBaglantiProfili.Https(address);storage=Path.GetFullPath(storage).Replace('\\','/');
        if(storage.Contains('"')||storage.Any(char.IsControl))throw new ArgumentException("Sertifika depolama yolu geçersiz.");
        return $$"""
        {
            admin off
            auto_https disable_redirects
            storage file_system {
                root "{{storage}}"
            }
        }
        {{KolayBaglantiProfili.KisaAdres(u)}} {
            tls {
                issuer acme {
                    disable_tlsalpn_challenge
                }
            }
            @erp path /api/mobile/v2/* /api/desktop/v1/*
            handle @erp {
                reverse_proxy 127.0.0.1:5188
            }
            handle {
                respond "MiaPaxERP" 404
            }
            header {
                Strict-Transport-Security "max-age=31536000"
                X-Content-Type-Options "nosniff"
            }
        }
        """;
    }
    static async Task<string> Run(string exe,params string[] args)
    {
        var start=new ProcessStartInfo(exe){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true};foreach(string a in args)start.ArgumentList.Add(a);
        using var p=Process.Start(start)??throw new IOException("Kurulum aracı başlatılamadı.");var output=p.StandardOutput.ReadToEndAsync();var error=p.StandardError.ReadToEndAsync();
        try{await p.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(60));}catch(System.TimeoutException){p.Kill(true);throw new IOException("Kurulum komutu zamanında tamamlanmadı.");}
        if(p.ExitCode!=0)throw new IOException(Path.GetFileName(exe)+" işlemi başarısız ("+p.ExitCode+"). Servis/port çakışmasını ve yönetici iznini kontrol edin.");await error;return await output;
    }
    sealed record ServiceState(string Name,bool Exists,string Path,bool Running);
    static ServiceState State(string name)
    {
        using var key=Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\"+name);
        if(key is null)return new(name,false,"",false);using var s=new ServiceController(name);return new(name,true,Convert.ToString(key.GetValue("ImagePath"))??"",s.Status==ServiceControllerStatus.Running);
    }
    static async Task Stop(ServiceState s){if(!s.Exists)return;using var service=new ServiceController(s.Name);if(service.Status==ServiceControllerStatus.Stopped)return;await Run("sc.exe","stop",s.Name);await Task.Run(()=>service.WaitForStatus(ServiceControllerStatus.Stopped,TimeSpan.FromSeconds(35)));}
    static async Task Start(string name){await Run("sc.exe","start",name);await Task.Run(()=>{using var s=new ServiceController(name);s.WaitForStatus(ServiceControllerStatus.Running,TimeSpan.FromSeconds(35));});}
    static async Task Configure(ServiceState old,string path,string display)
    {
        if(old.Exists)await Run("sc.exe","config",old.Name,"binPath=",path);
        else { await Run("sc.exe","create",old.Name,"binPath=",path,"start=","auto","DisplayName=",display); await Run("sc.exe","failure",old.Name,"reset=","86400","actions=","restart/30000/restart/60000/restart/120000"); }
    }
    static async Task CaddyIndir(string folder)
    {
        string asset=$"caddy_{CaddyVersion}_windows_amd64.zip",root=$"https://github.com/caddyserver/caddy/releases/download/v{CaddyVersion}/";
        using var http=new HttpClient(){Timeout=TimeSpan.FromMinutes(3),MaxResponseContentBufferSize=40*1024*1024};http.DefaultRequestHeaders.UserAgent.ParseAdd("MiapaxERP-Setup/2.8.1");
        string checks=await http.GetStringAsync(root+$"caddy_{CaddyVersion}_checksums.txt");
        var line=checks.Split('\n').Select(l=>l.Split((char[]?)null,StringSplitOptions.RemoveEmptyEntries)).SingleOrDefault(a=>a.Length==2&&a[1].TrimStart('*')==asset);
        if(line is null||!System.Text.RegularExpressions.Regex.IsMatch(line[0],"^[A-Fa-f0-9]{64}$"))throw new IOException("Resmî HTTPS aracı sağlama toplamı doğrulanamadı. Kurulum durduruldu.");
        var bytes=await http.GetByteArrayAsync(root+asset);
        if(!Convert.ToHexString(SHA256.HashData(bytes)).Equals(line[0],StringComparison.OrdinalIgnoreCase))throw new IOException("HTTPS aracı dosya doğrulaması başarısız. Dosya çalıştırılmadı.");
        using var zip=new ZipArchive(new MemoryStream(bytes));var exe=zip.GetEntry("caddy.exe")??throw new IOException("HTTPS aracı arşivi geçersiz.");
        await using(var source=exe.Open())await using(var output=File.Create(Path.Combine(folder,"caddy.exe")))await source.CopyToAsync(output);
        var license=zip.Entries.FirstOrDefault(e=>e.FullName.Equals("LICENSE",StringComparison.OrdinalIgnoreCase));
        if(license is not null){using var source=license.Open();using var output=File.Create(Path.Combine(folder,"CADDY-LICENSE.txt"));source.CopyTo(output);}
    }
    public static async Task Kur(Settings settings,Action<string> progress)
    {
        var uri=KolayBaglantiProfili.Https(settings.HttpsAddress);
        string folder=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),"MiapaxERP MobilSunucu","kurulum-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(folder);
        progress("Gerekli sunucu dosyaları hazırlanıyor…");
        foreach(string file in Directory.EnumerateFiles(AppContext.BaseDirectory,"*",SearchOption.AllDirectories))
        {
            string relative=Path.GetRelativePath(AppContext.BaseDirectory,file);if(relative.Split(Path.DirectorySeparatorChar).Any(s=>s is "obj" or ".vs"))continue;
            string target=Path.Combine(folder,relative);Directory.CreateDirectory(Path.GetDirectoryName(target)!);File.Copy(file,target);
        }
        progress("HTTPS aracı resmî kaynaktan indiriliyor ve dosyası doğrulanıyor…");await CaddyIndir(folder);
        string config=Path.Combine(Program.Folder,"Caddyfile"),configBody=CaddyConfig(settings.HttpsAddress,Path.Combine(Program.Folder,"https-sertifikalari"));
        string stagedConfig=Path.Combine(folder,"Caddyfile.validate");File.WriteAllText(stagedConfig,configBody,Encoding.UTF8);
        await Run(Path.Combine(folder,"caddy.exe"),"validate","--config",stagedConfig,"--adapter","caddyfile");
        var mobile=State("MiapaxERPMobil");var proxy=State("MiapaxERPHTTPS");
        byte[]? oldSettings=File.Exists(Program.FilePath)?File.ReadAllBytes(Program.FilePath):null;
        byte[]? oldConfig=File.Exists(config)?File.ReadAllBytes(config):null;
        string backup=Path.Combine(Program.Folder,"KurulumYedekleri",Guid.NewGuid().ToString("N"));Directory.CreateDirectory(backup);
        var acl=new System.Security.AccessControl.DirectorySecurity();acl.SetAccessRuleProtection(true,false);
        foreach(var sid in new[]{WellKnownSidType.BuiltinAdministratorsSid,WellKnownSidType.LocalSystemSid})acl.AddAccessRule(new System.Security.AccessControl.FileSystemAccessRule(new SecurityIdentifier(sid,null),System.Security.AccessControl.FileSystemRights.FullControl,System.Security.AccessControl.InheritanceFlags.ContainerInherit|System.Security.AccessControl.InheritanceFlags.ObjectInherit,System.Security.AccessControl.PropagationFlags.None,System.Security.AccessControl.AccessControlType.Allow));
        new DirectoryInfo(backup).SetAccessControl(acl);
        if(oldSettings is not null)File.WriteAllBytes(Path.Combine(backup,"ayarlar.dpapi"),oldSettings);
        if(oldConfig is not null)File.WriteAllBytes(Path.Combine(backup,"Caddyfile"),oldConfig);
        var createdRules=new List<string>();
        bool mobileChanged=false,proxyChanged=false;
        try
        {
            progress("Mobil servis ve HTTPS servisi hazırlanıyor…");await Stop(proxy);await Stop(mobile);
            Program.Store(settings);File.WriteAllText(config,configBody,Encoding.UTF8);
            string exe=Path.Combine(folder,"MiapaxERP.MobileServer.exe");
            mobileChanged=true;await Configure(mobile,'"'+exe+'"',"MiaPaxERP Mobil Sunucu");
            proxyChanged=true;await Configure(proxy,'"'+exe+"\" https-proxy","MiaPaxERP HTTPS");
            await Start(mobile.Name);await Start(proxy.Name);
            foreach(int port in new[]{80,uri.Port}.Distinct())
            {
                string name="MiaPaxERP-HTTPS-"+port+"-"+Guid.NewGuid().ToString("N");
                await Run("netsh.exe","advfirewall","firewall","add","rule","name="+name,"dir=in","action=allow","protocol=TCP","localport="+port,"program="+Path.Combine(folder,"caddy.exe"),"profile=any");createdRules.Add(name);
            }
            using var http=new HttpClient(){Timeout=TimeSpan.FromSeconds(2)};bool ready=false;
            for(int i=0;i<20;i++){try{var result=await http.GetStringAsync("http://127.0.0.1:5188/internal/ready");using var body=JsonDocument.Parse(result);if(body.RootElement.GetProperty("ready").GetBoolean()){ready=true;break;}}catch(HttpRequestException){}catch(TaskCanceledException){}await Task.Delay(500);}
            if(!ready)throw new IOException("Ana sunucunun lisansı ve veritabanı doğrulanamadı; önceki kurulum geri yüklenecek.");
            if(!State(proxy.Name).Running)throw new IOException("HTTPS servisi durdu. 80/443/8443 port çakışmasını kontrol edin.");
        }
        catch(Exception original)
        {
            progress("Kurulum tamamlanmadı; önceki servis ayarları geri yükleniyor…");
            var errors=new List<Exception>();
            async Task Undo(Func<Task> step){try{await step();}catch(Exception ex){errors.Add(ex);}}
            foreach(string name in createdRules)await Undo(async()=>{await Run("netsh.exe","advfirewall","firewall","delete","rule","name="+name);});
            foreach(var s in new[]{proxy,mobile})await Undo(async()=>{var current=State(s.Name);if(current.Exists)await Stop(current);});
            await Undo(()=>{if(oldSettings is not null)File.WriteAllBytes(Program.FilePath,oldSettings);else if(File.Exists(Program.FilePath))File.Delete(Program.FilePath);return Task.CompletedTask;});
            await Undo(()=>{if(oldConfig is not null)File.WriteAllBytes(config,oldConfig);else if(File.Exists(config))File.Delete(config);return Task.CompletedTask;});
            foreach(var s in new[]{mobile,proxy})await Undo(async()=>
            {
                if(s.Exists){await Run("sc.exe","config",s.Name,"binPath=",s.Path);if(s.Running)await Start(s.Name);}
                else if(s.Name==mobile.Name?mobileChanged:proxyChanged){if(State(s.Name).Exists)await Run("sc.exe","delete",s.Name);}
            });
            if(errors.Count>0)throw new IOException("Kurulum ve geri dönüşün bazı adımları tamamlanamadı. Servisleri kontrol edin. Korumalı önceki ayar yedeği: "+backup+". İlk hata türü: "+original.GetType().Name);
            throw;
        }
    }
}

internal sealed class HttpsProxyServisi : BackgroundService
{
    public static async Task Calistir()
    {
        var b=Host.CreateApplicationBuilder();b.Services.AddWindowsService(o=>o.ServiceName="MiapaxERPHTTPS");b.Services.AddHostedService<HttpsProxyServisi>();await b.Build().RunAsync();
    }
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var settings=Program.Read();_=KolayBaglantiProfili.Https(settings.HttpsAddress);
        var start=new ProcessStartInfo(Path.Combine(AppContext.BaseDirectory,"caddy.exe")){UseShellExecute=false,CreateNoWindow=true,WorkingDirectory=Program.Folder};
        foreach(string a in new[]{"run","--config",Path.Combine(Program.Folder,"Caddyfile"),"--adapter","caddyfile"})start.ArgumentList.Add(a);
        using var process=Process.Start(start)??throw new IOException("HTTPS işlemi başlatılamadı.");
        try{await process.WaitForExitAsync(stoppingToken);if(!stoppingToken.IsCancellationRequested)throw new IOException("HTTPS işlemi beklenmedik şekilde durdu: "+process.ExitCode);}
        catch(OperationCanceledException)when(stoppingToken.IsCancellationRequested){}
        finally{if(!process.HasExited)process.Kill(true);}
    }
}
